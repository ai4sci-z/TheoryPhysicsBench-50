# 发布包与文件验收

`tools/package_benchmark50.py`只复制白名单文件，不修改或删除开发工作区。默认预览文件清单；`--draft`生成明确标注为草稿的测试包；`--build`要求50题校准、整套预检和最终Harbor版本证据通过后，才生成开发验收发布包。

```bash
python3 tools/package_benchmark50.py
python3 tools/package_benchmark50.py --build
python3 tools/package_benchmark50.py --verify /absolute/path/TheoryPhysicsBench-50.zip
python3 tools/scan_release.py /absolute/path/TheoryPhysicsBench-50
```

默认输出位于项目父目录的`03-发布包/release-时间戳/`，每次使用新目录，不覆盖旧包。ZIP顶层为`TheoryPhysicsBench-50/`；旁边的`package-validation.json`记录压缩包SHA256和验证结果。

包内`release-files.json`记录其余每个文件的相对路径、大小和SHA256。验证器检查ZIP条目路径、重复文件、符号链接、文件集合和逐文件哈希，然后解压到临时目录再次检查。清单本身不自哈希，压缩包的整体SHA256保存在包外验证记录中。

发布保留逐题任务、公开材料、参考解、隔离真值、数值校准、来源说明、原始Harbor运行及复现工具。`runs/`内所有已归档开发尝试均保留，包括失败，不按分数挑选记录。若正式`results.csv`、`ta_results.csv`与原始运行确实存在，也按原文件保留；没有时不生成。

原书PDF、教材截图、整本OCR、`planning/source-notes/`、临时目录、缓存、本地`course.env`与凭据文件不进入发布包。`course.env.example`保留空版本字段，由课程统一填写。教材来源页码仍在逐题说明中，第三方书籍不随包分发。

`scan_release.py`扫描已准备发布的树，不输出任何命中值，只输出路径、模式类型和次数。它检查已知凭据格式和敏感配置文件名，属于可复现的发布检查，不声称能够识别所有未知凭据。GitHub Actions对提交树运行同一检查，checkout固定到提交SHA。

开发验收包与课程正式结果是不同阶段。当前正式模型完成状态以报告及原始`runs/codex/`为准；打包工具不会把oracle、空提交或离线自检标记成课程指定模型的三次测评。
