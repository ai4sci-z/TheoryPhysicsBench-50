# 50题正式测评入口

`tools/run_formal_benchmark50.py` 是用户与助教沟通过的50题扩展运行入口。课程原版材料的10–20题限制仍保留原文，本入口不声称已改变该限制。它沿用逐题 Harbor 0.24.0 合同、Codex + `gpt-6.1-sol` / `max`、每题3次独立尝试、并发1、不自动重试，以及每轮全部题43200秒预算。

课程原版 `tools/course/正式测评.sh`、`检查提交.py`、`汇总结果.py`、`quality_score.py` 保持不变。50题预检由 `tools/check_benchmark50.py --require-calibrated` 承担；结果表只由课程原版汇总器读取真实原始记录后生成。

## 助教统一配置

将助教给定的 CLI 版本写入一个无凭据的 `course.env`，例如项目内 `tools/course/course.env`。内容只能包含以下三个字面字段；引号和整行注释可用：

```text
MODEL='gpt-6.1-sol'
REASONING_EFFORT='max'
CLI_VERSION='助教提供的实际版本'
```

示例最后一行必须替换成助教给定的非空版本字符串。配置不存 API key、token、命令或环境变量引用；入口不执行 `source`，未知字段、重复字段、shell语法、错误模型与空版本会被拒绝。认证使用既有 Codex/Harbor 支持的课程环境，入口不会读取或输出凭据。

## 先预览

在项目根目录运行：

```bash
python3 tools/run_formal_benchmark50.py --config tools/course/course.env
```

不加运行模式时默认为 dry-run，只展示固定配置、将执行的命令、清单/逐题哈希和目标归档路径。它不会启动 Harbor、调用模型、创建正式结果目录或伪造 `results.csv`。没有助教CLI版本时先完成配置，入口不会猜测版本。

## 正式运行

```bash
python3 tools/run_formal_benchmark50.py --config tools/course/course.env --execute
```

仅这条显式 `--execute` 会运行正式模型。入口会依次检查 Harbor 恰为0.24.0、50题完整校准预检、清单和题包哈希、原版课程工具哈希以及正式结果目录不存在。`runs/codex` 已存在时拒绝覆盖或续写；不删除有效失败，不挑选最好的一次结果。

源路径可能含中文、空格和 `%`。入口将题包逐文件复制到 `/tmp/physics-formal50-*` 的 ASCII 安全路径，再核对清单与每题哈希。复制范围仅为 `benchmark.json` 和 `tasks`，不夹带项目根部 `checks`、开发工具或历史运行；逐题 Harbor 镜像仍只由 `environment/` 构建。参考解与隔离verifier按正常Harbor机制处理，不把它们复制进公开agent环境。

Harbor 使用如下固定关键参数：

```text
-a codex -m gpt-6.1-sol --ak version=<助教固定版本> --effort max
--n-attempts 3 --n-concurrent 1 --max-retries 0
```

所有原始job先写安全暂存路径，结束或中断后完整复制归档至 `runs/codex`，并逐文件核对归档哈希。源目录保留逐题冻结信息 `.formal50-frozen-input.json` 和入口运行记录 `.formal50-runner-record.json`。运行前后再次检查源题包、暂存副本和课程工具；发生变化时保留所有证据并停止自动汇总。暂存副本保留，便于审查和故障恢复，不自动删除原始记录。

实际Harbor命令失败时返回其非零退出码，仍保存已产生的原始记录。基础设施异常不能编造为模型零分；课程汇总器也会拒绝异常、不足三次或配置不一致的原始记录。

## 独立助教复测与汇总

助教全题独立复测使用单独目录：

```bash
python3 tools/run_formal_benchmark50.py --config tools/course/course.env --ta --execute
```

它写 `runs/ta-codex`，同样每题3次，不覆盖学生原始记录。

成功执行后会自动调用课程原版 `汇总结果.py`。也可对已有完整冻结记录单独汇总，不启动模型：

```bash
python3 tools/run_formal_benchmark50.py --summarize
python3 tools/run_formal_benchmark50.py --ta --summarize
```

汇总器分别生成 `results.csv` 和 `ta_results.csv`；每套50题应有150条真实可核实记录。开发用 `oracle=1/nop=0`、本地参考解校准和本入口离线自检均不是这150次正式Codex测评。

## 离线开发自检

```bash
python3 tools/test_formal_benchmark50.py
```

测试使用临时目录和模拟子进程，覆盖配置字面解析、拒绝shell语法、默认dry-run、固定三次/并发/重试参数、拒绝覆盖、ASCII暂存、逐题哈希一致、原始记录完整归档、失败退出及源题变化拦截。不会访问网络、调用正式模型或生成项目正式结果表。
