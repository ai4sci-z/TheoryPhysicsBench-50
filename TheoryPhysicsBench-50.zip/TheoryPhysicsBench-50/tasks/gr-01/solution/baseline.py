"""Effective-potential capture test plus straight-ray/weak-field observables."""
import argparse
import json
import math
from pathlib import Path


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--data-root",type=Path,default=Path("/app/data"));parser.add_argument("--output",type=Path,default=Path("/app/output/answer.json"));args=parser.parse_args()
    model=json.loads((args.data_root/"model.json").read_text(encoding="utf-8"));cases=[]
    bc=3*math.sqrt(3)
    for case in model["cases"]:
        d=case["delta"]
        if d>0:
            impact=bc*(1+d);alpha=4/impact
            entry={"id":case["id"],"outcome":"scatter","r_min":impact,"alpha":alpha,"full_turns":math.floor((math.pi+alpha)/(2*math.pi))}
        else:entry={"id":case["id"],"outcome":"capture" if d<0 else "critical","r_min":None,"alpha":None,"full_turns":None}
        cases.append(entry)
    images=[{"id":image["id"],"log10_delta":math.log10(max(1e-15,4/(bc*image["target_alpha"])-1))} for image in model["images"]]
    answer={"cases":cases,"images":images,"method":"capture threshold from potential maximum; straight closest approach; first-order 4M/b bending; clamp infeasible weak-field inverse to declared lower endpoint"}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(answer,ensure_ascii=False))


if __name__=="__main__":main()
