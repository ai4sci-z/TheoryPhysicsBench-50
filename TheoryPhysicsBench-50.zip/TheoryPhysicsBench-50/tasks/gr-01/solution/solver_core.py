"""Double precision, singularity-removed quadrature; public parameters only."""
import math


def simpson_adaptive(function,left,right,tolerance=2e-13):
    midpoint=(left+right)/2
    fa,fm,fb=function(left),function(midpoint),function(right)
    estimate=(right-left)*(fa+4*fm+fb)/6
    def refine(a,b,fa,fm,fb,previous,tol,depth):
        m=(a+b)/2;l=(a+m)/2;r=(m+b)/2
        fl,fr=function(l),function(r)
        low=(m-a)*(fa+4*fl+fm)/6;high=(b-m)*(fm+4*fr+fb)/6
        correction=low+high-previous
        if abs(correction)<=15*tol:return low+high+correction/15
        if depth==0:raise ArithmeticError("quadrature tolerance not reached")
        return refine(a,m,fa,fl,fm,low,tol/2,depth-1)+refine(m,b,fm,fr,fb,high,tol/2,depth-1)
    return refine(left,right,fa,fm,fb,estimate,tolerance,28)


def scattering(delta):
    if delta<=0:raise ValueError("scattering requires delta>0")
    q=delta*(2+delta)/(1+delta)**2
    lo,hi=0.0,1.0
    for _ in range(90):
        s=(lo+hi)/2
        if s*s*(3-2*s)<q:lo=s
        else:hi=s
    s=(lo+hi)/2;u0=(1-s)/3;a=2*s
    endpoint=math.asinh(1/math.sqrt(a))
    def transformed(y):
        t=math.sqrt(a)*math.sinh(y)
        t2=t*t
        return 1/math.sqrt(1-(a*t2+2*u0*t2*t2)/(a+t2))
    total_angle=4*simpson_adaptive(transformed,0,endpoint)
    return {"r_min":1/u0,"alpha":total_angle-math.pi,"full_turns":math.floor(total_angle/(2*math.pi))}


def solve_model(model):
    cases=[]
    for case in model["cases"]:
        delta=case["delta"]
        if delta>0:entry={"id":case["id"],"outcome":"scatter",**scattering(delta)}
        else:entry={"id":case["id"],"outcome":"capture" if delta<0 else "critical","r_min":None,"alpha":None,"full_turns":None}
        cases.append(entry)
    images=[]
    for image in model["images"]:
        lo,hi=model["inverse_log10_delta_interval"]
        target=image["target_alpha"]
        if not scattering(10**lo)["alpha"]>target>scattering(10**hi)["alpha"]:raise ValueError("inverse target not bracketed")
        for _ in range(52):
            z=(lo+hi)/2
            if scattering(10**z)["alpha"]>target:lo=z
            else:hi=z
        images.append({"id":image["id"],"log10_delta":(lo+hi)/2})
    return {"cases":cases,"images":images,"method":"outer radial root; two endpoint transformations; adaptive quadrature; inverse bisection in log impact excess"}
