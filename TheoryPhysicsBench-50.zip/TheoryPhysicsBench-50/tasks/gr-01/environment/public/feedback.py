"""Check format and the submitted turning point using only public equations."""
import argparse
import json
import math
from pathlib import Path
from physics import load_model,turning_residual,validate_answer


def main():
    parser=argparse.ArgumentParser();parser.add_argument("answer",type=Path);args=parser.parse_args()
    model=load_model(Path(__file__).parent)
    try:answer=json.loads(args.answer.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):print(json.dumps({"valid":False,"reason":"没有有效 JSON"},ensure_ascii=False));return
    mapped,reason=validate_answer(answer,model)
    result={"valid":reason is None,"reason":reason}
    if reason is None:
        result["turning_checks"]=[]
        for case in model["cases"]:
            entry=mapped["cases"][case["id"]]
            if entry["outcome"]=="scatter":
                result["turning_checks"].append({"id":case["id"],"null_geodesic_residual":turning_residual(case["delta"],entry["r_min"]),"outside_photon_sphere":entry["r_min"]>3,"turn_count_consistent":entry["full_turns"]==math.floor((math.pi+entry["alpha"])/(2*math.pi))})
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=="__main__":main()
