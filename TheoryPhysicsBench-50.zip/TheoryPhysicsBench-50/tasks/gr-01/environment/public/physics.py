"""Public model, schema and geodesic diagnostics; no reference answers."""
import json
import math
from pathlib import Path


def load_model(root="/app/data"):
    return json.loads((Path(root)/"model.json").read_text(encoding="utf-8"))


def finite(value):
    try:
        return type(value) in (int,float) and math.isfinite(value)
    except OverflowError:
        return False


def validate_answer(answer,model):
    if not isinstance(answer,dict):return None,"根对象须为 JSON 对象"
    result={}
    for key in ("cases","images"):
        entries=answer.get(key)
        expected={entry["id"] for entry in model[key]}
        if not isinstance(entries,list) or len(entries)!=len(expected):return None,f"{key} 须覆盖全部公开 id"
        mapped={}
        for entry in entries:
            if not isinstance(entry,dict) or type(entry.get("id")) is not str:return None,"须含字符串 id"
            identifier=entry["id"]
            if identifier not in expected or identifier in mapped:return None,"id 未知或重复"
            if key=="cases":
                outcome=entry.get("outcome")
                if outcome not in ("capture","critical","scatter"):return None,"outcome 须为 capture、critical 或 scatter"
                if outcome=="scatter":
                    if not finite(entry.get("r_min")) or entry["r_min"]<=0:return None,"散射的 r_min 须为正有限实数"
                    if not finite(entry.get("alpha")) or entry["alpha"]<0:return None,"alpha 须为非负有限实数"
                    if type(entry.get("full_turns")) is not int or entry["full_turns"]<0:return None,"full_turns 须为非负整数"
                elif any(entry.get(field,"missing") is not None for field in ("r_min","alpha","full_turns")):
                    return None,"capture/critical 的三个数值字段须显式填 null"
            elif not finite(entry.get("log10_delta")) or not -18<=entry["log10_delta"]<=6:
                return None,"log10_delta 须为 [-18,6] 内有限实数"
            mapped[identifier]=entry
        result[key]=mapped
    return result,None


def turning_residual(delta,r_min):
    # q avoids cancellation in 1-(1+delta)^(-2).
    q=delta*(2+delta)/(1+delta)**2
    u=1/r_min
    return (1-q)/27-u*u+2*u**3


def effective_potential(u):
    return u*u*(1-2*u)
