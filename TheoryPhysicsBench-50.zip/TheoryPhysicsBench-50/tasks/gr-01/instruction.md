# 施瓦西强场光线的散射、捕获与反向冲量参数

## 研究问题

光子在黑洞附近可以直接落入视界，也可以绕黑洞若干圈后逃向远方。弱场偏折公式不能可靠描述后者。本题研究从过去无穷远入射、位于施瓦西黑洞赤道面的类光测地线，要求完成跨越捕获阈值的前向计算，并由指定偏折角反求冲量参数。

取几何单位 \(G=c=M=1\)，度规为

\[
ds^2=-(1-2/r)dt^2+(1-2/r)^{-1}dr^2+r^2d\varphi^2.
\]

守恒量为 \(E=(1-2/r)\dot t\)、\(L=r^2\dot\varphi\)，点表示仿射参数导数。规定 \(L,E>0\)，令无量纲冲量参数 \(B=L/E\)、\(u=1/r\)，则

\[
\left(\frac{du}{d\varphi}\right)^2=\frac{1}{B^2}-u^2+2u^3.
\]

公开材料用精确约定 \(B=3\sqrt3(1+\delta)\) 指定光线。输入字段 `delta` 是定义该工况的权威数值；不要先把 \(B\) 舍入再用减法重建 \(\delta\)。所有工况均为从无穷远向内入射。

每条光线须区分：

- `capture`：穿过未来事件视界，不返回无穷远；
- `critical`：渐近趋近不稳定光子圆轨道，不在有限角度发生散射转折；
- `scatter`：存在从入射方向可达的外转折点，之后返回无穷远。

对散射光线报告最近距离 \(r_{\min}>3\) 及**未对 \(2\pi\) 取模的**总偏折角

\[
\alpha=2\int_0^{u_0}\frac{du}{\sqrt{B^{-2}-u^2+2u^3}}-\pi,
\qquad u_0=1/r_{\min}.
\]

\(u_0\) 应是从 \(u=0\) 向内演化时首先到达的正根。另报告累计方位角 \(\Delta\varphi=\alpha+\pi\) 中完整的周数 `full_turns`，定义为 \(\lfloor\Delta\varphi/(2\pi)\rfloor\)。它依据累计方位角定义，不是把偏折角取模后的像方位。

反向计算的四组 `images` 给定目标 `target_alpha`（弧度），要求求出唯一散射支上的 `log10_delta`，使未取模的 \(\alpha\) 等于该目标。在公开区间 \(\log_{10}\delta\in[-15,3]\) 内求解；各目标在该区间内均有唯一解。

## 公开材料与工具

- `/app/data/model.json`：10 条光线的 `id`、`delta`，4 个反向目标的 `id`、`target_alpha`，及反向搜索区间。
- `/app/data/physics.py`：读取模型、输出格式校验、径向转折残差和有效势函数。只包含公开方程，不包含参考答案。
- `/app/data/feedback.py`：对尝试提交进行格式检查，报告转折残差、是否位于光子球外侧，以及所报周数与偏折角是否自洽。
- `/app/data/metric.json`：固定指标、容差和基线/参考端点。
- Python 3.12、NumPy 2.1.3、SciPy 1.14.1、mpmath 1.3.0，可自行选择数值方法。

最小读取示例：

```python
import sys
sys.path.insert(0, "/app/data")
from physics import load_model, effective_potential
print(load_model()["cases"][0])
print(effective_potential(1/3))
```

## 探索与反馈

可从有效势 \(V(u)=u^2(1-2u)\) 的外部极值入手判断捕获边界，再选择转折根和适合近临界光线的积分方法。仅验证三次方程残差不足以说明根来自正确的入射支；还需考虑它与光子球的位置及入射路径。弱场结果 \(\alpha\simeq4/B\) 可用于远离黑洞时的量级检查。

写出符合最终格式的尝试文件后执行：

```bash
python /app/data/feedback.py /app/output/trial.json
```

反馈次数不限。该命令不提供独立真值、完整正确分类或最终得分。允许采用径向积分、椭圆积分、测地线数值积分等任何等价方法；最终按物理数值与分类评分，不按代码与参考解相似程度评分。

## 最终产物

提交 `/app/output/answer.json`，包含 `cases` 和 `images` 两个数组。每个公开 `id` 恰好一项，数组顺序不限。例如以下只用于说明字段：

```json
{
  "cases": [
    {"id":"ray-01","outcome":"capture","r_min":null,"alpha":null,"full_turns":null},
    {"id":"ray-04","outcome":"scatter","r_min":3.1,"alpha":10.0,"full_turns":2}
  ],
  "images": [
    {"id":"image-01","log10_delta":0.0}
  ]
}
```

真实提交必须覆盖全部 10 条光线和 4 个反向目标。`scatter` 的 `r_min` 为正有限实数，`alpha` 为非负有限实数，`full_turns` 为非负整数；`capture` 和 `critical` 三个数值字段均显式填 `null`。临界光线的无限累计角不能用 JSON `Infinity` 表示。`log10_delta` 为有限实数，格式允许范围 `[-18,6]`；求解区间仍为上述公开区间。可附加字符串 `method`，不参与评分。

## 固定评分

采用全部公开固定工况，验证器对照独立高精度重算结果。用帽号表示独立真值。

单条光线：分类错误记误差 1；正确的捕获/临界分类记 0；正确散射分类记

\[
e_j=0.2\min\left(1,\frac{|r_{\min}-\hat r_{\min}|}{\hat r_{\min}}\right)
+0.6\min\left(1,\frac{|\alpha-\hat\alpha|}{\max(\hat\alpha,0.05)}\right)
+0.2\,\mathbf1[\texttt{full\_turns}\ne\hat n].
\]

每个反向目标的误差为

\[
d_k=\min\left(1,\frac{|\log_{10}\delta-\widehat{\log_{10}\delta}|}{3}\right).
\]

总原始指标为 \(100[0.75\,\mathrm{mean}(e_j)+0.25\,\mathrm{mean}(d_k)]\)，单位百分点，越低越好。三个数量级的反向冲量误差达到该分项最大误差；更准确结果连续获得改善。各权重、归一化和截断预先固定。

简单基线使用有效势最大值判断捕获，散射时以直线路径的 \(r_{\min}\simeq B\) 及一阶弱场偏折 \(4/B\) 估计。用相同弱场式反求冲量参数；无正解时截到公开搜索下端。参考解使用完整测地线积分与反向求根，两者读取完全相同的公开数据并采用相同资源和评分。缺项、重复 id、非法分类、非有限数、布尔值冒充数字等格式错误视为无效产物；格式正确但物理错误的结果按上述指标评分。

## 时间与资源

Agent 720 秒，verifier 120 秒，4 CPU、4 GB 内存、4 GB 磁盘、0 GPU。公开反馈和最终结果都可离线计算，不需要加载大模型权重或连接服务器。
