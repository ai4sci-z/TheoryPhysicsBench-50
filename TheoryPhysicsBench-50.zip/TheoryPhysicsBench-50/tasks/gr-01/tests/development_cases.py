import copy


def make_cases(reference):
    equivalent=copy.deepcopy(reference);equivalent["cases"].reverse();equivalent["images"].reverse()
    wrong=copy.deepcopy(reference)
    for case in wrong["cases"]:
        case.update(outcome="capture",r_min=None,alpha=None,full_turns=None)
    for image in wrong["images"]:image["log10_delta"]=6
    no_winding=copy.deepcopy(reference)
    for case in no_winding["cases"]:
        if case["outcome"]=="scatter":case["full_turns"]=0
    modulo=copy.deepcopy(reference)
    for case in modulo["cases"]:
        if case["outcome"]=="scatter":case["alpha"]%=6.283185307179586
    critical=copy.deepcopy(reference);critical["cases"][2]["outcome"]="capture"
    inner=copy.deepcopy(reference);inner["cases"][3]["r_min"]=2.9
    duplicate=copy.deepcopy(reference);duplicate["cases"][0]["id"]=duplicate["cases"][1]["id"]
    boolean=copy.deepcopy(reference);boolean["cases"][3]["full_turns"]=True
    nan=copy.deepcopy(reference);nan["images"][0]["log10_delta"]=float("nan")
    return {"equivalent":equivalent,"wrong":wrong,"no_winding":no_winding,"modulo_angle":modulo,"critical_as_capture":critical,"inner_turning_point":inner,"malformed":{},"duplicate_id":duplicate,"boolean_integer":boolean,"nonfinite":nan}
