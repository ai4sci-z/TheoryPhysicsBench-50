import json
import os
import sys
from pathlib import Path
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get("TASK_DATA_ROOT","/app/data"));private=Path(private_root or os.environ.get("TASK_PRIVATE_ROOT","/tests/private"))
    sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    mapped,reason=validate_answer(answer,load_model(data))
    if reason:return None,{"reason":reason}
    truth=json.loads((private/"truth.json").read_text(encoding="utf-8"));rays=[];images=[]
    for expected in truth["cases"]:
        actual=mapped["cases"][expected["id"]]
        if actual["outcome"]!=expected["outcome"]:error=1.0;parts={"classification_error":1.0}
        elif expected["outcome"]!="scatter":error=0.0;parts={"classification_error":0.0}
        else:
            radius=min(1.0,abs(actual["r_min"]-expected["r_min"])/expected["r_min"])
            angle=min(1.0,abs(actual["alpha"]-expected["alpha"])/max(expected["alpha"],0.05))
            turns=float(actual["full_turns"]!=expected["full_turns"])
            error=0.2*radius+0.6*angle+0.2*turns
            parts={"relative_radius_error":radius,"relative_angle_error":angle,"turn_count_error":turns}
        rays.append({"id":expected["id"],"error":error,**parts})
    for expected in truth["images"]:
        error=min(1.0,abs(mapped["images"][expected["id"]]["log10_delta"]-expected["log10_delta"])/3)
        images.append({"id":expected["id"],"error":error})
    raw=100*(0.75*sum(x["error"] for x in rays)/len(rays)+0.25*sum(x["error"] for x in images)/len(images))
    return raw,{"cases":rays,"images":images}


def main():
    logs=Path(os.environ.get("VERIFIER_LOG_ROOT","/logs/verifier"));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get("TASK_TESTS_ROOT","/tests"));output=Path(os.environ.get("TASK_ANSWER_PATH","/app/output/answer.json"))
    metric=json.loads((tests/"metric.json").read_text(encoding="utf-8"))
    try:answer=json.loads(output.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{"reason":"没有有效 JSON 产物"}
    else:raw,details=evaluate(answer)
    status="invalid" if raw is None else "completed";details.update(raw_metric=raw,score=quality_score(metric,raw,status),status=status)
    (logs/"metrics.json").write_text(json.dumps(details,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");(logs/"reward.txt").write_text(str(details["score"])+"\n",encoding="utf-8")


if __name__=="__main__":main()
