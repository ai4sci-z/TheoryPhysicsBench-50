"""Global variable projection followed by exact node-separated angular analysis."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq,minimize_scalar,least_squares


def pattern(u,mu):
    mu=np.asarray(mu,dtype=float)
    a=2*np.sin(u*(1+mu)/2)*np.sin(u*(1-mu)/2)
    result=np.divide(a*a,1-mu*mu,out=np.zeros_like(mu),where=abs(mu)<1)
    return float(result) if result.ndim==0 else result


def recover(case,bounds):
    mus=np.array(case["mu"]);observed=np.array(case["intensity"])
    norm=float(np.dot(observed,observed))
    def projected(u,ret_scale=False):
        values=pattern(u,mus)
        scale=float(np.dot(values,observed)/np.dot(values,values))
        return scale if ret_scale else float(np.dot(scale*values-observed,scale*values-observed)/norm)
    grid=np.linspace(*bounds,6001)
    values=np.array([projected(float(u)) for u in grid])
    candidates=[bounds[0],bounds[1]]
    for i in range(1,len(grid)-1):
        if values[i]<=values[i-1] and values[i]<=values[i+1]:
            candidates.append(minimize_scalar(projected,bounds=(grid[i-1],grid[i+1]),method="bounded",options={"xatol":1e-14}).x)
    u=min(candidates,key=projected)
    fit=least_squares(lambda x:(x[1]*pattern(x[0],mus)-observed)/np.sqrt(norm),[u,projected(u,True)],bounds=([bounds[0],1e-6],[bounds[1],1e6]),xtol=1e-14,ftol=1e-14,gtol=1e-14,max_nfev=100)
    return map(float,fit.x)


def nodes(u):
    points=[0.,1.]
    for k in range(-20,21):
        for sign in (-1,1):
            mu=sign+2*math.pi*k/u
            if 1e-12<mu<1-1e-12:points.append(mu)
    return sorted(set(points))


def angular_analysis(u):
    cuts=nodes(u)
    peaks=[0.]
    def log_derivative(mu):
        return u/2/math.tan(u*(1+mu)/2)-u/2/math.tan(u*(1-mu)/2)+mu/(1-mu*mu)
    for left,right in zip(cuts[1:-1],cuts[2:]):
        epsilon=(right-left)*1e-8
        peaks.append(brentq(log_derivative,left+epsilon,right-epsilon,xtol=1e-14))
    power=2*quad(lambda mu:pattern(u,mu),0,1,points=cuts[1:-1],epsabs=1e-12,epsrel=1e-12)[0]
    lobes=[{"mu":mu,"height":pattern(u,mu)} for mu in peaks]
    return power,2*max(l["height"] for l in lobes)/power,lobes


def solve_case(case,bounds):
    u,scale=recover(case,bounds)
    power,directivity,lobes=angular_analysis(u)
    return {"id":case["id"],"u":u,"scale":scale,"power_integral":power,"directivity":directivity,"lobes":lobes}
