"""A natural local fit initialized at the half-wave antenna, with dipole analysis."""
import argparse
import json
import math
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--data-root",type=Path,default=Path("/app/data"));parser.add_argument("--output",type=Path,default=Path("/app/output/answer.json"));args=parser.parse_args()
    model=json.loads((args.data_root/"model.json").read_text(encoding="utf-8"));cases=[]
    for case in model["cases"]:
        mu=np.array(case["mu"]);observed=np.array(case["intensity"])
        def values(u):return (np.cos(u*mu)-math.cos(u))**2/(1-mu*mu)
        # Familiar half-wave local start; the inverse objective has many minima.
        start=math.pi/2;scale=float(np.dot(values(start),observed)/np.dot(values(start),values(start)))
        fit=least_squares(lambda x:x[1]*values(x[0])-observed,[start,scale],bounds=([model["u_range"][0],1e-6],[model["u_range"][1],1e6]),max_nfev=300)
        u,scale=map(float,fit.x)
        # The coherent long-wavelength approximation of Jackson (9.56).
        central=(1-math.cos(u))**2
        cases.append({"id":case["id"],"u":u,"scale":scale,"power_integral":4*central/3,"directivity":1.5,"lobes":[{"mu":0.,"height":central}]})
    answer={"cases":cases,"method":"single half-wave local initialization; dipole angular continuation"}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print(json.dumps(answer,ensure_ascii=False))


if __name__=="__main__":main()
