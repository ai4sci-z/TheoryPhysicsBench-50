import argparse
import json
from pathlib import Path
from physics import fitting_residual,load_model,validate_answer


def main():
    parser=argparse.ArgumentParser();parser.add_argument("answer",type=Path);args=parser.parse_args()
    try:answer=json.loads(args.answer.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):print(json.dumps({"valid":False,"reason":"没有有效JSON"},ensure_ascii=False));return
    model=load_model(Path(__file__).parent);mapped,reason=validate_answer(answer,model)
    if reason:print(json.dumps({"valid":False,"reason":reason},ensure_ascii=False));return
    print(json.dumps({"valid":True,"cases":[{"id":case["id"],"relative_angular_sample_residual":fitting_residual(case,mapped[case["id"]]["u"],mapped[case["id"]]["scale"])} for case in model["cases"]]},ensure_ascii=False,indent=2))


if __name__=="__main__":main()
