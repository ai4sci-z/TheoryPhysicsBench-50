"""Public forward antenna model and schema; no private inverse labels."""
import json
import math
from pathlib import Path
import numpy as np


def load_model(root="/app/data"):
    return json.loads((Path(root)/"model.json").read_text(encoding="utf-8"))


def pattern(u, mu):
    mu=np.asarray(mu,dtype=float)
    # Product identity avoids subtracting two nearly equal cosines.
    amplitude=2*np.sin(u*(1+mu)/2)*np.sin(u*(1-mu)/2)
    result=np.divide(amplitude*amplitude,1-mu*mu,out=np.zeros_like(mu),where=abs(mu)<1)
    return float(result) if result.ndim==0 else result


def fitting_residual(case,u,scale):
    values=scale*pattern(u,np.array(case["mu"]))
    observed=np.array(case["intensity"])
    return float(np.linalg.norm(values-observed)/np.linalg.norm(observed))


def finite(value):
    try:return type(value) in (int,float) and math.isfinite(value)
    except OverflowError:return False


def validate_answer(answer,model):
    if not isinstance(answer,dict) or not isinstance(answer.get("cases"),list):return None,"须提交 cases 数组"
    ids={case["id"] for case in model["cases"]}
    if len(answer["cases"])!=len(ids):return None,"每个公开工况须恰好一项"
    mapped={}
    for case in answer["cases"]:
        if not isinstance(case,dict) or type(case.get("id")) is not str or case["id"] not in ids or case["id"] in mapped:return None,"未知或重复工况 id"
        for key in ("u","scale","power_integral","directivity"):
            if not finite(case.get(key)) or case[key]<=0:return None,f"{key} 必须为有限正数"
        if not model["u_range"][0]<=case["u"]<=model["u_range"][1]:return None,"u 超出公开搜索区间"
        lobes=case.get("lobes")
        if not isinstance(lobes,list) or not 1<=len(lobes)<=12:return None,"lobes 须为1至12项数组"
        for lobe in lobes:
            if not isinstance(lobe,dict) or not finite(lobe.get("mu")) or not 0<=lobe["mu"]<1:return None,"lobe.mu 须位于[0,1)"
            if not finite(lobe.get("height")) or lobe["height"]<=0:return None,"lobe.height 须为有限正数"
        mapped[case["id"]]=case
    return mapped,None
