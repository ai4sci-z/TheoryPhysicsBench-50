"""Public simple starting point for the finite-wire inverse problem."""
import json
import math
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares


def pattern(u, mu):
    mu=np.asarray(mu,dtype=float)
    numerator=(np.cos(u*mu)-math.cos(u))**2
    return np.divide(numerator,1-mu*mu,out=np.zeros_like(mu),where=abs(mu)<1)


def main():
    root=Path('/app/data');model=json.loads((root/'model.json').read_text(encoding='utf-8'));cases=[]
    for case in model['cases']:
        mu=np.array(case['mu']);observed=np.array(case['intensity'])
        def values(u):return pattern(u,mu)
        start=math.pi/2
        initial=float(np.dot(values(start),observed)/np.dot(values(start),values(start)))
        fit=least_squares(lambda x:x[1]*values(x[0])-observed,[start,initial],bounds=([model['u_range'][0],1e-6],[model['u_range'][1],1e6]),max_nfev=300)
        u,scale=map(float,fit.x);central=float(values(u)[len(values(u))//2])
        cases.append({'id':case['id'],'u':u,'scale':scale,'power_integral':4*central/3,'directivity':1.5,'lobes':[{'mu':0.0,'height':central}]})
    answer={'cases':cases,'method':'public half-wave local fit and dipole angular starting point'}
    out=Path('/app/output/answer.json');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(answer,ensure_ascii=False))


if __name__=='__main__':main()
