import copy


def make_cases(reference):
    names=("equivalent","wrong","missing_lobe","repeated_lobe","wrong_power","wrong_directivity","duplicate","boolean","nonfinite")
    cases={name:copy.deepcopy(reference) for name in names}
    cases["equivalent"]["cases"].reverse()
    for case in cases["equivalent"]["cases"]:case["lobes"].reverse()
    for case in cases["wrong"]["cases"]:
        case.update(u=.5,scale=100,power_integral=100,directivity=100,lobes=[{"mu":.99,"height":100}])
    cases["missing_lobe"]["cases"][-1]["lobes"].pop()
    cases["repeated_lobe"]["cases"][-1]["lobes"].append(copy.deepcopy(cases["repeated_lobe"]["cases"][-1]["lobes"][0]))
    for case in cases["wrong_power"]["cases"]:case["power_integral"]*=2
    for case in cases["wrong_directivity"]["cases"]:case["directivity"]=1.5
    cases["duplicate"]["cases"][1]=copy.deepcopy(cases["duplicate"]["cases"][0])
    cases["boolean"]["cases"][0]["u"]=True
    cases["nonfinite"]["cases"][0]["scale"]=float("nan")
    cases["malformed"]={}
    return cases
