import argparse
import json
import math
from pathlib import Path
from physics import load_model,validate_answer,force_residual,potential
def main():
    p=argparse.ArgumentParser();p.add_argument("answer",type=Path);args=p.parse_args();model=load_model(Path(__file__).parent)
    try:answer=json.loads(args.answer.read_text())
    except (OSError,ValueError):print(json.dumps({"valid":False,"reason":"没有有效 JSON"},ensure_ascii=False));return
    mapped,reason=validate_answer(answer,model);out={"valid":reason is None,"reason":reason}
    if reason is None:
        m=mapped["parameters"]["mass"];offset=mapped["parameters"]["offset"]
        out["observation_residuals"]=[(point["measured_radius"]+offset)/m**(1/3)-point["omega_phi"]**(-2/3) for point in model["observations"]]
        out["stationarity"]=[]
        for case in model["branches"]:
            ell=m*math.sqrt(12*(1+case["delta"]))
            for state in mapped["branches"][case["id"]]["states"]:
                r=state["radius"];out["stationarity"].append({"id":case["id"],"force_residual":force_residual(r,m,ell),"energy_residual":state["specific_energy"]**2-potential(r,m,ell)})
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
