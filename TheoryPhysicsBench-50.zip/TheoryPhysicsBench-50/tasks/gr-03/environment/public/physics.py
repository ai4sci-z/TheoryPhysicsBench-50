import json
import math
from pathlib import Path
FIELDS=("radius","specific_energy","omega_phi","radial_t_squared","radial_tau_squared")
ISCO=("radius","specific_energy","angular_momentum","omega_phi")
def finite(value):
    try:return type(value) in (int,float) and math.isfinite(value)
    except OverflowError:return False
def load_model(root="/app/data"):return json.loads((Path(root)/"model.json").read_text())
def potential(radius,mass,angular_momentum):return (1-2*mass/radius)*(1+angular_momentum**2/radius**2)
def force_residual(radius,mass,angular_momentum):return 2*mass/radius**2-2*angular_momentum**2/radius**3+6*mass*angular_momentum**2/radius**4
def validate_answer(answer,model):
    if not isinstance(answer,dict):return None,"须为 JSON 对象"
    p=answer.get("parameters");isco=answer.get("isco");branches=answer.get("branches")
    if not isinstance(p,dict) or not all(finite(p.get(k)) for k in ("mass","offset")) or p["mass"]<=0:return None,"mass 须正且参数均有限"
    if not isinstance(isco,dict) or not all(finite(isco.get(k)) and isco[k]>0 for k in ISCO):return None,"ISCO 四个量须为正有限数"
    ids={c["id"] for c in model["branches"]}
    if not isinstance(branches,list) or len(branches)!=len(ids):return None,"须含全部角动量工况"
    result={}
    for branch in branches:
        if not isinstance(branch,dict) or type(branch.get("id")) is not str or branch["id"] not in ids or branch["id"] in result:return None,"id 未知或重复"
        states=branch.get("states")
        if not isinstance(states,list) or len(states)>4:return None,"states 须为至多四项数组，无圆轨道填 []"
        for state in states:
            if not isinstance(state,dict) or not all(finite(state.get(k)) for k in FIELDS):return None,"圆轨道字段须均为有限实数"
            if any(state[k]<=0 for k in ("radius","specific_energy","omega_phi")):return None,"半径、能量、方位频率须为正"
            if state.get("stability") not in ("stable","unstable","marginal"):return None,"未知稳定性"
        result[branch["id"]]=branch
    return {"parameters":p,"isco":isco,"branches":result},None
