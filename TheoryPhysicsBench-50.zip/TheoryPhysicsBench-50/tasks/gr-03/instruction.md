# Schwarzschild 类时圆轨道的分支、稳定性与 ISCO

## 研究目标与模型

由圆轨道频率模拟观测同时辨识黑洞质量和半径仪器零点，再追踪给定比角动量下的全部圆轨道、径向稳定性和最内稳定圆轨道（ISCO）。同一角动量可以对应两个不同半径；稳定分支与不稳定分支在临界点合并。不能只给稳定分支，也不能把不稳定模的负频率平方变成正数。

取固定几何单位 \(G=c=1\)。质量和半径共用同一个长度单位，时间也用该长度单位，频率为其倒数；不预设 \(M=1\)。考虑赤道面 Schwarzschild 度规

\[
ds^2=-(1-2M/r)dt^2+(1-2M/r)^{-1}dr^2+r^2d\varphi^2.
\]

单位静质量的类时粒子沿测地线运动。\(\tau\) 是粒子固有时间，\(t\) 是无穷远归一化的 Schwarzschild 时间。能量 \(E=(1-2M/r)dt/d\tau\) 与比角动量 \(L=r^2d\varphi/d\tau\) 守恒，径向方程为

\[
\left(\frac{dr}{d\tau}\right)^2+V_L(r)=E^2,
\qquad V_L(r)=(1-2M/r)(1+L^2/r^2).
\]

圆轨道必须是 \(r>3M\) 的类时圆测地线，满足 \(V_L'(r)=0\)、\(E^2=V_L(r)\)。对固定 \(L\) 的无穷小径向扰动，定义带符号频率平方

\[
\frac{d^2\delta r}{d\tau^2}+\kappa_\tau^2\delta r=0,
\quad \kappa_\tau^2=\frac12V_L''(r_c),
\qquad
\frac{d^2\delta r}{dt^2}+\kappa_t^2\delta r=0.
\]

正数为 `stable`，负数为 `unstable`，合并点为 `marginal`；后者是二阶线性意义的临界稳定，不宣称非线性稳定。`omega_phi` 始终指 \(d\varphi/dt>0\)，不是固有时间角速度。所有频率平方都必须保留符号。

## 公开模拟观测与拟合约定

`/app/data/model.json` 的 `observations` 是无随机噪声、14 位有效数字舍入的确定性模拟圆轨道观测，不是真实望远镜数据。每项包含仪器读数 `measured_radius` 和坐标方位角频率 `omega_phi`。真实面积半径与仪器读数相差未知常数 \(b\)：

\[
r=R_{\rm measured}+b.
\]

各观测均来自稳定圆轨道。由测地线方程可得 \(\Omega_\varphi^2=M/r^3\)。本题**规定**用变换后的无权最小二乘拟合：令 \(y_i=\Omega_{\varphi,i}^{-2/3}\)，最小化

\[
\sum_i[y_i-A R_i-B]^2,\qquad A=M^{-1/3},\ B=bM^{-1/3}.
\]

然后报告 \(M=A^{-3}\)、\(b=B/A\)。不要改成直接拟合原频率、相对误差或直接回填数据生成常数。`mass_bounds` 和 `offset_bounds` 给出公开物理搜索范围，最优解位于内部。

## 圆轨道分支与 ISCO

`branches` 的每个工况用权威输入 `delta` 定义

\[
(L/M)^2=12(1+\delta).
\]

使用拟合出的同一个 \(M\)。所有工况属于同一道分支追踪任务，不能各自重新拟合质量。临界点附近的 `delta` 直接定义工况，不要先舍入 \(L\) 再通过接近数相减重建它。

每工况报告**全部不同**类时圆轨道的半径、比能量、坐标方位频率、两种时间下的带符号径向频率平方，以及稳定性。没有圆轨道时填空列表；合并点只列一次。另报告 ISCO 的半径、比能量、比角动量和坐标方位频率。可通过有效势的驻点和二阶导数推导，不必使用特定数值算法。

## 材料与公开反馈

- `/app/data/model.json`：模拟观测、角动量分支工况、边界和单位。
- `/app/data/physics.py`：读入、有效势、驻点残差和 schema；不含完整正确分支。
- `/app/data/feedback.py`：返回变换观测残差、已提交轨道的驻点残差和能量残差。它不能以驻点残差代替轨道完整性或稳定性判断。
- `/app/data/metric.json`：固定指标及实测端点。
- Python 3.12、NumPy 2.1.3、SciPy 1.14.1、mpmath 1.3.0。

```python
import sys
sys.path.insert(0, "/app/data")
from physics import load_model, potential
print(load_model()["observations"][0])
```

尝试完成后运行，次数不限：

```bash
python /app/data/feedback.py /app/output/trial.json
```

## 最终产物

提交 `/app/output/answer.json`，格式如下（数字仅为字段示意）：

```json
{
  "parameters":{"mass":1.0,"offset":0.0},
  "branches":[{"id":"branch-01","states":[
    {"radius":7.0,"specific_energy":0.95,"omega_phi":0.05,
     "radial_t_squared":0.001,"radial_tau_squared":0.002,"stability":"stable"}
  ]}],
  "isco":{"radius":6.0,"specific_energy":0.94,"angular_momentum":3.46,"omega_phi":0.068}
}
```

真实提交须每个公开分支 id 恰好一项。工况和态的顺序不限，每工况 0 至 4 个态；漏态和重复态按分数处罚。所有数值有限，质量、半径、能量、方位频率以及 ISCO 四量为正；径向频率平方可以为负或零。稳定性为 `stable`、`unstable`、`marginal`。可附加文字说明，不参与评分。

## 固定评分

原始误差单位为百分点，越低越好。验证器以独立高精度有效势计算核对；所有无量纲分项截到 1。

- 参数误差 \(e_p\)：质量绝对误差除以真值质量的 10%，零点误差除以 0.5，两项平均。
- 单态匹配代价：五个数值字段按顺序采用尺度 \(0.05\hat r,0.02,0.05\hat\Omega,\max(0.1|\hat\kappa_t^2|,10^{-7}),\max(0.1|\hat\kappa_\tau^2|,10^{-7})\)，绝对误差除以尺度并截到 1。数值平均占 0.8，稳定性错误占 0.2。每个工况做一对一最小代价匹配；未匹配态代价 1；除以提交态数和真值态数的较大值。双方均无态则工况误差 0。
- 分支误差 \(e_b\)：全部工况误差平均。
- ISCO 误差 \(e_I\)：四个数值均按 5% 相对误差尺度，截到 1 后平均。

总误差为 \(100(0.2e_p+0.6e_b+0.2e_I)\)。近临界绝对频率尺度只防止双精度舍入被无限放大，不取消负号及分类检查。格式不合法、非有限值、重复 id 或布尔值冒充数值为无效；格式合法的物理错误按实际误差计分。

简单基线忽略仪器零点，用过原点的同一变换拟合质量，采用 Newton 有效势的唯一稳定圆轨道及相等的两种时间。Newton 理论没有 ISCO，基线明确以最内侧观测半径作经验代理，不把该代理声称为相对论结果。参考使用完整相对论有效势并辨识零点，两者使用相同公开数据和评分。

## 时间与资源

Agent 720 秒，verifier 120 秒；4 CPU、4 GB 内存、4 GB 磁盘、0 GPU。不需要服务器或大模型权重。
