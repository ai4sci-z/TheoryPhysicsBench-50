import math
import numpy as np


def infer(model,zero_offset=False):
    x=np.array([point["measured_radius"] for point in model["observations"]])
    y=np.array([point["omega_phi"]**(-2/3) for point in model["observations"]])
    if zero_offset:slope=float(x@y/(x@x));offset=0.0
    else:
        slope,intercept=np.linalg.lstsq(np.column_stack((x,np.ones(len(x)))),y,rcond=None)[0]
        offset=float(intercept/slope)
    return float(slope**-3),offset


def state(x,mass,stability):
    radius=mass*x
    omega=math.sqrt(mass/radius**3)
    energy=(1-2/x)/math.sqrt(1-3/x)
    return {"radius":radius,"specific_energy":energy,"omega_phi":omega,"radial_t_squared":omega**2*(1-6/x),"radial_tau_squared":omega**2*(1-6/x)/(1-3/x),"stability":stability}


def solve(model,baseline=False):
    mass,offset=infer(model,zero_offset=baseline);branches=[]
    for case in model["branches"]:
        d=case["delta"]
        if baseline:
            x=12*(1+d);r=mass*x;o=math.sqrt(mass/r**3)
            states=[{"radius":r,"specific_energy":1-1/(2*x),"omega_phi":o,"radial_t_squared":o*o,"radial_tau_squared":o*o,"stability":"stable"}]
        elif d<0:states=[]
        elif d==0:states=[state(6,mass,"marginal")]
        else:
            factor=math.sqrt(d/(1+d))
            inner=6/(1+factor);outer=6*(1+d)*(1+factor)
            states=[state(inner,mass,"unstable"),state(outer,mass,"stable")]
        branches.append({"id":case["id"],"states":states})
    return {"parameters":{"mass":mass,"offset":offset},"branches":branches,"isco":{"radius":6*mass,"specific_energy":math.sqrt(8/9),"angular_momentum":math.sqrt(12)*mass,"omega_phi":1/(6**1.5*mass)}}
