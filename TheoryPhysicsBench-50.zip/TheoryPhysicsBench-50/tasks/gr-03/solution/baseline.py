import argparse
import json
from pathlib import Path
from solver_core import solve

def main():
    p=argparse.ArgumentParser();p.add_argument("--data-root",type=Path,default=Path("/app/data"));p.add_argument("--output",type=Path,default=Path("/app/output/answer.json"));args=p.parse_args()
    model=json.loads((args.data_root/"model.json").read_text());answer=solve(model,baseline=True)
    # Newtonian gravity has no ISCO; use the innermost observed circular orbit
    # as a clearly labelled observational lower bound, not a fabricated GR value.
    r=min(point["measured_radius"] for point in model["observations"]);m=answer["parameters"]["mass"]
    answer["isco"]={"radius":r,"specific_energy":1-m/(2*r),"angular_momentum":(m*r)**0.5,"omega_phi":(m/r**3)**0.5}
    answer["method"]="zero instrumental offset; Newton circular effective potential; innermost observed radius as ISCO proxy"
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,indent=2)+"\n");print(json.dumps(answer))
if __name__=="__main__":main()
