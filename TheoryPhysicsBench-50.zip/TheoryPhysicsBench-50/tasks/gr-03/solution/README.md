# gr-03 参考推导与复现

教材依据为梁灿彬、周彬上册 PDF 327 页（书内 312 页）式 (9-1-5)–(9-1-6)，以及 PDF 332 页（书内 317 页）式 (9-2-13)–(9-2-15)。两页已目视核对，见 `checks/gr-03-source-pages/`。教材给出的类时径向方程是本题起点；本题的零点反演、跨临界分支及双时钟稳定性数据为新增设计，不声称教材已给出这些数值结果。

圆轨道满足 \(V_L'=2M/r^2-2L^2/r^3+6ML^2/r^4=0\)，所以

\[
Mr^2-L^2r+3ML^2=0.
\]

令 \(q=(L/M)^2=12(1+\delta)\)、\(x=r/M\)，得 \(x^2-qx+3q=0\)。当 \(\delta<0\) 无实圆轨道；\(\delta=0\) 两根合并到 \(x=6\)；\(\delta>0\) 有 \(3<x_-<6<x_+\)。由于输入保证 \(q>0\)，不存在从负角动量平方来的伪根。

直接对小根作两个接近数相减会损失精度。定义 \(s=\sqrt{\delta/(1+\delta)}\)，使用

\[
x_- =\frac6{1+s},\qquad x_+=6(1+\delta)(1+s).
\]

临界点单列一次，非零 \(\delta\) 不用粗糙容差并入临界点。

将驻点条件代回类时归一化，得到

\[
E=\frac{1-2/x}{\sqrt{1-3/x}},\quad
u^t=\frac1{\sqrt{1-3/x}},\quad
\Omega_\varphi=\sqrt{M/r^3}.
\]

固定 \(L\) 的径向方程线性化给出 \(\kappa_\tau^2=V_L''/2\)。在圆轨道处

\[
\kappa_\tau^2=\Omega_\varphi^2\frac{1-6/x}{1-3/x},\qquad
\kappa_t^2=\frac{\kappa_\tau^2}{(u^t)^2}
=\Omega_\varphi^2(1-6/x).
\]

时间变换的额外项在基准圆轨道上乘以径向速度，属于扰动二阶，因此在线性阶只需除以固定 \((u^t)^2\)。内支的频率平方为负，代表指数增长率的负平方而不是实振荡频率。ISCO 处两者为零，二阶线性判据退化；本题标为 marginal，不称非线性稳定。

因此 \(r_I=6M\)、\(E_I=\sqrt{8/9}\)、\(L_I=\sqrt{12}M\)、\(\Omega_I=1/(6^{3/2}M)\)。稳定性按势的二阶导数判断，不是按 \(E<1\) 判断；部分不稳定类时圆轨道也可满足 \(E<1\)。

由 \(\Omega^2=M/(R+b)^3\)，取 \(-2/3\) 次幂得 \(y=M^{-1/3}R+bM^{-1/3}\)。参考对公开已舍入数据做带截距的线性最小二乘，恢复质量与仪器零点；不直接回填生成常数。基线固定截距为零，使用 Newton 模型 \(r=L^2/M\)、\(E\simeq1-M/(2r)\)、\(\kappa_t^2=\kappa_\tau^2=M/r^3\)。它以最内观测半径作清楚标记的 ISCO 代理，所有字段仍走同一评分。

独立真值 `tools/build_gr03_truth.py` 使用 75 位正规方程重拟合，直接求二次多项式根，用 mpmath 对原始有效势求二阶导数计算频率，再用四速度归一化和守恒量得到坐标时间变换与方位频率。它不导入参考核心，避免用同一闭式频率表达式作唯一核验。驻点残差和归一化残差均保存。

开发核验命令：

```bash
python tools/build_gr03_truth.py
python tools/run_gr03_checks.py
```

`--generate-observations`、`--calibrate` 只用于首次构建/校准，冻结后不执行。完整数值、来源和命令记录在 `checks/gr-03-validation.md`、`checks/gr-03-sources-and-fairness.md`、`checks/gr-03-command-log.md`。Harbor 入口为 `bash /solution/solve.sh`。
