import argparse
import json
from pathlib import Path
from solver_core import solve

def main():
    p=argparse.ArgumentParser();p.add_argument("--data-root",type=Path,default=Path("/app/data"));p.add_argument("--output",type=Path,default=Path("/app/output/answer.json"));args=p.parse_args()
    answer=solve(json.loads((args.data_root/"model.json").read_text()));args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,indent=2)+"\n");print(json.dumps(answer))
if __name__=="__main__":main()
