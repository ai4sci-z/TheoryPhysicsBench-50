import copy
def make_cases(reference):
    eq=copy.deepcopy(reference);eq["branches"].reverse()
    for case in eq["branches"]:case["states"].reverse()
    wrong=copy.deepcopy(reference)
    for case in wrong["branches"]:case["states"]=[]
    wrong["parameters"]={"mass":0.1,"offset":-1}
    for key in wrong["isco"]:wrong["isco"][key]=1e-5
    missing=copy.deepcopy(reference);missing["branches"][5]["states"].pop()
    repeated=copy.deepcopy(reference);repeated["branches"][5]["states"].append(copy.deepcopy(repeated["branches"][5]["states"][0]))
    sign=copy.deepcopy(reference)
    for case in sign["branches"]:
        for state in case["states"]:
            state["radial_t_squared"]=abs(state["radial_t_squared"]);state["radial_tau_squared"]=abs(state["radial_tau_squared"])
    clock=copy.deepcopy(reference)
    for case in clock["branches"]:
        for state in case["states"]:state["radial_tau_squared"]=state["radial_t_squared"]
    duplicate=copy.deepcopy(reference);duplicate["branches"][0]["id"]=duplicate["branches"][1]["id"]
    boolean=copy.deepcopy(reference);boolean["parameters"]["mass"]=True
    return {"equivalent":eq,"wrong":wrong,"missing_branch":missing,"repeated_branch":repeated,"lost_frequency_sign":sign,"wrong_clock":clock,"malformed":{},"duplicate_id":duplicate,"boolean_number":boolean}
