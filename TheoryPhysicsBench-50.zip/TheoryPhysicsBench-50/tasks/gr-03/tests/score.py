import json
import os
import sys
from pathlib import Path
import numpy as np
from scipy.optimize import linear_sum_assignment
from quality_score import quality_score
def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get("TASK_DATA_ROOT","/app/data"));private=Path(private_root or os.environ.get("TASK_PRIVATE_ROOT","/tests/private"));sys.path.insert(0,str(data))
    from physics import FIELDS,load_model,validate_answer
    mapped,reason=validate_answer(answer,load_model(data))
    if reason:return None,{"reason":reason}
    truth=json.loads((private/"truth.json").read_text());p=mapped["parameters"];q=truth["parameters"]
    pe=(min(1,abs(p["mass"]-q["mass"])/(0.1*q["mass"]))+min(1,abs(p["offset"]-q["offset"])/0.5))/2
    details=[]
    for case in truth["branches"]:
        predicted=mapped["branches"][case["id"]]["states"];target=case["states"];n=max(len(predicted),len(target))
        if n==0:err=0.0
        else:
            costs=np.ones((n,n))
            for i,a in enumerate(predicted):
                for j,b in enumerate(target):
                    scales={"radius":0.05*b["radius"],"specific_energy":0.02,"omega_phi":0.05*b["omega_phi"],"radial_t_squared":max(abs(b["radial_t_squared"])*0.1,1e-7),"radial_tau_squared":max(abs(b["radial_tau_squared"])*0.1,1e-7)}
                    errors=[min(1,abs(a[key]-b[key])/scales[key]) for key in FIELDS]
                    costs[i,j]=0.8*sum(errors)/len(errors)+0.2*float(a["stability"]!=b["stability"])
            rows,cols=linear_sum_assignment(costs);err=float(costs[rows,cols].sum()/n)
        details.append({"id":case["id"],"error":err,"submitted_count":len(predicted),"expected_count":len(target)})
    isco=sum(min(1,abs(mapped["isco"][key]-value)/(0.05*value)) for key,value in truth["isco"].items())/len(truth["isco"])
    raw=100*(0.2*pe+0.6*sum(x["error"] for x in details)/len(details)+0.2*isco)
    return raw,{"parameter_error":pe,"branches":details,"isco_error":isco}
def main():
    logs=Path(os.environ.get("VERIFIER_LOG_ROOT","/logs/verifier"));logs.mkdir(parents=True,exist_ok=True);tests=Path(os.environ.get("TASK_TESTS_ROOT","/tests"));output=Path(os.environ.get("TASK_ANSWER_PATH","/app/output/answer.json"));metric=json.loads((tests/"metric.json").read_text())
    try:answer=json.loads(output.read_text())
    except (OSError,ValueError):raw,details=None,{"reason":"没有有效 JSON 产物"}
    else:raw,details=evaluate(answer)
    status="invalid" if raw is None else "completed";details.update(raw_metric=raw,status=status,score=quality_score(metric,raw,status));(logs/"metrics.json").write_text(json.dumps(details,ensure_ascii=False,indent=2)+"\n");(logs/"reward.txt").write_text(str(details["score"])+"\n")
if __name__=="__main__":main()
