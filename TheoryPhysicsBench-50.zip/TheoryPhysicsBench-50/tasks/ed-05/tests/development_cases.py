"""Valid physical/numerical mutations and malformed outputs for verifier checks."""
from copy import deepcopy


def make_cases(reference):
    result = {}
    equivalent = deepcopy(reference)
    equivalent["cases"] = list(reversed(equivalent["cases"]))
    result["equivalent"] = equivalent
    zero = deepcopy(reference)
    for case in zero["cases"]:
        for entry in case["coefficients"]:
            entry["a"] = [0.0, 0.0]
            entry["b"] = [0.0, 0.0]
        for key in ("qsca", "qext", "qback", "g"):
            case[key] = 0.0
        for point in case["phase"]:
            point["value"] = 0.0
    result["zero"] = zero
    conjugate = deepcopy(reference)
    for case in conjugate["cases"]:
        for entry in case["coefficients"]:
            entry["a"][1] *= -1
            entry["b"][1] *= -1
    result["wrong_hankel_sign"] = conjugate
    missing_magnetic = deepcopy(reference)
    for case in missing_magnetic["cases"]:
        for entry in case["coefficients"]:
            entry["b"] = [0.0, 0.0]
    result["missing_magnetic"] = missing_magnetic
    wrong_back = deepcopy(reference)
    for case in wrong_back["cases"]:
        case["qback"] /= 4
    result["backscatter_factor_four"] = wrong_back
    wrong_phase = deepcopy(reference)
    for case in wrong_phase["cases"]:
        for point in case["phase"]:
            point["value"] *= 2
    result["phase_factor_two"] = wrong_phase
    omitted_interference = deepcopy(reference)
    for case in omitted_interference["cases"]:
        case["g"] = 0.0
    result["zero_asymmetry"] = omitted_interference
    duplicate = deepcopy(reference)
    duplicate["cases"][1]["id"] = duplicate["cases"][0]["id"]
    result["duplicate"] = duplicate
    nonfinite = deepcopy(reference)
    nonfinite["cases"][0]["coefficients"][0]["a"][0] = float("nan")
    result["nonfinite"] = nonfinite
    boolean = deepcopy(reference)
    boolean["cases"][0]["coefficients"][0]["a"][0] = True
    result["boolean"] = boolean
    bool_order = deepcopy(reference)
    bool_order["cases"][0]["coefficients"][0]["l"] = True
    result["boolean_order"] = bool_order
    bool_angle = deepcopy(reference)
    bool_angle["cases"][0]["phase"][0]["theta_deg"] = False
    result["boolean_angle"] = bool_angle
    missing = deepcopy(reference)
    missing["cases"][0]["coefficients"].pop()
    result["missing_order"] = missing
    wrong_angle = deepcopy(reference)
    wrong_angle["cases"][0]["phase"][0]["theta_deg"] = 1
    result["wrong_angle"] = wrong_angle
    malformed = deepcopy(reference)
    malformed["cases"][0]["coefficients"][0]["a"] = "not-a-complex-pair"
    result["malformed"] = malformed
    huge = deepcopy(reference)
    huge["cases"][0]["qsca"] = 10**1000
    result["overflow_integer"] = huge
    negative = deepcopy(reference)
    negative["cases"][0]["qsca"] = -1
    result["negative_efficiency"] = negative
    missing_method = deepcopy(reference)
    missing_method.pop("method")
    result["missing_method"] = missing_method
    return result
