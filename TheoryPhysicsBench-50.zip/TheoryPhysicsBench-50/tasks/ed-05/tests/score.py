import json
import math
import os
from pathlib import Path
import sys

from quality_score import quality_score


def evaluate(answer, data_root=None, private_root=None):
    data = Path(data_root or os.environ.get("TASK_DATA_ROOT", "/app/data"))
    private = Path(private_root or os.environ.get("TASK_PRIVATE_ROOT", "/tests/private"))
    sys.path.insert(0, str(data))
    from physics import load_model, validate_answer
    model = load_model(data)
    mapped, reason = validate_answer(answer, model)
    if reason:
        return None, {"reason": reason}
    truth = json.loads((private / "truth.json").read_text(encoding="utf-8"))
    cfg = model["scoring"]
    details = []
    for expected in truth["cases"]:
        actual = mapped[expected["id"]]
        coeff_numerator, coeff_denominator = 0.0, 0.0
        for got, want in zip(actual["coefficients"], expected["coefficients"]):
            for key in ("a", "b"):
                z, target = complex(*got[key]), complex(*want[key])
                # Partial-wave energy weights preserve physical scale: negligible
                # tails do not receive the same penalty as a leading dipole.
                coeff_numerator += (2 * want["l"] + 1) * min(abs(z - target), 1e100)**2
                coeff_denominator += (2 * want["l"] + 1) * abs(target)**2
        coefficient_error = min(1.0, math.sqrt(coeff_numerator / coeff_denominator))
        integrated_errors = {
            key: min(1.0, abs(actual[key] - expected[key]) / max(abs(expected[key]), 1e-14))
            for key in ("qsca", "qext", "qback")
        }
        integrated_errors["g"] = min(1.0, abs(actual["g"] - expected["g"]) / 2)
        expected_phase = expected["phase"]
        phase_scale = max(point["value"] for point in expected_phase)
        phase_floor = max(phase_scale * 1e-10, 1e-14)
        phase_errors = [min(1.0, abs(got["value"] - want["value"]) / max(want["value"], phase_floor))
                        for got, want in zip(actual["phase"], expected_phase)]
        low_frequency_error = 0.0
        if expected["x"] <= 0.15:
            rayleigh = 10 * expected["x"]**4 / 3
            low_frequency_error = 0.5 * min(1.0, abs(actual["qsca"] - expected["qsca"]) / rayleigh)
            low_frequency_error += 0.5 * min(1.0, abs(actual["g"] - expected["g"]) / 2)
        raw = 100 * (
            cfg["coefficient_weight"] * coefficient_error
            + cfg["integrated_weight"] * sum(integrated_errors.values()) / len(integrated_errors)
            + cfg["angular_weight"] * sum(phase_errors) / len(phase_errors)
            + cfg["low_frequency_weight"] * low_frequency_error
        )
        details.append({"id": expected["id"], "raw_metric": raw,
                        "coefficient_error": coefficient_error,
                        "integrated_errors": integrated_errors,
                        "maximum_phase_error": max(phase_errors),
                        "low_frequency_error": low_frequency_error})
    return sum(case["raw_metric"] for case in details) / len(details), {"cases": details}


def main():
    logs = Path(os.environ.get("VERIFIER_LOG_ROOT", "/logs/verifier"))
    logs.mkdir(parents=True, exist_ok=True)
    tests = Path(os.environ.get("TASK_TESTS_ROOT", "/tests"))
    output = Path(os.environ.get("TASK_ANSWER_PATH", "/app/output/answer.json"))
    metric = json.loads((tests / "metric.json").read_text(encoding="utf-8"))
    try:
        answer = json.loads(output.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        raw, details = None, {"reason": "没有有效JSON产物"}
    else:
        raw, details = evaluate(answer)
    status = "invalid" if raw is None else "completed"
    details.update(raw_metric=raw, score=quality_score(metric, raw, status), status=status)
    (logs / "metrics.json").write_text(json.dumps(details, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (logs / "reward.txt").write_text(f"{details['score']}\n", encoding="utf-8")


if __name__ == "__main__":
    main()
