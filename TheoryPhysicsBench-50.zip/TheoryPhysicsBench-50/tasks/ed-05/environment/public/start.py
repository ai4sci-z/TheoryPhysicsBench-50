"""Physically consistent electric/magnetic dipole truncation baseline."""
import argparse
import json
from pathlib import Path

from physics import dipole_coefficients, load_model, observables


def make_answer(model, data_root):
    cases = []
    for spec in model["cases"]:
        a1, b1 = dipole_coefficients(spec["x"])
        obs = observables(spec["x"], a1, b1, model["angles_deg"])
        coefficients = [{"l": ell, "a": [0.0, 0.0], "b": [0.0, 0.0]} for ell in range(1, spec["lmax"] + 1)]
        coefficients[0] = {"l": 1, "a": [float(a1[0].real), float(a1[0].imag)], "b": [float(b1[0].real), float(b1[0].imag)]}
        obs["phase"] = [{"theta_deg": theta, "value": value} for theta, value in zip(model["angles_deg"], obs["phase"])]
        cases.append({"id": spec["id"], "coefficients": coefficients, **obs})
    return {"cases": cases, "method": "exact PEC electric and magnetic dipole (l=1) truncation"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, default=Path("/app/data"))
    parser.add_argument("--output", type=Path, default=Path("/app/output/answer.json"))
    args = parser.parse_args()
    model = load_model(args.data_root)
    answer = make_answer(model, args.data_root)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(answer, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"cases": len(answer["cases"]), "method": answer["method"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
