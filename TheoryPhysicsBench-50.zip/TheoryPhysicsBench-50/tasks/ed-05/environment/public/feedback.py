import argparse
import json
import math
from pathlib import Path

from physics import angular_amplitudes, load_model, observables, validate_answer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("answer", type=Path)
    args = parser.parse_args()
    try:
        answer = json.loads(args.answer.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        print(json.dumps({"valid": False, "reason": "没有有效JSON"}, ensure_ascii=False))
        return
    model = load_model(Path(__file__).parent)
    mapped, reason = validate_answer(answer, model)
    if reason:
        print(json.dumps({"valid": False, "reason": reason}, ensure_ascii=False))
        return
    results = []
    for spec in model["cases"]:
        case = mapped[spec["id"]]
        coeffs = case["coefficients"]
        a = [complex(*entry["a"]) for entry in coeffs]
        b = [complex(*entry["b"]) for entry in coeffs]
        expected = observables(spec["x"], a, b, model["angles_deg"])
        unitary = max([abs(abs(1 - 2 * z) - 1) for z in a + b], default=0.0)
        supplied = {key: case[key] for key in ("qsca", "qext", "qback", "g")}
        residuals = {key: (supplied[key] - expected[key]) / max(abs(expected[key]), 1e-14) for key in supplied}
        phase_error = max(abs(p["value"] - q) / max(abs(q), 1e-14) for p, q in zip(case["phase"], expected["phase"]))
        results.append({"id": spec["id"], "partial_wave_unitarity_residual": unitary,
                        "observable_residuals_from_submitted_coefficients": residuals,
                        "maximum_phase_residual_from_coefficients": phase_error})
    print(json.dumps({"valid": True, "cases": results,
                      "note": "这些恒等式检查内部一致性，不替代私有多极系数和角分布核验"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
