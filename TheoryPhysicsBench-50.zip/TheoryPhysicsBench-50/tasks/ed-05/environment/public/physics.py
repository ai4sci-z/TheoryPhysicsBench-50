"""Public conventions, forward observables and strict artifact validation."""
import json
import math
from pathlib import Path

import numpy as np
from scipy.special import spherical_jn, spherical_yn


def load_model(root="/app/data"):
    return json.loads((Path(root) / "model.json").read_text(encoding="utf-8"))


def dipole_coefficients(x):
    """Only the l=1 electric/magnetic coefficients for the public baseline."""
    j = spherical_jn(1, x)
    y = spherical_yn(1, x)
    jp = spherical_jn(1, x, derivative=True)
    yp = spherical_yn(1, x, derivative=True)
    psi = x * j
    chi = x * y
    psip = j + x * jp
    chip = y + x * yp
    a = psip / (psip + 1j * chip)
    b = psi / (psi + 1j * chi)
    return np.asarray([a], dtype=complex), np.asarray([b], dtype=complex)


def angular_amplitudes(mu, a, b):
    pi_prev = 0.0
    pi_now = 1.0
    s1 = 0j
    s2 = 0j
    for index, (an, bn) in enumerate(zip(a, b), start=1):
        tau = index * mu * pi_now - (index + 1) * pi_prev
        factor = (2 * index + 1) / (index * (index + 1))
        s1 += factor * (an * pi_now + bn * tau)
        s2 += factor * (an * tau + bn * pi_now)
        pi_prev, pi_now = pi_now, ((2 * index + 1) / index) * mu * pi_now - ((index + 1) / index) * pi_prev
    return s1, s2


def observables(x, a, b, angles_deg):
    a, b = np.asarray(a, dtype=complex), np.asarray(b, dtype=complex)
    orders = np.arange(1, len(a) + 1, dtype=float)
    weights = 2 * orders + 1
    qsca = float(2 / x**2 * np.sum(weights * (abs(a) ** 2 + abs(b) ** 2)))
    qext = float(2 / x**2 * np.real(np.sum(weights * (a + b))))
    back_amplitude = np.sum(weights * (-1.0) ** orders * (a - b))
    qback = float(abs(back_amplitude) ** 2 / x**2)
    adjacent = np.arange(1, len(a), dtype=float)
    adjacent_sum = np.sum(adjacent * (adjacent + 2) / (adjacent + 1) * np.real(
        a[:-1] * np.conjugate(a[1:]) + b[:-1] * np.conjugate(b[1:])
    ))
    same_order = np.sum(weights / (orders * (orders + 1)) * np.real(a * np.conjugate(b)))
    g = float(4 / (x**2 * qsca) * (adjacent_sum + same_order)) if qsca > 0 else 0.0
    phase = []
    for theta in angles_deg:
        s1, s2 = angular_amplitudes(math.cos(math.radians(theta)), a, b)
        phase.append(float((abs(s1) ** 2 + abs(s2) ** 2) / 2))
    return {"qsca": qsca, "qext": qext, "qback": qback, "g": g, "phase": phase}


def finite(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def validate_answer(answer, model):
    if not isinstance(answer, dict) or not isinstance(answer.get("cases"), list):
        return None, "须提交 cases 数组"
    ids = {case["id"]: case for case in model["cases"]}
    if len(answer["cases"]) != len(ids):
        return None, "每个公开工况须恰好一项"
    mapped = {}
    for case in answer["cases"]:
        if not isinstance(case, dict) or type(case.get("id")) is not str or case["id"] not in ids or case["id"] in mapped:
            return None, "未知或重复工况 id"
        spec = ids[case["id"]]
        coeffs = case.get("coefficients")
        if not isinstance(coeffs, list) or len(coeffs) != spec["lmax"]:
            return None, "multipole coefficients 数量与公开 lmax 不符"
        for index, entry in enumerate(coeffs, start=1):
            if not isinstance(entry, dict) or type(entry.get("l")) is not int or entry["l"] != index:
                return None, "multipole coefficients 必须按 l=1..lmax 排列"
            for key in ("a", "b"):
                pair = entry.get(key)
                if not isinstance(pair, list) or len(pair) != 2 or not all(finite(v) for v in pair):
                    return None, f"系数 {key} 须为有限的 [实部, 虚部]"
        for key in ("qsca", "qext", "qback"):
            if not finite(case.get(key)) or case[key] < 0:
                return None, f"{key} 须为有限非负数"
        if not finite(case.get("g")) or not -1 <= case["g"] <= 1:
            return None, "g 须位于[-1,1]"
        phase = case.get("phase")
        if not isinstance(phase, list) or len(phase) != len(model["angles_deg"]):
            return None, "phase 数量与公开角度不符"
        for angle, point in zip(model["angles_deg"], phase):
            if not isinstance(point, dict) or not finite(point.get("theta_deg")) or point["theta_deg"] != angle or not finite(point.get("value")) or point["value"] < 0:
                return None, "phase 须按公开角度依次提交有限非负值"
        mapped[case["id"]] = case
    if type(answer.get("method")) is not str or not answer["method"].strip():
        return None, "须简述数值方法"
    return mapped, None
