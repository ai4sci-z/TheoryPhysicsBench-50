"""PEC Mie coefficients and integrated/angle-resolved scattering observables."""
import math

import numpy as np
from scipy.special import spherical_jn, spherical_yn


def coefficients(x, lmax):
    ell = np.arange(1, lmax + 1)
    j = spherical_jn(ell, x)
    y = spherical_yn(ell, x)
    jp = spherical_jn(ell, x, derivative=True)
    yp = spherical_yn(ell, x, derivative=True)
    psi, chi = x * j, x * y
    dpsi, dchi = j + x * jp, y + x * yp
    return dpsi / (dpsi + 1j * dchi), psi / (psi + 1j * chi)


def amplitudes(mu, a, b):
    prev, current = 0.0, 1.0
    s1 = s2 = 0j
    for ell, (an, bn) in enumerate(zip(a, b), start=1):
        tau = ell * mu * current - (ell + 1) * prev
        factor = (2 * ell + 1) / (ell * (ell + 1))
        s1 += factor * (an * current + bn * tau)
        s2 += factor * (an * tau + bn * current)
        prev, current = current, ((2 * ell + 1) / ell) * mu * current - ((ell + 1) / ell) * prev
    return s1, s2


def summarize(x, a, b, angles):
    ell = np.arange(1, len(a) + 1, dtype=float)
    weight = 2 * ell + 1
    qsca = float(2 / x**2 * np.sum(weight * (abs(a)**2 + abs(b)**2)))
    qext = float(2 / x**2 * np.real(np.sum(weight * (a + b))))
    backward = np.sum(weight * (-1.0)**ell * (a - b))
    qback = float(abs(backward)**2 / x**2)
    n = np.arange(1, len(a), dtype=float)
    adjacent = np.sum(n * (n + 2) / (n + 1) * np.real(a[:-1] * np.conj(a[1:]) + b[:-1] * np.conj(b[1:])))
    same = np.sum(weight / (ell * (ell + 1)) * np.real(a * np.conj(b)))
    g = float(4 * (adjacent + same) / (x**2 * qsca))
    phase = []
    for theta in angles:
        s1, s2 = amplitudes(math.cos(math.radians(theta)), a, b)
        phase.append({"theta_deg": theta, "value": float((abs(s1)**2 + abs(s2)**2) / 2)})
    return {"qsca": qsca, "qext": qext, "qback": qback, "g": g, "phase": phase}


def solve_case(case, angles):
    a, b = coefficients(case["x"], case["lmax"])
    coeffs = [{"l": ell, "a": [float(z.real), float(z.imag)], "b": [float(w.real), float(w.imag)]}
              for ell, (z, w) in enumerate(zip(a, b), start=1)]
    return {"id": case["id"], "coefficients": coeffs, **summarize(case["x"], a, b, angles)}
