#!/usr/bin/env bash
set -euo pipefail
python3 /solution/solve.py --data-root /app/data --output /app/output/answer.json
