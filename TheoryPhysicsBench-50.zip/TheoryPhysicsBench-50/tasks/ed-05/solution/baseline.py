"""Run the actual public dipole starting point with configurable paths."""
import argparse
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, default=Path("/app/data"))
    parser.add_argument("--output", type=Path, default=Path("/app/output/answer.json"))
    args = parser.parse_args()
    sys.path.insert(0, str(args.data_root))
    from start import make_answer
    from physics import load_model
    answer = make_answer(load_model(args.data_root), args.data_root)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(answer, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"cases": len(answer["cases"]), "method": answer["method"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
