import argparse
import json
from pathlib import Path

from solver_core import solve_case


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, default=Path("/app/data"))
    parser.add_argument("--output", type=Path, default=Path("/app/output/answer.json"))
    args = parser.parse_args()
    model = json.loads((args.data_root / "model.json").read_text(encoding="utf-8"))
    answer = {"cases": [solve_case(case, model["angles_deg"]) for case in model["cases"]],
              "method": "PEC Riccati-Bessel multipole coefficients with adjacent-order asymmetry sum and angular amplitudes"}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(answer, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"cases": len(answer["cases"]), "method": answer["method"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
