# 圆柱介质波导的全轴对称模、色散与能流约束

## 研究问题

无限长、半径 a 的非磁性、无损、无材料色散圆柱芯层，介电常数 ε₁ 大于均匀外介质 ε₀。所有介电常数为相对真空值，磁导率均等于真空值。场沿 z 正方向以 exp(i k_z z-iωt) 传播，且**不依赖方位角**。本题只研究轴对称 TE₀ₙ、TM₀ₙ 模；非轴对称混合 HE/EH 模不在范围内。

定义无量纲频率 q=ωa/c、V=q√(ε₁−ε₀)、芯内横向波数 u=γa、外部衰减 w=αa、轴向波数 p=k_z a。导模要求 u>0、w>0；u²+w²=V²，p²=ε₁q²−u²。芯内轴向场为 J₀(u r/a)，外部为 A K₀(w r/a)，分别保证原点正则和无穷远衰减。连续谱、辐射模及恰在 w=0 的截止态不算导模。

对公开六个工况，找出全部轴对称 TE/TM 导模，按每种偏振从小 u 到大 u 的径向阶数 n=1,2,… 标记，计算：

- u；
- 有效折射率 n_eff=p/q；
- 群折射率 n_g=dp/dq，导数中 ε₁、ε₀ 固定；
- 沿正 z 的平均 Poynting 能流中位于芯层 r<a 的比例 Γ=P_core/P_total。

研究选择包括：截止附近导模数目、TE/TM 边界条件、外部能量扩展和隐式色散导数。不能只把圆柱当作金属封闭波导或把相折射率当作群折射率。

## 边界条件与材料

在 r=a 处切向 E、H 连续。Jackson 的轴对称介质波导方程化为

\[
\frac{J_1(u)}{uJ_0(u)}+C\frac{K_1(w)}{wK_0(w)}=0,
\quad w=\sqrt{V^2-u^2},\qquad
C=\begin{cases}1,&\mathrm{TE},\\ \epsilon_0/\epsilon_1,&\mathrm{TM}.\end{cases}
\]

避免直接在 J₀ 零点处除法，可以使用等价的无极点残差
\(C uJ_0(u)+w[K_0(w)/K_1(w)]J_1(u)\)。不应把 J₀ 的极点当作物理根。

- `/app/data/model.json`：ε₁、ε₀、V、所有评价权重。
- `/app/data/physics.py`：模型读取、格式校验、无极点边界残差。
- `/app/data/start.py`：强约束起点，采用 J₁(u)=0、外部功率为零的近似，可能漏掉新生模式。
- `/app/data/feedback.py`：核对输出并显示每模边界残差，不保证模完整性或导数/能流正确。
- `/app/data/metric.json`：实测基线、参考值和原始指标容差。

```bash
python3 /app/data/start.py
python3 /app/data/feedback.py /app/output/answer.json
```

## 芯层能流的约定

轴向场归一为芯内 J₀、外部 A K₀，A=J₀(u)/K₀(w)。在忽略相同正常数后，TE 轴向能流的径向积分权重为
\[
P_c\propto\int_0^1\rho\,[J_1(u\rho)/u]^2d\rho,\qquad
P_o\propto A^2\int_1^\infty\rho\,[K_1(w\rho)/w]^2d\rho.
\]
TM 对应将芯层积分乘 ε₁、外层积分乘 ε₀。Γ=P_c/(P_c+P_o)。这里计算沿轴能流，而不是只积分轴向场的平方。

## 最终产物

写 `/app/output/answer.json`，每个工况恰好一项，modes 列出全部导模。低于截止时填空数组。示意数值不是答案：

```json
{"cases":[{"id":"guide-01","modes":[
 {"polarization":"TE","radial_order":1,"u":2.5,
  "effective_index":1.2,"group_index":1.4,"core_power_fraction":0.5}
]}],"method":"brief method description"}
```

工况和模式顺序不限；polarization 只能为TE/TM，radial_order为1至8的整数（不能是布尔值）；u须严格位于(0,V)；折射率为有限正数，Γ为[0,1]有限实数。每工况最多16模。未知/重复工况、缺项、非有限数等为invalid并得0。重复模式、漏模和错误阶次按实际匹配误差处罚。

## 评价

每工况将提交模式和高精度参考模式做最小代价一一匹配，缺少或多余模式代价为1；偏振或径向阶次不同的匹配代价为1。相同标签时：u相对误差占20%，n_eff相对误差20%，n_g相对误差25%，Γ的绝对误差35%。所有相对误差截断到1，折射率分母用max(|参考值|,1)，u分母用max(|参考值|,1e-12)。匹配误差除以较大的模式数，再乘100；双方均无模则为0。六工况算术平均为原始指标（百分点，越低越好）。全部常数见公开模型。

私有真值由独立高精度边界求根、频率差分和径向能流积分生成。课程原版质量函数按本题实测b/h换算质量分，允许不同合法求解方法。原始指标容差1e-5百分点。

## 时间与资源

4 CPU、4 GiB内存、4 GiB磁盘、0 GPU。Agent720秒，独立verifier120秒。无需联网或下载权重。
