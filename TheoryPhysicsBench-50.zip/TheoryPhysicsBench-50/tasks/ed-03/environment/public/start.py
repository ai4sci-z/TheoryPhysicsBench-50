"""Strong-confinement metallic-boundary approximation; misses newborn modes."""
import argparse
import json
import math
from pathlib import Path
from scipy.special import jn_zeros


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--data-root",type=Path,default=Path("/app/data"));parser.add_argument("--output",type=Path,default=Path("/app/output/answer.json"));args=parser.parse_args()
    model=json.loads((args.data_root/"model.json").read_text(encoding="utf-8"));cases=[]
    for case in model["cases"]:
        q=case["V"]/math.sqrt(case["epsilon_core"]-case["epsilon_out"]);modes=[]
        for pol in ("TE","TM"):
            for n,u in enumerate(jn_zeros(1,8),1):
                if u<case["V"]:
                    index=math.sqrt(case["epsilon_core"]-(u/q)**2)
                    modes.append({"polarization":pol,"radial_order":n,"u":float(u),"effective_index":index,"group_index":case["epsilon_core"]/index,"core_power_fraction":1.0})
        cases.append({"id":case["id"],"modes":modes})
    answer={"cases":cases,"method":"strong confinement: J1(u)=0, zero external flux, fixed transverse eigenvalue"}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print(json.dumps(answer,ensure_ascii=False))


if __name__=="__main__":main()
