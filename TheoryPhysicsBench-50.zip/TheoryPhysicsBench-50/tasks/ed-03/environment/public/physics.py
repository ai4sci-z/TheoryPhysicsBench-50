"""Public cylindrical dielectric-guide boundary residual and result schema."""
import json
import math
from pathlib import Path
from scipy.special import jv,kve


def load_model(root="/app/data"):
    return json.loads((Path(root)/"model.json").read_text(encoding="utf-8"))


def boundary_residual(case,polarization,u):
    v=case["V"]
    if not 0<u<v:return None
    w=math.sqrt((v-u)*(v+u))
    ratio=1 if polarization=="TE" else case["epsilon_out"]/case["epsilon_core"]
    return ratio*u*jv(0,u)+w*kve(0,w)/kve(1,w)*jv(1,u)


def finite(value):
    try:return type(value) in (int,float) and math.isfinite(value)
    except OverflowError:return False


def validate_answer(answer,model):
    if not isinstance(answer,dict) or not isinstance(answer.get("cases"),list):return None,"须提交cases数组"
    expected={case["id"]:case for case in model["cases"]}
    if len(answer["cases"])!=len(expected):return None,"每个公开工况须恰好一项"
    mapped={}
    for case in answer["cases"]:
        if not isinstance(case,dict) or type(case.get("id")) is not str or case["id"] not in expected or case["id"] in mapped:return None,"未知或重复工况id"
        modes=case.get("modes")
        if not isinstance(modes,list) or len(modes)>16:return None,"modes须为0至16项数组"
        for mode in modes:
            if not isinstance(mode,dict) or mode.get("polarization") not in ("TE","TM"):return None,"polarization须为TE或TM"
            if type(mode.get("radial_order")) is not int or not 1<=mode["radial_order"]<=8:return None,"radial_order须为1至8的整数"
            for key in ("u","effective_index","group_index","core_power_fraction"):
                if not finite(mode.get(key)):return None,f"{key}须为有限实数"
            if not 0<mode["u"]<expected[case["id"]]["V"]:return None,"导模u须严格位于(0,V)"
            if mode["effective_index"]<=0 or mode["group_index"]<=0:return None,"折射率须为正"
            if not 0<=mode["core_power_fraction"]<=1:return None,"芯层功率比例须位于[0,1]"
        mapped[case["id"]]=modes
    return mapped,None
