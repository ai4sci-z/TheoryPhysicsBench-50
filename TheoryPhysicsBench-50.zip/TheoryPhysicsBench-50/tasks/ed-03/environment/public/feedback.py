import argparse
import json
from pathlib import Path
from physics import boundary_residual,load_model,validate_answer


def main():
    parser=argparse.ArgumentParser();parser.add_argument("answer",type=Path);args=parser.parse_args()
    try:answer=json.loads(args.answer.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):print(json.dumps({"valid":False,"reason":"没有有效JSON"},ensure_ascii=False));return
    model=load_model(Path(__file__).parent);mapped,reason=validate_answer(answer,model)
    if reason:print(json.dumps({"valid":False,"reason":reason},ensure_ascii=False));return
    details=[{"id":case["id"],"modes":[{"polarization":m["polarization"],"radial_order":m["radial_order"],"regularized_boundary_residual":boundary_residual(case,m["polarization"],m["u"])} for m in mapped[case["id"]]]} for case in model["cases"]]
    print(json.dumps({"valid":True,"cases":details,"note":"边界残差不证明模式完整性、群折射率或能流积分正确"},ensure_ascii=False,indent=2))


if __name__=="__main__":main()
