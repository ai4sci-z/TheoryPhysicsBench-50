import json
import os
from pathlib import Path
import sys
import numpy as np
from scipy.optimize import linear_sum_assignment
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get('TASK_DATA_ROOT','/app/data'));private=Path(private_root or os.environ.get('TASK_PRIVATE_ROOT','/tests/private'))
    sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    model=load_model(data);mapped,reason=validate_answer(answer,model)
    if reason:return None,{'reason':reason}
    truth=json.loads((private/'truth.json').read_text(encoding='utf-8'));details=[];cfg=model['scoring']
    for expected in truth['cases']:
        actual=mapped[expected['id']];count=max(len(actual),len(expected['modes']))
        if count==0:raw=0.0
        else:
            cost=np.ones((count,count))
            for i,p in enumerate(actual):
                for j,q in enumerate(expected['modes']):
                    if p['polarization']!=q['polarization'] or p['radial_order']!=q['radial_order']:continue
                    errors={key:min(1.,abs(p[key]-q[key])/max(abs(q[key]),cfg['index_floor'] if key in ('effective_index','group_index') else 1e-12)) for key in ('u','effective_index','group_index')}
                    errors['core_power_fraction']=abs(p['core_power_fraction']-q['core_power_fraction'])
                    cost[i,j]=sum(cfg[key+'_weight']*value for key,value in errors.items())
            rows,cols=linear_sum_assignment(cost);raw=100*float(cost[rows,cols].sum()/count)
        details.append({'id':expected['id'],'raw_metric':raw,'submitted_modes':len(actual),'expected_modes':len(expected['modes'])})
    return sum(c['raw_metric'] for c in details)/len(details),{'cases':details}


def main():
    logs=Path(os.environ.get('VERIFIER_LOG_ROOT','/logs/verifier'));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get('TASK_TESTS_ROOT','/tests'));output=Path(os.environ.get('TASK_ANSWER_PATH','/app/output/answer.json'))
    metric=json.loads((tests/'metric.json').read_text(encoding='utf-8'))
    try:answer=json.loads(output.read_text(encoding='utf-8'))
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{'reason':'没有有效JSON产物'}
    else:raw,details=evaluate(answer)
    status='invalid' if raw is None else 'completed';score=quality_score(metric,raw,status)
    details.update(raw_metric=raw,score=score,status=status)
    (logs/'metrics.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(logs/'reward.txt').write_text(f'{score}\n',encoding='utf-8')


if __name__=='__main__':main()
