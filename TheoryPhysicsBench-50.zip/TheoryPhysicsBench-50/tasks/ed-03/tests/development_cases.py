import copy


def make_cases(reference):
    names=('equivalent','wrong','missing_mode','repeated_mode','swap_polarization','wrong_flux','wrong_group','duplicate','boolean','nonfinite')
    cases={name:copy.deepcopy(reference) for name in names}
    cases['equivalent']['cases'].reverse()
    for case in cases['equivalent']['cases']:case['modes'].reverse()
    for case in cases['wrong']['cases']:case['modes']=[]
    cases['missing_mode']['cases'][1]['modes'].pop()
    cases['repeated_mode']['cases'][1]['modes'].append(copy.deepcopy(cases['repeated_mode']['cases'][1]['modes'][0]))
    for case in cases['swap_polarization']['cases']:
        for mode in case['modes']:mode['polarization']='TM' if mode['polarization']=='TE' else 'TE'
    for case in cases['wrong_flux']['cases']:
        for mode in case['modes']:mode['core_power_fraction']=1.0
    for case in cases['wrong_group']['cases']:
        for mode in case['modes']:mode['group_index']=mode['effective_index']
    cases['duplicate']['cases'][1]=copy.deepcopy(cases['duplicate']['cases'][0])
    cases['boolean']['cases'][1]['modes'][0]['radial_order']=True
    cases['nonfinite']['cases'][1]['modes'][0]['u']=float('nan')
    cases['malformed']={}
    return cases
