"""Pole-free Bessel boundary solve and analytic dispersion derivative."""
import math
from scipy.special import jv,jn_zeros,kve
from scipy.optimize import brentq


def root_for(case,pol,lo,hi):
    v=case["V"];ratio=1 if pol=="TE" else case["epsilon_out"]/case["epsilon_core"]
    def residual(u):
        w=math.sqrt(max((v-u)*(v+u),0))
        outside=0 if w==0 else w*kve(0,w)/kve(1,w)
        return ratio*u*jv(0,u)+outside*jv(1,u)
    return brentq(residual,lo+1e-12,min(hi,v)-1e-12,xtol=5e-15)


def mode_data(case,pol,n,u):
    eps1,eps0,v=case["epsilon_core"],case["epsilon_out"],case["V"]
    q=v/math.sqrt(eps1-eps0);w=math.sqrt((v-u)*(v+u));p=math.sqrt(eps1*q*q-u*u)
    ratio=1 if pol=="TE" else eps0/eps1
    a=jv(1,u)/(u*jv(0,u));b=kve(1,w)/(w*kve(0,w))
    derivative_a=1/u-2*a/u+u*a*a
    derivative_b=-1/w-2*b/w+w*b*b
    du_dv=-ratio*derivative_b*v/w/(derivative_a-ratio*derivative_b*u/w)
    group=(eps1*q-u*du_dv*math.sqrt(eps1-eps0))/p
    inside=(jv(1,u)**2-jv(0,u)*jv(2,u))/(2*u*u)
    outside=jv(0,u)**2*(kve(0,w)*kve(2,w)-kve(1,w)**2)/(2*w*w*kve(0,w)**2)
    if pol=="TM":inside*=eps1;outside*=eps0
    return {"polarization":pol,"radial_order":n,"u":u,"effective_index":p/q,"group_index":group,"core_power_fraction":inside/(inside+outside)}


def solve_case(case):
    j0,j1=jn_zeros(0,8),jn_zeros(1,8);modes=[]
    for pol in ("TE","TM"):
        for n,(lo,hi) in enumerate(zip(j0,j1),1):
            if case["V"]>lo:
                modes.append(mode_data(case,pol,n,root_for(case,pol,lo,hi)))
    return {"id":case["id"],"modes":modes}
