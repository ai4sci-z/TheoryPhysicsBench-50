# Kerr 黑洞局域分裂：负能量是否意味着实际能量提取

## 物理目标与约定

比较局部运动学允许的能量增益与真正能逃到无穷远的能量。给定赤道面 Kerr 黑洞旁的母粒子瞬时状态，让它分裂为两束背向光子，计算守恒量、每束光子的全局去向和实际提取比例。不能把初始向外运动或 Killing 能量为正直接当作逃逸。

使用度规号差 \((-+++)\) 和几何单位 \(G=c=M=1\)，母粒子静质量为 1。\(0<a<1\)，事件视界为 \(r_+=1+\sqrt{1-a^2}\)。以下量均在赤道面 \(\vartheta=\pi/2\) 计算，\(r\) 是 Boyer–Lindquist 径向坐标；它不是一般情形的面积半径。固定背景、测试粒子近似，不更新黑洞质量或自旋。

\[
\Delta=r^2-2r+a^2,\quad
A=(r^2+a^2)^2-a^2\Delta,\quad
\alpha=\sqrt{\Delta r^2/A},\quad
\omega=2ar/A,\quad \varpi=\sqrt A/r.
\]

相关度规分量为 \(g_{tt}=2/r-1\)、\(g_{t\phi}=-2a/r\)、\(g_{rr}=r^2/\Delta\)、\(g_{\phi\phi}=A/r^2\)。局部非转动观测者（零角动量观测者，ZAMO）的正交标架为

\[
e_{\hat0}=\alpha^{-1}(\partial_t+\omega\partial_\phi),\quad
e_{\hat r}=\sqrt\Delta\,r^{-1}\partial_r,\quad
e_{\hat\vartheta}=r^{-1}\partial_\vartheta,\quad
e_{\hat\phi}=\varpi^{-1}\partial_\phi.
\]

`/app/data/model.json` 给出五组独立瞬时条件，每组包含 `a,r,v_r,v_phi`。\(v_r,v_\phi\) 是母粒子相对 ZAMO 的三速度，\(\gamma=(1-v_r^2-v_\phi^2)^{-1/2}\)。这些速度是本题的直接输入，**不假设母粒子从无穷远静止下落，也不假设母粒子 Killing 能量等于 1**。

## 分裂与守恒量

母粒子瞬时静止系由 ZAMO 标架作标准无旋转 Lorentz boost 得到，坐标轴由该 boost 的定义固定。在此静止系，两束光子的四动量为

\[
p'_\pm=\frac12(1,\ \pm\cos\theta_j,\ 0,\ \pm\sin\theta_j),\qquad
\theta_j=\frac{\pi(j+0.37)}{32},\quad j=0,\ldots,31.
\]

因此两光子总四动量等于静止母粒子的四动量。将它们 boost 回 ZAMO 系，再转换为坐标分量，可用

\[
p^t=\hat p^0/\alpha,\quad p^r=\sqrt\Delta\,\hat p^r/r,\quad
p^\phi=\omega\hat p^0/\alpha+\hat p^\phi/\varpi,
\qquad E=-p_t,\quad L=p_\phi.
\]

本题的光子列表顺序固定：`photons[0]` 对应 \(+\) 方向，`photons[1]` 对应 \(-\) 方向，不能交换后当作等价答案。Killing 能量 \(E\) 在能层内可以为负，ZAMO 测量的局域能量 \(\hat p^0\) 始终为正。

另求母粒子的 \(E_0,L_0\)，以及分裂方向在整个平面连续变化时**单束光子 Killing 能量的局部运动学上界** \(E_{\rm local,max}\)。该上界只考察分裂点，不施加逃逸条件；它不是有限角度网格上的实际逃逸最大值。

## 全局逃逸与捕获

赤道面类光测地线的 Carter 常数为 0，径向势为

\[
\left(r^2\frac{dr}{d\lambda}\right)^2=\mathcal R(r),\qquad
\mathcal R(x)=[E(x^2+a^2)-aL]^2-\Delta(x)(L-aE)^2.
\]

初始径向符号由 boost 后 \(\hat p^r\) 决定。光子沿未来方向运动；遇径向单根时转向。输出 `escape` 仅当它最终到达无穷远，`capture` 当它最终穿过未来事件视界。必须检查发射点上下方的全部视界外转折点，不能只看初始符号。所有给定样本都不恰好位于切向发射、零能、临界双根或视界生成线；可通过双精度多项式根或其他可靠算法分类。

视界角速度 \(\Omega_H=a/(2r_+)\)。被捕获光子必须满足未来视界条件 \(E-\Omega_H L\ge0\)。该条件是核验条件，不能单独取代径向运动判断。

一次分裂计为实际能量提取，当且仅当一束 `escape`，另一束 `capture` 且被捕获束 \(E<0\)。每工况输出满足条件的样本数除以 32，以及这些样本中最大的 \(E_{\rm escape}/E_0-1\)；若无此类样本，两项均填 0。最优增益只在给定 32 个方向中取最大，不要求连续角优化，也不把黑洞可提取的整体旋转能比例当作本次分裂效率。

## 输入、反馈与最终产物

- `/app/data/model.json`：单位、角度规则、五组物理条件。
- `/app/data/physics.py`：schema、公开径向势函数，不提供完整逃逸分类。
- `/app/data/feedback.py`：结构、能量和角动量守恒残差、被标记捕获束的视界未来条件。
- `/app/data/metric.json`：固定指标与实测端点。
- Python 3.12、NumPy 2.1.3、SciPy 1.14.1、mpmath 1.3.0。

可不限次数运行公开反馈：

```bash
python /app/data/feedback.py /app/output/trial.json
```

最终提交 `/app/output/answer.json`。字段示意如下；真实文件须覆盖每个工况和全部 32 个角度：

```json
{"cases":[{"id":"split-01","parent_energy":0.7,
 "parent_angular_momentum":1.3,"local_energy_upper":0.5,
 "horizon_omega":0.13,"extraction_fraction":0.0,"best_fractional_gain":0.0,
 "samples":[{"index":0,"photons":[
   {"energy":0.4,"angular_momentum":0.8,"fate":"escape"},
   {"energy":0.3,"angular_momentum":0.5,"fate":"capture"}]}]}]}
```

工况顺序和 sample 顺序不限；id、index 各恰好出现一次。每个 sample 恰有两束，顺序按上文固定。所有数值有限；母粒子能量须正，提取比例在 \([0,1]\)，最优增益非负；光子能量和角动量可负。

## 固定评分与资源

原始误差越低越好，单位百分点。每个工况：光子数值误差按 \(|\Delta E|/0.05\) 和 \(|\Delta L|/0.1\) 各截到 1，再对全部光子平均；去向误差为全部光子的错误分类比例。六个汇总量按 `parent_energy,parent_angular_momentum,local_energy_upper,extraction_fraction,best_fractional_gain,horizon_omega` 的顺序，以绝对尺度 \(0.05,0.1,0.05,0.1,0.05,0.02\) 截断归一化并平均。工况误差为三类的 \(0.25,0.45,0.30\) 加权和；总误差为五工况均值乘 100。教师原版质量函数用固定基线/参考端点映射到 \([0,1]\)。结构非法、非有限数、重复标识或布尔冒充数值为无效；物理错误按实际误差评分。

基线正确计算局域 boost 与 Killing 守恒量，仅以 `E>0` 且初始径向向外作为逃逸近似；参考补齐完整径向转折拓扑。两者使用相同数据和指标。Agent 720 秒、verifier 120 秒；4 CPU、4 GB 内存、4 GB 磁盘、0 GPU。
