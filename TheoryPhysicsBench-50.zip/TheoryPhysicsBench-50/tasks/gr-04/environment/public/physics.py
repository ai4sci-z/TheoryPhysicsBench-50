import json
import math
from pathlib import Path
SUMMARY=("parent_energy","parent_angular_momentum","local_energy_upper","extraction_fraction","best_fractional_gain","horizon_omega")
def finite(x):
    try:return type(x) in (int,float) and math.isfinite(x)
    except OverflowError:return False
def load_model(root="/app/data"):return json.loads((Path(root)/"model.json").read_text())
def radial_potential(a,r,E,L):return (E*(r*r+a*a)-a*L)**2-(r*r-2*r+a*a)*(L-a*E)**2
def validate_answer(answer,model):
    if not isinstance(answer,dict) or not isinstance(answer.get("cases"),list) or len(answer["cases"])!=len(model["cases"]):return None,"须覆盖所有cases"
    ids={c["id"] for c in model["cases"]};result={}
    for case in answer["cases"]:
        if not isinstance(case,dict) or type(case.get("id")) is not str or case["id"] not in ids or case["id"] in result:return None,"未知或重复id"
        if not all(finite(case.get(k)) for k in SUMMARY) or case["parent_energy"]<=0 or not 0<=case["extraction_fraction"]<=1 or case["best_fractional_gain"]<0:return None,"汇总字段非法"
        samples=case.get("samples")
        if not isinstance(samples,list) or len(samples)!=model["angles_count"]:return None,"samples数量非法"
        seen=set();mapped={}
        for sample in samples:
            if not isinstance(sample,dict) or type(sample.get("index")) is not int or not 0<=sample["index"]<model["angles_count"] or sample["index"] in seen:return None,"index未知或重复"
            photons=sample.get("photons")
            if not isinstance(photons,list) or len(photons)!=2:return None,"每次分裂恰好两束光，顺序为正方向和负方向"
            for photon in photons:
                if not isinstance(photon,dict) or not finite(photon.get("energy")) or not finite(photon.get("angular_momentum")) or photon.get("fate") not in ("escape","capture"):return None,"光子字段非法"
            seen.add(sample["index"]);mapped[sample["index"]]=sample
        result[case["id"]]={**case,"samples":mapped}
    return result,None
