import argparse
import json
import math
from pathlib import Path
from physics import load_model,validate_answer,radial_potential
def main():
    p=argparse.ArgumentParser();p.add_argument("answer",type=Path);args=p.parse_args();model=load_model(Path(__file__).parent)
    try:answer=json.loads(args.answer.read_text())
    except (OSError,ValueError):print(json.dumps({"valid":False,"reason":"没有有效JSON"},ensure_ascii=False));return
    mapped,reason=validate_answer(answer,model);out={"valid":reason is None,"reason":reason}
    if reason is None:
        records=[]
        for case in model["cases"]:
            item=mapped[case["id"]];rp=1+math.sqrt(1-case["a"]**2);omega=case["a"]/(2*rp)
            for index,sample in item["samples"].items():
                photons=sample["photons"];records.append({"id":case["id"],"index":index,"energy_sum_residual":sum(p["energy"] for p in photons)-item["parent_energy"],"angular_momentum_sum_residual":sum(p["angular_momentum"] for p in photons)-item["parent_angular_momentum"],"capture_future_margins":[p["energy"]-omega*p["angular_momentum"] for p in photons if p["fate"]=="capture"]})
        out["conservation"]=records
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
