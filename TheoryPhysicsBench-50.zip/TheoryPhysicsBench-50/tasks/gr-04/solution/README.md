# gr-04 参考推导与复现

梁灿彬、周彬《微分几何入门与广义相对论》中册 PDF145（书133）式 (13-4-9)–(13-4-13) 给出局域非转动标架；PDF147（书135）给出 Penrose 四动量守恒及视界角速度 (13-5-3)，PDF148（书136）式 (13-5-5) 给出未来视界的能量角动量限制。已实际查看渲染原页，见 `checks/gr-04-source-pages/`。本题直接给定母粒子的局部速度，采用两束等能光子分裂并研究离散逃逸方向；不把这种新增数值任务声称为教材原习题。

令 \(\boldsymbol v=(v_r,v_\phi)\)、\(v^2=v_r^2+v_\phi^2\)，\(\boldsymbol n=(\cos\theta,\sin\theta)\)。母粒子系两光子为 \((1,\pm\boldsymbol n)/2\)。无旋转 boost 给出

\[
\hat e_\pm=\tfrac12\gamma(1\pm\boldsymbol v\cdot\boldsymbol n),\qquad
\hat{\boldsymbol p}_\pm=\tfrac12\left[\gamma\boldsymbol v\pm\boldsymbol n
\pm\frac{\gamma-1}{v^2}(\boldsymbol v\cdot\boldsymbol n)\boldsymbol v\right].
\]

固定输入的 \(v^2>0\)，不存在除零。通过标架转换或度规缩并得

\[
E=\alpha\hat e+\omega\varpi\hat p^\phi,\qquad L=\varpi\hat p^\phi,
\quad E_0=\gamma(\alpha+\omega\varpi v_\phi),\quad L_0=\gamma\varpi v_\phi.
\]

母粒子单位四速度为 \(u\)，平稳 Killing 场 \(\xi=\partial_t\)，有 \(-\xi\cdot u=E_0\)。将 \(\xi\) 分解为平行于 \(u\) 和正交于 \(u\) 的部分，后者的欧氏模长平方为 \(g_{tt}+E_0^2\)。母粒子系单束光子能量为 1/2，方向在赤道面自由变化，故 Cauchy–Schwarz 给出并可达到

\[
E_{\rm local,max}=\tfrac12\left(E_0+\sqrt{E_0^2+g_{tt}}\right).
\]

这不意味着对应方向可逃逸；它也不要求两束能量均为正。\(r<2\) 能层内可出现负 Killing 能量，但局域光子能量仍正。

展开赤道面类光径向势：

\[
\mathcal R(x)=x\{E^2x^3+(a^2E^2-L^2)x+2(L-aE)^2\}.
\]

只需考察三次多项式的所有视界外正实根。发射点处 \(\mathcal R\ge0\)。无外侧根才可能进入通往无穷远的允许区间；同时必须 \(E>0\)。若初始向外且无外侧根则逃逸；若初始向内，必须先在视界与发射点之间遇到转折根，再转向并且无外侧根，才会逃逸。其余为捕获。根的完整性优于只在有限径向窗口采样势函数；固定样本没有临界双根，无须为精确临界轨道新增第三类标签。

参考用 `numpy.roots` 求三次根，筛选小虚部和视界外根。最接近发射点的根距约 \(4.47\times10^{-7}\)，远大于代码 \(10^{-9}\) 发射点容差。视界未来性作为独立检查，而非替代转折拓扑。实际提取要求逃逸束和负能捕获束同时存在，由四动量守恒其增益等于 \(-E_{\rm capture}/E_0\)。

独立真值 `tools/build_gr04_truth.py` 不导入参考实现：使用 75 位 4×4 Lorentz 矩阵、ZAMO 标架与 Boyer–Lindquist 度规缩并求 E/L；用 Cardano/三角解析式计算全部三次实根。另检查标架正交、boost 的 Lorentz 性、光子零范数、母粒子四动量和、径向势恒等式、局部上界及被捕获束的未来视界条件。参考使用的简化 E/L 表达式和 NumPy 根不是唯一真值来源。

开发复现：

```bash
python tools/build_gr04_truth.py
python tools/run_gr04_checks.py
```

`author_gr04.py`、`--calibrate` 为首次构建/定标入口，冻结后不再使用。Harbor oracle 入口 `bash /solution/solve.sh`；完整结果见 `checks/gr-04-validation.md`。这些数值是参考程序开发核验，不是正式 Codex 三次测评。
