# 点电荷与介质核壳球的反作用：自力反号和径向平衡

## 研究问题

一个单位点电荷位于球心的正 z 轴上，距离为 d>1。球是无自由电荷、无损耗、线性且各向同性的同心介质核壳球：外半径 R=1，内半径 rho，核内与壳层的介电常数相对外部均匀介质分别为 epsilon_core、epsilon_shell。二者都为正；小于 1 表示相对外介质较小，不表示绝对介电常数小于真空值。球体固定，不考虑任何非静电力。

单位约定为 q=1、R=1、1/(4*pi*epsilon_out)=1。相互作用能 U 定义为扣除点电荷无穷自能和无关常数后的极化反作用能，以点电荷在无穷远时 U=0。F 是点电荷所受诱导电场力的 z 分量，F>0 为远离球心的排斥，F<0 为吸引。

研究目标是判断偶极极化近似何时失效，并确定核壳竞争能否产生径向稳定平衡。对公开三组材料，完成：

1. 在六个给定距离计算 U 和 F。
2. 找出公开闭区间内所有 F=0 的距离，并按 F'(d)<0 为径向稳定、F'(d)>0 为径向不稳定分类。

这里的稳定性只讨论沿径向的小位移；不声称电荷在三维所有方向被约束。每组材料、测点和区间都是公开的固定实例，合起来算一道题。

## 材料与边界条件

- `/app/data/model.json`：材料工况、六个测距和搜索区间。
- `/app/data/physics.py`：模型读取、输出校验、逐阶边界方程和绝对尾界。
- `/app/data/feedback.py`：公开诊断命令。
- `/app/data/metric.json`：实测基线、参考值和课程指标配置。

电荷所在的外部区域满足带点源的泊松方程，两个球内区域满足拉普拉斯方程。两界面均无自由面电荷，所以电势连续，epsilon*dPhi/dr 连续；原点正则，无穷远诱导势衰减。无需加入接地导体的自由单极电荷。

点电荷入射势在 r<d 的展开为

\[
\Phi_{\rm inc}(r,\theta)=\sum_{l=0}^{\infty}\frac{r^l}{d^{l+1}}P_l(\cos\theta).
\]

逐阶写出外部诱导势 A_l*r^(-l-1)、壳内 B_l*r^l+C_l*r^(-l-1)、核内 D_l*r^l。可以独立消元、求解界面方程或使用等价的边值方法。能量为 U=(1/2)*q*Phi_induced(d)，直接求自力时对场坐标求导要固定源位置；从总相互作用能取 -dU/dd 应得相同结果。

## 起点与探索反馈

读取模型示例：

```python
import sys
sys.path.insert(0, "/app/data")
from physics import load_model, boundary_matrix
model = load_model()
M, b = boundary_matrix(model["cases"][0], 1)
print(model, M, b)
```

`boundary_matrix(case,l)` 将入射系数 I_l 设为 1，未知向量顺序为 `[A,B,Cbar,D]`，其中 Cbar=C/rho^(2l+1)。第三、四行分别将内界面方程除以 rho^l 和 rho^(l-1)，防止高阶小半径幂引起下溢。实际系数再乘 I_l=d^(-l-1)。

给定任意系数或候选输出，可以运行：

```bash
python /app/data/feedback.py --case sphere-02 --degree 1 --coefficients 0 0 0 0 --distance 1.025 --cutoff 100
python /app/data/feedback.py /app/output/trial.json
```

诊断返回格式是否合法、四个边界残差，以及所选截断阶数的绝对能量/自力尾界，不返回完整正确答案或得分。查询次数不限。尾界来自正介电常数下 |A_l/I_l|<1；令 z=d^(-2)，截到 L 阶后，

\[
|\Delta U|\le\frac{d^{-2}z^{L+1}}{2(1-z)},\qquad
|\Delta F|\le d^{-3}z^{L+1}\left(\frac{L+2}{1-z}+\frac{z}{(1-z)^2}\right).
\]

可从 l=1 的偶极极化近似开始，再检查高阶项、近表面收敛和自力符号。选择截断阶数、核对能量因子与平衡完整性属于本题工作。

## 最终产物

提交 `/app/output/answer.json`，根对象含 `cases` 数组，每个材料工况恰好一项。结构示例只说明字段，不代表正确结果：

```json
{"cases":[{"id":"sphere-01","measurements":[
  {"d":1.025,"energy":-0.1,"force":-0.2}
],"equilibria":[]}]}
```

实际须包含全部三组工况及每组全部六个距离。`measurements` 的顺序不限；d 必须来自公开测距且不重复，energy/force 须为有限实数。`equilibria` 为该材料在闭区间内所有不同径向平衡点，每项为 `{"d":1.7,"stability":"stable"}` 或 `"unstable"`；无平衡点填空数组。最多接受 8 项，以允许对完整性的真实检验。可附加字符串 `method`，不参与评分。

## 评价办法

验证器用独立高精度界面计算结果核对实际产物。每个测点的能量和自力误差分别为

\[
e_U=\min\left(1,\frac{|U-\hat U|}{\max(|\hat U|,10^{-4})}\right),\qquad
e_F=\min\left(1,\frac{|F-\hat F|}{\max(|\hat F|,10^{-4})}\right).
\]

每材料的平衡误差 e_eq：若正确与提交都无根为 0；根数不同为 1；根数均为 1 时，

\[
e_{eq}=0.7\min\left(1,\frac{|d_* -\hat d_*|}{\hat d_*}\right)+0.3\,\mathbf1_{\text{稳定性错误}}.
\]

本固定实例每材料至多一个平衡点。材料误差为 100*(0.35*mean(e_U)+0.45*mean(e_F)+0.20*e_eq)，总指标是三材料误差的算术平均，单位百分点，越小越好。基线只保留偶极项；完整参考求解两界面及高阶多极项，两者使用同样的公开信息与资源。课程原版换算函数把实测基线映为 0、参考映为 1。

缺失工况或测点、未知/重复 id 或距离、非有限/布尔数值、越界平衡位置、未知稳定性标签为无效输出并得 0。格式合法的物理错误按实际误差连续评分。重复平衡点会改变根数并受罚。

## 时间与资源

Agent 720 秒，verifier 120 秒，4 CPU、4 GB 内存、4 GB 磁盘，0 GPU。全部材料工况和验证规则公开；最终标签只保存在独立 verifier 中。
