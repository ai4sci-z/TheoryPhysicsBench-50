"""Public model and boundary-condition diagnostic, without reference labels."""

import json
import math
from pathlib import Path


def load_model(root="/app/data"):
    return json.loads((Path(root)/"model.json").read_text(encoding="utf-8"))


def finite(value):
    try:
        return type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        return False


def validate_answer(answer, model):
    if not isinstance(answer, dict) or not isinstance(answer.get("cases"), list):
        return None, "须提交含 cases 数组的 JSON 对象"
    expected = {case["id"] for case in model["cases"]}
    if len(answer["cases"]) != len(expected):
        return None, "每个材料工况须恰好一项"
    result = {}
    lo, hi = model["equilibrium_interval"]
    for case in answer["cases"]:
        if not isinstance(case, dict) or type(case.get("id")) is not str:
            return None, "工况须含字符串 id"
        identifier = case["id"]
        if identifier not in expected or identifier in result:
            return None, "工况 id 未知或重复"
        measurements = case.get("measurements")
        if not isinstance(measurements, list) or len(measurements) != len(model["distances"]):
            return None, f"{identifier} 须含全部公开距离的 measurements"
        seen = set()
        for point in measurements:
            if not isinstance(point, dict) or not all(finite(point.get(key)) for key in ("d", "energy", "force")):
                return None, "d、energy、force 须为有限实数"
            if point["d"] not in model["distances"] or point["d"] in seen:
                return None, "距离未知或重复"
            seen.add(point["d"])
        equilibria = case.get("equilibria")
        if not isinstance(equilibria, list) or len(equilibria) > 8:
            return None, "equilibria 须为至多 8 项的数组；无平衡点填 []"
        for eq in equilibria:
            if not isinstance(eq, dict) or not finite(eq.get("d")) or not lo <= eq["d"] <= hi:
                return None, "平衡距离须在公开闭区间内"
            if eq.get("stability") not in ("stable", "unstable"):
                return None, "径向稳定性须为 stable 或 unstable"
        result[identifier] = case
    return result, None


def boundary_matrix(case, degree):
    """Unknowns [A,B,Cbar,D], Cbar=C/rho^(2l+1); incident I_l=1.

    Rows enforce Phi and epsilon*dPhi/dr continuity at r=1 and rho.
    Inner rows are divided by rho^l and rho^(l-1), respectively.
    """
    l = degree
    if type(l) is not int or not 1 <= l <= 10000:
        raise ValueError("degree 须为 1 至 10000 的整数")
    e1, e2, rho = (case[key] for key in ("epsilon_core", "epsilon_shell", "rho"))
    s = rho**(2*l+1)
    return [
        [1.0, -1.0, -s, 0.0],
        [-(l+1), -e2*l, e2*(l+1)*s, 0.0],
        [0.0, 1.0, 1.0, -1.0],
        [0.0, e2*l, -e2*(l+1), -e1*l],
    ], [-1.0, -float(l), 0.0, 0.0]


def tail_bounds(d, degree):
    """Positive permittivities imply |A_l/I_l|<1; absolute U/F tail bounds."""
    z = d**-2
    return (
        0.5*d**-2*z**(degree+1)/(1-z),
        d**-3*z**(degree+1)*((degree+2)/(1-z)+z/(1-z)**2),
    )
