"""Useful public checks: candidate format, interface residuals and tail bounds."""

import argparse
import json
from pathlib import Path
from physics import boundary_matrix, finite, load_model, tail_bounds, validate_answer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("answer", nargs="?", type=Path)
    parser.add_argument("--case", default="sphere-02")
    parser.add_argument("--degree", type=int, default=1)
    parser.add_argument("--coefficients", type=float, nargs=4, metavar=("A", "B", "CBAR", "D"))
    parser.add_argument("--distance", type=float, default=1.025)
    parser.add_argument("--cutoff", type=int, default=100)
    args = parser.parse_args()
    model = load_model(Path(__file__).parent)
    result = {}
    if args.answer:
        try:
            answer = json.loads(args.answer.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            result.update(valid=False, reason="没有有效 JSON")
        else:
            _, reason = validate_answer(answer, model)
            result.update(valid=reason is None, reason=reason)
    if not finite(args.distance) or args.distance <= 1 or type(args.cutoff) is not int or args.cutoff < 1:
        raise SystemExit("distance 须 >1；cutoff 须为正整数")
    result["absolute_tail_bounds"] = dict(zip(("energy", "force"), tail_bounds(args.distance, args.cutoff)))
    if args.coefficients is not None:
        cases = {case["id"]: case for case in model["cases"]}
        if args.case not in cases or not all(finite(x) for x in args.coefficients):
            raise SystemExit("未知 case 或非有限系数")
        matrix, rhs = boundary_matrix(cases[args.case], args.degree)
        result["boundary_residuals"] = [sum(a*b for a, b in zip(row, args.coefficients))-target for row, target in zip(matrix, rhs)]
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
