"""Analytic elimination of the dielectric interfaces and bounded multipole sums."""

import math


def reflection(case, degree):
    l = degree
    e1, e2, rho = (case[key] for key in ("epsilon_core", "epsilon_shell", "rho"))
    t = l*(e2-e1)/(e2*(l+1)+e1*l)*rho**(2*l+1)
    impedance = e2*(l-(l+1)*t)/(1+t)
    return (l-impedance)/(l+1+impedance)


def cutoff(distance, tolerance=1e-12):
    z = distance**-2
    for degree in range(1, 10001):
        tail = distance**-3*z**(degree+1)*((degree+2)/(1-z)+z/(1-z)**2)
        if tail < tolerance:
            return degree
    raise RuntimeError("multipole cutoff did not converge")


def observables(case, distance, baseline=False):
    degree = 1 if baseline else cutoff(distance)
    z = distance**-2
    energy = math.fsum(0.5*reflection(case,l)*z**(l+1) for l in range(1,degree+1))
    force = math.fsum((l+1)*reflection(case,l)*distance**-3*z**l for l in range(1,degree+1))
    return energy, force


def solve_case(case, model, baseline=False):
    distances = model["distances"]
    measurements = [{"d": d, "energy": observables(case,d,baseline)[0], "force": observables(case,d,baseline)[1]} for d in distances]
    equilibria = []
    if not baseline:
        # Fixed interval sweep establishes brackets; each bracket is refined from fresh sums.
        lo, hi = model["equilibrium_interval"]
        grid = [lo+(hi-lo)*i/300 for i in range(301)]
        def force(d):
            return observables(case,d)[1]
        values = [force(d) for d in grid]
        for left, right, fleft, fright in zip(grid[:-1],grid[1:],values[:-1],values[1:]):
            if fleft*fright >= 0:
                continue
            for _ in range(55):
                mid = (left+right)/2
                if force(mid)*fleft > 0:
                    left, fleft = mid, force(mid)
                else:
                    right = mid
            d = (left+right)/2
            step = 1e-5
            derivative = (force(d+step)-force(d-step))/(2*step)
            equilibria.append({"d": d, "stability": "stable" if derivative < 0 else "unstable"})
    return {"id": case["id"], "measurements": measurements, "equilibria": equilibria}
