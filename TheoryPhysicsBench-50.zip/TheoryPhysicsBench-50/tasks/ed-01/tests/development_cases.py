import copy


def make_cases(reference):
    equivalent=copy.deepcopy(reference)
    equivalent["cases"].reverse()
    for case in equivalent["cases"]:case["measurements"].reverse()
    wrong=copy.deepcopy(reference)
    for case in wrong["cases"]:
        for point in case["measurements"]:point["energy"]=0;point["force"]=0
        case["equilibria"]=[]
    double_energy=copy.deepcopy(reference)
    for case in double_energy["cases"]:
        for point in case["measurements"]:point["energy"]*=2
    wrong_force=copy.deepcopy(reference)
    for case in wrong_force["cases"]:
        for point in case["measurements"]:point["force"]*=-1
    missing=copy.deepcopy(reference);missing["cases"][1]["equilibria"]=[]
    unstable=copy.deepcopy(reference);unstable["cases"][1]["equilibria"][0]["stability"]="unstable"
    duplicate=copy.deepcopy(reference);duplicate["cases"][0]["measurements"][0]["d"]=duplicate["cases"][0]["measurements"][1]["d"]
    boolean=copy.deepcopy(reference);boolean["cases"][0]["measurements"][0]["force"]=True
    return {"equivalent":equivalent,"wrong":wrong,"double_energy":double_energy,"wrong_force_sign":wrong_force,"missing_equilibrium":missing,"wrong_stability":unstable,"malformed":{"cases":[]},"duplicate_distance":duplicate,"boolean_number":boolean}
