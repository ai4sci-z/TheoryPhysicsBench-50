import json
import os
import sys
from pathlib import Path
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get("TASK_DATA_ROOT","/app/data"))
    private=Path(private_root or os.environ.get("TASK_PRIVATE_ROOT","/tests/private"))
    sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    submitted,reason=validate_answer(answer,load_model(data))
    if reason:return None,{"reason":reason}
    truth=json.loads((private/"truth.json").read_text(encoding="utf-8"))
    details=[]
    for case in truth["cases"]:
        predicted=submitted[case["id"]]
        points={point["d"]:point for point in predicted["measurements"]}
        energy_errors=[];force_errors=[]
        for expected in case["measurements"]:
            point=points[expected["d"]]
            energy_errors.append(min(1.0,abs(point["energy"]-expected["energy"])/max(abs(expected["energy"]),1e-4)))
            force_errors.append(min(1.0,abs(point["force"]-expected["force"])/max(abs(expected["force"]),1e-4)))
        mean_energy=sum(energy_errors)/len(energy_errors)
        mean_force=sum(force_errors)/len(force_errors)
        p,q=predicted["equilibria"],case["equilibria"]
        if not p and not q:equilibrium_error=0.0
        elif len(p)!=len(q):equilibrium_error=1.0
        elif len(q)==1:
            equilibrium_error=0.7*min(1.0,abs(p[0]["d"]-q[0]["d"])/q[0]["d"])+0.3*float(p[0]["stability"]!=q[0]["stability"])
        else:raise RuntimeError("this fixed task expects at most one radial equilibrium per case")
        raw=100*(0.35*mean_energy+0.45*mean_force+0.20*equilibrium_error)
        details.append({"id":case["id"],"energy_error":mean_energy,"force_error":mean_force,"equilibrium_error":equilibrium_error,"raw_metric":raw})
    return sum(item["raw_metric"] for item in details)/len(details),{"cases":details}


def main():
    logs=Path(os.environ.get("VERIFIER_LOG_ROOT","/logs/verifier"));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get("TASK_TESTS_ROOT","/tests"))
    output=Path(os.environ.get("TASK_ANSWER_PATH","/app/output/answer.json"))
    metric=json.loads((tests/"metric.json").read_text(encoding="utf-8"))
    try:answer=json.loads(output.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{"reason":"没有有效 JSON 产物"}
    else:raw,details=evaluate(answer)
    status="invalid" if raw is None else "completed"
    details.update(raw_metric=raw,score=quality_score(metric,raw,status),status=status)
    (logs/"metrics.json").write_text(json.dumps(details,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (logs/"reward.txt").write_text(str(details["score"])+"\n",encoding="utf-8")


if __name__=="__main__":main()
