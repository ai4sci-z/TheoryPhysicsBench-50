"""课程统一质量分：简单基线0、专家参考1，逐次换算后取平均。"""
import math

VALID_FAILURES = {"invalid", "agent_error", "timeout"}


def finite_number(value, name):
    if type(value) not in (int, float):
        raise ValueError(f"{name}须为有限数值")
    try:
        result = float(value)
    except OverflowError as exc:
        raise ValueError(f"{name}须为有限数值") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name}须为有限数值")
    return result


def validate_metric(metric):
    if metric.get("kind") == "binary":
        baseline = finite_number(metric.get("baseline"), "baseline")
        reference = finite_number(metric.get("reference"), "reference")
        if baseline != 0 or reference != 1:
            raise ValueError("二元题须实测简单基线0、参考解1，否则不构成有效的参考提升")
        return
    if metric.get("kind") != "continuous":
        raise ValueError("kind须为binary或continuous")
    direction = metric.get("direction")
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction须为maximize或minimize")
    baseline = finite_number(metric.get("baseline"), "baseline")
    reference = finite_number(metric.get("reference"), "reference")
    tolerance = finite_number(metric.get("tolerance"), "tolerance")
    if tolerance < 0:
        raise ValueError("原始指标容差不能为负")
    improvement = reference - baseline if direction == "maximize" else baseline - reference
    if not math.isfinite(improvement) or improvement <= tolerance:
        raise ValueError("参考解相对基线的改善须超过原始指标容差；请先核查设置")


def quality_score(metric, raw_metric, status="completed"):
    validate_metric(metric)
    if status in VALID_FAILURES:
        return 0.0
    if status != "completed":
        raise ValueError("基础设施或评分器故障不能填0；请先处理并补跑")
    value = finite_number(raw_metric, "raw_metric")
    if metric["kind"] == "binary":
        if value not in {0.0, 1.0}:
            raise ValueError("二元任务的实测结果须为0或1")
        return value
    baseline = float(metric["baseline"])
    reference = float(metric["reference"])
    fraction = (value - baseline) / (reference - baseline)
    return max(0.0, min(1.0, fraction))
