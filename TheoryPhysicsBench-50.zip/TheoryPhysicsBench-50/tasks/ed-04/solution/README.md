# ed-04 参考方法与独立核验

来源是 Jackson §14.3，原PDF765-768页（书235-238），式(14.35)-(14.46)。式(14.37)将观测通量乘 \(dt/dt'=1-\boldsymbol\beta\cdot\mathbf n\)，得到源时间功率；直线加速式(14.39)与横向加速式(14.44)均可由通式恢复。原书式(14.43)、(14.46)分别给出平行、垂直极限的总功率。题包采用 \(\dot{\boldsymbol\beta}\) 约定，功率单位为 \(e^2|\dot{\boldsymbol\beta}|^2/c\)。

先绕方位角解析积分。若 \(\mu=\cos\theta\)，\(c=\cos\chi,s=\sin\chi,\delta=1-\beta^2\)，则
\[
g(\mu)=\frac{c^2(1-\mu^2)+s^2[(1-\beta\mu)^2-\delta(1-\mu^2)/2]}{(1-\beta\mu)^5}.
\]
这里总无量纲功率为 \(\frac12\int_{-1}^1g(\mu)d\mu\)。参考程序用像差坐标
\[
t=\frac{\mu-\beta}{1-\beta\mu},\qquad \mu=\frac{t+\beta}{1+\beta t},\qquad
g(\mu)d\mu=\delta^{-2}\left[\frac{c^2}{\delta}(1-t^2)+\frac{s^2}{2}(1+t^2)\right](1+\beta t)dt.
\]
原来集中在 \(\mu=1\) 附近的窄峰化成 \([-1,1]\) 上的三次多项式。设 \(A=c^2/\delta,B=s^2/2\)，则原函数为
\[
F(t)=A\left[t-\frac{t^3}{3}+\beta\left(\frac{t^2}{2}-\frac{t^4}{4}\right)\right]
+B\left[t+\frac{t^3}{3}+\beta\left(\frac{t^2}{2}+\frac{t^4}{4}\right)\right].
\]
以 \([F(1)-F(t)]/[F(1)-F(-1)]\) 定义前向锥累计分布，用括根法求50%、90%分位点。用稳定的半角式
\[
\theta=2\arctan\sqrt{\frac{(1-\beta)(1-t)}{(1+\beta)(1+t)}}
\]
恢复锥角，避免 \(\arccos\mu\) 在前向的小角消减。\(1/\gamma\) 锥也用半角关系反变换后计算。总功率恢复李纳公式 \(\frac23(\gamma^6c^2+\gamma^4s^2)\)，动量矩可积分得 \(\langle\mu\rangle=\beta\)。

简单基线用64节点Gauss-Legendre直接对角度离散，保留正确源时间密度但不做尖峰坐标变换；对于 \(\gamma\sim10^3\) 会低估前向峰。独立真值不采用参考程序的像差多项式，而令 \(y=1-\beta\mu\)，将密度写成有理幂函数并以65位 mpmath 计算；再与原始θ变量的直接积分、李纳公式及动量矩交叉核对，未导入参考实现。所有输入公开，私有答案仅用于 verifier。
