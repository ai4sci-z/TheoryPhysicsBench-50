"""Smooth aberration coordinate eliminates the ultra-relativistic endpoint peak."""
import math
from scipy.optimize import brentq


def solve_case(case):
    b=case['beta'];delta=(1-b)*(1+b);c=math.cos(case['chi']);s=math.sin(case['chi'])
    a=c*c/delta;d=s*s/2
    def primitive(t):return a*(t-t**3/3+b*(t*t/2-t**4/4))+d*(t+t**3/3+b*(t*t/2+t**4/4))
    total=primitive(1)-primitive(-1)
    def cdf(t):return (primitive(1)-primitive(t))/total
    def angle(t):
        return 2*math.atan(math.sqrt((1-b)*(1-t)/((1+b)*(1+t))))
    angles={f'theta{int(100*fraction)}':angle(brentq(lambda t:cdf(t)-fraction,-1,1,xtol=1e-14)) for fraction in (.5,.9)}
    gamma=1/math.sqrt(delta);ratio=math.tan(1/(2*gamma))**2;aberration=(1-b)/(1+b)
    t=(aberration-ratio)/(aberration+ratio)
    return {'id':case['id'],'power':total/(2*delta**2),**angles,'cone_fraction':max(0.,min(1.,cdf(t))),'mean_cosine':b}
