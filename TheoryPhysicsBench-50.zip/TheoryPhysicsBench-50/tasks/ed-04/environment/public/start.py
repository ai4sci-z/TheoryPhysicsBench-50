"""Fixed 64-node angular quadrature, using physically correct source-time density."""
import argparse
import json
import math
from pathlib import Path
import numpy as np


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',type=Path,default=Path('/app/data'));parser.add_argument('--output',type=Path,default=Path('/app/output/answer.json'));args=parser.parse_args()
    model=json.loads((args.data_root/'model.json').read_text(encoding='utf-8'));mu,weights=np.polynomial.legendre.leggauss(64);cases=[]
    for case in model['cases']:
        b=case['beta'];c,s=math.cos(case['chi']),math.sin(case['chi']);d=1-b*mu
        numerator=c*c*(1-mu*mu)+s*s*(d*d-(1-b*b)*(1-mu*mu)/2)
        mass=weights*numerator/d**5;total=mass.sum()
        cumulative=np.cumsum(mass[::-1])/total;reverse=mu[::-1]
        angles={f'theta{int(100*f)}':math.acos(float(np.interp(f,cumulative,reverse))) for f in (.5,.9)}
        gamma=1/math.sqrt((1-b)*(1+b))
        cases.append({'id':case['id'],'power':float(total/2),**angles,'cone_fraction':float(mass[mu>=math.cos(1/gamma)].sum()/total),'mean_cosine':float(np.dot(mass,mu)/total)})
    answer={'cases':cases,'method':'fixed 64-node Gauss-Legendre quadrature and discrete angular CDF'}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(answer,ensure_ascii=False))


if __name__=='__main__':main()
