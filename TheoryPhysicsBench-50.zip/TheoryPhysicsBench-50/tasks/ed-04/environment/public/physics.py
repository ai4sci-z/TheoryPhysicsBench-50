"""Public source-time radiation density and strict output validation."""
import json
import math
from pathlib import Path
import numpy as np


def load_model(root='/app/data'):
    return json.loads((Path(root)/'model.json').read_text(encoding='utf-8'))


def azimuth_average(case,mu):
    b=case['beta'];s=math.sin(case['chi']);c=math.cos(case['chi']);mu=np.asarray(mu)
    d=1-b*mu
    numerator=c*c*(1-mu*mu)+s*s*(d*d-(1-b*b)*(1-mu*mu)/2)
    return numerator/d**5


def finite(value):
    try:return type(value) in (int,float) and math.isfinite(value)
    except OverflowError:return False


def validate_answer(answer,model):
    if not isinstance(answer,dict) or not isinstance(answer.get('cases'),list):return None,'须提交cases数组'
    ids={c['id'] for c in model['cases']}
    if len(answer['cases'])!=len(ids):return None,'每个公开工况须恰好一项'
    mapped={}
    for case in answer['cases']:
        if not isinstance(case,dict) or type(case.get('id')) is not str or case['id'] not in ids or case['id'] in mapped:return None,'未知或重复工况id'
        for key in ('power','theta50','theta90','cone_fraction','mean_cosine'):
            if not finite(case.get(key)):return None,f'{key}须为有限实数'
        if case['power']<=0:return None,'power须为正'
        if not 0<case['theta50']<=case['theta90']<math.pi:return None,'角度须满足0<theta50<=theta90<pi'
        if not 0<=case['cone_fraction']<=1 or not -1<=case['mean_cosine']<=1:return None,'比例或余弦超出范围'
        mapped[case['id']]=case
    return mapped,None
