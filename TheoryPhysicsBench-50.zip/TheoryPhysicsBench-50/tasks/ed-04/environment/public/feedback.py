import argparse
import json
import math
from pathlib import Path
from physics import load_model,validate_answer


def main():
    parser=argparse.ArgumentParser();parser.add_argument('answer',type=Path);args=parser.parse_args()
    try:answer=json.loads(args.answer.read_text(encoding='utf-8'))
    except (OSError,UnicodeError,json.JSONDecodeError):print(json.dumps({'valid':False,'reason':'没有有效JSON'},ensure_ascii=False));return
    model=load_model(Path(__file__).parent);mapped,reason=validate_answer(answer,model)
    if reason:print(json.dumps({'valid':False,'reason':reason},ensure_ascii=False));return
    details=[]
    for case in model['cases']:
        b=case['beta'];g=1/math.sqrt((1-b)*(1+b));chi=case['chi']
        expected=2/3*(g**6*math.cos(chi)**2+g**4*math.sin(chi)**2)
        details.append({'id':case['id'],'lienard_total_relative_residual':(mapped[case['id']]['power']-expected)/expected,'radiation_momentum_residual':mapped[case['id']]['mean_cosine']-b})
    print(json.dumps({'valid':True,'cases':details,'note':'总功率和动量守恒残差不能证明前向能量锥已正确解析'},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
