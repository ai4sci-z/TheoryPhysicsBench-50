# ed-04：相对论性加速电荷的源时间辐射束射

Jackson 第14章给出远区辐射能流。速度沿 +z，\(\beta=v/c\)，加速度与速度夹角为公开的 \(\chi\)，并令 \(|\dot{\boldsymbol\beta}|=1\) 作为单位。题目要求使用**电荷自身的源时间** (t') 定义每立体角功率：

\[
\frac{dP(t')}{d\Omega}=\frac{e^2}{4\pi c}
\frac{|\mathbf n\times[(\mathbf n-\boldsymbol\beta)\times\dot{\boldsymbol\beta}]|^2}{(1-\mathbf n\cdot\boldsymbol\beta)^5}.
\]

`dot(beta)` 是速度除以光速后的时间导数，而非有量纲加速度 \(\dot{\mathbf v}\)。提交总功率 `power` 以 \(e^2|\dot{\boldsymbol\beta}|^2/c\) 为单位，另外提交包含总功率50%和90%的最小前向锥半角 `theta50`/`theta90`、\(\theta<1/\gamma\) 的能量比例 `cone_fraction` 和归一化辐射动量 \(\langle\cos\theta\rangle\)。角度以 +z 为极轴，使用弧度，\(\gamma=(1-\beta^2)^{-1/2}\)。

源时间是迟滞电荷的运动时间 \(t'\)，观测时间为 \(t\)，有 \(dt/dt'=1-\mathbf n\cdot\boldsymbol\beta\)。观测通量的六次分母乘这个 Jacobian 后，才得到上述五次分母的源时间功率。所有锥比例和动量矩都对这一个源时间角分布积分。

模型文件给出七个从非相对论到超相对论、包含平行和横向加速度的工况。公开 `physics.py` 只提供绕方位角平均后的密度和格式校验；`feedback.py` 仅检查李纳总功率及动量方向，不证明尖峰积分正确。结果写 `/app/output/answer.json`，每个工况一次：

```json
{"cases":[{"id":"radiation-01","power":1.0,"theta50":1.0,"theta90":2.0,"cone_fraction":0.5,"mean_cosine":0.0}],"method":"..."}
```

必须恰好覆盖 `model.json` 中七个不同的 `id`，不得遗漏、重复或新增工况。`method` 为非空字符串，说明求积和窄峰处理。角度必须满足 `0 < theta50 <= theta90 < pi`，比例在[0,1]，余弦在[-1,1]，所有数字有限且不得用布尔值代替数值。

令 \(D=dP/d\Omega\)，各提交量定义为
\[
\texttt{power}=\frac{c}{e^2|\dot{\boldsymbol\beta}|^2}\int D\,d\Omega,\qquad
\int_{0}^{\theta_f}\!\int_0^{2\pi}D\sin\theta\,d\phi\,d\theta=f\int D\,d\Omega,
\]
\[
\texttt{cone\_fraction}=\frac{\int_{0}^{1/\gamma}\!\int_0^{2\pi}D\sin\theta\,d\phi\,d\theta}{\int D\,d\Omega},\qquad
\texttt{mean\_cosine}=\frac{\int\cos\theta\,D\,d\Omega}{\int D\,d\Omega}.
\]

公开起点和反馈命令：

```bash
python /app/data/start.py --data-root /app/data --output /app/output/answer.json
python /app/data/feedback.py /app/output/answer.json
```

起点采用64节点 Gauss-Legendre 直接对角度求积。高速度峰区需要变换积分变量或自适应积分。反馈返回格式有效性、李纳总功率和动量残差；它不提供私有分位角或锥能量答案。

评分使用七工况平均误差（百分点），越低越好。对 `power`、`theta50`、`theta90`，令 \(e_z=\min(1,|z-z_*|/|z_*|)\)；令 \(e_C=|C-C_*|\)、\(e_M=|M-M_*|/2\)，则
\[
E=\frac{100}{7}\sum_i(0.25e_P+0.20e_{50}+0.20e_{90}+0.25e_C+0.10e_M).
\]
`/app/data/metric.json` 给出固定基线端点 \(b\)、参考端点 \(h\) 和用于验证端点改善的容差 \(t\)。课程原版连续质量评分为 \(\operatorname{clip}((b-E)/(b-h),0,1)\)；非法产物得0分。参考代码和私有真值不在 Agent 环境中。

资源：4 CPU、4 GiB、0 GPU，Agent 720 秒、verifier 120 秒。无需联网、权重或外部数据。
