import json
import os
from pathlib import Path
import sys
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get('TASK_DATA_ROOT','/app/data'));private=Path(private_root or os.environ.get('TASK_PRIVATE_ROOT','/tests/private'));sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    model=load_model(data);mapped,reason=validate_answer(answer,model)
    if reason:return None,{'reason':reason}
    truth=json.loads((private/'truth.json').read_text(encoding='utf-8'));details=[];cfg=model['scoring']
    for expected in truth['cases']:
        actual=mapped[expected['id']]
        errors={key:min(1.,abs(actual[key]-expected[key])/abs(expected[key])) for key in ('power','theta50','theta90')}
        errors['cone']=abs(actual['cone_fraction']-expected['cone_fraction'])
        errors['mean_cosine']=abs(actual['mean_cosine']-expected['mean_cosine'])/2
        raw=100*sum(cfg[key+'_weight']*value for key,value in errors.items())
        details.append({'id':expected['id'],'raw_metric':raw,'errors':errors})
    return sum(c['raw_metric'] for c in details)/len(details),{'cases':details}


def main():
    logs=Path(os.environ.get('VERIFIER_LOG_ROOT','/logs/verifier'));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get('TASK_TESTS_ROOT','/tests'));output=Path(os.environ.get('TASK_ANSWER_PATH','/app/output/answer.json'));metric=json.loads((tests/'metric.json').read_text(encoding='utf-8'))
    try:answer=json.loads(output.read_text(encoding='utf-8'))
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{'reason':'没有有效JSON产物'}
    else:raw,details=evaluate(answer)
    status='invalid' if raw is None else 'completed';score=quality_score(metric,raw,status);details.update(raw_metric=raw,score=score,status=status)
    (logs/'metrics.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(logs/'reward.txt').write_text(f'{score}\n',encoding='utf-8')


if __name__=='__main__':main()
