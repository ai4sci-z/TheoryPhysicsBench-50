import copy
import math


def make_cases(reference):
    names=('equivalent','wrong','wrong_power','cone_zero','isotropic_momentum','degrees','duplicate','boolean','nonfinite','reversed_quantiles')
    cases={name:copy.deepcopy(reference) for name in names}
    cases['equivalent']['cases'].reverse()
    for case in cases['wrong']['cases']:case.update(power=1,theta50=3.,theta90=3.1,cone_fraction=0,mean_cosine=-1)
    for case in cases['wrong_power']['cases']:case['power']*=2
    for case in cases['cone_zero']['cases']:case['cone_fraction']=0
    for case in cases['isotropic_momentum']['cases']:case['mean_cosine']=0
    for case in cases['degrees']['cases']:case['theta50']*=180/math.pi;case['theta90']*=180/math.pi
    cases['duplicate']['cases'][1]=copy.deepcopy(cases['duplicate']['cases'][0])
    cases['boolean']['cases'][0]['power']=True
    cases['nonfinite']['cases'][0]['power']=float('nan')
    cases['reversed_quantiles']['cases'][0]['theta50']=2.5;cases['reversed_quantiles']['cases'][0]['theta90']=1.5
    cases['malformed']={}
    return cases
