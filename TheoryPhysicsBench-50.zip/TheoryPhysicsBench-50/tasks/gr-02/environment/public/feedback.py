import argparse
import json
import math
from pathlib import Path
from physics import expansion_squared,load_model,validate_answer


def main():
    parser=argparse.ArgumentParser();parser.add_argument("answer",type=Path);args=parser.parse_args()
    model=load_model(Path(__file__).parent)
    try:answer=json.loads(args.answer.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):print(json.dumps({"valid":False,"reason":"没有有效 JSON"},ensure_ascii=False));return
    mapped,reason=validate_answer(answer,model);result={"valid":reason is None,"reason":reason}
    if reason is None:
        p=mapped["parameters"]
        result["closure_residual"]=model["omega_r"]+p["omega_m"]+p["omega_k"]+p["omega_lambda"]-1
        result["H_squared_residuals"]=[{"z":point["z"],"relative_residual":(p["H0"]**2*expansion_squared(point["z"],p,model["omega_r"])-point["H_km_s_Mpc"]**2)/point["H_km_s_Mpc"]**2} for point in model["H_observations"]]
        result["distance_duality_residuals"]=[{"z":z,"relative_residual":(entry["luminosity_geometric_mpc"]-(1+z)**2*entry["angular_mpc"])/max(entry["luminosity_geometric_mpc"],1e-30)} for z,entry in mapped["predictions"].items()]
        result["horizon_labels"]={name:mapped["future"][name]["event_horizon_exists"] for name in ("A","B")}
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=="__main__":main()
