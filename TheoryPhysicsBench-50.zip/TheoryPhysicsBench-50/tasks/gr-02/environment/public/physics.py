"""Public FLRW model, submission validation and observation residuals."""
import json
import math
from pathlib import Path

PARAMETERS=("H0","omega_m","omega_k","omega_lambda","epsilon")
HISTORY=("age_gyr","particle_radial_mpc","early_age_myr","z_da_max","da_max_mpc","z_acceleration_transition")
DISTANCES=("radial_comoving_mpc","angular_mpc","luminosity_geometric_mpc","lookback_gyr")


def finite(value):
    try:return type(value) in (int,float) and math.isfinite(value)
    except OverflowError:return False


def load_model(root="/app/data"):
    return json.loads((Path(root)/"model.json").read_text(encoding="utf-8"))


def expansion_squared(z,p,omega_r):
    x=1+z
    return omega_r*x**4+p["omega_m"]*x**3+p["omega_k"]*x**2+p["omega_lambda"]


def transverse(chi,omega_k):
    if abs(omega_k)<1e-12:return chi
    root=math.sqrt(abs(omega_k));arg=root*chi
    return (math.sinh(arg) if omega_k>0 else math.sin(arg))/root


def validate_answer(answer,model):
    if not isinstance(answer,dict):return None,"根对象须为 JSON 对象"
    p=answer.get("parameters");history=answer.get("history")
    if not isinstance(p,dict) or not all(finite(p.get(key)) for key in PARAMETERS):return None,"parameters 须含全部有限实数参数"
    if p["H0"]<=0 or p["omega_m"]<=0:return None,"H0 和 omega_m 须为正数"
    if not isinstance(history,dict) or not all(finite(history.get(key)) and history[key]>=0 for key in HISTORY):return None,"history 须含全部非负有限实数"
    entries=answer.get("predictions");redshifts=model["prediction_redshifts"]
    if not isinstance(entries,list) or len(entries)!=len(redshifts):return None,"predictions 须覆盖全部公开红移"
    seen=set();mapped={}
    for entry in entries:
        if not isinstance(entry,dict) or not finite(entry.get("z")) or entry["z"] not in redshifts or entry["z"] in seen:return None,"预测红移未知或重复"
        if not all(finite(entry.get(key)) and entry[key]>=0 for key in DISTANCES):return None,"距离与回溯时间须为非负有限实数"
        seen.add(entry["z"]);mapped[entry["z"]]=entry
    future=answer.get("future")
    if not isinstance(future,dict) or type(future.get("identifiable_from_past")) is not bool:return None,"future.identifiable_from_past 须为布尔值"
    for name in ("A","B"):
        part=future.get(name)
        if not isinstance(part,dict) or type(part.get("event_horizon_exists")) is not bool:return None,"A/B 须含布尔 event_horizon_exists"
        radius=part.get("event_radial_mpc","missing")
        if part["event_horizon_exists"]:
            if not finite(radius) or radius<=0:return None,"存在视界时 event_radial_mpc 须为正有限实数"
        elif radius is not None:return None,"无事件视界时 event_radial_mpc 须显式填 null"
    return {"parameters":p,"history":history,"predictions":mapped,"future":future},None
