# 非平直 FLRW 宇宙的联合反演、距离和视界

## 研究问题

膨胀率测量和标准烛光测量约束宇宙几何的方式不同。曲率会改变横向距离，光子衰减则会改变由通量推算的光度距离。即使过去的膨胀历史已经确定，也不能在没有未来物态假设时断言事件视界存在。

本题给出一套**确定性模拟观测**，并非真实天文观测。它们由含辐射、尘埃、空间曲率和宇宙学常数的 FLRW 模型生成，无随机噪声，观测值保留 13 位有效数字。要求按下述固定拟合目标重建宇宙参数及光子衰减，计算一组未参与拟合的距离和历史量，并比较两个共享相同过去的未来模型。所有小问共同属于这一套宇宙重建任务。

取当今尺度因子 \(a_0=1\)，红移 \(1+z=a^{-1}\)，哈勃参数 \(H=\dot a/a\)。对于全部过去历史 \(0<a\le1\)，模型为

\[
E(z)^2\equiv\frac{H(z)^2}{H_0^2}
=\Omega_r(1+z)^4+\Omega_m(1+z)^3
+\Omega_k(1+z)^2+\Omega_\Lambda,
\qquad
\Omega_r+\Omega_m+\Omega_k+\Omega_\Lambda=1.
\]

\(\Omega_r\) 是固定已知的当今辐射密度参数；其余参数待推断。约定 \(\Omega_k>0\) 表示负空间曲率、开放几何，和常见的离散曲率符号 \(k=-1\) 对应。这里的 \(\Omega_k\) 不是离散的 \(k\)。

## 公开材料与单位

`/app/data/model.json` 包含：

- `omega_r`：固定当今辐射密度参数；`parameter_bounds`：拟合参数的公开闭区间；\(\Omega_\Lambda\) 由闭合条件计算，并要求为正。
- `H_observations`：每项 `z` 与 `H_km_s_Mpc`，后者单位为 km·s⁻¹·Mpc⁻¹。
- `luminosity_observations`：每项 `z` 与 `luminosity_observed_mpc`，是由受衰减通量推算的光度距离，单位 Mpc。
- `prediction_redshifts`：需要给出预测的四个红移，不是额外观测值。
- `early_age_redshift`、`angular_peak_interval`、`transition_interval`：早期年龄的红移和两个根搜索区间。
- `c_km_s`、`mpc_km`、`seconds_per_gyr`：本题固定使用的单位转换值。1 Gyr=1000 Myr。

其他公开文件：

- `/app/data/physics.py`：读取模型、格式校验、膨胀率及曲率映射；没有参考参数和最终答案。
- `/app/data/feedback.py`：检查格式、密度闭合、膨胀率残差和预测距离的对偶关系。
- `/app/data/metric.json`：预先固定的评分指标和实测端点。
- Python 3.12、NumPy 2.1.3、SciPy 1.14.1、mpmath 1.3.0；0 GPU。

最小读取示例：

```python
import sys
sys.path.insert(0, "/app/data")
from physics import load_model
model = load_model()
print(model["H_observations"][0])
```

## 固定推断目标

为消除“拟合 H、H²、相对误差等得到略有不同参数”的歧义，本题规定顺序拟合，**不把预测值或生成数据的私有参数当作拟合信息**。

1. 仅用全部 `H_observations`，在公开参数边界和闭合条件内，最小化

\[
J_H=\sum_i\left[H_0^2 E(z_i)^2-H_{i,\mathrm{obs}}^2\right]^2.
\]

这是无权的 \(H^2\) 残差目标，不是 \(H\) 的无权最小二乘。数据的舍入允许残差不为零。所有后续计算使用这一目标在已舍入公开数据上的最优参数。最优点位于所给边界内部。

2. 固定第一步的几何与膨胀参数。定义光子光学深度 \(\tau(z)=\epsilon z\)，并规定

\[
D_{L,\mathrm{obs}}(z)=D_{L,\mathrm{geom}}(z)e^{\epsilon z/2}.
\]

在给定 \(\epsilon\) 边界内最小化

\[
J_\tau=\sum_j\left[
2\log\frac{D_{L,j,\mathrm{obs}}}{D_{L,\mathrm{geom}}(z_j)}-\epsilon z_j
\right]^2.
\]

\(\log\) 是自然对数。衰减令观测通量减小，因而按透明模型反推的光度距离增大；注意指数的方向与因子 2。

## 距离与历史量

以 \(D_{H0}=c/H_0\) 表示当今哈勃长度（不要和粒子视界半径混淆），定义

\[
\chi(z)=\int_0^z\frac{dz'}{E(z')},\qquad
S_k(\chi)=
\begin{cases}
\sinh(\sqrt{\Omega_k}\chi)/\sqrt{\Omega_k},&\Omega_k>0,\\
\chi,&\Omega_k=0,\\
\sin(\sqrt{-\Omega_k}\chi)/\sqrt{-\Omega_k},&\Omega_k<0.
\end{cases}
\]

每个预测红移需要：

\[
D_C=D_{H0}\chi,\quad D_M=D_{H0}S_k(\chi),\quad
D_A=\frac{D_M}{1+z},\quad
D_{L,\mathrm{geom}}=(1+z)D_M,
\]

以及从该红移到当今的回溯时间

\[
t_{\mathrm{lookback}}(z)=H_0^{-1}\int_0^z\frac{dz'}{(1+z')E(z')}.
\]

输出 \(D_C,D_A,D_{L,\mathrm{geom}}\) 和回溯时间；无需输出中间量 \(D_M\)。光度距离的预测字段是**未加衰减的几何距离**，不是观测通量距离。

历史量包括：

- `age_gyr`：当今宇宙年龄，积分到大爆炸极限，而非某个任意高红移截断。
- `particle_radial_mpc`：当今粒子视界的径向固有距离 \(c\int_0^{t_0}dt/a(t)\)。由于 \(a_0=1\)，它也等于当今径向共动距离。不要对这个积分再作 \(S_k\) 映射。
- `early_age_myr`：`early_age_redshift` 时刻自大爆炸起的年龄，单位 Myr；不是到当今的回溯时间。
- `z_da_max` 和 `da_max_mpc`：在公开区间内几何角径距离 \(D_A\) 的最大值位置和数值。此处峰值唯一。
- `z_acceleration_transition`：在公开区间内 \(\ddot a=0\) 的红移，需包含辐射和尘埃的贡献；此处根唯一。

辐射项虽然在低红移较小，但不能从完整过去历史中删除。

## 未来延拓与可辨识性

两个模型在 \(a\le1\) 与上述已拟合宇宙完全相同。它们在 \(a=1\) 具有相同 \(a\) 和 \(H\)，仅未来动力学不同：

- **A**：原有辐射、尘埃和正宇宙学常数均继续按原物态演化，\(E_A(a)^2=\Omega_r a^{-4}+\Omega_m a^{-3}+\Omega_k a^{-2}+\Omega_\Lambda\)。
- **B**：在当今把全部非曲率能量瞬时转换为尘埃，保留同一空间曲率。因此对于 \(a>1\)，\(E_B(a)^2=(1-\Omega_k)a^{-3}+\Omega_k a^{-2}\)。这是本题给定的理想化延拓，不是由观测推出的宇宙真实未来。物态转换可导致加速度变化，但不改变边界的总能量和 \(H\)。

对两者分别判断当今观者是否存在未来事件视界。若存在，报告当今径向事件视界距离

\[
D_{\mathrm{event}}=\frac{c}{H_0}\int_1^\infty\frac{da}{a^2 E_{\mathrm{future}}(a)}.
\]

若不存在填 `null`，不要将数值积分的有限截断误认为收敛。另回答 `identifiable_from_past`：**只凭本题全部过去观测，能否在 A 和 B 中唯一选出未来，进而唯一断言事件视界结论？**该字段是可辨识性问题，不是在给定 A 后计算条件预测。

## 探索反馈

将尝试写成最终格式后执行：

```bash
python /app/data/feedback.py /app/output/trial.json
```

它返回密度闭合、观测膨胀率相对残差和距离对偶残差，不给完整真值或最终分数。反馈次数不限。可以用变量变换、线性/非线性拟合、数值积分、渐近分析等任何等价方式；不要求使用参考解算法。

## 最终产物

提交 `/app/output/answer.json`，结构为：

```json
{
  "parameters": {"H0":70,"omega_m":0.3,"omega_k":0.01,"omega_lambda":0.68991,"epsilon":0.02},
  "predictions": [
    {"z":0.3,"radial_comoving_mpc":1000,"angular_mpc":800,"luminosity_geometric_mpc":1352,"lookback_gyr":3}
  ],
  "history": {
    "age_gyr":13,"particle_radial_mpc":14000,"early_age_myr":0.4,
    "z_da_max":1.6,"da_max_mpc":1700,"z_acceleration_transition":0.6
  },
  "future": {
    "A":{"event_horizon_exists":true,"event_radial_mpc":5000},
    "B":{"event_horizon_exists":false,"event_radial_mpc":null},
    "identifiable_from_past":false
  }
}
```

示例仅说明字段，不是本题答案。真实 `predictions` 必须包含全部四个公开红移，顺序不限。参数均为有限实数，\(H_0,\Omega_m>0\)；历史和预测字段为非负有限实数。是否有视界及可辨识性必须是 JSON 布尔值；有视界时距离为正有限实数，无视界时显式填 `null`。可附加字符串 `method` 或文字说明，不参与评分。格式允许偏离物理边界的有限参数，物理数值错误按实际指标处罚，不以隐藏限制拒绝。

## 固定评分

验证器对照独立高精度重算结果。令 \(\widehat y\) 表示参考真值，所有分项均限制在 \([0,1]\)。

- 参数分项：\(H_0,\Omega_m,\Omega_k,\Omega_\Lambda,\epsilon\) 的绝对误差分别除以 \(10,0.2,0.1,0.2,0.1\)，截到 1 后平均。
- 距离分项：对四个预测红移的四个字段，计算 \(\min(1,|y-\widehat y|/(0.05|\widehat y|))\) 后平均。
- 历史分项：对六个历史字段使用同样的 5% 相对误差尺度并平均。
- 未来分项：A 视界有无错误占 0.3，A 距离的 5% 尺度误差占 0.4，B 视界有无错误占 0.2，可辨识性错误占 0.1。A 分类错误时其距离误差同时记 1；B 无视界时没有有限距离值要拟合。

总原始指标为 \(100(0.25e_{\rm param}+0.30e_{\rm distance}+0.25e_{\rm history}+0.20e_{\rm future})\)，单位百分点，越低越好。权重和尺度预先固定，不根据正式模型作答调整。

简单基线采用常见的平直、透明 FLRW 假设：固定 \(\Omega_k=\epsilon=0\)，保留已知辐射，用同一 \(H^2\) 目标拟合其余参数，再精确计算该近似模型下的距离和历史。完整参考解识别曲率和衰减，并使用相同数据、资源和评分。基线并非故意用数值积分错误制造差距。

## 时间与资源

Agent 720 秒，verifier 120 秒，4 CPU、4 GB 内存、4 GB 磁盘、0 GPU。仅需本地科学计算，无模型权重或服务器资源需求。
