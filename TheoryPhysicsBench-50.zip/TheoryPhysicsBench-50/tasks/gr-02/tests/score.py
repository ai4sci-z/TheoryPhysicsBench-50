import json
import os
import sys
from pathlib import Path
from quality_score import quality_score


def relative(actual,expected):return min(1.0,abs(actual-expected)/max(abs(expected)*0.05,1e-20))


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get("TASK_DATA_ROOT","/app/data"));private=Path(private_root or os.environ.get("TASK_PRIVATE_ROOT","/tests/private"))
    sys.path.insert(0,str(data))
    from physics import DISTANCES,HISTORY,load_model,validate_answer
    actual,reason=validate_answer(answer,load_model(data))
    if reason:return None,{"reason":reason}
    expected=json.loads((private/"truth.json").read_text(encoding="utf-8"))
    scales={"H0":10,"omega_m":0.2,"omega_k":0.1,"omega_lambda":0.2,"epsilon":0.1}
    parameters={key:min(1.0,abs(actual["parameters"][key]-expected["parameters"][key])/scale) for key,scale in scales.items()}
    distances=[{"z":point["z"],**{key:relative(actual["predictions"][point["z"]][key],point[key]) for key in DISTANCES}} for point in expected["predictions"]]
    history={key:relative(actual["history"][key],expected["history"][key]) for key in HISTORY}
    future=actual["future"];target=expected["future"]
    a_class=float(future["A"]["event_horizon_exists"]!=target["A"]["event_horizon_exists"])
    b_class=float(future["B"]["event_horizon_exists"]!=target["B"]["event_horizon_exists"])
    a_radius=1.0 if a_class else relative(future["A"]["event_radial_mpc"],target["A"]["event_radial_mpc"])
    identifiability=float(future["identifiable_from_past"]!=target["identifiable_from_past"])
    future_error=0.3*a_class+0.4*a_radius+0.2*b_class+0.1*identifiability
    summary={"parameters":sum(parameters.values())/len(parameters),"distances":sum(point[key] for point in distances for key in DISTANCES)/(len(distances)*len(DISTANCES)),"history":sum(history.values())/len(history),"future":future_error}
    raw=100*(0.25*summary["parameters"]+0.30*summary["distances"]+0.25*summary["history"]+0.20*summary["future"])
    return raw,{"parameter_errors":parameters,"prediction_errors":distances,"history_errors":history,"future_errors":{"A_classification":a_class,"A_radius":a_radius,"B_classification":b_class,"identifiability":identifiability},"group_errors":summary}


def main():
    logs=Path(os.environ.get("VERIFIER_LOG_ROOT","/logs/verifier"));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get("TASK_TESTS_ROOT","/tests"));output=Path(os.environ.get("TASK_ANSWER_PATH","/app/output/answer.json"))
    metric=json.loads((tests/"metric.json").read_text(encoding="utf-8"))
    try:answer=json.loads(output.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{"reason":"没有有效 JSON 产物"}
    else:raw,details=evaluate(answer)
    status="invalid" if raw is None else "completed";details.update(raw_metric=raw,score=quality_score(metric,raw,status),status=status)
    (logs/"metrics.json").write_text(json.dumps(details,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");(logs/"reward.txt").write_text(str(details["score"])+"\n",encoding="utf-8")


if __name__=="__main__":main()
