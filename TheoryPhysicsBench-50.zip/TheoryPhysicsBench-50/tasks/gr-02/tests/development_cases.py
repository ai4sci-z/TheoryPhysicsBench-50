import copy


def make_cases(reference):
    equivalent=copy.deepcopy(reference);equivalent["predictions"].reverse()
    wrong=copy.deepcopy(reference)
    for prediction in wrong["predictions"]:
        for key in ("radial_comoving_mpc","angular_mpc","luminosity_geometric_mpc","lookback_gyr"):prediction[key]=0
    for key in wrong["history"]:wrong["history"][key]=0
    wrong["future"]={"A":{"event_horizon_exists":False,"event_radial_mpc":None},"B":{"event_horizon_exists":True,"event_radial_mpc":1},"identifiable_from_past":True}
    duality=copy.deepcopy(reference)
    for prediction in duality["predictions"]:prediction["luminosity_geometric_mpc"]=prediction["angular_mpc"]
    transverse_horizon=copy.deepcopy(reference);transverse_horizon["history"]["particle_radial_mpc"]*=1.25
    future=copy.deepcopy(reference);future["future"]["B"]={"event_horizon_exists":True,"event_radial_mpc":reference["future"]["A"]["event_radial_mpc"]}
    identified=copy.deepcopy(reference);identified["future"]["identifiable_from_past"]=True
    opacity=copy.deepcopy(reference);opacity["parameters"]["epsilon"]=0
    duplicate=copy.deepcopy(reference);duplicate["predictions"][0]["z"]=duplicate["predictions"][1]["z"]
    boolean=copy.deepcopy(reference);boolean["history"]["age_gyr"]=True
    nan=copy.deepcopy(reference);nan["parameters"]["omega_m"]=float("nan")
    return {"equivalent":equivalent,"wrong":wrong,"wrong_distance_duality":duality,"transverse_as_radial_horizon":transverse_horizon,"future_B_false_horizon":future,"future_identifiability_error":identified,"zero_opacity":opacity,"malformed":{},"duplicate_redshift":duplicate,"boolean_number":boolean,"nonfinite":nan}
