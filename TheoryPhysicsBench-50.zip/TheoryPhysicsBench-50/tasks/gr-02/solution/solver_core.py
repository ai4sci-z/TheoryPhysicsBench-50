"""Recover a curved FLRW history and opacity from the public observations."""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq


def fit_parameters(model,flat=False):
    radiation=model["omega_r"];matrix=[];values=[]
    for point in model["H_observations"]:
        x=1+point["z"]
        row=[1+radiation*(x**4-1),x**3-1]
        if not flat:row.append(x*x-1)
        matrix.append(row);values.append(point["H_km_s_Mpc"]**2)
    matrix=np.array(matrix);values=np.array(values)
    scales=np.linalg.norm(matrix,axis=0)
    coefficients=np.linalg.lstsq(matrix/scales,values,rcond=None)[0]/scales
    h0=math.sqrt(coefficients[0]);matter=coefficients[1]/coefficients[0]
    curvature=0.0 if flat else coefficients[2]/coefficients[0]
    p={"H0":h0,"omega_m":matter,"omega_k":curvature,"omega_lambda":1-radiation-matter-curvature,"epsilon":0.0}
    if not flat:
        cosmology=Cosmology(model,p)
        points=model["luminosity_observations"]
        p["epsilon"]=sum(point["z"]*2*math.log(point["luminosity_observed_mpc"]/cosmology.distances(point["z"])["luminosity_geometric_mpc"]) for point in points)/sum(point["z"]**2 for point in points)
    return p


class Cosmology:
    def __init__(self,model,p):
        self.model=model;self.p=p;self.r=model["omega_r"]
        self.dh=model["c_km_s"]/p["H0"]
        self.th=model["mpc_km"]/p["H0"]/model["seconds_per_gyr"]
    def poly(self,a):return self.r+self.p["omega_m"]*a+self.p["omega_k"]*a*a+self.p["omega_lambda"]*a**4
    def expansion(self,z):
        a=1/(1+z)
        return math.sqrt(self.poly(a))/a**2
    def integrate(self,kind,left,right):
        points=[x for x in (self.r/self.p["omega_m"],0.001,0.01,0.1) if left<x<right]
        fn=(lambda a:a/math.sqrt(self.poly(a))) if kind=="time" else (lambda a:1/math.sqrt(self.poly(a)))
        return quad(fn,left,right,points=points,epsabs=2e-13,epsrel=2e-13,limit=200)[0]
    def transverse(self,chi):
        k=self.p["omega_k"]
        if abs(k)<1e-12:return chi
        root=math.sqrt(abs(k));angle=root*chi
        return (math.sinh(angle) if k>0 else math.sin(angle))/root
    def distances(self,z):
        a=1/(1+z);chi=self.integrate("conformal",a,1);dm=self.dh*self.transverse(chi)
        return {"z":z,"radial_comoving_mpc":self.dh*chi,"angular_mpc":dm/(1+z),"luminosity_geometric_mpc":dm*(1+z),"lookback_gyr":self.th*self.integrate("time",a,1)}
    def peak_residual(self,z):
        chi=self.integrate("conformal",1/(1+z),1);k=self.p["omega_k"]
        derivative=1.0 if abs(k)<1e-12 else math.cosh(math.sqrt(k)*chi) if k>0 else math.cos(math.sqrt(-k)*chi)
        return (1+z)*derivative/self.expansion(z)-self.transverse(chi)
    def answer(self):
        model,p=self.model,self.p
        peak=brentq(self.peak_residual,*model["angular_peak_interval"],xtol=2e-13)
        transition=brentq(lambda z:2*self.r*(1+z)**4+p["omega_m"]*(1+z)**3-2*p["omega_lambda"],*model["transition_interval"],xtol=2e-13)
        early=1/(1+model["early_age_redshift"])
        history={"age_gyr":self.th*self.integrate("time",0,1),"particle_radial_mpc":self.dh*self.integrate("conformal",0,1),"early_age_myr":1000*self.th*self.integrate("time",0,early),"z_da_max":peak,"da_max_mpc":self.distances(peak)["angular_mpc"],"z_acceleration_transition":transition}
        event=self.dh*quad(lambda x:1/math.sqrt(self.r*x**4+p["omega_m"]*x**3+p["omega_k"]*x*x+p["omega_lambda"]),0,1,epsabs=2e-13,epsrel=2e-13)[0]
        return {"parameters":p,"predictions":[self.distances(z) for z in model["prediction_redshifts"]],"history":history,"future":{"A":{"event_horizon_exists":True,"event_radial_mpc":event},"B":{"event_horizon_exists":False,"event_radial_mpc":None},"identifiable_from_past":False}}
