"""Conventional flat transparent model; exact integration inside that model."""
import argparse
import json
from pathlib import Path
from solver_core import Cosmology,fit_parameters


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--data-root",type=Path,default=Path("/app/data"));parser.add_argument("--output",type=Path,default=Path("/app/output/answer.json"));args=parser.parse_args()
    model=json.loads((args.data_root/"model.json").read_text(encoding="utf-8"))
    answer=Cosmology(model,fit_parameters(model,flat=True)).answer();answer["method"]="flat transparent FLRW least-squares baseline; exact integrals with fixed radiation"
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print(json.dumps(answer,ensure_ascii=False))


if __name__=="__main__":main()
