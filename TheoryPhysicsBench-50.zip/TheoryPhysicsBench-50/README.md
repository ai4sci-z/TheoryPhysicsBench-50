# TheoryPhysicsBench-50

用可执行计算与独立物理验证，检验智能体在理论物理问题中的建模、分支判断、近似选择、数值收敛和可核验预测能力。整套包含 **50 个独立 Harbor 0.24.0 任务包**；一道题内的多个工况只计一道题。

当前交付是题集的开发验证版。50题已有通过的 Docker Linux 数值校准记录；Harbor 参考解与空提交运行保存在 `runs/`，最终版本的适用证据以 `checks/benchmark-50-harbor-evidence.json` 的哈希核对为准。课程指定 Codex 每题三次的正式测评尚未运行，当前没有正式 `results.csv` 或模型难度结论。统一正式入口已实现并通过14项离线自检。

## 题集与阅读入口

| 学科 | 编号 | 题数 | 主要研究选择 |
|---|---|---:|---|
| 理论力学 | tm-01～05 | 5 | 局部观测反演、非线性轨道、刚体稳定性、分布摩擦 |
| 电动力学 | ed-01～05 | 5 | 多极截断、辐射角谱反演、完整模谱、相对论束射、散射收敛 |
| 统计物理 | sp-01～05 | 5 | 全局与亚稳分支、有限储库、离散谱、低温展开边界、液气共存 |
| 量子力学 | qm-01～05 | 5 | 近阈值束缚态、窄共振、Bloch谱、非对易驱动、非微扰谱 |
| 量子场论 | qft-01～25 | 25 | 环图与反项、解析延拓、规范与拓扑、振幅、格点与热场、强场产对 |
| 广义相对论 | gr-01～05 | 5 | 强场分支、宇宙学反演、稳定轨道、全局逃逸、初值约束 |

- [50题题目、端点和校准索引](checks/benchmark-50-index.md)
- [四页报告正文](报告.md)
- [设计、原始来源及适用范围](docs/design-and-provenance.md)
- [正式测评配置与命令](docs/formal-evaluation.md)
- [第三方与材料说明](NOTICE.md)

项目按用户与助教沟通过的单人、多题扩展安排制作。课程原件仍写10～20题、最多20题计分，原版工具保留不变；本项目的50题入口不会改写该计分规则。旧工作目录名 `TheoryPhysicsBench-30` 不影响题集名和50题清单。

## 环境

主机需要 Docker、Python 和 Harbor。静态工具使用 Python 3.11+ 的 `tomllib`；课程运行环境建议 Python 3.12+，Harbor 固定为0.24.0。可按课程推荐方式安装：

```bash
uv tool install --python 3.12 'harbor==0.24.0'
harbor --version
docker version
```

每题镜像从固定 digest 的 Python 3.12.13 slim-bookworm 构建，基础镜像为：

```text
mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
```

逐题 `environment/requirements.txt` 固定所需依赖；整套数值开发依赖为 NumPy2.1.3、SciPy1.14.1、mpmath1.3.0。可选本机开发环境见 `requirements-dev.txt`，实际任务计算使用题包镜像。首次构建需要下载镜像和Python包，作答材料不依赖教材原文件或外部私有服务。

每题上限4 CPU、4 GiB内存、4 GiB磁盘、0 GPU，Agent720秒、独立verifier120秒。50题登记时限之和42000秒（11小时40分），低于每轮43200秒；三轮登记上限126000秒（35小时）。初次环境构建单独记录。全部本地开发使用Mac与Docker Linux，不需要连接远程推理服务器。

## 先核对整套结构

在解压后的项目根目录执行：

```bash
python3 tools/check_benchmark50.py --require-calibrated
python3 tools/test_formal_benchmark50.py
```

`check_benchmark50.py` 逐题调用课程原版 `check_task()`，另核50题ID、配置、指标一致性、公开材料隔离与整轮时限。`--require-harbor` 检查开发Harbor记录；发布前还要核对版本证据，不能只看历史运行成功。

## 复现一道题

下面以 `tm-01` 为例。构建上下文只有 `environment/`，公开Agent镜像不含参考解或隐藏标签。参考解检查时由出题者单独挂载 `solution/`：

```bash
task_id=tm-01
docker build -t "theoryphysicsbench-$task_id:local" "tasks/$task_id/environment"
mkdir -p "tmp/$task_id-reference" "tmp/$task_id-baseline"
docker run --rm --cpus 4 --memory 4g --network none --user 0 \
  -v "$PWD/tasks/$task_id/solution:/solution:ro" \
  -v "$PWD/tmp/$task_id-reference:/app/output" \
  "theoryphysicsbench-$task_id:local" python3 /solution/solve.py
docker run --rm --cpus 4 --memory 4g --network none --user 0 \
  -v "$PWD/tasks/$task_id/solution:/solution:ro" \
  -v "$PWD/tmp/$task_id-baseline:/app/output" \
  "theoryphysicsbench-$task_id:local" python3 /solution/baseline.py
```

每题均有 `solution/solve.py`、`baseline.py` 和 `solve.sh`；推导及具体基线假设见对应 `solution/README.md`。参考程序从 `/app/data` 读取相同公开输入，输出 `/app/output/answer.json`。格式按本题 `instruction.md`，不能假定所有题共用同一JSON结构。

用 Harbor 实际检查参考解与空提交：

```bash
python3 tools/run_harbor_local_checks.py tm-01
```

Linux使用交付配置的 `separate/no-network` verifier。当前Mac Docker兼容检查需显式加参数：

```bash
python3 tools/run_harbor_local_checks.py tm-01 --macos-compat
```

该参数仅把**暂存副本**的verifier网络改为public，源题包仍为 `separate/no-network`；兼容记录不能声称已经原样复测Linux正式网络隔离。数值Linux校准使用Docker `--network none`。两种运行都保存实际日志，失败记录同样保留。

## 正式测评

由课程提供固定CLI版本后，按 `tools/course/course.env.example` 填写仅含MODEL、REASONING_EFFORT、CLI_VERSION的无凭据配置；不猜测版本。随后：

```bash
python3 tools/run_formal_benchmark50.py --config tools/course/course.env
python3 tools/run_formal_benchmark50.py --config tools/course/course.env --execute
```

第一条只预览；第二条执行每题3次、并发1、重试0的统一Codex测评，冻结清单与逐题哈希，完整归档至 `runs/codex/`。入口使用安全暂存路径处理源目录中的中文、空格或 `%`，拒绝覆盖旧正式记录。成功后调用原版 `tools/course/汇总结果.py` 生成150条真实记录的 `results.csv`。助教加 `--ta`，单独写 `runs/ta-codex/` 和 `ta_results.csv`。详见[正式测评说明](docs/formal-evaluation.md)。

Oracle检查执行已写好的参考解，nop检查空提交，二者用于验证评分链路；它们不是被测Codex的作答表现。题集冻结后才能进行正式测评；看到正式结果后不替换题目、修改指标或只保留最好的一次。

## 文件与证据

```text
benchmark.json            50题登记、题名、覆盖目标
tasks/ID/instruction.md   公开题面、交付、指标与资源
tasks/ID/environment/     Agent可见的模型、数据、反馈和依赖
tasks/ID/solution/        出题者参考解、简单基线与推导
tasks/ID/tests/           隔离评分器、原版quality_score和private真值
checks/                  来源、公平性、校准、版本核验和命令记录
runs/                    实际Harbor原始运行证据；正式记录分开保存
provenance/              部分QFT题的原件摘要与页码
tools/                   制作、真值、校准、测评与打包工具
tools/course/            原样保留的课程工具
docs/                    设计来源与正式运行说明
报告.md                  最多四页的报告正文
```

每题的 `tests/metric.json` 给出实测基线b、参考h、单位、方向和容差；公开 `metric.json` 与之保持一致。全部采用越低越好的连续误差，质量分由课程原版函数换算为 `clip((b-x)/(b-h),0,1)`。归一尺度、分支匹配、漏报惩罚和工况权重以逐题题面为准；题间原始误差不可直接排名。私有真值仅供隔离verifier重算，不作为参考解可见输入。

发布包不包含教材PDF、整本OCR或截图，也不包含凭据和个人course.env。逐题来源记录保留原书、题号、页码及原创扩展边界，复现题包不要求访问这些原件。当前开发校准不构成对未知科研问题、隐藏新分布泛化或所有物理约定的外部专家背书。
