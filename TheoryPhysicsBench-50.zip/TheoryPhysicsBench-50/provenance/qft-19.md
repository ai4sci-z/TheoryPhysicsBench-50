# qft-19 来源与改造

François Gelis, Problems in Quantum Field Theory, PDF139–145，书页261–267，题67。

原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。

题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH19；私有JSON由Linux检查工具生成，评分时不执行oracle。
