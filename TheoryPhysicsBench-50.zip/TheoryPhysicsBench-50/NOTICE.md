# 材料、作者与使用说明

TheoryPhysicsBench-50 是用于课程研究与复现的私有任务包。本文件不代表为项目自编代码授予开源许可证；后续公开发布或另行许可由项目所有者决定。原作者、第三方软件和课程材料的权利不因本文件改变。

## 物理材料来源

选题和经典方法主要依据用户提供的鞠国兴《理论力学学习指导与习题解析（理科用）（第二版）》、Jackson《经典电动力学》及相关解答资料、林宗涵《热力学与统计物理学》及习题解答、Griffiths量子力学学习指导与习题解答、梁灿彬等《微分几何入门与广义相对论》、量子场论试题详解，以及 Voja Radovanović 的 *Problem Book in Quantum Field Theory* 和 François Gelis 的 *Problems in Quantum Field Theory*。逐题准确的题号、PDF页与书内页、物理内容和扩展边界见 `checks/*sources*.md`、`provenance/` 及 `docs/design-and-provenance.md`。

经典模型、公式和既有数值方法属于原有知识。本项目贡献是明确的任务目标、固定材料与工况、公开探索反馈、参考与基线实现、独立真值、量化评分及Harbor复现流程；不把教材理论或原题的结论宣称为新发现。教材扫描件、整本OCR、答案页截图不随发布包分发。

## 软件和框架

任务使用 Harbor 0.24.0；运行镜像使用 Python 3.12.13 和 Debian bookworm；数值实现依赖 NumPy2.1.3、SciPy1.14.1、mpmath1.3.0。第三方代码、安装包和容器层各自附带的许可证与声明继续适用；本文不替代其许可证。框架及依赖的官方来源：

- Harbor：<https://github.com/laude-institute/harbor>；文档 <https://docs.harborframework.com/>
- Python：<https://www.python.org/>；NumPy：<https://numpy.org/>
- SciPy：<https://scipy.org/>；mpmath：<https://mpmath.org/>
- Debian：<https://www.debian.org/>

`tools/course/` 和各题 `tests/quality_score.py` 来源于教师提供的科研探索课程材料，课程统一质量函数保留原样。它们用于遵循课程运行和计分合同，不构成本项目独立提出的评分公式。

## 工具使用与验证范围

用户确定理论物理主题、提供材料并提出课程目标；AI辅助完成选题整理、任务改造、代码、文档和数值交叉核验。独立数值路线降低同一实现自证的风险，但不等于已经由外部物理专家逐式审核全部50题。来源记录区分实际视觉核对、文本定位和原创扩展；不得将其中一种核查扩大为另一种。

公开Agent镜像只包含每题的 `environment/`。参考解和私有验证标签留在出题者任务包中，由Harbor按用途隔离。发布检查排除凭据、个人配置、无关文件和教材原件；正式模型输出及日志如后续产生，应按课程要求单独归档和审核。
