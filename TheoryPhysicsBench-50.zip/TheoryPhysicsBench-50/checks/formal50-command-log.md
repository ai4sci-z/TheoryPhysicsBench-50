
### 2026-11-16T22:42:20.766110+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(str(p) for p in Path(".").glob("*benchmark*"))); p=Path("tools/check_benchmark50.py"); print(p.read_text() if p.exists() else "check_benchmark50.py 尚未生成")'
```

```text

### 2026-11-16T22:42:20.766064+08:00

```bash
cat 'tools/course/正式测评.sh' 'tools/course/汇总结果.py' 'tools/course/检查提交.py'
```

```text
#!/bin/bash
set -euo pipefail
COURSE_TOOLS="$(cd "$(dirname "$0")" && pwd)"
GROUP_DIR="$(cd "${1:?用法：正式测评.sh 小组目录 [course.env路径] [--ta]}" && pwd)"
CONFIG_FILE="${2:-$COURSE_TOOLS/course.env}"
MODE="${3:-}"
case "$MODE" in
  '') JOBS_DIR="$GROUP_DIR/runs/codex" ;;
  --ta) JOBS_DIR="$GROUP_DIR/runs/ta-codex" ;;
  *) printf '%s\n' '第三个参数只能是--ta，表示助教全题独立复测。' >&2; exit 2 ;;
esac
if [ "$#" -gt 3 ]; then
  printf '%s\n' '用法：正式测评.sh 小组目录 [course.env路径] [--ta]' >&2; exit 2
fi
if [ ! -f "$CONFIG_FILE" ]; then
  printf '%s\n' '请先由助教填写course.env.example，另存为course.env。' >&2; exit 2
fi
source "$CONFIG_FILE"
: "${MODEL:?course.env缺少MODEL}"
: "${CLI_VERSION:?course.env缺少CLI_VERSION}"
: "${REASONING_EFFORT:?course.env缺少REASONING_EFFORT}"
if [ "$MODEL" != "gpt-6.1-sol" ] || [ "$REASONING_EFFORT" != "max" ]; then
  printf '%s\n' '正式配置须为Codex + GPT6.1-sol-max（MODEL=gpt-6.1-sol，REASONING_EFFORT=max）。' >&2; exit 2
fi
if [ -e "$JOBS_DIR" ]; then
  printf '%s\n' '该目录已有正式结果。请保留原记录，先与助教确认再补跑。' >&2; exit 2
fi
python3 "$COURSE_TOOLS/检查提交.py" "$GROUP_DIR"
mkdir -p "$GROUP_DIR/runs"
harbor run -p "$GROUP_DIR/tasks" -a codex -m "$MODEL" \
  --ak "version=$CLI_VERSION" --effort "$REASONING_EFFORT" \
  --n-attempts 3 --n-concurrent 1 --max-retries 0 --jobs-dir "$JOBS_DIR"
#!/usr/bin/env python3
"""从Harbor0.24的原始记录生成结果表；异常记录须先由助教核实。"""
import argparse
import csv
from datetime import datetime
import json
import math
from pathlib import Path
import tempfile
import tomllib

from quality_score import finite_number, quality_score, validate_metric

FIELDS = ["task_id", "config", "run", "score", "raw_metric", "seconds", "trial_dir", "status"]


def read_object(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path}须为JSON对象")
    return data


def phase_seconds(data, stage):
    phase = data.get(stage)
    if not isinstance(phase, dict):
        raise ValueError(f"缺少{stage}时间记录")
    try:
        started = datetime.fromisoformat(phase["started_at"])
        finished = datetime.fromisoformat(phase["finished_at"])
    except (KeyError, ValueError, TypeError) as exc:
        raise ValueError(f"{stage}的起止时间不完整") from exc
    if started.tzinfo is None or finished.tzinfo is None:
        raise ValueError(f"{stage}须有明确时区")
    duration = (finished-started).total_seconds()
    if not math.isfinite(duration) or duration < 0:
        raise ValueError(f"{stage}时间无效")
    return duration, started


def collect(root, ta=False):
    root = root.resolve()
    manifest = read_object(root / "benchmark.json")
    items = manifest.get("tasks")
    if not isinstance(items, list) or not items:
        raise ValueError("benchmark.json须登记tasks")
    tasks = {}
    names = {}
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("题目登记须为对象")
        identifier, relative = item.get("id"), item.get("path")
        if not isinstance(identifier, str) or relative != f"tasks/{identifier}" or identifier in tasks:
            raise ValueError("题目id须唯一，path须为tasks/id")
        directory = (root / relative).resolve()
        if directory.parent != (root / "tasks").resolve() or directory.name != identifier:
            raise ValueError(f"{identifier}的目录不符合登记")
        task_config = tomllib.loads((directory / "task.toml").read_text(encoding="utf-8"))
        task_metadata = task_config.get("task")
        if task_metadata is not None and not isinstance(task_metadata, dict):
            raise ValueError(f"{identifier}的[task]须为配置表")
        full_name = directory.name if task_metadata is None else task_metadata.get("name")
        if not isinstance(full_name, str) or not full_name.strip():
            raise ValueError(f"{identifier}的task.name须为非空字符串")
        if full_name in names:
            raise ValueError(f"task.name重复：{full_name}（{names[full_name]}、{identifier}）")
        names[full_name] = identifier
        metric = read_object(directory / "tests/metric.json")
        validate_metric(metric)
        tasks[identifier] = metric
    config = "ta_codex" if ta else "codex"
    jobs = root / "runs" / ("ta-codex" if ta else "codex")
    if not jobs.is_dir():
        raise ValueError(f"没有运行目录：{jobs}")
    records = {identifier: [] for identifier in tasks}
    errors, seen_ids = [], set()
    job_dirs = sorted(path for path in jobs.iterdir() if path.is_dir())
    if not job_dirs:
        raise ValueError(f"没有Harbor job：{jobs}")
    for job in job_dirs:
        if job.is_symlink() or not job.resolve().is_relative_to(jobs.resolve()):
            errors.append(f"{job.relative_to(root)}：job目录越界或为符号链接")
            continue
        if not (job / "config.json").is_file():
            errors.append(f"{job.relative_to(root)}：缺少job配置")
            continue
        for trial in sorted(path for path in job.iterdir() if path.is_dir()):
            location = str(trial.relative_to(root))
            try:
                if trial.is_symlink() or not trial.resolve().is_relative_to(jobs.resolve()):
                    raise ValueError("原始记录目录越界")
                data = read_object(trial / "result.json")
                full_name = data.get("task_name")
                if not isinstance(full_name, str) or full_name not in names:
                    raise ValueError(f"未登记的task_name：{full_name}")
                identifier = names[full_name]
                trial_id = data.get("id")
                if not isinstance(trial_id, str) or not trial_id or trial_id in seen_ids:
                    raise ValueError("trial id缺失或重复")
                seen_ids.add(trial_id)
                if data.get("step_results"):
                    raise ValueError("仅自动汇总课程单阶段任务")
                if data.get("verifier_environment_mode") != "separate":
                    raise ValueError("评分环境不是separate")
                if data.get("exception_info") is not None:
                    exception = data["exception_info"]
                    detail = exception.get("exception_type", "异常") if isinstance(exception, dict) else "异常"
                    raise ValueError(f"有{detail}，请保留记录并人工核实状态与补跑要求")
                info = data.get("agent_info")
                if not isinstance(info, dict) or info.get("name") != "codex":
                    raise ValueError("agent_info不是codex")
                model = info.get("model_info")
                if not isinstance(model, dict) or model.get("name") != "gpt-6.1-sol":
                    raise ValueError("模型不是gpt-6.1-sol")
                trial_config = data.get("config", {})
                agent_config = trial_config.get("agent", {})
                options = agent_config.get("kwargs", {})
                if agent_config.get("name") != "codex" or agent_config.get("model_name") != "gpt-6.1-sol":
                    raise ValueError("记录中的Agent配置不符合课程要求")
                if options.get("reasoning_effort") != "max" or not isinstance(options.get("version"), str) or not options["version"].strip():
                    raise ValueError("缺少max推理强度或固定CLI版本")
                metrics = read_object(trial / "verifier/metrics.json")
                if "raw_metric" not in metrics:
                    raise ValueError("metrics.json缺少raw_metric")
                raw = metrics["raw_metric"]
                if raw is not None:
                    finite_number(raw, "raw_metric")
                status = metrics.get("status")
                score = quality_score(tasks[identifier], raw, status)
                reported = finite_number(metrics.get("score"), "metrics.score")
                verifier = data.get("verifier_result")
                reward = verifier.get("rewards", {}).get("reward") if isinstance(verifier, dict) else None
                reward = finite_number(reward, "Harbor reward")
                if not all(math.isclose(v, score, rel_tol=0, abs_tol=1e-6) for v in (reported, reward)):
                    raise ValueError("原始指标重算q、metrics.score与Harbor reward不一致")
                agent_seconds, started = phase_seconds(data, "agent_execution")
                verifier_seconds, _ = phase_seconds(data, "verifier")
                seconds = agent_seconds + verifier_seconds
                if seconds > 43200:
                    raise ValueError("Agent与verifier执行累计超过43200秒")
                records[identifier].append((started, {
                    "task_id": identifier, "config": config, "score": score,
                    "raw_metric": "null" if raw is None else raw,
                    "seconds": round(seconds, 6), "trial_dir": location, "status": status,
                }))
            except (OSError, ValueError, TypeError, AttributeError) as exc:
                errors.append(f"{location}：{exc}")
    rows = []
    for identifier, trials in records.items():
        if len(trials) != 3:
            errors.append(f"{identifier}：应有3次可自动核实的正式记录，实际{len(trials)}次")
        for number, (_, row) in enumerate(sorted(trials, key=lambda x: x[0]), 1):
            rows.append({**row, "run": number})
    for number in range(1, 4):
        if sum(row["seconds"] for row in rows if row["run"] == number) > 43200:
            errors.append(f"第{number}轮全题执行累计超过43200秒")
    if errors:
        raise ValueError("\n".join(errors) + "\n未写入摘要；请核对全部原始记录，不删除有效失败或多余尝试。")
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--ta", action="store_true", help="汇总runs/ta-codex，生成ta_results.csv")
    args = parser.parse_args()
    temporary = None
    try:
        root = args.directory.expanduser().resolve()
        rows = collect(root, args.ta)
        target = root / ("ta_results.csv" if args.ta else "results.csv")
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="", dir=root, prefix=".results-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            writer = csv.DictWriter(stream, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(rows)
        temporary.replace(target)
    except (OSError, ValueError, TypeError) as exc:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
        parser.error(str(exc))
    print(f"已汇总{len(rows)}条记录：{target}；请继续核对配置、异常与逐题原始产物。")


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
"""静态检查benchmark清单、逐题配置及3N条结果；不执行学生代码。"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import tomllib

from quality_score import finite_number, quality_score, validate_metric

ROUND_LIMIT = 43200
TASK_ID = re.compile(r"[a-z0-9][a-z0-9_-]{0,63}\Z")


def read_manifest(root):
    """Return safe registered tasks plus validation errors, without following links."""
    errors, registered = [], []
    path = root / "benchmark.json"
    try:
        if path.is_symlink():
            raise ValueError("benchmark.json须为包内文件，不能使用符号链接")
        manifest = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(manifest, dict):
            raise ValueError("benchmark.json须为JSON对象")
        for field in ("name", "research_goal"):
            value = manifest.get(field)
            if not isinstance(value, str) or not value.strip() or "TODO" in value:
                errors.append(f"benchmark.json须填写{field}")
        entries = manifest.get("tasks")
        if not isinstance(entries, list):
            raise ValueError("tasks须为题目清单数组")
        if len(entries) < 10:
            errors.append("benchmark须登记不少于10道题")
        if len(entries) > 20:
            errors.append("benchmark最多登记20道题")
        ids = set()
        for index, entry in enumerate(entries, 1):
            if not isinstance(entry, dict):
                errors.append(f"清单第{index}项须为对象")
                continue
            task_id = entry.get("id")
            if not isinstance(task_id, str) or not TASK_ID.fullmatch(task_id):
                errors.append(f"清单第{index}项id须为1–64位小写字母、数字、短横线或下划线，以字母或数字开头")
                continue
            if task_id in ids:
                errors.append(f"题目id重复：{task_id}")
                continue
            ids.add(task_id)
            for field in ("title", "coverage"):
                value = entry.get(field)
                if not isinstance(value, str) or not value.strip() or "TODO" in value:
                    errors.append(f"{task_id}：清单须填写{field}")
            if entry.get("path") != f"tasks/{task_id}":
                errors.append(f"{task_id}：path须为tasks/{task_id}")
                continue
            registered.append(entry)
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        errors.append(f"清单有误：{exc}")

    tasks_root = root / "tasks"
    if tasks_root.is_symlink() or not tasks_root.is_dir():
        errors.append("tasks须为包内实际目录")
        return [], errors
    expected = {entry["id"] for entry in registered}
    actual = {p.name for p in tasks_root.iterdir() if p.is_dir() or p.is_symlink()}
    if actual != expected:
        missing, extra = sorted(expected - actual), sorted(actual - expected)
        if missing:
            errors.append("缺少登记目录：" + ", ".join(missing))
        if extra:
            errors.append("tasks中有未登记目录：" + ", ".join(extra))
    for path in tasks_root.iterdir():
        if path.name in {"instruction.md", "task.toml"}:
            errors.append("tasks只存放逐题目录，不能同时作为一道Harbor题")
    return registered, errors


def task_digest(task):
    digest = hashlib.sha256()
    if task.is_symlink() or not task.is_dir():
        return digest.hexdigest()
    for path in sorted(task.rglob("*")):
        if path.is_symlink() or "__pycache__" in path.parts or path.name == ".DS_Store" or path.suffix == ".pyc":
            continue
        if path.is_file():
            digest.update(path.relative_to(task).as_posix().encode())
            digest.update(b"\0" + path.read_bytes() + b"\0")
    return digest.hexdigest()


def task_digests(root):
    registered, _ = read_manifest(root)
    return {entry["id"]: task_digest(root / entry["path"]) for entry in registered}


def check_task(root, entry):
    errors = []
    task_id, task = entry["id"], root / entry["path"]
    if task.is_symlink() or not task.is_dir():
        return [f"{task_id}：题目须为包内实际目录"], None, None, None
    links = [p for p in task.rglob("*") if p.is_symlink()]
    if links:
        return [f"{task_id}：导出自包含任务，去掉符号链接{p.relative_to(task)}" for p in links], None, None, None
    for name in ["instruction.md", "task.toml", "solution/solve.sh", "tests/test.sh",
                 "tests/metric.json", "tests/quality_score.py"]:
        if not (task / name).is_file():
            errors.append(f"缺少：{entry['path']}/{name}")
    if not any((task / "environment" / name).is_file() for name in ("Dockerfile", "docker-compose.yaml")):
        errors.append(f"{task_id}：缺少environment/Dockerfile或docker-compose.yaml")
    editable = [task / "instruction.md", task / "task.toml", task / "tests/metric.json"]
    for folder in (task / "solution", task / "tests"):
        editable.extend(p for p in folder.rglob("*") if p.suffix in {".py", ".sh"})
    for path in editable:
        try:
            if path.is_file() and "TODO" in path.read_text(encoding="utf-8"):
                errors.append(f"尚有TODO：{path.relative_to(root)}")
        except (OSError, UnicodeError) as exc:
            errors.append(f"无法读取{path.relative_to(root)}：{exc}")
    time_limit, task_name = None, None
    try:
        cfg = tomllib.loads((task / "task.toml").read_text(encoding="utf-8"))
        if cfg.get("schema_version") != "1.4":
            errors.append(f"{task_id}：schema_version须为1.4")
        if cfg.get("verifier", {}).get("environment_mode") != "separate":
            errors.append(f"{task_id}：评分须使用独立verifier环境")
        timeouts = [finite_number(cfg.get(stage, {}).get("timeout_sec"), f"{stage}.timeout_sec")
                    for stage in ("agent", "verifier")]
        if any(t <= 0 for t in timeouts) or sum(timeouts) > ROUND_LIMIT:
            errors.append(f"{task_id}：Agent与verifier时限须为正，合计≤43200秒")
        else:
            time_limit = sum(timeouts)
        task_name = cfg.get("task", {}).get("name")
        if not isinstance(task_name, str) or not task_name.strip():
            errors.append(f"{task_id}：[task].name须填写唯一名称")
        env = cfg.get("environment", {})
        gpus = env.get("gpus", 0)
        if type(gpus) is not int or gpus not in {0, 1}:
            errors.append(f"{task_id}：GPU数量只能为0或1")
        if gpus == 1 and env.get("gpu_types") != ["A100"]:
            errors.append(f'{task_id}：GPU任务须声明gpu_types=["A100"]，按单块80GB设计')
        artifacts = cfg.get("artifacts", [])
        if not isinstance(artifacts, list) or not artifacts:
            errors.append(f"{task_id}：artifacts须列出实际产物路径")
        else:
            for name in artifacts:
                if not isinstance(name, str) or not name.startswith("/"):
                    errors.append(f"{task_id}：artifacts须使用容器内绝对路径")
                elif name.rstrip("/") in {"", "/app", "/tests", "/solution", "/logs"} or any(
                    name.startswith(prefix) for prefix in ("/tests/", "/solution/", "/logs/")
                ) or ".." in Path(name).parts:
                    errors.append(f"{task_id}：artifacts应只包含待评分产物：{name}")
    except (OSError, UnicodeError, ValueError, TypeError, AttributeError) as exc:
        errors.append(f"{task_id}：task.toml有误：{exc}")
    metric = None
    try:
        metric = json.loads((task / "tests/metric.json").read_text(encoding="utf-8"))
        validate_metric(metric)
        for field in ("metric_name", "unit"):
            if not isinstance(metric.get(field), str) or not metric[field].strip():
                errors.append(f"{task_id}：metric.json须填写{field}")
        if (task / "tests/quality_score.py").read_bytes() != Path(__file__).with_name("quality_score.py").read_bytes():
            errors.append(f"{task_id}：请保留课程提供的tests/quality_score.py")
    except (OSError, UnicodeError, ValueError, TypeError, AttributeError) as exc:
        errors.append(f"{task_id}：指标定义有误：{exc}")
        metric = None
    return errors, metric, time_limit, task_name


def check_results(root, registered, metrics, limits, ta):
    errors = []
    filename, config = ("ta_results.csv", "ta_codex") if ta else ("results.csv", "codex")
    table = root / filename
    try:
        if table.is_symlink():
            raise ValueError("结果表须为包内文件")
        with table.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            fields = {"task_id", "config", "run", "score", "raw_metric", "seconds", "trial_dir", "status"}
            headers = reader.fieldnames or []
            if not fields.issubset(headers) or len(set(headers)) != len(headers):
                errors.append(f"{filename}列名不完整或重复，请使用模板表头")
            rows = list(reader)
    except (OSError, UnicodeError, ValueError, csv.Error) as exc:
        return [f"无法读取{filename}：{exc}"]
    expected = {(entry["id"], config, str(n)) for entry in registered for n in range(1, 4)}
    keys = [(r.get("task_id"), r.get("config"), r.get("run")) for r in rows]
    if len(keys) != len(expected) or set(keys) != expected:
        errors.append(f"{filename}须恰好包含每道登记题{config}配置的三次运行，共{len(expected)}行；不能遗漏、重复或加入未登记题")
    round_seconds = {str(n): 0.0 for n in range(1, 4)}
    seen_trials = set()
    mode_dir = root / "runs" / ("ta-codex" if ta else "codex")
    if mode_dir.is_symlink():
        errors.append(f"runs/{mode_dir.name}须为独立实际目录，不能使用符号链接")
    for row in rows:
        task_id, run = row.get("task_id"), row.get("run")
        label = f"{task_id}/{row.get('config')}/{run}"
        try:
            score = finite_number(float(row.get("score", "")), "score")
            if not 0 <= score <= 1:
                raise ValueError("score须在0到1之间")
        except (ValueError, TypeError) as exc:
            errors.append(f"{label}：{exc}")
        try:
            seconds = finite_number(float(row.get("seconds", "")), "seconds")
            maximum = limits.get(task_id) or ROUND_LIMIT
            if not 0 <= seconds <= maximum:
                raise ValueError(f"seconds须在0到本题登记总时限{maximum:g}之间")
            if run in round_seconds:
                round_seconds[run] += seconds
        except (ValueError, TypeError) as exc:
            errors.append(f"{label}：{exc}")
        try:
            text = row.get("raw_metric", "").strip()
            if not text:
                raise ValueError("缺少raw_metric；没有原始值时明确填null")
            raw = None if text == "null" else finite_number(float(text), "raw_metric")
            if metrics.get(task_id) is not None:
                score = quality_score(metrics[task_id], raw, row.get("status"))
                if not math.isclose(float(row.get("score", "")), score, rel_tol=0, abs_tol=1e-6):
                    raise ValueError("score与原始指标按统一公式重算的结果不符")
        except (ValueError, TypeError, AttributeError) as exc:
            errors.append(f"{label}：{exc}")
        trial = row.get("trial_dir") or ""
        path = (root / trial).resolve()
        if (not trial or Path(trial).is_absolute() or not path.is_relative_to(root)
                or not path.is_relative_to(mode_dir.resolve()) or not path.is_dir()):
            errors.append(f"{label}：trial_dir须指向runs/{mode_dir.name}/内已有的相对目录")
        elif path in seen_trials:
            errors.append(f"{label}：多个结果指向同一运行目录，请保留独立运行记录")
        seen_trials.add(path)
    for run, seconds in round_seconds.items():
        if seconds > ROUND_LIMIT:
            errors.append(f"{filename}第{run}轮全部题累计耗时{seconds:g}秒，超过43200秒")
    return errors


def check(root, final=False, ta=False):
    root = Path(root).expanduser().resolve()
    errors = []
    for name in ("报告.md", "results.csv", "checks", "runs"):
        path = root / name
        expected = path.is_dir() if name in {"checks", "runs"} else path.is_file()
        if path.is_symlink() or not expected:
            errors.append(f"缺少包内实际文件/目录：{name}")
    registered, manifest_errors = read_manifest(root)
    errors.extend(manifest_errors)
    metrics, limits, names = {}, {}, {}
    for entry in registered:
        task_errors, metric, limit, name = check_task(root, entry)
        errors.extend(task_errors)
        metrics[entry["id"]], limits[entry["id"]] = metric, limit
        if isinstance(name, str):
            if name in names:
                errors.append(f"{entry['id']}与{names[name]}的[task].name重复")
            else:
                names[name] = entry["id"]
    if sum(value for value in limits.values() if value is not None) > ROUND_LIMIT:
        errors.append("全部题的Agent与verifier登记时限之和超过43200秒；一轮全题须≤12小时，三轮≤36小时")
    if final:
        errors.extend(check_results(root, registered, metrics, limits, ta))
    digest = hashlib.sha256()
    manifest = root / "benchmark.json"
    if manifest.is_file() and not manifest.is_symlink():
        digest.update(b"benchmark.json\0" + manifest.read_bytes() + b"\0")
    for task_id, task_hash in sorted(task_digests(root).items()):
        digest.update(task_id.encode() + b"\0" + task_hash.encode() + b"\0")
    return errors, digest.hexdigest()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--final", action="store_true", help="同时检查每题3次的完整结果表")
    parser.add_argument("--ta", action="store_true", help="--final时核对ta_results.csv及助教复测目录")
    args = parser.parse_args()
    root = args.directory.expanduser().resolve()
    if not root.is_dir():
        sys.exit(f"目录不存在：{root}")
    problems, digest = check(root, args.final, args.ta)
    print(f"benchmark SHA256: {digest}")
    for task_id, task_hash in sorted(task_digests(root).items()):
        print(f"{task_id} SHA256: {task_hash}")
    if problems:
        print("\n".join(f"- {item}" for item in problems))
        sys.exit(1)
    print("预检通过。助教仍将逐题复核创新性、质量、完整度，并重新评测全部题目。")

exit_code=0
```
benchmark.json
"""50-task development preflight. Does not alter the course's 10–20-task rule."""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tomllib

ROOT=Path(__file__).resolve().parents[1]
EXPECTED={f'{prefix}-{i:02}' for prefix,count in [('tm',5),('ed',5),('sp',5),('qm',5),('qft',25),('gr',5)] for i in range(1,count+1)}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--require-calibrated',action='store_true');parser.add_argument('--require-harbor',action='store_true');args=parser.parse_args()
    course=ROOT/'tools/course';sys.path.insert(0,str(course))
    spec=importlib.util.spec_from_file_location('course_check',course/'检查提交.py');official=importlib.util.module_from_spec(spec);spec.loader.exec_module(official)
    manifest=json.loads((ROOT/'benchmark.json').read_text());entries=manifest['tasks'];ids=[e['id'] for e in entries];errors=[];records=[];names=set();total=0
    if len(ids)!=50 or set(ids)!=EXPECTED:errors.append('注册题目不等于50个预期独立ID')
    if {p.name for p in (ROOT/'tasks').iterdir() if p.is_dir()}!=EXPECTED:errors.append('目录集合与登记不一致')
    for entry in entries:
        identifier=entry['id'];task=ROOT/entry['path'];item_errors,metric,limit,name=official.check_task(ROOT,entry)
        errors.extend(item_errors)
        if name in names:errors.append(identifier+': task.name重复')
        names.add(name);total+=limit or 0
        for p in task.rglob('*.py'):
            if '__pycache__' in p.parts:continue
            try:ast.parse(p.read_text(),filename=str(p))
            except (SyntaxError,UnicodeError) as exc:errors.append(str(p.relative_to(ROOT))+': '+str(exc))
        cfg=tomllib.loads((task/'task.toml').read_text())
        if cfg.get('environment',{}).get('gpus')!=0:errors.append(identifier+': 本题集应为CPU任务')
        docker=(task/'environment/Dockerfile').read_text()
        if 'sha256:' not in docker:errors.append(identifier+': 基础镜像未固定digest')
        for p in (task/'environment').rglob('*'):
            if p.is_symlink():errors.append(identifier+': 公开环境不能有符号链接')
            if p.is_file() and p.name in ('truth.json','solve.py','baseline.py','quality_score.py','score.py'):errors.append(identifier+': 公开环境混入答案或评分代码 '+str(p.relative_to(task)))
        if metric and (task/'environment/public/metric.json').exists():
            if json.loads((task/'environment/public/metric.json').read_text())!=metric:errors.append(identifier+': 公开和评分metric不一致')
        calibration=ROOT/f'checks/{identifier}-calibration.json';c=json.loads(calibration.read_text()) if calibration.exists() else {};checks=c.get('checks',{})
        calibrated=bool(checks) and all(checks.values())
        if args.require_calibrated and not calibrated:errors.append(identifier+': 缺少通过的校准证据')
        sessions=[]
        for path in (ROOT/'runs'/identifier/'harbor-macos-compat').glob('session-*.json'):
            s=json.loads(path.read_text());ok={r.get('agent'):r.get('passed') for r in s.get('runs',[])}
            if ok.get('oracle') and ok.get('nop'):sessions.append(str(path.relative_to(ROOT)))
        if args.require_harbor and not sessions:errors.append(identifier+': 尚无oracle=1/nop=0同会话证据')
        records.append({'id':identifier,'course_task_check_passed':not item_errors,'calibrated':calibrated,'harbor_sessions':sessions,'sha256':official.task_digest(task)})
    if total>43200:errors.append(f'总登记时限{total}超过43200秒')
    report={'task_count':len(entries),'total_timeout_seconds':total,'errors':errors,'passed':not errors,'tasks':records,
            'scope':'50-task development package; original course count limit is preserved and not certified by this extension'}
    path=ROOT/'checks/benchmark-50-preflight.json';path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'task_count':len(entries),'total_timeout_seconds':total,'passed':not errors,'errors':errors},ensure_ascii=False,indent=2))
    if errors:raise SystemExit(1)

if __name__=='__main__':main()


exit_code=0
```

### 2026-11-16T22:42:54.307890+08:00

```bash
cat tools/course/course.env.example
```

```text

### 2026-11-16T22:42:54.309348+08:00

```bash
python3 -c 'import json; from pathlib import Path; m=json.loads(Path("benchmark.json").read_text()); print(json.dumps({k:v for k,v in m.items() if k!="tasks"},ensure_ascii=False,indent=2)); print(json.dumps(m["tasks"][:2],ensure_ascii=False,indent=2))'
```

```text
# 正式配置：Codex + GPT6.1-sol-max。这里不存API密钥。
MODEL='gpt-6.1-sol'
REASONING_EFFORT='max'
# 助教填写统一CLI版本后，另存为course.env。
CLI_VERSION=''

exit_code=0
```
{
  "name": "TheoryPhysicsBench-50",
  "research_goal": "在六门理论物理中检验智能体依据明确物理约定完成建模、推导构造、数值收敛、近似选择与可核验预测的能力。50题为统一Harbor运行的完整开发题集；固定实例通过隔离真值、独立重算和物理证书评分。",
  "version": "0.2.0-dev"
}
[
  {
    "id": "ed-01",
    "path": "tasks/ed-01",
    "title": "点电荷与介质核壳球的反作用：自力反号和径向平衡",
    "coverage": "电动力学：点电荷与介质核壳球的反作用：自力反号和径向平衡；独立任务材料、参考结果和评分依据见ed-01题包。"
  },
  {
    "id": "ed-02",
    "path": "tasks/ed-02",
    "title": "有限长直天线的角谱反演和多瓣辐射",
    "coverage": "电动力学：有限长直天线的角谱反演和多瓣辐射；独立任务材料、参考结果和评分依据见ed-02题包。"
  }
]

exit_code=0
```

### 2026-11-16T22:48:12.221809+08:00

```bash
python3 tools/test_formal_benchmark50.py
```

```text
Traceback (most recent call last):
  File "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/test_formal_benchmark50.py", line 16, in <module>
    spec.loader.exec_module(runner)
  File "<frozen importlib._bootstrap_external>", line 995, in exec_module
  File "<frozen importlib._bootstrap_external>", line 1133, in get_code
  File "<frozen importlib._bootstrap_external>", line 1063, in source_to_code
  File "<frozen importlib._bootstrap>", line 488, in _call_with_frames_removed
  File "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_formal_benchmark50.py", line 23
    EXPECTED = {f'{prefix}-{i:02}' for prefix, count in
               ^
SyntaxError: '{' was never closed

exit_code=1
```

### 2026-11-16T22:48:27.253090+08:00

```bash
python3 tools/test_formal_benchmark50.py
```

```text
test_attempts_concurrency_retries_model_and_fixed_version (__main__.Formal50Tests.test_attempts_concurrency_retries_model_and_fixed_version) ... ok
test_config_shell_syntax_is_never_executed (__main__.Formal50Tests.test_config_shell_syntax_is_never_executed) ... ok
test_config_symlink_rejected_without_resolve_bypass (__main__.Formal50Tests.test_config_symlink_rejected_without_resolve_bypass) ... ok
test_config_unknown_duplicate_empty_and_wrong_model_rejected (__main__.Formal50Tests.test_config_unknown_duplicate_empty_and_wrong_model_rejected) ... ok
test_default_dry_run_never_invokes_subprocess_or_creates_results (__main__.Formal50Tests.test_default_dry_run_never_invokes_subprocess_or_creates_results) ... ok
test_execute_uses_ascii_safe_copy_freezes_hashes_and_archives_all_raw (__main__.Formal50Tests.test_execute_uses_ascii_safe_copy_freezes_hashes_and_archives_all_raw) ... FAIL
test_existing_student_and_ta_results_never_overwritten (__main__.Formal50Tests.test_existing_student_and_ta_results_never_overwritten) ... ok
test_failed_model_preserves_raw_and_does_not_summarize (__main__.Formal50Tests.test_failed_model_preserves_raw_and_does_not_summarize) ... ok
test_preflight_failure_propagates_and_does_not_launch_model (__main__.Formal50Tests.test_preflight_failure_propagates_and_does_not_launch_model) ... ok
test_runtime_source_mutation_blocks_summary_but_keeps_raw (__main__.Formal50Tests.test_runtime_source_mutation_blocks_summary_but_keeps_raw) ... ok
test_summarize_refuses_missing_or_mutated_freeze (__main__.Formal50Tests.test_summarize_refuses_missing_or_mutated_freeze) ... ok
test_symlink_task_and_changed_staging_rejected (__main__.Formal50Tests.test_symlink_task_and_changed_staging_rejected) ... ok
test_valid_literal_config_and_no_credentials (__main__.Formal50Tests.test_valid_literal_config_and_no_credentials) ... ok
test_wrong_harbor_version_stops_before_model (__main__.Formal50Tests.test_wrong_harbor_version_stops_before_model) ... ok

======================================================================
FAIL: test_execute_uses_ascii_safe_copy_freezes_hashes_and_archives_all_raw (__main__.Formal50Tests.test_execute_uses_ascii_safe_copy_freezes_hashes_and_archives_all_raw)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/test_formal_benchmark50.py", line 175, in test_execute_uses_ascii_safe_copy_freezes_hashes_and_archives_all_raw
    self.assertTrue(any(str(self.course / '汇总结果.py') in c for c in commands))
AssertionError: False is not true

----------------------------------------------------------------------
Ran 14 tests in 0.826s

FAILED (failures=1)

exit_code=1
```

### 2026-11-16T22:48:57.067355+08:00

```bash
python3 tools/test_formal_benchmark50.py
```

```text
test_attempts_concurrency_retries_model_and_fixed_version (__main__.Formal50Tests.test_attempts_concurrency_retries_model_and_fixed_version) ... ok
test_config_shell_syntax_is_never_executed (__main__.Formal50Tests.test_config_shell_syntax_is_never_executed) ... ok
test_config_symlink_rejected_without_resolve_bypass (__main__.Formal50Tests.test_config_symlink_rejected_without_resolve_bypass) ... ok
test_config_unknown_duplicate_empty_and_wrong_model_rejected (__main__.Formal50Tests.test_config_unknown_duplicate_empty_and_wrong_model_rejected) ... ok
test_default_dry_run_never_invokes_subprocess_or_creates_results (__main__.Formal50Tests.test_default_dry_run_never_invokes_subprocess_or_creates_results) ... ok
test_execute_uses_ascii_safe_copy_freezes_hashes_and_archives_all_raw (__main__.Formal50Tests.test_execute_uses_ascii_safe_copy_freezes_hashes_and_archives_all_raw) ... ok
test_existing_student_and_ta_results_never_overwritten (__main__.Formal50Tests.test_existing_student_and_ta_results_never_overwritten) ... ok
test_failed_model_preserves_raw_and_does_not_summarize (__main__.Formal50Tests.test_failed_model_preserves_raw_and_does_not_summarize) ... ok
test_preflight_failure_propagates_and_does_not_launch_model (__main__.Formal50Tests.test_preflight_failure_propagates_and_does_not_launch_model) ... ok
test_runtime_source_mutation_blocks_summary_but_keeps_raw (__main__.Formal50Tests.test_runtime_source_mutation_blocks_summary_but_keeps_raw) ... ok
test_summarize_refuses_missing_or_mutated_freeze (__main__.Formal50Tests.test_summarize_refuses_missing_or_mutated_freeze) ... ok
test_symlink_task_and_changed_staging_rejected (__main__.Formal50Tests.test_symlink_task_and_changed_staging_rejected) ... ok
test_valid_literal_config_and_no_credentials (__main__.Formal50Tests.test_valid_literal_config_and_no_credentials) ... ok
test_wrong_harbor_version_stops_before_model (__main__.Formal50Tests.test_wrong_harbor_version_stops_before_model) ... ok

----------------------------------------------------------------------
Ran 14 tests in 0.794s

OK

exit_code=0
```
