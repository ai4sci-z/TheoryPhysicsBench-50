
### 2026-11-16T21:56:24.881135+08:00

```bash
python3 -c 'from pathlib import Path; import json; r=Path("."); print("AGENTS",list(r.parents[0].glob("AGENTS.md"))); print(Path("README.md").read_text()[:18000]); print(Path("planning/qft-expansion-20-audit.md").read_text()); d=json.loads(Path("planning/qft-expansion-20-selection.json").read_text()); print(type(d)); print(json.dumps(d,ensure_ascii=False)[:5000]); print("QFT04",list(Path("tasks/qft-04").rglob("*"))); print("MATERIALS",list(Path("../../00-老师原始材料/科研探索课程项目").glob("*")))'
```

```text
Traceback (most recent call last):
  File "<string>", line 1, in <module>
  File "/Library/Frameworks/Python.framework/Versions/3.12/lib/python3.12/pathlib.py", line 282, in __getitem__
    raise IndexError(idx)
IndexError: 0

exit_code=1
```

### 2026-11-16T21:56:37.358314+08:00

```bash
python3 -c 'from pathlib import Path; import json; r=Path.cwd(); print("AGENTS",[str(p/"AGENTS.md") for p in [r,*r.parents] if (p/"AGENTS.md").exists()]); print(Path("README.md").read_text()[:15000]); d=json.loads(Path("planning/qft-expansion-20-selection.json").read_text()); print(type(d)); print(json.dumps(d,ensure_ascii=False)[:3000]); print("QFT04",[str(p) for p in Path("tasks/qft-04").rglob("*")]); print("MATERIALS",[str(p) for p in Path("../../00-老师原始材料/科研探索课程项目").glob("*")])'
```

```text
AGENTS []
# TheoryPhysicsBench-30

面向课程指定 Codex 的理论物理科学任务集。题目来自用户提供的六门课程教材与习题材料，通过物理建模、数值计算、参数反演等任务改造，交付可独立验证的 Harbor 题包。

## 题集规模

| 学科 | 编号前缀 | 计划题数 | 已有完整开发题包 |
|---|---|---:|---|
| 理论力学 | tm | 5 | tm-01、tm-02 |
| 电动力学 | ed | 5 | ed-01 |
| 热力学与统计物理 | sp | 5 | sp-01 |
| 量子力学 | qm | 5 | qm-01 |
| 量子场论 | qft | 5 | — |
| 广义相对论 | gr | 5 | — |

共 30 道独立问题。理论力学属于理论物理，`tm-01` 的固定端质点链与简正振动辨识保留在本题集中。各题需要不同的物理推理和计算工作，不将同一道题的换参数版本计为多道。

## 已完成开发验证的题目

**tm-01：局部振动观测下的弹簧链损伤辨识。** 从三组含噪位移记录恢复八质点链的九个非均匀刚度与两处软化位置，以参数精度、隐藏运动预测和位置识别共同评分。

- [题面](tasks/tm-01/instruction.md)
- [物理推导和参考解](tasks/tm-01/solution/README.md)
- [教材出处及已有评测对照](checks/tm-01-sources.md)
- [公开材料与隐藏验证划分](checks/tm-01-materials-and-fairness.md)
- [Docker / Harbor 验证记录](checks/tm-01-validation.md)
- [完整校准数据](checks/tm-01-calibration.json)

已完成 Docker Linux 的基线、参考解与评分样例验证，11 项检查全部通过；Harbor 0.24.0 的 oracle=1、nop=0。参考解在此次 4 CPU/4 GB 容器内耗时约 1.67 秒，无需 GPU。

课程指定 Codex 的每题三次独立正式测评在题集冻结后执行。`oracle` 记录用于核对参考解和评分链路，正式模型结果单独保存。

**tm-02：非开普勒中心势中束缚轨道的拱点进动。** 从有效势求转折点、径向周期与完整方位角，处理端点奇性，并与独立运动方程积分核对。近圆近似基线误差 10.4201 个百分点，完整轨道积分参考误差约 1.07e-11；11 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/tm-02/instruction.md)、[推导](tasks/tm-02/solution/README.md)、[验证记录](checks/tm-02-validation.md)。

**sp-01：平均场铁磁体的多分支平衡与亚稳态。** 找全驻点，区分局部稳定性与平衡态，计算分支磁化率。Landau 基线误差 3.1082，完整参考约 9.49e-14；13 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/sp-01/instruction.md)、[推导](tasks/sp-01/solution/README.md)、[验收记录](checks/sp-01-validation.md)。

**qm-01：非对称双 δ 势阱的束缚态与空间局域化。** 恢复全部负能态及左半轴概率，处理近阈值浅态和非对称混合。弱耦合基线误差 41.8244，完整参考约 1.00e-13；11 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/qm-01/instruction.md)、[推导](tasks/qm-01/solution/README.md)、[验收记录](checks/qm-01-validation.md)。

**ed-01：点电荷与介质核壳球的反作用、自力反号及径向平衡。** 由多极边界匹配计算极化能、自力和全部径向平衡点，以尾界保证近表面收敛。偶极基线误差 65.6807，完整参考约 8.16e-10；14 项 Linux 检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/ed-01/instruction.md)、[推导](tasks/ed-01/solution/README.md)、[验收记录](checks/ed-01-validation.md)。

## 目录

```text
tasks/       Harbor 任务；每题含题面、环境、参考解和 verifier
checks/      出处、校准、材料划分与验收证据
runs/        已保存的 Harbor 运行记录
planning/    教材 OCR 索引和选题笔记
tools/       本地制作与检查工具
```

Agent 镜像只带该题的公开材料；`solution/` 与 `tests/private/` 供参考解及独立 verifier 使用。原始教材保留在原路径，题包不附扫描教材或习题答案页。

<class 'dict'>
{"name": "TheoryPhysicsBench：新增20道量子场论任务遴选", "schema_version": 1, "status": "selected_for_development_not_frozen", "research_goal": "在受控量子场论模型中，从理论约束与公开材料构造可计算方案，辨别物理分支、近似适用性和数值伪解，以独立物理量验证推断。", "scope": "原30题开发计划保留；本清单新增qft-06至qft-25，不是课程正式benchmark.json。", "difficulty_status": "按理论工作量与研究判断筛选，尚无课程统一Codex三次测评难度结果。", "resource_plan": {"cpu": 4, "memory_gib": 4, "gpu": 0, "agent_timeout_seconds": 1200, "verifier_timeout_seconds": 120, "measured": false}, "sources": {"R": {"author": "Voja Radovanović", "title": "Problem Book in Quantum Field Theory", "edition": "Second Edition, 2008", "path": "/Users/ai4s/Downloads/Problem Book in Quantum Field Theory.pdf", "sha256": "26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db", "review": "planning/qft-expansion-radovanovic-review.md"}, "G": {"author": "François Gelis", "title": "Problems in Quantum Field Theory", "path": "/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf", "sha256": "7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5", "review": "planning/qft-expansion-gelis-review.md", "thermal_review": "planning/qft-expansion-gelis-thermal-review.md", "page_warning": "PDF章节重排，页码按实际文件逐段登记，不用全书统一偏移。"}}, "tasks": [{"id": "qft-06", "title": "Goldstone 模式的一圈质量保护与漏图诊断", "source": "R", "problems": ["11.8"], "pages": [{"pdf": [65, 65], "printed": [63, 63], "role": "题面"}, {"pdf": [219, 220], "printed": [221, 222], "role": "解答"}], "reading": "完整题面与相关解答已核读；关键原页已视觉核对。", "original_work": "移位后的两标量模型中枚举五类一圈贡献，含真空tadpole，用同一正则化和真空条件证明Σπ(0)=0。", "task_design": "从公开拉氏量和图拓扑重建各图系数，计算零动量抵消证书和空间样动量处的有限响应；诊断三组删图或错因子方案产生的伪质量。", "public_materials": "固定模型、顶点归一化、欧氏外动量、共同减除方案和待诊断方案；不公开正确系数表。", "deliverables": ["各图master-integral系数", "零动量抵消与真空条件残差", "有限动量响应", "错误方案的伪质量及故障位置"], "verification": ["独立Wick组合与符号系数核算", "高精度参数积分及对称性关系交叉检查"], "baseline": "逐图直接积分但使用有限精度和朴素减除；漏图模型只作错误对照，不充当故意降分的基线。", "difficulty": "图组合、真空移位、对称因子与对称性约束必须同时自洽，背诵Goldstone定理不能完成非零动量结果。", "independence": "区别既有真空极化阈值、树图Ward检查及qft-12的非微扰有效势。", "implementation_gate": "独立核对全部五图系数、有限响应的UV减除与合法等价表示。"}, {"id": "qft-07", "title": "赝标量 Yukawa 理论的反项闭合与有限振幅", "source": "R", "problems": ["11.12"], "pages": [{"pdf": [66, 66], "printed": [64, 64], "role": "题面"}, {"pdf": [225, 231], "printed": [227, 233], "role": "解答"}], "reading": "完整题面与解答已核读；关键原页已视觉核对。", "original_work": "由幂计数及一圈费米子/标量两点、Yukawa三点和标量四点图，构造闭合的局域反项，包括费米盒图排列和耦合混合。", "task_design": "判断几个候选算符基是否重整化闭合，独立提取全部UV极点多项式，构造明确MS方案下的有限欧氏响应，定位删除φ⁴反项后的剩余发散。", "public_materials": "拉氏量、γ5与维数约定、非例外运动学、允许算符和图枚举规则。", "deliverables": ["发散振幅及最小反项基", "UV极点系数", "有限两点/三点/四点响应", "方案闭合性证书"], "verification": ["Gamma函数Laurent展开及独立Dirac迹/排列计数", "独立参数积分和改变减除尺度的一致性检验"], "baseline": "直接维数积分加低阶参数求积的完整一圈起点。", "difficulty": "多场结构、闭费米环符号、γ5和六个盒图排列共同决定反项混合；不拆小问计题。", "independence": "qft-03只演化已给beta函数，本题从图构造反项；六维φ³不同时入选。", "implementation_gate": "固定ε和MS约定，重新推导不能机械抄用书中的质量壳有限项。"}, {"id": "qft-08", "title": "二维 Schwinger 模型的质量生成与守恒源响应", "source": "R", "problems": ["11.13"], "pages": [{"pdf": [66, 66], 
QFT04 ['tasks/qft-04/tests', 'tasks/qft-04/solution', 'tasks/qft-04/instruction.md', 'tasks/qft-04/environment', 'tasks/qft-04/task.toml', 'tasks/qft-04/tests/development_cases.py', 'tasks/qft-04/tests/quality_score.py', 'tasks/qft-04/tests/private', 'tasks/qft-04/tests/metric.json', 'tasks/qft-04/tests/test.sh', 'tasks/qft-04/tests/score.py', 'tasks/qft-04/solution/baseline.py', 'tasks/qft-04/solution/solve.sh', 'tasks/qft-04/solution/README.md', 'tasks/qft-04/solution/solver_core.py', 'tasks/qft-04/solution/solve.py', 'tasks/qft-04/environment/requirements.txt', 'tasks/qft-04/environment/Dockerfile', 'tasks/qft-04/environment/.dockerignore', 'tasks/qft-04/environment/public', 'tasks/qft-04/tests/private/truth.json', 'tasks/qft-04/environment/public/model.json', 'tasks/qft-04/environment/public/feedback.py', 'tasks/qft-04/environment/public/physics.py', 'tasks/qft-04/environment/public/metric.json']
MATERIALS ['../../00-老师原始材料/科研探索课程项目/附件一_Benchmark制作与提交指南.pdf', '../../00-老师原始材料/科研探索课程项目/tools', '../../00-老师原始材料/科研探索课程项目/附件二_评分与验收规则.pdf', '../../00-老师原始材料/科研探索课程项目/.DS_Store', '../../00-老师原始材料/科研探索课程项目/附件一_Benchmark制作与提交指南.md', '../../00-老师原始材料/科研探索课程项目/附件三_科研任务示例教程.pdf', '../../00-老师原始材料/科研探索课程项目/课程大作业说明.pdf', '../../00-老师原始材料/科研探索课程项目/template', '../../00-老师原始材料/科研探索课程项目/附件二_评分与验收规则.md', '../../00-老师原始材料/科研探索课程项目/课程大作业说明.md', '../../00-老师原始材料/科研探索课程项目/examples', '../../00-老师原始材料/科研探索课程项目/附件三_科研任务示例教程.md']

exit_code=0
```

### 2026-11-16T21:56:57.901192+08:00

```bash
python3 -c 'from pathlib import Path; import json; fs=["../../00-老师原始材料/科研探索课程项目/附件一_Benchmark制作与提交指南.md","../../00-老师原始材料/科研探索课程项目/附件二_评分与验收规则.md","tasks/qft-04/task.toml","tasks/qft-04/environment/Dockerfile","tasks/qft-04/tests/score.py","tasks/qft-04/tests/test.sh","tasks/qft-04/tests/development_cases.py","tools/run_qft04_checks.py","tools/build_qft04_truth.py"]; [(print("FILE",f),print(Path(f).read_text())) for f in fs]; d=json.loads(Path("planning/qft-expansion-20-selection.json").read_text()); print(json.dumps(d["tasks"][:7],ensure_ascii=False,indent=2))'
```

```text
FILE ../../00-老师原始材料/科研探索课程项目/附件一_Benchmark制作与提交指南.md
# 附件一：Benchmark制作与提交指南

这份指南从选题讲到提交，配合材料包中的`template/`和`tools/`使用。作业要求见[主说明](课程大作业说明.md)，评分规则见[附件二](附件二_评分与验收规则.md)。建议先选一道代表性题目走完全流程，再扩展成整套题集。

**制作顺序：确定研究目标 → 写题面 → 准备探索与验证材料 → 跑通基线和参考解 → 封装与检查 → 冻结 → 三次正式测评与提交。**

| 谁或什么 | 做什么 |
|---|---|
| 出题小组 | 选择研究问题，准备题面、材料、参考解和评分程序 |
| Codex（Agent） | 阅读公开材料，探索并提交解答 |
| 评分程序（verifier） | 作答结束后独立检查实际产物，计算本题指标 |
| Harbor | 为每次作答建立运行环境，作答结束后启动评分程序 |
| 助教 | 复核题目与评分，在独立环境中重新测评 |

<a id="topic"></a>

## 一、从研究主题组织题集

主题应落到具体的研究能力，例如实验选择、模型辨识、竞争解释、材料互证、统计分析、推导构造或算法改进。以“带噪声实验曲线的参数研究”为例：

| 需要设计的内容 | 示意 |
|---|---|
| 共同能力目标 | 面对带噪声的实验曲线，选择合理方法估计参数并检验模型 |
| 10至20道，至少10道有效 | 来自不同反应体系、观测条件或研究约束的独立实例 |
| 每题公开材料 | 反应模型与单位、开发曲线、拟合起点、开发误差命令 |
| 每题研究选择 | 怎样利用约束、选择初始化和拟合方法 |
| 每题交付 | 读取该题新曲线并输出参数的程序 |
| 每题最终验证 | 用预先留出的曲线重算误差并检查参数约束 |
| 整套结果分析 | 哪类体系表现较好，哪些条件下失败，参考方法的优势在哪里 |

**怎样判断题目独立。** 每题有自己的研究材料、待解决问题、参考结果和评分依据，能单独启动Codex作答。各题可以共享数据来源、工具、容器、参考方法和评分代码。两道曲线题分别研究不同反应体系、需要判断不同的参数约束，可以算两道题；同一条曲线只换随机种子、文件名或提示词，或者一道题里的多个小问、多条留出测试曲线，都只算一道题。

在 `benchmark.json` 中登记题目ID、路径、名称与研究差异；相近任务、来源和本组贡献的比对材料放在 `checks/`。

<a id="instruction"></a>

## 二、写一份能开始做的题面

`instruction.md`是Codex收到的任务说明，应让它独立收到后就能开始做。模板按下面六栏组织：

| 栏目 | 写清楚什么 | 曲线参数研究的例子 |
|---|---|---|
| 研究问题 | 背景、已知条件、待作出的研究选择 | 从带噪声曲线估计反应参数，检验估计是否稳定 |
| 材料与工具 | 容器内路径、字段、单位、工具及最小用法 | 提供反应模型、开发曲线和数据读取例子 |
| 探索反馈 | 从哪里起步，可以改什么，运行后看到什么 | 运行常规拟合，得到开发曲线误差和约束检查结果 |
| 最终产物 | 文件位置、接口、字段与有效值 | 提交读取新曲线并输出参数的程序 |
| 评价办法 | 主指标、固定条件、最终验证与容差 | 在留出曲线上重算误差，同时检查参数范围 |
| 时间与资源 | Agent、执行和评分的时限与硬件需求 | 使用CPU，明确单题探索和评分时限 |

专业概念解释到完成任务所需的程度，单位、符号和数据含义写在材料旁边。起点命令要在干净环境中实际运行一次，确认能返回可用反馈。完整的任务示例见[附件三](附件三_科研任务示例教程.md)。

<a id="validation"></a>

## 三、准备探索材料与最终验证

先想清楚要测什么：方法能否处理新情况，还是一个给定问题能否被解决。

- **检验方法能否处理新样本**：公开开发材料、起点和反馈办法，在未用于调参的新案例上重算指标。按对象、时间或实验批次划分材料，检查近重复记录和未来信息泄漏；参考解与Codex都只用开发材料调参。
- **解决一个固定实例**（固定优化、单个问答、构造或证明）：可以公开完整题设，通过独立执行、重算或核对证据、约束、证书来检验。

例如研究“新曲线上的参数估计”时，开发曲线用于选方法和调参，留出曲线检验泛化；研究“一条给定曲线是否存在两组同样合理的参数解释”时，可以公开这条曲线，用复算和约束检查核验论证。

公开材料应支持一次有用的尝试与反馈，例如开发误差命令、开发集分数、实验接口（写清返回内容和查询上限，并保存记录）、资料索引或约束检查。各类材料的可见范围如下：

| 材料 | 出题小组 | 正式作答的Codex | 助教 |
|---|---|---|---|
| 题面、公开数据、工具与开发反馈 | 可见 | 可见 | 可见 |
| 指标、评分规则、基线值/参考值与容差 | 可见 | 可见 | 可见 |
| 完整参考解、报告、检查记录 | 可见 | 不提供 | 可见 |
| 最终测试中保密的案例或答案 | 仅用于最终验证 | 不提供 | 可见 |

材料怎样划分、谁能访问、最终验证覆盖什么，写入`checks/`。最终测试答案只由评分环境读取，候选程序与答案隔离执行。

<a id="reference"></a>

## 四、准备基线、专家参考与评分器

| 部分 | 用途 | 曲线题中的例子 |
|---|---|---|
| 简单基线 | 合理、容易实现的起点 | 常规拟合程序 |
| 专家参考解 | 相同条件下效果较好的方案 | 利用物理约束的拟合程序 |
| 评分器 | 读取或运行产物，独立计算主指标 | 对照最终答案重算参数误差 |

- 每题须有可复核的专家参考解，可以由本组完成，也可以采用公开专家方案并注明来源。定量题提供方法、代码与结果；定性题提供研究分析、证据出处与评分要点。
- 定性题同样需要简单基线，例如只整理直接事实与出处的朴素答案。基线与专家参考用同一评分流程，得到本题的b、h。
- 定性题评分看证据定位、事实与计算、推论和关键材料处理，允许有充分依据的不同结论；文采、立场和与参考文字的相似度不作为主要标准。评分流程须可执行，把公开的分项标准汇总成原始指标。采用AI评分时，固定评分模型、版本、提示与输出格式，提供评分代码并保存逐项依据。
- 输出格式、成功条件、容差和多案例汇总办法提前确定，登记在 `tests/metric.json`。

### 填写本题指标

| 字段 | 填写方式 |
|---|---|
| `kind` | `binary`：能否完成；`continuous`：质量有高低 |
| `metric_name`、`unit` | 原始主指标与单位，如平均参数误差、%、秒或证据评分 |
| `direction` | 连续题填 `maximize` 或 `minimize` |
| `baseline`、`reference` | 实测简单基线b、专家参考h；二元题分别为0、1 |
| `tolerance` | 连续题的原单位容差及依据 |

先实测简单基线与专家参考，再填数值；b、h、x使用同一单位，7.6%填7.6。例如基线平均误差10%、参考误差2%，可以写成下面这样，容差按本题指标的实际精度确定：

```json
{
  "kind": "continuous",
  "metric_name": "平均参数误差",
  "unit": "%",
  "direction": "minimize",
  "baseline": 10.0,
  "reference": 2.0,
  "tolerance": 0.05
}
```

### 把评价办法写进评分程序

在`tests/score.py`的`evaluate()`中读取或运行实际产物，重算主指标，并输出支持判分的明细。模板随后调用统一的`quality_score.py`，生成`metrics.json`和`reward.txt`。两者方向相反：Harbor的reward越高，表示解答越好；课程计分用`metrics.json`中的原始指标计算难度系数，Codex越难做好，单题得分越高。

候选产物违反题意时，返回无效产物及具体原因；评分器本身出错时保留异常供排查。


<a id="packaging"></a>

## 五、封装任务并检查运行

### 运行时间与资源

- 全部题各运行一次为一轮，每轮累计≤12小时（43200秒），包括探索、方案执行和最终评分。各题提前登记Agent与verifier时限，整套时限之和不超过43200秒。基线与参考解各跑一轮，同样遵守此上限。
- 耗时逐题相加，平行执行也累计，正常API等待计入；首次环境构建和公共数据下载单独记录。
- GPU最多单块80GB A100（`gpus=1`、`gpu_types=["A100"]`），纯CPU任务设 `gpus=0`。写清CPU、内存、磁盘需求，固定依赖、数据版本、随机种子与容差。
- 可以用离线资料、数据回放、轻量模拟或统一提供的固定检查点开展研究。可在本机开发，正式测评使用Linux与Docker。

### 从模板建立任务目录

复制材料包中的 `template/` 并改名为 `group-XX`。模板提供10题骨架，最多扩展到20题；更新题目ID、`[task].name`和登记表，保持名称唯一。

```
group-XX/
├── benchmark.json     # 主题、题目ID、路径、名称与覆盖说明
├── tasks/
│   ├── task-01/
│   │   ├── instruction.md   # 本题公开题面，文中使用容器路径
│   │   ├── task.toml        # 时限、资源与产物路径
│   │   ├── environment/     # 依赖和公开材料
│   │   ├── solution/        # 本题完整参考解
│   │   └── tests/           # 评分程序、metric.json、最终验证材料（private/）
│   └── ...                  # 10至20个独立任务目录
├── 报告.md            # 正文最多4页
├── results.csv        # 学生正式测评，每题3行
├── checks/            # 逐题检查、来源、划分与公平性记录
└── runs/              # 全部原始运行记录
```

- 每个任务目录须能独立构建和运行；共用代码复制到所需目录，或通过固定版本的基础镜像提供。
- `environment/` 只放依赖和公开材料；参考解放在 `solution/`，最终答案放在 `tests/private/`。
- 模板以 `answer.json` 示范输出；改为提交程序或模型时，同步修改 `task.toml` 的artifacts与评分程序。
- 模板每题默认Agent 1200秒、verifier 600秒，可按研究需要重新分配。verifier默认无网络；评分需要联网（如AI评分）时，声明依赖、调整网络配置并写入复现说明，密钥由运行环境注入。
- `tests/quality_score.py` 是课程统一换算函数，保持原样。

题面使用容器内路径，对照关系如下：

| 提交包中的位置 | 运行时的用途 |
|---|---|
| `tasks/task-01/instruction.md` | 本题直接提供给Codex的题面 |
| `tasks/task-01/environment/public/demo.csv` | 构建后位于Agent容器 `/app/data/demo.csv` |
| `tasks/task-01/solution/solve.sh` | 参考解阶段执行 `/solution/solve.sh` |
| `tasks/task-01/tests/test.sh` | 评分阶段执行 `/tests/test.sh` |

### 先跑通参考解与空提交

在Linux主机准备Python 3.12及以上、uv和Docker。确认`python3 --version`为所需版本，启动Docker后运行以下命令（将路径替换为实际绝对路径）：

```bash
cd /absolute/path/group-XX
uv tool install 'harbor==0.24.0'
harbor run -p "$PWD/tasks" -a oracle \
  --n-attempts 1 --n-concurrent 1 --max-retries 0 \
  --jobs-dir "$PWD/runs/reference"
harbor run -p "$PWD/tasks" -a nop \
  --n-attempts 1 --n-concurrent 1 --max-retries 0 \
  --jobs-dir "$PWD/runs/empty"
```

`oracle` 逐题执行 `solution/solve.sh`，`nop` 检查空提交。第一次运行建议只选一题（`-p`改为该题目录并换新运行目录），打开评分记录中的 `metrics.json` 与 `reward.txt`，对照一个具体产物追踪“输入材料 → 输出 → 原始指标 → Harbor评分”。

### 检查评分是否反映真实质量

| 检查材料 | 要确认的结果 |
|---|---|
| 参考解 | 达到登记的参考表现，材料与执行资源符合要求 |
| 空提交 | 缺少有效产物时解题得分为0 |
| 实质错误解 | 格式正确但违反题意的结果被识别 |
| 合法替代解 | 不同方法或等价表示得到正常评分 |

每题都要跑通参考解和空提交，并检查本题特有的规则；错误解和合法替代解的检查可按评分器类型复用。命令、产物和检查结果放在 `checks/`。


<a id="run"></a>

## 六、冻结、正式测评与提交

### 冻结

开发试跑按第三节的材料划分进行，保存运行记录和选题调整依据。完成来源、近重复、评分与参考解检查后，可以集中补正一次，然后冻结整套题集的题目、版本、指标、参考解、时限和Codex配置。冻结后每题从相同的公开起点、新会话和干净工作区独立作答3次，全部正式记录纳入结果。

### 预检、正式测评与汇总

```bash
cd /absolute/path/科研探索课程项目
python3 tools/检查提交.py /absolute/path/group-XX            # 结构预检，输出整套及逐题哈希
bash tools/正式测评.sh /absolute/path/group-XX /absolute/path/course.env   # 每题3次
python3 tools/汇总结果.py /absolute/path/group-XX            # 生成 results.csv
python3 tools/检查提交.py /absolute/path/group-XX --final    # 最终检查
```

- `course.env` 由 `tools/course.env.example` 另存，设置 `MODEL=gpt-6.1-sol`、`REASONING_EFFORT=max` 和助教发布的 `CLI_VERSION`，密钥通过运行环境配置。
- 测评脚本按登记表每题运行3次，单并发、无自动重试，写入 `runs/codex/`；目录已存在时停止。
- 汇总工具发现异常、缺记录或分数矛盾时会列出位置并停止，按[附件二第五节](附件二_评分与验收规则.md#failures)处理后再做最终预检。
- 提交整个 `group-XX` 目录的压缩包，清理其中的密钥；引用的代码和数据保留来源与许可。

### 报告

`template/报告.md` 提供空表，正文最多4页；题面、长命令和日志留在任务包中，用路径引用。开头写小组名、benchmark名称和成员分工，正文分三部分：

1. **主题与原创设计**：共同科研目标与研究场景；各题覆盖的研究对象、条件、证据或难点（索引见 `benchmark.json`）；最接近的已有benchmark、重合处、本组实质差异与价值，以及论文、数据、代码等来源。
2. **制作与验证**：公开材料与反馈、基线、参考解和评分程序如何组织；逐题指标b/h、方向、单位、容差；开发/最终材料划分与防泄漏办法，或固定实例、定性论证的核验办法；环境、数据版本、种子、资源与每轮耗时；各题检查记录。
3. **结果、分析与改进**：冻结版本与哈希；统一配置与运行日期；每题3次原始结果、难度系数及单题得分；结合具体产物或日志分析代表性的成功与失败，区分事实与待验证解释；局限与一项具体改进；异常与额外尝试的原因、处理和记录路径。


<a id="fields"></a>

## 七、登记与结果字段速查

**benchmark.json**：`name`、`research_goal`（整套名称与共同科研能力目标）；`tasks` 数组为10至20项，每项填 `id`（稳定唯一）、`path`（固定为 `tasks/ID`）、`title`、`coverage`（研究对象或难点，与其他题的实质差异）。

**results.csv / ta_results.csv**：

| 字段 | 填写方式 |
|---|---|
| `task_id` | 与冻结登记表一致 |
| `config` | 学生为 `codex`；助教为 `ta_codex` |
| `run` | 每题恰好1、2、3 |
| `raw_metric` | 评分器计算的原始值，缺少时填null |
| `score` | 由原始指标换算的Harbor解答表现，越好越高 |
| `seconds` | Agent执行与verifier耗时之和 |
| `trial_dir` | 指向 `runs/` 下原始运行目录的相对路径 |
| `status` | `completed`、`invalid`（无效产物）、`agent_error`、`timeout`；后三种Harbor解答表现为0 |

所有题run=1的耗时之和为第1轮累计，各轮≤43200秒。助教结果写入`ta_results.csv`和`runs/ta-codex/`。


<a id="sources"></a>

## 进一步阅读

这些材料可帮助理解公开起点、探索反馈、最终测试与独立复现的组织方式。

- [RE-Bench](https://arxiv.org/html/2411.15114)：公开起点、探索评估与最终测试。
- [MLE-bench](https://arxiv.org/html/2410.07095v1)：题目、数据、提交与最终评价。
- [PaperBench](https://arxiv.org/html/2504.01848v1)：提交后在新环境中独立复现。
- [Harbor评分器文档](https://docs.harborframework.com/tasks/verifier)：评分入口和reward，课程使用0.24.0。

FILE ../../00-老师原始材料/科研探索课程项目/附件二_评分与验收规则.md
# 附件二：评分与验收规则

本附件说明成绩怎样计算、助教怎样验收复测，以及失败和故障怎样处理。任务制作与运行命令见[附件一](附件一_Benchmark制作与提交指南.md)。

满分100分：**完整性30分＋创新性20分＋题目数量与难度50分。** 前两项评价整套benchmark；第三项逐题计算，最终采用助教每题3次复测的结果，学生自测结果用于分析和预估。

<a id="manual-scores"></a>

## 一、完整性与创新性

### 完整性（30分）

| 项目（各10分） | 主要依据 |
|---|---|
| 题集与实验设计 | 主题明确、覆盖有依据；逐题研究选择、公开材料、指标与最终验证合理；公平性和评分检查充分 |
| 复现与交付 | 全部任务在规定条件下独立运行，参考解可复核；代码、数据、环境与每题3次记录完整 |
| 报告与结果分析 | 整体与逐题结果清楚，结合实际产物解释差异，分析典型成功与失败、局限及改进 |

每项以0、5、10分为参考，分别对应核心工作缺失或无法核查、基本完成但有明显不足、充分可靠，可给中间分。

### 创新性（20分）

| 参考分 | 大体标准 |
|---|---|
| 20 | 围绕真实科研需求形成鲜明的题集设计，并用题目、产物或实验说明新增检验价值 |
| 15 | 新增的研究选择、约束、覆盖范围或验证目标明确，与相近benchmark的差异及作用说明充分 |
| 10 | 有合理、可辨认的本组设计，新增研究内容或检验价值较有限 |
| 0 | 本组设计贡献缺少有效说明或依据 |

报告中按“最近已有benchmark - 本组实质差异 - 新增价值及证据”说明贡献，并落实到具体题目。助教可在参考档之间给分。


<a id="quality"></a>

## 二、题目数量与难度（50分）

最多20道题计分，每道有效题得1至2.5分。想拿高分只有两条路：多出有效题，提高题目难度；20道困难题即可拿满50分。

> 单题得分 Sᵢ = 1 + 1.5 × Dᵢ（Dᵢ为难度系数，取0至1，题目越难越接近1）
>
> 题目总分 = S₁ + S₂ + … + Sₙ（n为有效题数，n ≤ 20）

| 题目 | Codex的表现 | 难度系数 | 单题得分 |
|---|---|---|---|
| 简单题 | 达到或超过专家参考 | 0 | 1分 |
| 中等题 | 完成基线到专家参考之间一半的改善 | 0.5 | 1.75分 |
| 困难题 | 只达到基线或更差 | 1 | 2.5分 |
| 无效题 | 未通过质量验收 | — | 0分 |

计分遵守四条规定：

1. **登记10至20题。** 至少10道为有效独立题；登记表最多20题，表外的题目不参与计分。
2. **有效题越多，分数越高。** 20题以内，每多一道有效题至少多1分。
3. **题目越难，分数越高。** 难度系数由基线、专家参考和助教的3次Codex复测计算，方法见下文。
4. **计分题目提前冻结。** 冻结登记的题目全部计分，不允许看到测试结果后替换题目，也不允许从更多题中挑出得分最高的20道。

### 难度系数怎样计算

先对助教每次复测的原始指标计算难度系数，再取三次平均。简单基线为b、专家参考为h、Codex某次结果为x，三者使用同一指标和单位。将公式结果限制在0至1之间：

| 题目指标 | 单次难度系数 |
|---|---|
| 越大越好，如准确率 | clip((h−x)÷(h−b), 0, 1) |
| 越小越好，如误差 | clip((x−h)÷(b−h), 0, 1) |
| 二元题：能否完成 | 完成为0；未完成为1 |

`clip(..., 0, 1)`表示低于0按0、高于1按1。有效题的无效产物、Agent错误或超时，单次难度系数为1；平台和评分故障按第五节处理。连续指标先分别截断，再取三次平均；多个最终案例先汇总原始指标。专家参考相对基线的改善须超过容差。

### 用一道题算一遍

基线误差10%，专家参考误差2%，Codex三次误差为7.6%、6.8%、6.0%，误差越小越好：

| 复测 | 难度系数 |
|---|---|
| 第1次 | (7.6−2)÷(10−2) = 0.7 |
| 第2次 | (6.8−2)÷(10−2) = 0.6 |
| 第3次 | (6.0−2)÷(10−2) = 0.5 |

平均难度系数为0.6，**本题得分＝1＋1.5×0.6＝1.9分**。

不同题数和难度下的题目总分：

| 有效题数 | 全部简单 | 全部中等 | 全部困难 |
|---|---|---|---|
| 10 | 10分 | 17.5分 | 25分 |
| 15 | 15分 | 26.25分 | 37.5分 |
| 20 | 20分 | 35分 | 50分 |

例如10道有效题的平均难度系数都是0.6，题目总分为19分；再加完整性26分、创新性16分，总分为61分。

<a id="integrity"></a>

## 三、原创性与公平性

### 原创与复用

原创性看整套benchmark的研究目标、题目组织、材料设计和能力检验。可以使用公开论文思路、算法、数据、代码和Harbor框架，但要保留来源。

| 做法 | 判断 |
|---|---|
| 设计有明确研究目标的题集，选择有实质差异的实例 | 符合要求，说明覆盖范围与本组贡献 |
| 共用工具、环境、参考方法和评分代码 | 可以复用，各题材料与结果分别核验 |
| 同一实例只换种子、数字、名称、格式或近重复材料 | 不增加有效题数 |
| 翻译已有benchmark题，或仅加Harbor外壳 | 不构成原创 |
| 未注明挪用他人题面、核心设计、代码或结果 | 属于抄袭 |

报告说明最接近的已有任务、本组的实质差异和证据；未找到相近任务时，记录检索关键词与范围。助教会逐题核对来源，疑似抄袭的证据交给小组说明，经两位助教共同确认后，**整份大作业记0分**。照搬现有题或课程示例、仅作表面修改的，同样处理。判断以实质内容为依据，文字相似率只用作检索线索。

### 公平比较

参考解与Codex使用相同的任务信息、执行资源和最终评分办法。参考方案提前开发，注明来源和工具使用。以下做法属于不公平：

- 读取最终标签、按隐藏案例编号回填答案，或将答案混入训练数据；
- 只给参考方案额外数据、私有服务或未申报算力；
- 只认参考答案的字面写法，误拒等价正确解，或绕过实际产物伪造分数；
- 换弱模型、挑选失败记录、伪造运行记录，看到结果后删题、换题或改指标、种子和阈值；
- 用接近参考的强方案充当“简单基线”，压小计分公式的分母；
- 在正式作答会话中提供参考解、隐藏答案或其他题的作答记录。

两位助教核实并听取小组说明后，确认故意操纵且实质影响结果的，**整份大作业记0分**。


<a id="acceptance"></a>

## 四、助教验收与复测

两位助教分工完成全量验收：主审逐题检查并组织复测，另一位复核验收记录与成绩；争议、异常和违规由两人共同核实。助教可以用AI辅助阅读材料、检索和查代码，结论以可核查的来源、产物与复测记录为准。

| 验收项目 | 对全部题目执行的检查 |
|---|---|
| 创新性与来源 | 检索相近benchmark、任务、数据和代码，核对本组差异与题间近重复 |
| 研究质量与独立性 | 确认科研用途和研究选择，核实有效独立题数 |
| 题面与材料 | 只凭公开资料核对输入、工具、反馈、输出、指标和时限 |
| 基线与参考 | 在干净环境复跑基线、参考解与空提交；定性题逐项核查证据与论证要点 |
| 评分与最终验证 | 检查实际产物、四类评分检查与本题特有规则，核对数据划分、标签隔离或固定实例的核验办法 |
| 学生记录 | 核对3次运行的配置、日志、产物、原始指标、Harbor评分与耗时 |

每题保留验收结论、证据路径和复测记录；完整性三项与创新性各写一两句评分依据。

### 独立复测

助教按冻结题集对每题独立运行3次Codex，每次使用相同的公开起点、新会话与干净工作区。做题的Codex只接收公开材料。在材料包根目录执行：

```bash
bash tools/正式测评.sh /absolute/path/group-XX /absolute/path/course.env --ta
python3 tools/汇总结果.py /absolute/path/group-XX --ta
python3 tools/检查提交.py /absolute/path/group-XX --final --ta
```

结果写入 `runs/ta-codex/` 和 `ta_results.csv`（每题3行），与学生记录分开保存。

默认组内同分；贡献明显失衡时，由两位助教核实调整并说明依据，学生可按具体条目申诉。


<a id="failures"></a>

## 五、失败、故障与补正

| 情况 | 处理 |
|---|---|
| 题目有效，Codex无有效产物、违反约束、报错或超时 | 该次难度系数计1，保留原因；缺少原始指标填null |
| 平台/API、机器、依赖或评分程序故障 | 保存原记录，修复后按统一条件补跑或重评 |
| 题目无法公平验证、参考不可复现或无有效提升 | 该题无效，得0分，保留原始记录 |
| 缺题或近重复题 | 同上 |
| 经两位助教确认的抄袭或故意操纵 | 整份记0分 |

冻结后保留全部题目及有效失败，禁止事后替换或择优计分。评分程序有实现错误时，按原协议统一重评受影响的产物；错误影响了Agent作答的，统一重跑受影响的运行，并记录版本与原因。实质改变题意、材料或目标的修改，该题按无效处理。

### 自动汇总停止后怎样处理

1. **核实原因。** 保留原日志和产物，把任务ID、run编号、原trial路径、异常依据和处理结论记入`checks/`，交助教核实。
2. **有效失败保留原记录。** 有效的超时或Agent错误，`status`填`timeout`或`agent_error`，`score`填0，没有原始指标时`raw_metric`填null。
3. **故障只补受影响的那一次。** 仅评分出错时，重评原产物并另存重评记录；需要重新作答时，单独补跑该次运行，并登记“原trial → 替代trial”。
4. **整理CSV后做最终预检。** 每题run仍为1、2、3，分别指向有效失败的原trial、故障后的替代trial或正常记录；`seconds`填Agent与verifier实际耗时之和（仅重评时用原Agent耗时加新verifier耗时）。然后运行`检查提交.py --final`，助教加`--ta`。

补跑沿用冻结配置。例如学生补跑`task-01`第2次：

```bash
cd /absolute/path/group-XX
source /absolute/path/course.env
harbor run -p "$PWD/tasks/task-01" -a codex -m "$MODEL" \
  --ak "version=$CLI_VERSION" --effort "$REASONING_EFFORT" \
  --n-attempts 1 --n-concurrent 1 --max-retries 0 \
  --jobs-dir "$PWD/runs/codex/retry-task-01-run-2"
```

助教补跑把最后一行改为`runs/ta-codex/`内的新目录。CSV的`trial_dir`填实际trial目录相对小组根目录的路径，例如`runs/codex/retry-task-01-run-2/<job>/<trial>`。所有尝试均留档。

FILE tasks/qft-04/task.toml
schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/qft-04"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 1200.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "no-network"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0

FILE tasks/qft-04/environment/Dockerfile
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2

COPY requirements.txt /tmp/requirements.txt
RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
 && useradd --uid 1000 --create-home student \
 && mkdir -p /app/data /app/output \
 && chown -R student:student /app

COPY public/ /app/data/
WORKDIR /app
USER student

FILE tasks/qft-04/tests/score.py
import json
import os
from pathlib import Path
import sys
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get('TASK_DATA_ROOT','/app/data'));private=Path(private_root or os.environ.get('TASK_PRIVATE_ROOT','/tests/private'))
    sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    model=load_model(data);parsed,reason=validate_answer(answer,model)
    if reason:return None,{'reason':reason}
    truth=json.loads((private/'truth.json').read_text());scoring=model['scoring'];floor=scoring['relative_floor'];details=[]
    def relative(actual,expected):return min(1,abs(actual-expected)/max(floor,abs(expected)))
    for expected in truth['cases']:
        actual=parsed['cases'][expected['id']]
        parts={name:relative(actual[name],expected[name]) for name in ('sigma','accepted_sigma','acceptance')}
        for name in ('mean_energy','energy_quantiles','accepted_cos_interval'):
            a,b=actual[name],expected[name]
            if a is None or b is None:parts[name]=float(a!=b)
            elif name=='accepted_cos_interval':parts[name]=sum(min(1,abs(x-y)/2) for x,y in zip(a,b))/2
            elif isinstance(b,list):parts[name]=sum(relative(x,y) for x,y in zip(a,b))/len(b)
            else:parts[name]=relative(a,b)
        error=sum(scoring['case_parts'][name]*value for name,value in parts.items());details.append({'id':expected['id'],'error':error,'parts':parts})
    probe_details=[]
    for expected in truth['probes']:
        actual=parsed['probes'][expected['id']]
        errors={name:min(1,abs(actual[name]-expected[name])/max(scoring['probe_floor'],abs(expected[name]))) for name in ('s_squared','u_squared','interference','total','gauge_shifted_total')}
        probe_details.append({'id':expected['id'],'error':sum(errors.values())/len(errors),'parts':errors})
    error=scoring['case_weight']*sum(x['error'] for x in details)/len(details)+scoring['probe_weight']*sum(x['error'] for x in probe_details)/len(probe_details)
    return 100*error,{'cases':details,'probes':probe_details}


def main():
    logs=Path(os.environ.get('VERIFIER_LOG_ROOT','/logs/verifier'));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get('TASK_TESTS_ROOT','/tests'));answer=Path(os.environ.get('TASK_ANSWER_PATH','/app/output/answer.json'));metric=json.loads((tests/'metric.json').read_text())
    try:payload=json.loads(answer.read_text())
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{'reason':'没有有效 JSON 产物'}
    else:raw,details=evaluate(payload)
    status='invalid' if raw is None else 'completed';score=quality_score(metric,raw,status)
    details.update(raw_metric=raw,score=score,status=status)
    (logs/'metrics.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n');(logs/'reward.txt').write_text(f'{score}\n')


if __name__=='__main__':main()

FILE tasks/qft-04/tests/test.sh
#!/bin/bash
set -euo pipefail
python3 "$(dirname -- "$0")/score.py"

FILE tasks/qft-04/tests/development_cases.py
import copy


def make_cases(reference):
    names=('equivalent','wrong','no_interference','no_boost','wrong_quantile_order','fake_nonempty','false_empty','duplicate','boolean','nonfinite','missing_empty_field','huge_integer')
    cases={name:copy.deepcopy(reference) for name in names};cases['malformed']={}
    cases['equivalent']['cases'].reverse();cases['equivalent']['probes'].reverse()
    for item in cases['wrong']['cases']:item['sigma']*=5;item['accepted_sigma']*=5
    for item in cases['no_interference']['probes']:
        item['interference']=0;item['total']=item['s_squared']+item['u_squared'];item['gauge_shifted_total']=item['total']*2
    for item in cases['no_boost']['cases']:
        if item['mean_energy'] is not None:item['mean_energy']*=2;item['energy_quantiles']=[q*2 for q in item['energy_quantiles']]
    # kn-07 has energy decreasing with rest-frame cos(theta): a CDF must be reversed.
    item=cases['wrong_quantile_order']['cases'][-1];item['energy_quantiles']=[item['energy_quantiles'][1]]*3
    item=cases['fake_nonempty']['cases'][5];item.update(accepted_cos_interval=[-1,1],accepted_sigma=1,acceptance=.5,mean_energy=.8,energy_quantiles=[.75,.8,.85])
    item=cases['false_empty']['cases'][4];item.update(accepted_cos_interval=None,accepted_sigma=0,acceptance=0,mean_energy=None,energy_quantiles=None)
    cases['duplicate']['cases'][1]=copy.deepcopy(cases['duplicate']['cases'][0])
    cases['boolean']['cases'][0]['sigma']=True
    cases['nonfinite']['probes'][0]['total']=float('inf')
    del cases['missing_empty_field']['cases'][5]['mean_energy']
    cases['huge_integer']['cases'][0]['sigma']=10**400
    return cases

FILE tools/run_qft04_checks.py
"""Local Linux calibration and physical regression checks for qft-04."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qft-04';DATA=TASK/'environment/public';TESTS=TASK/'tests'
sys.path.insert(0,str(TESTS))


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--calibrate',action='store_true');args=parser.parse_args()
    scorer=load('qft04_score',TESTS/'score.py');quality=load('qft04_quality',TESTS/'quality_score.py')
    answers={};cases={};runtime={}
    with tempfile.TemporaryDirectory(prefix='qft04-check-') as directory:
        temp=Path(directory)
        for name,script in (('baseline','baseline.py'),('reference','solve.py')):
            output=temp/f'{name}.json';started=time.perf_counter()
            subprocess.run([sys.executable,str(TASK/'solution'/script),'--data-root',str(DATA),'--output',str(output)],check=True,capture_output=True,text=True)
            runtime[f'{name}_seconds']=time.perf_counter()-started;answers[name]=json.loads(output.read_text())
        answers.update(load('qft04_cases',TESTS/'development_cases.py').make_cases(answers['reference']))
        answers['independent_truth']=json.loads((TESTS/'private/truth.json').read_text())
        for name,answer in answers.items():
            raw,detail=scorer.evaluate(answer,DATA,TESTS/'private');cases[name]={'raw_metric':raw,**detail,'status':'invalid' if raw is None else 'completed'}
        measured={'kind':'continuous','metric_name':'康普顿相干振幅与实验室接受能谱误差','unit':'百分点','direction':'minimize','baseline':cases['baseline']['raw_metric'],'reference':cases['reference']['raw_metric'],'tolerance':1e-6}
        metric=measured if args.calibrate else json.loads((TESTS/'metric.json').read_text());quality.validate_metric(metric)
        for item in cases.values():item['score']=quality.quality_score(metric,item['raw_metric'],item['status'])
        testroot=temp/'tests';testroot.mkdir();(testroot/'metric.json').write_text(json.dumps(metric));entries={}
        for name in ('reference','empty','missing_empty_field','huge_integer'):
            if name not in ('reference','empty'):(temp/f'{name}.json').write_text(json.dumps(answers[name]))
            logs=temp/f'logs-{name}'
            env=dict(os.environ,TASK_DATA_ROOT=str(DATA),TASK_PRIVATE_ROOT=str(TESTS/'private'),TASK_TESTS_ROOT=str(testroot),TASK_ANSWER_PATH=str(temp/f'{name}.json'),VERIFIER_LOG_ROOT=str(logs))
            subprocess.run(['bash',str(TESTS/'test.sh')],env=env,check=True,capture_output=True,text=True)
            entries[name]=json.loads((logs/'metrics.json').read_text())
        feedback=json.loads(subprocess.run([sys.executable,str(DATA/'feedback.py'),str(temp/'reference.json')],check=True,capture_output=True,text=True).stdout)
    checks={
        'reference_matches_independent_truth':measured['reference']<metric['tolerance'],
        'reference_improves_baseline':measured['baseline']-measured['reference']>metric['tolerance'],
        'registered_endpoints_match':all(abs(measured[k]-metric[k])<metric['tolerance'] for k in ('baseline','reference')),
        'baseline_zero_reference_one':cases['baseline']['score']==0 and cases['reference']['score']==1,
        'equivalent_order_same':cases['equivalent']['raw_metric']==cases['reference']['raw_metric'],
        'independent_truth_full_credit':cases['independent_truth']['score']==1,
        'wrong_physics_penalized':cases['wrong']['raw_metric']>measured['reference']+1,
        'missing_interference_penalized':cases['no_interference']['raw_metric']>measured['reference']+.1,
        'wrong_boost_penalized':cases['no_boost']['raw_metric']>measured['reference']+.1,
        'wrong_energy_quantiles_penalized':cases['wrong_quantile_order']['raw_metric']>measured['reference']+.01,
        'false_nonempty_penalized':cases['fake_nonempty']['raw_metric']>measured['reference']+.1,
        'false_empty_constant_spectrum_penalized':cases['false_empty']['raw_metric']>measured['reference']+.1,
        'invalid_answers_rejected':all(cases[n]['status']=='invalid' and cases[n]['score']==0 for n in ('duplicate','boolean','nonfinite','malformed','missing_empty_field','huge_integer')),
        'constant_energy_quantiles_correct':max(answers['reference']['cases'][4]['energy_quantiles'])-min(answers['reference']['cases'][4]['energy_quantiles'])==0,
        'empty_window_conditions_undefined':answers['reference']['cases'][5]['mean_energy'] is None and answers['reference']['cases'][5]['energy_quantiles'] is None,
        'ward_identity_total_invariant':all(abs(item['total']-item['gauge_shifted_total'])<1e-9 for item in answers['reference']['probes']),
        'verifier_reference_one_empty_zero':entries['reference']['score']==1 and entries['empty']['score']==0 and entries['empty']['status']=='invalid',
        'verifier_malformed_boundary_cases_zero':all(entries[n]['score']==0 and entries[n]['status']=='invalid' for n in ('missing_empty_field','huge_integer')),
        'public_feedback_works':feedback['valid'] and len(feedback['cases'])==7,
        'course_quality_score_unchanged':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
    }
    report={'metric':metric,'cases':cases,'runtime':{'platform':platform.platform(),'python':platform.python_version(),**runtime},'checks':checks,'verifier_entries':entries}
    print(json.dumps({'metric':metric,'scores':{k:{f:v[f] for f in ('raw_metric','score','status')} for k,v in cases.items()},'runtime':report['runtime'],'checks':checks},ensure_ascii=False,indent=2))
    if not all(checks.values()):raise SystemExit('qft-04 checks failed')
    if args.calibrate:
        for path in (DATA/'metric.json',TESTS/'metric.json'):path.write_text(json.dumps(metric,ensure_ascii=False,indent=2)+'\n')
    elif json.loads((DATA/'metric.json').read_text())!=metric:raise SystemExit('metric copies differ')
    (ROOT/'checks/qft-04-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    saved=ROOT/'runs/qft-04/development-answers';saved.mkdir(parents=True,exist_ok=True)
    for name,answer in answers.items():(saved/f'{name}.json').write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()

FILE tools/build_qft04_truth.py
"""Independent arbitrary-precision KN primitives and explicit-spinor amplitudes."""
import json
from pathlib import Path
import mpmath as mp

ROOT=Path(__file__).resolve().parents[1]
TASK=ROOT/'tasks/qft-04'


def scalar(value):return mp.mpf(str(value))


def build_case(case):
    x=scalar(case['x']);bn,bd=case['beta_fraction'];beta=mp.mpf(bn)/bd;gamma=1/mp.sqrt(1-beta*beta)
    A=1-2*(1+x)/x**2;B=(1+2*x)/x**2
    def primitive(c):
        t=1+x*(1-c)
        return -mp.pi/x*(A*mp.log(t)-B/t-1/(2*t*t)+t/x**2)
    def integral(a,b):return primitive(b)-primitive(a)
    def density(c):
        t=1+x*(1-c)
        return mp.pi/t**2*(t+1/t-(1-c*c))
    def energy(c):return gamma*x*(1+beta*c)/(1+x*(1-c))
    def costheta(theta):
        if abs(theta-mp.pi)<mp.mpf('1e-14'):return -mp.mpf(1)
        return mp.cos(theta)
    theta0,theta1=map(scalar,case['lab_theta_window'])
    inv=lambda mu:(mu-beta)/(1-beta*mu)
    left=max(-mp.mpf(1),inv(costheta(theta1)));right=min(mp.mpf(1),inv(costheta(theta0)))
    el,eh=map(scalar,case['lab_energy_window']);cuts=[left,right]
    D=x+beta*(1+x)
    if abs(D)<mp.mpf('1e-60'):
        valid=left<right and el<=energy(0)<=eh
    else:
        for e in (el,eh):
            denominator=x*(e+gamma*beta)
            if abs(denominator)>mp.mpf('1e-60'):
                crossing=(e*(1+x)-gamma*x)/denominator
                if left<crossing<right:cuts.append(crossing)
        cuts=sorted(cuts);segments=[(a,b) for a,b in zip(cuts[:-1],cuts[1:]) if a<b and el<=energy((a+b)/2)<=eh]
        valid=bool(segments)
        if valid:left,right=segments[0][0],segments[-1][1]
    total=integral(-1,1)
    # A separate direct integrator verifies the analytic primitive.
    total_quad=mp.quad(density,[-1,0,mp.mpf('.9'),mp.mpf('.99'),1])
    difference=abs(total-total_quad)
    result={'id':case['id'],'sigma':total}
    if not valid:return {**result,'accepted_sigma':mp.mpf(0),'acceptance':mp.mpf(0),'mean_energy':None,'energy_quantiles':None,'accepted_cos_interval':None},difference
    accepted=integral(left,right)
    mean=mp.quad(lambda c:density(c)*energy(c),[left,(left+right)/2,right])/accepted
    if abs(D)<mp.mpf('1e-60'):quantiles=[energy(0)]*3
    else:
        quantiles=[]
        for p in map(mp.mpf,('.1','.5','.9')):
            probability=p if D>0 else 1-p
            a,b=left,right
            for _ in range(230):
                c=(a+b)/2
                if integral(left,c)/accepted<probability:a=c
                else:b=c
            quantiles.append(energy((a+b)/2))
    return {**result,'accepted_sigma':accepted,'acceptance':accepted/total,'mean_energy':mean,'energy_quantiles':quantiles,'accepted_cos_interval':[left,right]},difference


def spinor_probes(probe):
    x=scalar(probe['x']);c=scalar(probe['cos_theta']);r=x/(1+x*(1-c));sn=mp.sqrt(1-c*c)
    pauli=[mp.matrix([[0,1],[1,0]]),mp.matrix([[0,-mp.j],[mp.j,0]]),mp.matrix([[1,0],[0,-1]])]
    g0=mp.diag([1,1,-1,-1]);gammas=[g0]
    for sigma in pauli:
        matrix=mp.zeros(4)
        for a in range(2):
            for b in range(2):matrix[a,b+2]=sigma[a,b];matrix[a+2,b]=-sigma[a,b]
        gammas.append(matrix)
    def slash(v):
        result=v[0]*gammas[0]
        for j in range(1,4):result-=v[j]*gammas[j]
        return result
    p=mp.matrix([1,0,0,0]);k=mp.matrix([x,0,0,x]);kp=mp.matrix([r,r*sn,0,r*c]);pp=p+k-kp
    def spinor(momentum,spin):
        chi=mp.matrix([int(spin==0),int(spin==1)])
        sigma_p=sum((momentum[j+1]*pauli[j] for j in range(3)),mp.zeros(2))
        top=mp.sqrt(momentum[0]+1)*chi;bottom=sigma_p*chi/mp.sqrt(momentum[0]+1)
        return mp.matrix([top[0],top[1],bottom[0],bottom[1]])
    incoming=[mp.matrix([0,1,0,0]),mp.matrix([0,0,1,0])]
    outgoing=[mp.matrix([0,c,0,-sn]),mp.matrix([0,0,1,0])]
    def parts(eta,zeta):
        values=[mp.mpf(0)]*3
        for ei in incoming:
            for eo in outgoing:
                inslash=slash(ei+eta*k/x);outslash=slash(eo+zeta*kp/r)
                s=outslash*(slash(p+k)+mp.eye(4))*inslash/(2*x)
                u=inslash*(slash(p-kp)+mp.eye(4))*outslash/(-2*r)
                for a in range(2):
                    for b in range(2):
                        initial=spinor(p,a);final=spinor(pp,b);bar=final.H*g0
                        ms=(bar*s*initial)[0];mu=(bar*u*initial)[0]
                        values[0]+=abs(ms)**2/4;values[1]+=abs(mu)**2/4;values[2]+=mp.re(ms*mp.conj(mu))/2
        return values
    ordinary=parts(0,0);shifted=parts(scalar(probe['incoming_gauge_shift']),scalar(probe['outgoing_gauge_shift']))
    expected=2*((r/x)+(x/r)-(1-c*c))
    check={'id':probe['id'],'ward_residual':str(abs(sum(ordinary)-sum(shifted))),'kn_residual':str(abs(sum(ordinary)-expected))}
    return {'id':probe['id'],'s_squared':ordinary[0],'u_squared':ordinary[1],'interference':ordinary[2],'total':sum(ordinary),'gauge_shifted_total':sum(shifted)},check


def serialize(value,digits=False):
    if value is None or isinstance(value,(str,bool,int)):return value
    if isinstance(value,dict):return {k:serialize(v,digits) for k,v in value.items()}
    if isinstance(value,list):return [serialize(v,digits) for v in value]
    return str(value) if digits else float(value)


def build(model,precision):
    with mp.workdps(precision):
        cases=[];differences=[]
        for item in model['cases']:
            result,error=build_case(item);cases.append(result);differences.append(str(error))
        probes=[];checks=[]
        for item in model['probes']:
            result,check=spinor_probes(item);probes.append(result);checks.append(check)
        return {'cases':serialize(cases,True),'probes':serialize(probes,True)}, {'primitive_quad_differences':differences,'amplitude_checks':checks}


def numbers(value):
    if isinstance(value,dict):return {k:numbers(v) for k,v in value.items()}
    if isinstance(value,list):return [numbers(v) for v in value]
    if isinstance(value,str):
        try:return float(value)
        except ValueError:return value
    return value


def compare(a,b):
    if isinstance(a,dict):return max([compare(a[k],b[k]) for k in a]+[mp.mpf(0)])
    if isinstance(a,list):return max([compare(x,y) for x,y in zip(a,b)]+[mp.mpf(0)])
    if a is None or isinstance(a,(bool,int)):return mp.mpf(0) if a==b else mp.inf
    try:return abs(mp.mpf(a)-mp.mpf(b))/max(1,abs(mp.mpf(a)))
    except ValueError:return mp.mpf(0) if a==b else mp.inf


def main():
    model=json.loads((TASK/'environment/public/model.json').read_text())
    truth,validation=build(model,70);check,_=build(model,45)
    with mp.workdps(80):difference=compare(truth,check)
    if difference>mp.mpf('1e-38'):raise ArithmeticError('precision cross-check failed')
    for item in validation['amplitude_checks']:
        if max(mp.mpf(item['ward_residual']),mp.mpf(item['kn_residual']))>mp.mpf('1e-60'):raise ArithmeticError('amplitude identity failed')
    for error in validation['primitive_quad_differences']:
        if mp.mpf(error)>mp.mpf('1e-60'):raise ArithmeticError('independent integral failed')
    (TASK/'tests/private/truth.json').write_text(json.dumps(numbers(truth),ensure_ascii=False,indent=2)+'\n')
    validation.update(precision_digits=70,recheck_digits=45,max_relative_precision_difference=str(difference),truth_digits=truth,method='analytic KN primitive with direct mp.quad check; exact rational beta, algebraic cut intersection, explicit-spinor amplitudes')
    (ROOT/'checks/qft-04-truth-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'max_relative_precision_difference':str(difference),'validation':{k:v for k,v in validation.items() if k!='truth_digits'},'truth':numbers(truth)},ensure_ascii=False,indent=2))


if __name__=='__main__':main()

[
  {
    "id": "qft-06",
    "title": "Goldstone 模式的一圈质量保护与漏图诊断",
    "source": "R",
    "problems": [
      "11.8"
    ],
    "pages": [
      {
        "pdf": [
          65,
          65
        ],
        "printed": [
          63,
          63
        ],
        "role": "题面"
      },
      {
        "pdf": [
          219,
          220
        ],
        "printed": [
          221,
          222
        ],
        "role": "解答"
      }
    ],
    "reading": "完整题面与相关解答已核读；关键原页已视觉核对。",
    "original_work": "移位后的两标量模型中枚举五类一圈贡献，含真空tadpole，用同一正则化和真空条件证明Σπ(0)=0。",
    "task_design": "从公开拉氏量和图拓扑重建各图系数，计算零动量抵消证书和空间样动量处的有限响应；诊断三组删图或错因子方案产生的伪质量。",
    "public_materials": "固定模型、顶点归一化、欧氏外动量、共同减除方案和待诊断方案；不公开正确系数表。",
    "deliverables": [
      "各图master-integral系数",
      "零动量抵消与真空条件残差",
      "有限动量响应",
      "错误方案的伪质量及故障位置"
    ],
    "verification": [
      "独立Wick组合与符号系数核算",
      "高精度参数积分及对称性关系交叉检查"
    ],
    "baseline": "逐图直接积分但使用有限精度和朴素减除；漏图模型只作错误对照，不充当故意降分的基线。",
    "difficulty": "图组合、真空移位、对称因子与对称性约束必须同时自洽，背诵Goldstone定理不能完成非零动量结果。",
    "independence": "区别既有真空极化阈值、树图Ward检查及qft-12的非微扰有效势。",
    "implementation_gate": "独立核对全部五图系数、有限响应的UV减除与合法等价表示。"
  },
  {
    "id": "qft-07",
    "title": "赝标量 Yukawa 理论的反项闭合与有限振幅",
    "source": "R",
    "problems": [
      "11.12"
    ],
    "pages": [
      {
        "pdf": [
          66,
          66
        ],
        "printed": [
          64,
          64
        ],
        "role": "题面"
      },
      {
        "pdf": [
          225,
          231
        ],
        "printed": [
          227,
          233
        ],
        "role": "解答"
      }
    ],
    "reading": "完整题面与解答已核读；关键原页已视觉核对。",
    "original_work": "由幂计数及一圈费米子/标量两点、Yukawa三点和标量四点图，构造闭合的局域反项，包括费米盒图排列和耦合混合。",
    "task_design": "判断几个候选算符基是否重整化闭合，独立提取全部UV极点多项式，构造明确MS方案下的有限欧氏响应，定位删除φ⁴反项后的剩余发散。",
    "public_materials": "拉氏量、γ5与维数约定、非例外运动学、允许算符和图枚举规则。",
    "deliverables": [
      "发散振幅及最小反项基",
      "UV极点系数",
      "有限两点/三点/四点响应",
      "方案闭合性证书"
    ],
    "verification": [
      "Gamma函数Laurent展开及独立Dirac迹/排列计数",
      "独立参数积分和改变减除尺度的一致性检验"
    ],
    "baseline": "直接维数积分加低阶参数求积的完整一圈起点。",
    "difficulty": "多场结构、闭费米环符号、γ5和六个盒图排列共同决定反项混合；不拆小问计题。",
    "independence": "qft-03只演化已给beta函数，本题从图构造反项；六维φ³不同时入选。",
    "implementation_gate": "固定ε和MS约定，重新推导不能机械抄用书中的质量壳有限项。"
  },
  {
    "id": "qft-08",
    "title": "二维 Schwinger 模型的质量生成与守恒源响应",
    "source": "R",
    "problems": [
      "11.13"
    ],
    "pages": [
      {
        "pdf": [
          66,
          66
        ],
        "printed": [
          64,
          64
        ],
        "role": "题面"
      },
      {
        "pdf": [
          231,
          232
        ],
        "printed": [
          233,
          234
        ],
        "role": "解答"
      }
    ],
    "reading": "完整题面与解答已核读；关键原页已视觉核对。",
    "original_work": "保留D=2−ε的张量结构计算横向极化，再Dyson求和，在守恒源响应中得到mγ²=e²/π。",
    "task_design": "重建调节后极化和横向传播子，计算有限时间守恒源的频域与时域响应；比较规范参数变化及提前取二维极限的错误方案。",
    "public_materials": "二维QED作用量、retarded处方、由流函数生成的守恒源、查询网格与分布约定。",
    "deliverables": [
      "极化张量及横向残差",
      "质量极点与留数",
      "规范不变源响应",
      "有限时域响应与错误极限诊断"
    ],
    "verification": [
      "保留ε的张量参数积分与Laurent极限",
      "横向谱表示和独立因果初值响应"
    ],
    "baseline": "有明确时间窗和粗离散的谱积分响应。",
    "difficulty": "有限质量来自调节极限，纵向规范项只能在守恒源投影后消去；单报e/√π不得满分。",
    "independence": "不同于qft-01的四维阈值谱，也不同于qft-25的外场标量产对。",
    "implementation_gate": "固定源、边界与极点处方，推导有限响应后再校准，避免靠人为超严容差制造难度。"
  },
  {
    "id": "qft-09",
    "title": "Landau 方程的物理奇点分支与夹挤证书",
    "source": "G",
    "problems": [
      "5"
    ],
    "pages": [
      {
        "pdf": [
          34,
          40
        ],
        "printed": [
          22,
          28
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读。",
    "original_work": "推导Feynman参数在壳条件和逐圈方程，找出无质量三角图两条共线支、一条软支，以Coleman–Norton图像排除伪分支。",
    "task_design": "对同一研究任务中的有限图集枚举物理奇点分支，给非负参数、在壳与闭环证书，区分可绕过的分母零点、端点和夹挤。",
    "public_materials": "动量定向、质量和外线运动学、Feynman参数约束、候选缩图及明确分子。",
    "deliverables": [
      "完整分支列表与分类",
      "归一化参数证书",
      "在壳与逐圈残差",
      "被排除分支的不可行条件"
    ],
    "verification": [
      "有理消元及边界分支枚举",
      "评分器代回方程并检查正性、物理域和完整性"
    ],
    "baseline": "多初值数值找根与残差过滤，不承诺完整枚举。",
    "difficulty": "数值零点不等于实际奇点，物理域、端点和分子抵消必须区别。",
    "independence": "研究分支结构而非重复qft-01固定一圈函数的求积。",
    "implementation_gate": "为选定图族建立可证明完备的分支真值；Landau必要条件不直接当充分条件。"
  },
  {
    "id": "qft-10",
    "title": "简并态、探测分辨率与红外安全可观测量",
    "source": "G",
    "problems": [
      "11"
    ],
    "pages": [
      {
        "pdf": [
          55,
          61
        ],
        "printed": [
          43,
          49
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读；具体辐射过程为待推导原创扩展。",
    "original_work": "用散射算符端点简并子空间及幺正性，证明完整初末不可分辨态求和消除红外奇异；有明确连续谱及简并集合假设。",
    "task_design": "在单一中性源到无质量带电费米子对的受控NLO辐射模型中，比较软/共线安全和不安全的测量函数；组合真实与虚修正，选择探测分辨率，重建有限inclusive量及残余调节器对数。",
    "public_materials": "一套完整且自洽的实/虚修正、相空间、局部减除起点及测量函数定义；所需初态是否须平均由具体过程明定。",
    "deliverables": [
      "测量函数的软/共线极限证书",
      "inclusive修正",
      "调节器扫描及对数残项",
      "安全性分类和分辨率下的物理预测"
    ],
    "verification": [
      "局部减除的独立有限积分",
      "相空间切片法加解析软/共线抵消，逐步外推切片参数"
    ],
    "baseline": "固定相空间切片与普通求积的物理完整起点。",
    "difficulty": "局部实虚相消、测量定义和实验不可分辨性共同决定有限答案，不能仅验证矩阵范数恒等式。",
    "independence": "qft-16研究规范完整的非阿贝尔真空角分布；本题研究inclusive可观测量及调节器消除。",
    "implementation_gate": "优先级C：先独立推导一个完整具体NLO过程并补来源；若只完成有限矩阵玩具或软口号则不计作完成题。"
  },
  {
    "id": "qft-11",
    "title": "Casimir 相互作用的双路线重构与有限壁强度",
    "source": "G",
    "problems": [
      "24",
      "25"
    ],
    "pages": [
      {
        "pdf": [
          274,
          277
        ],
        "printed": [
          103,
          106
        ],
        "role": "24题完整题面与解答"
      },
      {
        "pdf": [
          278,
          281
        ],
        "printed": [
          107,
          110
        ],
        "role": "25题完整题面与解答"
      }
    ],
    "reading": "两题完整相关段落已核读；合为一道。",
    "original_work": "零点模和减去体积项，用Euler–Maclaurin得到能量与应力；以δ壁的泛函行列式和ζ函数独立复现强壁极限。",
    "task_design": "构造有限正壁强度的标量真空相互作用，减去孤立壁自能，计算距离依赖的能量和力，比较弱壁及Dirichlet极限并证明调节独立性。",
    "public_materials": "δ壁作用量、跳跃匹配条件、减除定义、无量纲壁强度和距离查询。",
    "deliverables": [
      "相互作用能与力",
      "匹配/谱条件证书",
      "强壁与弱壁误差",
      "应力与能量导数的一致性"
    ],
    "verification": [
      "独立反射系数的Euclidean行列式积分",
      "谱密度/相移或调节模和减除，强壁用原书解析结果校验"
    ],
    "baseline": "固定截断的谱或积分求积。",
    "difficulty": "必须正确分离不可观测壁自能与有限壁间力，不能只抄−π²/(1440a³)。",
    "independence": "边界真空相互作用，区别现有ED腔波导的经典传播及有限温统计题。",
    "implementation_gate": "有限强度公式须由匹配条件独立推导，不归称原书已完成。"
  },
  {
    "id": "qft-12",
    "title": "Gross–Neveu 行列式、质量隙与真空选择",
    "source": "G",
    "problems": [
      "26"
    ],
    "pages": [
      {
        "pdf": [
          282,
          285
        ],
        "printed": [
          111,
          114
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读。",
    "original_work": "引入辅助场、积分费米子并重整化有效势，得到非解析质量尺度和leading large-N真空。",
    "task_design": "从带明确减除约定的行列式输入恢复质量隙与全局真空，比较两种重整化约定，跟踪小显式源下分支及曲率。",
    "public_materials": "1+1维作用量、large-N保持量、两种减除条件、积分起点及源项。",
    "deliverables": [
      "全部驻点及稳定性",
      "质量隙、真空能和曲率",
      "方案转换下的不变量",
      "源变形的物理解分支"
    ],
    "verification": [
      "高精度fermion determinant积分与减除",
      "独立gap方程和势能比较"
    ],
    "baseline": "直接粗网格有效势和局部极小值搜索。",
    "difficulty": "非微扰指数尺度、近原点数值消减及全局真空选择；有限N不能误称精确。",
    "independence": "区别qft-06逐图Goldstone抵消、qft-20谱密度外推和SP的多项式平均场。",
    "implementation_gate": "源项gap方程另行推导，限制尺度范围以满足CPU资源。"
  }
]

exit_code=0
```

### 2026-11-16T21:57:14.776307+08:00

```bash
cat /Users/ai4s/.codex/plugins/cache/openai-primary-runtime/pdf/26.1112.11217/skills/pdf/SKILL.md
```

```text

### 2026-11-16T21:57:14.776319+08:00

```bash
python3 tools/read_qft_source_pages.py radovanovic 219:220
```

```text

### 2026-11-16T21:57:14.776332+08:00

```bash
cat tasks/qft-04/task.toml tasks/qft-04/environment/Dockerfile tasks/qft-04/tests/test.sh tasks/qft-04/tests/score.py tools/run_qft04_checks.py
```

```text
---
name: "pdf"
description: "Read, create, inspect, render, and verify PDF files where visual layout matters, including fillable AcroForms. Use Poppler rendering plus Python tools such as reportlab, pdfplumber, and pypdf for generation and extraction."
---

# PDF Skill

## When To Use

- Read or review PDF content where layout and visuals matter.
schema_version = "1.4"
- Create PDFs programmatically with reliable formatting.
- Fill and validate interactive PDF forms.
artifacts = ["/app/output/answer.json"]
- Validate final rendering before delivery.


[task]
## Tools + Contract Requirements
name = "theory-physics-bench/qft-04"

version = "0.1.0"
Immediately before the first create/edit authoring command, run `mark_artifact_operation_started.mjs` successfully exactly once using the command below. Do not run it for read-only work. For edits, replace `create` with `edit`; adjust the expected count and output format to match the requested outputs.


[metadata]

category = "research"

```bash
node container_tools/mark_artifact_operation_started.mjs --operation-kind create --expected-output-count 1 --output-format pdf
```


## Workflow
[agent]

user = "student"
1. Prefer visual review: render PDF pages to PNGs and inspect them.
timeout_sec = 1200.0
   - Use `pdftoppm` from the bundled runtime or system Poppler when available.
network_mode = "public"
   - If unavailable, install Poppler or ask the user to review the output locally.

2. Use `reportlab` to generate PDFs when creating new documents.
[verifier]
3. Use `pdfplumber` or `pypdf` for text extraction and quick checks; do not rely on text extraction for layout fidelity.
user = "root"
4. After each meaningful update, re-render pages and verify alignment, spacing, and legibility.
timeout_sec = 120.0

environment_mode = "separate"
## Fill And Validate AcroForms
network_mode = "no-network"


Visual review alone is not a correctness check for a fillable PDF. A page `/Widget` annotation can render a value from its appearance stream while the canonical `/AcroForm/Fields` tree is missing or contains a stale value.
[environment]

cpus = 4
1. Keep the result interactive by default; set `flatten=True` only when the user explicitly requests a completed, static form. Preserve the source PDF, and do not flatten a signed PDF without an explicit workflow decision.
memory_mb = 4096
2. Inspect both representations before filling: enumerate fields from `reader.get_fields()` and `/Widget` annotations from every page's `/Annots`, following `/Parent` and `/Kids`. If a widget and a canonical field have the same name but are distinct objects with no `/Parent` relationship, do not call `reattach_fields()` blindly: it can create a second top-level field with the same name. Report the ambiguity or produce a static result.
storage_mb = 4096
3. Recover genuinely orphaned widgets, fill all pages, and write the result with `pypdf`:
gpus = 0

build_timeout_sec = 900.0
```python
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject

reader = PdfReader(input_pdf)
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
writer = PdfWriter()

writer.clone_document_from_reader(reader)
COPY requirements.txt /tmp/requirements.txt

RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
# Restores widgets that are missing from /AcroForm/Fields.
 && useradd --uid 1000 --create-home student \
writer.reattach_fields()
 && mkdir -p /app/data /app/output \
fields = writer.get_fields() or {}
 && chown -R student:student /app
missing = set(expected_values) - set(fields)

if missing:
COPY public/ /app/data/
    raise ValueError(f"Form fields not found after repair: {sorted(missing)}")
WORKDIR /app

USER student
values_to_write = dict(expected_values)
#!/bin/bash
if flatten:
set -euo pipefail
    # Paint every existing value before removing every widget.
python3 "$(dirname -- "$0")/score.py"
    values_to_write = {
import json
        name: field.get("/V", "/Off" if field.get("/FT") == "/Btn" else "")
import os
        for name, field in fields.items()
from pathlib import Path
    }
import sys
    values_to_write.update(expected_values)
from quality_score import quality_score


writer.update_page_form_field_values(

    None, values_to_write, auto_regenerate=False, flatten=flatten
def evaluate(answer,data_root=None,private_root=None):
)
    data=Path(data_root or os.environ.get('TASK_DATA_ROOT','/app/data'));private=Path(private_root or os.environ.get('TASK_PRIVATE_ROOT','/tests/private'))

    sys.path.insert(0,str(data))
if flatten:
    from physics import load_model,validate_answer
    # pypdf's flatten=True paints appearances but does not remove widgets.
    model=load_model(data);parsed,reason=validate_answer(answer,model)
    writer.remove_annotations(subtypes="/Widget")
    if reason:return None,{'reason':reason}
    writer.root_object.pop(NameObject("/AcroForm"), None)
    truth=json.loads((private/'truth.json').read_text());scoring=model['scoring'];floor=scoring['relative_floor'];details=[]

with open(output_pdf, "wb") as stream:
    def relative(actual,expected):return min(1,abs(actual-expected)/max(floor,abs(expected)))
    writer.write(stream)
    for expected in truth['cases']:
```
        actual=parsed['cases'][expected['id']]

        parts={name:relative(actual[name],expected[name]) for name in ('sigma','accepted_sigma','acceptance')}
        for name in ('mean_energy','energy_quantiles','accepted_cos_interval'):
4. Reopen the written PDF before delivery. For an interactive result, require every expected field to be present in `get_fields()` with the expected `/V`, enumerate page widgets again, and confirm their effective `/V` (the widget value or inherited `/Parent` value) agrees. Confirm each updated widget has a non-empty `/AP` `/N` appearance and render the final pages to catch stale or clipped appearances. Do not rely on `/NeedAppearances` or a successful PNG render as proof that logical field data was updated.
            a,b=actual[name],expected[name]
5. For a flattened result, require zero `/Widget` annotations and no remaining `/AcroForm` field tree after reopening, then render the final pages. Keep an editable copy when the user may need to revise the form.
            if a is None or b is None:parts[name]=float(a!=b)

            elif name=='accepted_cos_interval':parts[name]=sum(min(1,abs(x-y)/2) for x,y in zip(a,b))/2
## Temp And Output Conventions
            elif isinstance(b,list):parts[name]=sum(relative(x,y) for x,y in zip(a,b))/len(b)

            else:parts[name]=relative(a,b)
- Use `tmp/pdfs/` for intermediate files; delete them when done.
        error=sum(scoring['case_parts'][name]*value for name,value in parts.items());details.append({'id':expected['id'],'error':error,'parts':parts})
    probe_details=[]
    for expected in truth['probes']:
        actual=parsed['probes'][expected['id']]
- Write final artifacts under `output/pdf/` when working in this repo.
        errors={name:min(1,abs(actual[name]-expected[name])/max(scoring['probe_floor'],abs(expected[name]))) for name in ('s_squared','u_squared','interference','total','gauge_shifted_total')}
        probe_details.append({'id':expected['id'],'error':sum(errors.values())/len(errors),'parts':errors})
- Keep filenames stable and descriptive.
    error=scoring['case_weight']*sum(x['error'] for x in details)/len(details)+scoring['probe_weight']*sum(x['error'] for x in probe_details)/len(probe_details)

    return 100*error,{'cases':details,'probes':probe_details}
## Dependencies


Prefer the Codex bundled workspace/runtime dependencies when available. The primary runtime is expected to include:


def main():
- Python packages: `reportlab`, `pdfplumber`, `pypdf`
    logs=Path(os.environ.get('VERIFIER_LOG_ROOT','/logs/verifier'));logs.mkdir(parents=True,exist_ok=True)
- Rendering tools: `pdftoppm` and `pdfinfo` from Poppler
    tests=Path(os.environ.get('TASK_TESTS_ROOT','/tests'));answer=Path(os.environ.get('TASK_ANSWER_PATH','/app/output/answer.json'));metric=json.loads((tests/'metric.json').read_text())

    try:payload=json.loads(answer.read_text())
If a dependency is missing, install only what is needed.
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{'reason':'没有有效 JSON 产物'}

    else:raw,details=evaluate(payload)
Python packages:
    status='invalid' if raw is None else 'completed';score=quality_score(metric,raw,status)

    details.update(raw_metric=raw,score=score,status=status)
```bash
    (logs/'metrics.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n');(logs/'reward.txt').write_text(f'{score}\n')
uv pip install reportlab pdfplumber pypdf

```


if __name__=='__main__':main()
If `uv` is unavailable:
"""Local Linux calibration and physical regression checks for qft-04."""

import argparse
```bash
import importlib.util
python3 -m pip install reportlab pdfplumber pypdf
```
import json

import os
System tools for rendering:
from pathlib import Path

import platform
```bash
import subprocess
# macOS (Homebrew)
import sys
brew install poppler
import tempfile

import time
# Ubuntu/Debian

sudo apt-get install -y poppler-utils
ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qft-04';DATA=TASK/'environment/public';TESTS=TASK/'tests'
```
sys.path.insert(0,str(TESTS))


If installation is not possible in this environment, tell the user which dependency is missing and how to install it locally.


def load(name,path):
## Environment
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


No required environment variables.


def main():
## Rendering Command
    parser=argparse.ArgumentParser();parser.add_argument('--calibrate',action='store_true');args=parser.parse_args()

    scorer=load('qft04_score',TESTS/'score.py');quality=load('qft04_quality',TESTS/'quality_score.py')
```bash
    answers={};cases={};runtime={}
pdftoppm -png "$INPUT_PDF" "$OUTPUT_PREFIX"
    with tempfile.TemporaryDirectory(prefix='qft04-check-') as directory:
```
        temp=Path(directory)

        for name,script in (('baseline','baseline.py'),('reference','solve.py')):
## Quality Expectations
            output=temp/f'{name}.json';started=time.perf_counter()

            subprocess.run([sys.executable,str(TASK/'solution'/script),'--data-root',str(DATA),'--output',str(output)],check=True,capture_output=True,text=True)
- Maintain polished visual design: consistent typography, spacing, margins, and section hierarchy.
            runtime[f'{name}_seconds']=time.perf_counter()-started;answers[name]=json.loads(output.read_text())
- Avoid rendering issues: clipped text, overlapping elements, broken tables, black squares, or unreadable glyphs.
        answers.update(load('qft04_cases',TESTS/'development_cases.py').make_cases(answers['reference']))
- Charts, tables, and images must be sharp, aligned, and clearly labeled.
        answers['independent_truth']=json.loads((TESTS/'private/truth.json').read_text())
- Use ASCII hyphens only. Avoid U+2011 and other Unicode dashes.
        for name,answer in answers.items():
- Citations and references must be human-readable; never leave tool tokens or placeholder strings.
            raw,detail=scorer.evaluate(answer,DATA,TESTS/'private');cases[name]={'raw_metric':raw,**detail,'status':'invalid' if raw is None else 'completed'}

## Final Checks
        measured={'kind':'continuous','metric_name':'康普顿相干振幅与实验室接受能谱误差','unit':'百分点','direction':'minimize','baseline':cases['baseline']['raw_metric'],'reference':cases['reference']['raw_metric'],'tolerance':1e-6}

        metric=measured if args.calibrate else json.loads((TESTS/'metric.json').read_text());quality.validate_metric(metric)
- Do not deliver until the latest PNG inspection shows zero visual or formatting defects.
        for item in cases.values():item['score']=quality.quality_score(metric,item['raw_metric'],item['status'])
- Confirm headers, footers, page numbering, and section transitions look polished.
        testroot=temp/'tests';testroot.mkdir();(testroot/'metric.json').write_text(json.dumps(metric));entries={}
- Keep intermediate files organized or remove them after final approval.
        for name in ('reference','empty','missing_empty_field','huge_integer'):

            if name not in ('reference','empty'):(temp/f'{name}.json').write_text(json.dumps(answers[name]))
## Final response
            logs=temp/f'logs-{name}'

            env=dict(os.environ,TASK_DATA_ROOT=str(DATA),TASK_PRIVATE_ROOT=str(TESTS/'private'),TASK_TESTS_ROOT=str(testroot),TASK_ANSWER_PATH=str(temp/f'{name}.json'),VERIFIER_LOG_ROOT=str(logs))
### Final Response Citations
            subprocess.run(['bash',str(TESTS/'test.sh')],env=env,check=True,capture_output=True,text=True)

            entries[name]=json.loads((logs/'metrics.json').read_text())
        feedback=json.loads(subprocess.run([sys.executable,str(DATA/'feedback.py'),str(temp/'reference.json')],check=True,capture_output=True,text=True).stdout)
- **Create/edit:** for created or edited PDFs, cite each final deliverable exactly once with `purpose="output"`, in its own paragraph. Briefly describe the result without repeating its filename, path, or link. Never put output directives inside prose or list items.
    checks={
        'reference_matches_independent_truth':measured['reference']<metric['tolerance'],
        'reference_improves_baseline':measured['baseline']-measured['reference']>metric['tolerance'],
- **Q&A and summaries:** Every file whose contents you summarize or use to support an answer MUST receive a `:codex-file-citation{...}` with `purpose="source"` in the final response. Use the source citation in place of the filename, wherever the filename would appear. Do not write the filename separately and append its citation at the end. Files merely inspected but not used in the answer need no citation. Do not emit output citations for unchanged files or read-only answers.
        'registered_endpoints_match':all(abs(measured[k]-metric[k])<metric['tolerance'] for k in ('baseline','reference')),

        'baseline_zero_reference_one':cases['baseline']['score']==0 and cases['reference']['score']==1,
- Emit `:codex-file-citation{...}` directly, without backticks, code fences, or a Markdown-link wrapper. Use verified targets only. No need to cite or reference intermediate work.
        'equivalent_order_same':cases['equivalent']['raw_metric']==cases['reference']['raw_metric'],

        'independent_truth_full_credit':cases['independent_truth']['score']==1,
For file citations, set `path` to the verified absolute file path on the task host. Omit `mode`.
        'wrong_physics_penalized':cases['wrong']['raw_metric']>measured['reference']+1,

        'missing_interference_penalized':cases['no_interference']['raw_metric']>measured['reference']+.1,
Some illustrative examples, real responses use verified targets outside code fences.
        'wrong_boost_penalized':cases['no_boost']['raw_metric']>measured['reference']+.1,

        'wrong_energy_quantiles_penalized':cases['wrong_quantile_order']['raw_metric']>measured['reference']+.01,
```text
        'false_nonempty_penalized':cases['fake_nonempty']['raw_metric']>measured['reference']+.1,
:codex-file-citation{path="/absolute/path/review.pdf" purpose="output"}
        'false_empty_constant_spectrum_penalized':cases['false_empty']['raw_metric']>measured['reference']+.1,
```
        'invalid_answers_rejected':all(cases[n]['status']=='invalid' and cases[n]['score']==0 for n in ('duplicate','boolean','nonfinite','malformed','missing_empty_field','huge_integer')),

        'constant_energy_quantiles_correct':max(answers['reference']['cases'][4]['energy_quantiles'])-min(answers['reference']['cases'][4]['energy_quantiles'])==0,
```text
The review of :codex-file-citation{path="/absolute/path/review.pdf" purpose="source"} is due Friday.
        'empty_window_conditions_undefined':answers['reference']['cases'][5]['mean_energy'] is None and answers['reference']['cases'][5]['energy_quantiles'] is None,
```
        'ward_identity_total_invariant':all(abs(item['total']-item['gauge_shifted_total'])<1e-9 for item in answers['reference']['probes']),

        'verifier_reference_one_empty_zero':entries['reference']['score']==1 and entries['empty']['score']==0 and entries['empty']['status']=='invalid',

        'verifier_malformed_boundary_cases_zero':all(entries[n]['score']==0 and entries[n]['status']=='invalid' for n in ('missing_empty_field','huge_integer')),
### Additional Citation Guidance
        'public_feedback_works':feedback['valid'] and len(feedback['cases'])==7,

        'course_quality_score_unchanged':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
For PDF Q&A, inspect complete relevant pages and preserve material headings, table/figure labels, footnotes, sources, and sample sizes. PDF citations support only plain file citations; do not add `artifact_kind`, `page_number`, or other locators.
    }
    report={'metric':metric,'cases':cases,'runtime':{'platform':platform.platform(),'python':platform.python_version(),**runtime},'checks':checks,'verifier_entries':entries}
    print(json.dumps({'metric':metric,'scores':{k:{f:v[f] for f in ('raw_metric','score','status')} for k,v in cases.items()},'runtime':report['runtime'],'checks':checks},ensure_ascii=False,indent=2))
    if not all(checks.values()):raise SystemExit('qft-04 checks failed')
    if args.calibrate:
        for path in (DATA/'metric.json',TESTS/'metric.json'):path.write_text(json.dumps(metric,ensure_ascii=False,indent=2)+'\n')
    elif json.loads((DATA/'metric.json').read_text())!=metric:raise SystemExit('metric copies differ')

exit_code=0
```
    (ROOT/'checks/qft-04-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    saved=ROOT/'runs/qft-04/development-answers';saved.mkdir(parents=True,exist_ok=True)
    for name,answer in answers.items():(saved/f'{name}.json').write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()

exit_code=0
```
usage: read_qft_source_pages.py [-h] {gelis,problem-book} spans
read_qft_source_pages.py: error: argument source: invalid choice: 'radovanovic' (choose from gelis, problem-book)

exit_code=2
```

### 2026-11-16T21:57:32.608117+08:00

```bash
cat tools/run_harbor_local_checks.py tools/run_pending_harbor.py tools/task_status.py tasks/qft-04/tests/metric.json tasks/qft-04/environment/public/model.json
```

```text

### 2026-11-16T21:57:32.608283+08:00

```bash
python3 tools/read_qft_source_pages.py problem-book 219:220
```

```text

### 2026-11-16T21:57:32.608223+08:00

```bash
cat planning/qft-expansion-gelis-review.md
```

```text
#!/usr/bin/env python3
"""Run oracle/nop locally and archive raw jobs, including unsuccessful runs."""

import argparse
import datetime
import json
import platform
import re
import shlex
import shutil
import subprocess
import tempfile
# Gelis 量子场论扩展选题：原文核读与任务独立性审阅
from pathlib import Path


日期：2026-11-16。本文是扩展题库的来源评审，**不是已经完成的 Harbor 题包、专家参考解或正式 Codex 测评结果**。题号均为 Gelis 书内题号，不是最终 benchmark ID。
ROOT = Path(__file__).resolve().parents[1]


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("task_id")
## 来源和核读边界
    parser.add_argument("--macos-compat", action="store_true")

    args = parser.parse_args()
    if not re.fullmatch(r"[a-z]+-[0-9]{2}", args.task_id):
- 来源：François Gelis，*Problems in Quantum Field Theory*，用户提供的 PDF：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。
        parser.error("invalid task id")
- PDF 共 375 页；SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。
    source = ROOT / "tasks" / args.task_id
    if not source.is_dir():
        parser.error("task directory does not exist")
    harbor = shutil.which("harbor")
    if not harbor:
        raise SystemExit("harbor executable not found")
    # Avoid '%' URL handling in Harbor/Compose, retaining the exact task contents.
    stage = Path(tempfile.mkdtemp(prefix=f"physics-{args.task_id}-harbor-", dir="/tmp"))
- 提取索引：`planning/source-notes/qft-gelis-all.txt`；逐页映射：`planning/source-notes/qft-gelis-page-map.json`。
    task = stage / args.task_id
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"))
    if args.macos_compat:
- **此 PDF 的章节顺序被打乱；以下 PDF 页码均按文件中从 1 开始计数，印刷页码按原页页眉核对，不能统一加减一个偏移。**
        config = task / "task.toml"
        original = config.read_text(encoding="utf-8")
- 本次逐页核读了下表 16 题的题面和解答正文。主要依据全文提取；还渲染并目视核对 PDF 299、188 页，分别确认复杂 Langevin 的高斯定点系数和 LPM 形成时间/扩散近似。没有声称对全书每页进行目视校对。
        needle = 'environment_mode = "separate"\nnetwork_mode = "no-network"'
        if needle not in original:
- 查看了当前 `tasks/qft-01` 至 `tasks/qft-04/instruction.md`；`qft-05/instruction.md` 当时尚未创建。现有题分别是：真空极化的解析延拓/阈值谱；三体衰变窄共振干涉；跨阈值 RG 及参数可辨识性；康普顿双图干涉/探测接受度。下文与既有题的差异据此判断。
            raise SystemExit("expected verifier network declaration missing")
- 原书提供的是物理题与解析解答；下文的研究情境、公开数据、诊断探针和评分方式是**拟议的本地原创改造**，不能反向归于作者。
        config.write_text(original.replace(needle, 'environment_mode = "separate"\nnetwork_mode = "public"'), encoding="utf-8")

    mode = "harbor-macos-compat" if args.macos_compat else "harbor-linux"
## 候选总表
    destination = ROOT / "runs" / args.task_id / mode

    destination.mkdir(parents=True, exist_ok=True)
| 原题号 | 原题名 | PDF 页 | 印刷页 | 建议 | 物理机制/核心判别 |
    records = []
|---|---|---|---|---|---|
    for agent in ("oracle", "nop"):
| 5 | Landau Equations for Soft and Collinear Singularities | 34–40 | 22–28 | 优先 | 可避开的分母零点 vs. 夹捏/端点奇点；完整奇点分支 |
        jobs = stage / "runs" / agent
| 11 | Lee–Nauenberg Theorem | 55–61 | 43–49 | 条件备选 | 初末简并态求和的红外安全与幺正性；不能只背结论 |
        command = [harbor, "run", "-p", str(task), "-a", agent,
| 26 | Gross–Neveu Model | 282–285 | 111–114 | 优先 | 辅助场、费米子行列式、大 N 与非微扰质量生成 |
                   "--n-attempts", "1", "--n-concurrent", "1", "--max-retries", "0",
| 29 | Complex Langevin Equation | 294–300 | 123–129 | 优先 | 矩递推满足性不等于正确性；稳定、边界条件、相消误差 |
                   "--jobs-dir", str(jobs)]
| 37 | Classical Non-Abelian Particles and the Wong Equations | 322–325 | 151–154 | 优先 | 色荷的协变输运、路径序和规范协变检验 |
        print("$ " + shlex.join(command), flush=True)
| 43 | Soft Radiation and Antenna Effects in QCD | 346–354 | 175–183 | 优先 | 色单态天线干涉、角序及完整色荷守恒 |
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
| 48 | Instantons and Tunneling in Quantum Mechanics | 364–367 | 193–196 | 备选 | Euclidean 鞍点、平移零模、多瞬子有效范围；与 QM 可能重合 |
        result = subprocess.run(command, text=True)
| 49 | Instantons as Transitions between Pure Gauges in Yang–Mills Theory | 368–370 | 197–199 | 优先 | 大规范变换、绕数、四维拓扑荷与边界差 |
        job_results=sorted(jobs.glob('*/result.json'))
| 52 | Six-Point −−−+++ Amplitude | 93–94 | 215–216 | 优先 | BCFW 在壳递推、合法通道和因子化 |
        summaries=[]
| 67 | One-Loop Four-Point ++++ Amplitude from Generalized Unitarity | 139–145 | 261–267 | 优先 | 四维割遗漏的有理项、额外维分量和有限残项 |
        for result_path in job_results:
| 69 | Banks–Casher Relation | 161–163 | 283–285 | 优先 | Dirac 近零谱、体积/质量极限顺序、手征凝聚 |
            payload=json.loads(result_path.read_text(encoding='utf-8'))
| 70 | Nielsen–Ninomiya Theorem | 163–168 | 285–290 | 优先 | 布里渊环面上的零点指数和手征倍增 |
            stats=payload.get('stats',{})
| 72 | Center Symmetry and Deconfinement | 171–175 | 293–297 | 优先 | 周期边界、中心扭曲、表示的 N-ality 与 Polyakov 环 |
            expected=1.0 if agent=='oracle' else 0.0
            evaluations=stats.get('evals',{})
| 73 | Photon Hard Thermal Loop from Classical Particles | 176–179 | 298–301 | 优先，需检查与 ED 内容重叠 | 无碰撞 Vlasov 响应、因果解析延拓、Ward 横向性 |
            passed=(stats.get('n_errored_trials')==0 and stats.get('n_completed_trials')==1
| 75 | Landau–Pomeranchuk–Migdal Effect | 183–190 | 305–312 | 优先 | 形成时间内多次散射同阶、碰撞积分重求和、软谱抑制 |
                    and len(evaluations)==1)
| 80 | Schwinger Mechanism from Bogoliubov Transformations | 209–217 | 331–339 | 优先 | 模式混合、强场粒子产生、真空持续概率与关联 |
            for evaluation in evaluations.values():

                passed=passed and evaluation.get('n_trials')==1 and evaluation.get('n_errors')==0
13 个优先候选是 5、26、29、37、43、49、52、67、69、70、72、75、80；第 73 题可成为第 14 个。优先级不是模型难度成绩，真正难度须冻结后按课程配置独立测评。
                metrics=evaluation.get('metrics',[])

                passed=passed and len(metrics)==1 and metrics[0].get('mean')==expected
## 逐题核读与可实施改造
            summaries.append({'result':str(result_path.relative_to(jobs)), 'passed':passed,

                              'expected_reward':expected, 'stats':stats})
### G05：Landau 奇点分类与证书
        archive = destination / agent

        archive.mkdir(parents=True, exist_ok=True)
        if jobs.exists():
**已核实原题。** 题面以 L 圈、m 个分母的一般费曼积分出发，推导 `x_r(q_r²−m_r²)=0` 和每圈 `Σ_r ε_rj x_r q_r^μ=0`。给出的无质量三角图满足 `k²=k′²=0`、`(k+k′)²>0`。解答分别找到两条共线支和一条软支，并在结尾以 Coleman–Norton 图像排除看似可能的额外缩图。单纯存在分母零点不构成奇点证明；还要分析可否变形积分流形、夹捏和端点。
            shutil.copytree(jobs, archive, dirs_exist_ok=True)

        records.append({"agent": agent, "command": command, "returncode": result.returncode,
**建议研究任务。** 对公开给定的小型图集（质量/外线在壳状态不同的三角图及缩图）建立奇点诊断器；输出所有物理解分支、非负 Feynman 参数的归一化证书、在壳/圈方程残差，以及分支的软/共线/阈值分类。材料变化必须影响真实可解分支，而不是同图换种子。整体算一题。
                        "started_utc": started, "archive": str(archive.relative_to(ROOT)),

                        "verified_results":summaries,
**可靠验证。** 评分器代回原 Landau 方程检查证书，另用手工消元/有理代数确定完整分支列表；既检查正确分支也检查遗漏与伪分支。只靠数值求根找到几个点不能证明“找全”。如加入分子零点，需明确区分 Landau 必要条件与实际奇性消除，不把方程解一律视为非零奇点。
                        "passed":result.returncode==0 and len(summaries)==1 and all(s['passed'] for s in summaries)})

    report = {"task_id": args.task_id, "host": platform.platform(), "temporary_task": str(task),
**独立性。** 检验奇点结构及物理解支，区别于 QFT01 的固定真空极化函数求积和分支计算。不得只把 QFT01 的阈值根改个名字。
              "macos_verifier_network_override": args.macos_compat, "runs": records}

    output = destination / ("session-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".json")
### G11：简并态求和与红外安全（条件备选）
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    if any(not record['passed'] for record in records):
**已核实原题。** 以 Lippmann–Schwinger 展开构造 `T`，将初/末态的不可分辨集合写为 `D(α), D(β)`。发散链只在两端简并子空间形成；解答将奇异部分分解为 `Uβ,out† T3 Uα,in`，用子空间幺正性把双简并求和化为有限的 `tr(Pβ T3 Pα T3†)`。原解明确假设初末简并集合不相交，并在分离奇异部分时忽略不导致发散的小简并区域贡献。
        raise SystemExit("Harbor trial/reward verification failed; original jobs have been archived")


**可行改造方向。** 给出某个明确红外调节下的完整微扰计算，要求识别相同实验分辨率所需的初/末态集合、组合实/虚修正，并用调节参数扫描证实可观测量的极限。输出系数证书和调节依赖残差，而不是自然语言背诵 KLN。


if __name__ == "__main__":
    main()
**为何不列首批优先。** 不能随意生成有限矩阵、令所有能量相等，再称其模拟了散射 Møller 算符的幺正性：有限维离散谱中的 `iη` resolvent 一般不能直接替代原题的连续散射极限。若没有经过独立推导的具体 QED 调节计算，该题容易变成只按关键词评分的证明题。先完成其他候选更稳妥。

### G26：Gross–Neveu 的质量生成和大 N 有效势

"""Sequential local oracle/nop checks for tasks already calibrated."""
**已核实原题。** 这是 (1+1) 维 N 种无质量费米子的四费米模型；离散手征变换禁止显式质量项。引入辅助标量后，积分掉费米子得到行列式；常场有效势为 `Veff(φ)=φ²/(2g²)+Nφ²/(4π)[ln(φ²/μ²)−1]`。非零极小值的绝对值为 `μ exp[−π/(Ng²)]`，其对 g=0 的非解析性解释了为何普通有限阶微扰找不到质量。精确性是**固定 't Hooft 型组合的 leading large-N 结果**，不能称有限 N 全阶精确。
import subprocess

import sys
**建议研究任务。** 公开一组带有限减除约定的 fermion-determinant/有效势采样和可计算积分起点，要求恢复相同物理质量尺度、找出对称破缺极小值及曲率，比较两个重整化约定，判断某候选微扰/数值解是否找错真空。可加入小显式源作为连续变形，但需重新独立推导其 gap equation，不声称原书已给出。
from pathlib import Path


root=Path(__file__).resolve().parents[1]
for identifier in sys.argv[1:]:
    command=[sys.executable,str(root/'tools/run_logged.py'),'--log',f'checks/{identifier}-command-log.md',
             '--',sys.executable,str(root/'tools/run_harbor_local_checks.py'),identifier,'--macos-compat']
    subprocess.run(command,cwd=root,check=True)
**可靠验证。** 独立高精度 determinant 积分和 gap 方程互检；验证全局极小值、偶对称、尺度变换一致性。不能只提交一个已知闭式指数并得满分；至少要求多尺度一致性及能量/曲率可观测量。基线取有限阶展开/粗网格，参考为稳定行列式或解析势。
"""Report actual development and Harbor evidence without interpreting plans."""

import json
**独立性。** 与 G69 的共同词是“手征破缺”，但此题研究辅助场有效作用量和动力学生成质量，G69 研究谱数据及两个极限次序，材料和验证依据实质不同。区别于现有 QFT03 线性分段 RG 反演。
from pathlib import Path


### G29：复杂 Langevin 的正确性诊断
ROOT=Path(__file__).resolve().parents[1]


**已核实原题。** `S(z)=αz²/2+βz⁴/4`。带 `n!` 归一化的矩服从 `C[n−2]=αn C[n]+βn(n+1)(n+2) C[n+2]`。同一递推和 `C0=1` 仍留下一个自由解支，需额外的大 n 边界条件。β 正实时，书中对有限截断矩阵 B 的谱实部给出与 Re α 相反的符号；这不是未经条件限制的“复杂 Langevin 对任意作用量都正确”定理。纯高斯情况下，强相位导致高阶矩由大项相消得到小结果，即使采样正分布也不能消灭方差问题。
def harbor_status(task,agent):

    records=[]
**建议研究任务。** 提供动作参数与几组待诊断的候选矩/有限步长模拟结果；要求计算低阶到中阶复矩、识别满足局部递推却属于错误分支的解、区分截断偏差和采样误差，并设计有限预算下的稳定重构。任务不应强制唯一算法，允许复积分、稳定递推、Langevin 或混合方法。
    for path in (ROOT/'runs'/task/'harbor-macos-compat'/agent).glob('*/result.json'):

        value=json.loads(path.read_text())
**可靠验证。** 独立高精度实轴复权积分为真值；用不同截断深度和递推残差作诊断但不把残差本身当正确性。高阶矩用公开绝对误差尺度防止除以接近零真值放大。纯高斯矩可作为解析证书。输入限制避免配分函数零点造成未说明病态性。
        stats=value.get('stats',{})

        for evaluation in stats.get('evals',{}).values():
**独立性。** 这是符号问题与数值方法正确性，不是另一个普通积分题。必须保留错误递推解、截断选择和相消诊断，不能退化为四次函数积分数值表。
            if evaluation.get('n_trials')==1 and evaluation.get('n_errors')==0 and stats.get('n_errored_trials')==0:

                metrics=evaluation.get('metrics',[])
### G37：Wong 色荷输运与路径序
                if metrics and metrics[0].get('mean')==(1.0 if agent=='oracle' else 0.0):

                    records.append(str(path.relative_to(ROOT)))
**已核实原题。** 非阿贝尔 Lorentz 力是 `dpμ/dt=2tr(QFμν) dxν/dt`；Q 需与 F 同样协变变换。由局域电流 `Jμ(x)=∫dt Q(x(t)) xdotμ δ(x−x(t))` 的协变守恒得到 `dQ/dt−ig xdotμ[Aμ,Q]=0`。色荷不能在一般非阿贝尔背景下简单取常数；即便轨迹近似不偏转，颜色仍可演化。
    return sorted(records)


**建议研究任务。** 给定固定高能轨迹与一段段互不对易的 SU(2)/SU(3) 背景，求 Wilson-line 伴随输运后的色荷与规范不变量，比较两条顺序不同的背景路径，并在显式时变规范变换下重算同一物理结果。保留轨迹为公开固定起点，不同时再做复杂反演；关键挑战是路径序和规范协变。
def collect():

    records=[]
**可靠验证。** 分段常量背景可用独立高精度矩阵指数乘积提供精确真值，参考解用 ODE；检查 `tr(Q²)`、Hermiticity、tracelessness、终点共轭变换和物理 Lorentz 力一致性。不得用矩阵逐元素相等判断不同规范的解。交换背景顺序时的差异是实质输入变化。
    for directory in sorted((ROOT/'tasks').iterdir()):

        if not directory.is_dir():continue
**独立性。** 与 G49 的规范拓扑不同；此题是一维路径上的颜色平行输运，无需拓扑荷或四维 instanton。与 QFT04 均可能有规范检查，但研究对象和真值路线不同。
        path=ROOT/'checks'/f'{directory.name}-calibration.json'

        calibration=json.loads(path.read_text()) if path.exists() else {}
### G43：QCD 天线辐射、色守恒与角序
        checks=calibration.get('checks',{})

        records.append({'id':directory.name,'calibrated':bool(checks) and all(checks.values()),
**已核实原题。** 色单态 q qbar 对的软流为 `pμ/(p·k)−qμ/(q·k)`，平方辐射因子 `2g²Cf (p·q)/[(p·k)(q·k)]`。解答把它拆为仅含一侧共线极点的两项；两项并非独立规范不变、正定的单粒子辐射率。各项在各自不同极轴下做方位角平均产生角序；不能说总辐射在这两个角平均意义以外处处严格为零。
                        'check_count':len(checks),'oracle':harbor_status(directory.name,'oracle'),

                        'nop':harbor_status(directory.name,'nop')})
**八重态的重要条件。** 原解明确：只有 q、qbar 两条有色线的硬过程不可能产生非单态 pair。必须补上有色 parent/伴随外线的软辐射，才能满足 Ward/色荷守恒。q qbar g 情况含三个偶极项，不能只把 Cf 换成 Ca。
    return records


**建议研究任务。** 给出规范完整的单态 q qbar 与 q qbar g 硬事件，恢复软角分布、有限角接受窗的辐射概率，识别缺失有色线/不相干叠加模型，并设计最能区分模型的角区。公开 collinear/angular cut 防止总概率发散。
if __name__=='__main__':

    for item in collect():
**可靠验证。** 真值由完整颜色矩阵逐色求和与独立偶极表达式互检；角积分独立高精度求积。同时核查色守恒和 gauge-shift 稳定，不能将任意非单态 pair 的不守恒软流当合法模型。把精确分布、相干/不相干差异和诊断选择共同评分，不能仅预测已背熟的角序口号。
        print(item['id'], 'calibrated='+str(item['calibrated']), 'checks='+str(item['check_count']),

              'oracle='+str(bool(item['oracle'])), 'nop='+str(bool(item['nop'])))
**独立性。** 相对于 QFT04，新增的是非阿贝尔颜色结构、角序及多外线一致性，不应再主要考 Lorentz boost/接受窗数值积分。相对于 G75，真空天线空间干涉不同于热介质形成时间内碰撞重求和。
{

  "kind": "continuous",
### G48：双阱 instanton 与零模（备选）
  "metric_name": "康普顿相干振幅与实验室接受能谱误差",

  "unit": "百分点",
**已核实原题。** `V=λ(x²−x*²)²` 的 Euclidean 鞍点为 `x* tanh[ω(τ−τ0)/2]`，`ω²=8λx*²`、`SE=ω³/(12λ)`。平移零模 τ0 产生与持续时间成正比的 prefactor；单 instanton 结果只在 `1≪ωt≪exp(SE)` 的区域有意义。更长时间需包括 multi-instanton，不能把线性随 t 增长的概率外推到大于 1。
  "direction": "minimize",

  "baseline": 55.40229668995407,
**候选改造。** 对不同 barrier/source 下的 Euclidean boundary-value problem，计算鞍点作用量、涨落零模和谱劈裂，和独立 Schrödinger 谱解比较，判断何时半经典展开失效。有限时区间需要明确边界条件，不能直接将无限时 tanh 当作精确有限区间解。
  "reference": 5.46829428869829e-13,

  "tolerance": 1e-06
**优先级。** 若现有/计划 QM 题已有双阱谱或 WKB 隧穿，此题不应再作为独立 QFT 新题凑数。杨–米尔斯 G49 更能补足场论内容。除非最终版确实围绕 fluctuation determinant/collective coordinate，并证明与 QM 题目标不同，否则保留为备选。
}

{
### G49：杨–米尔斯真空绕数与 instanton 拓扑荷
  "units": "m_e=c=hbar=1; cross sections in r_e^2=alpha^2/m_e^2",

  "metric_signature": "+---",
**已核实原题。** 对 temporal gauge 下趋于纯规范的有限作用量构型，将空间无穷远紧化为 S³，并用 Cartan–Maurer 积分定义 `π3(SU(N))` 的整数。将四维 `F Ftilde` 积分转为边界流，得到 `N=n(+∞)−n(−∞)`；这建立 instanton 与不同拓扑真空的联系。题目不是让模型重复双阱 tanh。
  "spin_average": "average over 2 initial electron spins and 2 incoming photon polarizations; sum over final states",

  "scoring": {"case_weight": 0.8, "probe_weight": 0.2, "case_parts": {"sigma":0.15,"accepted_sigma":0.25,"acceptance":0.1,"mean_energy":0.15,"energy_quantiles":0.2,"accepted_cos_interval":0.15},"relative_floor":0.000001,"probe_floor":1.0},
**建议研究任务。** 给定一组有解析定义的 SU(2) 空间映射（含取向反转和光滑径向变形），计算完整绕数与边界条件证书；对一组明确归一化的四维场构型，独立计算 topological charge、Euclidean action 和自对偶残差，判断其能否连接指定两个真空。若采用 BPST 具体形式，该形式与 action bound 需补充公开来源和独立推导，不能声称都由原题49给出。
  "cases": [

    {"id":"kn-01","x":0.015,"beta_fraction":[0,1],"lab_theta_window":[0.0,3.141592653589793],"lab_energy_window":[0.0,100.0]},
**可靠验证。** 保留真正整数拓扑证书；解析角积分/径向一维积分与独立四维或球对称积分交叉核对，公开 epsilon/trace 归一化。边界不满足条件的构型必须可被拒绝；不能把粗网格得到的任意近整数直接四舍五入得分。各变形只作为该题内部多案例。
    {"id":"kn-02","x":0.8,"beta_fraction":[4,5],"lab_theta_window":[0.05,0.9],"lab_energy_window":[0.3,2.5]},

    {"id":"kn-03","x":8.0,"beta_fraction":[-3,5],"lab_theta_window":[1.5,3.0],"lab_energy_window":[0.1,1.0]},
**独立性。** 材料是空间映射与四维场、真值是拓扑整数/作用量，不同于 G37 的颜色 ODE、G70 的动量空间 fermion doubling。不得将共同使用 SU(2) 当作内容重复的充分理由。
    {"id":"kn-04","x":40.0,"beta_fraction":[97,100],"lab_theta_window":[0.0,0.15],"lab_energy_window":[0.5,500.0]},

    {"id":"kn-05","x":1.25,"beta_fraction":[-5,9],"lab_theta_window":[0.2,2.8],"lab_energy_window":[0.66,0.68]},
### G52：六胶子 NMHV 树振幅的递推与因子化
    {"id":"kn-06","x":1.25,"beta_fraction":[-5,9],"lab_theta_window":[0.0,3.141592653589793],"lab_energy_window":[0.7,0.9]},

    {"id":"kn-07","x":0.2,"beta_fraction":[-4,5],"lab_theta_window":[1.0,2.7],"lab_energy_window":[0.1,0.5]}
**已核实原题。** 对 `1−2−3−4+5+6+` 在 3、4 外线施加合法 BCFW shift，仅有两个非零递推图；原文推导出两个项的紧凑式，并对照传统 38 个 color-ordered 图。原式含旋量夹积及看似 spurious 的分母，归一化为书中 `−4ig⁴` 约定，不能直接与采用另一顶点归一化的库比较。
  ],

  "probes": [
**建议研究任务。** 公开自洽 spinor-helicity 约定、合法复在壳动量构造器与低点起始振幅，要求提交通用递推实现；验证完整六点振幅、不同合法 shift 等价性，以及 approaching 物理/伪极点时的因子化或抵消。输出可执行求值器与代表性点结果，而不是只填一条已给出的公式。
    {"id":"amp-01","x":0.015,"cos_theta":-0.2,"incoming_gauge_shift":0.3,"outgoing_gauge_shift":-0.7},

    {"id":"amp-02","x":0.8,"cos_theta":0.4,"incoming_gauge_shift":-0.5,"outgoing_gauge_shift":0.2},
    {"id":"amp-03","x":8.0,"cos_theta":-0.7,"incoming_gauge_shift":0.4,"outgoing_gauge_shift":0.6},
    {"id":"amp-04","x":40.0,"cos_theta":0.97,"incoming_gauge_shift":0.7,"outgoing_gauge_shift":-0.3}
  ]
}
**可靠验证。** 参考用独立 Berends–Giele/显式树图递推与 BCFW 交叉核对；公共生成器保证动量守恒、在壳、旋量相位约定，不随机生成不合法 spinor 数据。soft/collinear 极限检验必须扣除有声明的奇异因子，公开相对/绝对误差尺度。多种外线排序只是同一题测试，不各算一道。

**独立性。** 与 QFT04 两图树散射不同，重点是高多重度在壳递推和因子化，而不是双图 trace。与 G67 也不同：树级递推不能替代一圈 D 维有理项重构。

### G67：D 维幺正割与全正螺旋有理项


exit_code=0
```
**已核实原题。** 外胶子四维、loop momentum d=4−2ε。把额外维分量写成 `μ²=−ℓ⊥²`，四维 massive scalar loop 的 quadruple cut 给出 box 系数 `8g⁴ ℓ⊥⁴ [12][34]/(⟨12⟩⟨34⟩)`，triple cut 被 box 饱和、triangle 系数为零。`O(ε)` tensor contraction 乘 UV `1/ε` pole 保留有限有理项；结果按书中约定为 `−ig⁴/(12π²) [12][34]/(⟨12⟩⟨34⟩)`。四维 cuts 全零不能推出振幅零。

**建议研究任务。** 给出完整 cut 数据/树子振幅接口，要求选择足够的积分基并恢复 rational part；比较仅四维割、过早置 μ=0、遗漏 ε 因子的错误重构，输出 box/triangle 系数、有限项和多点振幅。关键是重构与极限顺序，不能只把该常数乘 spinor 比值。

**可靠验证。** 用独立 D-dimensional tensor/维数位移公式计算有限系数，再以 cut 重算检查；统一复标量与实标量、color-ordered coupling、loop measure 归一化。中间 scaleless UV integral 不能无 IR 区分地当完整零积分；需公开 regulator 或说明只提取 UV pole 的操作。

**独立性。** 虽有“维数正则化”和“一圈”标签，机制不同于 QFT01 的真空极化色散，也不同于 Radovanović 一般 counterterm bookkeeping；本题考 D 维遗漏信息和有限 rational remainder。

### G69：Dirac 谱与 Banks–Casher 极限

**已核实原题。** 成对 Dirac 本征值使 `tr[(iDslash−m)⁻¹]=−Σ m/(λn²+m²)`；按体积归一化后，先取热力学极限、再取 m→0，得到 `⟨ψbarψ⟩=−πρ(0)`。这里 ρ 是按体积归一化、经规范场平均的谱密度。有限体积谱离散，有 spectral gap；不能不区分两个极限便把一个有限矩阵的最小本征值视为凝聚。

**建议研究任务。** 公开多个体积的 paired low-lying spectra 和严格生成规则，要求恢复小质量凝聚、外推 thermodynamic/chiral limits、判断哪个谱族支持非零凝聚，并给出可核验的极限路径/有限体积诊断。保留另一个不支持凝聚的 gapped 家族，避免所有输入只需照公式求和。

**可靠验证。** 独立已知谱密度积分产生连续极限真值，finite V 和小 m 由高精度离散求和复核。每个谱族需声明零模、UV 截断和是否纳入 fermion determinant 权重。若使用合成谱，就称为解析可控的谱模型，不能伪称实际 lattice-QCD 数据。评分不依赖单一经验拟合阶数，合法等价外推方法均可。

**独立性。** 与 G26 分别是谱推断与有效势机制；与 G70 分别是近零谱密度和零点拓扑手征结构。不能把谱的多个体积当成多道独立题。

### G70：格点手征倍增的完整零点诊断

**已核实原题。** 局域/准局域且平移不变的格点 Dirac operator 对应 Brillouin 环面上的连续实向量场 Fμ(p)。零点附近 Jacobian 的取向决定有效手征性；单方向反射通过 γ1γ5 similarity 交换左右手征。Poincaré–Hopf 在环面上给出总指数零，因此在本题假设下左右手征数相等。定理有假设，不能断言所有现代 lattice fermion 方案都被排除。

**建议研究任务。** 对几组明确周期、含非分离耦合/变形的格点 kinetic kernels，找全 Brillouin 区零点，给出 Jacobian 符号和总指数证书，诊断一个“只剩单手征零点”的主张违反哪项假设。根的变化应改变分析，但各 kernel 仍作为同一研究任务内部案例。

**可靠验证。** 使用可解析分块求根或 interval enclosure 做完整性证书，独立数值 winding/degree 核对局部指数。不能只在网格上找到几个零点；周期边界同一点不可重复计数。Wilson term 若作为对照，需公开它如何改变 chiral assumptions/质量而不是胡称其违反拓扑定理。

**独立性。** 动量空间的格点 fermion doubling，不是 G49 的 gauge vacuum winding。作为第 48 题的替换更能降低与既有 QM 隧穿题的重叠。

### G72：中心对称、边界条件与 Polyakov 环

**已核实原题。** `center(SU(N))=ZN`；Ω(β)=ξΩ(0) 的 center transformation 保持 gauge field periodic，却使 fundamental Polyakov loop 乘 ξ。它不是单纯冗余 gauge reparametrization，因为会改变 gauge-invariant observable。纯 YM 中 Polyakov loop 与无限重夸克自由能关联；基本表示 dynamical fermion 的 antiperiodicity 不被非平凡 center twist 保持，从而显式破坏中心对称；adjoint matter 不破坏该对称。

**建议研究任务。** 给出 holonomy/representation 数据及几组候选 twisted transformations，要求判断边界条件合法性、计算 Polyakov loops 在各表示的变换、区分显式与自发破缺，并检验某个“有限体积 mean loop 为零所以必禁闭”的结论是否被 sector averaging 混淆。研究情境以确切矩阵数据和变换判别为主。

**可靠验证。** 高精度 SU(N) 矩阵乘积与群表示 character 独立核对。有限体积无外源时对全部中心扇区平均可使 loop 均值为零，不能仅此判相；若要判 thermodynamic phase，需提供体积序列、源/扇区约定和相变模型真值。Polyakov free energy 要声明 renormalization/静态源自能约定，不把任意有限矩阵分布伪称完整 YM 动力学。

**独立性。** 热场全局对称与 representation/boundary consistency，区别于局部 Wong 输运和谱凝聚。

### G73：Vlasov 推导的 HTL 因果响应

**已核实原题。** 从 massless classical particles 的 Liouville/Vlasov 方程求 f1，得到 induced current 与非局域有效 Lagrangian。电子/正电子和 spin degeneracy 合为4；书中 thermal radial integral 产生 `e²T²/6`，最终 `Πμμ=e²T²/3`、`Π00=(e²T²/3)[1−(k0/2k) ln|(k0+k)/(k0−k)|]`。原页最后写了实数 log 形式；若 benchmark 要问 retarded imaginary part，必须另外公开 i0 约定并独立推导，不能把绝对值 log 当完整 retarded tensor。

**建议研究任务。** 给定已声明的 retarded Vlasov response 与热分布，重建 Πμν、纵/横响应及 space-like Landau damping，区分 static 与 long-wavelength 极限，审计破坏 Ward identity 的候选近似。可扩展 anisotropy，但那是新增推导，不能暗用 isotropic tensor decomposition。

**可靠验证。** 参考用 analytic angular integration，真值用独立复频率 angular quadrature+iη extrapolation，核查 kμΠμν=0、Debye limit 和 dispersion roots。light-cone 邻域要公开 tolerances，避免以极端病态浮点条件制造难度。

**独立性与优先级。** 虽与 QFT01 同属 polarization tensor，本题的 thermal kinetic origin、因果响应和非交换极限不同；必须保留这些维度。需再查 ED/SP 已有题是否已有等价 plasma dielectric inverse problem，若有则退为备选。不能把 QED 换成 QCD 便再算一题。

### G75：LPM 形成时间与碰撞积分重求和

**已核实原题。** 由 induced current 得到 retarded photon self-energy，再由线性化 Boltzmann–Vlasov 得到横向碰撞核 `mD²/[ℓ⊥²(ℓ⊥²+mD²)]` 乘 `F(p)−F(p−ℓ⊥)`。当 `v·K≲e²T`，形成时间覆盖多次碰撞，各阶同量级，不能用有限阶单散射展开。高温 near-collinear 几何产生 soft emission suppression；在 `m≫mD`、leading-log diffusion approximation 下，原书化为可解 ODE/Laplace expression，最后 soft spectrum 从 Bethe–Heitler 的 `1/k0` 变成 `1/sqrt(k0)`。

**建议研究任务。** 以完整公开的 dimensionless collision/formation equation 为起点，数值求 finite-frequency photon response，与 single-collision 和 leading-log diffusion 近似比较，确定各近似适用区并重建 soft scaling。需要提交可执行求解器和 convergence evidence；这不是要求训练模型或大 GPU。

**可靠验证。** 独立离散化/网格 refinement 和 diffusion-limit analytic solution 互检；碰撞核的差分必须整体积分，不能将两个各自 IR 发散的项拆开。原页 188 的差分 Taylor/扩散符号必须从对称积分重新独立推导，不机械转录 OCR/原文；最终算子的耗散性给出额外证据。只在声明 `m≫mD` 范围使用 leading-log ODE，不把它当全参数真值。

**独立性。** G73 是无碰撞 hard-loop linear response；G75 研究 coherence/formation time 内 collisions 的 nonperturbative resummation。若两个题都简化成同样的二维响应积分，则需要重构以恢复差异。

### G80：强场 Schwinger 模式混合与成对关联

**已核实原题。** 复标量场在给定背景下方程线性且不含 backreaction。in/out 模式通过 αk、βk 的 Bogoliubov transformation 关联，满足 `|αk|²−|βk|²=1`。渐近常量 Ai 即使场强为零也改变 canonical wave number 与 kinetic momentum 的关系，提取渐近频率不能一律用 sqrt(m²+k²)。每个模式的产对数是均值 `|βk|²` 的 geometric distribution；真空持续概率为 `exp[−V∫ln(1+|βk|²)]`，一般不等于 `exp(−Npairs)`。该差别在 occupation 大时重要。

**建议研究任务。** 给定 smooth finite-duration external pulse 的 A(t)，求 mode ODE 的 in/out mixing、动量谱、vacuum survival 和 pair factorial cumulants；区分 canonical/kinetic momentum、双脉冲相干干涉与无关联 Poisson 模型。脉冲与数值参数是本 benchmark 新设计，需公开它们，不声称原题80提供了特定 Sauter/double-pulse 数据。

**可靠验证。** 独立高精度 mode integration/transfer matrix 互检，检查 Wronskian 和渐近平台截断误差，必要时用解析可解单脉冲锚定。弱产生时提取极小 β 要控制 cancellation，误差指标公开绝对 floor。particle-vacuum relations 分别验证，不能单从 P0 反推出完整动量谱。多脉冲实例仍是一道题。

**独立性。** 与 Radovanović 微扰振荡外场 e+e− 产生的物理统计/机制不同，但若同选必须明确：这里是 nonperturbative scalar mode mixing/occupancy correlations，另题应是真正 fermionic perturbative response。若两题最终都仅求一张产生率曲线，则合并，不能靠换统计/脉冲名字计数。

## 明确不建议直接采用的候选

1. **G82 Anderson Localization。** 已读 PDF225–228/印347–350。原题通过 leading Born self-energy 的虚部说明 disorder-averaged 单粒子传播子衰减；单凭这种衰减不能充分证明 Anderson localization。扩散金属也有 finite elastic scattering rate 和平均传播子衰减，真正局域化还需 transport/多重散射干涉或态的 spatial localization 证据。不能把 `ImΣ≠0` 直接评分为“所有能量均局域化”。若将来选，应独立引入 transfer-matrix/participation/transport 验证，已超出此原题的简单改造，故首轮不选。
2. **G68 五点 all-plus。** 本次没有完整核读其全部解答；目录和开头显示它是 G67 的延伸。不能将四点改五点当作当然独立的新题；优先只留 G67，避免相同 generalized-unitarity 技法扩点凑数。
3. **G74 gluon HTL。** 与 G73 是延续；本轮不把 QED 换 QCD 单独计一道，除非真正新增非线性非阿贝尔 n-point hard-loop 信息与独立验证。
4. **G81 Unruh/Hawking。** 只浏览了开头和书内交叉引用，未在本轮完整核读；与 G80 共用 Bogoliubov 主机制，还可能与 GR 题重合，不作为已审定候选。
5. **G48 双阱隧穿。** 并非题目质量差，而是更适合作为 quantum mechanics sector 的备选，当前优先 G49 的纯规范拓扑内容。

## 选题进入封装前的统一门槛

每个选题须真正提供：公开、足以求解的物理定义与约定；可执行的简单基线和同信息/同资源的专家解；独立真值或可重算证书；公开分数定义；能拒绝空提交/实质错误解并接受合法替代解的校准记录。不能用语言风格、与参考解相似度或模型是否复述教材关键词打分。

本轮优先选题覆盖多个机制，但**没有任何一题仅凭这份评审就能登记为已有效验收或已难倒指定模型**。对应题包正式生成后，还须独立验证、冻结和按课程统一 CLI 每题3次正式测评。现有 oracle/nop 仅说明题包运行链，不能替代这些正式测评。

原课程材料写明冻结登记10–20题、最多20题计分；本项目用户另与助教沟通扩展题量。建议新增20道先作为扩展题库，正式提交清单遵循最终确认口径；不能在说明中声称“扩展到50题自然得到额外分数”。

exit_code=0
```

===== PDF PAGE 219 =====
Chapter 11. Renormalization and regularization 221
−iΣ2(p)= −(−ig)2
2 μϵ
∫ 1
0
dx
∫ dDk
(2π)D
1
[k2 − 2k ·px +p2x −m2]2 .
The integration over the momentumk gives
−iΣ2(p)= i
2μϵg2 1
(4π)2−ϵ/2Γ
(ϵ
2
)∫ 1
0
dx (m2 −p2x +p2x2)−ϵ/2
= ig2(4πμ2)ϵ/2
2(4π)2
(2
ϵ −γ +o(ϵ)
)
×
[
1 − ϵ
2
∫ 1
0
dx
(
lnm2 +l n ( 1+p2
m2x(x − 1))
)]
.
Finally, the integration over the Feynman parameterx gives (forp2 < 4m2)
−iΣ2(p)= ig2
32π2
[
2
ϵ −γ +2+l n 4πμ2
m2 − 2
√
4m2
p2 − 1arc s i n
√
p2
4m2
]
.
The self–energy of the particle is
−iΣ(p)= −iΣ1(p) − iΣ2(p).
The mass shift isδm2 =Σ(m2)= Σ1(m2)+ Σ2(m2).
11.8 The vertices in this theory are shown in Fig. 11.2.
Fig. 11.2. Vertices in σ–model
The self–energy of the π particle is determined by the diagrams given in
Fig. 11.3. The full line depict theπ ﬁeld, while the dashed line depictσ.
The ﬁrst diagram is one of the terms in the second order of the perturbation
theory
1
2(−iλv)22
∫
dx1dx2 ⟨0|T(π(y1)π(y2)σ3(x1)σ(x2)π2(x2)) |0⟩ , (11.25)


===== PDF PAGE 220 =====
222 Solutions
Fig. 11.3. The one-loop correction to the π propagator
so that
−iΣ1(p2)=6 ( −ivλ)2 i
−m2
∫ dDk
(2π)D
i
k2 −m2 .
The symmetry factor of this diagram is 6, since oneπ ﬁeld can be contracted
to π ﬁeld from ππσ-vertex in two ways, while σσ contraction in the vertex
σσσ can be done in 3 ways. Other diagrams are:
−iΣ2(p2)= λ
∫ dDk
(2π)D
1
k2 −m2 ,
−iΣ3(p2)= −2v2λ2
m2
∫ dDk
(2π)D
1
k2 ,
−iΣ4(p2)=3 λ
∫ dDk
(2π)D
1
k2 ,
−iΣ5(p2)=4 λ2v2
∫ dDk
(2π)D
1
k2 −m2
1
(k +p)2 .
Note that only the last diagram depends on the momentump. The renormal-
ized mass is determined bym2R =Σ(0). It is easy to see that
−iΣ5(0) = 4λ2v2
∫ dDk
(2π)D
1
k2 −m2
1
k2
= 4λ2v2
m2
∫ dDk
(2π)D
( 1
k2 −m2 − 1
k2
)
.
By summing all diagrams we obtain
Σ(0) =Σ1(0) +Σ2(0) +Σ3(0) +Σ4(0) +Σ5(0) = 0,
somR =0 .
11.9 The amplitude for the diagram


exit_code=0
```

### 2026-11-16T21:57:46.899289+08:00

```bash
python3 tools/read_qft_source_pages.py gelis 34:40,55:61,274:285
```

```text

### 2026-11-16T21:57:46.899266+08:00

```bash
python3 tools/read_qft_source_pages.py problem-book 65:66,225:232
```

```text

===== PDF PAGE 65 =====
Chapter 11. Renormalization and regularization 63
11.5. Compute
Iαβμνρσ =
∫
dDkkαkβkμkνkρkσ
(k2)n .
Also, ﬁnd the divergent part of the previous integral for n = 5. Apply the
dimensional regularization.
11.6. Consider the interacting theory of two scalar ﬁeldsφ andχ:
L = 1
2(∂φ)2 − 1
2m2φ2 + 1
2(∂χ)2 − 1
2M 2χ2 −gφ2χ.
(a) Find the self–energy of theχ particle, −iΠ(p2).
(b) Calculate the decay rate of theχ particle into twoφ particles.
(c) Prove that
ImΠ(M 2)= −MΓ.
11.7. Consider the theory
L = 1
2(∂μφ)2 −m2
2 φ2 − g
3!φ3 − λ
4!φ4 .
Find the expression for the self–energy and the mass shiftδm.
11.8. The Lagrangian density is given by
L = 1
2(∂μσ)2 + 1
2(∂μπ)2 −m2
2 σ2 −λvσ3 −λvσπ2 −λ
4 (σ2 +π2)2 ,
whereσ andπ are scalar ﬁelds, and v2 = m2
2λ is constant. Classically,π ﬁeld
is massless. Show that it also remains massless when the one–loop corrections
are included.
11.9. Find the divergent part of the diagram
Prove that this diagram cancels with the diagram of the reverse orientation
inside the fermion loop.
11.10. The polarization of vacuum in QED has form
−iΠμν(q)= −i(qμqν −q2gμν)Π(q2).
Prove the following expression:
ImΠ(q2)= − e2
12π
(
1+ 2m2
q2
)√
1 − 4m2
q2 θ
(
1 − 4m2
q2
)
.


===== PDF PAGE 66 =====
64 Problems
11.11. In scalar electrodynamics two diagrams give contribution to the po-
larization of vacuum. Using dimensional regularization derive the following
expression for the divergent part of the vacuum polarization:
ie2
24π2
1
ϵ (pμpν −p2gμν).
11.12. The Lagrangian density for the pseudoscalar Yukawa theory is given
by
L = 1
2(∂φ)2 −m2
2 φ2 + ¯ψ(iγμ∂μ −M)ψ − ig ¯ψγ5ψφ − λ
4!φ4 .
(a) Find the superﬁcial degree of divergence for this theory and the corre-
sponding divergent amplitudes. Write the bare Lagrangian density as a
sum of the initial Lagrangian density and counterterms. Write out the
Feynman rules in the renormalized theory.
(b) Find the self–energy of the spinor ﬁeld at one–loop and determine the
corresponding counterterms.
(c) Find the self–energy of the scalar ﬁeld at one–loop and determine the
corresponding counterterms.
(d) Calculate the one–loop vertex correctionφ ¯ψψ andδg.
(e) Calculate the one–loop vertex correctionφ4 andδλ.
11.13. Consider massless two–dimensional QED, the so–called Schwinger mo-
del.
(a) Calculate the vacuum polarization at one–loop.
(b) Find the full photon propagator and read oﬀ the mass of the photon.
11.14. Considerφ3 theory in six–dimensional spacetime, with the Lagrangian
density given by
L = 1
2(∂φ)2 −m2
2 φ2 − g
3!φ3 −hφ.
(a) Determine the superﬁcial divergent amplitudes. Write the renormalized
Lagrangian density and derive the Feynman rules.
(b) Calculate the tadpole one–loop diagram and explain why the contribution
of the tadpole diagrams can be ignored.
(c) Calculate the propagator correction at one–loop order and determine δZ
andδm. Use the minimal subtraction (MS) scheme.
(d) Calculate the vertex correction and ﬁndδg.
(e) Derive the relationsm0 =m0(m,g,ϵ )a n dg0 =g0(m,g,ϵ ).


===== PDF PAGE 225 =====
Chapter 11. Renormalization and regularization 227
−iΠ(2)μν =e2
∫ dDk
(2π)D
(2k +p)μ(2k +p)ν
(k2 −m2)((k +p)2 −m2) .
By using the Feynman parametrization in the previous integral we get
−iΠ(2)μν =e2
∫ 1
0
dx
∫ dDk
(2π)D
4kμkν +2kμpν +2kνpμ +pμpν
[k2 +2xk ·p +p2x −m2]2 .
Applying the formulae (11.A–C) it follows that :
−iΠ(2)μν = ie2πD/2
(2π)D
∫ 1
0
dx
[
Γ
(ϵ
2
) 1
(m2 +p2x2 −p2x)ϵ/2 (4x2 − 4x +1 )pμpν
− 2gμν
Γ
(ϵ
2 − 1
)
(m2 +p2x2 −p2x)ϵ/2−1
]
,
which is equal to
−iΠ(2)μν = ie2
16π2
( 2
3ϵ(pμpν −p2gμν)+ 4m2
ϵ gμν
)
+ﬁ n. part. (11.38)
Adding the divergent parts of the expressions (11.37) and (11.38) we get the
requested result. Note that the terms proportional tom2 cancel. So, the ﬁnal
result is gauge invariant, as expected.
11.12
(a) Let us introduce the following notation:
Nf − the number of external fermionic lines
Ns− the number of external scalar lines
Pf − the number of internal fermionic lines
Ps− the number of internal scalar lines
V3− the number of ¯ψγ5ψφ vertices
V4− the number ofφ4 vertices
L− the number of loops.
Then the superﬁcial degree of divergence for a diagram is
D =4L − 2Ps −Pf .
On the other hand,L can be expressed as
L =Ps +Pf − (V − 1),
since it is a number of independent internal momenta. By combining the
previous formulae with
2V3 =Nf +2Pf ,
V3 +4V4 =Ns +2Ps ,
we get


===== PDF PAGE 226 =====
228 Solutions
Fig. 11.4. Superﬁcially divergent diagrams in the Yukawa theory
D =4 −Ns − 3
2Nf .
Superﬁcially divergent amplitudes are shown in Fig. 11.4.
The ﬁrst diagram is the vacuum one and it can be ignored; the second and
ﬁfth are equal to zero. The bare Lagrangian density is
L0 = 1
2(∂φ0)2 −m20
2 φ20+ ¯ψ0(iγμ∂μ −M0)ψ0 −ig0 ¯ψ0γ5ψ0φ0 −λ0
4!φ40 . (11.39)
If we rescale the ﬁelds as
φ0 =
√
Zφφ =
√
1+ δZφφ,
ψ0 =
√
Zψψ =
√
1+ δZψψ,
and introduce a new set of variables:
Zφm20 =m2 +δm2
ZψM0 =M +δM
Zψ
√
Zφg0 =μϵ/2(g +δg)
Z2φλ0 =μϵ(λ +δλ),
the bare Lagrangian density becomes
L0 = 1
2(1 +δZφ)(∂φ)2 −m2 +δm2
2 φ2 +i ( 1+δZψ) ¯ψ/∂ψ
− (M +δM) ¯ψψ − i(g +δg)μϵ/2 ¯ψγ5ψφ − (λ +δλ)μϵ
4! φ4 .
The Feynman rules are given in the Fig. 11.5
(b) The one–loop fermionic propagator correction is represented in Fig. 11.6.
The ﬁrst diagram is
−iΣ2(p)= −g2μϵ
∫ dDk
(2π)D
1
k2 −m2 +i 0γ5
/p − /k +M
(p −k)2 −M 2 +i 0γ5 .


===== PDF PAGE 227 =====
Chapter 11. Renormalization and regularization 229
Fig. 11.5. Feynman rules in renormalized Yukawa theory
Fig. 11.6. The one–loop correction to fermionic propagator
Sinceγ5/aγ5 = −/a and (γ5)2 =1w eh a v e
−iΣ2(p)= − g2μϵ
(2π)D
∫
dDk −/p +/k +M
(k2 −m2 + i0)((p −k)2 −M 2 +i 0 )
= − g2μϵ
(2π)D
∫
dDk
∫ 1
0
dx −/p +/k +M
(k −px)2 −Δ +i 0 )2
= − g2μϵ
(2π)D iπD/2Γ (ϵ
2
)∫ 1
0
dx/p(x − 1) +M
Δϵ/2 , (11.40)
whereΔ =M 2x +m2(1 −x) −p2x +p2x2. Since
μϵ
2DπD/2 = 1
16π2 (4πμ2)ϵ/2 = 1
16π2
(
1+ ϵ
2 ln(4πμ2)+ ... ) ,
we have
−iΣ2(p)= − ig2
16π2
[2
ϵ −γ +o(ϵ)
]∫ 1
0
dx[M +(x − 1)/p]
[
1 − ϵ
2 ln Δ
4πμ2
]
= − ig2
8π2ϵ(M − 1
2/p)+ﬁ n. part. (11.41)
The full one–loop correction to the fermionic propagator is
−iΣ(p)= − ig2
8π2ϵ(M − 1
2/p) − iδM +iδZψ/p +ﬁ n. part.
From the renormalization conditions:
Σ(/p =M)=0 ,
dΣ
d/p
⏐⏐⏐/p=M =0 , (11.42)


===== PDF PAGE 228 =====
230 Solutions
follows that
δZψ = − g2
16π2ϵ +ﬁ n. part,
δM = −g2M
8π2ϵ +ﬁ n. part. (11.43)
(c) The one–loop correction to the scalar propagator is represented in Fig.
11.7.
Fig. 11.7. The one-loop correction to the scalar propagator
The ﬁrst diagram is
−iΠ1(p2)= −i2g2μϵ
(2π)D
∫
dDk tr[γ5(/k +M)γ5(/p +/k +M)]
(k2 −M 2 + i0)((p +k)2 −M 2 +i 0 )
= g2μϵ
(2π)D
∫
dDk
∫ 1
0
dx tr[(−/k +M)(/p +/k +M)]
(k2 +2k ·px −M 2 +p2x)2
= g2μϵ
(2π)D
∫ 1
0
dx
∫
dDk 4(−k ·p −k2 +M 2)
(k2 +2k ·px −M 2 +p2x)2 ,
where we use the Feynman parametrization formula (11.G). Introducing a
new variablel =k +px we further have
−iΠ1(p2)=4 g2μϵ
∫ 1

0
dx
===== PDF PAGE 34 =====
∫ dDl
22 1 QUANTUM FIELD THEORY BASICS
(2π)D
use of (1.41). It is straightforward to check that
2M 2 −Δ −l2
δ
(l2 −Δ +i 0 )2
δλ(y)
= ig2
(
4π2
δS[λ]
∫ 1
δλ(x) S†[λ]
0
)
dx
= S2(x,y )+ S1(x)S†1(y)+ O(λ).
(
Therefore, at lowest order, (1.41) tells us that
1 − ϵ
S2(x,y )=− S1(x)S†1(y)= S1(x)S1(y) ify is not in the future light-cone ofx.
2 ln Δ
Using the fact thatS2(x,y ) should be symmetric, we also have
4πμ2
S2(x,y )= S2(y,x )= S1(y)S1(x) ifx is not in the future light-cone ofy.
)
×
(Note that these two conditions onx,y are both satisﬁed if their separation is space-like. For
(
such a space-like separation, we could thus use either of the two formulas. This does not
(M 2 −p2(x2 −x))(2
lead to any contradiction, provided thatS1(x) is a local function of the ﬁeld operator and its
ϵ −γ +o(ϵ))+
derivatives.) Therefore, the answer valid for anyx,y can be written as
+ D
S2(x,y )= T (S1(x),S1(y)).
2 (−2
(One may check a posteriori that the unitarity constraint is satisﬁed.) Using the same constraints,
ϵ − 1+ γ +o(ϵ))(M 2 +p2(x2 −x))
one could show by induction that the coefﬁcient of ordern,Sn(x1,...,x n), is the time-ordered
)
product ofn factorsS1. Therefore, we see that unitarity and causality provide an almost closed
= ig2
form for theS-matrix,
2π2ϵ
S[λ]= Te x p
(p2
( ∫
2 −M 2
d4xS 1(x)λ(x)),
)
in which the only remaining unknown is the ﬁrst coefﬁcientS1(x). The latter can be related to
+ﬁ n. part,
the interaction Lagrangian by considering aλ(x) which is non-zero in an inﬁnitesimal region
whereΔ =M 2 +p2(x2 −x). The second diagram is
−iΠ2 = iλm2
16π2ϵ +ﬁ n. part. (11.44)
Summing, we obtain


===== PDF PAGE 229 =====
Chapter 11. Renormalization and regularization 231
of spacetime. Therefore, regardless of the microscopic details of a given theory – which control
−iΠ(p2)= ig2
the ﬁrst coefﬁcientS1 –, the general structure of theS-matrix is governed to a large extent by
2π2ϵ
the constraints provided by unitarity and causality.
(p2
5. Landau Equations for Soft and Collinear Singularities The goal of this problem is to
2 −M 2
study the singularities that may occur in a Feynman integral due to vanishing denominators
(not to be confused with ultraviolet divergences, due to an integrand that decreases too slowly
)
at large momentum). Consider a Feynman integral with L loops andm denominators:
+ iλm2
I({pi}) ≡
16π2ϵ +iδZφp2 −iδm2 +ﬁn.part. (11.45)
∫ L∏
Using the renormalization conditions:
j=1
dD𝓁j
(2π)D
Π(p2 =m2)=0
N({pi},{𝓁j})
dΠ
(q21 −m21 +i0+)··· (q2m −m2m +i0+).
dp2
In this integral, the pi are the external momenta, the 𝓁j the loop momenta, and the qr the
⏐⏐⏐
momenta of the propagators in the loops, i.e., linear combinations of loop momenta and
p2=m2
external momenta of the formqr ≡ ∑Lj=1 ϵrj𝓁j +Δr (where the coefﬁcientsϵrj take values in
=0 , (11.46)
{−1,0, +1} and theΔr depend only on the external momenta).
we get

δZφ = − g2

4π2ϵ +ﬁ n. part
===== PDF PAGE 35 =====
δm2 = λm2
5 LANDAU EQUATIONS FOR SOFT AND COLLINEAR SINGULARITIES 23
16π2ϵ −g2M 2
5.a Use Feynman parametersxr to combine them denominators into a single one,Dm.
5.b By considering the following elementary examples,
∫ +1
−1
dx
x +i0+,
∫ +1
0
dx
2π2ϵ +ﬁ n. part. (11.47)
x +i0+,
(d) The amplitude of the diagram
∫ +1
is
−1
iM3 =( ig)3μ3ϵ/2
dx
∫ dDk
(x +i0+)(x −i0+),
(2π)D
explain why singularities occur only when a pole is located on the boundary of the
γ5(/k +/q +M)γ5(/k +M)γ5
integration manifold, or when multiple poles “pinch” the integration manifold.
((k +q)2 −M 2)(k2 −M 2)((k −p)2 −m2)
5.c Study the variations of D as a function of the loop momenta 𝓁j, and explain why the
= −2ig3μ3ϵ/2
zeroes of D must also be extrema ofD in order to produce singularities.
(2π)D γ5
5.d Now study the dependence with respect to the Feynman parameters and show that, for
∫ 1
eachr, one must have eitherxr = 0 orq2r = m2r in order to have a singularity.
0
5.e Conclude that the conditions for a singularity are given by the Landau equations:
dx
For each propagatorr: xr(q2r −m2r )= 0; For each loopj:
∫ 1−x
m∑
r=1
ϵrjxrqμr = 0.
5.f Determine the singularities of the one-loop
Feynman diagram shown on the right (assume
k2 = k′2 = 0, (k +k′)2 >0 and all internal
particles are massless)
q2
q1=𝓁
q3
k
0
k'
k+k'
5.a Consider a Feynman integral withL loops and m denominators. Generically, such an
integral may be written as
dz
I({pi}) ≡
∫
∫ L∏
dDk M 2 − /q/k +M/q −k2
j=1
dD𝓁j
((k +qx −pz)2 −Δ)3
(2π)D
N({pi},{𝓁j})
= −2ig3μ3ϵ/2
(q21 −m21 +i0+)··· (q2m −m2m +i0+),
(2π)D γ5
where thepi are the momenta external to the loops and the𝓁j areL independent loop momenta.
∫ 1
The momentaqr are the momenta carried by the various propagators along the loops. They are
0
all of the form
dx
qr ≡
∫ 1−x
L∑
j=1
0
ϵrj𝓁j +Δr,
dz
where the coefﬁcientsϵrj take values in{−1,0, +1} (a propagator may belong to a loop or not,
and may be oriented in the same way as the loop momentum or in the opposite direction) and
∫
where the Δr depend only on the external momenta (they are thus constants from the point
dDl N
(l2 −Δ)3 ,
of view of evaluating the loop integrals). N({pi},{𝓁j}) is a numerator that comprises all the
where
momentum dependence that may arise, e.g., from three-gluon vertices in QCD or from the
Δ =x2q2 +z2p2 +( 1−z)M 2 −xq2 +zm2 −p2z − 2xzq ·p
Dirac traces if there are fermion loops. This factor plays no role in analyzing the singularities of
and

N =M 2 − (l −xq +zp)2 +M/q − /q(/l −x/q +z/p).
In the previous formulae we introduced a variablel =k +xq −zp.A sw e
are interested to ﬁnd only the divergent part of i M3,i ti su s e f u lt on o t e

that only l2–term in the numerator of the integrand is divergent. So, by
using (11.C) we get:
===== PDF PAGE 36 =====

24 1 QUANTUM FIELD THEORY BASICS

the integral, except in those rare situations where a singularity due to a vanishing denominator
===== PDF PAGE 230 =====
may be canceled by an accidental concomitant vanishing of the numerator.
The ﬁrst step is to combine the m denominators into a single one thanks to Feynman
parameterization:
I({pi})= Γ (m)
232 Solutions
∫ L∏
iM3 =2 ig3μ3ϵ/2γ5
j=1
∫ dDl
dD𝓁j
(2π)D
(2π)D
∫ 1
∫
0
xr≥0
dx
m∏
∫ 1−x
r=1
0
dxr δ
dz l2
(
(l2 −Δ)3 +...
1−
= −g3μϵ/2(4 −ϵ)
∑
32π2 γ5
r
(2
xr
ϵ −γ +...
) N({pi},{𝓁j})(
)∫ 1
D({qr},{xr})+i0+)m, (1.42)
D({qr},{xr}) ≡
m∑
r=1
xr(q2r −m2r ).
5.b In this problem, we assume that the ultraviolet divergences have been properly disposed of
by some regularization, and we are chieﬂy interested in the possibility of additional singularities
0
that may arise from a vanishing denominator. Obviously, that the equation
dx
D({qr},{xr})= 0
×
has solutions in the integration domain is a necessary condition for having such singularities.
∫ 1−x
But a zero of the denominator of the integrand does not always lead to a singularity in the
0
integral. In order to see this, let us consider the following toy examples:
dz
∫ +1
(
−1
1 − ϵ
dx
2 ln Δ
x +i0+ =
4πμ2
∫ +1
)
−1
.
dx
Finally
(
iM3 = −g3μϵ/2
P
8π2ϵ γ5 +ﬁ n. part. (11.48)
(1
The vertex correction is
x
so, from
iV3 =
(
gγ5μϵ/2 +δgγ5μϵ/2 −g3μϵ/2
)
8π2ϵ γ5 +ﬁ n.part
−iπδ (x)
)⏐⏐⏐
)
q2 =0 =gγ5
=− iπ,
∫ +1
follows
0
δg = g3
dx
8π2ϵ +ﬁ n. part.
x +i0+ = ∞,
(e) Let us ﬁrst calculate the following diagram
∫ +1
Since we have to ﬁnd the divergent part of this diagram we can put that
−1
the external momenta are equal to zero. Then,
dx
iM4(k1 =k2 =k3 =k4 =0 )= −g4μ2ϵ
(x +i0+)(x −i0+) = limε→0+
∫ dDp
∫ +1
(2π)D
−1
tr[γ5(/p +M)]4
dx
(p2 −M 2)4 .
x2 +ε2 = ∞.
(11.49)
In the ﬁrst example, the integral is ﬁnite despite the fact that denominator vanishes atx = 0,
Since
γ5(/p +M)γ5(/p +M)=( −/p +M)(/p +M)= M 2 −p2
we have

because the integration contour is slightly shifted from the singularity by the presence of the

i0+. An inﬁnite result would be obtained when it is impossible to shift the contour to avoid
===== PDF PAGE 231 =====
the pole. In the second example, we cannot avoid the singularity because the pole occurs on
Chapter 11. Renormalization and regularization 233
the boundary (here, at an endpoint) of the integration domain. In the third example, there are
iM4(k1 =k2 =k3 =k4 =0 )= −4g4μ2ϵ
two poles in the interior of the integration range, but these poles pinch the integration contour,
∫ dDp
which prevents moving the contour to avoid the poles and also leads to an inﬁnite result.
(2π)D
5.c Although the conditions of occurrence of a genuine singularity are the same, the situ-
1
ation we have to analyze is arguably more complex than these toy examples because of the
(p2 −M 2)2
multivariate nature of the denominator. For a multi-dimension integral, the above condition is
= −ig4μϵ
that the poles of the integrand cannot be avoided by deforming the integration manifold. We
4π2
can make the following observations:
(2
• Note ﬁrst that the fact thatD is raised to them-th power in (1.42) is irrelevant for this
ϵ −γ
discussion: every zero of D leads to a pole of order m of the integrand, but this is
)(
equivalent to having m poles all on the same side of the integration domain, so this
1 − ϵ
cannot produce a pinch.
2 ln M 2

4πμ2

)
===== PDF PAGE 37 =====
= −ig4μϵ
5 LANDAU EQUATIONS FOR SOFT AND COLLINEAR SINGULARITIES 25
2π2ϵ +ﬁ n. part. (11.50)
The previous result should be multiplied by a factor 6 as there are six
diagrams of this type.
The complete four vertex is
iV4 =
(
−iλμϵ − iδλμϵ − 6ig4μϵ
• For theL loop momenta𝓁j, the integration domain is R DL. We may add to this domain
2π2ϵ + 3iλ2μϵ
16π2ϵ +ﬁ n. part
)⏐⏐⏐
a point at inﬁnity (assuming an ultraviolet regularization, the integrand goes to zero in
s=4m2,t=u=0
all directions at inﬁnity), which leads to an integration domain topologically equivalent
= −iλ, (11.51)
to aDL-dimensional sphereSDL . This domain is boundaryless and therefore the only
and ﬁnally
possibility of singularities when integrating over the loop momenta is to have a pinch.
δλ = −3g4
• For the Feynman parameters xr, the integration domain is a (m − 1)-dimensional
π2ϵ + 3λ2
simplex,
16π2ϵ +ﬁ n. part. (11.52)
{
11.13 In this problem dimension of spacetime isD =2 −ϵ.
(x1,...,x m)
(a) The polarization of vacuum is given by:
⏐⏐⏐xr ≥ 0, ∑
−iΠμν(p)=( ie)2(−i2)
r
∫ dDq
xr = 1
(2π)D
}
tr[(/q − /p)γν/qγμ]
,
q2(q −p)2 . (11.53)
In D-dimensional space trace identities necessary to calculate the previous
expression read:
tr(γμγν)= f(D)gμν,
tr(γμγνγργσ)= f(D)(gμνgρσ −gμρgνσ +gμσgρν),
wheref(D) is any analytical function which satisﬁes the conditionf(2) =
2. Instead off(D) we will write 2 as we did in the previous problems (of
i.e., a line segment for m = 2, a triangle for m = 3, a tetrahedron for m = 4, etc.
course, theref(D) = 4). The Feynman parametrization gives
−iΠμν(p)= − 2e2
Clearly, this domain has a boundary and therefore endpoint singularities may occur.
(2π)D
∫ 1
Let us now study the behavior of the denominator D. This function is quadratic in the loop
0
dx
∫
dDq
× 2qμqν −q2gμν −pμqν −pνqμ +(p ·q)gμν
(q2 − 2p ·qx +p2x)2 . (11.54)
By using (11.A–C) in (11.54) we obtain
−iΠμν = −2ie2πD/2
(2π)D
∫ 1
0
dx
[
2
momenta, and linear in the Feynman parameters. Note also that, after a Wick rotation of the
( x2pμpν
loop momenta, D is a negative deﬁnite quadratic form in the Euclidean loop momenta, at ﬁxed
(−p2x +p2x2)1+ϵ/2Γ(1 +ϵ
2)
{xr} (this is obvious from the fact that the second-degree part ofD is a sum of squares weighted
− 1
by the negative coefﬁcients −xr). Therefore, when varying the loop momenta at ﬁxed {xr}, the
2
gμν
denominatorD has a maximum. We can distinguish the following cases:
(−p2x +p2x2)ϵ/2Γ(ϵ
2)
• If max{𝓁j}(D) <0 , the denominator is always non-zero and there is no singularity.
)
• If max{𝓁j}(D) >0 , the denominator can vanish, but the zeroes are simple zeroes that


cannot pinch the integration manifold for the variables{𝓁j}. The integral is also ﬁnite in
this case.
• The dangerous situation is when max{𝓁j}(D)= 0, because the location of the maximum
is then a double zero (as in the third of the toy examples considered earlier) in all the 𝓁μj
variables.
Therefore, we are seeking zeroes of D that are also extrema of its dependence with respect to
all the loop momenta:
D = 0, ∂D∂𝓁μj = 0.
Note that these conditions are still not sufﬁcient for a genuine singularity since we have only
discussed what happens at ﬁxed {xr}, and we have not yet analyzed whether it may be avoided
by a deformation of the integration domain for thexr’s. This discussion can be divided into
===== PDF PAGE 232 =====
two cases:
234 Solutions
• First, note that if q2r ⁄= m2r , a small variation ofxr will change the value ofD and move
−gμν
the denominator away from zero. For xr in the interior of its allowed range, this means
that there is no actual singularity. The only exception is atxr = 0, since this is on the
( x2p2
boundary of the integration range.
(−p2x +p2x2)1+ϵ/2Γ(1 +ϵ
2)
• In contrast, when q2r = m2r , the denominator D is independent of xr, and a zero of D
− 2 −ϵ
persists at all values ofxr.
2

1

(−p2x +p2x2)ϵ/2Γ(ϵ
2)
===== PDF PAGE 38 =====
)
− 2 xpμpν
26 1 QUANTUM FIELD THEORY BASICS
(−p2x +p2x2)1+ϵ/2Γ(1 +ϵ
2)
q2
+ gμν
p2x
q1=𝓁
(−p2x +p2x2)1+ϵ/2Γ(1 +ϵ
2)
q3
]
.
k
From the previous expression (forD → 2 i.e.ϵ → 0) we obtain
−iΠμν(p)= −i(pμpν −p2gμν)Π(p2)
k'
= − ie2
πp2 (pμpν −p2gμν), (11.55)
k+k'
from which we see that the polarization of vacuum is a ﬁnite quantity.
Figure 1.4 One-loop example of application of the Landau equations.
(b) The full photon propagator is obtained by summing the diagrams in the
Figure
iDμν(p)= −igμν
p2 +i 0 + −igμρ
p2 +i 0[p2gρσ −pρpσ]iΠ(p2) −igσν
5.d We now have all the information to give the conditions of occurrence of a singularity in
p2 +i 0 +...
the Feynman integralI({pi}):
= − i
p2 +i 0(gμν −pμpν
D = 0, ∂D∂𝓁μj = 0; for eachr, eitherxr = 0 orq2r = m2r.
p2 )(1 +Π(p2)+ Π2(p2)+ ... ) − ipμpν
(Note that the last condition can be phrased as xr(q2r − m2r )= 0 for each r, which makes
p4
the ﬁrst one, D = 0, redundant.) These conditions are known as the Landau equations.B y
= −
explicitly evaluating the derivative of the denominator with respect to the loop momenta, these
i(gμν − pμpν
conditions can be written as
p2 )
for each propagatorr: xr(q2r −m2r )= 0; for each loopj:
p2(1 −Π(p2)+i 0 ), (11.56)
m∑
were we discarded the ipμpν/p4-term in the last line since the propagator
is coupled to a conserved current. Then the photon propagator is
iDμν(p)= −
i(gμν − pμpν
p2 )
p2 − e2
π
r=1
. (11.57)
Photon mass ise/√
π.
ϵrjxrqμr = 0.
11.14 The dimension of spacetime isD =6 −ϵ.
5.e Consider now the example of Figure 1.4. The corresponding Landau equations read
(a) The renormalized Lagrangian density is
Lren = L + Lct , (11.58)
x1𝓁2 = x2(𝓁 +k′)2 = x3(𝓁 −k)2 = 0, x 1𝓁μ +x2(𝓁μ +k′μ)+ x3(𝓁μ −kμ)= 0.
where
A ﬁrst solution is obtained for
L = 1
𝓁2 =( 𝓁 −k)2 = 0, x 2 = 0, x 1𝓁μ +x3(𝓁μ −kμ)= 0,
2(∂φ)2 −m2
which (since we have assumed thatk2 = 0) is equivalent to
2 φ2 −gμϵ/2
𝓁2 = k2 = 𝓁·k = 0, 𝓁 μ = x3
3! φ3 −hμ−ϵ/2φ, (11.59)
x1 +x3

kμ.
This type of singularity is called a collinear singularity, since it occurs when the loop momen-
tum is aligned with one of the external momenta. A similar type of singularity is obtained at
x3 = 0, i.e.,
𝓁2 = k′2 = 𝓁·k′ = 0, 𝓁 μ =− x2
x1 +x2
k
′μ.
Another way to fulﬁll the Landau equations is to have 𝓁μ ≪ kμ,k′μ. In this limit, the ﬁrst
three conditions are automatically satisﬁed, and the last one becomes x2k
′μ = x3kμ. Since kμ
andk
′μ are a priori not collinear, this implies thatx2 = x3 = 0. This last type of singularity
is called a soft or infrared singularity, since it occurs when all the components of the loop
momentum go to zero.


===== PDF PAGE 39 =====
5 LANDAU EQUATIONS FOR SOFT AND COLLINEAR SINGULARITIES 27
Coleman–Norton Interpretation: A more intuitive physical interpretation of the Landau
equations was found by Coleman and Norton (see Coleman, S. and Norton, R. E. (1965),
Nuovo Cimento 38: 438). They propose to interpret a Feynman graph literally, as if the
graph represents a process in spacetime, with the vertices being the locations where some
instantaneous interactions happen. They further propose that the spacetime separation dxμr
between two vertices is parallel to the momentum qμr , and proportional to the Feynman
parameterxr:
dxμr = xrqμr.
(The constant of proportionality could be different from 1, but should be the same for all
propagators. Its value is not important, as one may freely rescale the entire diagram without
affecting the Landau equations.) Based on this identiﬁcation, one may make the following
observations:
• If a singularity happens atxr = 0, the spacetime separation is zero, and we may shrink
the corresponding propagator to a point. The resulting graph is called a reduced graph.
A similar reduction is possible ifqμr = 0, in the case of a soft divergence.
• Ifxr ⁄= 0, the Landau equations tell us that we should haveq2r = m2r instead. Thus, in
this interpretation, the propagators of a reduced graph represent the on-shell propagation
of a particle between two interactions. In this case, we may also write
xr = dx0rq0r ,d x μr = dx0r qμrq0r , i.e., dxμrdx0r = qμrq0r = vμr,
wherevμr is the4-velocity of an on-shell particle of momentumqμr .
• The last of the Landau equations becomes
∑
r
ϵrj dxμr = 0, for every loopj.
This equation is consistent with dxμr being a separation in spacetime, since adding these
separations along a closed loop should obviously give zero. This also implies that the
spacetime separation between two vertices does not depend on which path we follow on
the graph to connect them, as it should for this interpretation to make sense.
As an illustration, let us show the reduced diagrams for the three singularities we have found
for the triangle one-loop graph studied above:
𝓁
𝓁−k
k
k'
𝓁
𝓁+k'
k
k'
k
k'
In more complicated cases, where solving the Landau equations may be difﬁcult, the Coleman–
Norton interpretation and the associated reduced diagrams can be used as guidance for identi-
fying the possible solutions. This is based on the fact that there is a one-to-one correspondence


===== PDF PAGE 40 =====
28 1 QUANTUM FIELD THEORY BASICS
between the solutions of the Landau equations and the spacetime diagrams proposed by Cole-
man and Norton. For instance, in the case of the above example, we could use it as a way of
checking that there are no other solutions. Indeed, there could in principle be two additional
reduced diagrams:
k'
−k k
k'
𝓁
k
k'
However, neither of them is kinematically allowed; the left graph would have two non-collinear
particles propagating along the same spacetime interval, and the right graph would have a
physical free particle making a closed loop.
6. Multi-loop Integration in D Dimensions Start from equation (1.42) in Problem 5, in
the special case where the numerator is trivial, i.e.,N ≡ 1. Note that the denominator D is a
quadratic form in the components of the loop momenta, which we may arrange as follows:
D ≡ LtμALμ +LtμBμ +BtμLμ +C, L μ ≡ (𝓁μ1,𝓁μ2,...,𝓁 μL ).
6.a Perform explicitly the integration over theL loop momenta inD dimensions in order to
obtain
I({pi})= iLΓ (m − DL2 )
(−4π)
DL
2
∫
xr≥0
m∏
r=1
dxr
δ
(
1 − ∑r xr)( detA)m− (L+1)D2
(
C detA −Btμ CtA Bμ/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ Δ
+i0+)m−DL2 ,
whereCA is the matrix of co-factors ofA.
6.b Show thatΔ = det
⎛
⎜⎜⎜⎜⎜⎜⎝
A11 ... A 1L Bμ1
A21 ... A 2L Bμ2
... ... ...
AL1 ... A LL BμL
B1μ ... B Lμ C
⎞
⎟⎟⎟⎟⎟⎟⎠ and is of degree two in each variablexr.


===== PDF PAGE 55 =====
11 LEE–NAUENBERG THEOREM 43
11. Lee–Nauenberg Theorem In quantum mechanics and quantum ﬁeld theory, there exist
states that are practically undistinguishable (e.g., states that differ by features that are too dim to
be experimentally detected). Transition amplitudes with such initial or ﬁnal states are in general
plagued by singularities. The goal of this problem is to discuss these pathologies in the simple
setting of quantum mechanics, and to show that they can be avoided by averaging transition
probabilities over all degenerate states. To that end, consider a Hamiltonian H = H0 +V
decomposed into a free Hamiltonian H0 and an interaction potential V. We recall that the
scattering matrixS can be written as
Sβα = δβα −2πiδ (Eα −Eβ)Tβα,
withTβα ≡ Vβα +
∫
dγ VβγTγα
Eα −Eγ +i0+,V βα ≡
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψ(0)α ⟩,
where theEα’s and
⏐⏐Ψ(0)α ⟩’s are the eigenvalues and eigenstates ofH0.
11.a Show that
(
Ωin
)
βα ≡ δβα + TβαEα−Eβ+i0+ is a unitary matrix. Hint: deﬁne ⏐⏐Ψα,in⟩ ≡∫
dγ
(
Ωtin)αγ⏐⏐Ψ(0)γ ⟩ and consider the matrix element ⟨Ψβ,in⏐⏐V⏐⏐Ψα,in⟩.
11.b Solve formally the equation forTβα, to obtain
Tβα = Vβα +
+∞∑
n=1
∫
dγ1 ··· dγn
VβγnVγnγn−1 ··· Vγ1α
(Eα −Eγ1 +i0+)··· (Eα −Eγn +i0+).
11.c Denote byD(α) the set of states obtained fromα by adding/removing ultrasoft particles,
by splitting collinearly hard massless particles or by recombining collinear particles,
i.e., the set of states that are undistinguishable from the stateα. Explain why Tβα has
divergences if γ1,γ2,...,γ i all belong to D(α) or if γi,γi+1,...,γ n all belong to
D(β).
11.d IntroducePα,Pβ,P3, the projectors on D(α),D(β) and on the rest of the Hilbert space,
respectively. Show that squared matrix elements ofT become ﬁnite if they are summed
over all the states inD(α) andD(β), i.e., ∑
a∈D(α),b∈D(β)
⏐⏐Tba⏐⏐2 < ∞.
Reminders on Scattering Theory in Quantum Mechanics: The setting of this study is the
formulation of scattering in quantum mechanics. Let us consider a Hamiltonian H, which we
decompose into a free Hamiltonian and an interaction potential:
H = H0 +V.
Denote by
⏐⏐Ψ(0)α ⟩ the eigenstates of the free Hamiltonian,


===== PDF PAGE 56 =====
44 1 QUANTUM FIELD THEORY BASICS
H0
⏐⏐Ψ(0)α ⟩ = Eα⏐⏐Ψ(0)α ⟩,
and by
⏐⏐Ψα⟩ those of the full Hamiltonian,
H
⏐⏐Ψα⟩ = Eα⏐⏐Ψα⟩.
The eigenvalues of the free and interacting Hamiltonians are the same, provided we disregard
the formation of bound states that may happen with certain interactions, and provided the free
Hamiltonian is expressed in terms of the physical masses of the particles. The last equation
may be rewritten as
(Eα −H0)
⏐⏐Ψα⟩ = V⏐⏐Ψα⟩. (1.54)
Note that the operatorEα −H0 is not invertible, since
⏐⏐Ψ(0)α ⟩ lies in its kernel (as well as any
other state degenerate with it). Consider the following states:
⏐⏐Ψα,in⟩ ≡⏐⏐Ψ(0)α ⟩ +(Eα −H0 +i0+)−1 V⏐⏐Ψα,in⟩,⏐⏐Ψα,out⟩ ≡⏐⏐Ψ(0)α ⟩ +(Eα −H0 −i0+)−1 V⏐⏐Ψα,out⟩.
These states are obviously solutions of (1.54). These states are time-independent (i.e., they are
states in the Heisenberg representation), but may look different to observers in different frames.
In particular, in a frame that differs by a translation by a timeT, these states are multiplied by
e−iHT . Since they are energy eigenstates, the action of this operator is just a multiplication by
an irrelevant phase exp(−iEαT ). But these phases have a non-trivial effect on superpositions
of states. Consider, for instance,
⏐⏐Ψh,in⟩ ≡ ∫ dα h(α)⏐⏐Ψα,in⟩
(the notationdα is a shorthand for the integration/summation measure over all the quantum
numbers of the particles in the stateα, such as3-momenta, spins, etc.), whereh(α) is a smooth
function that spans a small range of energiesEα. Under such a translation in time, this state
becomes
⏐⏐Ψh,in⟩ →⏐⏐Ψh,in⟩T = ∫ dα h(α) e−iEαT ⏐⏐Ψα,in⟩
= e−iH0T ⏐⏐Ψ(0)h ⟩+∫ dαh (α) e−iEαT(Eα −H0 +i0+)−1 V⏐⏐Ψα,in⟩.
(1.55)
In the second term, we must close the contour for the integral over the energyEα in the upper
half-plane in order to ensure its convergence if T<0 . Then, the theorem of residues gives
the integral in terms of the singularities of the integrand. Except for the denominator, the
other factors generically have their singularities at ﬁnite imaginary part, Im (Eα) >0 (because
interactions typically lead to a ﬁnite lifetime for the particles), and their contribution vanishes
whenT → −∞. The denominator leads to poles located at Eα = E∗ −i0+, i.e., below the real
axis, and therefore it does not contribute to the result. Thus, we have
e−iHT ⏐⏐Ψh,in⟩ =T →−∞ e−iH0T ⏐⏐Ψ(0)h ⟩,e −iHT ⏐⏐Ψh,out⟩ =T →+∞ e−iH0T ⏐⏐Ψ(0)h ⟩.
Note that, since the operators exp(−iHT ) and exp(−iH0T ) are unitary, the states
⏐⏐Ψh,in⟩ and⏐⏐Ψh,out⟩ are normalized like the states ⏐⏐Ψ(0)h ⟩. Since this is true for any function h(α), the


===== PDF PAGE 57 =====
11 LEE–NAUENBERG THEOREM 45
states
⏐⏐Ψα,in⟩ and⏐⏐Ψα,out⟩ each form an orthonormal set of states. In other words, the in and
out states become identical to the eigenstates of the free Hamiltonian in frames translated by
a time T → −∞ or T → +∞, respectively. Thus, the physical interpretation of the (time-
independent) state
⏐⏐Ψα,in⟩ is that it encodes all the possible outcomes of an interacting system
initialized at T =− ∞ in the free state
⏐⏐Ψ(0)α ⟩. Likewise, ⏐⏐Ψα,out⟩ encodes all the possible
histories that lead to the free state
⏐⏐Ψ(0)α ⟩ atT =+ ∞. Therefore, the transition amplitude from
a stateα to a stateβ should be deﬁned as
Sβα ≡
⟨
Ψβ,out
⏐⏐Ψα,in⟩.
Note that the deﬁnition of the state
⏐⏐Ψα,in⟩ can be rewritten as
⏐⏐Ψα,in⟩ = ∫ dβ(δβα + TβαEα −Eβ +i0+/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ Ωβα
)⏐⏐Ψ(0)β ⟩, withTβα ≡⟨Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩
(δβα is the combination of delta functions and Kronecker symbols such that
∫
dβf (β)δβα =
f(α)). Inserting the deﬁnition of
⏐⏐Ψα,in⟩ inTβα, we obtain an integral equation forT:
Tβα = Vβα +
∫
dγ VβγTγα
Eα −Eγ +i0+ =
∫
dγ Vβγ Ωγα, (1.56)
withVβα ≡
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψ(0)α ⟩. This equation, known as the Lipmann–Schwinger equation, shows
how the matrix elements ofT are obtained from the matrix elements of the interaction potential
in the free basis.
11.a Given the above discussion, we have
⏐⏐Ψα,in⟩ =T →−∞ eiHT e−iH0T ⏐⏐Ψ(0)α ⟩,
which implies thatΩβα = limT →−∞
⟨
Ψ(0)β ⏐⏐eiHT e−iH0T⏐⏐Ψ(0)α ⟩. In this form, we see immedi-
ately that theΩβα’s are the matrix elements of a unitary operator.
Alternatively, we can reach the same conclusion using only the information provided in
the statement of the problem. For this, it is convenient to write
Ω ≡ 1 +Δ, T βα =( Eα −Eβ +i0+)Δβα,
⏐⏐Ψα,in⟩ =⏐⏐Ψ(0)α ⟩ + ∫ dγΔtαγ⏐⏐Ψ(0)γ ⟩ (Δtαγ ≡ Δγα).
Given the integral equation that relatesVβα andTβα and the deﬁnition of
⏐⏐Ψα,in⟩, we have also
Tβα =
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩.
Then, the matrix element
⟨
Ψβ,in
⏐⏐V⏐⏐Ψα,in⟩ can be written in two ways, depending on whether


===== PDF PAGE 58 =====
46 1 QUANTUM FIELD THEORY BASICS
we expand the state on the left or the state on the right:
⟨
Ψβ,in
⏐⏐V⏐⏐Ψα,in⟩ =⟨Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Tβα
+
∫
dγΔ†βγ ⟨Ψ(0)γ ⏐⏐V⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Tγα
=
⟨
Ψβ,in
⏐⏐V⏐⏐Ψ(0)α ⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
T∗αβ
+
∫
dγ
⟨
Ψβ,in
⏐⏐V⏐⏐Ψ(0)γ ⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
T∗γβ=T†βγ
Δγα.
Equating these two expressions for the matrix element leads to
T∗αβ −Tβα =
∫
dγ
(
Δ†βγTγα −T†βγΔγα
)
=( Eα −Eβ +i0+)
∫
dγ Δ†βγΔγα,
i.e.,Δ +Δ† +Δ†Δ = 0. From this relationship, we conclude that Ω = 1 +Δ is unitary.
S-matrix: The matrix element Sβα can also be expressed in terms of Tβα. In order to obtain
this relationship, let us start again from (1.55), but this time we take the limit T → +∞. Since
T>0 , we must close the integration contour in the lower half-plane. In the limit T → +∞,
the only term that survives when we apply the theorem of residues comes from the zero in the

exit_code=0
```
denominator, and we get
⏐⏐Ψh,in⟩T =T →+∞ e−iH0T ⏐⏐Ψ(0)h ⟩ −2πi ∫ dαdβ h(α)e−iEβT δ(Eα −Eβ)Tβα⏐⏐Ψ(0)β ⟩
=
T →+∞
∫
dαdβ h(α)e−iEβT
(
δβα −2πiδ (Eα −Eβ)Tβα
)⏐⏐Ψ(0)β ⟩.
Alternatively, we can also write
⏐⏐Ψh,in⟩T = ∫ dα h(α)e−iEαT ⏐⏐Ψα,in⟩
=
∫
dα h(α)e−iEαT
∫
dβ
⏐⏐Ψβ,out⟩⟨Ψβ,out⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Sβα
=
T →+∞
∫
dαdβ h(α)e−iEβT Sβα⏐⏐Ψ(0)β ⟩.
(In the last line, we also used the fact that Sβα is proportional to a delta function of energy
conservation to changeEα intoEβ in the exponential.) By comparing the two formulas, we
conclude that
Sβα = δβα −2πiδ (Eα −Eβ)Tβα.


===== PDF PAGE 59 =====
11 LEE–NAUENBERG THEOREM 47
11.b The Lipmann–Schwinger equation (1.56) can be solved iteratively, leading to the
following series in powers of the interaction potential:
Tβα = Vβα +
+∞∑
n=1
∫
dγ1 ··· dγn
VβγnVγnγn−1 ··· Vγ1α
(Eα −Eγ1 +i0+)··· (Eα −Eγn +i0+).
The physical interpretation of this expression is that the system starts in the stateα and evolves
to the stateβ, undergoing a sequence of interactions that take it through the intermediate states
γ1,γ2,...,γ n.
11.c In this formula, the matrix elements ofV are regular, and the only potential singularities
come from the poles in the other factors under the integral. However, these poles do not always
lead to a divergence in the result. This can be seen, for instance, in the following two toy
examples:
+1∫
−1
dx
x +i0+ =− iπ,
+1∫
0
dx
x +i0+ = ∞.
In these examples, we see that in order to lead to a divergence, the pole should be at one of
the endpoints of the integration domain; otherwise we may deform the integration contour
to completely avoid the pole. Another conﬁguration leading to an unavoidable divergence is
when the integrand has a pair of poles “pinching” the integration contour so that it cannot be
deformed.
Two statesα andγ may accidentally have the same energy when one varies the momentum
of a particle. However, when varying the stateγ, these accidental degeneracies occur in the
middle of the allowed domain of the variables that parameterizeγ. The corresponding pole in
(Eα −Eγ +i0+)−1 is therefore avoidable by deforming the integration contour, and this does
not lead to a divergence.
The state γ also has the same energy as α if it differs from α by one or more ultrasoft
particles. In this situation, the resulting pole in (Eα −Eγ +i0+)−1 occurs when the energy of
these extra particles goes to zero, which is on the boundary of the integration domain for γ,
and therefore produces an actual divergence in the result. Another situation whereγ has the
same energy asα is when a hard massless particle in one of the two states is replaced in the
other state by two or more collinear particles with the same total momentum. This case also
leads to a divergence, because the pole is reached on the boundary of the angular integration
domain.
In order to keep track of these two problematic situations, let us denote byD(α) the set
of states that are degenerate withα, excluding the accidental degeneracies. Consider now the
sequence of states
α → γ1 → ··· → γi−1 → γi → γi+1 → ··· → γn → β.
Each stateγi in this sequence is related to the preceding and following states by an elementary
interactionV. Obviously, in order to produce a pole, the state γi must have the same energy as
α. But for this pole to lead to a divergence, a stronger condition should be satisﬁed: the pole
must occur on the boundary of the integration domain of γi, which is made of the states in
D(γi−1) or in D(γi+1).


===== PDF PAGE 60 =====
48 1 QUANTUM FIELD THEORY BASICS
Assume for instance that γi ∈ D(γi−1), and has the same energy as α. But this implies
thatγi−1 also has the same energy asα, which happens on a harmless zero measure subset of
the phase-space ofγi−1 unlessγi−1 itself belongs to the degeneracy set ofγi−2, D(γi−2).B y
repeating this inductive argument, we see that this divergence occurs only if all ofγ1,γ2,...,γ i
belong to D(α). If instead we make the assumption that γi ∈ D(γi+1), then it is the entire
chain γi,γi+1,...,γ n that must be in D(β) in order to have a divergence. This result is
consistent with the well-known fact that infrared divergences happen when soft photons are
attached to the external legs of a hard process, but not when one attaches the soft photon to a
hard internal line of a graph. The same is true of the divergences due to collinear splittings.
11.d We assume now that the initial and ﬁnal states are not degenerate, i.e., thatD(α) and
D(β) do not overlap. Then, we introduce projectors Pα,Pβ andP3 that project respectively on
D(α),o n D(β) and on the remaining portion of the Hilbert space. Since the union of these
sets is the complete Hilbert space, the sum of these projectors is the identity
Pα +Pβ +P3 = 1.
Moreover, we assume that the volume ofD(α) andD(β) is very small (this is controlled by
what is experimentally meant by “soft” or “collinear”) compared to the rest, implying that we
may neglect these states except when they produce a divergence. In terms of these projectors,
the matrix elementTβα can be written as
Tβα =
+∞∑
n=0
[
V
( Pα +Pβ +P3
Eα −H0 +i0+V
)n]
βα
.
This formula is still exact. The next step is to expand this expression, and to dropPα andPβ
unless they occur in conﬁgurations that produce a divergence. Thus we keep thePα’s if they
form an uninterrupted chain on the right of the product, and thePβ’s if they form a chain on
the left of the product:
Tβα =sing.
+∞∑
r,s,n=0
[(
V Pβ
Eα −H0 +i0+
)s
V
( P3
Eα −H0 +i0+V
)n( Pα
Eα −H0 +i0+V
)r]
βα
,
which can be written compactly as
Tβα =
(
U†β,out T3 Uα,in
)
βα
, with T3 ≡ V
+∞∑
n=0
( P3
Eα −H0 +i0+V
)n
,
and
Uα,in ≡
+∞∑
r=0
( Pα
Eα −H0 +i0+V
)r
,U β,out ≡
+∞∑
s=0
( Pβ
Eα −H0 −i0+V
)s
.
The factorsUα,in andUβ,out contain divergences, while the factorT3 is divergence-free.
Note now that the operatorUα,in is the restriction to the subspace D(α) of the operatorΩ
that we introduced just above (1.56), and that we have shown to be unitary. Therefore,Uα,in is


===== PDF PAGE 61 =====
12 CLASSICAL EXTERNAL FIELD APPROXIMATION 49
also unitary if restricted toD(α), which means that
Uα,in Pα U†α,in = Pα,U β,out Pβ U†β,out = Pβ.
(We have also written an analogous relationship forUβ,out.) Then, summing the squared matrix
elements over all the states degenerate withα andβ, we obtain
∑
a∈D(α),b∈D(β)
⏐⏐Tba⏐⏐2 = ∑
a∈D(α),b∈D(β)
(
U†β,out T3 Uα,in
)
ba
(
U†α,in T†3 Uβ,out
)
ab
= tr
(
Uβ,out Pβ U†β,out T3 Uα,in Pα U†α,in T†3
)
= tr
(
Pβ T3 Pα T†3
)
=
∑
a∈D(α),b∈D(β)
⏐⏐(T3)ba⏐⏐2,
which is a ﬁnite quantity since it contains only the ﬁnite operator T3. In the second line, we
have rewritten the sum over the states inD(α) and D(β) in the form of a trace by introducing
the appropriate projectors, and we have used the cyclic invariance of the trace to reorder the
factors.
This result, established by Lee and Nauenberg, shows that ﬁnite cross-sections are obtained
provided one sums over all the initial and ﬁnal degenerate states. This is rather natural
in quantum mechanics since all these states are undistinguishable in practice, given the
unavoidable limited resolutions (in energy and in angle) of any detector.
12. Classical External Field Approximation The goal of this problem is to study the
scattering between an electron of charge −e and a large atomic nucleus of chargeZe, and to
show that, in the limit of a recoilless nucleus at rest, the nucleus can be approximated by its
classical Coulomb potential.
12.a Why are multiple scatterings important at largeZ?
12.b We are interested in the limit where the momentum exchangeski are soft. Why is this
the relevant limit for a scattering at large impact parameter? How can we simplify the
treatment of the nucleus in this limit?
12.c Express the lower part A
μσ1···μσn
ss′ (P, P′;{kσi}) of the graph shown below (surroundedby a box) in this limit, for an arbitrary number of exchanged photons.
k1 k2 k3 k4 k5 k6
123456
σ1 σ2 σ3 σ4 σ5 σ6
PP '
Perform the sum explicitly over all the permutationsσ of the attachments of the photons
to the nucleus, in order to obtain
∑
σ∈Sn
A
μσ1···μσn
ss′ (P, P′;{kσi})
≈
ki≪P
2EP δss′ (2π)3δ(P + ∑ki −P′) ∏
i
2π (−iZe)Pμi δ(P·ki).


===== PDF PAGE 274 =====
24 CASIMIR ZERO-POINT ENERGY 103
volume to be ﬁnite for the integral to converge). We have expressed the ﬁnal answer in terms
of the modiﬁed Bessel function of the second kind, whose integral representation is
Kν(x) ≡
∫ ∞
0
dτ
τ τν e−x2 (τ+τ−1).
The only property of this special function that we need is its behavior nearx = 0,
Kν(x)=x≈0
Γ (ν)
2
(2
x
)ν
+··· .
Thanks to this formula, we obtain
ζO (s)= Vd(4π)d/2 1m2s−d Γ (s −d/2)Γ (s) =d=4 m4V416π2 1m2s 1(s −1)(s −2).
Here, we can note a slightly unpleasant feature of our deﬁnition of the zeta function of an
operator, namely the fact that its dimension depends on the dimension of the operator and on
the value of the arguments (this is because the eigenvaluesλn have the same dimension asO
itself). Since in this example O has mass dimension two, this can be remedied by redeﬁning
ζO (s) → μ2sζO (s)=d=4 m4V416π2 ( μm)2s 1(s −1)(s −2),
whereμ is some arbitrary mass scale (which one may think of as a renormalization scale). By
taking the derivative of this expression ats = 0,w eg e t
ln det(m2 −∂2)=
d=4
m4V4
16π2
[
ln
(m
μ
)
− 34].
24. Casimir Zero-Point Energy The goal of this problem is to calculate the Casimir
force exerted on a pair of parallel plates in a massless scalar ﬁeld theory. As shown in
Figure 2.7, we consider a box of size L×L×𝓁, containing three parallel plates at z = 0,a
and 𝓁 on which we assume that the ﬁeld must vanish. E(r) denotes the zero-point energy
contained between a pair of such plates separated byr, and the Casimir energy is deﬁned as
E(a) ≡ E(a)+ E(𝓁 −a)− 2E (𝓁2 ).
24.a Determine the expression forE(r) (as a combination of integrals and sums that we shall
not try to compute at this point). In order to make it ﬁnite, introduce a cutoff function on
the energy of the modes,f(ω/Λ).
24.b In the case where the separationr is large, approximate the discrete sum on the longitu-
dinal modes by an integral, and show that
E(r)=
larger
π2L2r
8a4
∫ ∞
0
dnF(n), with F(n) ≡
∫ ∞
n2
dx√xf (π√xaΛ ).


===== PDF PAGE 275 =====
104 2 FUNCTIONAL METHODS
L
L
a𝓁 −a
Figure 2.7 Setup for the calculation of the Casimir energy.
24.c Whenr = a, show that
E(a)= π2L2
8a3
∑
n≥0
F(n).
24.d Use the Euler–MacLaurin formula in order to obtain the following Casimir energy:
E(a)= const − π2L2
1440a3.
Calculate the corresponding force.
24.e Determine a constant energy–momentum tensorTμν such thatE(a)= T00L2a.
24.a It is common to deﬁne the Hamiltonian of quantum ﬁeld theory as normal-ordered in
order to remove the inﬁnite zero-point vacuum energy, on the grounds that it is a constant that
does not play a role in physical processes since they are sensitive only to energy differences.
However, when a system is subject to non-trivial boundary conditions, it may happen that
changes at the boundaries lead to measurable variations of the vacuum energy. This is known
as the Casimir effect. In this problem, we illustrate this phenomenon in the case of a massless
scalar ﬁeld theory, for a particularly simple geometrical conﬁguration.
Let us denote byE(r) the vacuum zero-point energy in a “slice” of sizeL×L×r (with
the ﬁeld vanishing atz = 0 andz = r). With the notation of Figure 2.7, the Casimir energy is
deﬁned by
E(a) ≡ E(a)+ E(𝓁 −a)− 2E (𝓁2 ). (2.32)
The subtraction in the third term is not crucial, but removes some inﬁnite a-independent terms
(although inﬁnite, these terms are not very important, because they do not contribute to the
Casimir force since they are constant). Since we assume that the walls that delimitate the


===== PDF PAGE 276 =====
24 CASIMIR ZERO-POINT ENERGY 105
two cavities in the z direction are such that the ﬁeld vanishes on the walls, while there is
no boundary condition in thex,y directions, the allowed Fourier modeskx,y are continuous
variables, whilekz is discrete:
k‖ ≡ (kx,ky),k z = πnzr ,ω (k‖,nz) ≡√k2‖ +k2z,
wherenz is an integer. Note that changingnz → −nz does not give a distinct eigenmode of
the ﬁeld; therefore, we must restrict it tonz ≥ 0. The corresponding zero-point vacuum energy
is therefore given by
E(r)= L2
∫ d2k‖
(2π)2
∑
nz≥0
ω(k‖,nz)
2 f
(ω(k‖,nz)
Λ
)
,
where we have regularized the ultraviolet divergence of this sum/integral by inserting a
regulating function f(ω/Λ) chosen such that f(0)= 1 and f(z) decreases sufﬁciently fast
whenz →∞ .
24.b Whenr is large, we can also treat the momentum kz as a continuous variable, since the
splitting between two successive modes is inversely proportional to the width of the cavity in
this direction. In this limit, we obtain the following expression for E(𝓁):
E(r)=
larger
L2
∫ d2k‖
(2π)2
∫ ∞
0
dnz
ω(k‖,nz)
2 f
(ω(k‖,nz)
Λ
)
= π2L2r8a4 ∫ ∞0 dn ∫ ∞n2 dx√xf (π√xaΛ )/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ J(n)
,
where we have performed the angular integration in the (kx,ky) plane and introduced new
integration variablesn ≡ anz/r andx ≡ n2 + a2π2 k2‖ in the ﬁnal expression.
24.c This approximation of a continuously varyingnz is not applicable to the ﬁrst term of
(2.32), wherer = a. For this term, we may still perform the angular integration in the (kx,ky)
plane and introduce the variablesn ≡ nz andx ≡ n2 + a2π2 k2‖ in order to obtain
E(a)= L2
∫ ∞
0
dk‖k‖
4π
∑
nz≥0
ω(k‖,nz)f
(ω(k‖,nz)
Λ
)
= π2L2
8a3
∑
n≥0
∫ ∞
n2
dx√xf (π√xaΛ ) = π2L28a3 ∑n≥0J(n).


===== PDF PAGE 277 =====
106 2 FUNCTIONAL METHODS
24.d Therefore, in the limita ≪ 𝓁, the Casimir energy is given by
E(a)= π2L2
8a3
{ ∑
n≥0
J(n)−
∫ ∞
0
dnJ(n)
}
.
The most effective way to evaluate this quantity is by using the Euler–MacLaurin formula,
which gives
E(a)= π2L2
8a3
{
1
2J(0)−
∞∑
p=1
B2p
(2p)! J(2p−1)(0)},
where theB2p are the Bernoulli numbers (B2 = 16,B4 =− 130,... ; the odd ones are zero). Inwriting this expression, we have already used the fact thatJ(n) vanishes whenn →∞ ,a sd o
all its derivatives (this property follows from our assumptions about the behavior of the cutoff
functionf(z) at largez). By a simple rescaling of the integration variable x, we see that the
term ina−3J(0) is independent ofa and therefore only gives a constant (inﬁnite) shift to the
Casimir energy. Then, a straightforward calculation gives
J′(0)= 0, J′′′(0)=− 4,
which leads to the following contribution to the Casimir energy:
E(a)= const − π2L2
1440a3.
Note that this result does not depend on the choice of the regulator function, aside from
the generic properties we have assumed. (However, there are additional terms, suppressed
by powers of 1/(aΛ), that are not universal and depend on the details of how the cutoff is
implemented.) The derivative of this energy tells us the force exerted on the plate:
F(a)=− dE(a)da =− π2L2480a4,
which is attractive. A similar calculation could have been done in QED, with a result twice
as large as the scalar one (because photons have two degrees of polarization per momentum
mode). Although predicted in 1948, this force was ﬁrst observed experimentally only in 1997.
24.e One may also view the Casimir energy as coming from a homogeneous “vacuum
energy–momentum tensor,” E(a)= L2aT 00. With the geometrical setup of the problem
at hand, this energy–momentum tensor must be constructed solely from gμν and from the
unit vectornμ =( 0,0,0,1 ) orthogonal to the plates. Moreover, it has to be symmetric, and
traceless since we are considering massless ﬁelds (a free massless scalar ﬁeld theory is scale
invariant). These constraints lead to
Tμν =− π2
1440a4
(
gμν +4nμnν).
From this, we obtain the pressure in the z direction (i.e., the force per unit of transverse area):
Pz ≡ T33 =− π2480a4.
This negative pressure implies an attraction between the plates, consistent with the force
obtained above if multiplied byL2 (recall that pressure is force per unit area).


===== PDF PAGE 278 =====
25 THE FEYNMAN DIAGRAMS BEHIND THE CASIMIR FORCE 107
25. The Feynman Diagrams behind the Casimir Force In Problem 24, we derived the
expression for the Casimir force exerted on two nearby walls by calculating how the zero-
point vacuum energy is altered by the presence of the two walls. This derivation may seem
somewhat mystifying because nowhere did we talk about the interactions of the scalar ﬁeld
with the walls (these interactions were of course implicit in the boundary conditions imposed
on the ﬁeld). Here, we propose a more explicit derivation of the Casimir energy, achieved by
modeling the ﬁeld–wall interaction and by calculating the corresponding free energy, using
the technique developed in Problem 23. This calculation suggests that the Casimir force is an
actual wall–wall interaction mediated by a scalar loop.
The walls atx3 = 0 andx3 = a are modeled by an external ﬁeldσ(x), coupled as follows
to the scalar ﬁeld:
L = 12(∂μφ)(∂μφ) − g2σφ2,σ (x) ≡ δ(x3)+ δ(x3 −a).
25.a Show that the free energyF of the system is F = 12β−1 ln det(gσ − □E ), where β is theinverse temperature and □E is the Euclidean d’Alembertian operator.
25.b Show that, in the limitg →∞ , the normalized eigenfunctions ofgσ − □E are
ψk,n(x)=
√
2eik·x sin(πnx3a ) (k ≡ (k0,k1,k2),x ≡ (x0,x1,x2),n ∈ N +).
25.c Show that, wheng →∞ , the zeta function of the operatorgσ − □E is equal to
ζgσ−□ (s)= βL28π3/2 (aπ)2s−3 ζ(2s −3)Γ (s − 32 )Γ (s) .
25.d Use this result to recover the expression for the Casimir energy.
25.a The walls are modeled as an external ﬁeld σ(x) localized on the two planes x3 = 0 and
x3 = a, which acts as a kind of mass for the scalar ﬁeld. The corresponding Lagrangian reads
L = 12(∂μφ)(∂μφ) − g2σφ2,σ (x) ≡ δ(x3)+ δ(x3 −a),
whereg is a coupling constant that controls the strength of the interaction of the scalar ﬁeld
with the walls. In the limit g →∞ , the potential of the ﬁeld φ has very steep minima at
x3 = 0 andx3 = a, which forces the ﬁeld to vanish on the walls. Therefore, this limit should
be equivalent to the boundary conditions assumed in Problem 24. By going to Euclidean time,
we can express the partition functionZ(β) of the system as a path integral,
Z(β)=
∫
φ(0,x)=φ(β,x)
[
Dφ
]
e−SE [φ], with SE [φ] ≡ 12 ∫β0 dτd3x( −φ□Eφ +gσφ2),
where β is the inverse temperature and □E is the Euclidean d’Alembertian operator. The
path integral is over ﬁeld conﬁgurations that are periodic in Euclidean time with a period


===== PDF PAGE 279 =====
108 2 FUNCTIONAL METHODS
x3
x3 = 0x 3 = a
Figure 2.8 Example of a diagram contributing to the free energy in the presence of two walls
described as localized external ﬁelds. The solid black lines are scalar propagators, and the dots
denote insertions of the external ﬁeldgσ(x).
β. The ﬁniteness of the time interval implies that the corresponding frequencies are discrete
(they are the Matsubara frequencies). However, in the following, we shall assume that the
spacinga between the walls is much smaller thanβ, which allows us to treat the frequencies
in the temporal direction as continuous variables (physically, this assumption means that the
temperature is low enough so that the thermal excitations have an energy much smaller than
that of the discrete modes in thex3 direction). From the partition function, we can obtain the
free energy of the system as
F =− β−1 ln(Z).
(Note that, since we neglect thermal ﬂuctuations, the entropy is zero, and the energy and the
free energy are identical.) Since the above action is quadratic, the path integral is immediate
and leads to
Z(β)= const√
det (gσ − □E )
, i.e., ln (Z)= const − 12 ln det(gσ − □E ). (2.33)
Diagrammatically, the logarithm of the determinant ofgσ − □E is the sum of all the connected
one-loop diagrams such as the one shown in Figure 2.8. One may view these graphs as a kind
of wall–wall interaction mediated by scalar ﬁelds (given the coupling betweenφ and the ﬁeld
σ that describes the walls, this is the only allowed topology).
25.b In order to calculate the logarithm of the determinant that enters in Eq. (2.33), we use
the zeta function regularization method developed in Problem 23, which requires ﬁrst obtaining
the eigenfunctions of the operator gσ − □E . Quite generally, these eigenfunctions can be
written as
ψk,λ(x) ≡ eik·xfλ(x3),
where we denotek ≡ (k0,k1,k2),x ≡ (x0,x1,x2). The undetermined function fλ(x3) must
satisfy
(
gσ(x3)− ∂23)fλ(x3)= λ2 fλ(x3). (2.34)
Since the function σ(x3) is zero almost everywhere, we look for a functionfλ(x3) of the form


===== PDF PAGE 280 =====
25 THE FEYNMAN DIAGRAMS BEHIND THE CASIMIR FORCE 109
fλ(x3)=
⎧
⎪⎪⎨
⎪⎪⎩
Aeiλx3 +Be−iλx3 for x3 ≤ 0,
A′eiλx3 +B′e−iλx3 for 0 ≤ x3 ≤ a,
A′′eiλx3 +B′′e−iλx3 for a ≤ x3.
Since the differential equation that controls fλ has only second-order derivatives, the delta
functions inσ(x3) produce jumps of the ﬁrst derivativef′λ(x3) atx3 = 0 anda, but the function
f(x3) itself is continuous. The continuity of the function leads to two conditions:
A +B = A′ +B′,A ′eiλa +B′e−iλa = A′′eiλa +B′′e−iλa.
Two additional conditions are obtained by integrating the differential equation (2.34) over
inﬁnitesimal intervals centered at x3 = 0 and x3 = a, respectively. Using the continuity of
the function, we obtain a relationship between the values of the function atx3 = 0,a , and the
jump of its derivative at these points. This gives
g(A +B)= iλ (A′ −A −B′ +B),
g(A′eiλa +B′e−iλa)= iλ (A′′eiλa −B′′e−iλa −A′eiλa +B′e−iλa).
Although this could in principle be carried out for any value of the coupling g, we restrict
ourselves to the limitg →∞ for simplicity. In this limit, the above four conditions simplify to
B =− A, B ′ =− A′,A ′(eiλa −e−iλa)= 0, A ′′eiλa +B′′e−iλa = 0.
In order to have a non-zero solution in the range [0,a ], the frequencyλ must be of the form
λn ≡ πna ,n ∈ N +.
When this is the case, the last constraint becomesB′′ =− A′′. Therefore, the eigenfunctions
in the domain between the two walls are given by
ψk,n(x)=
√
2eik·x sin(πnx3a ).
The prefactor
√
2 ensures that they are normalized with a unit probability per unit volume, i.e.,
∫
d4x⏐⏐ψk,n(x)⏐⏐2 = βL2a,
where β is the length of the Euclidean time interval and L2 is the transverse section under
consideration. The completeness relation satisﬁed by these eigenfunctions reads
a−1 ∑
n≥1
∫ d3k
(2π)3 ψk,n(x)ψ∗k,n(x′)= δ(x −x′).


===== PDF PAGE 281 =====
110 2 FUNCTIONAL METHODS
25.c The heat kernel (see Problem 23) ofgσ − □E is then given by
Hgσ−□ (x,x ′;τ) ≡ 2a ∑n≥1 ∫ d3k(2π)3 e−τ(k2+π2n2/a2) eik·(x−x′) sin(πnx3a ) sin(πnx′3a ).
Evaluating this atx = x′ and integrating overx in a domain of transverse sectionL2 between
the two walls gives
∫
d4xH gσ−□ (x,x ;τ)= βL2 ∑
n≥1
∫ d3k
(2π)3 e−τ(k2+π2n2/a2),
and the corresponding zeta function is therefore
ζgσ−□ (s)= βL2Γ (s) ∫ ∞0 dττ τs ∑n≥1 ∫ d3k(2π)3 e−τ(k2+π2n2/a2).
The integral overk is an elementary Gaussian integral,
∫ d3k
(2π)3 e−τk2 = 18π3/2τ3/2.
Up to a rescaling, the integral overτ gives a gamma function,
∫ ∞
0
dτ
τ τs−32 e−τπ2n2/a2 =( aπn)2s−3 Γ (s − 32 ).
Finally, the sum onn produces a Riemann zeta function. Combining everything, we get
ζgσ−□ (s)= βL28π3/2 (aπ)2s−3 ζ(2s −3)Γ (s − 32 )Γ (s) .
25.d Noting thatΓ (s) ≈ s−1 in the vicinity ofs = 0, its derivative ats = 0 is
ζ′gσ−□ (0)=− ln det(gσ − □E )= π3/2βL28a3 ζ(−3)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 1120
Γ (−32 )/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=43π1/2
= π2βL2
720a3.
Finally, we obtain the following expression for the free energy:
F =− 12β−1ζ′gσ−□ (0)=− π2L21440a3,
which is identical to the expression for the Casimir vacuum energy obtained in Problem 24.
Although the derivation followed here is not technically simpler, it provides a much more
satisfactory handle on how the ﬁelds interact with the walls. In particular, we see explicitly
how the Casimir energy is nothing but the free energy of the two walls (strongly coupled to the
ﬁelds) interacting by the exchange of scalar particles. Technical challenges aside, there would
be no conceptual difﬁculty in extending the present approach to deal with the case where the
ﬁeld–wall interaction has a ﬁnite strength, or walls that have a non-zero thickness, or even
to calculate the ﬁnite-temperature corrections (neglected here because we have replaced the
Matsubara frequencies by a continuousk0).
Source: this problem was inspired by Jaffe, R. L. (2005), Phys Rev D 72: 021301.


===== PDF PAGE 282 =====
26 GROSS–NEVEU MODEL 111
26. Gross–Neveu Model The Gross–Neveu model is a (1 + 1)-dimensional quantum
ﬁeld theory withN species of massless fermions (indexed byn = 1,...,N ), with a quartic
interaction,
L ≡ i
∑
n
ψn/∂ψn + g22 ( ∑n ψnψn)2.
This quantum ﬁeld theory is a toy model for the spontaneous breaking of chiral symmetry, and
also provides an example of the technique of bosonization.
26.a Check that a valid representation of the Dirac matrices in two dimensions isγ0 = σ2,
γ1 = iσ1 (with σ1,2 Pauli matrices). Also deﬁne γ5 ≡ γ0γ1. Check that (γ5)2 = 1,
(γ5)† = γ5, {γ5,γμ} = 0 for μ = 0,1 . Show that L is invariant under ψn → γ5ψn.
Would a mass term be consistent with this symmetry?
According to the power counting, can this theory be renormalizable ind = 2?
26.b Prove the following equality:
∫
[DψDψ]ei
∫
L =
∫
[DψDψDφ]ei
∫ ∑
n ψn(i/∂−φ)ψne− i2g2 ∫φ2,
whereφ is an auxiliary scalar ﬁeld.
26.c We are now interested in the ground state of this theory, in whichφ is constant. Perform
the integration over the fermions in closed form for a constant φ, and show that the
result of this integration is a factor
exp
{
N
∫ d2p
(2π)2 ln(−p2 +φ2)
}
, withp2 ≡ p20 −p21.
26.d Using ln(A)=− ∂α(A−α)α=0, and using dimensional regularization withd = 2 −2ϵ,
show that the integral can be written as
∫ ddp
(2π)d ln(−p2 +φ2)= iφ24π(1ϵ + const +1 − lnφ2 +O(ϵ2)).
Which operator should one renormalize to eliminate the ultraviolet divergence? After
introduction of an appropriate counterterm, show that the effective potential for the ﬁeld
φ can be written as
Veff(φ)= φ22g2 + Nφ24π ( ln(φ2μ2) −1),
whereμ is a constant whose precise value depends on the ﬁnite terms included in the
counterterm besides the pole inϵ−1.
26.e Determine analytically the location of the minimum of Veff(φ). Could this answer have
been found by a perturbative expansion in powers ofg2? What are the consequences for
the fermions of having a non-zero expectation value forφ?
26.f What are the diagrams that would give the result of the above functional calculation?
Why is the answer exact in the limitN →∞ ?


===== PDF PAGE 283 =====
112 2 FUNCTIONAL METHODS
26.a In order to verify that the proposed matrices are valid Dirac matrices in two dimensions,
we just need to verify that
{
γμ,γν} = 2gμν:
(
γ0)2 =(σ2)2 = 1, (γ1)2 =(iσ1)2 =− 1,
γ0γ1 +γ1γ0 = iσ2σ1 +iσ1σ2 = i(−iσ3)+ i(iσ3)= 0.
Deﬁningγ5 ≡ γ0γ1,w eh a v e
(
γ5)2 = γ0γ1γ0γ1 =− γ0 γ1γ1
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1
γ0 =+ 1,
(
γ5)† =( iσ2σ1)† =− iσ1σ2 =+ iσ2σ1 = γ5,
{
γ5,γμ} = γ0γ1γμ +γμγ0γ1 = 0.
(In the ﬁnal equality above, since μ is either 0 or 1, γμ commutes with one of γ0,1 and
anti-commutes with the other one.) Under the transformation ψn → γ5ψn,w eh a v e
ψn → γ5ψn,
ψn ≡ ψ†nγ0 → ψ†n γ5†γ0/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=γ5γ0=−γ0γ5
=− ψnγ5,
ψnψn → −ψnψn,(
ψnψn
)2 →(ψnψn)2,
ψnγμψn → −ψn γ5γμγ5/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−γμ
ψn = ψnγμψn,
hence the invariance of the Lagrangian. Note that a mass term is not allowed by this symmetry
sinceψnψn → −ψnψn under this transformation.
The mass dimension of the ﬁeldψn is 12 ind = 2, and therefore the mass dimension of thecoupling constant g is zero. This theory should therefore be renormalizable in two dimensions
according to the power counting.
26.b In order to check the proposed equality, we proceed by explicitly performing the
integration overφ on the right-hand side. For this, we need
− 12g2 φ2 −φ ∑
n
ψnψn =− 12g2
[
φ2 +2g2φ ∑
n
ψnψn
]
=− 12g2
[(
φ +g2 ∑
n
ψnψn
)2
−g4
( ∑
n
ψnψn
)2]
.
Then, we deﬁne φ′ ≡ φ + g2 ∑n ψnψn and trade the integration variable φ in favor
of φ′. The integral produces a constant prefactor (which we ignore), and leaves a factor
exp(g22 (∑n ψnψn)2), hence the announced equality.


===== PDF PAGE 284 =====
26 GROSS–NEVEU MODEL 113
26.c Whenφ is a constant, we can perform the integration over the fermions explicitly. Each
pair of integralsDψnDψn produces a factor
det
(
i/∂ −φ
)
.
These factors do not depend on the index n, and there are N of them, so the N fermionic
integrations give
[
det
(
i/∂ −φ
)]N
= exp
{
N tr ln
(
i/∂ −φ)
}
= exp
{
N
∫ d2p
(2π)2 tr ln(/p −φ)
}
.
Note that the original trace was over both spacetime and the Dirac indices. In the ﬁnal equality,
we have rewritten the trace over spacetime as a trace over momentum and we keep unchanged
the trace over the Dirac indices. For the latter, we can write
tr ln(/p −φ)= ln det
(
−φi (p0 −p1)
−i(p0 +p1)− φ
)
= ln
(
φ2 −p2).
(We have used the explicit form of the Pauli matrices in the ﬁrst equality.) This gives the
announced formula.
Alternative Proof: It is possible to do this calculation without resorting to any explicit
representation of the Dirac matrices, as follows:
tr ln(/p −φ)= tr ln(−φ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=2 ln(−φ)=ln(φ2)
+tr ln(1 −/p/φ)
= ln(φ2)− ∑
n≥1
1
n tr
([/p
φ
]n)
= ln(φ2)− ∑
p≥1
1
2p tr
([/p
φ
]2p)
= ln(φ2)− ∑
p≥1
1
p
(p2
φ2
)p
= ln(φ2)+ ln(1 −p2/φ2)= ln(φ2 −p2).
(In the third line, we used the fact that/p2p+1 = p2p/p has a null trace, and therefore we keep
only the terms of even order.)
26.d Then, the integration of the momentump proceeds as follows:
∫ ddp
(2π)d ln(−p2 +φ2)=− ∂α
∫ ddp
(2π)d
1
(−p2 +φ2)α
⏐⏐⏐⏐⏐
α=0
=− i∂α
∫ ddpE
(2π)d
1
(p2E +φ2)α
⏐⏐⏐⏐⏐
α=0
=− i∂α
φd−2α
(4π)d/2
Γ (α − d2 )
Γ (α)
⏐⏐⏐⏐⏐
α=0
.
Note thatΓ (α) ≈ α−1 whenα → 0. Therefore, we have


===== PDF PAGE 285 =====
114 2 FUNCTIONAL METHODS
∂α
F(α)
Γ (α)
⏐⏐⏐⏐⏐
α=0
= F(0),
and we obtain
∫ ddp
(2π)d ln(−p2 +φ2)=− i φd(4π)d/2Γ (−d2 )=− iφ2φ−2ϵ(4π)1−ϵ Γ (−1 +ϵ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1ϵ +const+O(ϵ)
= iφ2
4π
[1
ϵ + const +1 − ln(φ2)+ O(ϵ2)]. (2.35)
(We could have written const +1 as some unique constant, but it will be convenient later to
pull out this 1.) The pole in ϵ−1 can be removed by renormalizing the operator φ2. More
precisely, we introduce the counterterm
−iφ2
4π
[1
ϵ + const′
]
,
where const′ is a ﬁnite constant that may be subtracted along with the poleϵ−1. Combining
the original term inφ2 with the result (2.35) and the counterterm, we get
φ2
2g2 + Nφ24π ( ln(φ2μ2) −1)
for the sum of the terms inφ2 inside the exponential.
26.e The derivative of this effective potential is given by
∂
∂φVeff(φ)= 2φ
[ 1
2g2 + N4π ln(φ2μ2)].
This derivative vanishes atφ = 0, but this is a local maximum. The other zero of the derivative
is at
φ∗ ≡ μ exp
(
− πg2N).
One may check that this is a local minimum. Note that the location of this minimum depends
on the renormalization scale, but the minimum is always there, no matter which scale we
choose. Note also that this minimum is non-perturbative since its value is a non-analytic
function of the couplingg (more precisely, it is a function whose Taylor coefﬁcients atg = 0
are all zero). Because of the couplingψnφψn, and the non-zero expectation value of the scalar
ﬁeld, the fermions become massive in the ground state of this theory (this is similar to the
Higgs mechanism), and the chiral symmetry is spontaneously broken.
26.f Diagrammatically, the determinant resulting from the integration over the fermion ﬁelds
corresponds to the sum of all the diagrams with one fermion loop, dressed by insertions of the
scalar ﬁeldφ. By its position inside the exponential, N acts in a similar way to ¯h−1. Taking
the limitN → +∞ has the same effect as taking the limit ¯h → 0, namely eliminating all the
higher-order corrections. For this reason, the results we have derived in this problem do not
receive any higher-order corrections whenN is very large.


exit_code=0
```

### 2026-11-16T22:10:59.530446+08:00

```bash
python3 tools/author_qft_06_12.py
```

```text
Authored: qft-06,qft-07,qft-08,qft-09,qft-10,qft-11,qft-12

exit_code=0
```

### 2026-11-16T22:10:59.623253+08:00

```bash
python3 -c 'from pathlib import Path; p=Path("planning/work-order-build-qft-06-12-update.md"); print(p.read_text() if p.exists() else "No update file")'
```

```text
No update file

exit_code=0
```

### 2026-11-16T22:15:34.954490+08:00

```bash
python3 tools/build_qft_06_12_truth.py
```

```text
Traceback (most recent call last):
  File "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/build_qft_06_12_truth.py", line 6, in <module>
    import mpmath as mp
ModuleNotFoundError: No module named 'mpmath'

exit_code=1
```

### 2026-11-16T22:15:47.185993+08:00

```bash
/Users/ai4s/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 tools/build_qft_06_12_truth.py
```

```text
Traceback (most recent call last):
  File "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/build_qft_06_12_truth.py", line 6, in <module>
    import mpmath as mp
ModuleNotFoundError: No module named 'mpmath'

exit_code=1
```

### 2026-11-16T22:15:56.547875+08:00

```bash
docker image ls --format '{{.Repository}}:{{.Tag}}'
```

```text
theory-physics-sp05:dev
theory-physics-sp04:dev
theory-physics-sp03:dev
theory-physics-sp02:dev
theory-physics-qft04:dev
theory-physics-ed05:dev
theory-physics-qft03:dev
theory-physics-ed04:dev
theory-physics-ed03:dev
theory-physics-tm03:dev
theory-physics-qft02:dev
theory-physics-qm03:dev
theory-physics-ed02:dev
theory-physics-qm02:dev
theory-physics-qft01:dev
theory-physics-ed01:dev
theory-physics-qm01:dev
theory-physics-sp01:dev
theory-physics-tm02:dev
theory-physics-tm01:dev
mechanics-inverse-task01:dev
gbplanner2-course:local
gbplanner2-course-fortress:local
gbplanner2-course-base:local
gbplanner2-humble:local
iquest-benchmark-sqlite-db-truncate:20261019
iquest-benchmark-git-leak-recovery:20261019
iquest-benchmark-log-summary-date-ranges:20261019
iquest-benchmark-openssl-selfsigned-cert:20261019
iquest-benchmark-regex-log:20261019
iquest-benchmark-cancel-async-tasks:20261019
iquest-benchmark-base:20261019
mirror.gcr.io/library/ros:humble-ros-base-jammy
subject-agent-searxng:latest
subject-agent-searxng:alpine-clean
subject-agent-searxng:alpine-fixed
subject-agent-searxng:alpine
subject-agent-searxng:trixie
subject-agent-mysql:8.0
deploy-word-worker:latest
deploy-image-sanitizer:latest
deploy-ops:latest
deploy-migrate:latest
deploy-backend:latest
subject-agent-d04-amd64-image:local
subject-agent-d04-amd64-word:local
subject-agent-d04-amd64-frontend:local
subject-agent-d04-amd64-backend:local
deploy-frontend:latest
subject-agent-d04-image-local:latest
subject-agent-d04-word-local:latest
subject-agent-d04-backend-local:latest
subject-agent-d04-builder-local:latest
subject-agent-d04-backend:local
subject-agent-d04-builder:local
subject-agent-d04-word:local
subject-agent-d04-image:local
subject-agent-security:word-current
subject-agent-security:image-current
subject-agent-security:backend-current
subject-agent-d04-frontend:local
subject-agent-security:frontend-current
subject-agent-d04-frontend-local:latest
cgr.dev/chainguard/python:latest
mirror.gcr.io/library/python:3.14-slim-bookworm
mirror.gcr.io/library/python:3.14-slim-trixie
mirror.gcr.io/library/python:3.14-alpine
subject-agent-security:frontend-resilient-20260924
deploy-frontend-builder:resilient-current
subject-agent-security:frontend-20260924
nginx:1.30.5-alpine3.24
subject-agent-nginx-verified:20260924
mirror.gcr.io/library/nginx:<none>
redis:8-alpine
subject-agent-security:word-d1a408d-20260919
subject-agent-security:image-d1a408d-20260919
subject-agent-security:backend-d1a408d-20260919
subject-agent-security:frontend-d1a408d-20260919
subject-agent-security:builder-d1a408d-20260919
node:24-alpine
mirror.gcr.io/library/node:24-alpine
mirror.gcr.io/library/python:3.12.13-slim-bookworm
ollama/ollama:latest
searxng/searxng:latest
nginx:alpine
mirror.gcr.io/library/python:3.14-alpine3.22
mysql:8.0
mirror.gcr.io/library/mysql:8.0
alpine:<none>
hello-world:latest
nginx:1.27-alpine
gcr.io/distroless/python3-debian13:latest

exit_code=0
```

### 2026-11-16T22:16:08.408916+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/build_qft_06_12_truth.py
```

```text
qft-06 {"wick_counts": [-3.0, 0, 1.0, 0, 0, -1.0, 0, 3.0, 2, -2], "master_column_sums": [0.0, 0.0], "closed_form_vs_parameter_integral": 5.011433831422867e-52, "precision_digits": 50, "truth_route": "independent local program, no import from solution", "formal_codex_measurement": false}
qft-07 {"unreduced_triangle_vs_reduced_integral": 0.0, "constant_background_determinant_vs_six_boxes": 0.0, "scheme": "D=4-epsilon; pole fields multiply 16 pi² epsilon; MSbar finite subtraction; anticommuting gamma5, no anomalous trace", "precision_digits": 50, "truth_route": "independent local program, no import from solution", "formal_codex_measurement": false}
qft-08 {"parameter_integral_vs_beta_function": 9.632340165100567e-50, "causal_convolution_vs_DOP853_max_error": 1.24065175960527e-13, "ODE_tolerance": "rtol=2e-12, atol=2e-13; max_step=width/5; finite interval initial value is exact task definition", "precision_digits": 50, "truth_route": "independent local program, no import from solution", "formal_codex_measurement": false}
qft-09 {"bubble_F_and_stationarity_residual": 2.1382117680737565e-50, "triangle_landau_substitution_residual": 0.0, "completeness": "Stationarity gives l=-alpha2 k+alpha3 kprime; alpha1*l²=0 with s>0 forbids alpha1 alpha2 alpha3>0; remaining three nonnegative faces give two collinear interiors and soft alpha1 vertex. Other isolated vertices do not satisfy Coleman-Norton with positive future k,kprime. Bubble discriminant has only (m1+-m2)^2.", "precision_digits": 50, "truth_route": "independent local program, no import from solution", "formal_codex_measurement": false}
qft-10 {"unsafe_subleading_remainder_at_delta_1e12": 7.106685912456545e-11, "analytic_anchors": {"integral_R_yz": "1/2", "integral_R_sqrt_yz": "5 pi/4", "inclusive_C": "3/2"}, "independent_thrust_route": "Exact b integral followed by 50-digit one-dimensional adaptive quadrature; reference uses two-dimensional Gauss-Legendre regions.", "real_virtual_organization": "W2=1, C[W]=3/2+integral R(W3-1); finite inclusive matching incorporates virtual plus integrated counterterm, not a pure virtual diagram.", "precision_digits": 50, "truth_route": "independent local program, no import from solution", "formal_codex_measurement": false}
qft-11 {"determinant_ratio_vs_reflection_log": 4.00184688076472e-55, "fixed_physical_lambda_force_vs_energy_derivative": 0.0, "subtraction": "det(I+Lambda G) divided by both isolated-wall factors, before integral", "precision_digits": 50, "truth_route": "independent local program, no import from solution", "formal_codex_measurement": false}
qft-12 {"Lambert_W_gap_residual": 5.011433831422867e-52, "subtracted_fermion_determinant_vs_potential": 3.4388354546352224e-52, "scheme_invariant_mass_residual": 3.3409558876152446e-52, "root_completeness": "x ln|x| monotone on (-inf,-1/e),(-1/e,0),(0,1/e),(1/e,inf); all real W0/W-1 branches included; no spinodal-equality cases in model", "precision_digits": 50, "truth_route": "independent local program, no import from solution", "formal_codex_measurement": false}

exit_code=0
```

### 2026-11-16T22:18:38.412923+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/run_qft_06_12_checks.py --calibrate
```

```text
{
  "task_id": "qft-06",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-06 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.014735869029594778,
    "reference": 1.0222377899060933e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.1944639590000179,
    "baseline_seconds": 0.15596849999997175
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "both_master_columns_cancel": true,
    "nonzero_momentum_response_positive": true,
    "all_three_omission_residuals_differ": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-07",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-07 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.1941668798006142,
    "reference": 3.7565563087237505e-07,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.12833537500000602,
    "baseline_seconds": 0.11743241700003182
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "operator_basis_closure_diagnostic": true,
    "six_box_pole_count": true,
    "pseudoscalar_fermion_mass_and_wavefunction_poles": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-08",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-08 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 6.176256407956054,
    "reference": 3.7541804814140155e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.27399383400006627,
    "baseline_seconds": 0.18353537500001949
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "gauge_parameters_same_conserved_response": true,
    "polarization_transverse": true,
    "finite_causal_energy_positive": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-09",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-09 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.032167402278406705,
    "reference": 2.6686109635508026e-15,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.20522670800005471,
    "baseline_seconds": 0.21041854099996726
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "pseudothreshold_not_physical": true,
    "normal_threshold_positive_parameters": true,
    "numerator_soft_cancellation": true,
    "course_quality_hash_matches": true
  }
}
qft-10 checks failed
{
  "task_id": "qft-10",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-10 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.728165274895041,
    "reference": 0.013930616883306667,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.42925704200001746,
    "baseline_seconds": 0.25089858299998014
  },
  "checks": {
    "reference_matches_independent_truth": false,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "inclusive_known_R_ratio": true,
    "polynomial_and_sqrt_analytic_moments": false,
    "unsafe_cutoff_dependence_detected": true,
    "laplace_weight_monotone": true,
    "course_quality_hash_matches": true
  }
}

exit_code=1
```

### 2026-11-16T22:19:50.685184+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/run_qft_06_12_checks.py qft-10 qft-11 qft-12 --calibrate
```

```text
{
  "task_id": "qft-10",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-10 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.47992867558681396,
    "reference": 0.0006421045668667445,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 2.1561130850000154,
    "baseline_seconds": 0.252831125000057
  },
  "checks": {
    "reference_matches_independent_truth": false,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "inclusive_known_R_ratio": true,
    "polynomial_and_sqrt_analytic_moments": true,
    "unsafe_cutoff_dependence_detected": true,
    "laplace_weight_monotone": true,
    "course_quality_hash_matches": true
  }
}
qft-10 checks failed

exit_code=1
```

### 2026-11-16T22:21:12.532735+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/run_qft_06_12_checks.py qft-10 qft-11 qft-12 --calibrate
```

```text
Traceback (most recent call last):
  File "/work/tools/run_qft_06_12_checks.py", line 120, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/work/tools/run_qft_06_12_checks.py", line 64, in main
    subprocess.run([sys.executable,str(task/'solution'/script),'--data-root',str(data),'--output',str(output)],check=True,text=True,capture_output=True)
  File "/usr/local/lib/python3.12/subprocess.py", line 571, in run
    raise CalledProcessError(retcode, process.args,
subprocess.CalledProcessError: Command '['/usr/local/bin/python', '/work/tasks/qft-10/solution/solve.py', '--data-root', '/work/tasks/qft-10/environment/public', '--output', '/tmp/qft-10-check-ba7dzw13/reference.json']' returned non-zero exit status 1.

exit_code=1
```

### 2026-11-16T22:21:42.251714+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tasks/qft-10/solution/solve.py --data-root tasks/qft-10/environment/public --output /tmp/qft10-answer.json
```

```text
/work/tasks/qft-10/solution/solve.py:16: RuntimeWarning: divide by zero encountered in divide
  R2=((1-b)**2+(1-c)**2)/(b*c)
/work/tasks/qft-10/solution/solve.py:17: RuntimeWarning: invalid value encountered in multiply
  return a*math.expm1(-kappa*a)*L*float(np.dot(w0,(2*R1+R2)*jac))
/work/tasks/qft-10/solution/solve.py:18: IntegrationWarning: The occurrence of roundoff error is detected, which prevents 
  the requested tolerance from being achieved.  The error may be 
  underestimated.
  return quad(integrand,0,40,epsabs=1e-10,epsrel=1e-11,limit=150)[0]
Traceback (most recent call last):
  File "/work/tasks/qft-10/solution/solve.py", line 56, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/work/tasks/qft-10/solution/solve.py", line 55, in main
    out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(answer,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
                                                                                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.12/json/__init__.py", line 238, in dumps
    **kw).encode(obj)
          ^^^^^^^^^^^
  File "/usr/local/lib/python3.12/json/encoder.py", line 202, in encode
    chunks = list(chunks)
             ^^^^^^^^^^^^
  File "/usr/local/lib/python3.12/json/encoder.py", line 432, in _iterencode
    yield from _iterencode_dict(o, _current_indent_level)
  File "/usr/local/lib/python3.12/json/encoder.py", line 406, in _iterencode_dict
    yield from chunks
  File "/usr/local/lib/python3.12/json/encoder.py", line 326, in _iterencode_list
    yield from chunks
  File "/usr/local/lib/python3.12/json/encoder.py", line 406, in _iterencode_dict
    yield from chunks
  File "/usr/local/lib/python3.12/json/encoder.py", line 317, in _iterencode_list
    yield buf + _floatstr(value)
                ^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.12/json/encoder.py", line 240, in floatstr
    raise ValueError(
ValueError: Out of range float values are not JSON compliant: nan

exit_code=1
```

### 2026-11-16T22:22:22.573922+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/run_qft_06_12_checks.py qft-10 qft-11 qft-12 --calibrate
```

```text
{
  "task_id": "qft-10",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-10 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.47992867558681396,
    "reference": 2.7144065196341442e-08,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 2.5732823350000444,
    "baseline_seconds": 0.25783149999995203
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "inclusive_known_R_ratio": true,
    "polynomial_and_sqrt_analytic_moments": true,
    "unsafe_cutoff_dependence_detected": true,
    "laplace_weight_monotone": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-11",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-11 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.13806808543184862,
    "reference": 5.59956619037007e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.27453733400000147,
    "baseline_seconds": 0.30456199999991895
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "positive_walls_attract": true,
    "matching_transmission_one_plus_reflection": true,
    "finite_walls_below_dirichlet_magnitude": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-12",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-12 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.007777707476305905,
    "reference": 1.1413301842607661e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.2906423749999476,
    "baseline_seconds": 0.3155546250000043
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "symmetric_two_vacua": true,
    "strong_source_removes_metastability": true,
    "near_spinodal_three_roots": true,
    "running_coupling_keeps_mass": true,
    "course_quality_hash_matches": true
  }
}

exit_code=0
```

### 2026-11-16T22:24:36.915199+08:00

```bash
python3 tools/run_pending_harbor.py qft-06 qft-07 qft-08 qft-09 qft-10 qft-11 qft-12
```

```text
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-06 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-06-harbor-y0qp7ims/qft-06 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-06-harbor-y0qp7ims/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-06-harbor-y0qp7ims/runs/oracle/2026-11-16__22-24-37/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-06-harbor-y0qp7ims/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-06-harbor-y0qp7ims/runs/oracle/2026-11-16__22-24-37`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-06-harbor-y0qp7ims/qft-06 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-06-harbor-y0qp7ims/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-06-harbor-y0qp7ims/runs/nop/2026-11-16__22-25-08/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-06-harbor-y0qp7ims/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-06-harbor-y0qp7ims/runs/nop/2026-11-16__22-25-08`

{
  "task_id": "qft-06",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-06-harbor-y0qp7ims/qft-06",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-06-harbor-y0qp7ims/qft-06",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-06-harbor-y0qp7ims/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:24:37.009051+00:00",
      "archive": "runs/qft-06/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-24-37/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-06__nXkmqkk"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-06-harbor-y0qp7ims/qft-06",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-06-harbor-y0qp7ims/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:25:08.426172+00:00",
      "archive": "runs/qft-06/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-25-08/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-06__bYKk5zL"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-07 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-07-harbor-k3lyu_yw/qft-07 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-07-harbor-k3lyu_yw/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-07-harbor-k3lyu_yw/runs/oracle/2026-11-16__22-25-38/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-07-harbor-k3lyu_yw/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-07-harbor-k3lyu_yw/runs/oracle/2026-11-16__22-25-38`

22:26:10 - LiteLLM:WARNING: get_model_cost_map.py:397 - LiteLLM: model cost map fetch attempt 1/3 failed (ConnectTimeout fetching https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json: _ssl.c:993: The handshake operation timed out); retrying in 2.3s
22:26:10 - LiteLLM:WARNING: get_model_cost_map.py:775 - LiteLLM: Failed to fetch remote model cost map from https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json: ConnectTimeout fetching https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json: _ssl.c:993: The handshake operation timed out. Falling back to local backup.
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-07-harbor-k3lyu_yw/qft-07 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-07-harbor-k3lyu_yw/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-07-harbor-k3lyu_yw/runs/nop/2026-11-16__22-26-12/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-07-harbor-k3lyu_yw/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-07-harbor-k3lyu_yw/runs/nop/2026-11-16__22-26-12`

{
  "task_id": "qft-07",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-07-harbor-k3lyu_yw/qft-07",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-07-harbor-k3lyu_yw/qft-07",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-07-harbor-k3lyu_yw/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:25:38.190262+00:00",
      "archive": "runs/qft-07/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-25-38/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-07__xg4w2TA"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-07-harbor-k3lyu_yw/qft-07",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-07-harbor-k3lyu_yw/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:26:12.244155+00:00",
      "archive": "runs/qft-07/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-26-12/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-07__L5QoZqB"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-08 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-08-harbor-6oexbie5/qft-08 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-08-harbor-6oexbie5/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-08-harbor-6oexbie5/runs/oracle/2026-11-16__22-26-42/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-08-harbor-6oexbie5/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-08-harbor-6oexbie5/runs/oracle/2026-11-16__22-26-42`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-08-harbor-6oexbie5/qft-08 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-08-harbor-6oexbie5/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-08-harbor-6oexbie5/runs/nop/2026-11-16__22-27-13/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-08-harbor-6oexbie5/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-08-harbor-6oexbie5/runs/nop/2026-11-16__22-27-13`

{
  "task_id": "qft-08",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-08-harbor-6oexbie5/qft-08",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-08-harbor-6oexbie5/qft-08",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-08-harbor-6oexbie5/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:26:41.788416+00:00",
      "archive": "runs/qft-08/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-26-42/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-08__DwJzuZJ"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-08-harbor-6oexbie5/qft-08",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-08-harbor-6oexbie5/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:27:12.717245+00:00",
      "archive": "runs/qft-08/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-27-13/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-08__6BJx2gF"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-09 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-09-harbor-912yd2px/qft-09 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-09-harbor-912yd2px/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-09-harbor-912yd2px/runs/oracle/2026-11-16__22-27-43/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-09-harbor-912yd2px/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-09-harbor-912yd2px/runs/oracle/2026-11-16__22-27-43`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-09-harbor-912yd2px/qft-09 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-09-harbor-912yd2px/runs/nop

### 2026-11-16T22:28:22.416327+08:00

```bash
python3 tools/finalize_qft_06_12.py
```

```text
[
  {
    "id": "qft-06",
    "checks": 17,
    "passed": true,
    "baseline": 0.014735869029594778,
    "reference": 1.0222377899060933e-14,
    "reference_seconds": 0.1944639590000179
  },
  {
    "id": "qft-07",
    "checks": 17,
    "passed": true,
    "baseline": 0.1941668798006142,
    "reference": 3.7565563087237505e-07,
    "reference_seconds": 0.12833537500000602
  },
  {
    "id": "qft-08",
    "checks": 17,
    "passed": true,
    "baseline": 6.176256407956054,
    "reference": 3.7541804814140155e-14,
    "reference_seconds": 0.27399383400006627
  },
  {
    "id": "qft-09",
    "checks": 17,
    "passed": true,
    "baseline": 0.032167402278406705,
    "reference": 2.6686109635508026e-15,
    "reference_seconds": 0.20522670800005471
  },
  {
    "id": "qft-10",
    "checks": 18,
    "passed": true,
    "baseline": 0.47992867558681396,
    "reference": 2.7144065196341442e-08,
    "reference_seconds": 2.5732823350000444
  },
  {
    "id": "qft-11",
    "checks": 17,
    "passed": true,
    "baseline": 0.13806808543184862,
    "reference": 5.59956619037007e-14,
    "reference_seconds": 0.27453733400000147
  },
  {
    "id": "qft-12",
    "checks": 18,
    "passed": true,
    "baseline": 0.007777707476305905,
    "reference": 1.1413301842607661e-14,
    "reference_seconds": 0.2906423749999476
  }
]

exit_code=0
```

### 2026-11-16T22:28:22.511950+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/run_qft_06_12_checks.py qft-12 --calibrate
```

```text
{
  "task_id": "qft-12",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-12 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 7.28094755939297,
    "reference": 1.1413301842607661e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.30124545900002886,
    "baseline_seconds": 0.28215320799995425
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "course_quality_score_unchanged": true,
    "symmetric_two_vacua": true,
    "strong_source_removes_metastability": true,
    "near_spinodal_three_roots": true,
    "running_coupling_keeps_mass": true,
    "course_quality_hash_matches": true
  }
}

exit_code=0
```
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-09-harbor-912yd2px/runs/nop/2026-11-16__22-28-15/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-09-harbor-912yd2px/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-09-harbor-912yd2px/runs/nop/2026-11-16__22-28-15`

{
  "task_id": "qft-09",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-09-harbor-912yd2px/qft-09",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-09-harbor-912yd2px/qft-09",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-09-harbor-912yd2px/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:27:43.217620+00:00",
      "archive": "runs/qft-09/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-27-43/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-09__rndSmDE"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-09-harbor-912yd2px/qft-09",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-09-harbor-912yd2px/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:28:15.174524+00:00",
      "archive": "runs/qft-09/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-28-15/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-09__VDFhnaU"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-10 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-10-harbor-uihxa8lf/qft-10 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-10-harbor-uihxa8lf/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-10-harbor-uihxa8lf/runs/oracle/2026-11-16__22-28-44/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-10-harbor-uihxa8lf/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-10-harbor-uihxa8lf/runs/oracle/2026-11-16__22-28-44`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-10-harbor-uihxa8lf/qft-10 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-10-harbor-uihxa8lf/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-10-harbor-uihxa8lf/runs/nop/2026-11-16__22-29-15/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-10-harbor-uihxa8lf/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-10-harbor-uihxa8lf/runs/nop/2026-11-16__22-29-15`

{
  "task_id": "qft-10",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-10-harbor-uihxa8lf/qft-10",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-10-harbor-uihxa8lf/qft-10",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-10-harbor-uihxa8lf/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:28:44.145991+00:00",
      "archive": "runs/qft-10/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-28-44/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-10__9mnzQ4y"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-10-harbor-uihxa8lf/qft-10",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-10-harbor-uihxa8lf/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:29:14.824970+00:00",
      "archive": "runs/qft-10/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-29-15/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-10__8n9WVbu"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-11 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-11-harbor-t74yo_1t/qft-11 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-11-harbor-t74yo_1t/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-11-harbor-t74yo_1t/runs/oracle/2026-11-16__22-29-46/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-11-harbor-t74yo_1t/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-11-harbor-t74yo_1t/runs/oracle/2026-11-16__22-29-46`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-11-harbor-t74yo_1t/qft-11 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-11-harbor-t74yo_1t/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-11-harbor-t74yo_1t/runs/nop/2026-11-16__22-30-16/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-11-harbor-t74yo_1t/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-11-harbor-t74yo_1t/runs/nop/2026-11-16__22-30-16`

{
  "task_id": "qft-11",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-11-harbor-t74yo_1t/qft-11",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-11-harbor-t74yo_1t/qft-11",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-11-harbor-t74yo_1t/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:29:45.697859+00:00",
      "archive": "runs/qft-11/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-29-46/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-11__wiLnh9v"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-11-harbor-t74yo_1t/qft-11",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-11-harbor-t74yo_1t/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:30:15.841844+00:00",
      "archive": "runs/qft-11/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-30-16/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-11__3mfmYaZ"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-12 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-12-harbor-wojwkh4m/qft-12 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-12-harbor-wojwkh4m/runs/oracle

### 2026-11-16T22:31:12.496564+08:00

```bash
python3 tools/finalize_qft_06_12.py
```

```text
[
  {
    "id": "qft-06",
    "checks": 17,
    "passed": true,
    "baseline": 0.014735869029594778,
    "reference": 1.0222377899060933e-14,
    "reference_seconds": 0.1944639590000179
  },
  {
    "id": "qft-07",
    "checks": 17,
    "passed": true,
    "baseline": 0.1941668798006142,
    "reference": 3.7565563087237505e-07,
    "reference_seconds": 0.12833537500000602
  },
  {
    "id": "qft-08",
    "checks": 17,
    "passed": true,
    "baseline": 6.176256407956054,
    "reference": 3.7541804814140155e-14,
    "reference_seconds": 0.27399383400006627
  },
  {
    "id": "qft-09",
    "checks": 17,
    "passed": true,
    "baseline": 0.032167402278406705,
    "reference": 2.6686109635508026e-15,
    "reference_seconds": 0.20522670800005471
  },
  {
    "id": "qft-10",
    "checks": 18,
    "passed": true,
    "baseline": 0.47992867558681396,
    "reference": 2.7144065196341442e-08,
    "reference_seconds": 2.5732823350000444
  },
  {
    "id": "qft-11",
    "checks": 17,
    "passed": true,
    "baseline": 0.13806808543184862,
    "reference": 5.59956619037007e-14,
    "reference_seconds": 0.27453733400000147
  },
  {
    "id": "qft-12",
    "checks": 18,
    "passed": true,
    "baseline": 7.28094755939297,
    "reference": 1.1413301842607661e-14,
    "reference_seconds": 0.30124545900002886
  }
]

exit_code=0
```

### 2026-11-16T22:31:12.606189+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/run_qft_06_12_checks.py
```

```text
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-12-harbor-wojwkh4m/runs/oracle/2026-11-16__22-30-46/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-12-harbor-wojwkh4m/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-12-harbor-wojwkh4m/runs/oracle/2026-11-16__22-30-46`

{
  "task_id": "qft-06",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-06 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.014735869029594778,
    "reference": 1.0222377899060933e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.17331316700006028,
    "baseline_seconds": 0.16051079099997878
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "both_master_columns_cancel": true,
    "nonzero_momentum_response_positive": true,
    "all_three_omission_residuals_differ": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-07",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-07 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.1941668798006142,
    "reference": 3.7565563087237505e-07,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.16679295900007673,
    "baseline_seconds": 0.14991520900002797
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "operator_basis_closure_diagnostic": true,
    "six_box_pole_count": true,
    "pseudoscalar_fermion_mass_and_wavefunction_poles": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-08",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-08 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 6.176256407956054,
    "reference": 3.7541804814140155e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.27992362500003765,
    "baseline_seconds": 0.307643459000019
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "gauge_parameters_same_conserved_response": true,
    "polarization_transverse": true,
    "finite_causal_energy_positive": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-09",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-09 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.032167402278406705,
    "reference": 2.6686109635508026e-15,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.25691295800015723,
    "baseline_seconds": 0.2958888339999248
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "pseudothreshold_not_physical": true,
    "normal_threshold_positive_parameters": true,
    "numerator_soft_cancellation": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-10",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-10 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.47992867558681396,
    "reference": 2.7144065196341442e-08,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.8390066670001488,
    "baseline_seconds": 0.2676206670000738
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "inclusive_known_R_ratio": true,
    "polynomial_and_sqrt_analytic_moments": true,
    "unsafe_cutoff_dependence_detected": true,
    "laplace_weight_monotone": true,
    "course_quality_hash_matches": true
  }
}
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-12-harbor-wojwkh4m/qft-12 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-12-harbor-wojwkh4m/runs/nop
{
  "task_id": "qft-11",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-11 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.13806808543184862,
    "reference": 5.59956619037007e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.300350582999954,
    "baseline_seconds": 0.26848420900000747
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "positive_walls_attract": true,
    "matching_transmission_one_plus_reflection": true,
    "finite_walls_below_dirichlet_magnitude": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-12",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-12 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 7.28094755939297,
    "reference": 1.1413301842607661e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.2888052499999958,
    "baseline_seconds": 0.2976653329999408
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "symmetric_two_vacua": true,
    "strong_source_removes_metastability": true,
    "near_spinodal_three_roots": true,
    "running_coupling_keeps_mass": true,
    "course_quality_hash_matches": true
  }
}

exit_code=0
```
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-12-harbor-wojwkh4m/runs/nop/2026-11-16__22-31-18/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-12-harbor-wojwkh4m/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-12-harbor-wojwkh4m/runs/nop/2026-11-16__22-31-18`

{
  "task_id": "qft-12",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-12-harbor-wojwkh4m/qft-12",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-12-harbor-wojwkh4m/qft-12",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-12-harbor-wojwkh4m/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:30:46.337423+00:00",
      "archive": "runs/qft-12/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-30-46/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-12__zYfdMap"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-12-harbor-wojwkh4m/qft-12",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-12-harbor-wojwkh4m/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:31:18.058127+00:00",
      "archive": "runs/qft-12/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-31-18/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-12__fJy85b6"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}

exit_code=0
```

### 2026-11-16T22:32:21.480756+08:00

```bash
python3 -c 'from pathlib import Path; p=Path("tasks/qft-06/instruction.md"); s=p.read_text(); a=s.index("## 探索反馈"); b=s.index("## 最终产物"); print(s[a:b]); print(Path("planning/status-qft-06-12.md").read_text()); print("WORKORDER"); print([str(p) for p in Path("planning").glob("*06*12*")]); print("QFT12_SESSIONS",[str(p) for p in Path("runs/qft-12/harbor-macos-compat").glob("session*.json")])'
```

```text
## 探索反馈

`python3 /app/data/explore.py` 实际计算一个公开物理积分/残差起点；Schwinger 题可用 `--mass` 比较候选质量。该探针不提供全部反项或分支答案。

`python3 /app/data/explore.py` 实际计算一个公开物理积分/残差起点；Schwinger 题可用 `--mass` 比较候选质量。该探针不提供全部反项或分支答案。

`python3 /app/data/start.py /app/output/answer.json` 生成接口样例（不是科学基线）；`python3 /app/data/feedback.py /app/output/answer.json` 检查全部输出接口和公开锚点。可自由改进方法；没有实验查询限制。公开锚点和渐近关系用于调试，最终独立答案未放入镜像。实测科学基线与专家参考值见 `/app/data/metric.json`。


# QFT-06～12实际制作状态

[
  {
    "id": "qft-06",
    "checks": 17,
    "passed": true,
    "baseline": 0.014735869029594778,
    "reference": 1.0222377899060933e-14,
    "reference_seconds": 0.1944639590000179
  },
  {
    "id": "qft-07",
    "checks": 17,
    "passed": true,
    "baseline": 0.1941668798006142,
    "reference": 3.7565563087237505e-07,
    "reference_seconds": 0.12833537500000602
  },
  {
    "id": "qft-08",
    "checks": 17,
    "passed": true,
    "baseline": 6.176256407956054,
    "reference": 3.7541804814140155e-14,
    "reference_seconds": 0.27399383400006627
  },
  {
    "id": "qft-09",
    "checks": 17,
    "passed": true,
    "baseline": 0.032167402278406705,
    "reference": 2.6686109635508026e-15,
    "reference_seconds": 0.20522670800005471
  },
  {
    "id": "qft-10",
    "checks": 18,
    "passed": true,
    "baseline": 0.47992867558681396,
    "reference": 2.7144065196341442e-08,
    "reference_seconds": 2.5732823350000444
  },
  {
    "id": "qft-11",
    "checks": 17,
    "passed": true,
    "baseline": 0.13806808543184862,
    "reference": 5.59956619037007e-14,
    "reference_seconds": 0.27453733400000147
  },
  {
    "id": "qft-12",
    "checks": 18,
    "passed": true,
    "baseline": 7.28094755939297,
    "reference": 1.1413301842607661e-14,
    "reference_seconds": 0.30124545900002886
  }
]

七题题包、来源、完整推导、公开物理探索探针、参考/基线、独立真值与Linux校准已实现。Harbor每题oracle/nop原始记录另见runs；不得把尚在运行的项目记为已通过。课程正式三次Codex测评尚未执行。

WORKORDER
['planning/work-order-build-qft-06-12.md', 'planning/status-qft-06-12.md']
QFT12_SESSIONS ['runs/qft-12/harbor-macos-compat/session-20261116-223148.json']

exit_code=0
```

### 2026-11-16T22:33:05.384752+08:00

```bash
cat planning/work-order-build-qft-06-12.md
```

```text
# 实施任务：QFT-06 至 QFT-12

当前用户要求实际完成整个50题Harbor benchmark，不能只交选题计划。

你负责 qft-06、07、08、09、10、11、12 共7题。读取主选题JSON及独立审核，逐题制作完整可运行任务。根目录为本文件父目录的父目录。

参照 tasks/qft-04：instruction.md、task.toml、environment/Dockerfile及公开材料、solution/solve.py+baseline.py+solve.sh+推导README、tests/score.py+test.sh+metric.json+课程原版quality_score.py+private/truth.json。需有来源说明、材料与公平性、独立真值生成工具和实质错误/合法替代/空答案回归，实际Linux校准。原书题面和解答已在 planning/source-notes/，按页核读；不复制答案当挑战，不用同一个核心函数同时做参考和真值。

按 qft-expansion-20-selection.json 的独立机制实施。QFT10需先落实自洽NLO实/虚辐射过程和测量函数，不能用有限矩阵恒等式凑题。QFT06须处理tadpole和完整Goldstone抵消。QFT08纵向项仅对守恒源不贡献。QFT11为两本原题合并一道。

每题固定公开实例，明确输入、单位、schema、评分误差和容差；4CPU/4GiB/0GPU。agent时限暂用720秒、verifier120秒，50题总计不超43200秒；真实求解若需要更多时间向主代理报告重新分配。不要写共享README/manifest，只写本题和专属tools/checks，状态存 planning/status-qft-06-12.md。

命令执行前在commentary展示，并用 python3 tools/run_logged.py --log checks/qft-06-12-command-log.md -- COMMAND 记录。仅Mac本地和Docker，不连服务器、不使用GPU、不推送，不停止别人的容器。Docker只运行自己创建的新容器。每做完一题就继续下一题，直到7题实际完成；课程正式Codex三次测评不等于oracle，不能伪称完成。

exit_code=0
```

### 2026-11-16T22:34:16.884413+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/run_qft_06_12_checks.py
```

```text
{
  "task_id": "qft-06",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-06 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.014735869029594778,
    "reference": 1.0222377899060933e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.14707370800010722,
    "baseline_seconds": 0.16587574999994104
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "specific_physics_fault_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "both_master_columns_cancel": true,
    "nonzero_momentum_response_positive": true,
    "all_three_omission_residuals_differ": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-07",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-07 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.1941668798006142,
    "reference": 3.7565563087237505e-07,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.18845116700003928,
    "baseline_seconds": 0.1375775839999278
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "specific_physics_fault_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "operator_basis_closure_diagnostic": true,
    "six_box_pole_count": true,
    "pseudoscalar_fermion_mass_and_wavefunction_poles": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-08",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-08 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 6.176256407956054,
    "reference": 3.7541804814140155e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.31017929200015715,
    "baseline_seconds": 0.29170012500003395
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "specific_physics_fault_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "gauge_parameters_same_conserved_response": true,
    "polarization_transverse": true,
    "finite_causal_energy_positive": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-09",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-09 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.032167402278406705,
    "reference": 2.6686109635508026e-15,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.29126583399988704,
    "baseline_seconds": 0.31086758400010694
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "specific_physics_fault_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "pseudothreshold_not_physical": true,
    "normal_threshold_positive_parameters": true,
    "numerator_soft_cancellation": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-10",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-10 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.47992867558681396,
    "reference": 2.7144065196341442e-08,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.6658640420000665,
    "baseline_seconds": 0.24082066699997995
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "specific_physics_fault_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "inclusive_known_R_ratio": true,
    "polynomial_and_sqrt_analytic_moments": true,
    "unsafe_cutoff_dependence_detected": true,
    "laplace_weight_monotone": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-11",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-11 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 0.13806808543184862,
    "reference": 5.59956619037007e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.2800352079998447,
    "baseline_seconds": 0.23207941700002266
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "specific_physics_fault_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "positive_walls_attract": true,
    "matching_transmission_one_plus_reflection": true,
    "finite_walls_below_dirichlet_magnitude": true,
    "course_quality_hash_matches": true
  }
}
{
  "task_id": "qft-12",
  "metric": {
    "kind": "continuous",
    "metric_name": "qft-12 物理证书与可观测量归一化误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 7.28094755939297,
    "reference": 1.1413301842607661e-14,
    "tolerance": 1e-05
  },
  "runtime": {
    "reference_seconds": 0.30369662499992955,
    "baseline_seconds": 0.2816408330002105
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_beats_physical_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "record_reordering_same_score": true,
    "independent_truth_full_credit": true,
    "scientific_error_penalized": true,
    "specific_physics_fault_penalized": true,
    "all_invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "verifier_nonfinite_boundaries_zero": true,
    "verifier_wrong_physics_penalized": true,
    "development_feedback_usable": true,
    "public_physics_probe_runs": true,
    "course_quality_score_unchanged": true,
    "symmetric_two_vacua": true,
    "strong_source_removes_metastability": true,
    "near_spinodal_three_roots": true,
    "running_coupling_keeps_mass": true,
    "course_quality_hash_matches": true
  }
}

exit_code=0
```

### 2026-11-16T22:35:30.451499+08:00

```bash
python3 tools/finalize_qft_06_12.py
```

```text
[
  {
    "id": "qft-06",
    "checks": 19,
    "passed": true,
    "baseline": 0.014735869029594778,
    "reference": 1.0222377899060933e-14,
    "reference_seconds": 0.14707370800010722,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-06/harbor-macos-compat/session-20261116-222538.json"
    ]
  },
  {
    "id": "qft-07",
    "checks": 19,
    "passed": true,
    "baseline": 0.1941668798006142,
    "reference": 3.7565563087237505e-07,
    "reference_seconds": 0.18845116700003928,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-07/harbor-macos-compat/session-20261116-222641.json"
    ]
  },
  {
    "id": "qft-08",
    "checks": 19,
    "passed": true,
    "baseline": 6.176256407956054,
    "reference": 3.7541804814140155e-14,
    "reference_seconds": 0.31017929200015715,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-08/harbor-macos-compat/session-20261116-222743.json"
    ]
  },
  {
    "id": "qft-09",
    "checks": 19,
    "passed": true,
    "baseline": 0.032167402278406705,
    "reference": 2.6686109635508026e-15,
    "reference_seconds": 0.29126583399988704,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-09/harbor-macos-compat/session-20261116-222844.json"
    ]
  },
  {
    "id": "qft-10",
    "checks": 20,
    "passed": true,
    "baseline": 0.47992867558681396,
    "reference": 2.7144065196341442e-08,
    "reference_seconds": 0.6658640420000665,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-10/harbor-macos-compat/session-20261116-222945.json"
    ]
  },
  {
    "id": "qft-11",
    "checks": 19,
    "passed": true,
    "baseline": 0.13806808543184862,
    "reference": 5.59956619037007e-14,
    "reference_seconds": 0.2800352079998447,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-11/harbor-macos-compat/session-20261116-223046.json"
    ]
  },
  {
    "id": "qft-12",
    "checks": 20,
    "passed": true,
    "baseline": 7.28094755939297,
    "reference": 1.1413301842607661e-14,
    "reference_seconds": 0.30369662499992955,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-12/harbor-macos-compat/session-20261116-223148.json"
    ]
  }
]

exit_code=0
```

### 2026-11-16T22:35:30.559111+08:00

```bash
python3 tools/run_pending_harbor.py qft-06 qft-07 qft-08 qft-09 qft-10 qft-11 qft-12
```

```text
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-06 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-06-harbor-ytrjije2/qft-06 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-06-harbor-ytrjije2/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-06-harbor-ytrjije2/runs/oracle/2026-11-16__22-35-31/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-06-harbor-ytrjije2/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-06-harbor-ytrjije2/runs/oracle/2026-11-16__22-35-31`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-06-harbor-ytrjije2/qft-06 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-06-harbor-ytrjije2/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-06-harbor-ytrjije2/runs/nop/2026-11-16__22-36-00/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-06-harbor-ytrjije2/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-06-harbor-ytrjije2/runs/nop/2026-11-16__22-36-00`

22:36:31 - LiteLLM:WARNING: get_model_cost_map.py:397 - LiteLLM: model cost map fetch attempt 1/3 failed (ConnectTimeout fetching https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json: _ssl.c:993: The handshake operation timed out); retrying in 2.1s
22:36:31 - LiteLLM:WARNING: get_model_cost_map.py:775 - LiteLLM: Failed to fetch remote model cost map from https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json: ConnectTimeout fetching https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json: _ssl.c:993: The handshake operation timed out. Falling back to local backup.
{
  "task_id": "qft-06",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-06-harbor-ytrjije2/qft-06",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-06-harbor-ytrjije2/qft-06",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-06-harbor-ytrjije2/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:35:30.647935+00:00",
      "archive": "runs/qft-06/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-35-31/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-06__zEocWJU"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-06-harbor-ytrjije2/qft-06",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-06-harbor-ytrjije2/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:35:59.840126+00:00",
      "archive": "runs/qft-06/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-36-00/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-06__ryvAyiH"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-07 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-07-harbor-y980_qmm/qft-07 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-07-harbor-y980_qmm/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-07-harbor-y980_qmm/runs/oracle/2026-11-16__22-36-33/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-07-harbor-y980_qmm/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-07-harbor-y980_qmm/runs/oracle/2026-11-16__22-36-33`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-07-harbor-y980_qmm/qft-07 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-07-harbor-y980_qmm/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-07-harbor-y980_qmm/runs/nop/2026-11-16__22-37-02/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-07-harbor-y980_qmm/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-07-harbor-y980_qmm/runs/nop/2026-11-16__22-37-02`

{
  "task_id": "qft-07",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-07-harbor-y980_qmm/qft-07",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-07-harbor-y980_qmm/qft-07",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-07-harbor-y980_qmm/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:36:33.532850+00:00",
      "archive": "runs/qft-07/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-36-33/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-07__zXGgqZF"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-07-harbor-y980_qmm/qft-07",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-07-harbor-y980_qmm/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:37:02.610618+00:00",
      "archive": "runs/qft-07/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-37-02/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-07__b9wZoUk"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-08 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-08-harbor-tp1ftk1q/qft-08 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-08-harbor-tp1ftk1q/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-08-harbor-tp1ftk1q/runs/oracle/2026-11-16__22-37-30/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-08-harbor-tp1ftk1q/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-08-harbor-tp1ftk1q/runs/oracle/2026-11-16__22-37-30`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-08-harbor-tp1ftk1q/qft-08 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-08-harbor-tp1ftk1q/runs/nop

### 2026-11-16T22:38:05.925856+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user root -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python tools/build_qft_06_12_truth.py qft-07
```

```text
qft-07 {"unreduced_triangle_vs_reduced_integral": 0.0, "constant_background_determinant_vs_six_boxes": 0.0, "unexpanded_D_dimensional_Gamma_masters_vs_finite_MSbar": 2.3023731924459825e-14, "epsilon_extrapolation": [1e-07, 5e-08], "scheme": "D=4-epsilon; pole fields multiply 16 pi² epsilon; MSbar finite subtraction; anticommuting gamma5, no anomalous trace", "precision_digits": 50, "truth_route": "independent local program, no import from solution", "formal_codex_measurement": false}

exit_code=0
```
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-08-harbor-tp1ftk1q/runs/nop/2026-11-16__22-37-59/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-08-harbor-tp1ftk1q/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-08-harbor-tp1ftk1q/runs/nop/2026-11-16__22-37-59`

{
  "task_id": "qft-08",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-08-harbor-tp1ftk1q/qft-08",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-08-harbor-tp1ftk1q/qft-08",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-08-harbor-tp1ftk1q/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:37:30.672936+00:00",
      "archive": "runs/qft-08/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-37-30/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-08__MuXWUAY"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-08-harbor-tp1ftk1q/qft-08",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-08-harbor-tp1ftk1q/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:37:59.395902+00:00",
      "archive": "runs/qft-08/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-37-59/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-08__oKP3fxc"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-09 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-09-harbor-4xwen4oo/qft-09 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-09-harbor-4xwen4oo/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-09-harbor-4xwen4oo/runs/oracle/2026-11-16__22-38-31/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-09-harbor-4xwen4oo/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-09-harbor-4xwen4oo/runs/oracle/2026-11-16__22-38-31`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-09-harbor-4xwen4oo/qft-09 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-09-harbor-4xwen4oo/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-09-harbor-4xwen4oo/runs/nop/2026-11-16__22-39-01/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-09-harbor-4xwen4oo/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-09-harbor-4xwen4oo/runs/nop/2026-11-16__22-39-01`

{
  "task_id": "qft-09",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-09-harbor-4xwen4oo/qft-09",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-09-harbor-4xwen4oo/qft-09",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-09-harbor-4xwen4oo/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:38:30.878537+00:00",
      "archive": "runs/qft-09/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-38-31/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-09__FjtGV8D"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-09-harbor-4xwen4oo/qft-09",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-09-harbor-4xwen4oo/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:39:01.490812+00:00",
      "archive": "runs/qft-09/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-39-01/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-09__DKbWRiM"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-10 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-10-harbor-fvgwis16/qft-10 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-10-harbor-fvgwis16/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-10-harbor-fvgwis16/runs/oracle/2026-11-16__22-39-31/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-10-harbor-fvgwis16/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-10-harbor-fvgwis16/runs/oracle/2026-11-16__22-39-31`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-10-harbor-fvgwis16/qft-10 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-10-harbor-fvgwis16/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-10-harbor-fvgwis16/runs/nop/2026-11-16__22-40-01/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-10-harbor-fvgwis16/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-10-harbor-fvgwis16/runs/nop/2026-11-16__22-40-01`

{
  "task_id": "qft-10",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-10-harbor-fvgwis16/qft-10",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-10-harbor-fvgwis16/qft-10",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-10-harbor-fvgwis16/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:39:30.942411+00:00",
      "archive": "runs/qft-10/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-39-31/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-10__wpuPSLP"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-10-harbor-fvgwis16/qft-10",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-10-harbor-fvgwis16/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:40:01.540299+00:00",
      "archive": "runs/qft-10/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-40-01/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-10__L9tVgFP"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-11 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-11-harbor-uuhdctni/qft-11 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-11-harbor-uuhdctni/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-11-harbor-uuhdctni/runs/oracle/2026-11-16__22-40-31/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-11-harbor-uuhdctni/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-11-harbor-uuhdctni/runs/oracle/2026-11-16__22-40-31`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-11-harbor-uuhdctni/qft-11 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-11-harbor-uuhdctni/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-11-harbor-uuhdctni/runs/nop/2026-11-16__22-41-01/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-11-harbor-uuhdctni/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-11-harbor-uuhdctni/runs/nop/2026-11-16__22-41-01`

{
  "task_id": "qft-11",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-11-harbor-uuhdctni/qft-11",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-11-harbor-uuhdctni/qft-11",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-11-harbor-uuhdctni/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:40:31.404305+00:00",
      "archive": "runs/qft-11/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-40-31/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-11__HHS5XZL"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-11-harbor-uuhdctni/qft-11",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-11-harbor-uuhdctni/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:41:01.490215+00:00",
      "archive": "runs/qft-11/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-41-01/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-11__Ex5Cvoh"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-12 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-12-harbor-cao83maw/qft-12 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-12-harbor-cao83maw/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-12-harbor-cao83maw/runs/oracle/2026-11-16__22-41-32/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-12-harbor-cao83maw/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-12-harbor-cao83maw/runs/oracle/2026-11-16__22-41-32`


### 2026-11-16T22:42:01.179358+08:00

```bash
python3 -c 'from pathlib import Path; import ast,json,tomllib; root=Path.cwd(); required=["instruction.md","task.toml","environment/Dockerfile","environment/public/model.json","environment/public/explore.py","solution/README.md","solution/solve.py","solution/baseline.py","solution/solve.sh","tests/score.py","tests/test.sh","tests/metric.json","tests/private/truth.json"]; out=[]; count=0; limit=0; [ast.parse(p.read_text()) for p in Path("tools").glob("*qft_06_12*.py")]; exec("for n in range(6,13):\n t=root/\"tasks\"/f\"qft-{n:02}\"\n assert all((t/f).is_file() for f in required)\n for p in t.rglob(\"*.py\"): ast.parse(p.read_text())\n for p in t.rglob(\"*.json\"): json.loads(p.read_text())\n c=tomllib.loads((t/\"task.toml\").read_text())\n assert c[\"artifacts\"]==[\"/app/output/answer.json\",\"/app/output/derivation.md\"]\n assert c[\"verifier\"][\"network_mode\"]==\"no-network\"\n assert (t/\"instruction.md\").read_text().count(\"`python3 /app/data/explore.py`\")==1\n calibration=json.loads((root/\"checks\"/(t.name+\"-calibration.json\")).read_text())\n assert all(calibration[\"checks\"].values())\n count+=len(calibration[\"checks\"]);limit+=c[\"agent\"][\"timeout_sec\"]+c[\"verifier\"][\"timeout_sec\"]\n out.append({\"id\":t.name,\"checks\":len(calibration[\"checks\"]),\"declared_seconds\":c[\"agent\"][\"timeout_sec\"]+c[\"verifier\"][\"timeout_sec\"]})"); print(json.dumps({"tasks":out,"check_total":count,"declared_total_seconds":limit},ensure_ascii=False,indent=2))'
```

```text
{
  "tasks": [
    {
      "id": "qft-06",
      "checks": 19,
      "declared_seconds": 840.0
    },
    {
      "id": "qft-07",
      "checks": 19,
      "declared_seconds": 840.0
    },
    {
      "id": "qft-08",
      "checks": 19,
      "declared_seconds": 840.0
    },
    {
      "id": "qft-09",
      "checks": 19,
      "declared_seconds": 840.0
    },
    {
      "id": "qft-10",
      "checks": 20,
      "declared_seconds": 840.0
    },
    {
      "id": "qft-11",
      "checks": 19,
      "declared_seconds": 840.0
    },
    {
      "id": "qft-12",
      "checks": 20,
      "declared_seconds": 840.0
    }
  ],
  "check_total": 135,
  "declared_total_seconds": 5880.0
}

exit_code=0
```
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-12-harbor-cao83maw/qft-12 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-12-harbor-cao83maw/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-12-harbor-cao83maw/runs/nop/2026-11-16__22-42-02/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-12-harbor-cao83maw/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-12-harbor-cao83maw/runs/nop/2026-11-16__22-42-02`

{
  "task_id": "qft-12",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-12-harbor-cao83maw/qft-12",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-12-harbor-cao83maw/qft-12",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-12-harbor-cao83maw/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:41:31.774270+00:00",
      "archive": "runs/qft-12/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-41-32/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-12__Q7Vzcjg"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-12-harbor-cao83maw/qft-12",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-12-harbor-cao83maw/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:42:02.666637+00:00",
      "archive": "runs/qft-12/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-42-02/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-12__uKDBXRS"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}

exit_code=0
```

### 2026-11-16T22:43:00.776656+08:00

```bash
python3 tools/finalize_qft_06_12.py
```

```text
[
  {
    "id": "qft-06",
    "checks": 19,
    "passed": true,
    "baseline": 0.014735869029594778,
    "reference": 1.0222377899060933e-14,
    "reference_seconds": 0.14707370800010722,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-06/harbor-macos-compat/session-20261116-222538.json",
      "runs/qft-06/harbor-macos-compat/session-20261116-223633.json"
    ]
  },
  {
    "id": "qft-07",
    "checks": 19,
    "passed": true,
    "baseline": 0.1941668798006142,
    "reference": 3.7565563087237505e-07,
    "reference_seconds": 0.18845116700003928,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-07/harbor-macos-compat/session-20261116-222641.json",
      "runs/qft-07/harbor-macos-compat/session-20261116-223730.json"
    ]
  },
  {
    "id": "qft-08",
    "checks": 19,
    "passed": true,
    "baseline": 6.176256407956054,
    "reference": 3.7541804814140155e-14,
    "reference_seconds": 0.31017929200015715,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-08/harbor-macos-compat/session-20261116-222743.json",
      "runs/qft-08/harbor-macos-compat/session-20261116-223830.json"
    ]
  },
  {
    "id": "qft-09",
    "checks": 19,
    "passed": true,
    "baseline": 0.032167402278406705,
    "reference": 2.6686109635508026e-15,
    "reference_seconds": 0.29126583399988704,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-09/harbor-macos-compat/session-20261116-222844.json",
      "runs/qft-09/harbor-macos-compat/session-20261116-223930.json"
    ]
  },
  {
    "id": "qft-10",
    "checks": 20,
    "passed": true,
    "baseline": 0.47992867558681396,
    "reference": 2.7144065196341442e-08,
    "reference_seconds": 0.6658640420000665,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-10/harbor-macos-compat/session-20261116-222945.json",
      "runs/qft-10/harbor-macos-compat/session-20261116-224031.json"
    ]
  },
  {
    "id": "qft-11",
    "checks": 19,
    "passed": true,
    "baseline": 0.13806808543184862,
    "reference": 5.59956619037007e-14,
    "reference_seconds": 0.2800352079998447,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-11/harbor-macos-compat/session-20261116-223046.json",
      "runs/qft-11/harbor-macos-compat/session-20261116-224131.json"
    ]
  },
  {
    "id": "qft-12",
    "checks": 20,
    "passed": true,
    "baseline": 7.28094755939297,
    "reference": 1.1413301842607661e-14,
    "reference_seconds": 0.30369662499992955,
    "harbor_oracle_nop_passed": true,
    "harbor_sessions": [
      "runs/qft-12/harbor-macos-compat/session-20261116-223148.json",
      "runs/qft-12/harbor-macos-compat/session-20261116-224231.json"
    ]
  }
]

exit_code=0
```

### 2026-11-16T22:46:05.080215+08:00

```bash
cat planning/work-order-build-qft-06-12.md
```

```text
# 实施任务：QFT-06 至 QFT-12

当前用户要求实际完成整个50题Harbor benchmark，不能只交选题计划。

你负责 qft-06、07、08、09、10、11、12 共7题。读取主选题JSON及独立审核，逐题制作完整可运行任务。根目录为本文件父目录的父目录。

参照 tasks/qft-04：instruction.md、task.toml、environment/Dockerfile及公开材料、solution/solve.py+baseline.py+solve.sh+推导README、tests/score.py+test.sh+metric.json+课程原版quality_score.py+private/truth.json。需有来源说明、材料与公平性、独立真值生成工具和实质错误/合法替代/空答案回归，实际Linux校准。原书题面和解答已在 planning/source-notes/，按页核读；不复制答案当挑战，不用同一个核心函数同时做参考和真值。

按 qft-expansion-20-selection.json 的独立机制实施。QFT10需先落实自洽NLO实/虚辐射过程和测量函数，不能用有限矩阵恒等式凑题。QFT06须处理tadpole和完整Goldstone抵消。QFT08纵向项仅对守恒源不贡献。QFT11为两本原题合并一道。

每题固定公开实例，明确输入、单位、schema、评分误差和容差；4CPU/4GiB/0GPU。agent时限暂用720秒、verifier120秒，50题总计不超43200秒；真实求解若需要更多时间向主代理报告重新分配。不要写共享README/manifest，只写本题和专属tools/checks，状态存 planning/status-qft-06-12.md。

命令执行前在commentary展示，并用 python3 tools/run_logged.py --log checks/qft-06-12-command-log.md -- COMMAND 记录。仅Mac本地和Docker，不连服务器、不使用GPU、不推送，不停止别人的容器。Docker只运行自己创建的新容器。每做完一题就继续下一题，直到7题实际完成；课程正式Codex三次测评不等于oracle，不能伪称完成。

exit_code=0
```

### 2026-11-16T22:47:29.048650+08:00

```bash
python3 -c 'from pathlib import Path; p=Path("planning/work-order-build-qft-06-12-update.md"); print(p.read_text() if p.exists() else "追加工作单尚未写入")'
```

```text
追加工作单尚未写入

exit_code=0
```
