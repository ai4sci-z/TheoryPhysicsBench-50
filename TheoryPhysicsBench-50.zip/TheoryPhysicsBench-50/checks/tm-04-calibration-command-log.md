
### 2026-11-16T22:11:07.055466+08:00

```bash
docker run --rm --cpus 4 --memory 4g --network none --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/workspace' -w /workspace theory-physics-qft04:dev python3 tools/run_remaining_five_checks.py tm-04 --calibrate
```

```text
{
  "task": "tm-04",
  "checks": {
    "linux": true,
    "reference_matches_independent_truth": true,
    "truth_zero": true,
    "reference_reward": true,
    "baseline_is_nontrivial": true,
    "reordered_equivalent": true,
    "rounding_accepted": true,
    "wrong_physics_penalized": true,
    "empty_invalid": true,
    "missing_case_invalid": true,
    "duplicate_invalid": true,
    "boolean_invalid": true,
    "nan_invalid": true,
    "infinity_invalid": true,
    "string_invalid": true,
    "null_invalid": true,
    "huge_integer_invalid": true,
    "short_vector_invalid": true,
    "public_feedback_runs": true,
    "reference_entrypoint": true,
    "wrong_physics_entrypoint": true,
    "empty_entrypoint": true
  },
  "runtimes": {
    "baseline_seconds": 0.5372919590000009,
    "reference_seconds": 0.49098862499999996
  },
  "metric": {
    "kind": "continuous",
    "metric_name": "tm-04物理量归一误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 34.07714359344464,
    "reference": 1.7615553800201666e-11,
    "tolerance": 2e-05
  }
}

exit_code=0
```
