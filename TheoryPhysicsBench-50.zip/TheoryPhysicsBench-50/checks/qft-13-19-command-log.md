
### 2026-11-16T21:56:51.271052+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(str(p) for p in Path(".").rglob("AGENTS.md"))); print(Path("tasks/qft-04/task.toml").read_text()); print(Path("tasks/qft-04/instruction.md").read_text())'
```

```text

### 2026-11-16T21:56:51.271047+08:00

```bash
python3 -c 'import json; d=json.load(open("planning/qft-expansion-20-selection.json")); print(json.dumps(d,ensure_ascii=False,indent=2))'
```

```text
{
  "name": "TheoryPhysicsBench：新增20道量子场论任务遴选",
  "schema_version": 1,
  "status": "selected_for_development_not_frozen",
  "research_goal": "在受控量子场论模型中，从理论约束与公开材料构造可计算方案，辨别物理分支、近似适用性和数值伪解，以独立物理量验证推断。",
  "scope": "原30题开发计划保留；本清单新增qft-06至qft-25，不是课程正式benchmark.json。",
  "difficulty_status": "按理论工作量与研究判断筛选，尚无课程统一Codex三次测评难度结果。",
  "resource_plan": {
    "cpu": 4,
    "memory_gib": 4,
    "gpu": 0,
    "agent_timeout_seconds": 1200,
    "verifier_timeout_seconds": 120,
    "measured": false
  },
  "sources": {
    "R": {
      "author": "Voja Radovanović",
      "title": "Problem Book in Quantum Field Theory",
      "edition": "Second Edition, 2008",
      "path": "/Users/ai4s/Downloads/Problem Book in Quantum Field Theory.pdf",
      "sha256": "26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db",
      "review": "planning/qft-expansion-radovanovic-review.md"
    },
    "G": {
      "author": "François Gelis",
      "title": "Problems in Quantum Field Theory",
      "path": "/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf",
      "sha256": "7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5",
      "review": "planning/qft-expansion-gelis-review.md",
      "thermal_review": "planning/qft-expansion-gelis-thermal-review.md",
      "page_warning": "PDF章节重排，页码按实际文件逐段登记，不用全书统一偏移。"
    }
  },
  "tasks": [
    {
      "id": "qft-06",
      "title": "Goldstone 模式的一圈质量保护与漏图诊断",
      "source": "R",
      "problems": [
        "11.8"
      ],
      "pages": [
        {
          "pdf": [
            65,
            65
          ],
          "printed": [
            63,
            63
          ],
          "role": "题面"
        },
        {
          "pdf": [
            219,
            220
          ],
          "printed": [
            221,
            222
          ],
          "role": "解答"
        }
      ],
      "reading": "完整题面与相关解答已核读；关键原页已视觉核对。",
      "original_work": "移位后的两标量模型中枚举五类一圈贡献，含真空tadpole，用同一正则化和真空条件证明Σπ(0)=0。",
      "task_design": "从公开拉氏量和图拓扑重建各图系数，计算零动量抵消证书和空间样动量处的有限响应；诊断三组删图或错因子方案产生的伪质量。",
      "public_materials": "固定模型、顶点归一化、欧氏外动量、共同减除方案和待诊断方案；不公开正确系数表。",
      "deliverables": [
        "各图master-integral系数",
        "零动量抵消与真空条件残差",
        "有限动量响应",
        "错误方案的伪质量及故障位置"
      ],
      "verification": [
        "独立Wick组合与符号系数核算",
        "高精度参数积分及对称性关系交叉检查"
      ],
      "baseline": "逐图直接积分但使用有限精度和朴素减除；漏图模型只作错误对照，不充当故意降分的基线。",
      "difficulty": "图组合、真空移位、对称因子与对称性约束必须同时自洽，背诵Goldstone定理不能完成非零动量结果。",
      "independence": "区别既有真空极化阈值、树图Ward检查及qft-12的非微扰有效势。",
      "implementation_gate": "独立核对全部五图系数、有限响应的UV减除与合法等价表示。"
    },
    {
      "id": "qft-07",
      "title": "赝标量 Yukawa 理论的反项闭合与有限振幅",
      "source": "R",
      "problems": [
        "11.12"
      ],
      "pages": [
        {
          "pdf": [
            66,
            66
          ],
          "printed": [
            64,
            64
          ],
          "role": "题面"
        },
        {
          "pdf": [
            225,
            231
          ],
          "printed": [
            227,
            233
          ],
          "role": "解答"
        }
      ],
      "reading": "完整题面与解答已核读；关键原页已视觉核对。",
      "original_work": "由幂计数及一圈费米子/标量两点、Yukawa三点和标量四点图，构造闭合的局域反项，包括费米盒图排列和耦合混合。",
      "task_design": "判断几个候选算符基是否重整化闭合，独立提取全部UV极点多项式，构造明确MS方案下的有限欧氏响应，定位删除φ⁴反项后的剩余发散。",
      "public_materials": "拉氏量、γ5与维数约定、非例外运动学、允许算符和图枚举规则。",
      "deliverables": [
        "发散振幅及最小反项基",
        "UV极点系数",
        "有限两点/三点/四点响应",
        "方案闭合性证书"
      ],
      "verification": [
        "Gamma函数Laurent展开及独立Dirac迹/排列计数",
        "独立参数积分和改变减除尺度的一致性检验"
      ],
      "baseline": "直接维数积分加低阶参数求积的完整一圈起点。",
      "difficulty": "多场结构、闭费米环符号、γ5和六个盒图排列共同决定反项混合；不拆小问计题。",
      "independence": "qft-03只演化已给beta函数，本题从图构造反项；六维φ³不同时入选。",
      "implementation_gate": "固定ε和MS约定，重新推导不能机械抄用书中的质量壳有限项。"
    },
    {
      "id": "qft-08",
      "title": "二维 Schwinger 模型的质量生成与守恒源响应",
      "source": "R",
      "problems": [
        "11.13"
      ],
      "pages": [
        {
          "pdf": [
            66,
            66
          ],
          "printed": [
            64,
            64
          ],
          "role": "题面"
        },
        {
          "pdf": [
            231,
            232
          ],
          "printed": [
            233,
            234
          ],
          "role": "解答"
        }
      ],
      "reading": "完整题面与解答已核读；关键原页已视觉核对。",
      "original_work": "保留D=2−ε的张量结构计算横向极化，再Dyson求和，在守恒源响应中得到mγ²=e²/π。",
      "task_design": "重建调节后极化和横向传播子，计算有限时间守恒源的频域与时域响应；比较规范参数变化及提前取二维极限的错误方案。",
      "public_materials": "二维QED作用量、retarded处方、由流函数生成的守恒源、查询网格与分布约定。",
      "deliverables": [
        "极化张量及横向残差",
        "质量极点与留数",
        "规范不变源响应",
        "有限时域响应与错误极限诊断"
      ],
      "verification": [
        "保留ε的张量参数积分与Laurent极限",
        "横向谱表示和独立因果初值响应"
      ],
      "baseline": "有明确时间窗和粗离散的谱积分响应。",
      "difficulty": "有限质量来自调节极限，纵向规范项只能在守恒源投影后消去；单报e/√π不得满分。",
      "independence": "不同于qft-01的四维阈值谱，也不同于qft-25的外场标量产对。",
      "implementation_gate": "固定源、边界与极点处方，推导有限响应后再校准，避免靠人为超严容差制造难度。"
    },
    {
      "id": "qft-09",
      "title": "Landau 方程的物理奇点分支与夹挤证书",
      "source": "G",
      "problems": [
        "5"
      ],
      "pages": [
        {
          "pdf": [
            34,
            40
          ],
          "printed": [
            22,
            28
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "推导Feynman参数在壳条件和逐圈方程，找出无质量三角图两条共线支、一条软支，以Coleman–Norton图像排除伪分支。",
      "task_design": "对同一研究任务中的有限图集枚举物理奇点分支，给非负参数、在壳与闭环证书，区分可绕过的分母零点、端点和夹挤。",
      "public_materials": "动量定向、质量和外线运动学、Feynman参数约束、候选缩图及明确分子。",
      "deliverables": [
        "完整分支列表与分类",
        "归一化参数证书",
        "在壳与逐圈残差",
        "被排除分支的不可行条件"
      ],
      "verification": [
        "有理消元及边界分支枚举",
        "评分器代回方程并检查正性、物理域和完整性"
      ],
      "baseline": "多初值数值找根与残差过滤，不承诺完整枚举。",
      "difficulty": "数值零点不等于实际奇点，物理域、端点和分子抵消必须区别。",
      "independence": "研究分支结构而非重复qft-01固定一圈函数的求积。",
      "implementation_gate": "为选定图族建立可证明完备的分支真值；Landau必要条件不直接当充分条件。"
    },
    {
      "id": "qft-10",
      "title": "简并态、探测分辨率与红外安全可观测量",
      "source": "G",
      "problems": [
        "11"
      ],
      "pages": [
        {
          "pdf": [
            55,
            61
          ],
          "printed": [
            43,
            49
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；具体辐射过程为待推导原创扩展。",
      "original_work": "用散射算符端点简并子空间及幺正性，证明完整初末不可分辨态求和消除红外奇异；有明确连续谱及简并集合假设。",
      "task_design": "在单一中性源到无质量带电费米子对的受控NLO辐射模型中，比较软/共线安全和不安全的测量函数；组合真实与虚修正，选择探测分辨率，重建有限inclusive量及残余调节器对数。",
      "public_materials": "一套完整且自洽的实/虚修正、相空间、局部减除起点及测量函数定义；所需初态是否须平均由具体过程明定。",
      "deliverables": [
        "测量函数的软/共线极限证书",
        "inclusive修正",
        "调节器扫描及对数残项",
        "安全性分类和分辨率下的物理预测"
      ],
      "verification": [
        "局部减除的独立有限积分",
        "相空间切片法加解析软/共线抵消，逐步外推切片参数"
      ],
      "baseline": "固定相空间切片与普通求积的物理完整起点。",
      "difficulty": "局部实虚相消、测量定义和实验不可分辨性共同决定有限答案，不能仅验证矩阵范数恒等式。",
      "independence": "qft-16研究规范完整的非阿贝尔真空角分布；本题研究inclusive可观测量及调节器消除。",
      "implementation_gate": "优先级C：先独立推导一个完整具体NLO过程并补来源；若只完成有限矩阵玩具或软口号则不计作完成题。"
    },
    {
      "id": "qft-11",
      "title": "Casimir 相互作用的双路线重构与有限壁强度",
      "source": "G",
      "problems": [
        "24",
        "25"
      ],
      "pages": [
        {
          "pdf": [
            274,
            277
          ],
          "printed": [
            103,
            106
          ],
          "role": "24题完整题面与解答"
        },
        {
          "pdf": [
            278,
            281
          ],
          "printed": [
            107,
            110
          ],
          "role": "25题完整题面与解答"
        }
      ],
      "reading": "两题完整相关段落已核读；合为一道。",
      "original_work": "零点模和减去体积项，用Euler–Maclaurin得到能量与应力；以δ壁的泛函行列式和ζ函数独立复现强壁极限。",
      "task_design": "构造有限正壁强度的标量真空相互作用，减去孤立壁自能，计算距离依赖的能量和力，比较弱壁及Dirichlet极限并证明调节独立性。",
      "public_materials": "δ壁作用量、跳跃匹配条件、减除定义、无量纲壁强度和距离查询。",
      "deliverables": [
        "相互作用能与力",
        "匹配/谱条件证书",
        "强壁与弱壁误差",
        "应力与能量导数的一致性"
      ],
      "verification": [
        "独立反射系数的Euclidean行列式积分",
        "谱密度/相移或调节模和减除，强壁用原书解析结果校验"
      ],
      "baseline": "固定截断的谱或积分求积。",
      "difficulty": "必须正确分离不可观测壁自能与有限壁间力，不能只抄−π²/(1440a³)。",
      "independence": "边界真空相互作用，区别现有ED腔波导的经典传播及有限温统计题。",
      "implementation_gate": "有限强度公式须由匹配条件独立推导，不归称原书已完成。"
    },
    {
      "id": "qft-12",
      "title": "Gross–Neveu 行列式、质量隙与真空选择",
      "source": "G",
      "problems": [
        "26"
      ],
      "pages": [
        {
          "pdf": [
            282,
            285
          ],
          "printed": [
            111,
            114
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "引入辅助场、积分费米子并重整化有效势，得到非解析质量尺度和leading large-N真空。",
      "task_design": "从带明确减除约定的行列式输入恢复质量隙与全局真空，比较两种重整化约定，跟踪小显式源下分支及曲率。",
      "public_materials": "1+1维作用量、large-N保持量、两种减除条件、积分起点及源项。",
      "deliverables": [
        "全部驻点及稳定性",
        "质量隙、真空能和曲率",
        "方案转换下的不变量",
        "源变形的物理解分支"
      ],
      "verification": [
        "高精度fermion determinant积分与减除",
        "独立gap方程和势能比较"
      ],
      "baseline": "直接粗网格有效势和局部极小值搜索。",
      "difficulty": "非微扰指数尺度、近原点数值消减及全局真空选择；有限N不能误称精确。",
      "independence": "区别qft-06逐图Goldstone抵消、qft-20谱密度外推和SP的多项式平均场。",
      "implementation_gate": "源项gap方程另行推导，限制尺度范围以满足CPU资源。"
    },
    {
      "id": "qft-13",
      "title": "复杂 Langevin 的正确分支与相消误差诊断",
      "source": "G",
      "problems": [
        "29"
      ],
      "pages": [
        {
          "pdf": [
            294,
            300
          ],
          "printed": [
            123,
            129
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；高斯定点关键原页已视觉核对。",
      "original_work": "复四次作用量的矩递推、无穷远边界、截断动力学稳定性及高斯例子的强相消采样问题。",
      "task_design": "恢复中低阶复矩，诊断满足局部递推却属错误支的候选，选择截断深度与精度，分离采样误差、离散误差和边界偏差。",
      "public_materials": "复作用量参数、候选矩及固定模拟记录、有限预算反馈；不强制Langevin单一算法。",
      "deliverables": [
        "复矩",
        "候选正确性分类及可计算误差证据",
        "截断收敛记录",
        "相消与精度需求"
      ],
      "verification": [
        "高精度实轴复权积分",
        "独立后向递推/解析特殊函数与高斯矩校验"
      ],
      "baseline": "固定深度三对角矩递推。",
      "difficulty": "小递推残差并不保证物理解，正采样权重也不能消除观测量相消。",
      "independence": "考查符号问题和数值方案正确性，不是普通积分参数扫描。",
      "implementation_gate": "避开未说明的配分函数零点，不能要求用随机误差证明严格正确。"
    },
    {
      "id": "qft-14",
      "title": "Wong 方程中的色荷输运、路径序与规范协变",
      "source": "G",
      "problems": [
        "37"
      ],
      "pages": [
        {
          "pdf": [
            322,
            325
          ],
          "printed": [
            151,
            154
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "由非阿贝尔Lorentz力和电流协变守恒推出色荷的Wong演化，色荷随背景发生非交换旋转。",
      "task_design": "在固定高能轨迹上输运SU(2)/SU(3)色荷，处理分段非对易背景，比较路径顺序并验证时变规范变换后的终点协变性及物理力。",
      "public_materials": "生成元归一化、固定轨迹、背景场及规范变换、初始色荷和查询时刻。",
      "deliverables": [
        "Wilson输运与终点色荷",
        "不变量和守恒残差",
        "规范变换后的物理力",
        "顺序互换的效应"
      ],
      "verification": [
        "参考用Wong矩阵ODE",
        "真值用独立高精度分段矩阵指数，连续段另作收敛"
      ],
      "baseline": "固定步长保持Hermiticity的颜色演化。",
      "difficulty": "路径序、色荷共轭变换和规范不变量须共同正确，不能将颜色当常数。",
      "independence": "颜色沿路径的输运不同于空间拓扑qft-17和有限温环qft-22。",
      "implementation_gate": "固定轨迹属于eikonal受控近似，不把轨迹忽略反作用说成完整耦合解。"
    },
    {
      "id": "qft-15",
      "title": "大 N Yang–Mills 图的颜色拓扑与平面近似",
      "source": "G",
      "problems": [
        "42"
      ],
      "pages": [
        {
          "pdf": [
            342,
            346
          ],
          "printed": [
            171,
            175
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "主代理已完整核读题面与相关解答。",
      "original_work": "双线图与Fierz恒等式给颜色幂次；固定λ=g²N时G∼λ^(L−1)N^(V−E+F)，闭定向连通真空图χ=2−2h。",
      "task_design": "对公开旋转系统表示的规范图，解析颜色收缩、枚举允许双线取向并识别抵消，比较准确SU(N)色因子与大N首项，判断平面截断在给定N下的误差。",
      "public_materials": "少量三/四胶子连通1PI图、半边配对和顶点循环顺序、Fierz规则、规范固定后的颜色约定及目标误差。",
      "deliverables": [
        "每个颜色项的面数/亏格",
        "准确颜色多项式",
        "完整图首项及抵消证书",
        "平面截断误差与适用N"
      ],
      "verification": [
        "置换循环计算ribbon faces和独立符号Fierz收缩",
        "若干小N显式SU(N)生成元收缩核验多项式"
      ],
      "baseline": "leading-color双线计数，不保留次领先SU(N)项。",
      "difficulty": "同一抽象图可有不同ribbon嵌入，图首项可能抵消，不能对给定V/E/F套Euler公式就算完成。",
      "independence": "规范图颜色组合与受控large-N误差，不重复qft-16实辐射或qft-21格点手征拓扑。",
      "implementation_gate": "需把ribbon项和完整规范图分开，孤立退化零色因子按精确零处理；不合物理的任意ribbon图不伪称Yang–Mills图。"
    },
    {
      "id": "qft-16",
      "title": "QCD 天线辐射的色守恒、角序与模型辨析",
      "source": "G",
      "problems": [
        "43"
      ],
      "pages": [
        {
          "pdf": [
            346,
            354
          ],
          "printed": [
            175,
            183
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "推导单态qq̄软流和干涉，正确角平均下出现角序；八重态对必须包括其他有色外线才能满足色荷守恒。",
      "task_design": "恢复规范完整qq̄和qq̄g事件的软角分布及有限角窗辐射；诊断缺外线和不相干模型，按公开分离度指标选择最有鉴别力的角窗。",
      "public_materials": "自洽硬事件、色张量、软能区间、共线角截断和可选探测窗。",
      "deliverables": [
        "角分布及接受窗积分",
        "完整色流与Ward残差",
        "候选模型偏差",
        "最优鉴别窗与效应量"
      ],
      "verification": [
        "显式颜色矩阵和物理极化求和",
        "独立偶极表达式和高精度角积分"
      ],
      "baseline": "保持规范完整但使用leading-color天线近似。",
      "difficulty": "独立辐射直觉会遗漏干涉与负的次领先偶极项；角序不是总辐射逐点硬零。",
      "independence": "非阿贝尔真空颜色相干，不重复qft-24介质多碰撞或qft-10实虚抵消。",
      "implementation_gate": "公布截断和鉴别指标，确保不把非守恒八重态两线模型当合法真值。"
    },
    {
      "id": "qft-17",
      "title": "Yang–Mills 纯规范绕数与瞬子拓扑荷",
      "source": "G",
      "problems": [
        "49"
      ],
      "pages": [
        {
          "pdf": [
            368,
            370
          ],
          "printed": [
            197,
            199
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "空间无穷远紧化为S³，纯规范以π3(SU(N))分类，四维拓扑荷为初末Cartan–Maurer绕数之差。",
      "task_design": "对有解析边界的SU(2)映射与指定四维场，重建绕数、拓扑荷及边界差；检查规范变换、取向和光滑变形，拒绝不满足边界的伪瞬子。",
      "public_materials": "场构型及径向profile、ε/迹归一化、有限边界误差界；若用BPST则另附完整公开定义与来源。",
      "deliverables": [
        "绕数及收敛证书",
        "四维拓扑荷",
        "边界差残差",
        "自对偶残差及作用量（采用BPST扩展时）"
      ],
      "verification": [
        "解析角积分和独立高精度径向积分",
        "独立场强构造与四维/球对称积分、边界绕数互检"
      ],
      "baseline": "固定网格直接拓扑密度求积。",
      "difficulty": "边界、方向和规范归一化决定整数，粗积分四舍五入不能构成证书。",
      "independence": "四维场拓扑与真空跃迁，不是量子力学双阱，也不是Wong颜色旋转。",
      "implementation_gate": "BPST与作用量界属于补充内容须独立推导，允许只选择物理闭合的拓扑/边界核心。"
    },
    {
      "id": "qft-18",
      "title": "六胶子 NMHV 树振幅的递推与因子化",
      "source": "G",
      "problems": [
        "52"
      ],
      "pages": [
        {
          "pdf": [
            93,
            94
          ],
          "printed": [
            215,
            216
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；已核实不从PDF92起题。",
      "original_work": "3、4线的合法BCFW位移将---+++振幅归结为两个非零递推图，得到紧凑表达式。",
      "task_design": "构建可执行六点在壳递推器，在合法复动量上比较不同shift，并检测物理极点因子化、软极限及伪极点抵消。",
      "public_materials": "旋量/耦合约定、合法动量构造器、低点振幅与输出接口。",
      "deliverables": [
        "可执行求值器",
        "通道及内部螺旋贡献",
        "代表性复振幅",
        "物理极限及伪极点残差"
      ],
      "verification": [
        "BCFW独立位移递推",
        "独立Berends–Giele/显式颜色有序树递推及极点留数"
      ],
      "baseline": "直接颜色有序树递推的双精度实现。",
      "difficulty": "复在壳运动学、内部螺旋选择、归一化与不稳定伪极点必须一致。",
      "independence": "高多重度在壳因子化，不重复QFT-04双图散射；树振幅不等同qft-19一圈有理项。",
      "implementation_gate": "生成器严格保证动量守恒，误差按已剥离物理奇异因子定义；不得靠极端病态点人为制造失败。"
    },
    {
      "id": "qft-19",
      "title": "D 维幺正切割与全正螺旋一圈有理项",
      "source": "G",
      "problems": [
        "67"
      ],
      "pages": [
        {
          "pdf": [
            139,
            145
          ],
          "printed": [
            261,
            267
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "四维外线与D维环动量分解；μ⁴盒系数和零三角系数由cuts重构，O(ε)乘UV极点产生有限有理项。",
      "task_design": "从公开树子振幅/cut接口识别所需积分基，重建盒/三角系数和有限振幅，诊断只做四维cuts、过早置μ=0及遗漏ε项的方案。",
      "public_materials": "复标量圈、loop measure与颜色有序约定、D=4−2ε、cut查询和master积分定义。",
      "deliverables": [
        "master系数",
        "ε展开与有限残项",
        "多点复振幅",
        "错误重构的缺失信息"
      ],
      "verification": [
        "独立D维张量/维数位移积分",
        "重算cut和参考Feynman参数Laurent展开"
      ],
      "baseline": "只用严格四维cut的标准起点，作为方法能力下限；同时明示其已知信息缺失。",
      "difficulty": "四维cuts为零不代表振幅为零，有限项来自额外维与发散极点相乘。",
      "independence": "重点是有限rational remainder的遗漏信息，不是一般反项账本或树图递推。",
      "implementation_gate": "使用含质量或非零外动量的IR定义提取UV系数，不把无尺度积分的UV pole和完整积分混用。"
    },
    {
      "id": "qft-20",
      "title": "Dirac 低谱的 Banks–Casher 凝聚与极限次序",
      "source": "G",
      "problems": [
        "69"
      ],
      "pages": [
        {
          "pdf": [
            161,
            163
          ],
          "printed": [
            283,
            285
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "配对谱将凝聚化为m/(λ²+m²)积分，先取体积无穷再取零质量得到−πρ(0)。",
      "task_design": "对受控谱族分离拓扑零模和广延近零模，恢复有限质量凝聚，选择满足公开误差目标的缩放窗口并判断非零手征极限。",
      "public_materials": "多体积成对低谱、已知UV尾、误差模型和谱族生成约束；明确为受控模型而非真实QCD观测。",
      "deliverables": [
        "凝聚与零模分量",
        "有限体积修正",
        "缩放窗口及误差界",
        "两种极限次序与ρ(0)"
      ],
      "verification": [
        "高精度离散谱求和及解析尾",
        "独立连续谱积分和有限体积求和公式"
      ],
      "baseline": "固定质量窗口的朴素外推。",
      "difficulty": "有限体积、零模与热力学极限不交换，局部直方图不能独自证明凝聚。",
      "independence": "低谱统计和极限推断，不重复qft-12辅助场质量生成及qft-21动量零点拓扑。",
      "implementation_gate": "统一完整正负谱及每体积归一化；不假定所有背景无精确零模。"
    },
    {
      "id": "qft-21",
      "title": "格点费米子零点、手征指数与物种倍增",
      "source": "G",
      "problems": [
        "70"
      ],
      "pages": [
        {
          "pdf": [
            163,
            168
          ],
          "printed": [
            285,
            290
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "周期动量环面上的连续局域核零点携带手征指数，总指数由χ(T⁴)=0限制。",
      "task_design": "对可证完备的Fourier动量核族找全Brillouin区零点，判断Jacobians、手征与临界生成/湮灭，识别漏掉doublers或放弃定理假设的方案。",
      "public_materials": "核的有限Fourier表达、周期坐标、参数区间、定理假设和允许的退化情形。",
      "deliverables": [
        "周期去重零点集",
        "Jacobian和局部指数",
        "简并点与物种数",
        "全局指数及假设诊断"
      ],
      "verification": [
        "半角有理化后的完备实根隔离与边界检查",
        "独立解析枚举/同伦和局部映射度"
      ],
      "baseline": "多初值找根加周期去重。",
      "difficulty": "找全所有零点及精确识别临界退化比找几个根困难，必须服从全局拓扑约束。",
      "independence": "动量空间Weyl零点的手征障碍，不是qft-17空间场绕数或qft-20凝聚密度。",
      "implementation_gate": "选择根可证明完备的核，不笼统声称所有格点手征实现均不可能。"
    },
    {
      "id": "qft-22",
      "title": "中心对称、Polyakov 环与有限体积扇区混合",
      "source": "G",
      "problems": [
        "72"
      ],
      "pages": [
        {
          "pdf": [
            171,
            175
          ],
          "printed": [
            293,
            297
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "有限温边界允许中心扭曲，Polyakov环按中心变换；重色源自由能与物质N-ality决定序参量解释及显式破缺。",
      "task_design": "在受控非对易时间链与精确定义中心有效系综中，重建holonomy、相关函数和残余中心，区分对称分布、扇区混合的有序分布与显式破缺。",
      "public_materials": "SU(N)时间连接、有效系综权重、体积序列、N-ality与可判定物相规则；不伪称真实QCD相变数据。",
      "deliverables": [
        "有序holonomy和变换规律",
        "均值、模平方及远距相关",
        "残余中心集合",
        "有限体积与热力学判断"
      ],
      "verification": [
        "高精度有序乘积与有限系综穷举",
        "独立中心字符求和和转移矩阵关联计算"
      ],
      "baseline": "单点Polyakov环均值的朴素分类，并提供其有限体积局限。",
      "difficulty": "⟨L⟩=0可能来自扇区抵消，不足以判禁闭；路径顺序和全局对称性必须分清。",
      "independence": "全局中心与静态色源，不重复Wong开放路径输运或SP多项式极值。",
      "implementation_gate": "优先级B：落实转移矩阵模型与公开物相判据，不能退化为一次SU(N)矩阵相乘。"
    },
    {
      "id": "qft-23",
      "title": "热光子 HTL 的因果响应、屏蔽与集体模",
      "source": "G",
      "problems": [
        "73"
      ],
      "pages": [
        {
          "pdf": [
            176,
            179
          ],
          "printed": [
            298,
            301
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "线性Vlasov诱导流产生规范不变HTL有效作用和极化，单无质量Dirac物种mD²=e²T²/3。",
      "task_design": "从速度角响应计算retarded极化，跨空间样和时间样区域恢复Landau阻尼，求纵横集体模及留数，比较静态和均匀极限。",
      "public_materials": "弱耦合软外动量条件、分布与简并度、retarded处方、守恒源和查询尺度。",
      "deliverables": [
        "复极化分量与Ward残差",
        "屏蔽质量",
        "纵横色散根及留数",
        "非交换极限和源响应"
      ],
      "verification": [
        "解析因果复对数与隐函数根",
        "独立主值/δ角积分和时域Vlasov响应"
      ],
      "baseline": "有限角网格速度求积和固定宽度η。",
      "difficulty": "真实热介质的解析处方、光锥极限、Landau阻尼和色散根不能用实对数一律代替。",
      "independence": "零温QFT-01与经典ED题没有热占据硬环；本题无碰撞，区别qft-24。",
      "implementation_gate": "限制至各向同性平衡模型，明确k=0解析极限和离光锥距离。"
    },
    {
      "id": "qft-24",
      "title": "LPM 多次散射重求和与辐射近似选择",
      "source": "G",
      "problems": [
        "75"
      ],
      "pages": [
        {
          "pdf": [
            183,
            190
          ],
          "printed": [
            305,
            312
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键扩散页已视觉核对。",
      "original_work": "形成时间内多次软散射同阶，差分碰撞核需重求和；leading-log扩散解仅在受控层次有效。",
      "task_design": "求旋转对称m=1角谐波的完整横动量响应，比较单碰撞和扩散近似，按公开误差目标选择适用区并恢复软频率标度。",
      "public_materials": "无量纲完整碰撞核、边界/尾部、质量与Debye比、光子能量网格和率归一化。",
      "deliverables": [
        "发射函数及独立残差",
        "Bethe–Heitler抑制比",
        "两种近似误差与适用域",
        "小频率指数"
      ],
      "verification": [
        "保持红外差分抵消的动量空间Nyström/有限体积",
        "独立impact-parameter径向复边值问题"
      ],
      "baseline": "单碰撞Bethe–Heitler起点，另列leading-log近似为对照。",
      "difficulty": "非局域核、红外抵消、复响应和形成时间干涉须自洽；扩散近似不能冒充完整真值。",
      "independence": "介质碰撞相干重求和，区别无碰撞HTL和真空天线。",
      "implementation_gate": "优先级C：从正定差分算子重推扩散符号，双路线收敛后量测CPU/内存，不先承诺既定耗时。"
    },
    {
      "id": "qft-25",
      "title": "标量强场产对的 Bogoliubov 谱与粒子数统计",
      "source": "G",
      "problems": [
        "80"
      ],
      "pages": [
        {
          "pdf": [
            209,
            217
          ],
          "printed": [
            331,
            339
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "标量QED中正负频模混合满足|α|²−|β|²=1，压缩真空的模产对数服从几何统计，logP0=−Σlog(1+n)。",
      "task_design": "求单/双平滑电场脉冲的模式演化和动量谱，判断非相干相加的失效；从同一谱构建有限盒产对均值、方差、真空存活率和异号配对关联。",
      "public_materials": "标量KG方程、脉冲profile与渐近常势、canonical/kinetic动量约定、有限盒模集和误差尺度。",
      "deliverables": [
        "occupation谱与Wronskian残差",
        "双脉冲干涉比",
        "log真空存活率",
        "均值/方差及配对协方差",
        "规范平移后kinetic谱一致性"
      ],
      "verification": [
        "高精度二阶KG复ODE与渐近投影",
        "独立一阶Bogoliubov/quantum kinetic演化，单脉冲解析结果再校验"
      ],
      "baseline": "绝热近似或局域常场近似，并明确适用层次。",
      "difficulty": "渐近频率、相干相位和玻色统计共同决定结果，不能套费米子归一化或Poisson统计。",
      "independence": "非微扰外场真空到多粒子映射，不重复二维Schwinger模型质量生成；简单单频一阶产对不另计。",
      "implementation_gate": "统计量从数算符重推，有限时间窗与极小谱尾用绝对容差，不按规范相关裸相位唯一判分。"
    }
  ],
  "excluded_or_reserve": [
    {
      "source": "R",
      "problem": "11.14",
      "reason": "六维φ³为强后备，但与11.12局域UV减除能力重合；优先保留格点倍增等不同机制。"
    },
    {
      "source": "R",
      "problem": "11.6",
      "reason": "与既有真空极化阈值和衰变相空间交集大。"
    },
    {
      "source": "R",
      "problem": "4.33",
      "reason": "相对论单粒子势阱，偏量子力学且与既有QM谱题相近。"
    },
    {
      "source": "R",
      "problem": "5.18",
      "reason": "原样为标准Noether代数推导，不足以独立形成高难研究任务。"
    },
    {
      "source": "R",
      "problem": "10.10",
      "reason": "单频一阶产对较简单，保留更完整的G80，不双计。"
    },
    {
      "source": "G",
      "problem": "48",
      "reason": "量子力学双阱瞬子可能与原QM计划重复，采用Yang–Mills瞬子。"
    },
    {
      "source": "G",
      "problem": "68",
      "reason": "不以四点换五点增加独立题数，与G67同机制。"
    },
    {
      "source": "G",
      "problem": "74",
      "reason": "不以QED换QCD重复增加HTL题数。"
    },
    {
      "source": "G",
      "problem": "82/83",
      "reason": "G82的Born平均传播子衰减本身不证明局域化；真实输运扩展需额外材料，不作为本轮20题。"
    }
  ]
}

exit_code=0
```

schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/qft-04"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 1200.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "no-network"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0

# QFT-04：康普顿散射的双图干涉与运动探测接受度

## 物理问题与约定

用户提供的《量子场论试题详解》PDF 第 83--85 页（书内 75--77 页）给出康普顿散射的两个树图及 QED 动量空间 Feynman 规则。请把这两个图相干相加，建立精确的电子反冲计算，再求运动电子实验中探测器角窗、能窗筛选后的光子能谱。只使用 Thomson 低能近似，或将两图的概率不相干相加，均不足以覆盖本题。

取 \(m_e=\hbar=c=1\)、\(g_{\mu\nu}=\operatorname{diag}(1,-1,-1,-1)\)，\(r_e^2=\alpha^2/m_e^2\)。所有截面均输出 \(\sigma/r_e^2\)，能量以电子质量为单位，角度为弧度。输入 `x` 是**初始电子静止系**的入射光子能量。该系中

\[
p=(1,0,0,0),\quad k=(x,0,0,x),\quad
k'=(r,r\sqrt{1-c^2},0,rc),\quad c=\cos\theta,
\quad p'=p+k-k',
\]

其中 \(r\) 由末态电子在壳条件 \(p'^2=1\) 确定。输入 `beta_fraction=[a,b]` 精确表示 \(\beta=a/b\)：从初始电子静止系到实验室系沿 \(+z\) 做速度 \(\beta\) 的 Lorentz boost，\(E_{\rm lab}=\gamma(E+\beta p_z)\)。因此负的 \(\beta\) 对应逆向运动电子。

采用实线偏振基

\[
\epsilon_1=(0,1,0,0),\quad\epsilon_2=(0,0,1,0),\qquad
\epsilon'_1=(0,c,0,-\sqrt{1-c^2}),\quad\epsilon'_2=(0,0,1,0).
\]

旋量归一化为 \(\bar u_s(p)u_s(p)=2\)，对初态电子自旋及入射光子偏振平均，对末态求和。省略对概率无影响的共同相位，定义两个无量纲振幅 \(a_s=\mathcal M_s/e^2\)、\(a_u=\mathcal M_u/e^2\)：

\[
a_s=\bar u(p')\slashed\epsilon'^{*}
\frac{\slashed p+\slashed k+1}{2p\cdot k}
\slashed\epsilon\,u(p),\qquad
a_u=\bar u(p')\slashed\epsilon
\frac{\slashed p-\slashed k'+1}{-2p\cdot k'}
\slashed\epsilon'^{*}u(p).
\]

\(\slashed v=\gamma^0v^0-\sum_{i=1}^3\gamma^iv^i\)。定义 \(S=\overline{|a_s|^2}\)、\(U=\overline{|a_u|^2}\)、\(I=2\operatorname{Re}\overline{a_sa_u^*}\) 及 \(T=S+U+I\)。它们均包含上述初态平均。单图贡献按固定偏振约定比较，不能将单图当作独立的规范不变可观测量。精确微分截面为

\[
\frac1{r_e^2}\frac{d\sigma}{d\Omega}
=\frac14\left(\frac r x\right)^2T.
\]

## 需要完成的工作

1. 对 `model.json` 中的每个 `probes` 项，计算 `s_squared=S`、`u_squared=U`、`interference=I`、`total=T`。再同时把每个入射偏振变为 \(\epsilon_i+\eta k/x\)，每个出射偏振变为 \(\epsilon'_j+\zeta k'/r\)，其中 \(\eta,\zeta\) 来自公开输入，计算总振幅平方 `gauge_shifted_total`。总结果应满足 Ward 一致性，单图一般会变化。
2. 对每个 `cases` 项，积分求完整静止系总截面 `sigma`。`lab_theta_window=[theta_min,theta_max]`、`lab_energy_window=[E_min,E_max]` 同时作用于 **boost 后的出射光子**；边界均包含在接受区内。求满足两个窗口的静止系 \(c\) 区间 `accepted_cos_interval=[c_min,c_max]`，无正测度接受区时填 `null`。
3. 在接受区内求截面 `accepted_sigma`、`acceptance=accepted_sigma/sigma`、条件实验室系光子能量均值 `mean_energy`，以及条件能谱的 10%、50%、90% 分位数 `energy_quantiles=[E10,E50,E90]`，按**能量升序**给出。分位数定义为下分位数 \(\inf\{E:F(E)\ge p\}\)；若能量在整个接受区恒定，三个分位数均等于该常量。空接受区时 `accepted_sigma=0`、`acceptance=0`，均值、分位数和区间均为 `null`；`sigma` 仍为全角域总截面。

这里 `accepted_sigma` 是电子静止系散射截面对**实验室探测窗口所选事件**的积分；不额外乘实验室束流的相对流因子。任务中电子静止系的方位角全接受，故对方位角积分为 \(2\pi\)。输入刻意包含低能、高能前向峰、逆向 boost、能量随 \(c\) 反向排序、恒能量以及无事件工况，须以精确运动学处理。

## 材料、产物和开发反馈

公开 `/app/data/model.json` 提供全部输入及评分权重，`physics.py` 提供实验室系运动学与格式检查接口。Python、NumPy、SciPy、mpmath 已固定版本安装；无需网络或 GPU。

在 `/app/output/answer.json` 写 UTF-8 JSON：

```json
{
  "cases":[{"id":"kn-01","sigma":1.0,"accepted_sigma":0.5,"acceptance":0.5,"accepted_cos_interval":[-0.5,0.5],"mean_energy":0.4,"energy_quantiles":[0.3,0.4,0.5]}],
  "probes":[{"id":"amp-01","s_squared":1.0,"u_squared":1.0,"interference":-0.5,"total":1.5,"gauge_shifted_total":1.5}],
  "method":"brief method description"
}
```

示例数字仅演示 schema；两数组分别恰好覆盖全部公开 ID 一次，顺序不限。除规定可为 `null` 的字段外，所有数值均须为有限实数，不能用布尔值、NaN 或 Infinity。截面不能为负，`sigma>0`，接受率位于 \([0,1]\)，非空接受区满足 \(-1\le c_{min}<c_{max}\le1\)。

`python3 /app/data/feedback.py /app/output/answer.json` 检查格式并显示接受率归一化残差，不能代替最终物理验证。评分器使用隔离的 70 位独立真值：截面部分由解析 Klein--Nishina 原函数和独立积分互查，探针由显式旋量逐态求和得到，与参考解的 Dirac 矩阵迹路线分开。

## 评分

对于非空条件量，标量误差为 \(\min(1,|y-\hat y|/\max(10^{-6},|\hat y|))\)。三个能量分位数取此误差平均；区间端点误差为 \(\tfrac12\sum_{j=1}^2\min(1,|c_j-\hat c_j|/2)\)。两个字段都为 `null` 时该部分误差 0，仅一个为 `null` 时误差 1。每个事件工况中，总截面、接受截面、接受率、条件均值、分位数、接受区误差的权重分别是 15%、25%、10%、15%、20%、15%。

每个振幅探针的五个字段分别计算 \(\min(1,|y-\hat y|/\max(1,|\hat y|))\) 并平均。事件工况误差平均占 80%，振幅探针误差平均占 20%；原始指标为其 100 倍，单位百分点，越低越好。`metric.json` 公开实测简单基线、参考端点与 \(10^{-6}\) 百分点容差，课程原版统一函数将原始指标换成质量分。

Agent 为 4 CPU、4 GiB、0 GPU，限时 1200 秒；verifier 120 秒、独立环境、无网络。只需提交上述 JSON，其他文件不参与评分。


exit_code=0
```

### 2026-11-16T21:57:07.571927+08:00

```bash
python3 -c 'import json; from pathlib import Path; d=json.load(open("planning/qft-expansion-20-selection.json")); print(json.dumps([x for x in d["tasks"] if 13<=int(x["id"][-2:])<=19],ensure_ascii=False,indent=2)); print(Path("tasks/qft-04/tests/test.sh").read_text()); print(Path("tools/course_quality_score.py").read_text())'
```

```text

### 2026-11-16T21:57:07.571955+08:00

```bash
python3 -c 'from pathlib import Path; print(Path("tasks/qft-04/tests/grade.py").read_text() if Path("tasks/qft-04/tests/grade.py").exists() else list(Path("tasks/qft-04/tests").iterdir())); print(Path("tasks/qft-04/environment/Dockerfile").read_text()); print(Path("tools/run_qft04_checks.py").read_text())'
```

```text
[PosixPath('tasks/qft-04/tests/development_cases.py'), PosixPath('tasks/qft-04/tests/quality_score.py'), PosixPath('tasks/qft-04/tests/private'), PosixPath('tasks/qft-04/tests/metric.json'), PosixPath('tasks/qft-04/tests/test.sh'), PosixPath('tasks/qft-04/tests/score.py')]
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2

COPY requirements.txt /tmp/requirements.txt
RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
 && useradd --uid 1000 --create-home student \
 && mkdir -p /app/data /app/output \
 && chown -R student:student /app

COPY public/ /app/data/
WORKDIR /app
USER student

"""Local Linux calibration and physical regression checks for qft-04."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qft-04';DATA=TASK/'environment/public';TESTS=TASK/'tests'
sys.path.insert(0,str(TESTS))


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--calibrate',action='store_true');args=parser.parse_args()
    scorer=load('qft04_score',TESTS/'score.py');quality=load('qft04_quality',TESTS/'quality_score.py')
    answers={};cases={};runtime={}
    with tempfile.TemporaryDirectory(prefix='qft04-check-') as directory:
        temp=Path(directory)
        for name,script in (('baseline','baseline.py'),('reference','solve.py')):
            output=temp/f'{name}.json';started=time.perf_counter()
            subprocess.run([sys.executable,str(TASK/'solution'/script),'--data-root',str(DATA),'--output',str(output)],check=True,capture_output=True,text=True)
            runtime[f'{name}_seconds']=time.perf_counter()-started;answers[name]=json.loads(output.read_text())
        answers.update(load('qft04_cases',TESTS/'development_cases.py').make_cases(answers['reference']))
        answers['independent_truth']=json.loads((TESTS/'private/truth.json').read_text())
        for name,answer in answers.items():
            raw,detail=scorer.evaluate(answer,DATA,TESTS/'private');cases[name]={'raw_metric':raw,**detail,'status':'invalid' if raw is None else 'completed'}
        measured={'kind':'continuous','metric_name':'康普顿相干振幅与实验室接受能谱误差','unit':'百分点','direction':'minimize','baseline':cases['baseline']['raw_metric'],'reference':cases['reference']['raw_metric'],'tolerance':1e-6}
        metric=measured if args.calibrate else json.loads((TESTS/'metric.json').read_text());quality.validate_metric(metric)
        for item in cases.values():item['score']=quality.quality_score(metric,item['raw_metric'],item['status'])
        testroot=temp/'tests';testroot.mkdir();(testroot/'metric.json').write_text(json.dumps(metric));entries={}
        for name in ('reference','empty','missing_empty_field','huge_integer'):
            if name not in ('reference','empty'):(temp/f'{name}.json').write_text(json.dumps(answers[name]))
            logs=temp/f'logs-{name}'
            env=dict(os.environ,TASK_DATA_ROOT=str(DATA),TASK_PRIVATE_ROOT=str(TESTS/'private'),TASK_TESTS_ROOT=str(testroot),TASK_ANSWER_PATH=str(temp/f'{name}.json'),VERIFIER_LOG_ROOT=str(logs))
            subprocess.run(['bash',str(TESTS/'test.sh')],env=env,check=True,capture_output=True,text=True)
            entries[name]=json.loads((logs/'metrics.json').read_text())
        feedback=json.loads(subprocess.run([sys.executable,str(DATA/'feedback.py'),str(temp/'reference.json')],check=True,capture_output=True,text=True).stdout)
    checks={
        'reference_matches_independent_truth':measured['reference']<metric['tolerance'],
        'reference_improves_baseline':measured['baseline']-measured['reference']>metric['tolerance'],
        'registered_endpoints_match':all(abs(measured[k]-metric[k])<metric['tolerance'] for k in ('baseline','reference')),
        'baseline_zero_reference_one':cases['baseline']['score']==0 and cases['reference']['score']==1,
        'equivalent_order_same':cases['equivalent']['raw_metric']==cases['reference']['raw_metric'],
        'independent_truth_full_credit':cases['independent_truth']['score']==1,
        'wrong_physics_penalized':cases['wrong']['raw_metric']>measured['reference']+1,
        'missing_interference_penalized':cases['no_interference']['raw_metric']>measured['reference']+.1,
        'wrong_boost_penalized':cases['no_boost']['raw_metric']>measured['reference']+.1,
        'wrong_energy_quantiles_penalized':cases['wrong_quantile_order']['raw_metric']>measured['reference']+.01,
        'false_nonempty_penalized':cases['fake_nonempty']['raw_metric']>measured['reference']+.1,
        'false_empty_constant_spectrum_penalized':cases['false_empty']['raw_metric']>measured['reference']+.1,
        'invalid_answers_rejected':all(cases[n]['status']=='invalid' and cases[n]['score']==0 for n in ('duplicate','boolean','nonfinite','malformed','missing_empty_field','huge_integer')),
        'constant_energy_quantiles_correct':max(answers['reference']['cases'][4]['energy_quantiles'])-min(answers['reference']['cases'][4]['energy_quantiles'])==0,
        'empty_window_conditions_undefined':answers['reference']['cases'][5]['mean_energy'] is None and answers['reference']['cases'][5]['energy_quantiles'] is None,
        'ward_identity_total_invariant':all(abs(item['total']-item['gauge_shifted_total'])<1e-9 for item in answers['reference']['probes']),
        'verifier_reference_one_empty_zero':entries['reference']['score']==1 and entries['empty']['score']==0 and entries['empty']['status']=='invalid',
        'verifier_malformed_boundary_cases_zero':all(entries[n]['score']==0 and entries[n]['status']=='invalid' for n in ('missing_empty_field','huge_integer')),
        'public_feedback_works':feedback['valid'] and len(feedback['cases'])==7,
        'course_quality_score_unchanged':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
    }
    report={'metric':metric,'cases':cases,'runtime':{'platform':platform.platform(),'python':platform.python_version(),**runtime},'checks':checks,'verifier_entries':entries}
    print(json.dumps({'metric':metric,'scores':{k:{f:v[f] for f in ('raw_metric','score','status')} for k,v in cases.items()},'runtime':report['runtime'],'checks':checks},ensure_ascii=False,indent=2))
    if not all(checks.values()):raise SystemExit('qft-04 checks failed')
    if args.calibrate:
        for path in (DATA/'metric.json',TESTS/'metric.json'):path.write_text(json.dumps(metric,ensure_ascii=False,indent=2)+'\n')
    elif json.loads((DATA/'metric.json').read_text())!=metric:raise SystemExit('metric copies differ')
    (ROOT/'checks/qft-04-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    saved=ROOT/'runs/qft-04/development-answers';saved.mkdir(parents=True,exist_ok=True)
    for name,answer in answers.items():(saved/f'{name}.json').write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()

[
  {
    "id": "qft-13",
    "title": "复杂 Langevin 的正确分支与相消误差诊断",
    "source": "G",
    "problems": [
      "29"
    ],
    "pages": [
      {
        "pdf": [
          294,
          300
        ],
        "printed": [
          123,
          129
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读；高斯定点关键原页已视觉核对。",
    "original_work": "复四次作用量的矩递推、无穷远边界、截断动力学稳定性及高斯例子的强相消采样问题。",
    "task_design": "恢复中低阶复矩，诊断满足局部递推却属错误支的候选，选择截断深度与精度，分离采样误差、离散误差和边界偏差。",
    "public_materials": "复作用量参数、候选矩及固定模拟记录、有限预算反馈；不强制Langevin单一算法。",
    "deliverables": [
      "复矩",
      "候选正确性分类及可计算误差证据",
      "截断收敛记录",
      "相消与精度需求"
    ],
    "verification": [
      "高精度实轴复权积分",
      "独立后向递推/解析特殊函数与高斯矩校验"
    ],
    "baseline": "固定深度三对角矩递推。",
    "difficulty": "小递推残差并不保证物理解，正采样权重也不能消除观测量相消。",
    "independence": "考查符号问题和数值方案正确性，不是普通积分参数扫描。",
    "implementation_gate": "避开未说明的配分函数零点，不能要求用随机误差证明严格正确。"
  },
  {
    "id": "qft-14",
    "title": "Wong 方程中的色荷输运、路径序与规范协变",
    "source": "G",
    "problems": [
      "37"
    ],
    "pages": [
      {
        "pdf": [
          322,
          325
        ],
        "printed": [
          151,
          154
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读。",
    "original_work": "由非阿贝尔Lorentz力和电流协变守恒推出色荷的Wong演化，色荷随背景发生非交换旋转。",
    "task_design": "在固定高能轨迹上输运SU(2)/SU(3)色荷，处理分段非对易背景，比较路径顺序并验证时变规范变换后的终点协变性及物理力。",
    "public_materials": "生成元归一化、固定轨迹、背景场及规范变换、初始色荷和查询时刻。",
    "deliverables": [
      "Wilson输运与终点色荷",
      "不变量和守恒残差",
      "规范变换后的物理力",
      "顺序互换的效应"
    ],
    "verification": [
      "参考用Wong矩阵ODE",
      "真值用独立高精度分段矩阵指数，连续段另作收敛"
    ],
    "baseline": "固定步长保持Hermiticity的颜色演化。",
    "difficulty": "路径序、色荷共轭变换和规范不变量须共同正确，不能将颜色当常数。",
    "independence": "颜色沿路径的输运不同于空间拓扑qft-17和有限温环qft-22。",
    "implementation_gate": "固定轨迹属于eikonal受控近似，不把轨迹忽略反作用说成完整耦合解。"
  },
  {
    "id": "qft-15",
    "title": "大 N Yang–Mills 图的颜色拓扑与平面近似",
    "source": "G",
    "problems": [

exit_code=0
```
      "42"
    ],
    "pages": [
      {
        "pdf": [
          342,
          346
        ],
        "printed": [
          171,
          175
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "主代理已完整核读题面与相关解答。",
    "original_work": "双线图与Fierz恒等式给颜色幂次；固定λ=g²N时G∼λ^(L−1)N^(V−E+F)，闭定向连通真空图χ=2−2h。",
    "task_design": "对公开旋转系统表示的规范图，解析颜色收缩、枚举允许双线取向并识别抵消，比较准确SU(N)色因子与大N首项，判断平面截断在给定N下的误差。",
    "public_materials": "少量三/四胶子连通1PI图、半边配对和顶点循环顺序、Fierz规则、规范固定后的颜色约定及目标误差。",
    "deliverables": [
      "每个颜色项的面数/亏格",
      "准确颜色多项式",
      "完整图首项及抵消证书",
      "平面截断误差与适用N"
    ],
    "verification": [
      "置换循环计算ribbon faces和独立符号Fierz收缩",
      "若干小N显式SU(N)生成元收缩核验多项式"
    ],
    "baseline": "leading-color双线计数，不保留次领先SU(N)项。",
    "difficulty": "同一抽象图可有不同ribbon嵌入，图首项可能抵消，不能对给定V/E/F套Euler公式就算完成。",
    "independence": "规范图颜色组合与受控large-N误差，不重复qft-16实辐射或qft-21格点手征拓扑。",
    "implementation_gate": "需把ribbon项和完整规范图分开，孤立退化零色因子按精确零处理；不合物理的任意ribbon图不伪称Yang–Mills图。"
  },
  {
    "id": "qft-16",
    "title": "QCD 天线辐射的色守恒、角序与模型辨析",
    "source": "G",
    "problems": [
      "43"
    ],
    "pages": [
      {
        "pdf": [
          346,
          354
        ],
        "printed": [
          175,
          183
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读。",
    "original_work": "推导单态qq̄软流和干涉，正确角平均下出现角序；八重态对必须包括其他有色外线才能满足色荷守恒。",
    "task_design": "恢复规范完整qq̄和qq̄g事件的软角分布及有限角窗辐射；诊断缺外线和不相干模型，按公开分离度指标选择最有鉴别力的角窗。",
    "public_materials": "自洽硬事件、色张量、软能区间、共线角截断和可选探测窗。",
    "deliverables": [
      "角分布及接受窗积分",
      "完整色流与Ward残差",
      "候选模型偏差",
      "最优鉴别窗与效应量"
    ],
    "verification": [
      "显式颜色矩阵和物理极化求和",
      "独立偶极表达式和高精度角积分"
    ],
    "baseline": "保持规范完整但使用leading-color天线近似。",
    "difficulty": "独立辐射直觉会遗漏干涉与负的次领先偶极项；角序不是总辐射逐点硬零。",
    "independence": "非阿贝尔真空颜色相干，不重复qft-24介质多碰撞或qft-10实虚抵消。",
    "implementation_gate": "公布截断和鉴别指标，确保不把非守恒八重态两线模型当合法真值。"
  },
  {
    "id": "qft-17",
    "title": "Yang–Mills 纯规范绕数与瞬子拓扑荷",
    "source": "G",
    "problems": [
      "49"
    ],
    "pages": [
      {
        "pdf": [
          368,
          370
        ],
        "printed": [
          197,
          199
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读。",
    "original_work": "空间无穷远紧化为S³，纯规范以π3(SU(N))分类，四维拓扑荷为初末Cartan–Maurer绕数之差。",
    "task_design": "对有解析边界的SU(2)映射与指定四维场，重建绕数、拓扑荷及边界差；检查规范变换、取向和光滑变形，拒绝不满足边界的伪瞬子。",
    "public_materials": "场构型及径向profile、ε/迹归一化、有限边界误差界；若用BPST则另附完整公开定义与来源。",
    "deliverables": [
      "绕数及收敛证书",
      "四维拓扑荷",
      "边界差残差",
      "自对偶残差及作用量（采用BPST扩展时）"
    ],
    "verification": [
      "解析角积分和独立高精度径向积分",
      "独立场强构造与四维/球对称积分、边界绕数互检"
    ],
    "baseline": "固定网格直接拓扑密度求积。",
    "difficulty": "边界、方向和规范归一化决定整数，粗积分四舍五入不能构成证书。",
    "independence": "四维场拓扑与真空跃迁，不是量子力学双阱，也不是Wong颜色旋转。",
    "implementation_gate": "BPST与作用量界属于补充内容须独立推导，允许只选择物理闭合的拓扑/边界核心。"
  },
  {
    "id": "qft-18",
    "title": "六胶子 NMHV 树振幅的递推与因子化",
    "source": "G",
    "problems": [
      "52"
    ],
    "pages": [
      {
        "pdf": [
          93,
          94
        ],
        "printed": [
          215,
          216
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读；已核实不从PDF92起题。",
    "original_work": "3、4线的合法BCFW位移将---+++振幅归结为两个非零递推图，得到紧凑表达式。",
    "task_design": "构建可执行六点在壳递推器，在合法复动量上比较不同shift，并检测物理极点因子化、软极限及伪极点抵消。",
    "public_materials": "旋量/耦合约定、合法动量构造器、低点振幅与输出接口。",
    "deliverables": [
      "可执行求值器",
      "通道及内部螺旋贡献",
      "代表性复振幅",
      "物理极限及伪极点残差"
    ],
    "verification": [
      "BCFW独立位移递推",
      "独立Berends–Giele/显式颜色有序树递推及极点留数"
    ],
    "baseline": "直接颜色有序树递推的双精度实现。",
    "difficulty": "复在壳运动学、内部螺旋选择、归一化与不稳定伪极点必须一致。",
    "independence": "高多重度在壳因子化，不重复QFT-04双图散射；树振幅不等同qft-19一圈有理项。",
    "implementation_gate": "生成器严格保证动量守恒，误差按已剥离物理奇异因子定义；不得靠极端病态点人为制造失败。"
  },
  {
    "id": "qft-19",
    "title": "D 维幺正切割与全正螺旋一圈有理项",
    "source": "G",
    "problems": [
      "67"
    ],
    "pages": [
      {
        "pdf": [
          139,
          145
        ],
        "printed": [
          261,
          267
        ],
        "role": "完整题面与解答"
      }
    ],
    "reading": "完整相关题段已核读。",
    "original_work": "四维外线与D维环动量分解；μ⁴盒系数和零三角系数由cuts重构，O(ε)乘UV极点产生有限有理项。",
    "task_design": "从公开树子振幅/cut接口识别所需积分基，重建盒/三角系数和有限振幅，诊断只做四维cuts、过早置μ=0及遗漏ε项的方案。",
    "public_materials": "复标量圈、loop measure与颜色有序约定、D=4−2ε、cut查询和master积分定义。",
    "deliverables": [
      "master系数",
      "ε展开与有限残项",
      "多点复振幅",
      "错误重构的缺失信息"
    ],
    "verification": [
      "独立D维张量/维数位移积分",
      "重算cut和参考Feynman参数Laurent展开"
    ],
    "baseline": "只用严格四维cut的标准起点，作为方法能力下限；同时明示其已知信息缺失。",
    "difficulty": "四维cuts为零不代表振幅为零，有限项来自额外维与发散极点相乘。",
    "independence": "重点是有限rational remainder的遗漏信息，不是一般反项账本或树图递推。",
    "implementation_gate": "使用含质量或非零外动量的IR定义提取UV系数，不把无尺度积分的UV pole和完整积分混用。"
  }
]
#!/bin/bash
set -euo pipefail
python3 "$(dirname -- "$0")/score.py"

"""课程统一质量分：简单基线0、专家参考1，逐次换算后取平均。"""
import math

VALID_FAILURES = {"invalid", "agent_error", "timeout"}


def finite_number(value, name):
    if type(value) not in (int, float):
        raise ValueError(f"{name}须为有限数值")
    try:
        result = float(value)
    except OverflowError as exc:
        raise ValueError(f"{name}须为有限数值") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name}须为有限数值")
    return result


def validate_metric(metric):
    if metric.get("kind") == "binary":
        baseline = finite_number(metric.get("baseline"), "baseline")
        reference = finite_number(metric.get("reference"), "reference")
        if baseline != 0 or reference != 1:
            raise ValueError("二元题须实测简单基线0、参考解1，否则不构成有效的参考提升")
        return
    if metric.get("kind") != "continuous":
        raise ValueError("kind须为binary或continuous")
    direction = metric.get("direction")
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction须为maximize或minimize")
    baseline = finite_number(metric.get("baseline"), "baseline")
    reference = finite_number(metric.get("reference"), "reference")
    tolerance = finite_number(metric.get("tolerance"), "tolerance")
    if tolerance < 0:
        raise ValueError("原始指标容差不能为负")
    improvement = reference - baseline if direction == "maximize" else baseline - reference
    if not math.isfinite(improvement) or improvement <= tolerance:
        raise ValueError("参考解相对基线的改善须超过原始指标容差；请先核查设置")


def quality_score(metric, raw_metric, status="completed"):
    validate_metric(metric)
    if status in VALID_FAILURES:
        return 0.0
    if status != "completed":
        raise ValueError("基础设施或评分器故障不能填0；请先处理并补跑")
    value = finite_number(raw_metric, "raw_metric")
    if metric["kind"] == "binary":
        if value not in {0.0, 1.0}:
            raise ValueError("二元任务的实测结果须为0或1")
        return value
    baseline = float(metric["baseline"])
    reference = float(metric["reference"])
    fraction = (value - baseline) / (reference - baseline)
    return max(0.0, min(1.0, fraction))


exit_code=0
```

### 2026-11-16T21:57:20.655791+08:00

```bash
cat tasks/qft-04/tests/score.py
```

```text

### 2026-11-16T21:57:20.655897+08:00

```bash
python3 tools/read_qft_source_pages.py gelis 294:300 322:325 342:354 368:370 93:94 139:145
```

```text
import json
import os
from pathlib import Path
import sys
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get('TASK_DATA_ROOT','/app/data'));private=Path(private_root or os.environ.get('TASK_PRIVATE_ROOT','/tests/private'))
    sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    model=load_model(data);parsed,reason=validate_answer(answer,model)
    if reason:return None,{'reason':reason}
    truth=json.loads((private/'truth.json').read_text());scoring=model['scoring'];floor=scoring['relative_floor'];details=[]
    def relative(actual,expected):return min(1,abs(actual-expected)/max(floor,abs(expected)))
    for expected in truth['cases']:
        actual=parsed['cases'][expected['id']]
        parts={name:relative(actual[name],expected[name]) for name in ('sigma','accepted_sigma','acceptance')}
        for name in ('mean_energy','energy_quantiles','accepted_cos_interval'):
            a,b=actual[name],expected[name]
            if a is None or b is None:parts[name]=float(a!=b)
            elif name=='accepted_cos_interval':parts[name]=sum(min(1,abs(x-y)/2) for x,y in zip(a,b))/2
            elif isinstance(b,list):parts[name]=sum(relative(x,y) for x,y in zip(a,b))/len(b)
            else:parts[name]=relative(a,b)
        error=sum(scoring['case_parts'][name]*value for name,value in parts.items());details.append({'id':expected['id'],'error':error,'parts':parts})
    probe_details=[]
    for expected in truth['probes']:
        actual=parsed['probes'][expected['id']]
        errors={name:min(1,abs(actual[name]-expected[name])/max(scoring['probe_floor'],abs(expected[name]))) for name in ('s_squared','u_squared','interference','total','gauge_shifted_total')}
        probe_details.append({'id':expected['id'],'error':sum(errors.values())/len(errors),'parts':errors})
    error=scoring['case_weight']*sum(x['error'] for x in details)/len(details)+scoring['probe_weight']*sum(x['error'] for x in probe_details)/len(probe_details)
    return 100*error,{'cases':details,'probes':probe_details}


def main():
    logs=Path(os.environ.get('VERIFIER_LOG_ROOT','/logs/verifier'));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get('TASK_TESTS_ROOT','/tests'));answer=Path(os.environ.get('TASK_ANSWER_PATH','/app/output/answer.json'));metric=json.loads((tests/'metric.json').read_text())
    try:payload=json.loads(answer.read_text())
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{'reason':'没有有效 JSON 产物'}
    else:raw,details=evaluate(payload)
    status='invalid' if raw is None else 'completed';score=quality_score(metric,raw,status)
    details.update(raw_metric=raw,score=score,status=status)
    (logs/'metrics.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n');(logs/'reward.txt').write_text(f'{score}\n')


if __name__=='__main__':main()

exit_code=0
```
usage: read_qft_source_pages.py [-h] {gelis,problem-book} spans
read_qft_source_pages.py: error: unrecognized arguments: 322:325 342:354 368:370 93:94 139:145

exit_code=2
```

### 2026-11-16T21:57:34.302834+08:00

```bash
python3 tools/read_qft_source_pages.py gelis 294:300,322:325,342:354,368:370,93:94,139:145
```

```text

===== PDF PAGE 294 =====
29 COMPLEX LANGEVIN EQUATION 123
propagator. By combining contributions of ordersη andη3 in twoϕ’s, we can construct the
following more elaborate example:
ττ
τ' p
k =
∫
dτ′ d4k(2π)4 G(τ,τ ′,p )G(τ′,τ ′,k )G (τ,τ ′, −p)
=
∫τ
0
dτ′ d4k(2π)4 e−(m2+p2)(τ−τ′) −e−(m2+p2)(τ+τ′)p2 +m2
× 1 −e−2(m2+k2)τ′
k2 +m2 e−(m2+p2)(τ−τ′)
=
τ→∞
1
2
1
(p2 +m2)2
∫ d4k
(2π)4
1
k2 +m2.
We again recover the expected perturbative contribution (ultraviolet divergence included).
Source: Damgaard, P. H. and H¨uffel, H. (1987), Phys Rep 152: 227.
29. Complex Langevin Equation This problem is a continuation of Problem 28. Its goal
is to explore within a toy model what happens when the action is complex-valued, leading to
a complex Langevin equation. We consider the “action” S(x) ≡ α2x2 + β4 x4, and write thefollowing Langevin equation:
∂τx =− S′(x)+ η, ⟨η(τ)⟩η = 0, ⟨η(τ)η(τ′)⟩η = 2δ(τ −τ′).
29.a Whenα,β are complex, why can’t the distribution ofx deﬁned from solutions of this
equation be proportional to exp(−S(x))?
29.b Show that the momentsCn ≡
⟨zn(τ)
n!
⟩
η (if they converge) satisfy in the limitτ →∞ the
same three-term recurrence relation,
Cn−2 = αnCn +βn(n +1)(n +2)Cn+2,
as the true moments
∫
dx xnn! exp(−S(x))/ ∫dx exp(−S(x)).
29.c Show that the momentsCn obtained from the complex Langevin equation coincide with
the true moments if we have limn→∞ Cn = 0.
29.d Ifβ ∈ R ∗+, ﬁnd a condition onα that guarantees the convergence of the momentsCn
(use results from Gibson, P. M. (1971),Proc Edinb Math Soc 17(4): 317).
29.e Show that the complex Langevin equation is equivalent to the following Fokker–Planck
equation for a distributionPτ(x,y ) over the complex plane:
∂τPτ(x,y )=
(
∂2x +∂xReS′(x+iy)+∂yImS′(x+iy))Pτ(x,y ).


===== PDF PAGE 295 =====
124 2 FUNCTIONAL METHODS
29.f For β = 0,α ≡ a +ib, show that the ﬁxed point of this Fokker–Planck equation is
Gaussian,
P∞(x,y ) ∝ exp
{
−a
(
x2 + 2ab xy +(1 + 2a2b )y2)}.
Although everything looks ﬁne in this case, what practical problem arises whenb ≫ a ?
29.a As we have seen in Problem 28, when α,β are positive real integers we can view
exp(−S(x)) as a probability distribution on the real axis, and generate an ensemble of x’s that
samples this distribution by solving the following Langevin equation:
∂τx =− S′(x)+ η, ⟨η(τ)⟩ = 0, ⟨η(τ)η(τ′)⟩ = 2δ(τ −τ′). (2.38)
Moreover, the probability distribution Pτ(x) of an ensemble of x’s that obey this Langevin
equation evolves according to a Fokker–Planck equation,
∂τPτ = ∂x
(
∂x +S′(x))Pτ,
that admits exp(−S(x)) as a unique ﬁxed point.
Consider now the case where the coefﬁcients α,β that deﬁne S(x) are complex. In this
case, the weight exp(−S(x)) in the integral is complex-valued and cannot be interpreted as a
probability distribution (moreover, in this case, the integrand has a strong oscillatory behavior
that prevents evaluation by Monte Carlo sampling).
On the other hand, when we solve the Langevin equation (2.38) with a complex action,
it leads to complex solutions even if the initial condition and the noise are real-valued. For
this reason, it is called a complex Langevin equation. Thus, the equilibrium distribution of an
ensemble ofz ≡ x +iy’s obeying this Langevin equation is a positive deﬁnite distribution on
the complex plane, i.e., deﬁnitely not the complex-valued weight exp(−S(x)) of the original
integral.
29.b From the solution of the complex Langevin equation, let us deﬁneτ-dependent moments
by averaging over the noise, as follows:
Cn(τ) ≡ Z−1
∫
[Dη] zn(τ)n! e−14 ∫η2, with Z ≡ ∫ [Dη]e−14 ∫η2.
From this representation, we obtain the derivative of the moments with respect toτ:


===== PDF PAGE 296 =====
29 COMPLEX LANGEVIN EQUATION 125
∂τCn(τ)= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!∂τz(τ) e−14 ∫ η2
= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!
(
−S′(z(τ)) +η(τ)) e−14 ∫ η2
= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!
(
−S′(z(τ)) −2 δδη(τ)) e−14 ∫ η2
=−
⟨xn−1(τ)
(n −1)! S′(x(τ))⟩η +2⟨xn−2(τ)(n −2)! δz(τ)δη(τ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 12
⟩
η
,
i.e.,
∂τCn(τ)= Cn−2 −αnCn −βn(n +1)(n +2)Cn+2. (2.39)
Consider now the true moments of this toy model,
Mn ≡
∫
dx e−S(x) xnn!∫
dx e−S(x) .
A simple integration by parts shows that
Mn−2 = αnMn +βn(n +1)(n +2)Mn+2.
Interestingly, the ﬁxed points of the equation (2.39) (deﬁned by requiring that∂τCn = 0) obey
exactly the same three-term recurrence relation.
This has led to the conjecture that the probability distributionPτ(x,y ) in the complex plane
(we denote byx andy the real and imaginary parts, respectively) followed by an ensemble of
solutions of the complex Langevin equation is such that
lim
τ→∞
∫
dxdy Pτ(x,y )f(x +iy)=?
∫
dx e−S(x) f(x). (2.40)
The remarkable aspect if this equality (if true) is that the left hand side has a positive weight
over C and the test functionf is evaluated at complex numbers, while on the right-hand side
the functionf is evaluated solely on the real axis but weighted with a complex-valued action.
This certainly requires at a minimum that the functionf(z) be analytic so that the values on
the real axis are related to those in the rest of the complex plane (but this limitation should
not be a surprise, since we arrived at this conjecture from considerations on the moments). If
this conjecture were valid (and generalizable from this toy model to a realistic quantum ﬁeld
theory), it would offer the prospect of turning a path integral that has a sign problem (e.g.,
a path integral in Minkowski spacetime) into one that has a positive deﬁnite weight over a
complexiﬁed ﬁeld space (and is thus approachable by Monte Carlo sampling).
The question of the validity of the conjecture (2.40) can in fact be divided into three
sub-questions:
1. If the moments Cn(τ) deﬁned from the complex Langevin equation do converge to a
ﬁxed point, does this ﬁxed point actually give the true momentsMn?


===== PDF PAGE 297 =====
126 2 FUNCTIONAL METHODS
−4
−3
−2
−1
0
1
2
3
4
5
0 500 1000 1500 2000 2500 3000 3500
ρn/2000, ϕn   (Cn,Mn = 10−ρn eiϕn )
n
α = 1+5i, β = 1
true moments
recur. w. C5000=0
Figure 2.9 Comparison of the true momentsMn (evaluated numerically) and the moments
Cn obtained by solving the recurrence with the constraintsC0 = 1,C5000 = 0. The moments
are parameterized as10−ρneiϕn ; the exponentρn (divided by2000, open squares and solid
line) and the phaseϕn (open circles and solid dots) are both shown in the plot.
2. Do they actually converge to a ﬁxed point?
3. In practice one has only a ﬁnite number of solutions of the complex Langevin equation,
which is equivalent to evaluating the left-hand side of (2.40) by Monte Carlo sampling.
Even though the distributionPτ(x,y ) is positive, are there situations where the integral
onx,y cannot be sampled efﬁciently?
29.c The recurrence relation satisﬁed both by the ﬁxed point of the Cn and by the true
moments Mn is not sufﬁcient to uniquely determine the moments, and therefore cannot
guarantee that the Cn and Mn are equal. Since this recurrence is linear and involves three
terms, the space of its solutions is a linear space of dimension two. The zeroth-order moment
is trivially ﬁxed at C0 = M0 = 1 in both cases, which reduces to one the dimension of the
space of solutions. One may check that the true momentsMn go to zero whenn →∞ , thanks
to the factorial included in their deﬁnition. Therefore, if we also had C∞ = 0, the recurrence
would determine a unique sequence of moments, and this sequence would coincide with the
true moments. This is illustrated in Figure 2.9 (for practical reasons related to the numerical
algorithm used to solve the recurrence, we have set C5000 = 0 instead of C∞ = 0), where
we see a perfect agreement (both in norm and in phase) between the true moments and those
obtained by solving the recurrence.
29.d Let us now discuss the convergence of the momentsCn whenτ → +∞. Since C0 = 1
is independent ofτ, and using the fact that the odd moments are zero, we can write the equation
of motion of the higher moments as follows:
∂τC = C∗ +BC,
where we denote


===== PDF PAGE 298 =====
29 COMPLEX LANGEVIN EQUATION 127
C ≡
⎛
⎜⎜⎜⎝
C2
C4
...
C2N
⎞
⎟⎟⎟⎠, C∗ ≡
⎛
⎜⎜⎜⎝
C0
0
...
0
⎞
⎟⎟⎟⎠, B ≡
⎛
⎜⎜⎜⎝
−2α −24β 0 ··· 00
1 −4α −120β ··· 00
... ... ... ... ...
00 0 ··· 1 −2Nα
⎞
⎟⎟⎟⎠.
(Here, we have truncated the recurrence by imposing that C2N+2 = 0. Alternatively, one could
view B as a matrix of inﬁnite size.) The matrix B is invertible, and the ﬁxed point of the
preceding equation is given by
C(∞)=− B−1C∗.
Whether the solution actually converges to this ﬁxed point is controlled by the sign of the real
part of the eigenvalues of the matrix B. A formal solution of the equation of motion of the
moments is
C(τ)= eτB
[
C(0)+
∫τ
0
dτ′ e−τ′B C∗] ,
where C(0) is the initial condition for the moments C2,4,6,.... For this solution to forget its
initial condition, we must have
lim
τ→+∞
eτB = 0,
which requires that all the eigenvalues of B have strictly negative real parts. (The matrix
B is non-Hermitian, and therefore not necessarily diagonalizable. However, the property
exp(τB) → 0 if all eigenvalues have negative real parts remains true, as can be seen by using
the Jordan form of the matrix.) Moreover, when this is the case, we also have
lim
τ→+∞
eτB
∫τ
0
dτ′ e−τ′B =− B−1,
which ensures that the solution converges to the expected ﬁxed point.
Whenβ ∈ R (in this case,β should be positive for the original integral to make sense), we
may use the following theorem (see Gibson, P. M. (1971),Proc Edinb Math Soc 17(4): 317):
given a complex tri-diagonal matrix
Ω ≡
⎛
⎜⎜⎜⎜⎜⎜⎜⎜⎝
b1 c1 0 ··· 00
a1 b2 c2 ··· 00
0a 2 b3 ··· 00
... ... ... ... ...
000 ··· bn−1 cn−1
000 ··· an−1 bn
⎞
⎟⎟⎟⎟⎟⎟⎟⎟⎠,
withai,bi,ci ∈ C ,i faici ∈ R andaici ≤ 0 for all1 ≤ i ≤ n −1, then all the eigenvaluesλ
ofΩ satisfy
min
{
Re (bi)
}
≤ Re (λ) ≤ max
{
Re (bi)
}
.
Therefore, whenβ is real positive, we may conclude that all the eigenvalues ofB have a real
part whose sign is opposite to that of the real part ofα:


===== PDF PAGE 299 =====
128 2 FUNCTIONAL METHODS
•R e (α) >0 : Re (λ) <0 for all eigenvalues, and the moments converge to the ﬁxed
point, in a ﬁctitious time at most τ ∼ (2 Re (α))−1 (this is the inverse of the smallest
possible real part, among all eigenvalues).
•R e (α) <0 : Re (λ) >0 for all eigenvalues, and the moments diverge (but would
converge if we changed the direction of the evolution,τ → −τ).
29.e The derivation of the time evolution of the distribution Pτ(x,y ) can be done by the
same method as the one used in Problem 28, by considering a generic test functionF(x,y ) and
writing
∫
dxdy
(
∂τPτ
)
F = Z−1
∫
[Dη]
{
(∂τx)∂xF +(∂τy)(∂yF)
}
e−14 ∫η2
= Z−1
∫
[Dη]
{
(−ReS′ + η/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
−2 δδη
)∂xF +( −ImS′)(∂yF)}e−14 ∫η2.
Then, we integrate the derivative with respect toη by parts to let it act on∂xF, which gives
2 δδη(τ)∂xF = 2 δx(τ)δη(τ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 12
∂2xF = ∂2xF.
Therefore, we have
∫
dxdy
(
∂τPτ
)
F =
∫
dxdy Pτ
{
∂2xF − ReS′(∂xF)− ImS′(∂yF)}
=
∫
dxdy F
{
∂2x +∂xReS′ +∂yImS′
}
Pτ,
which gives the announced Fokker–Planck equation since this equality must be true for any
test functionF(x,y ).
29.f Let us assume a quadratic action, i.e.,β ≡ 0,α ≡ a +ib. The statement of the problem
announces an asymptotic solution in the form of the exponential of a polynomial of degree
two, of the form
− lnP∞(x,y )= 12(ux2 +vy2 +2wxy).
Fixed points of the Fokker–Planck equation make its right-hand side vanish. With the above
ansatz, this results in the following set of equations for the coefﬁcientsu,v,w :
u2 = au +bw, w 2 = av −bw, 2uw = 2aw +b(v −u),u = 2a.
(The four equations correspond to equating to zero the coefﬁcients ofx2,y2,xy and1, respec-
tively.) Onceu is known, it is straightforward to obtain the other coefﬁcients,
w = 2a2b ,v = 2a(1 + 2a2b2 ).
(One should also check that the fourth equation is satisﬁed by this solution.) Therefore, when
β = 0, we indeed obtain the announced ﬁxed point. This distribution looks completely
innocuous, with rapidly falling tails in all directions of the complex plane.


===== PDF PAGE 300 =====
29 COMPLEX LANGEVIN EQUATION 129
When b ≫ a (i.e., when the original integral suffers from a severe sign problem), this
distribution becomes nearly isotropic in thex,y plane:
P∞(x,y )=a≪b
a
π exp
{
−a
(
x2 +y2)}. (2.41)
(We have restored the proper normalization prefactor.) From this isotropic distribution, we
would predictC0 = 1,C2,4,6,... = 0, while the exact moments are
M2n = 12nn!(a +ib)n ≈ 12nn!bn.
The momentz2n/(2n)! obtained with (2.41) in an angular slice [θ,θ +ϵ] reads
ϵ
∫ ∞
0
dr raπe−ar2 r2ne2inθ(2n)! = ϵπ n!e2inθan(2n)! ≫ M2n.
Had we performed the calculation with the exact distributionP∞(x,y ), we would have
ϵ
∫ ∞
0
dr rP∞(x,y ) r2ne2inθ(2n)! = ϵπ n!e2inθan(2n)! {1⊕ ab ⊕···⊕ anbn/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
order
ofM2n
⊕···
}
.
We see that the correct result forM2n results from cancellations in the angular integration over
θ (thanks to the weight e2inθ), such that the result ∼ a−n in a small angular slice is reduced to
b−n after the angular integration. Thus, the sign problem we sought to circumvent reappears
in a (milder) form that renders difﬁcult the evaluation of high-order moments.


===== PDF PAGE 322 =====
37 CLASSICAL NON-ABELIAN PARTICLES AND THE WONG EQUATIONS 151
expectation value of a product of Wilson loops amounts to connecting the ﬁelds attached to the
loops in all possible ways, according to the rules deﬁned by the Yang–Mills actionS[A]. In the
case of the double loop shown in the preceding ﬁgure, there are conﬁgurations of these links
that do not mix the two loops. These conﬁgurations correspond in fact to the product of the
expectation values of the two traces:
⟨
tr
(
W[A;γxy]
)⟩⟨
tr
(
W[A;γyx]
)⟩
= ··· +
γxy
γyx
+··· = O(N2).
(In the graphical representation, we have slightly displaced the loops to highlight the fact that
there are two separate traces.) In contrast, links that connect the two loops contribute to the
“correlated” term:
⟨
tr
(
W[A;γxy]
)
tr
(
W[A;γyx]
)⟩
−
⟨
tr
(
W[A;γxy]
)⟩⟨
tr
(
W[A;γyx]
)⟩
=
γxy
γyx
+··· = 12
γxy
γyx
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
O(N)
− 12N
γxy
γyx
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
O(N)
+··· .
Therefore, we see that the correlated part of the double trace is only of order N, and in the
large-N limit we have
⟨
tr
(
W[A;γxy]
)
tr
(
W[A;γyx]
)⟩
=
N→+∞
⟨
tr
(
W[A;γxy]
)⟩⟨
tr
(
W[A;γyx]
)⟩
.
In this limit, the loop equation becomes
∂μx
δ
⟨
1
N tr
(
W[A;γ]
)⟩
δσμν(x) =N→+∞−ig2N2
∫
γ
dyν δ(x−y)
⟨
1
N tr
(
W[A;γxy]
)⟩⟨1
N tr
(
W[A;γyx]
)⟩
.
This equation, which is a closed equation for expectation values of traces of Wilson loops, is
known as the Makeenko–Migdal equation. In this ﬁnal form, we have normalized each trace
by a factor N−1 in order to have quantities of order one in the fundamental representation.
With this normalization, the prefactor of the second term contains the combinationg2N, called
the ’t Hooft coupling. The limit N → +∞ we have considered in this derivation in general
assumes that the limit is taken whileg2N is kept ﬁnite.
Source: Makeenko, Y . M. and Migdal, A. A. (1979),Phys Lett B 88: 135.
37. Classical Non-Abelian Particles and the Wong Equations The goal of this problem
is to extend to the non-Abelian case the concept of a classical particle that moves along
a trajectory xμ(t). This is useful in situations where the classical approximation provides
the leading answer, for instance in the calculation of hard thermal loops in QCD at ﬁnite
temperature (see Problem 74).


===== PDF PAGE 323 =====
152 3 NON-ABELIAN FIELDS
37.a First, consider the Abelian case. Recall the deﬁnition of the momentumpμ of the particle
(assume it is massive, with a mass m), and the expression for dpμ/dt given by the
Lorentz force. Write the electromagnetic current created by this classical particle, and
check that it is conserved.
37.b Write down a non-Abelian generalization of the Lorentz force, introducing a “color
charge”Qa in place of the electrical chargee. Can Qa be gauge invariant? If not, what
is its transformation law?
37.c CanQa be constant when the particle moves through an external color ﬁeld?
37.d Write down the non-Abelian current generated by the moving particle. What should its
conservation equation be? Show that this conservation equation implies the following
equation of motion forQa:
dxμ
dt
[
Dμ,Q
]
= 0 (Q ≡ Qataf ).
37.a First, let us recall the conservation of the electromagnetic current in QED:
Jμ(x) ≡ eψγμψ, ∂ μJμ = 0,
which follows from the equation of motion of the ﬁeld operator ψ. In this equation, the
current is a quantum operator. However, in this case, it is well known how to obtain a classical
description of the electromagnetic current in terms of classical charged particles. Let us
illustrate this for a single point-like particle of chargee and massm. We denote byxμ(t) the
worldline of this particle, parameterized by its proper time. Its momentum is given by
pμ = mdxμ
dt ,
whose equation of motion is driven by the Lorentz force:
dpμ
dt = eFμν dxνdt . (3.34)
The electromagnetic current it produces can be written as
Jμ ≡ e
∫
dt dxμ
dt δ(x −x(t)).
(In this compact notation, keep in mind that the delta function is in fact a product of four delta
functions, one for each dimension of spacetime.) The veriﬁcation that this current is conserved
goes as follows:
∂μJμ = e
∫
dt dxμ
dt ∂μδ(x −x(t))/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
− ddtδ(x−x(t))
= 0.
Note an implicit assumption, crucial in obtaining this conservation law: the electrical charge
of the particle is time-independent (otherwise, an integration by parts would give a non-zero
integrand proportional to the time derivative ofe). This is of course very trivial: the electro-
magnetic current of the particle is conserved precisely because electrical charges are constants.


===== PDF PAGE 324 =====
37 CLASSICAL NON-ABELIAN PARTICLES AND THE WONG EQUATIONS 153
37.b Now, we would like to generalize the concept of classical particle to particles that carry
a non-Abelian charge. The ﬁrst equation,
pμ = mdxμ
dt ,
is of course the same. Then, we would like to write an equation for the time derivative of the
momentum, involving the non-Abelian ﬁeld strength. Sincedpμ/dt is anSU(N) scalar, we
want a scalar on the right-hand side, not a matrix. Then comes the issue of gauge invariance:
dpμ/dt describes the trajectory of the particle, and therefore should be gauge invariant, while
Fμν is not. Taking the trace ofFμν gives a gauge invariant quantity, but this cannot be correct
since the trace is zero. These considerations suggest that we generalize (3.34) as follows in the
non-Abelian case:
dpμ
dt = 2 tr
(
QFμν) dxν
dt , (3.35)
where Q is a matrix-valued “charge” (in the same representation of the Lie algebra as Fμν).
For the right-hand side to be gauge invariant,Q should be gauge-dependent and transform in
the same way as the ﬁeld strength:
Fμν → Ω† Fμν Ω, Q → Ω† QΩ.
The prefactor2 on the right-hand side was chosen with the fundamental representation in mind,
so that we also have
dpμ
dt = QaFμνa dxνdt .
37.c Because of its transformation law and because a gauge transformationΩ can depend
on spacetime, Q should be regarded as a spacetime-dependent object. Moreover, since Q
describes the charge of a colored particle, and since the ﬁelds with which it may interact
during its propagation themselves carry color, we expect thatQ should evolve according to the
background gauge ﬁeld in which the particle propagates.
37.d In order to derive the equation of motion for Q, let us ﬁrst deﬁne the non-Abelian
current by mimicking the QED deﬁnition:
Jμ(x) ≡
∫
dt Q(x(t)) dxμ
dt δ(x −x(t)). (3.36)
The only notable modiﬁcation is that the charge Q is evaluated at the current point on the
trajectory of the particle, to account for its spacetime dependence inherited from gauge
transformations. Note also that this current is matrix-valued, and not gauge invariant. It


===== PDF PAGE 325 =====
154 3 NON-ABELIAN FIELDS
transforms as
Jμ(x) → Ω†(x)Jμ(x)Ω(x).
For this classical current to be a good replacement for the quantum one, it should fulﬁll the
same covariant conservation equation,
[
Dμ,Jμ] = 0.
(The covariant derivative makes this conservation law gauge invariant.) Therefore, let us
evaluate the covariant derivative of the current deﬁned in (3.36):
[
Dμ,Jμ] = ∫ dt( −ig[Aμ,Q (x(t))] dxμdt δ(x −x(t))
+Q(x(t)) dxμ
dt ∂μδ(x −x(t))/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
− ddtδ(x−x(t))
)
=
∫
dt
(dQ(x(t))
dt −igdxμdt [Aμ,Q (x(t))])δ(x −x(t)).
Requesting that this covariant derivative vanish leads to the following equation of motion for
the non-Abelian chargeQ:
dQ(x(t))
dt −igdxμdt [Aμ,Q (x(t))]/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
dxμ
dt [Dμ,Q]
= 0.
This equation, known as the Wong equation forQ, describes the variation of the color charge
of the particle as it moves through a given background gauge ﬁeld. Note that even a very soft
ﬁeld (i.e., whose non-zero Fourier modes are much smaller than the momentum of the particle),
which does not alter the straight motion of the particle, will change its color. Finally, observe
that this equation may also be written as
dxμ
dt
(
Dadjμ )abQb = 0.
In other words, the covariant derivative ofQ projected along the trajectory of the particle is
vanishing (this equation of motion is reminiscent of the differential equation that deﬁnes a
Wilson line).
Source: Wong, S. K. (1970), Nuovo Cimento A 65: 689.
38. Wong Equations from the Worldline Formalism The goal of this problem is to obtain
the Wong equation derived in Problem 37 by using the worldline formalism. Consider a colored
complex scalar ﬁeld (which ultimately we would like to describe as a colored classical particle)
embedded in a non-Abelian gauge ﬁeldAμ.


===== PDF PAGE 342 =====
42 LARGE- N EXPANSION IN SU(N) YANG–MILLS THEORY 171
• we apply the gauge transformation to both φ1 andφ2 in the inner product. This means
that, in the LSZ formulas, we must also use the gauge transformed plane waves, i.e.,
Φikp(x)= Ω†ij(x)δjk e−ip·x, Aμacλp(x)= Ω†ab(x)δbc ϵμλ (p)e−ip·x,
Ψi+ksp(x)= Ω†ij(x)δjk us(p)e−ip·x,Ψ i−ksp(x)= Ω†ij(x)δjk vs(p)e+ip·x,
respectively
• we limit ourselves to gauge transformations that become time-independent at large|x0|
(this property is necessary for theΩ to go through the time derivative). In other words,
asymptotically, the ﬁelds and their conjugate momenta must transform in the same way.
(In the case of gauge bosons, after theΩ’s have canceled, the extra term∂μθb cancels when
contracted with physical polarization vectors.)
42. Large- N Expansion in SU(N) Yang–Mills Theory Consider anSU(N) Yang–Mills
theory (i.e., a non-Abelian gauge theory without matter ﬁelds). The goal of this problem is
to study the behavior of graphs whenN → +∞, and to relate this behavior to a topological
property of these graphs. (Although we consider the example of vacuum to vacuum graphs in
this problem, the result is more general.)
42.a Draw all the one-particle-irreducible vacuum-to-vacuum graphs made only of gluons
up to three loops (explain why ghosts and gluons contribute similarly to the leading-N
behavior), and determine their leading behavior at largeN. Explain why this limit can
be obtained by replacing each gluon line by a double quark–antiquark line.
42.b Find a rescaling of the gauge ﬁeld in the Lagrangian so that the coupling constant g
appears as an overall prefactorg−2. For later convenience, introduce λ ≡ g2N.H o wd o
the various objects in the Feynman rules scale withλ andN?
42.c Determine the scaling withλ andN of a generic vacuum graph in terms of its numbers
of loops, vertices, propagators and faces (we call every closed quark loop in the double
line representation a face).
42.d Explain why χ ≡ (number of vertices)−( number of edges)+( number of faces) de-
pends only on the genus of the closed surface on which the graph is embedded, but not
on the other details of the graph.
42.e What is the value ofχ for a sphere, for a torus with a single handle, and for a torus with
h handles?


===== PDF PAGE 343 =====
172 3 NON-ABELIAN FIELDS
42.a Let us ﬁrst note that the ghost–antighost–gluon vertex has the same color dependence as
the three-gluon vertex. Likewise, the ghost propagator is identical to the gluon one as far as the
color factors are concerned. Therefore, graphs containing ghosts have the same color structure
as graphs of the same topology with the ghosts replaced by gluons. For this reason, we do
not need to consider ghosts in this discussion. Up to three loops, the one-particle-irreducible
vacuum graphs made only of gluons are the following:
∼O (N2), ∼O ((g2N)N2), ∼O ((g2N)N2),
∼O ((g2N)2N2), ∼O ((g2N)2N2), ∼O ((g2N)2N2),
∼O ((g2N)2N2), ∼O ((g2N)2N2), ∼O ((g2N)2).
(3.47)
The scaling of the ﬁrst graph is simply that of a gluon propagator with the two endpoints
connected to each other. The sum over the contracted color indices of this propagator gives a
factorδaa = N2 −1 ∼O (N2). For the other graphs, we ﬁrst use the following identity:
ifabc = 2 tr (taf tbf tcf )− 2 tr (tbf taf tcf ),
in order to view the color structure of the three-gluon vertex as that of a quark loop. The
next step is to use the su(N) Fierz identity in order to perform all the contractions taf ··· taf .
Recalling the diagrammatic representation of this identity,
(taf )ij(taf )kl =
kl
ji
= 12 − 12N ,
the leading term inN is obtained by replacing the gluon line by a pair of “quark–antiquark” lines
(i.e., the ﬁrst term of the Fierz identity). When we apply this procedure to vacuum diagrams,
we obtain only closed “quark” or “antiquark” loops, which in this estimate correspond to the
trace of the identity matrix in the fundamental representation, and therefore provide a factor N.
For instance, we have
∼ ∼O (N2), ∼ ∼O (g2N3).
The only missing rule to this recipe is how to handle the four-gluon vertices. For these, it is
sufﬁcient to note that the color structure of a four-gluon vertex is equivalent to that of graphs
with a pair of three-gluon vertices:
=
a b
cd
+
a b
cd
+
a b
cd
a b
cd
(3.48)


===== PDF PAGE 344 =====
42 LARGE- N EXPANSION IN SU(N) YANG–MILLS THEORY 173
42.b Interestingly, in the examples listed in (3.47), the ﬁrst eight graphs are of the form
N2(g2N)p, while the last one is of the form N0(g2N)p. Let us now try to understand this
pattern more generally. Recall the form of the Yang–Mills action,
SYM =− 12 ∫ d4x tr(FμνFμν), withFμν ≡ ∂μAν −∂νAμ −ig [Aμ,Aν].
Let us deﬁne ~Aμ ≡ gAμ. In terms of these rescaled ﬁelds, the Yang–Mills action becomes
SYM =− 12g2
∫
d4x tr(~Fμν~Fμν), with~Fμν ≡ ∂μ~Aν −∂ν~Aμ −i [~Aμ,~Aν].
With this rescaling, the coupling constantg appears only in an overall prefactor of the action,
and no longer in the ﬁeld strength. In view of the observations made on the examples of (3.47),
it is useful to rewrite it as
SYM =− N2λ ∫ d4x tr(~Fμν~Fμν), withλ ≡ g2N.
(λ is known as the ’t Hooft coupling.) In terms of these rescaled ﬁelds and couplings, the
various ingredients of the Feynman rules scale as
propagator ←→ λ/N,
vertex ←→ N/λ.
(Note that, after this rescaling, the behaviors of three-gluon and four-gluon vertices are the
same.) In addition, in the large-N limit, each gluon line is replaced by a double quark line.
Each closed quark line brings a factorN:
quark or antiquark loop ←→ N.
Each closed quark line corresponds to a face of the diagram, so we may equivalently count the
faces of the diagram. In order to properly account for the factorN coming from the outer quark
line, we must also count as one face the domain external to the graph (for instance, the ﬁrst
graph of (3.47) has two faces according to this prescription). Topologically, this is equivalent
to viewing a vacuum graph as a polytope embedded in three-dimensional space and counting
its faces, the propagators being the edges of the polytope.
42.c We are now equipped for counting the powers ofλ andN in a generic graph. Let us
denote by nV the number of vertices, bynI the number of internal propagators, and by nF the
number of faces of a vacuum graphG.W eh a v e
G∼ λnI −nV NnV −nI +nF ∼ λnL −1 Nχ(G), (3.49)
wherenL ≡ nI −nV +1 is the number of loops of the graph (i.e., the number of unconstrained
internal momenta). We have also deﬁnedχ(G) ≡ nV −nI +nF . This quantity is called the
Euler characteristic of the graph. Before we discuss its properties, note that in (3.49) it was not
necessary to introduce a distinction between three-gluon and four-gluon vertices. Indeed, if
we replace every four-gluon vertex by a pair of three-gluon vertices according to (3.48), we
increase bothnV andnI by one unit (whilenF remains unchanged), but this does not change
nL , norχ(G).


===== PDF PAGE 345 =====
174 3 NON-ABELIAN FIELDS
Figure 3.4 Illustration of the invariance of the Euler characteristic when a face of a polytope is
split into two faces.
χ = 2 χ = 2 χ = 2 χ = 2 χ = 2
Figure 3.5 Polytopes with the Euler characteristic of a2-sphere.
42.d The most important property of the Euler characteristic is that it is invariant under the
addition of lines to a graph, provided the new lines do not cross the existing ones, as illustrated
in Figure 3.4. In the left image, we show one face of a graph (here, a pentagonal face), with the
rest of the graph – in the shaded area – not represented. In the second image from the left, we
have added one line inside this face, connecting two of the existing vertices. When this is done,
the numbers of vertices, lines and faces vary byδnV = 0,δnI = 1,δnF = 1, respectively, and
the Euler characteristic does not change, δχ = 0. In the third image, the new line connects an
existing vertex and a newly created vertex. Thus, we have δnV = 1,δnI = 2,δnF = 1,b u t
stillδχ = 0. And in the last image, we have δnV = 2,δnI = 3,δnF = 1, and againδχ = 0.
This property of being unchanged when lines that do not lead to crossings are added
implies that the Euler characteristic does not depend on the details of the graph, but is in fact a
topological property of the minimal closed surface on which we can embed the graph without
line crossings. For instance, the ﬁrst ﬁve graphs of equation (3.47) can be embedded on a
2-sphere (recall that we must count as a face the domain outside the graph), while the last one
requires a torus.
42.e Conversely, we may use this invariance in order to compute the Euler characteristic of
all closed surfaces, as follows
• A tetrahedron (nV = 4,nI = 6,nF = 4) is topologically equivalent to a two-dimen-
sional sphere. Therefore, χ = 2 for the sphere, and for all the graphs whose minimal
embedding is the sphere. Figure 3.5 illustrates the invariance of the Euler characteristic
as one reﬁnes the triangulation of a surface.
• If we take a polytope and remove one of its faces to create a hole (while keeping the
edges and vertices on the boundary of the hole), we decrease the Euler characteristic
by one unit, since this operation corresponds to δnV = 0,δnI = 0,δnF =− 1.I fw e


===== PDF PAGE 346 =====
43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 175
χ = 2 χ = 1 χ = 0 χ = −1
Figure 3.6 Euler characteristics of polytopes with faces removed (indicated as hatched
triangles).
Figure 3.7 Deformation of a polytope with two holes into a torus. The Euler characteristic
does not change in the process.
remove two faces in order to create two holes, we haveδχ =− 2, etc. In Figure 3.6, we
have indicated the removed faces by hatched areas. Note that removing just the face, or
the face as well as the vertices and edges on the boundary, leads to the sameχ (indeed,
the boundary of a triangle has equal numbers of vertices and edges).
• If we create two holes and then bend the polytope to glue the boundaries of these holes,
we also haveδχ =− 2, as illustrated in Figure 3.7 (we show three stages of this process;
the Euler characteristic is equal to χ = 0 at all stages). However, this manipulation
creates a handle in the polytope: for instance, it transforms a sphere into a torus with
one handle, a torus with one handle into a torus with two handles, etc. Therefore, the
Euler characteristic of a closed surface withh handles isχ = 2 −2h.
Thus, the formula (3.49) provides a one-to-one correspondence between the order in N of
a vacuum graph (after we have absorbed a factor N in the deﬁnition of λ) and the genus of
the surface on which the graph may be embedded without line crossings. If we consider the
limit of largeN at ﬁxedλ, the leading graphs are those that can be embedded on a sphere (the
standard QFT terminology for these graphs is to call them planar graphs, because the sphere is
topologically equivalent to a plane if we remove its north pole; the large-N limit is also called
the planar approximation), the next-to-leading ones are those that can be embedded on a torus,
etc.
43. Soft Radiation and Antenna Effects in QCD The goal of this problem is to study soft
gluon radiation from a hard QCD process. The main result is that when a soft gluon is emitted
from a quark–antiquark pair in a color-singlet state, its emission at large angles is forbidden.


===== PDF PAGE 347 =====
176 3 NON-ABELIAN FIELDS
43.a Generalize the equation (1.50) in the statement of Problem 10 for the emission of a soft
gluon off a massless quark or antiquark in the ﬁnal state.
43.b Consider now the case where the only colored particles in the hard process are a quark–
antiquark pair in a singlet state. Show that the squared amplitude for producing an extra
soft gluon is the square of theq ¯q production amplitude times the following factor:
I ≡ 2g2 Cf p·q(p·k)(q·k),
wherep,q are the momenta of the quark and antiquark, andk that of the gluon.
43.c Check that the above expression is singular when the gluon is aligned with the quark or
with the antiquark. Rewrite it as a sum of two terms, I ≡ Iq +I¯q, such thatIq (resp. I¯q)
is singular only in the direction of the quark (resp. antiquark). Note: these conditions do
not uniquely determine the splitting; try to ﬁnd the most symmetrical one.
43.d Choose the quark momentum as polar direction and integrate Iq over the azimuthal
angle. Show that this integral vanishes if the gluon polar angle is larger than the angular
separation between the quark and antiquark. Similarly, studyI¯q with respect to the polar
direction deﬁned by the direction of the antiquark.
43.e Does this result hold in the case where the quark–antiquark pair is produced from a
gluon, i.e., is in an octet state?
43.a Consider a QCD scattering amplitude with a massless quark and a massless antiquark
in the ﬁnal state,
Mri,sjq, ¯q (p,q,... ).
(We only explicitly indicate the quark and the antiquark in this notation. The indicesi andj
are the color indices of the quark and antiquark,r ands their spins, andp,q their momenta.)
In order to exhibit the corresponding spinors, we may write
Mri,sjq, ¯q (p,q,... )= ur(p)Aijq, ¯q(p,q,... )vs(q).
Let us now attach a gluon of momentumk, polarizationλ and color indexa to the outgoing
quark line. This gives the following amplitude:
Mri+λa,sjq+g, ¯q (p,q,k,... )
= ur(p)
(
−ig(taf )ii′γμϵλμ(k))i(/p +/k)(p +k)2Ai′jq, ¯q(p +k,q,... )vs(q)
≈
k≪p,q
g(taf )ii′ p·ϵλ(k)p·k ur(p)Ai′jq, ¯q(p,q,... )vs(q)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Mri′,sjq, ¯q (p,q,... )
.
In the last line, we have assumed the gluon to be soft compared to the quark, and we have
usedur(p)γμ/p = 2pμ ur(p) (thanks to the Dirac equation satisﬁed by the massless spinor).


===== PDF PAGE 348 =====
43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 177
Likewise, we can attach the soft gluon to the outgoing antiquark:
Mri,sj+λaq, ¯q+g (p,q,k,... )
= ur(p)Aij′q, ¯q(p,q +k,... ) −i(/q +/k)(q +k)2 ( −ig(taf )j′jγμϵλμ(k))vs(q)
≈
k≪p,q
−g(taf )j′jq·ϵλ(k)q·k ur(p)Aij′q, ¯q(p,q,... )vs(q)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Mri,sj′q, ¯q (p,q,... )
.
43.b If we assume that the quark–antiquark pair is in a color-singlet state (this is always true
if they are the only colored particles in the process), we may write
Aijq, ¯q(p,q,... ) ≡ δij Aq, ¯q(p,q,... ).
Summing the two terms previously obtained, we obtain the following expression for a q ¯qg
ﬁnal state:
Mri,sj,λaq, ¯q,g (p,q,k,... )≈g(taf )ij
[p·ϵλ(k)
p·k −q·ϵλ(k)q·k/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Jμϵλμ
]
×ur(p)Aq, ¯q(p,q,... )vs(q).
(3.50)
Note that the currentJμ contracted into the gluon polarization vector satisﬁes an Abelian-like
Ward–Takahashi identity,
kμ
[ pμ
p·k − qμq·k] = 0,
which ensures the gauge invariance of the amplitude (since a gauge transformation modiﬁes
the polarization vector by a term proportional tokμ).
At this stage, squaring the above amplitude and summing over colors and the gluon
polarizations leads to
∑
ija,λ
⏐⏐⏐Mri,sj,λaq, ¯q,g (p,q,k,... )⏐⏐⏐2
≈ g2 (taf )ij(ta∗f )ij
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
tr (taf taf )=NCf
JμJν
( ∑
λ
ϵλμϵ∗λν
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−gμν+terms inkμ,ν
)⏐⏐⏐ur(p)Aq, ¯q(p,q,... )vs(q)⏐⏐⏐2
= 2g2Cf p·q(p·k)(q·k)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ I
×N
⏐⏐⏐ur(p)Aq, ¯q(p,q,... )vs(q)⏐⏐⏐2
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
∑
i,j
⏐⏐Mri,sjq, ¯q (p,q,... )⏐⏐2
.


===== PDF PAGE 349 =====
178 3 NON-ABELIAN FIELDS
43.c Obviously, the factorI is singular ifp·k = 0 orq·k = 0. Consider the ﬁrst of these
conditions,
0 = EpEk(1 − cosθpk),
whereθpk is the angle between the3-momenta of the quark and of the gluon. Therefore, this
condition is realized when the gluon is emitted collinearly to the quark (note that there would
be no singularity if the quark were massive). Likewise, the conditionq·k = 0 is realized when
the gluon is emitted in the direction of the antiquark. These singularities are called collinear
singularities. The residues at the poles corresponding to the conditions p·k = 0 orq·k = 0
can be obtained easily:
p·q
(p·k)(q·k) = EpEk(p·k) + ﬁnite terms whenθpk → 0,
p·q
(p·k)(q·k) = EqEk(q·k) + ﬁnite terms whenθqk → 0.
This suggests that we writeI = Iq +I¯q, with
Iq ≡ g2Cf
[
p·q
(p·k)(q·k) − EqEk(q·k) + EpEk(p·k)
]
,
I¯q ≡ g2Cf
[
p·q
(p·k)(q·k) + EqEk(q·k) − EpEk(p·k)
]
.
(This decomposition is not unique, as we may subtract some ﬁnite terms along with the poles.)
By construction, Iq is ﬁnite when k ‖ q and I¯q is ﬁnite when k ‖ p, and their sum is trivially
equal to I. Note a caveat here: although it is tempting to interpret the factors Iq, ¯q as giving the
gluon emission off the quark and the antiquark, respectively, this interpretation is not robust
because these two quantities are not gauge invariant independently (only their sum is).
43.d Consider now the ﬁrst quantity, Iq. In this case, it is convenient to use spherical
coordinates with a polar axis alongp. The various vectors involved in the expression forIq
have the following Cartesian coordinates:
p =
⎛
⎜⎝ 00
Ep
⎞
⎟⎠, q =
⎛
⎜⎝sinθqp0
cosθqp
⎞
⎟⎠, k =
⎛
⎜⎝sinθpk cosφsinθpk sinφ
cosθpk
⎞
⎟⎠,
so that


===== PDF PAGE 350 =====
43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 179
p
q
Figure 3.8 Allowed regions (illustrated by the two disks) for the emission of a soft gluon from
a quark–antiquark dipole in a singlet color state.
Iq = 1E2k(1 − cosθpk)
[
cosθpk − cosθqp
1 − cosθqp cosθpk − sinθqp sinθpk cosφ +1
]
.
Let us now perform the integration over the azimuthal angleφ. This integral is of the form
∫2π
0
dφ
a −b cosφ = 2πθ (|a| −|b|) sign (a)√a2 −b2.
This formula, after some trigonometric manipulations, leads to
∫2π
0
dφ Iq = 2πE2k(1 − cosθpk)
[
cosθpk − cosθqp
| cosθpk − cosθqp| +1
]
= θ(θqp −θpk) 4πE2k(1 − cosθpk).
Quite remarkably, the azimuthal integral ofIq vanishes if the emission angleθpk of the gluon
with respect to the quark is larger than the opening of the cone formed by theq ¯q pair. The same
conclusion holds for the integral of I¯q, but this time with a polar axis along the momentum
q of the antiquark. The pattern of allowed soft gluon emission is shown in Figure 3.8. Let
us rephrase more precisely the caveat mentioned earlier: Iq, ¯q cannot be interpreted as the
emission spectra off the quark and antiquark, respectively. Indeed, the emission of a gluon off
a quark does not suffer any angular restriction. The angular veto we are observing here is in
fact due to a destructive interference between the emissions by the quark and by the antiquark.
Let us mention a paradox: the soft radiation factor J is positive deﬁnite, and it is therefore
surprising to ﬁnd regions with seemingly no radiation. But the quantities Jq and J¯q into which
we decompose J are not positive deﬁnite, which allows their azimuthal integrals to be zero for
some polar angles. The paradox is resolved by noting that the polar axis is not the same for the
integrals ofJq andJ¯q (therefore, the sum of these integrals is not the integral ofJ).


===== PDF PAGE 351 =====
180 3 NON-ABELIAN FIELDS
Semi-quantitative Interpretation: The same collimation effect exists in QED for photon
emission off an e+e− pair, where it is known as the Chudakov effect. This suppression of
gluon radiation at angles larger than the opening of the quark–antiquark pair can be understood
semi-quantitatively as follows. According to the uncertainty principle, the virtuality of the line
of momentump +k just before the gluon emission vertex deﬁnes the gluon “formation time,”
t−1f ≡ Ep +Ek −Ep+k ≈ (p +k)22Ep = Ek(1 − cosθpk) ≈θpk≪1 12Ekθ2pk.
During this time, the quark–antiquark pair grows to a transverse size
r⊥ = tfθpq.
Moreover, the gluon wavelength (E−1k ), projected on the plane orthogonal to the quark momen-tum, reads
λ⊥ = 1Ek sinθpk ≈θpk≪1 1Ekθpk.
For the gluon to be emitted without suppression, its transverse wavelength must be smaller than
the size of the quark–antiquark dipole. Otherwise, the gluon cannot resolve the quark–antiquark
pair, and sees only its total charge, which is zero in the present case since we have assumed the
pair to be in a singlet state. This condition reads
1
Ekθpk
≲ r⊥ ⇔ θpk ≲ θpq.
This property, known as angular ordering in the context of QCD, can be used to formulate
gluon emission in the form of “parton cascades” in which each quark, antiquark or gluon has a
certain probability of emitting a new gluon. The effect of quantum interference, which would
in principle preclude such a probabilistic description, is taken into account by vetoing emission
at large angles.
43.e Let us now consider the case where the quark–antiquark pair is produced in an octet
state, i.e., from a gluon. In this case, the above qualitative argument fails: even if the produced
gluon does not resolve the pair, it sees a non-zero total charge, and there should not be any
suppression of its emission (in fact, we expect that the emission at large angle should be
equivalent to the emission by the gluon that produced the quark–antiquark pair). First, let us
rewrite the analogue of (3.50) in the case where the quark–antiquark pair is not assumed to be
singlet:
Mri,sj,λaq, ¯q,g (p,q,k,... ) ≈ gur(p)[p·ϵλ(k)p·k (taf )ii′Ai′jq, ¯q(p,q,... )
−q·ϵλ(k)q·k Aij′q, ¯q(p,q,... )(taf )j′j
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ Jμijaϵλμ(k)
]
vs(q).
Let us check the Ward–Takahashi identity on the currentJμija:
kμJμija =[taf ,Aq, ¯q(p,q,... )]ij.
We can see a difﬁculty here: this current is conserved only when Aq, ¯q is singlet (indeed,
requesting that the commutator on the right-hand side vanish for all generatorstaf implies by
Schur’s lemma thatAq, ¯q must be proportional to the identity).


===== PDF PAGE 352 =====
43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 181
The reason for this problem is that it is impossible for the quark–antiquark pair to be
non-singlet if the quark and antiquark are the only colored particles in the hard process.
Therefore, we must start from a hard process that has at least one gluon in addition to theq ¯q
pair:
Mri,sj,λaq, ¯q,g (p,q,k,... ) ≡ ϵμλ (k)ur(p)Aijaμ (p,q,k,... )vs(q).
Since this gluon is colored, it also contributes to the soft radiation. Therefore, the next step is
to calculate the soft radiation off an external gluon line. To be deﬁnite, we take this gluon line
to be in the ﬁnal state. The amplitude corrected by the emission of a soft gluon (of momentum
k′) off the gluon (of momentumk) line reads
Mri,sj,λa+λ′a′q, ¯q,g (p,q,k,k ′,... )= ϵλ′μ′ (k′) −i(k+k′)2 (−gfaba′ )Vμνμ′ (−k,k +k′, −k′)
×ϵλμ(k)ur(p)Aijbν (p,q,k +k′,... )vs(q),
whereVμνμ′ (−k,k +k′, −k′) is the momentum-dependent factor in the three-gluon vertex:
Vμνμ′ (−k,k +k′, −k′)= gμν(−2k −k′)μ′ +gνμ′ (k +2k′)μ +gμ′μ(−k′ +k)ν
≈
k′≪k gμν(−2kμ′ )+ gνμ′kμ +gμ′μkν.
The two underlined terms will give zero, sincekμϵλμ = 0 andkνAijbν (p,q,k,... )= 0. Using
also (k +k′)2 ≈ 2k·k′, we obtain
Mri,sj,λa+λ′a′q, ¯q,g+g (p,q,k,k ′ ... )
≈ (−igfaba′
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
g(Ta′adj )ab
)k·ϵλ′ (k′)k·k′ ϵμλ (k)ur(p)Aijbμ (p,q,k,... )vs(q).
(One may check that the soft emission off an incoming gluon is given by the same formula.)
Summing the soft emissions off the quark, the antiquark and the gluon, we have
Mri,sj,λa,λ′a′q, ¯q,g,g (p,q,k,k ′,... )
≈ gϵμλ (k)ur(p)[k·ϵλ′ (k′)k·k′ (Ta′adj)ab Aijbμ (p,q,k,... )
+ p·ϵλ′ (k′)p·k′ (ta′f )ii′ Ai′jaμ (p,q,k,... )
−q·ϵλ′ (k′)q·k′ Aij′aμ (p,q,k,... )(ta′f )j′j
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ ϵλ′μ′ (k)Jμ′ijaa′
]
vs(q). (3.51)
This time, we have
k′μ′Jμ′ijaa′ =(Ta′adj)ab Aijbμ +(ta′f )ii′ Ai′jaμ −Aij′aμ (ta′f )j′j = 0. (3.52)
(See Problem 44 for a discussion of this identity, which may be viewed as the statement of
color conservation in the hard process.) In order to be more speciﬁc, consider the case where


===== PDF PAGE 353 =====
182 3 NON-ABELIAN FIELDS
the quark–antiquark pair is in the octet channel, i.e.,
Aijaμ ≡ Aabμ (tbf )ij.
(In this representation, b is the color of the gluon that produces the pair.) Plugging this
representation into Eq. (3.52) leads to
[
Ta′adj,Aμ]ac (tcf )ij = 0.
For this to be true for all assignments of the color indices, Schur’s lemma implies that the
object Aabμ must be proportional toδab,
Aabμ ≡ Bμ δab,
which is just saying that the gluon that produces the quark–antiquark pair must have the same
color as the external gluon in the hard process. We can now plug this speciﬁc form ofAijaμ into
(3.51) and square the amplitude. Because p2 = q2 = k2 = 0, the squares of the three terms
vanish after summing over the polarizationsλ′. Therefore, we need only consider the crossed
products,
∑
λ′
⏐⏐⏐Mri,sj,λa,λ′a′q, ¯q,g,g (p,q,k,k ′,... )⏐⏐⏐2
=
⏐⏐⏐Mhard⏐⏐⏐2( −Ikp(k′)(Ta′adj)ab(tbf )ij(taf )ji′(ta′f )i′i
+Ikq(k′)(Ta′adj)ab(tbf )ij(ta′f )jj′(taf )j′i
+Ipq(k′)(ta′f )ii′(taf )i′j(ta′f )jj′(taf )j′i + complex conjugate),
where we denote
Ipq(k′) ≡ g2 p·q(p·k′)(q·k′), Mhard ≡ ϵμλ (k)ur(p)Bμvs(q).
When we sum over the colors, the various color structures that appear in this formula can be
simpliﬁed easily in the case of su(N):
(
Ta′adj)ab(tbf )ij(taf )ji′(ta′f )i′i =− ifa′ab tr(tbf taf ta′f ) =− 14 N(N2 −1),(
Ta′adj)ab(tbf )ij(ta′f )jj′(taf )j′i =− ifa′ab tr(tbf ta′f taf ) =+ 14 N(N2 −1),(
ta′f )ii′(taf )i′j(ta′f )jj′(taf )j′i = tr(ta′f taf ta′f taf ) =− 12 Cf.
Therefore, we obtain
∑
ijaa′,λ′
⏐⏐⏐Mri,sj,λa,λ′a′q, ¯q,g,g (p,q,k,k ′,... )⏐⏐⏐2
= N2−12 ⏐⏐⏐Mhard⏐⏐⏐2(NIkp(k′)+ NIkq(k′)− 1NIpq(k′)).
Each term in this sum has a speciﬁc radiation pattern, as discussed earlier, and the total emission
pattern depends on the relative orientations ofp,q,k. For instance, if these three vectors are


===== PDF PAGE 354 =====
44 AN IDENTITY OBEYED BY ON-SHELL QCD AMPLITUDES 183
all nearly in the same direction, then the soft gluon emission is also collimated in this direction
(this happens, for instance, if the gluon was itself radiated from the quark–antiquark pair; this
argument indicates that successive emissions of gluons from an initial color-singletq ¯q pair
remain collimated). In contrast, if k ∼ −(p +q), then the soft emission covers most of the
solid angle.
From the above formula, one can also see that, when N →∞ , the soft radiation is
dominated by the ﬁrst two terms, i.e., as if the gluon were emitted independently by a (pk)
quark–antiquark pair and by a (kq) quark–antiquark pair. This can easily be understood from
the fact that we can replace the gluon by a quark–antiquark double line in this limit, which
effectively amounts to replacing the qgq system by qqqq. This observation is the starting
point of the dipole model for successive soft gluon emissions in the large-N limit.
44. An Identity Obeyed by On-Shell QCD Amplitudes Consider an amplitude
Ma1···i1···¯ı1···, where the indices a1,a2,... are the color indices of external gluons, the indices
i1,i2,... are those of outgoing quarks or incoming antiquarks, and the indices ¯ı1, ¯ı2,... those
of outgoing antiquarks or incoming quarks. Show that
∑
α ∈ {out. q, in. ¯q}
(
tbf )iαi′α M···i′α··· − ∑
α ∈ {in. q, out. ¯q}
M···¯ı′α··· (tbf )¯ı′α¯ıα
+
∑
α ∈ {gluons}
(
Tbadj)aαa′α M···a′α··· = 0.
This identity may be proven in several ways. In the spirit of Problem 43, we can derive it
by adding a soft gluon to the amplitude under consideration, in all possible ways. In Problem
43, we worked out the eikonal factors corresponding to the emission of a soft gluon by an
outgoing quark or antiquark:
outgoing quark: M···i··· → gp·ϵλ(k)p·k (tbf )ii′ M···i′···,
outgoing antiquark: M···¯ı··· → −gp·ϵλ(k)p·k M···¯ı′··· (tbf )¯ı′¯ı.
(Of course, the momentum p should be that of the corresponding outgoing line.) Similar
considerations give the following corrective factors for gluon emission off an incoming quark


===== PDF PAGE 368 =====
49 INSTANTONS AS TRANSITIONS BETWEEN PURE GAUGE FIELDS 197
49. Instantons as Transitions between Pure Gauges in Yang–Mills Theory In this
problem, we consider time-independent pure gauge ﬁelds such that Ai(x) → 0 when |x| →∞
(in the gaugeA0 = 0). We show that these ﬁelds can be classiﬁed in topological classes whose
index is a Cartan–Maurer invariant, and that instantons are ﬁeld conﬁgurations that interpolate
between two such pure gauges.
49.a Consider a pure gauge Ai(x) ≡ ig−1Ω†(x)∂iΩ(x), with Ω(x) → 1 at |x| →∞ .
Explain why the homotopy classes of these ﬁelds are the elements ofπ3(SU(N)), with
an indexn given by
n ≡
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ)).
49.b We denote by
⏐⏐nin,out⟩ the asymptotic states made of pure gauges in the homotopy
class of index n. A representative ﬁeld conﬁguration of the topological class n = 0
is Aia(x) ≡ 0. How does this ﬁeld evolve via the classical Yang–Mills equation in
the gauge A0 = 0? Conclude from this that the transitions ⟨nout⏐⏐0in⟩ are classically
forbidden ifn ⁄= 0 and necessarily happen by quantum tunneling.
49.c By analogy with Problem 48, write the path integral representation of this transition
amplitude after going to imaginary time, and argue that the amplitude is dominated by
Euclidean classical solutions.
49.d Recall that the topological index of the instanton is given by
N = g2
∫ d4x
64π2 ϵijklFaijFakl = limR→∞g2
∫
SR
d3Si
16π2 ϵijkl tr
(
AjFkl + 2ig3 AjAkAl),
where SR is a three-dimensional sphere of radius R. Deform the sphere S∞ at inﬁnity
into the surface of a hyper-cube, and show that in the gaugeA0 = 0 this integral is the
difference of two integrals on surfaces atx0 = ±∞, respectively, that are the topological
indices of two pure gauges. Conclude that the instanton of index N interpolates between
pure gauges of index0 andN.
49.a Since the pure gauge ﬁelds Ai(x) under consideration go to a constant when |x| →∞ ,
we may identify all the points at inﬁnity inR 3, which amounts to identifyingR 3 with a3-sphere
S3 (this mapping can be done explicitly by a stereographic projection). Thus, the group element
Ω(x) that deﬁnes the pure gauge can be viewed as a function from S3 to SU(N), and the
homotopy classes are the elements of the third homotopy group ofSU(N),π3(SU(N)). The
topological index of a givenΩ(x) is the appropriately normalized Cartan–Maurer invariant,
n ≡
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ)).


===== PDF PAGE 369 =====
198 3 NON-ABELIAN FIELDS
49.b The topological sectorn = 0 admits as representative the group elementΩ(x) which
is constant and equal to the identity everywhere, i.e., the null gauge potentialAia = 0. In the
gauge A0 = 0, the classical Yang–Mills equations leave this ﬁeld conﬁguration unchanged
throughout all the time evolution. Therefore, the transition from a ﬁeld of index n = 0 to a
ﬁeld of indexn ⁄= 0 is classically forbidden, and can only be mediated by quantum tunneling.
49.c After a transformation to imaginary time, this transition amplitude may be written as
⟨
nout
⏐⏐0in⟩ = ∫ [n]
[0]
[DAi]e−SE [A],
whereSE is the Euclidean action, and where the notations[0] and [n] on the integral symbol are
a reminder of its boundary conditions, namely pure gauge ﬁeld conﬁgurations (which depend
only on x since they are at the boundaries in time) of topological indices 0 andn, respectively.
This path integral is dominated by the minimal action over the set of ﬁelds compatible with
these boundary conditions. On the other hand, we know that the ﬁelds that give the minima of
the Euclidean action are instantons, whose value at the boundary of R 4 is a pure gauge.
49.d The topological indexN of an instanton solution is given by the integral
N = g2
∫ d4x
64π2 ϵijklFaijFakl = g2
∫
∂(R 4)
d3Si
32π2 Ki, (3.55)
with
Ki = 2ϵijkl tr(AjFkl + 2ig3 AjAkAl) =|x|→∞ 4ig3 ϵijkl tr(AjAkAl).
(The ﬁrst term in Ki becomes negligible in the limit |x| →∞ for ﬁelds that go to a pure gauge
at inﬁnity.) The second equality in (3.55) comes from the fact thatϵijklFaijFakl is equal to the
total derivative2∂iKi. Therefore, by Stokes’s theorem, the integral can be rewritten as the
ﬂux ofKi through the boundary at inﬁnity. The result does not depend on the precise shape
of this boundary, and we can thus take a four-dimensional hyper-cube. Two “faces” of this
hyper-cube correspond to the boundaries at inﬁnite time, and all the others are boundaries at
inﬁnity in one of the spatial directions.
Let us consider the A0 = 0 gauge. If i is a spatial direction, then in ϵijklAjAkAl, one
of j,k,l must be 0 and therefore Ki vanishes at inﬁnity on the two faces of the hyper-cube
orthogonal to the spatial directioni. Thus, only the two boundaries atx0 = ±∞ may contribute,
and the topological index of the instanton can be rewritten as
N = 4ig3
3 ϵ0jkl
{ ∫
x0=+∞
d3x
32π2 tr
(
AjAkAl
)
−
∫
x0=−∞
d3x
32π2 tr
(
AjAkAl
)
}
.
In these integrals, the ﬁeld Ai is a pure gauge Ai =( i/g)Ω†∂iΩ, with Ω belonging to the
topological sector 0 (at x0 =− ∞)o r n (at x0 =+ ∞), respectively. The integrals are the


===== PDF PAGE 370 =====
50 VACUA OF YANG–MILLS THEORY 199
corresponding Cartan–Maurer invariants, i.e., the topological indices of the initial and ﬁnal
pure gauges. For instance:
4ig3
3 ϵ0jkl
∫
x0=+∞
d3x
32π2 tr
(
AjAkAl
)
=
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ))
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
topological indexn ofΩ(x) atx0 =+ ∞
.
Therefore, we have shown that
N = n −0 (more generally,N = n(+∞)− n(−∞)).
Therefore, the instanton of indexN is the Euclidean solution that interpolates between pure
gauges of topological indicesn andn +N.
50. Vacua of Yang–Mills Theory The goal of this problem is to show that classical
Yang–Mills theory has a countable inﬁnity of ground states. When quantum effects are taken
into account, this leads to a continuous set of ground states known as theθ-vacua. Consider
Yang–Mills theory in the temporal gaugeA0 = 0, with the coupling set tog = 1 for simplicity.
50.a What is the conjugate momentum of Ai? Derive the Hamiltonian, and check that
Hamilton’s equations are the usual Yang–Mills equations. Why do we need in addition
to impose Gauss’s law, i.e.,G[A] ≡
[
Di,∂0Ai] = 0, on the classical solutions? (Note
that the quantum analogue of Gauss’s law is that physical states should be annihilated
byG[A].)
50.b Yang–Mills theory in the temporal gauge has a residual invariance under purely spatial
gauge transformationsΩ(x). Explain why the gauge transformation Ω(x) ≡ eiϑa(x)ta
is generated by
Qϑ =−
∫
d3x(∂0Aia)(Diabϑb).
IfΩ(x) goes to the identity at spatial inﬁnity, show that this generator becomes propor-
tional to the Gauss’s law constraint, implying that physical states are in fact invariant
under the action ofeiQϑ .
50.c From the above considerations, show that a vacuum state is a superposition of pure
gauge ﬁeldsiU†∂iU, related to one another by spatial gauge transformations Ω(x) that
go to the identity at inﬁnity.
50.d Consider transition amplitudes between two vacua, the ﬁrst one corresponding toU1 ≡ 1
and the second one toU2(x). Show that U2(x) should go to a constant at inﬁnity for this
amplitude to be non-zero. Why can these U’s be seen as mappings from the3-sphere S3
to the gauge group?
50.e Use the preceding result to conclude that SU(N) Yang–Mills theory has a countable
inﬁnity of inequivalent energy minima, indexed by an integer given by the Cartan–
Maurer invariant. How do quantum ﬂuctuations alter this classical picture? Determine


===== PDF PAGE 93 =====
52 SIX-POINT −−−+++ AMPLITUDE 215
3−^ 4+^
2−
5+
6+
1−
+−
3−^ 4+^
1−
2−
5+6+
+−
Figure 4.1 Contributions to the six-point color-ordered amplitude1−2−3−4+5+6+, with a
shift applied to the lines3 and4 (the lines carrying the shift are shown in boldface).
52. Six-Point −−−+++ Amplitude Using a BCFW shift on lines 3 and 4, derive an
expression for the color-ordered amplitude1−2−3−4+5+6+ that has only two terms:
A6(1−2−3−4+5+6+)=− 4ig4[2⏐⏐P3 +P4⏐⏐5⟩ { ⟨1⏐⏐P2 +P3⏐⏐4]3[23][34]⟨56⟩⟨61⟩(p2 +p3 +p4)2
+
⟨
3
⏐⏐P4 +P5⏐⏐6]3[
61
][
12
]⟨
34
⟩⟨
45
⟩
(p3 +p4 +p5)2
}
.
When the shift is applied to lines3 and4, there are only two ways to arrange the remaining
lines and to choose the internal helicities, as shown in Figure 4.1. Note that the graph on the
right contains an anti-MHV amplitude with two positive helicities and three negative ones. For
this sub-amplitude, we will accept without proof that the Parke–Taylor formula with square
brackets instead of angle brackets is valid. The shift that has good behavior when|z| →∞ is
the one with
⏐⏐ˆ4] =⏐⏐4] and⏐⏐ˆ3⟩ =⏐⏐3⟩ (and the direction of the shift is a complex momentum
kμ such that ⏐⏐k⟩ = ⏐⏐3⟩ and⏐⏐k] = ⏐⏐4]). Therefore, the sum of these two graphs gives the
following expression for the six-point amplitude:
A6(1−2−3−4+5+6+)=− 4ig4
{
1
s23
⟨
23
⟩3
⟨
3ˆKI
⟩⟨ˆKI2⟩
⟨
1ˆKI
⟩3
⟨ˆKIˆ4⟩⟨ˆ45⟩⟨56⟩⟨61⟩
+ 1s45
[
45
]3
[
5ˆLI
][ˆLI4]
[ˆLI6]3[
61
][
12
][
2ˆ3][ˆ3ˆLI]
}
,
where we denotes23 ≡ (p2 +p3)2,s45 ≡ (p4 +p5)2. We have deﬁnedKI ≡ −(p2 +p3) in the
ﬁrst term andLI =− (p4 +p5) in the second one. Consider the ﬁrst term, for which the value of
z at the pole is given by0 = ˆK2I = K2I +2z∗ KI ·k = s23 −z∗⟨kKI⟩[KIk] = s23 +z∗⟨32⟩[24],which leads to
z∗ =− s23⟨32⟩[24] =−
⟨
23
⟩[
23
]
⟨
32
⟩[
24
] =
[
23
]
[
24
], ⏐⏐ˆ4⟩ =⏐⏐4⟩ + [23][24]⏐⏐3⟩.
The angle brackets containingˆKI can be evaluated as follows. For a generic on-shell momentum


===== PDF PAGE 94 =====
216 4 SCATTERING AMPLITUDES
𝓁μ,w eh a v e
⟨
𝓁ˆKI
⟩[ˆKI4] =−⟨𝓁2⟩[24] −⟨𝓁3⟩[34] +z∗⟨𝓁3⟩[44]/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
= 0
=−
⟨
𝓁
⏐⏐P2 +P3⏐⏐4].
Moreover,
[
24
]⟨ˆ45⟩ =[24]⟨45⟩ +z∗[24]⟨35⟩ =[24]⟨45⟩ +[23]⟨35⟩ =[2⏐⏐P3 +P4⏐⏐5⟩,⟨ˆ4⏐⏐P2 +P3⏐⏐4] =⟨4⏐⏐P2 +P3⏐⏐4] +z∗⟨3⏐⏐P2 +P3⏐⏐4]
=
⟨
42
⟩[
24
]
+
⟨
43
⟩[
34
]
−s23 =− 2
(
p2 ·p4 +p3 ·p4 +p2 ·p3
)
=− (p2 +p3 +p4)2.
Therefore, the ﬁrst term can be rewritten as
A(1)6 (1−2−3−4+5+6+)=− 4ig4(p2 +p3 +p4)2 ⟨1⏐⏐P2 +P3⏐⏐4]3[23][34]⟨56⟩⟨61⟩[2⏐⏐P3 +P4⏐⏐5⟩.
The same method can be used to simplify the second term, leading to the following ﬁnal result:
A6(1−2−3−4+5+6+)=− 4ig4[2⏐⏐P3 +P4⏐⏐5⟩ { ⟨1⏐⏐P2 +P3⏐⏐4]3[23][34]⟨56⟩⟨61⟩(p2 +p3 +p4)2
+
⟨
3
⏐⏐P4 +P5⏐⏐6]3[
61
][
12
]⟨
34
⟩⟨
45
⟩
(p3 +p4 +p5)2
}
.
This is a remarkably simple expression given the fact that it would be obtained as the sum of
38 color-ordered Feynman graphs in the traditional approach. Non-adjacent conﬁgurations of
the three negative helicities and the three positive ones lead to more complicated formulas, but
it is easy to see that BCFW recursion produces at most six terms in the worst case.
53. Two Spinor-Helicity Identities Deﬁne the following four4×4 matrices:
γμ ≡
(
0σ μ
σμ 0
)
, with σμ ≡ (1,σi), σμ ≡ (1, −σi).
53.a Check that theseγμ are a valid representation of the Dirac matrices in four dimensions.
53.b Show that
tr (σμσνσρσσ)= 2(gμνgρσ −gμρgνσ +gμσgνρ +iϵμνρσ),
tr (σμσνσρσσ)= 2(gμνgρσ −gμρgνσ +gμσgνρ −iϵμνρσ).
53.c Use this result to prove the following identities (withsij ≡ (pi +pj)2):
[
12
]⟨
23
⟩[
34
]⟨
41
⟩
−
⟨
12
⟩[
23
]⟨
34
⟩[
41
]
= 4ip 1μp2νp3ρp4σ ϵμνρσ,⟨
12
⟩[
23
]
⟨
14
⟩[
43
] = s12s34 −s13s24 +s14s23 −4ip 1μp2νp3ρp4σ ϵμνρσ
2s14s34
.


===== PDF PAGE 139 =====
67 ONE-LOOP ++++ AMPLITUDE FROM GENERALIZED CUTS 261
proportional to each other:
⏐⏐1⟩ ∝⏐⏐a⟩ ∝⏐⏐d⟩.
Likewise, by considering the other three sub-amplitudes, we also have
⏐⏐2⟩ ∝⏐⏐b⟩ ∝⏐⏐a⟩, ⏐⏐3⟩ ∝⏐⏐c⟩ ∝⏐⏐b⟩, ⏐⏐4⟩ ∝⏐⏐d⟩ ∝⏐⏐c⟩.
Since proportionality is a transitive relationship, this implies that
⏐⏐1⟩ ∝⏐⏐2⟩ ∝⏐⏐3⟩ ∝⏐⏐4⟩.
This is a constraint on the external momenta, which implies that the three Mandelstam
invariants are zero,s = t = u = 0, which is not satisﬁed in general. Therefore, this cut
is also zero.
Thus, we have shown that all the possible cuts of the one-loop amplitudeA4(1+2+3+4+) are
zero in four dimensions, which implies that this amplitude is purely rational.
66.c Consider now the all-plusn-point amplitude at one loop,An(1+2+ ··· n+), withn ≥ 5.
With a four-dimensional loop momentum, the maximal number of cut lines is four. The proof
that all these cuts are zero follows the same reasoning as in the preceding case, and is even
simpler in the case of the four-particle cuts.
• Two-particle cuts split the amplitude into ap-point (3 ≤ p ≤ n) and an (n−p+4)-point
sub-amplitude. In total, these two sub-amplitudes require at least three negative helicities,
while the two cut propagators provide only two. These cuts are all zero.
• Three-particle cuts give ap-point, a q-point and an (n−p−q+6)-point sub-amplitude.
At least four negative helicities are necessary, while the cut propagators carry only three.
All these cuts are also zero.
• Four-particle cuts split the amplitude into a p-point, a q-point, an r-point and an
(n−p−q−r+8)-point sub-amplitude. At least ﬁve negative helicities are necessary
whenn ≥ 5, since at least one of the sub-amplitudes has four points or more. The cuts
provide only four negative helicities, implying that these cuts are zero.
Therefore, An(1+2+ ··· n+) is purely rational at one loop.
67. One-Loop Four-Point ++++ Amplitude from Generalized Unitarity The goal of
this problem is to calculate analytically the all-plus four-gluon color-ordered amplitude at one
loop, with a massless complex scalar running in the loop. Assume the loop momentum 𝓁μ to
be ind ≡ 4 −2ϵ dimensions, while the external gluons are kept strictly four-dimensional.
67.a Explain why the reduction of the corresponding loop integral is equivalent to that of the
same loop with a massive scalar in four dimensions. What set of scalar integrals can
appear in the result of this reduction?


===== PDF PAGE 140 =====
262 4 SCATTERING AMPLITUDES
67.b Consider now the four-point all-plus amplitude with a scalar loop,Ascalar4 (1+2+3+4+).
Write its reduction to master integrals. Why are tadpoles and bubbles absent?
67.c Apply a four-particle cut to this amplitude to obtain the box coefﬁcient,
D0123 = 8g4𝓁4⊥
[
12
][
34
]
⟨
12
⟩⟨
34
⟩.
67.d By applying the three-particle cut (012), check that the triangle coefﬁcientC012 is zero.
67.e Perform explicitly the loop momentum integration in the master integrals, to obtain
Ascalar4 (1+2+3+4+)=− ig412π2 [12][34]⟨12⟩⟨34⟩.
67.a Recall the propagator for a massless complex scalar and its trilinear coupling to a gauge
ﬁeld:
p
= ip2 +i0+,
p
q
μ =− ig(p +q)μ.
(Since we are interested in color-ordered amplitudes, the vertex has been stripped of its color
factor. There is in addition aφ∗φAμAμ vertex that we shall not need in the discussion.) The
loop momentum 𝓁μ can be decomposed into a component 𝓁μ‖ that lives in the four physical
dimensions, and a component𝓁μ⊥ in thed −4 extra dimensions:
𝓁μ ≡ 𝓁μ‖/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
4 dim
+ 𝓁μ⊥
/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
d −4 dim
.
By construction, 𝓁⊥ is orthogonal to 𝓁‖, and also to all the external momenta and polariza-
tion vectors that are assumed to remain four-dimensional. Given this decomposition, the
denominators of the propagators in the loop are all of the form
(𝓁 +q)2 =( 𝓁‖ +q)2 +𝓁2⊥.
Interestingly,𝓁⊥ appears in the same way in all the denominators, via its square. Moreover,
if we view the extra dimensions as space-like, this contribution is identical to a mass term
μ2 ≡ −𝓁2⊥.
Consider now the numerator of the loop integral. Its momentum dependence comes from
theφ∗φAμ vertices, contracted with external trees made of gluons or with polarization vectors.


===== PDF PAGE 141 =====
67 ONE-LOOP ++++ AMPLITUDE FROM GENERALIZED CUTS 263
Since these are four-dimensional, these contractions depend on𝓁‖ but not on𝓁⊥. Therefore, a
loop integral withm denominators has the following generic structure:
∫ dd𝓁
(2π)d
N(𝓁)∏m−1
i=0 (𝓁 +qi)2/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
d-dimensional massless
=
∫ dd−4𝓁⊥
(2π)d−4
∫ d4𝓁‖
(2π)4
N(𝓁‖)∏m−1
i=0
(
(𝓁‖ +qi)2 +𝓁2⊥)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
four-dimensional massive
.
Except for the additional integration over the extra dimensions of the loop momentum, the
right-hand side contains the same loop integral, for a four-dimensional but massive scalar. The
standard reduction techniques, applied to the latter integral, lead to a general decomposition in
boxes, triangles, bubbles and tadpoles.
67.b This observation is handy for calculating some amplitudes that are purely rational, such
as a one-loop amplitude with all external gluons having positive helicities. Since the result is
rational, it can be picked by unitarity methods only if the loop momentum is allowed to be
d-dimensional rather than four-dimensional. But this makes it difﬁcult to use the spinor-helicity
formalism to express the tree sub-amplitudes obtained after the cuts have been applied. With
the above observation, we need to cut a four-dimensional massive loop instead. When the
particle running in the loop is a scalar, simple expressions exist for the tree sub-amplitudes,
some of which have been derived in Problem 57, even when the scalar is massive.
Let us now apply this to the calculation of the one-loop amplitude Ascalar4 (1+2+3+4+).
From Problems 65 and 66, we know that this amplitude is ultraviolet ﬁnite and is a rational
function of the external momenta. Splitting the loop momentum into its four-dimensional part
𝓁‖ and the extra components𝓁⊥, we ﬁrst have
Ascalar4 (1+2+3+4+)= limd→4
∫ dd−4𝓁⊥
(2π)d−4 Ascalar4 (1+2+3+4+;−𝓁2⊥)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
massive4d scalar loop
,
where the integrand on the right-hand side is the same amplitude evaluated with a four-
dimensional loop momentum and a squared mass −𝓁2⊥. Since we expect an ultraviolet ﬁnite
result (see Problem 65), the reduction of the four-dimensional loop integral over 𝓁μ‖ cannot
contain bubbles or tadpoles, but only boxes and triangles. Therefore, the reduction applied to
this integrand leads to
Ascalar4 (1+2+3+4+;−𝓁2⊥)= D0123L(4)0123
+C012L(4)012 +C023L(4)023 +C013L(4)013 +C123L(4)123, (4.44)
where we have deﬁned
L(4)i1···ip ≡
∫ d4𝓁‖
(2π)4
ip
((𝓁‖ +qi1 )2 +𝓁2⊥)··· ((𝓁‖ +qip )2 +𝓁2⊥),
q0 ≡ 0, q 1 ≡ p1,q 2 ≡ p1 +p2,q 3 ≡ p1 +p2 +p3 =− p4
(p1,2,3,4 are the momenta of the four external gluons). It is interesting to note the dimensions


===== PDF PAGE 142 =====
264 4 SCATTERING AMPLITUDES
of the various objects in the decomposition of the amplitude (in the limitϵ → 0):
dim (Ascalar4 )= 0,
dim (L(4)0123)=− 4, dim (D0123)= 4,
dim (L(4)ijk)=− 2, dim (Cijk)= 2.
Given the dimension of the coefﬁcientD0123, it may contain a factor𝓁4⊥, which would produce
an ultraviolet divergence in the integration over𝓁⊥, and therefore a pole inϵ−1. However, as
we shall see, because the factor𝓁4⊥ is restricted to the d −4 extra dimensions, it also brings
an explicit factorϵ into the numerator that compensates for the pole and thus leads to a ﬁnite
result in the end.
67.c In order to determine the coefﬁcientsD0123 andCijk, we apply cuts simultaneously to
the amplitude Ascalar4 (1+2+3+4+;−𝓁2⊥) and to the various integralsL(4)i1···ip . Let us denote by
Δi the operator that cuts the propagator of denominator (𝓁‖ +qi)2 +𝓁2⊥:
i
(𝓁‖ +qi)2 +𝓁2⊥ −→Δi δ
(
(𝓁‖ +qi)+ 𝓁2⊥)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ δi
.
Consider ﬁrst the four-line cut obtained by applyingΔ0Δ1Δ2Δ3 to Eq. (4.44). All the triangles
L(4)ijk give zero since they have only three denominators. Therefore, we must have
Δ0Δ1Δ2Δ3
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)] = D0123 Δ0Δ1Δ2Δ3[L(4)0123].
On the right-hand side, the application of the four cuts is immediate and gives
Δ0Δ1Δ2Δ3
[
L(4)0123] = ∫ d4𝓁‖(2π)4 δ0δ1δ2δ3. (4.45)
Applying the four cuts to the full amplitude is equally straightforward, since the four-point
amplitude has at most four denominators. We obtain
Δ0Δ1Δ2Δ3
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)] =
1+ 2+
3+4+
= 2
∫ d4𝓁‖
(2π)4 δ0δ1δ2δ3 A3(𝓁‖,1 +, −(𝓁‖ +q1)∗) A3(𝓁‖ +q1,2 +, −(𝓁‖ +q2)∗)
×A3(𝓁‖ +q2,3 +, −(𝓁‖ +q3)∗) A3(𝓁‖ +q3,4 +, −𝓁∗‖),
(4.46)
where A3(𝓁‖,i +, −𝓁′∗‖ ) denotes the on-shell three-point amplitude (with a mass −𝓁2⊥ for the
scalar particles), with a scalar, an antiscalar and a gluon. The prefactor 2 accounts for the fact
that the roles of the scalar and antiscalar may be interchanged. These three-point amplitudes


===== PDF PAGE 143 =====
67 ONE-LOOP ++++ AMPLITUDE FROM GENERALIZED CUTS 265
have been calculated in Problem 57. In fact, we also evaluated there the product of two such
amplitudes, leading to the following compact results:
A3(𝓁‖,1 +, −(𝓁‖ +q1)∗)A3(𝓁‖ +q1,2 +, −(𝓁‖ +q2)∗)= 2g2𝓁2⊥
[
12
]
⟨
12
⟩,
A3(𝓁‖ +q2,3 +, −(𝓁‖ +q3)∗)A3(𝓁‖ +q3,4 +, −𝓁∗‖)= 2g2𝓁2⊥
[
34
]
⟨
34
⟩.
Comparing (4.45) and (4.46) therefore gives the following value for the box coefﬁcient:
D0123 = 8g4𝓁4⊥
[
12
][
34
]
⟨
12
⟩⟨
34
⟩.
(Such a direct identiﬁcation is permitted by the fact that the four delta functions freeze the
integral over the four components of𝓁‖.)
67.d Let us now turn to the triple cuts. We can limit the discussion to the cutΔ0Δ1Δ2, and
by symmetry we will be able to infer the other triple cuts without further calculation. When
applied to the right-hand side of (4.44), this triple cut receives contributions from the box
integralL(4)0123 and from the triangleL(4)012:
Δ0Δ1Δ2
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)] = D0123 Δ0Δ1Δ2[L(4)0123] +C012 Δ0Δ1Δ2[L(4)012].
The cuts on the right-hand side of this equation read
Δ0Δ1Δ2
[
L(4)0123] = ∫ d4𝓁‖(2π)4 i(𝓁‖ +q3)2 +𝓁2⊥ δ0δ1δ2,
Δ0Δ1Δ2
[
L(4)012] = ∫ d4𝓁‖(2π)4 δ0δ1δ2.
Applying this triple cut to the full amplitude gives
Δ0Δ1Δ2
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)] =
1+ 2+
3+4+
= 2
∫ d4𝓁‖
(2π)4 δ0δ1δ2 A3(𝓁‖,1 +, −(𝓁‖ +q1)∗) A3(𝓁‖ +q1,2 +, −(𝓁‖ +q2)∗)
×A4(𝓁‖ +q2,3 +4+, −𝓁∗‖).
The four-point amplitude that appears in the last line has also been calculated in Problem 57:


===== PDF PAGE 144 =====
266 4 SCATTERING AMPLITUDES
A4(𝓁‖ +q2,3 +4+, −𝓁∗‖)= 2g2𝓁2⊥
[
34
]
⟨
34
⟩ i
(𝓁‖ +q3)2 +𝓁2⊥.
Therefore, we have
Δ0Δ1Δ2
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)]
= 8g4𝓁4⊥
[
12
][
34
]
⟨
12
⟩⟨
34
⟩
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
D0123
∫ d4𝓁‖
(2π)4
i
(𝓁‖ +q3)2 +𝓁2⊥ δ0δ1δ2/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Δ0Δ1Δ2
[
L(4)0123
]
.
This triple cut is in fact saturated by the triple cut of the box integral. Therefore, the coefﬁcient
of the triangleL(4)012 vanishes,C012 = 0.
67.e Likewise, all the other triangle coefﬁcients are zero, and the amplitude is fully given by
Ascalar4 (1+2+3+4+)
= 8g4
[
12
][
34
]
⟨
12
⟩⟨
34
⟩ lim
d→4
∫ dd−4𝓁⊥
(2π)d−4
∫ d4𝓁‖
(2π)4
𝓁4⊥
((𝓁‖ +q0)2 +𝓁2⊥)··· ((𝓁‖ +q3)2 +𝓁2⊥)
= 8g4
[
12
][
34
]
⟨
12
⟩⟨
34
⟩ lim
d→4
gd−4μν gd−4ρσ
∫ dd𝓁
(2π)d
𝓁μ𝓁ν𝓁ρ𝓁σ
(𝓁 +q0)2 ··· (𝓁 +q3)2.
In the ﬁnal line, it is convenient to combine the integrations over 𝓁⊥ and 𝓁‖ into a unique
d-dimensional integral, by introducing the restriction gd−4μν of the metric tensor to the extra
dimensions. Its trace is equal tod −4, and it gives zero when contracted to a Lorentz index that
lives in the four physical dimensions. Therefore, after the Lorentz contractions are performed,
the factorgd−4μν gd−4ρσ will bring at least one power ofϵ. However, the integral is logarithmically
divergent in four dimensions, and therefore has a poleϵ−1. Since the divergence is logarithmic,
the coefﬁcient of the pole is simply given by
∫ dd𝓁
(2π)d
𝓁μ𝓁ν𝓁ρ𝓁σ
𝓁8 = 1d(d+2) (gμνgρσ +gμρgνσ +gμσgνρ)
∫ dd𝓁
(2π)d
1
𝓁4
= i24 (gμνgρσ +gμρgνσ +gμσgνρ) Γ (2 − d2 )(4π)2 Γ (2)
= i12(4π)2(4−d) (gμνgρσ +gμρgνσ +gμσgνρ).
(At every stage, we keep only the term that produces a pole ind = 4, and disregard the ﬁnite


===== PDF PAGE 145 =====
68 ONE-LOOP +++++ AMPLITUDE FROM GENERALIZED CUTS 267
(1 graph) (4 graphs) (4 graphs)
(2 graphs) (2 graphs) (4 graphs)
(4 graphs) (4 graphs) (4 graphs)
(4 graphs) (4 graphs)
Figure 4.4 The37 color-ordered graphs contributing to the amplitudeAscalar4 (1+2+3+4+) in
the traditional approach (solid lines≡ gluons, dashed lines≡ scalars).
terms.) Contracting this with gd−4μν gd−4ρσ gives
gd−4μν gd−4ρσ
∫ dd𝓁
(2π)d
𝓁μ𝓁ν𝓁ρ𝓁σ
𝓁8 = i12(4π)2(4−d)gd−4μν gd−4ρσ (gμνgρσ +gμρgνσ +gμσgνρ)
= i12(4π)2 (2 −d),
so that we ﬁnally obtain the following remarkably simple result:
Ascalar4 (1+2+3+4+)=− ig412π2 [12][34]⟨12⟩⟨34⟩.
In the traditional approach based on Feynman diagrams, one would have to sum the contribu-
tions of37 color-ordered graphs (see Figure 4.4) in order to obtain this one-loop amplitude.
For reasons beyond the scope of this problem, this result also turns out to be the value of the
1+2+3+4+ amplitude in Yang–Mills theory (i.e., with a gluon and a ghost loop instead of a
scalar loop).
Source: Brandhuber, A., McNamara, S., Spence, B. and Travaglini, G. (2005), J High Energy
Phys 10: 011.
68. One-Loop Five-Point +++++ Amplitude from Generalized Unitarity This problem
continues along the lines of Problem 67. The goal is now to calculate the ﬁve-point all-plus
one-loop amplitudeAscalar5 (1+2+3+4+5+).
68.a Interpreting the contribution of thed −4 extra dimensions to the scalar propagator as a
mass, write the reduction of this amplitude on a basis of master integrals (denote by𝓁i
the momenta carried by the loop propagators, with 𝓁i = 𝓁i−1 +pi, and by Di ≡ 𝓁2i +𝓁2⊥
the corresponding denominators).


exit_code=0
```

### 2026-11-16T22:01:19.915041+08:00

```bash
python3 -c 'from pathlib import Path; print(Path("tools/run_harbor_local_checks.py").read_text()); print(Path("tasks/qft-04/environment/requirements.txt").read_text()); print(Path("tools/init_task_shell.py").read_text())'
```

```text

### 2026-11-16T22:01:19.915659+08:00

```bash
python3 tools/read_qft_source_pages.py gelis 368:370
```

```text
#!/usr/bin/env python3
"""Run oracle/nop locally and archive raw jobs, including unsuccessful runs."""

import argparse
import datetime
import json
import platform
import re
import shlex
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("task_id")
    parser.add_argument("--macos-compat", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z]+-[0-9]{2}", args.task_id):
        parser.error("invalid task id")
    source = ROOT / "tasks" / args.task_id
    if not source.is_dir():
        parser.error("task directory does not exist")
    harbor = shutil.which("harbor")
    if not harbor:
        raise SystemExit("harbor executable not found")
    # Avoid '%' URL handling in Harbor/Compose, retaining the exact task contents.
    stage = Path(tempfile.mkdtemp(prefix=f"physics-{args.task_id}-harbor-", dir="/tmp"))
    task = stage / args.task_id
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"))
    if args.macos_compat:
        config = task / "task.toml"
        original = config.read_text(encoding="utf-8")
        needle = 'environment_mode = "separate"\nnetwork_mode = "no-network"'
        if needle not in original:
            raise SystemExit("expected verifier network declaration missing")
        config.write_text(original.replace(needle, 'environment_mode = "separate"\nnetwork_mode = "public"'), encoding="utf-8")
    mode = "harbor-macos-compat" if args.macos_compat else "harbor-linux"
    destination = ROOT / "runs" / args.task_id / mode
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for agent in ("oracle", "nop"):
        jobs = stage / "runs" / agent
        command = [harbor, "run", "-p", str(task), "-a", agent,
                   "--n-attempts", "1", "--n-concurrent", "1", "--max-retries", "0",
                   "--jobs-dir", str(jobs)]
        print("$ " + shlex.join(command), flush=True)
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(command, text=True)
        job_results=sorted(jobs.glob('*/result.json'))
        summaries=[]
        for result_path in job_results:
            payload=json.loads(result_path.read_text(encoding='utf-8'))
            stats=payload.get('stats',{})
            expected=1.0 if agent=='oracle' else 0.0
            evaluations=stats.get('evals',{})
            passed=(stats.get('n_errored_trials')==0 and stats.get('n_completed_trials')==1
                    and len(evaluations)==1)
            for evaluation in evaluations.values():
                passed=passed and evaluation.get('n_trials')==1 and evaluation.get('n_errors')==0
                metrics=evaluation.get('metrics',[])
                passed=passed and len(metrics)==1 and metrics[0].get('mean')==expected
            summaries.append({'result':str(result_path.relative_to(jobs)), 'passed':passed,
                              'expected_reward':expected, 'stats':stats})
        archive = destination / agent
        archive.mkdir(parents=True, exist_ok=True)
        if jobs.exists():
            shutil.copytree(jobs, archive, dirs_exist_ok=True)
        records.append({"agent": agent, "command": command, "returncode": result.returncode,
                        "started_utc": started, "archive": str(archive.relative_to(ROOT)),
                        "verified_results":summaries,
                        "passed":result.returncode==0 and len(summaries)==1 and all(s['passed'] for s in summaries)})
    report = {"task_id": args.task_id, "host": platform.platform(), "temporary_task": str(task),
              "macos_verifier_network_override": args.macos_compat, "runs": records}
    output = destination / ("session-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    if any(not record['passed'] for record in records):
        raise SystemExit("Harbor trial/reward verification failed; original jobs have been archived")


if __name__ == "__main__":
    main()

numpy==2.1.3
scipy==1.14.1
mpmath==1.3.0

"""Copy only the common, pinned Harbor shell for a newly authored task."""
import argparse
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('task_id');args=parser.parse_args()
destination=ROOT/'tasks'/args.task_id
destination.mkdir(parents=True,exist_ok=True)
for relative in ('environment/Dockerfile','environment/requirements.txt','environment/.dockerignore',
                 'solution/solve.sh','tests/test.sh','task.toml'):
    target=destination/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        raise SystemExit(f'refusing to overwrite {target}')
    shutil.copyfile(ROOT/'tasks/qm-01'/relative,target)
    if relative=='task.toml':
        target.write_text(target.read_text().replace('qm-01',args.task_id),encoding='utf-8')
(destination/'environment/public').mkdir(exist_ok=True)
(destination/'tests/private').mkdir(exist_ok=True)
shutil.copyfile(ROOT/'tools/course_quality_score.py',destination/'tests/quality_score.py')
print(f'Created common Harbor shell: {args.task_id}')


exit_code=0
```

===== PDF PAGE 368 =====
49 INSTANTONS AS TRANSITIONS BETWEEN PURE GAUGE FIELDS 197
49. Instantons as Transitions between Pure Gauges in Yang–Mills Theory In this
problem, we consider time-independent pure gauge ﬁelds such that Ai(x) → 0 when |x| →∞
(in the gaugeA0 = 0). We show that these ﬁelds can be classiﬁed in topological classes whose
index is a Cartan–Maurer invariant, and that instantons are ﬁeld conﬁgurations that interpolate
between two such pure gauges.
49.a Consider a pure gauge Ai(x) ≡ ig−1Ω†(x)∂iΩ(x), with Ω(x) → 1 at |x| →∞ .
Explain why the homotopy classes of these ﬁelds are the elements ofπ3(SU(N)), with
an indexn given by
n ≡
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ)).
49.b We denote by
⏐⏐nin,out⟩ the asymptotic states made of pure gauges in the homotopy
class of index n. A representative ﬁeld conﬁguration of the topological class n = 0
is Aia(x) ≡ 0. How does this ﬁeld evolve via the classical Yang–Mills equation in
the gauge A0 = 0? Conclude from this that the transitions ⟨nout⏐⏐0in⟩ are classically
forbidden ifn ⁄= 0 and necessarily happen by quantum tunneling.
49.c By analogy with Problem 48, write the path integral representation of this transition
amplitude after going to imaginary time, and argue that the amplitude is dominated by
Euclidean classical solutions.
49.d Recall that the topological index of the instanton is given by
N = g2
∫ d4x
64π2 ϵijklFaijFakl = limR→∞g2
∫
SR
d3Si
16π2 ϵijkl tr
(
AjFkl + 2ig3 AjAkAl),
where SR is a three-dimensional sphere of radius R. Deform the sphere S∞ at inﬁnity
into the surface of a hyper-cube, and show that in the gaugeA0 = 0 this integral is the
difference of two integrals on surfaces atx0 = ±∞, respectively, that are the topological
indices of two pure gauges. Conclude that the instanton of index N interpolates between
pure gauges of index0 andN.
49.a Since the pure gauge ﬁelds Ai(x) under consideration go to a constant when |x| →∞ ,
we may identify all the points at inﬁnity inR 3, which amounts to identifyingR 3 with a3-sphere
S3 (this mapping can be done explicitly by a stereographic projection). Thus, the group element
Ω(x) that deﬁnes the pure gauge can be viewed as a function from S3 to SU(N), and the
homotopy classes are the elements of the third homotopy group ofSU(N),π3(SU(N)). The
topological index of a givenΩ(x) is the appropriately normalized Cartan–Maurer invariant,
n ≡
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ)).


===== PDF PAGE 369 =====
198 3 NON-ABELIAN FIELDS
49.b The topological sectorn = 0 admits as representative the group elementΩ(x) which
is constant and equal to the identity everywhere, i.e., the null gauge potentialAia = 0. In the
gauge A0 = 0, the classical Yang–Mills equations leave this ﬁeld conﬁguration unchanged
throughout all the time evolution. Therefore, the transition from a ﬁeld of index n = 0 to a
ﬁeld of indexn ⁄= 0 is classically forbidden, and can only be mediated by quantum tunneling.
49.c After a transformation to imaginary time, this transition amplitude may be written as
⟨
nout
⏐⏐0in⟩ = ∫ [n]
[0]
[DAi]e−SE [A],
whereSE is the Euclidean action, and where the notations[0] and [n] on the integral symbol are
a reminder of its boundary conditions, namely pure gauge ﬁeld conﬁgurations (which depend
only on x since they are at the boundaries in time) of topological indices 0 andn, respectively.
This path integral is dominated by the minimal action over the set of ﬁelds compatible with
these boundary conditions. On the other hand, we know that the ﬁelds that give the minima of
the Euclidean action are instantons, whose value at the boundary of R 4 is a pure gauge.
49.d The topological indexN of an instanton solution is given by the integral
N = g2
∫ d4x
64π2 ϵijklFaijFakl = g2
∫
∂(R 4)
d3Si
32π2 Ki, (3.55)
with
Ki = 2ϵijkl tr(AjFkl + 2ig3 AjAkAl) =|x|→∞ 4ig3 ϵijkl tr(AjAkAl).
(The ﬁrst term in Ki becomes negligible in the limit |x| →∞ for ﬁelds that go to a pure gauge
at inﬁnity.) The second equality in (3.55) comes from the fact thatϵijklFaijFakl is equal to the
total derivative2∂iKi. Therefore, by Stokes’s theorem, the integral can be rewritten as the
ﬂux ofKi through the boundary at inﬁnity. The result does not depend on the precise shape
of this boundary, and we can thus take a four-dimensional hyper-cube. Two “faces” of this
hyper-cube correspond to the boundaries at inﬁnite time, and all the others are boundaries at
inﬁnity in one of the spatial directions.
Let us consider the A0 = 0 gauge. If i is a spatial direction, then in ϵijklAjAkAl, one
of j,k,l must be 0 and therefore Ki vanishes at inﬁnity on the two faces of the hyper-cube
orthogonal to the spatial directioni. Thus, only the two boundaries atx0 = ±∞ may contribute,
and the topological index of the instanton can be rewritten as
N = 4ig3
3 ϵ0jkl
{ ∫
x0=+∞
d3x
32π2 tr
(
AjAkAl
)
−
∫
x0=−∞
d3x
32π2 tr
(
AjAkAl
)
}
.
In these integrals, the ﬁeld Ai is a pure gauge Ai =( i/g)Ω†∂iΩ, with Ω belonging to the
topological sector 0 (at x0 =− ∞)o r n (at x0 =+ ∞), respectively. The integrals are the


===== PDF PAGE 370 =====
50 VACUA OF YANG–MILLS THEORY 199
corresponding Cartan–Maurer invariants, i.e., the topological indices of the initial and ﬁnal
pure gauges. For instance:
4ig3
3 ϵ0jkl
∫
x0=+∞
d3x
32π2 tr
(
AjAkAl
)
=
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ))
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
topological indexn ofΩ(x) atx0 =+ ∞
.
Therefore, we have shown that
N = n −0 (more generally,N = n(+∞)− n(−∞)).
Therefore, the instanton of indexN is the Euclidean solution that interpolates between pure
gauges of topological indicesn andn +N.
50. Vacua of Yang–Mills Theory The goal of this problem is to show that classical
Yang–Mills theory has a countable inﬁnity of ground states. When quantum effects are taken
into account, this leads to a continuous set of ground states known as theθ-vacua. Consider
Yang–Mills theory in the temporal gaugeA0 = 0, with the coupling set tog = 1 for simplicity.
50.a What is the conjugate momentum of Ai? Derive the Hamiltonian, and check that
Hamilton’s equations are the usual Yang–Mills equations. Why do we need in addition
to impose Gauss’s law, i.e.,G[A] ≡
[
Di,∂0Ai] = 0, on the classical solutions? (Note
that the quantum analogue of Gauss’s law is that physical states should be annihilated
byG[A].)
50.b Yang–Mills theory in the temporal gauge has a residual invariance under purely spatial
gauge transformationsΩ(x). Explain why the gauge transformation Ω(x) ≡ eiϑa(x)ta
is generated by
Qϑ =−
∫
d3x(∂0Aia)(Diabϑb).
IfΩ(x) goes to the identity at spatial inﬁnity, show that this generator becomes propor-
tional to the Gauss’s law constraint, implying that physical states are in fact invariant
under the action ofeiQϑ .
50.c From the above considerations, show that a vacuum state is a superposition of pure
gauge ﬁeldsiU†∂iU, related to one another by spatial gauge transformations Ω(x) that
go to the identity at inﬁnity.
50.d Consider transition amplitudes between two vacua, the ﬁrst one corresponding toU1 ≡ 1
and the second one toU2(x). Show that U2(x) should go to a constant at inﬁnity for this
amplitude to be non-zero. Why can these U’s be seen as mappings from the3-sphere S3
to the gauge group?
50.e Use the preceding result to conclude that SU(N) Yang–Mills theory has a countable
inﬁnity of inequivalent energy minima, indexed by an integer given by the Cartan–
Maurer invariant. How do quantum ﬂuctuations alter this classical picture? Determine


exit_code=0
```

### 2026-11-16T22:04:42.712854+08:00

```bash
docker images --format '{{.Repository}}:{{.Tag}}'
```

```text
theory-physics-sp05:dev
theory-physics-sp04:dev
theory-physics-sp03:dev
theory-physics-sp02:dev
theory-physics-qft04:dev
theory-physics-ed05:dev
theory-physics-qft03:dev
theory-physics-ed04:dev
theory-physics-ed03:dev
theory-physics-tm03:dev
theory-physics-qft02:dev
theory-physics-qm03:dev
theory-physics-ed02:dev
theory-physics-qm02:dev
theory-physics-qft01:dev
theory-physics-ed01:dev
theory-physics-qm01:dev
theory-physics-sp01:dev
theory-physics-tm02:dev
theory-physics-tm01:dev
mechanics-inverse-task01:dev
gbplanner2-course:local
gbplanner2-course-fortress:local
gbplanner2-course-base:local
gbplanner2-humble:local
iquest-benchmark-sqlite-db-truncate:20261019
iquest-benchmark-git-leak-recovery:20261019
iquest-benchmark-log-summary-date-ranges:20261019
iquest-benchmark-openssl-selfsigned-cert:20261019
iquest-benchmark-regex-log:20261019
iquest-benchmark-cancel-async-tasks:20261019
iquest-benchmark-base:20261019
mirror.gcr.io/library/ros:humble-ros-base-jammy
subject-agent-searxng:alpine-clean
subject-agent-searxng:latest
subject-agent-searxng:alpine-fixed
subject-agent-searxng:alpine
subject-agent-searxng:trixie
subject-agent-mysql:8.0
deploy-word-worker:latest
deploy-image-sanitizer:latest
deploy-migrate:latest
deploy-ops:latest
deploy-backend:latest
subject-agent-d04-amd64-image:local
subject-agent-d04-amd64-word:local
subject-agent-d04-amd64-frontend:local
subject-agent-d04-amd64-backend:local
deploy-frontend:latest
subject-agent-d04-image-local:latest
subject-agent-d04-word-local:latest
subject-agent-d04-backend-local:latest
subject-agent-d04-builder-local:latest
subject-agent-d04-backend:local
subject-agent-d04-builder:local
subject-agent-d04-word:local
subject-agent-d04-image:local
subject-agent-security:word-current
subject-agent-security:image-current
subject-agent-security:backend-current
subject-agent-d04-frontend:local
subject-agent-security:frontend-current
subject-agent-d04-frontend-local:latest
cgr.dev/chainguard/python:latest
mirror.gcr.io/library/python:3.14-slim-bookworm
mirror.gcr.io/library/python:3.14-slim-trixie
mirror.gcr.io/library/python:3.14-alpine
subject-agent-security:frontend-resilient-20260924
deploy-frontend-builder:resilient-current
subject-agent-security:frontend-20260924
subject-agent-nginx-verified:20260924
nginx:1.30.5-alpine3.24
mirror.gcr.io/library/nginx:<none>
redis:8-alpine
subject-agent-security:word-d1a408d-20260919
subject-agent-security:image-d1a408d-20260919
subject-agent-security:backend-d1a408d-20260919
subject-agent-security:frontend-d1a408d-20260919
subject-agent-security:builder-d1a408d-20260919
node:24-alpine
mirror.gcr.io/library/node:24-alpine
mirror.gcr.io/library/python:3.12.13-slim-bookworm
ollama/ollama:latest
searxng/searxng:latest
nginx:alpine
mirror.gcr.io/library/python:3.14-alpine3.22
mysql:8.0
mirror.gcr.io/library/mysql:8.0
alpine:<none>
hello-world:latest
nginx:1.27-alpine
gcr.io/distroless/python3-debian13:latest

exit_code=0
```

### 2026-11-16T22:13:36.753236+08:00

```bash
python3 tools/author_qft13_19.py
```

```text
Authored qft-13 through qft-19; truth/schema/metric await Linux calibration.

exit_code=0
```

### 2026-11-16T22:15:22.512898+08:00

```bash
python3 tools/author_qft13_19.py
```

```text
Authored qft-13 through qft-19; truth/schema/metric await Linux calibration.

exit_code=0
```

### 2026-11-16T22:15:22.624598+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 13 14 15 16 17 18 19 --calibrate
```

```text
qft-13 raw/reference/baseline {'reference': 0.058500153443693415, 'baseline': 26.618052126734653} runtime {'reference_seconds': 0.0016096670000251834, 'baseline_seconds': 0.0012658750000014152} truth_s 0.8679972510000198
[
  {
    "id": "quartic-01",
    "field": 5,
    "reference": 0.00010427608327779245,
    "truth": 0.00010427630854676977,
    "relative": 2.160308323784795e-06
  },
  {
    "id": "quartic-01",
    "field": 6,
    "reference": -1.6205872505155135e-06,
    "truth": -1.6205719557322267e-06,
    "relative": 9.437892117426842e-06
  },
  {
    "id": "quartic-01",
    "field": 9,
    "reference": 0.0005246241795152993,
    "truth": 0.000524627639088701,
    "relative": 6.5943407168463405e-06
  },
  {
    "id": "quartic-01",
    "field": 10,
    "reference": 9.78729470007888e-05,
    "truth": 9.787568830469779e-05,
    "relative": 2.800801666356146e-05
  },
  {
    "id": "quartic-01",
    "field": 11,
    "reference": 1.1205265812438296e-05,
    "truth": 1.1204511326807082e-05,
    "relative": 6.733766508924682e-05
  },
  {
    "id": "quartic-01",
    "field": 12,
    "reference": 5.76519588437051e-07,
    "truth": 5.800250244844811e-07,
    "relative": 0.0035054360474301104
  },
  {
    "id": "quartic-03",
    "field": 12,
    "reference": 4.5145725089728954e-08,
    "truth": 4.51532084963996e-08,
    "relative": 7.483406670649062e-06
  },
  {
    "id": "quartic-04",
    "field": 0,
    "reference": 0.12773029920779336,
    "truth": 0.12776535733760985,
    "relative": 0.0002743946445816062
  },
  {
    "id": "quartic-04",
    "field": 1,
    "reference": -0.38489471666000613,
    "truth": -0.3848633330428553,
    "relative": 8.15448354165029e-05
  },
  {
    "id": "quartic-04",
    "field": 2,
    "reference": -0.05716007490642657,
    "truth": -0.057137817239891635,
    "relative": 0.00038954352143848745
  },
  {
    "id": "quartic-04",
    "field": 3,
    "reference": -0.0636758363776049,
    "truth": -0.06370853855435761,
    "relative": 0.0005133091653766787
  },
  {
    "id": "quartic-04",
    "field": 4,
    "reference": -0.011588703285149713,
    "truth": -0.01159864556647903,
    "relative": 0.000857193305229563
  },
  {
    "id": "quartic-04",
    "field": 5,
    "reference": 0.0005003556600354076,
    "truth": 0.0004961334022211447,
    "relative": 0.008510327656554127
  },
  {
    "id": "quartic-04",
    "field": 6,
    "reference": -0.0007688577385700051,
    "truth": -0.0007689333718279068,
    "relative": 9.836126337165184e-05
  },
  {
    "id": "quartic-04",
    "field": 7,
    "reference": 0.0007940886189821434,
    "truth": 0.0007953157035969898,
    "relative": 0.0015428899609257565
  },
  {
    "id": "quartic-04",
    "field": 9,
    "reference": 0.025479895025435458,
    "truth": 0.025524963003949477,
    "relative": 0.0017656432452828933
  },
  {
    "id": "quartic-04",
    "field": 10,
    "reference": 0.013373568385965115,
    "truth": 0.013394034705194395,
    "relative": 0.0015280174853767752
  },
  {
    "id": "quartic-04",
    "field": 11,
    "reference": 0.004595595116618584,
    "truth": 0.0046408911303571585,
    "relative": 0.00976019744188414
  },
  {
    "id": "quartic-04",
    "field": 12,
    "reference": 0.0010463583921912778,
    "truth": 0.0010611753340297153,
    "relative": 0.013962765024109192
  }
]
{"linux_environment": true, "reference_matches_independent_truth": false, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true}
Traceback (most recent call last):
  File "/work/tools/run_qft13_19_checks.py", line 115, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 113, in main
    for i in a.ids:check_one(i,a.calibrate)
                   ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 108, in check_one
    if not all(checks.values()):raise RuntimeError(ident+' validation failed')
                                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
RuntimeError: qft-13 validation failed

exit_code=1
```

### 2026-11-16T22:15:53.401437+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 14 15 16 17 18 19 --calibrate
```

```text
qft-14 raw/reference/baseline {'reference': 6.507387475499469e-10, 'baseline': 2.619567285973766} runtime {'reference_seconds': 0.014737374999981512, 'baseline_seconds': 0.0008202090000395401} truth_s 0.03560283399997388
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true}

### 2026-11-16T22:17:09.458393+08:00

```bash
python3 tools/author_qft13_19.py
```

```text
Authored qft-13 through qft-19; truth/schema/metric await Linux calibration.

exit_code=0
```

### 2026-11-16T22:17:09.555763+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 13 --calibrate
```

```text
qft-13 raw/reference/baseline {'reference': 0.058500153443693415, 'baseline': 26.618052126734653} runtime {'reference_seconds': 0.016931207999959952, 'baseline_seconds': 0.001718999999980042} truth_s 1.3365464999999972
[
  {
    "id": "quartic-01",
    "field": 5,
    "reference": 0.00010427608327779245,
    "truth": 0.00010427630854676977,
    "relative": 2.160308323784795e-06
  },
  {
    "id": "quartic-01",
    "field": 6,
    "reference": -1.6205872505155135e-06,
    "truth": -1.6205719557322267e-06,
    "relative": 9.437892117426842e-06
  },
  {
    "id": "quartic-01",
    "field": 9,
    "reference": 0.0005246241795152993,
    "truth": 0.000524627639088701,
    "relative": 6.5943407168463405e-06
  },
  {
    "id": "quartic-01",
    "field": 10,
    "reference": 9.78729470007888e-05,
    "truth": 9.787568830469779e-05,
    "relative": 2.800801666356146e-05
  },
  {
    "id": "quartic-01",
    "field": 11,
    "reference": 1.1205265812438296e-05,
    "truth": 1.1204511326807082e-05,
    "relative": 6.733766508924682e-05
  },
  {
    "id": "quartic-01",
    "field": 12,
    "reference": 5.76519588437051e-07,
    "truth": 5.800250244844811e-07,
    "relative": 0.0035054360474301104
  },
  {
    "id": "quartic-03",
    "field": 12,
    "reference": 4.5145725089728954e-08,
    "truth": 4.51532084963996e-08,
    "relative": 7.483406670649062e-06
  },
  {
    "id": "quartic-04",
    "field": 0,
    "reference": 0.12773029920779336,
    "truth": 0.12776535733760985,
    "relative": 0.0002743946445816062
  },
  {
    "id": "quartic-04",
    "field": 1,
    "reference": -0.38489471666000613,
    "truth": -0.3848633330428553,
    "relative": 8.15448354165029e-05
  },
  {
    "id": "quartic-04",
    "field": 2,
    "reference": -0.05716007490642657,
    "truth": -0.057137817239891635,
    "relative": 0.00038954352143848745
  },
  {
    "id": "quartic-04",
    "field": 3,
    "reference": -0.0636758363776049,
    "truth": -0.06370853855435761,
    "relative": 0.0005133091653766787
  },
  {
    "id": "quartic-04",
    "field": 4,
    "reference": -0.011588703285149713,
    "truth": -0.01159864556647903,
    "relative": 0.000857193305229563
  },
  {
    "id": "quartic-04",
    "field": 5,
    "reference": 0.0005003556600354076,
    "truth": 0.0004961334022211447,
    "relative": 0.008510327656554127
  },
  {
    "id": "quartic-04",
    "field": 6,
    "reference": -0.0007688577385700051,
    "truth": -0.0007689333718279068,
    "relative": 9.836126337165184e-05
  },
  {
    "id": "quartic-04",
    "field": 7,
    "reference": 0.0007940886189821434,
    "truth": 0.0007953157035969898,
    "relative": 0.0015428899609257565
  },
  {
    "id": "quartic-04",
    "field": 9,
    "reference": 0.025479895025435458,
    "truth": 0.025524963003949477,
    "relative": 0.0017656432452828933
  },
  {
    "id": "quartic-04",
    "field": 10,
    "reference": 0.013373568385965115,
    "truth": 0.013394034705194395,
    "relative": 0.0015280174853767752
  },
  {
    "id": "quartic-04",
    "field": 11,
    "reference": 0.004595595116618584,
    "truth": 0.0046408911303571585,
    "relative": 0.00976019744188414
  },
  {
    "id": "quartic-04",
    "field": 12,
    "reference": 0.0010463583921912778,
    "truth": 0.0010611753340297153,
    "relative": 0.013962765024109192
  }
]
{"linux_environment": true, "reference_matches_independent_truth": false, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true}
Traceback (most recent call last):
  File "/work/tools/run_qft13_19_checks.py", line 115, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 113, in main
    for i in a.ids:check_one(i,a.calibrate)
                   ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 108, in check_one
    if not all(checks.values()):raise RuntimeError(ident+' validation failed')
                                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
RuntimeError: qft-13 validation failed

exit_code=1
```

### 2026-11-16T22:17:53.326667+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 -c 'import sys,json,numpy as np;sys.path.insert(0,"tools");import author_qft13_19 as a;ns={};exec(a.source_for(13,True),ns);m=json.load(open("tasks/qft-13/environment/public/model.json"));from scipy.integrate import quad; c=m["cases"][3];al=complex(*c["alpha"]);b=c["beta"];f=lambda n:complex(quad(lambda x:(x**n*np.exp(-al*x*x/2-b*x**4/4)).real,0,12,epsabs=1e-13,limit=1000)[0],quad(lambda x:(x**n*np.exp(-al*x*x/2-b*x**4/4)).imag,0,12,epsabs=1e-13,limit=1000)[0]);print("direct",f(2)/f(0)/2);print("banded",[(n,ns["moments"](al,b,n)[0]) for n in (20,180,1000,12000)]);print("truth",ns["truth"](m)["records"][3])'
```

```text
direct (0.12776535733760983-0.38486333304285536j)
banded [(20, np.complex128(0.1338442931165808-0.3875713840708649j)), (180, np.complex128(0.12773029920779336-0.38489471666000613j)), (1000, np.complex128(0.12773029920779336-0.38489471666000613j)), (12000, np.complex128(0.12773029920779336-0.38489471666000613j))]
truth {'id': 'quartic-04', 'values': [0.12776535733760985, -0.3848633330428553, -0.057137817239891635, -0.06370853855435761, -0.01159864556647903, 0.0004961334022211447, -0.0007689333718279068, 0.0007953157035969898, 0.6130036583157579, 0.025524963003949477, 0.013394034705194395, 0.0046408911303571585, 0.0010611753340297153], 'labels': []}

exit_code=0
```

### 2026-11-16T22:18:51.245204+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 16 17 18 19 --calibrate
```

```text
qft-16 raw/reference/baseline {'reference': 6.956032802867774e-13, 'baseline': 22.95323347687499} runtime {'reference_seconds': 0.3048324589999538, 'baseline_seconds': 0.15747224999995524} truth_s 0.03897329099993385
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true}
qft-17 raw/reference/baseline {'reference': 9.599622440873136e-13, 'baseline': 1.9158529179807469} runtime {'reference_seconds': 0.32555458399997406, 'baseline_seconds': 0.020927791999952206} truth_s 0.0773636249999754
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true}
qft-18 raw/reference/baseline {'reference': 5.992612696781737e-12, 'baseline': 13.687635964550857} runtime {'reference_seconds': 0.000759207999976752, 'baseline_seconds': 0.0005759170001056191} truth_s 0.0028048750000380096
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "on_shell_momentum_conservation": true, "little_group_covariance": true}
qft-19 raw/reference/baseline {'reference': 2.3885028526430424e-14, 'baseline': 12.500000044980169} runtime {'reference_seconds': 0.008372833999942486, 'baseline_seconds': 0.0011272089999465607} truth_s 0.13792770899999596
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true}

exit_code=0
```

### 2026-11-16T22:19:29.441884+08:00

```bash
docker ps --format '{{.ID}} {{.Names}} {{.Command}}'
```

```text
83de1135367c frosty_ganguly "python3 tools/run_q…"

exit_code=0
```

### 2026-11-16T22:19:54.633846+08:00

```bash
docker stats --no-stream 83de1135367c
```

```text
CONTAINER ID   NAME             CPU %     MEM USAGE / LIMIT   MEM %     NET I/O   BLOCK I/O       PIDS
83de1135367c   frosty_ganguly   100.29%   51.18MiB / 4GiB     1.25%     0B / 0B   741kB / 393kB   19

exit_code=0
```

### 2026-11-16T22:19:55.700448+08:00

```bash
docker stop 83de1135367c
```

```text
83de1135367c

exit_code=0
```

exit_code=137
```

### 2026-11-16T22:20:41.798979+08:00

```bash
python3 tools/author_qft13_19.py
```

```text
Authored qft-13 through qft-19; truth/schema/metric await Linux calibration.

exit_code=0
```

### 2026-11-16T22:20:41.920846+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 13 --calibrate
```

```text
qft-13 raw/reference/baseline {'reference': 1.2238316049032204e-09, 'baseline': 26.618052126734653} runtime {'reference_seconds': 0.009528917000011461, 'baseline_seconds': 0.0012095839999801683} truth_s 0.9521519169999237
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true}

exit_code=0
```

### 2026-11-16T22:21:01.063358+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 15 --calibrate
```

```text
explicit-color theta N= 2 value= 6.0 seconds= 5.870899997262313e-05
explicit-color theta N= 3 value= 24.0 seconds= 4.0833999946698896e-05
explicit-color tetrahedron N= 2 value= 6.0 seconds= 4.124999998111889e-05
explicit-color tetrahedron N= 3 value= 36.0 seconds= 0.0018150829999967755
explicit-color tetrahedron N= 4 value= 120.0 seconds= 0.05436654199991153
explicit-color triangular-prism N= 2 value= 6.0 seconds= 0.0003755410000394477
explicit-color triangular-prism N= 3 value= 54.0 seconds= 0.7274190829999725

### 2026-11-16T22:22:09.323249+08:00

```bash
docker run --rm --network none --cpus 1 --memory 1g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 -c 'import numpy as np; f=np.zeros((15,15,15));print(np.einsum_path("abc,ade,ebf,cgh,hdi,ifg->",*[f]*6,optimize="optimal")[1])'
```

```text
  Complete contraction:  abc,ade,ebf,cgh,hdi,ifg->
         Naive scaling:  9
     Optimized scaling:  9
      Naive FLOP count:  2.307e+11
  Optimized FLOP count:  2.307e+11
   Theoretical speedup:  1.000
  Largest intermediate:  1.000e+00 elements
--------------------------------------------------------------------------
scaling                  current                                remaining
--------------------------------------------------------------------------
   9    ifg,hdi,cgh,ebf,ade,abc->                                       ->

exit_code=0
```

### 2026-11-16T22:22:29.819911+08:00

```bash
docker ps --format '{{.ID}} {{.Command}}'
```

```text
a3b3f7965d84 "sh -c 'sleep infini…"
a18e688d6dc8 "python3 tools/run_q…"

exit_code=0
```

### 2026-11-16T22:23:03.482513+08:00

```bash
docker stop a18e688d6dc8
```

```text
a18e688d6dc8

exit_code=0
```

exit_code=137
```

### 2026-11-16T22:23:13.600559+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 15 --calibrate
```

```text
explicit-color theta N= 2 value= 6.0 seconds= 6.074999998872954e-05
explicit-color theta N= 3 value= 24.0 seconds= 3.1417000059263955e-05
explicit-color tetrahedron N= 2 value= 6.0 seconds= 0.00017633300001307362
explicit-color tetrahedron N= 3 value= 36.0 seconds= 0.000108875000023545
explicit-color tetrahedron N= 4 value= 120.0 seconds= 0.00026841600003990607
explicit-color triangular-prism N= 2 value= 6.0 seconds= 0.014456500000051165
explicit-color triangular-prism N= 3 value= 54.00000000000003 seconds= 0.008042165999995632
explicit-color triangular-prism N= 4 value= 240.0000000000001 seconds= 0.003100541999970119
explicit-color K3-3 N= 2 value= 0.0 seconds= 0.00793612499990104
explicit-color K3-3 N= 3 value= -8.686833737232044e-16 seconds= 0.007463958000016646
explicit-color K3-3 N= 4 value= -1.6879100466855096e-16 seconds= 0.008181415999956698
qft-15 raw/reference/baseline {'reference': 0.0, 'baseline': 21.652157738095237} runtime {'reference_seconds': 0.554124000999991, 'baseline_seconds': 0.5286759589999974} truth_s 0.055030499999929816
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true}

exit_code=0
```

### 2026-11-16T22:26:36.445430+08:00

```bash
python3 tools/author_qft13_19.py
```

```text
Authored qft-13 through qft-19; truth/schema/metric await Linux calibration.

exit_code=0
```

### 2026-11-16T22:26:36.589402+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 18 --calibrate
```

```text
qft-18 raw/reference/baseline {'reference': 5.954666384956382e-12, 'baseline': 7.050805883909107} runtime {'reference_seconds': 0.0018250000000534783, 'baseline_seconds': 0.0017095000000608707} truth_s 0.027132375000064712
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "on_shell_momentum_conservation": true, "little_group_covariance": true}

exit_code=0
```

### 2026-11-16T22:27:41.736208+08:00

```bash
docker run --rm --network none --cpus 1 --memory 1g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 -c 'import json,numpy as np,sys;sys.path.insert(0,"tools");import author_qft13_19 as a; ns={};exec(a.source_for(18),ns);m=json.load(open("tasks/qft-18/environment/public/model.json"));out=ns["solve"](m);print([(r["id"],r["values"][:2]) for r in out["records"]]);print("soft_ratios");br=ns["br"];base=m["cases"][0];l=ns["matrix"](base["lambda"]);t=ns["matrix"](base["tilde"]);S=br(l[4],l[0])/(br(l[4],l[5])*br(l[5],l[0]));print("S",S); print([(c["id"],c.get("delta")) for c in m["cases"] if c.get("family")])'
```

```text

### 2026-11-16T22:27:41.736205+08:00

```bash
python3 -c 'from pathlib import Path; p=Path("planning/work-order-build-qft13-19-current.md"); print(p.read_text() if p.exists() else "no new work-order file")'
```

```text
no new work-order file

exit_code=0
```
[('nmhv-01', [-224.08895154680695, -89.67822809791689]), ('nmhv-02', [4.976772226989498, -0.08862493008540676]), ('nmhv-03', [-0.591149799762348, -1.1887372470688171]), ('nmhv-04', [18.093696979251682, 14.494087313420746]), ('nmhv-05', [-1.998540385269612, 1.6373129961373263]), ('nmhv-06', [0.22221389266269992, 0.005193417842898326]), ('soft6-0.08', [559.2888517011932, -1491.8188791172813]), ('soft6-0.02', [2845.8487770529296, -5363.48451667921]), ('soft6-0.005', [11950.812562568575, -20850.43271502307]), ('pole234-0.08', [14.000132974421142, -7.81259231450227]), ('pole234-0.02', [46.53394490714406, -26.148234896326358]), ('pole234-0.005', [177.11220019453899, -99.24565294315909])]
soft_ratios
S (-0.33242720693269273+0.3694625256275824j)
[('soft6-0.08', 0.08), ('soft6-0.02', 0.02), ('soft6-0.005', 0.005), ('pole234-0.08', None), ('pole234-0.02', None), ('pole234-0.005', None)]

exit_code=0
```

### 2026-11-16T22:29:28.866853+08:00

```bash
python3 tools/author_qft13_19.py
```

```text
Authored qft-13 through qft-19; truth/schema/metric await Linux calibration.

exit_code=0
```

### 2026-11-16T22:29:29.018287+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 13 14 15 16 17 18 19 --calibrate
```

```text
qft-13 raw/reference/baseline {'reference': 1.2238316049032204e-09, 'baseline': 26.618052126734653} runtime {'reference_seconds': 0.011461083000085637, 'baseline_seconds': 0.0013371250001910084} truth_s 1.440401791999875
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "integration_by_parts_moment_recursion": true, "average_phase_bounded": true, "strong_cancellation_increases_sample_cost": true}
qft-14 raw/reference/baseline {'reference': 6.507387475499469e-10, 'baseline': 2.619567285973766} runtime {'reference_seconds': 0.018551540999851568, 'baseline_seconds': 0.0011930000000575092} truth_s 0.07228625099992314
Traceback (most recent call last):
  File "/work/tools/run_qft13_19_checks.py", line 157, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 155, in main
    for i in a.ids:check_one(i,a.calibrate)
                   ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 145, in check_one
    (ROOT/'checks'/(ident+'-calibration.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
                                                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.12/json/__init__.py", line 238, in dumps
    **kw).encode(obj)
          ^^^^^^^^^^^
  File "/usr/local/lib/python3.12/json/encoder.py", line 202, in encode
    chunks = list(chunks)
             ^^^^^^^^^^^^
  File "/usr/local/lib/python3.12/json/encoder.py", line 432, in _iterencode
    yield from _iterencode_dict(o, _current_indent_level)
  File "/usr/local/lib/python3.12/json/encoder.py", line 406, in _iterencode_dict
    yield from chunks
  File "/usr/local/lib/python3.12/json/encoder.py", line 406, in _iterencode_dict
    yield from chunks
  File "/usr/local/lib/python3.12/json/encoder.py", line 439, in _iterencode
    o = _default(o)
        ^^^^^^^^^^^
  File "/usr/local/lib/python3.12/json/encoder.py", line 180, in default
    raise TypeError(f'Object of type {o.__class__.__name__} '
TypeError: Object of type bool is not JSON serializable

exit_code=1
```

### 2026-11-16T22:30:16.509696+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 14 15 16 17 18 19 --calibrate
```

```text
qft-14 raw/reference/baseline {'reference': 6.507387475499469e-10, 'baseline': 2.619567285973766} runtime {'reference_seconds': 0.02150458300002356, 'baseline_seconds': 0.0018973339999774907} truth_s 0.0419702500000767
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "unitarity_hermiticity_casimirs_gauge_covariance": true}
explicit-color theta N= 2 value= 6.0 seconds= 5.633299997498398e-05
explicit-color theta N= 3 value= 24.0 seconds= 2.879199996641546e-05
explicit-color tetrahedron N= 2 value= 6.0 seconds= 0.0003698750001603912
explicit-color tetrahedron N= 3 value= 36.0 seconds= 0.00027908299989576335
explicit-color tetrahedron N= 4 value= 120.0 seconds= 0.0007427080001889408
explicit-color triangular-prism N= 2 value= 6.0 seconds= 0.026715792000004512
explicit-color triangular-prism N= 3 value= 54.00000000000003 seconds= 0.015219333999993978
explicit-color triangular-prism N= 4 value= 240.0000000000001 seconds= 0.004155624999839347
explicit-color K3-3 N= 2 value= 0.0 seconds= 0.010217042000022047
explicit-color K3-3 N= 3 value= -8.686833737232044e-16 seconds= 0.01964008400000239
explicit-color K3-3 N= 4 value= -1.6879100466855096e-16 seconds= 0.005095707999998922
qft-15 raw/reference/baseline {'reference': 0.0, 'baseline': 21.652157738095237} runtime {'reference_seconds': 0.6139883749999626, 'baseline_seconds': 0.6170215829999961} truth_s 0.09043441699986943
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "nonplanar_zero_graph_cancellation": true, "theta_known_adjoint_casimir": true}
qft-16 raw/reference/baseline {'reference': 6.956032802867774e-13, 'baseline': 22.95323347687499} runtime {'reference_seconds': 0.3973725830001058, 'baseline_seconds': 0.16353416700007983} truth_s 0.046092667000039
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "three_line_color_conservation": true, "nonnegative_soft_intensities": true}
qft-17 raw/reference/baseline {'reference': 9.599622440873136e-13, 'baseline': 1.9158529179807469} runtime {'reference_seconds': 0.2825636260001829, 'baseline_seconds': 0.018970999999964988} truth_s 0.06205870899998445
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "bulk_topology_equals_boundary_flux": true, "bps_bound_and_deformation_cost": false, "non_pure_gauge_boundary_rejected": true}
Traceback (most recent call last):
  File "/work/tools/run_qft13_19_checks.py", line 158, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 156, in main
    for i in a.ids:check_one(i,a.calibrate)
                   ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 151, in check_one
    if not all(checks.values()):raise RuntimeError(ident+' validation failed')
                                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
RuntimeError: qft-17 validation failed

exit_code=1
```

### 2026-11-16T22:31:22.552514+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 17 18 19 --calibrate
```

```text
qft-17 raw/reference/baseline {'reference': 9.599622440873136e-13, 'baseline': 1.9158529179807469} runtime {'reference_seconds': 0.32618283400006476, 'baseline_seconds': 0.019215791000078752} truth_s 0.0699650419999216
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "bulk_topology_equals_boundary_flux": true, "bps_bound_and_deformation_cost": true, "non_pure_gauge_boundary_rejected": true}
qft-18 raw/reference/baseline {'reference': 5.954666384956382e-12, 'baseline': 0.002697504032897863} runtime {'reference_seconds': 0.0016820420000840386, 'baseline_seconds': 0.001444332999881226} truth_s 0.005915832999789927
soft ratios [np.complex128(0.6688636685739383-0.006489510599408722j), np.complex128(0.9098948624087566-0.0077215634381786495j), np.complex128(0.9770097607054966-0.002374980886775816j)] s234 residues [np.complex128(-0.3071680210264039+0.3247251646095536j), np.complex128(-0.2548659627311942+0.2710329442482125j), np.complex128(-0.24265490193088934+0.25743352816502296j)]
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "on_shell_momentum_conservation": true, "little_group_covariance": true, "soft_limit_converges": false, "physical_pole_residue_converges": true}
Traceback (most recent call last):
  File "/work/tools/run_qft13_19_checks.py", line 158, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 156, in main
    for i in a.ids:check_one(i,a.calibrate)
                   ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/work/tools/run_qft13_19_checks.py", line 151, in check_one
    if not all(checks.values()):raise RuntimeError(ident+' validation failed')
                                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
RuntimeError: qft-18 validation failed

exit_code=1
```

### 2026-11-16T22:33:15.081098+08:00

```bash
python3 tools/author_qft13_19.py
```

```text
Authored qft-13 through qft-19; truth/schema/metric await Linux calibration.

exit_code=0
```

### 2026-11-16T22:33:15.198086+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 18 19 --calibrate
```

```text
qft-18 raw/reference/baseline {'reference': 5.6407564150928496e-12, 'baseline': 0.002560925086380524} runtime {'reference_seconds': 0.0013857909998478135, 'baseline_seconds': 0.0012138749998484855} truth_s 0.014220292000118206
soft ratios [np.complex128(0.6688636685739383-0.006489510599408722j), np.complex128(0.9098948624087566-0.0077215634381786495j), np.complex128(0.9770097607054966-0.002374980886775816j), np.complex128(0.9942233484984654-0.0006225396789561376j)] s234 residues [np.complex128(-0.3071680210264039+0.3247251646095536j), np.complex128(-0.2548659627311942+0.2710329442482125j), np.complex128(-0.24265490193088934+0.25743352816502296j)]
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "on_shell_momentum_conservation": true, "little_group_covariance": true, "soft_limit_converges": true, "physical_pole_residue_converges": true}
qft-19 raw/reference/baseline {'reference': 2.349922806575258e-14, 'baseline': 0.9854842971852217} runtime {'reference_seconds': 0.008694750000131535, 'baseline_seconds': 0.0021534170000450104} truth_s 0.12621162499999627
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "solve.py_cli": true, "baseline.py_cli": true, "finite_rational_term_retained": true, "universal_uv_finite_master_constant": true}

exit_code=0
```

### 2026-11-16T22:33:47.705497+08:00

```bash
python3 -c 'from pathlib import Path; print(Path("README.md").read_text()); p=Path("planning/work-order-build-qft13-19-current.md"); print(p.read_text() if p.exists() else "no new work order")'
```

```text

### 2026-11-16T22:33:47.705674+08:00

```bash
rg --files '../../00-老师原始材料/科研探索课程项目'
```

```text
../../00-老师原始材料/科研探索课程项目/附件三_科研任务示例教程.md
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/NOTICE.md
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/task.toml
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/data.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/frozen_model.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/data_manifest.json
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/baseline_recipe.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/recipe_guard.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/train_worker.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/config.json
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/prepare_data.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/environment/requirements.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/provenance/record-2600-manifest.json
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/README.md
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/instruction.md
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tests/score.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tests/test.sh
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tests/frozen_eval.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/optional_prime_sources.json
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/sha256.json
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/summary.tsv
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed0.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed10.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed11.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed1.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed3.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed2.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed6.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed7.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed5.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed4.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/README.md
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed9.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/GH200_seed8.txt
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/train_gpt_bimaxwell_kfac_2600.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/keller/LICENSE
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/keller/train_gpt_simple.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/SOURCES.json
../../00-老师原始材料/科研探索课程项目/附件三_科研任务示例教程.pdf
../../00-老师原始材料/科研探索课程项目/附件二_评分与验收规则.md
../../00-老师原始材料/科研探索课程项目/附件一_Benchmark制作与提交指南.md
../../00-老师原始材料/科研探索课程项目/附件二_评分与验收规则.pdf
../../00-老师原始材料/科研探索课程项目/课程大作业说明.md
../../00-老师原始材料/科研探索课程项目/附件一_Benchmark制作与提交指南.pdf
../../00-老师原始材料/科研探索课程项目/课程大作业说明.pdf
../../00-老师原始材料/科研探索课程项目/tools/检查提交.py
../../00-老师原始材料/科研探索课程项目/tools/course.env.example
../../00-老师原始材料/科研探索课程项目/tools/计算成绩.py
../../00-老师原始材料/科研探索课程项目/tools/quality_score.py
../../00-老师原始材料/科研探索课程项目/tools/汇总结果.py
../../00-老师原始材料/科研探索课程项目/tools/成绩输入示例.json
../../00-老师原始材料/科研探索课程项目/tools/正式测评.sh
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tools/make_profile.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tools/reproduce_record_2600.sh
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tools/fetch_prime_sources.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tools/prepare.sh
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tools/verify_record_2600.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tools/cpu_smoke.py
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/tools/reproduce_record_2600.py
../../00-老师原始材料/科研探索课程项目/template/results.csv
../../00-老师原始材料/科研探索课程项目/template/报告.md
../../00-老师原始材料/科研探索课程项目/template/benchmark.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/task.toml
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/task.toml
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/instruction.md
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/data/README.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/solution/solve.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/MODEL_FORMAT.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/task.toml
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/campaign/campaign.json
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/Dockerfile
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/campaign.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/__init__.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/ledger.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/backends/base.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/backends/live.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/backends/replay.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/backends/__init__.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/backends/twin.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/lab/asb_lab/server.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/model_template.js
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/instruction.md
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/asb/asb.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/asb/js_runner.ts
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/docker-compose.yaml
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/authoring/provenance/DATA_PROVENANCE.md
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/authoring/calibrate_gates.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/authoring/build_fixture.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/README.md
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/instruction.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/solution/reference_solver.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/test.sh
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/test_outputs.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/report.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/js_sandbox.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/artifacts.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/ranking.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/__init__.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/paths.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/points.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/ledger_check.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/scan_report.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/Dockerfile
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/js_runner.ts
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/LICENSE.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/NOTICE
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/LICENSE
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/README.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/task.toml
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/task.toml
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/scripts/prepare.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/scripts/run_native.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/task.toml
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/provenance/upstream-manifest.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/instruction.md
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/upstream-tools/run_local.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/upstream-tools/pyproject.toml
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/upstream-tools/uv.lock
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/instruction.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/task.toml
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/instruction.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/task.toml
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/task.toml
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/task.toml
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/instruction.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/instruction.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/task.toml
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/instruction.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/instruction.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/instruction.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/environment/Dockerfile
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/solution/solve.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/solution/solve.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/tests/score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/tests/test.sh
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/tests/metric.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/tests/quality_score.py
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/environment/public/README.txt

exit_code=0
```
# TheoryPhysicsBench-30

面向课程指定 Codex 的理论物理科学任务集。题目来自用户提供的六门课程教材与习题材料，通过物理建模、数值计算、参数反演等任务改造，交付可独立验证的 Harbor 题包。

## 题集规模

| 学科 | 编号前缀 | 计划题数 | 已有完整开发题包 |
|---|---|---:|---|
| 理论力学 | tm | 5 | tm-01、tm-02 |
| 电动力学 | ed | 5 | ed-01 |
| 热力学与统计物理 | sp | 5 | sp-01 |
| 量子力学 | qm | 5 | qm-01 |
| 量子场论 | qft | 5 | — |
| 广义相对论 | gr | 5 | — |

共 30 道独立问题。理论力学属于理论物理，`tm-01` 的固定端质点链与简正振动辨识保留在本题集中。各题需要不同的物理推理和计算工作，不将同一道题的换参数版本计为多道。

## 已完成开发验证的题目

**tm-01：局部振动观测下的弹簧链损伤辨识。** 从三组含噪位移记录恢复八质点链的九个非均匀刚度与两处软化位置，以参数精度、隐藏运动预测和位置识别共同评分。

- [题面](tasks/tm-01/instruction.md)
- [物理推导和参考解](tasks/tm-01/solution/README.md)
- [教材出处及已有评测对照](checks/tm-01-sources.md)
- [公开材料与隐藏验证划分](checks/tm-01-materials-and-fairness.md)
- [Docker / Harbor 验证记录](checks/tm-01-validation.md)
- [完整校准数据](checks/tm-01-calibration.json)

已完成 Docker Linux 的基线、参考解与评分样例验证，11 项检查全部通过；Harbor 0.24.0 的 oracle=1、nop=0。参考解在此次 4 CPU/4 GB 容器内耗时约 1.67 秒，无需 GPU。

课程指定 Codex 的每题三次独立正式测评在题集冻结后执行。`oracle` 记录用于核对参考解和评分链路，正式模型结果单独保存。

**tm-02：非开普勒中心势中束缚轨道的拱点进动。** 从有效势求转折点、径向周期与完整方位角，处理端点奇性，并与独立运动方程积分核对。近圆近似基线误差 10.4201 个百分点，完整轨道积分参考误差约 1.07e-11；11 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/tm-02/instruction.md)、[推导](tasks/tm-02/solution/README.md)、[验证记录](checks/tm-02-validation.md)。

**sp-01：平均场铁磁体的多分支平衡与亚稳态。** 找全驻点，区分局部稳定性与平衡态，计算分支磁化率。Landau 基线误差 3.1082，完整参考约 9.49e-14；13 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/sp-01/instruction.md)、[推导](tasks/sp-01/solution/README.md)、[验收记录](checks/sp-01-validation.md)。

**qm-01：非对称双 δ 势阱的束缚态与空间局域化。** 恢复全部负能态及左半轴概率，处理近阈值浅态和非对称混合。弱耦合基线误差 41.8244，完整参考约 1.00e-13；11 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/qm-01/instruction.md)、[推导](tasks/qm-01/solution/README.md)、[验收记录](checks/qm-01-validation.md)。

**ed-01：点电荷与介质核壳球的反作用、自力反号及径向平衡。** 由多极边界匹配计算极化能、自力和全部径向平衡点，以尾界保证近表面收敛。偶极基线误差 65.6807，完整参考约 8.16e-10；14 项 Linux 检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/ed-01/instruction.md)、[推导](tasks/ed-01/solution/README.md)、[验收记录](checks/ed-01-validation.md)。

## 目录

```text
tasks/       Harbor 任务；每题含题面、环境、参考解和 verifier
checks/      出处、校准、材料划分与验收证据
runs/        已保存的 Harbor 运行记录
planning/    教材 OCR 索引和选题笔记
tools/       本地制作与检查工具
```

Agent 镜像只带该题的公开材料；`solution/` 与 `tests/private/` 供参考解及独立 verifier 使用。原始教材保留在原路径，题包不附扫描教材或习题答案页。

no new work order

exit_code=0
```

### 2026-11-16T22:34:20.795771+08:00

```bash
cat '../../00-老师原始材料/科研探索课程项目/附件一_Benchmark制作与提交指南.md' '../../00-老师原始材料/科研探索课程项目/附件二_评分与验收规则.md'
```

```text
# 附件一：Benchmark制作与提交指南

这份指南从选题讲到提交，配合材料包中的`template/`和`tools/`使用。作业要求见[主说明](课程大作业说明.md)，评分规则见[附件二](附件二_评分与验收规则.md)。建议先选一道代表性题目走完全流程，再扩展成整套题集。

**制作顺序：确定研究目标 → 写题面 → 准备探索与验证材料 → 跑通基线和参考解 → 封装与检查 → 冻结 → 三次正式测评与提交。**

| 谁或什么 | 做什么 |
|---|---|
| 出题小组 | 选择研究问题，准备题面、材料、参考解和评分程序 |
| Codex（Agent） | 阅读公开材料，探索并提交解答 |
| 评分程序（verifier） | 作答结束后独立检查实际产物，计算本题指标 |
| Harbor | 为每次作答建立运行环境，作答结束后启动评分程序 |
| 助教 | 复核题目与评分，在独立环境中重新测评 |

<a id="topic"></a>

## 一、从研究主题组织题集

主题应落到具体的研究能力，例如实验选择、模型辨识、竞争解释、材料互证、统计分析、推导构造或算法改进。以“带噪声实验曲线的参数研究”为例：

| 需要设计的内容 | 示意 |
|---|---|
| 共同能力目标 | 面对带噪声的实验曲线，选择合理方法估计参数并检验模型 |
| 10至20道，至少10道有效 | 来自不同反应体系、观测条件或研究约束的独立实例 |
| 每题公开材料 | 反应模型与单位、开发曲线、拟合起点、开发误差命令 |
| 每题研究选择 | 怎样利用约束、选择初始化和拟合方法 |
| 每题交付 | 读取该题新曲线并输出参数的程序 |
| 每题最终验证 | 用预先留出的曲线重算误差并检查参数约束 |
| 整套结果分析 | 哪类体系表现较好，哪些条件下失败，参考方法的优势在哪里 |

**怎样判断题目独立。** 每题有自己的研究材料、待解决问题、参考结果和评分依据，能单独启动Codex作答。各题可以共享数据来源、工具、容器、参考方法和评分代码。两道曲线题分别研究不同反应体系、需要判断不同的参数约束，可以算两道题；同一条曲线只换随机种子、文件名或提示词，或者一道题里的多个小问、多条留出测试曲线，都只算一道题。

在 `benchmark.json` 中登记题目ID、路径、名称与研究差异；相近任务、来源和本组贡献的比对材料放在 `checks/`。

<a id="instruction"></a>

## 二、写一份能开始做的题面

`instruction.md`是Codex收到的任务说明，应让它独立收到后就能开始做。模板按下面六栏组织：

| 栏目 | 写清楚什么 | 曲线参数研究的例子 |
|---|---|---|
| 研究问题 | 背景、已知条件、待作出的研究选择 | 从带噪声曲线估计反应参数，检验估计是否稳定 |
| 材料与工具 | 容器内路径、字段、单位、工具及最小用法 | 提供反应模型、开发曲线和数据读取例子 |
| 探索反馈 | 从哪里起步，可以改什么，运行后看到什么 | 运行常规拟合，得到开发曲线误差和约束检查结果 |
| 最终产物 | 文件位置、接口、字段与有效值 | 提交读取新曲线并输出参数的程序 |
| 评价办法 | 主指标、固定条件、最终验证与容差 | 在留出曲线上重算误差，同时检查参数范围 |
| 时间与资源 | Agent、执行和评分的时限与硬件需求 | 使用CPU，明确单题探索和评分时限 |

专业概念解释到完成任务所需的程度，单位、符号和数据含义写在材料旁边。起点命令要在干净环境中实际运行一次，确认能返回可用反馈。完整的任务示例见[附件三](附件三_科研任务示例教程.md)。

<a id="validation"></a>

## 三、准备探索材料与最终验证

先想清楚要测什么：方法能否处理新情况，还是一个给定问题能否被解决。

- **检验方法能否处理新样本**：公开开发材料、起点和反馈办法，在未用于调参的新案例上重算指标。按对象、时间或实验批次划分材料，检查近重复记录和未来信息泄漏；参考解与Codex都只用开发材料调参。
- **解决一个固定实例**（固定优化、单个问答、构造或证明）：可以公开完整题设，通过独立执行、重算或核对证据、约束、证书来检验。

例如研究“新曲线上的参数估计”时，开发曲线用于选方法和调参，留出曲线检验泛化；研究“一条给定曲线是否存在两组同样合理的参数解释”时，可以公开这条曲线，用复算和约束检查核验论证。

公开材料应支持一次有用的尝试与反馈，例如开发误差命令、开发集分数、实验接口（写清返回内容和查询上限，并保存记录）、资料索引或约束检查。各类材料的可见范围如下：

| 材料 | 出题小组 | 正式作答的Codex | 助教 |
|---|---|---|---|
| 题面、公开数据、工具与开发反馈 | 可见 | 可见 | 可见 |
| 指标、评分规则、基线值/参考值与容差 | 可见 | 可见 | 可见 |
| 完整参考解、报告、检查记录 | 可见 | 不提供 | 可见 |
| 最终测试中保密的案例或答案 | 仅用于最终验证 | 不提供 | 可见 |

材料怎样划分、谁能访问、最终验证覆盖什么，写入`checks/`。最终测试答案只由评分环境读取，候选程序与答案隔离执行。

<a id="reference"></a>

## 四、准备基线、专家参考与评分器

| 部分 | 用途 | 曲线题中的例子 |
|---|---|---|
| 简单基线 | 合理、容易实现的起点 | 常规拟合程序 |
| 专家参考解 | 相同条件下效果较好的方案 | 利用物理约束的拟合程序 |
| 评分器 | 读取或运行产物，独立计算主指标 | 对照最终答案重算参数误差 |

- 每题须有可复核的专家参考解，可以由本组完成，也可以采用公开专家方案并注明来源。定量题提供方法、代码与结果；定性题提供研究分析、证据出处与评分要点。
- 定性题同样需要简单基线，例如只整理直接事实与出处的朴素答案。基线与专家参考用同一评分流程，得到本题的b、h。
- 定性题评分看证据定位、事实与计算、推论和关键材料处理，允许有充分依据的不同结论；文采、立场和与参考文字的相似度不作为主要标准。评分流程须可执行，把公开的分项标准汇总成原始指标。采用AI评分时，固定评分模型、版本、提示与输出格式，提供评分代码并保存逐项依据。
- 输出格式、成功条件、容差和多案例汇总办法提前确定，登记在 `tests/metric.json`。

### 填写本题指标

| 字段 | 填写方式 |
|---|---|
| `kind` | `binary`：能否完成；`continuous`：质量有高低 |
| `metric_name`、`unit` | 原始主指标与单位，如平均参数误差、%、秒或证据评分 |
| `direction` | 连续题填 `maximize` 或 `minimize` |
| `baseline`、`reference` | 实测简单基线b、专家参考h；二元题分别为0、1 |
| `tolerance` | 连续题的原单位容差及依据 |

先实测简单基线与专家参考，再填数值；b、h、x使用同一单位，7.6%填7.6。例如基线平均误差10%、参考误差2%，可以写成下面这样，容差按本题指标的实际精度确定：

```json
{
  "kind": "continuous",
  "metric_name": "平均参数误差",
  "unit": "%",
  "direction": "minimize",
  "baseline": 10.0,
  "reference": 2.0,
  "tolerance": 0.05
}
```

### 把评价办法写进评分程序

在`tests/score.py`的`evaluate()`中读取或运行实际产物，重算主指标，并输出支持判分的明细。模板随后调用统一的`quality_score.py`，生成`metrics.json`和`reward.txt`。两者方向相反：Harbor的reward越高，表示解答越好；课程计分用`metrics.json`中的原始指标计算难度系数，Codex越难做好，单题得分越高。

候选产物违反题意时，返回无效产物及具体原因；评分器本身出错时保留异常供排查。


<a id="packaging"></a>

## 五、封装任务并检查运行

### 运行时间与资源

- 全部题各运行一次为一轮，每轮累计≤12小时（43200秒），包括探索、方案执行和最终评分。各题提前登记Agent与verifier时限，整套时限之和不超过43200秒。基线与参考解各跑一轮，同样遵守此上限。
- 耗时逐题相加，平行执行也累计，正常API等待计入；首次环境构建和公共数据下载单独记录。
- GPU最多单块80GB A100（`gpus=1`、`gpu_types=["A100"]`），纯CPU任务设 `gpus=0`。写清CPU、内存、磁盘需求，固定依赖、数据版本、随机种子与容差。
- 可以用离线资料、数据回放、轻量模拟或统一提供的固定检查点开展研究。可在本机开发，正式测评使用Linux与Docker。

### 从模板建立任务目录

复制材料包中的 `template/` 并改名为 `group-XX`。模板提供10题骨架，最多扩展到20题；更新题目ID、`[task].name`和登记表，保持名称唯一。

```
group-XX/
├── benchmark.json     # 主题、题目ID、路径、名称与覆盖说明
├── tasks/
│   ├── task-01/
│   │   ├── instruction.md   # 本题公开题面，文中使用容器路径
│   │   ├── task.toml        # 时限、资源与产物路径
│   │   ├── environment/     # 依赖和公开材料
│   │   ├── solution/        # 本题完整参考解
│   │   └── tests/           # 评分程序、metric.json、最终验证材料（private/）
│   └── ...                  # 10至20个独立任务目录
├── 报告.md            # 正文最多4页
├── results.csv        # 学生正式测评，每题3行
├── checks/            # 逐题检查、来源、划分与公平性记录
└── runs/              # 全部原始运行记录
```

- 每个任务目录须能独立构建和运行；共用代码复制到所需目录，或通过固定版本的基础镜像提供。
- `environment/` 只放依赖和公开材料；参考解放在 `solution/`，最终答案放在 `tests/private/`。
- 模板以 `answer.json` 示范输出；改为提交程序或模型时，同步修改 `task.toml` 的artifacts与评分程序。
- 模板每题默认Agent 1200秒、verifier 600秒，可按研究需要重新分配。verifier默认无网络；评分需要联网（如AI评分）时，声明依赖、调整网络配置并写入复现说明，密钥由运行环境注入。
- `tests/quality_score.py` 是课程统一换算函数，保持原样。

题面使用容器内路径，对照关系如下：

| 提交包中的位置 | 运行时的用途 |
|---|---|
| `tasks/task-01/instruction.md` | 本题直接提供给Codex的题面 |
| `tasks/task-01/environment/public/demo.csv` | 构建后位于Agent容器 `/app/data/demo.csv` |
| `tasks/task-01/solution/solve.sh` | 参考解阶段执行 `/solution/solve.sh` |
| `tasks/task-01/tests/test.sh` | 评分阶段执行 `/tests/test.sh` |

### 先跑通参考解与空提交

在Linux主机准备Python 3.12及以上、uv和Docker。确认`python3 --version`为所需版本，启动Docker后运行以下命令（将路径替换为实际绝对路径）：

```bash
cd /absolute/path/group-XX
uv tool install 'harbor==0.24.0'
harbor run -p "$PWD/tasks" -a oracle \
  --n-attempts 1 --n-concurrent 1 --max-retries 0 \
  --jobs-dir "$PWD/runs/reference"
harbor run -p "$PWD/tasks" -a nop \
  --n-attempts 1 --n-concurrent 1 --max-retries 0 \
  --jobs-dir "$PWD/runs/empty"
```

`oracle` 逐题执行 `solution/solve.sh`，`nop` 检查空提交。第一次运行建议只选一题（`-p`改为该题目录并换新运行目录），打开评分记录中的 `metrics.json` 与 `reward.txt`，对照一个具体产物追踪“输入材料 → 输出 → 原始指标 → Harbor评分”。

### 检查评分是否反映真实质量

| 检查材料 | 要确认的结果 |
|---|---|
| 参考解 | 达到登记的参考表现，材料与执行资源符合要求 |
| 空提交 | 缺少有效产物时解题得分为0 |
| 实质错误解 | 格式正确但违反题意的结果被识别 |
| 合法替代解 | 不同方法或等价表示得到正常评分 |

每题都要跑通参考解和空提交，并检查本题特有的规则；错误解和合法替代解的检查可按评分器类型复用。命令、产物和检查结果放在 `checks/`。


<a id="run"></a>

## 六、冻结、正式测评与提交

### 冻结

开发试跑按第三节的材料划分进行，保存运行记录和选题调整依据。完成来源、近重复、评分与参考解检查后，可以集中补正一次，然后冻结整套题集的题目、版本、指标、参考解、时限和Codex配置。冻结后每题从相同的公开起点、新会话和干净工作区独立作答3次，全部正式记录纳入结果。

### 预检、正式测评与汇总

```bash
cd /absolute/path/科研探索课程项目
python3 tools/检查提交.py /absolute/path/group-XX            # 结构预检，输出整套及逐题哈希
bash tools/正式测评.sh /absolute/path/group-XX /absolute/path/course.env   # 每题3次
python3 tools/汇总结果.py /absolute/path/group-XX            # 生成 results.csv
python3 tools/检查提交.py /absolute/path/group-XX --final    # 最终检查
```

- `course.env` 由 `tools/course.env.example` 另存，设置 `MODEL=gpt-6.1-sol`、`REASONING_EFFORT=max` 和助教发布的 `CLI_VERSION`，密钥通过运行环境配置。
- 测评脚本按登记表每题运行3次，单并发、无自动重试，写入 `runs/codex/`；目录已存在时停止。
- 汇总工具发现异常、缺记录或分数矛盾时会列出位置并停止，按[附件二第五节](附件二_评分与验收规则.md#failures)处理后再做最终预检。
- 提交整个 `group-XX` 目录的压缩包，清理其中的密钥；引用的代码和数据保留来源与许可。

### 报告

`template/报告.md` 提供空表，正文最多4页；题面、长命令和日志留在任务包中，用路径引用。开头写小组名、benchmark名称和成员分工，正文分三部分：

1. **主题与原创设计**：共同科研目标与研究场景；各题覆盖的研究对象、条件、证据或难点（索引见 `benchmark.json`）；最接近的已有benchmark、重合处、本组实质差异与价值，以及论文、数据、代码等来源。
2. **制作与验证**：公开材料与反馈、基线、参考解和评分程序如何组织；逐题指标b/h、方向、单位、容差；开发/最终材料划分与防泄漏办法，或固定实例、定性论证的核验办法；环境、数据版本、种子、资源与每轮耗时；各题检查记录。
3. **结果、分析与改进**：冻结版本与哈希；统一配置与运行日期；每题3次原始结果、难度系数及单题得分；结合具体产物或日志分析代表性的成功与失败，区分事实与待验证解释；局限与一项具体改进；异常与额外尝试的原因、处理和记录路径。


<a id="fields"></a>

## 七、登记与结果字段速查

**benchmark.json**：`name`、`research_goal`（整套名称与共同科研能力目标）；`tasks` 数组为10至20项，每项填 `id`（稳定唯一）、`path`（固定为 `tasks/ID`）、`title`、`coverage`（研究对象或难点，与其他题的实质差异）。

**results.csv / ta_results.csv**：

| 字段 | 填写方式 |
|---|---|
| `task_id` | 与冻结登记表一致 |
| `config` | 学生为 `codex`；助教为 `ta_codex` |
| `run` | 每题恰好1、2、3 |
| `raw_metric` | 评分器计算的原始值，缺少时填null |
| `score` | 由原始指标换算的Harbor解答表现，越好越高 |
| `seconds` | Agent执行与verifier耗时之和 |
| `trial_dir` | 指向 `runs/` 下原始运行目录的相对路径 |
| `status` | `completed`、`invalid`（无效产物）、`agent_error`、`timeout`；后三种Harbor解答表现为0 |

所有题run=1的耗时之和为第1轮累计，各轮≤43200秒。助教结果写入`ta_results.csv`和`runs/ta-codex/`。


<a id="sources"></a>

## 进一步阅读

这些材料可帮助理解公开起点、探索反馈、最终测试与独立复现的组织方式。

- [RE-Bench](https://arxiv.org/html/2411.15114)：公开起点、探索评估与最终测试。
- [MLE-bench](https://arxiv.org/html/2410.07095v1)：题目、数据、提交与最终评价。
- [PaperBench](https://arxiv.org/html/2504.01848v1)：提交后在新环境中独立复现。
- [Harbor评分器文档](https://docs.harborframework.com/tasks/verifier)：评分入口和reward，课程使用0.24.0。
# 附件二：评分与验收规则

本附件说明成绩怎样计算、助教怎样验收复测，以及失败和故障怎样处理。任务制作与运行命令见[附件一](附件一_Benchmark制作与提交指南.md)。

满分100分：**完整性30分＋创新性20分＋题目数量与难度50分。** 前两项评价整套benchmark；第三项逐题计算，最终采用助教每题3次复测的结果，学生自测结果用于分析和预估。

<a id="manual-scores"></a>

## 一、完整性与创新性

### 完整性（30分）

| 项目（各10分） | 主要依据 |
|---|---|
| 题集与实验设计 | 主题明确、覆盖有依据；逐题研究选择、公开材料、指标与最终验证合理；公平性和评分检查充分 |
| 复现与交付 | 全部任务在规定条件下独立运行，参考解可复核；代码、数据、环境与每题3次记录完整 |
| 报告与结果分析 | 整体与逐题结果清楚，结合实际产物解释差异，分析典型成功与失败、局限及改进 |

每项以0、5、10分为参考，分别对应核心工作缺失或无法核查、基本完成但有明显不足、充分可靠，可给中间分。

### 创新性（20分）

| 参考分 | 大体标准 |
|---|---|
| 20 | 围绕真实科研需求形成鲜明的题集设计，并用题目、产物或实验说明新增检验价值 |
| 15 | 新增的研究选择、约束、覆盖范围或验证目标明确，与相近benchmark的差异及作用说明充分 |
| 10 | 有合理、可辨认的本组设计，新增研究内容或检验价值较有限 |
| 0 | 本组设计贡献缺少有效说明或依据 |

报告中按“最近已有benchmark - 本组实质差异 - 新增价值及证据”说明贡献，并落实到具体题目。助教可在参考档之间给分。


<a id="quality"></a>

## 二、题目数量与难度（50分）

最多20道题计分，每道有效题得1至2.5分。想拿高分只有两条路：多出有效题，提高题目难度；20道困难题即可拿满50分。

> 单题得分 Sᵢ = 1 + 1.5 × Dᵢ（Dᵢ为难度系数，取0至1，题目越难越接近1）
>
> 题目总分 = S₁ + S₂ + … + Sₙ（n为有效题数，n ≤ 20）

| 题目 | Codex的表现 | 难度系数 | 单题得分 |
|---|---|---|---|
| 简单题 | 达到或超过专家参考 | 0 | 1分 |
| 中等题 | 完成基线到专家参考之间一半的改善 | 0.5 | 1.75分 |
| 困难题 | 只达到基线或更差 | 1 | 2.5分 |
| 无效题 | 未通过质量验收 | — | 0分 |

计分遵守四条规定：

1. **登记10至20题。** 至少10道为有效独立题；登记表最多20题，表外的题目不参与计分。
2. **有效题越多，分数越高。** 20题以内，每多一道有效题至少多1分。
3. **题目越难，分数越高。** 难度系数由基线、专家参考和助教的3次Codex复测计算，方法见下文。
4. **计分题目提前冻结。** 冻结登记的题目全部计分，不允许看到测试结果后替换题目，也不允许从更多题中挑出得分最高的20道。

### 难度系数怎样计算

先对助教每次复测的原始指标计算难度系数，再取三次平均。简单基线为b、专家参考为h、Codex某次结果为x，三者使用同一指标和单位。将公式结果限制在0至1之间：

| 题目指标 | 单次难度系数 |
|---|---|
| 越大越好，如准确率 | clip((h−x)÷(h−b), 0, 1) |
| 越小越好，如误差 | clip((x−h)÷(b−h), 0, 1) |
| 二元题：能否完成 | 完成为0；未完成为1 |

`clip(..., 0, 1)`表示低于0按0、高于1按1。有效题的无效产物、Agent错误或超时，单次难度系数为1；平台和评分故障按第五节处理。连续指标先分别截断，再取三次平均；多个最终案例先汇总原始指标。专家参考相对基线的改善须超过容差。

### 用一道题算一遍

基线误差10%，专家参考误差2%，Codex三次误差为7.6%、6.8%、6.0%，误差越小越好：

| 复测 | 难度系数 |
|---|---|
| 第1次 | (7.6−2)÷(10−2) = 0.7 |
| 第2次 | (6.8−2)÷(10−2) = 0.6 |
| 第3次 | (6.0−2)÷(10−2) = 0.5 |

平均难度系数为0.6，**本题得分＝1＋1.5×0.6＝1.9分**。

不同题数和难度下的题目总分：

| 有效题数 | 全部简单 | 全部中等 | 全部困难 |
|---|---|---|---|
| 10 | 10分 | 17.5分 | 25分 |
| 15 | 15分 | 26.25分 | 37.5分 |
| 20 | 20分 | 35分 | 50分 |

例如10道有效题的平均难度系数都是0.6，题目总分为19分；再加完整性26分、创新性16分，总分为61分。

<a id="integrity"></a>

## 三、原创性与公平性

### 原创与复用

原创性看整套benchmark的研究目标、题目组织、材料设计和能力检验。可以使用公开论文思路、算法、数据、代码和Harbor框架，但要保留来源。

| 做法 | 判断 |
|---|---|
| 设计有明确研究目标的题集，选择有实质差异的实例 | 符合要求，说明覆盖范围与本组贡献 |
| 共用工具、环境、参考方法和评分代码 | 可以复用，各题材料与结果分别核验 |
| 同一实例只换种子、数字、名称、格式或近重复材料 | 不增加有效题数 |
| 翻译已有benchmark题，或仅加Harbor外壳 | 不构成原创 |
| 未注明挪用他人题面、核心设计、代码或结果 | 属于抄袭 |

报告说明最接近的已有任务、本组的实质差异和证据；未找到相近任务时，记录检索关键词与范围。助教会逐题核对来源，疑似抄袭的证据交给小组说明，经两位助教共同确认后，**整份大作业记0分**。照搬现有题或课程示例、仅作表面修改的，同样处理。判断以实质内容为依据，文字相似率只用作检索线索。

### 公平比较

参考解与Codex使用相同的任务信息、执行资源和最终评分办法。参考方案提前开发，注明来源和工具使用。以下做法属于不公平：

- 读取最终标签、按隐藏案例编号回填答案，或将答案混入训练数据；
- 只给参考方案额外数据、私有服务或未申报算力；
- 只认参考答案的字面写法，误拒等价正确解，或绕过实际产物伪造分数；
- 换弱模型、挑选失败记录、伪造运行记录，看到结果后删题、换题或改指标、种子和阈值；
- 用接近参考的强方案充当“简单基线”，压小计分公式的分母；
- 在正式作答会话中提供参考解、隐藏答案或其他题的作答记录。

两位助教核实并听取小组说明后，确认故意操纵且实质影响结果的，**整份大作业记0分**。


<a id="acceptance"></a>

## 四、助教验收与复测

两位助教分工完成全量验收：主审逐题检查并组织复测，另一位复核验收记录与成绩；争议、异常和违规由两人共同核实。助教可以用AI辅助阅读材料、检索和查代码，结论以可核查的来源、产物与复测记录为准。

| 验收项目 | 对全部题目执行的检查 |
|---|---|
| 创新性与来源 | 检索相近benchmark、任务、数据和代码，核对本组差异与题间近重复 |
| 研究质量与独立性 | 确认科研用途和研究选择，核实有效独立题数 |
| 题面与材料 | 只凭公开资料核对输入、工具、反馈、输出、指标和时限 |
| 基线与参考 | 在干净环境复跑基线、参考解与空提交；定性题逐项核查证据与论证要点 |
| 评分与最终验证 | 检查实际产物、四类评分检查与本题特有规则，核对数据划分、标签隔离或固定实例的核验办法 |
| 学生记录 | 核对3次运行的配置、日志、产物、原始指标、Harbor评分与耗时 |

每题保留验收结论、证据路径和复测记录；完整性三项与创新性各写一两句评分依据。

### 独立复测

助教按冻结题集对每题独立运行3次Codex，每次使用相同的公开起点、新会话与干净工作区。做题的Codex只接收公开材料。在材料包根目录执行：

```bash
bash tools/正式测评.sh /absolute/path/group-XX /absolute/path/course.env --ta
python3 tools/汇总结果.py /absolute/path/group-XX --ta
python3 tools/检查提交.py /absolute/path/group-XX --final --ta
```

结果写入 `runs/ta-codex/` 和 `ta_results.csv`（每题3行），与学生记录分开保存。

默认组内同分；贡献明显失衡时，由两位助教核实调整并说明依据，学生可按具体条目申诉。


<a id="failures"></a>

## 五、失败、故障与补正

| 情况 | 处理 |
|---|---|
| 题目有效，Codex无有效产物、违反约束、报错或超时 | 该次难度系数计1，保留原因；缺少原始指标填null |
| 平台/API、机器、依赖或评分程序故障 | 保存原记录，修复后按统一条件补跑或重评 |
| 题目无法公平验证、参考不可复现或无有效提升 | 该题无效，得0分，保留原始记录 |
| 缺题或近重复题 | 同上 |
| 经两位助教确认的抄袭或故意操纵 | 整份记0分 |

冻结后保留全部题目及有效失败，禁止事后替换或择优计分。评分程序有实现错误时，按原协议统一重评受影响的产物；错误影响了Agent作答的，统一重跑受影响的运行，并记录版本与原因。实质改变题意、材料或目标的修改，该题按无效处理。

### 自动汇总停止后怎样处理

1. **核实原因。** 保留原日志和产物，把任务ID、run编号、原trial路径、异常依据和处理结论记入`checks/`，交助教核实。
2. **有效失败保留原记录。** 有效的超时或Agent错误，`status`填`timeout`或`agent_error`，`score`填0，没有原始指标时`raw_metric`填null。
3. **故障只补受影响的那一次。** 仅评分出错时，重评原产物并另存重评记录；需要重新作答时，单独补跑该次运行，并登记“原trial → 替代trial”。
4. **整理CSV后做最终预检。** 每题run仍为1、2、3，分别指向有效失败的原trial、故障后的替代trial或正常记录；`seconds`填Agent与verifier实际耗时之和（仅重评时用原Agent耗时加新verifier耗时）。然后运行`检查提交.py --final`，助教加`--ta`。

补跑沿用冻结配置。例如学生补跑`task-01`第2次：

```bash
cd /absolute/path/group-XX
source /absolute/path/course.env
harbor run -p "$PWD/tasks/task-01" -a codex -m "$MODEL" \
  --ak "version=$CLI_VERSION" --effort "$REASONING_EFFORT" \
  --n-attempts 1 --n-concurrent 1 --max-retries 0 \
  --jobs-dir "$PWD/runs/codex/retry-task-01-run-2"
```

助教补跑把最后一行改为`runs/ta-codex/`内的新目录。CSV的`trial_dir`填实际trial目录相对小组根目录的路径，例如`runs/codex/retry-task-01-run-2/<job>/<trial>`。所有尝试均留档。

exit_code=0
```

### 2026-11-16T22:38:02.634843+08:00

```bash
python3 tools/author_qft13_19.py
```

```text
Authored qft-13 through qft-19; truth/schema/metric await Linux calibration.

exit_code=0
```

### 2026-11-16T22:38:02.766137+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0 -e OPENBLAS_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft13_19_checks.py 13 14 15 16 17 18 19 --calibrate
```

```text
qft-13 raw/reference/baseline {'reference': 1.2238316049032204e-09, 'baseline': 26.618052126734653} runtime {'reference_seconds': 0.00935579199995118, 'baseline_seconds': 0.0011489999999412248} truth_s 0.8678521250001268
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "public_physical_explorer_runs": true, "solve.py_cli": true, "baseline.py_cli": true, "integration_by_parts_moment_recursion": true, "average_phase_bounded": true, "strong_cancellation_increases_sample_cost": true}
qft-14 raw/reference/baseline {'reference': 6.507387475499469e-10, 'baseline': 2.619567285973766} runtime {'reference_seconds': 0.015194792000102098, 'baseline_seconds': 0.0008254169999872829} truth_s 0.023858459000166476
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "public_physical_explorer_runs": true, "solve.py_cli": true, "baseline.py_cli": true, "unitarity_hermiticity_casimirs_gauge_covariance": true}
explicit-color theta N= 2 value= 6.0 seconds= 5.866699984835577e-05
explicit-color theta N= 3 value= 24.0 seconds= 4.024999998364365e-05
explicit-color tetrahedron N= 2 value= 6.0 seconds= 0.00011020800002370379
explicit-color tetrahedron N= 3 value= 36.0 seconds= 9.912500013342651e-05
explicit-color tetrahedron N= 4 value= 120.0 seconds= 0.0002651659999628464
explicit-color triangular-prism N= 2 value= 6.0 seconds= 0.00807058300006247
explicit-color triangular-prism N= 3 value= 54.00000000000003 seconds= 0.007632708000073762
explicit-color triangular-prism N= 4 value= 240.0000000000001 seconds= 0.0030045409998820105
explicit-color K3-3 N= 2 value= 0.0 seconds= 0.012659957999858307
explicit-color K3-3 N= 3 value= -8.686833737232044e-16 seconds= 0.0071723329999713314
explicit-color K3-3 N= 4 value= -1.6879100466855096e-16 seconds= 0.00410279199991237
qft-15 raw/reference/baseline {'reference': 0.0, 'baseline': 21.652157738095237} runtime {'reference_seconds': 0.4579436250000981, 'baseline_seconds': 0.44917258300006324} truth_s 0.04839816699995936
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "public_physical_explorer_runs": true, "solve.py_cli": true, "baseline.py_cli": true, "nonplanar_zero_graph_cancellation": true, "theta_known_adjoint_casimir": true}
qft-16 raw/reference/baseline {'reference': 6.956032802867774e-13, 'baseline': 22.95323347687499} runtime {'reference_seconds': 0.26967149999995854, 'baseline_seconds': 0.1410278749999634} truth_s 0.03574208399982126
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "public_physical_explorer_runs": true, "solve.py_cli": true, "baseline.py_cli": true, "three_line_color_conservation": true, "nonnegative_soft_intensities": true}
qft-17 raw/reference/baseline {'reference': 9.599622440873136e-13, 'baseline': 1.9158529179807469} runtime {'reference_seconds': 0.2693504999999732, 'baseline_seconds': 0.018018250000068292} truth_s 0.058723332999989
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "public_physical_explorer_runs": true, "solve.py_cli": true, "baseline.py_cli": true, "bulk_topology_equals_boundary_flux": true, "bps_bound_and_deformation_cost": true, "non_pure_gauge_boundary_rejected": true}
qft-18 raw/reference/baseline {'reference': 5.6407564150928496e-12, 'baseline': 79.03318228032632} runtime {'reference_seconds': 0.0013696660000732663, 'baseline_seconds': 0.0013390420001542225} truth_s 0.005726417000005313
soft ratios [np.complex128(0.6688636685739383-0.006489510599408722j), np.complex128(0.9098948624087566-0.0077215634381786495j), np.complex128(0.9770097607054966-0.002374980886775816j), np.complex128(0.9942233484984654-0.0006225396789561376j)] s234 residues [np.complex128(-0.3071680210264039+0.3247251646095536j), np.complex128(-0.2548659627311942+0.2710329442482125j), np.complex128(-0.24265490193088934+0.25743352816502296j)]
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "public_physical_explorer_runs": true, "solve.py_cli": true, "baseline.py_cli": true, "on_shell_momentum_conservation": true, "little_group_covariance": true, "soft_limit_converges": true, "physical_pole_residue_converges": true}
qft-19 raw/reference/baseline {'reference': 2.349922806575258e-14, 'baseline': 0.9854842971852217} runtime {'reference_seconds': 0.007899541999904613, 'baseline_seconds': 0.002019249999875683} truth_s 0.11877125000000888
{"linux_environment": true, "reference_matches_independent_truth": true, "reference_improves_baseline": true, "course_quality_unchanged": true, "baseline_zero_reference_one": true, "independent_truth_full_credit": true, "reordered_same_score": true, "invalid_rejected": true, "wrong_values_penalized": true, "wrong_labels_penalized": true, "feedback_accepts_reference": true, "verifier_entrypoint": true, "public_physical_explorer_runs": true, "solve.py_cli": true, "baseline.py_cli": true, "finite_rational_term_retained": true, "universal_uv_finite_master_constant": true}

exit_code=0
```

### 2026-11-16T22:40:27.267616+08:00

```bash
python3 tools/write_qft13_19_status.py
```

```text
Wrote seven validation reports and planning/status-qft-13-19.md from saved all-pass Linux evidence.

exit_code=0
```

### 2026-11-16T22:46:05.545625+08:00

```bash
python3 -c 'from pathlib import Path; ps=sorted(Path("planning").glob("*qft*13*19*")); print("\n".join(str(p) for p in ps)); p=Path("planning/work-order-build-qft13-19-current.md"); print(p.read_text() if p.exists() else "current work order not found")'
```

```text
planning/status-qft-13-19.md
planning/work-order-build-qft-13-19.md
current work order not found

exit_code=0
```

### 2026-11-16T22:46:17.027694+08:00

```bash
cat planning/work-order-build-qft-13-19.md
```

```text
# 实施任务：QFT-13 至 QFT-19

用户要求实际完成整个50题Harbor benchmark。你负责 qft-13 至 qft-19 共7题，不能只做选题。

先读 planning/qft-expansion-20-selection.json、qft-expansion-20-audit.md 和来源评审；原书已提取在planning/source-notes/qft-gelis-all.txt。参照 tasks/qft-04 的独立Harbor结构，每题交付题面、固定依赖环境、公开模型和反馈、参考代码及推导、合理朴素baseline、课程原版quality_score、独立私有真值和评分器、校准和错误/等价/空提交回归。参考与真值不能同源函数重算。

QFT13 complex Langevin分支；14 Wong路径序；15 large-N颜色拓扑；16色守恒软天线；17限定单一构型族并用边界绕数和体积拓扑荷双路线；18六点NMHV；19 D维cuts的一圈有理项。完整来源和研究判断，非换参数重复；QFT16不能将角序当作总辐射逐点硬零，QFT19不能将四维cuts零当振幅零。

每题4CPU4GiB0GPU，agent暂720秒、verifier120秒，整体50题<=43200秒；必要时报告具体实测后重新分配。只写本组tasks及专属tools/checks/provenance，状态 planning/status-qft-13-19.md。所有shell执行前commentary展示，统一 python3 tools/run_logged.py --log checks/qft-13-19-command-log.md -- COMMAND。本地Mac/Docker，不连远程、不用GPU、不推送、不停止他人容器。

需实际做完7题并Linux校准，而非空目录。每完成一题继续下一题。oracle不伪称正式Codex3次测评。共享manifest/README由主代理写。

exit_code=0
```

### 2026-11-16T22:47:36.287692+08:00

```bash
rg -n 'timeout_sec|1200|720|1320|43200' tasks/qft-13 tasks/qft-14 tasks/qft-15 tasks/qft-16 tasks/qft-17 tasks/qft-18 tasks/qft-19 tools/author_qft13_19.py tools/write_qft13_19_status.py planning/status-qft-13-19.md
```

```text
tasks/qft-16/task.toml:13:timeout_sec = 720.0
tasks/qft-16/task.toml:18:timeout_sec = 120.0
tasks/qft-16/task.toml:27:build_timeout_sec = 900.0
tasks/qft-13/task.toml:13:timeout_sec = 720.0
tasks/qft-13/task.toml:18:timeout_sec = 120.0
tasks/qft-13/task.toml:27:build_timeout_sec = 900.0
tools/write_qft13_19_status.py:61:    '题包当前按范例为1200秒agent+120秒verifier；50题全部按此上限累计会超出43200秒，整套应统一分配并在最终验证前冻结。本题实测参考均远低于此限；正式模型是否能在重分配时间内解决须由正式测评记录支持。','']
tools/author_qft13_19.py:47:        m=moments(a,b,6 if baseline else 12000)[:4]
tools/author_qft13_19.py:648:13:r'''分部积分给 $C_{n-2}=n\alpha C_n+\beta n(n+1)(n+2)C_{n+2}$。设 $r_n=C_n/C_{n-2}$，从截断边界$r_{2N+2}=0$后向迭代 $r_n=[n\alpha+\beta n(n+1)(n+2)r_{n+2}]^{-1}$，再由$C_0=1$重建低阶矩。此式避免解带状线性系统时阶乘归一化产生的下溢/病态。参考采用N=12000；公开固定N实验仍严格用各自N。真值用65位实轴积分并由后向高精度递推交叉验证。高斯稳态解二维Ornstein–Uhlenbeck的Lyapunov方程，复方差为 $\langle|z|^4\rangle-|\langle z^2\rangle|^2$；由Wick关系计算四阶矩，不把独立样本需求等同MCMC步数。''',
tools/author_qft13_19.py:725:运行环境 Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0；4CPU、4GiB、0GPU，agent1200秒，隔离verifier120秒无网络。仅answer.json参与评分，所需计算均可在本地CPU完成。参考答案和独立真值不进入agent镜像。
tasks/qft-18/task.toml:13:timeout_sec = 720.0
tasks/qft-18/task.toml:18:timeout_sec = 120.0
tasks/qft-18/task.toml:27:build_timeout_sec = 900.0
tasks/qft-15/task.toml:13:timeout_sec = 720.0
tasks/qft-15/task.toml:18:timeout_sec = 120.0
tasks/qft-15/task.toml:27:build_timeout_sec = 900.0
tasks/qft-19/task.toml:13:timeout_sec = 720.0
tasks/qft-19/task.toml:18:timeout_sec = 120.0
tasks/qft-19/task.toml:27:build_timeout_sec = 900.0
tasks/qft-14/task.toml:13:timeout_sec = 720.0
tasks/qft-14/task.toml:18:timeout_sec = 120.0
tasks/qft-14/task.toml:27:build_timeout_sec = 900.0
planning/status-qft-13-19.md:42:题包当前按范例为1200秒agent+120秒verifier；50题全部按此上限累计会超出43200秒，整套应统一分配并在最终验证前冻结。本题实测参考均远低于此限；正式模型是否能在重分配时间内解决须由正式测评记录支持。
tasks/qft-17/task.toml:13:timeout_sec = 720.0
tasks/qft-17/task.toml:18:timeout_sec = 120.0
tasks/qft-17/task.toml:27:build_timeout_sec = 900.0
tasks/qft-19/instruction.md:30:运行环境 Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0；4CPU、4GiB、0GPU，agent720秒，隔离verifier120秒无网络。仅answer.json参与评分，所需计算均可在本地CPU完成。参考答案和独立真值不进入agent镜像。
tasks/qft-13/instruction.md:26:运行环境 Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0；4CPU、4GiB、0GPU，agent720秒，隔离verifier120秒无网络。仅answer.json参与评分，所需计算均可在本地CPU完成。参考答案和独立真值不进入agent镜像。
tasks/qft-19/tests/private/truth.json:29:        -1.3107200000000003,
tasks/qft-18/instruction.md:28:运行环境 Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0；4CPU、4GiB、0GPU，agent720秒，隔离verifier120秒无网络。仅answer.json参与评分，所需计算均可在本地CPU完成。参考答案和独立真值不进入agent镜像。
tasks/qft-13/solution/solve.py:38:        m=moments(a,b,6 if baseline else 12000)[:4]
tasks/qft-18/environment/public/model.json:28:            -0.0663572058807127,
tasks/qft-18/environment/public/model.json:120:            -0.720415049060766,
tasks/qft-18/environment/public/model.json:216:            0.12005982220511935
tasks/qft-18/environment/public/model.json:370:            1.3720687428582732,
tasks/qft-18/environment/public/model.json:838:            -0.0663572058807127,
tasks/qft-18/environment/public/model.json:975:            -0.0663572058807127,
tasks/qft-18/environment/public/model.json:1112:            -0.0663572058807127,
tasks/qft-18/environment/public/model.json:1158:            -0.6587207118153516,
tasks/qft-18/environment/public/model.json:1209:            0.010576855927207965
tasks/qft-18/environment/public/model.json:1249:            -0.0663572058807127,
tasks/qft-18/environment/public/model.json:1302:            0.3438374472083801
tasks/qft-18/environment/public/model.json:1439:            0.12005982220511935
tasks/qft-18/environment/public/model.json:1576:            0.12005982220511935
tasks/qft-18/environment/public/model.json:1713:            0.12005982220511935
tasks/qft-14/instruction.md:26:运行环境 Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0；4CPU、4GiB、0GPU，agent720秒，隔离verifier120秒无网络。仅answer.json参与评分，所需计算均可在本地CPU完成。参考答案和独立真值不进入agent镜像。
tasks/qft-17/instruction.md:28:运行环境 Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0；4CPU、4GiB、0GPU，agent720秒，隔离verifier120秒无网络。仅answer.json参与评分，所需计算均可在本地CPU完成。参考答案和独立真值不进入agent镜像。
tasks/qft-16/instruction.md:26:运行环境 Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0；4CPU、4GiB、0GPU，agent720秒，隔离verifier120秒无网络。仅answer.json参与评分，所需计算均可在本地CPU完成。参考答案和独立真值不进入agent镜像。
tasks/qft-13/solution/README.md:3:分部积分给 $C_{n-2}=n\alpha C_n+\beta n(n+1)(n+2)C_{n+2}$。设 $r_n=C_n/C_{n-2}$，从截断边界$r_{2N+2}=0$后向迭代 $r_n=[n\alpha+\beta n(n+1)(n+2)r_{n+2}]^{-1}$，再由$C_0=1$重建低阶矩。此式避免解带状线性系统时阶乘归一化产生的下溢/病态。参考采用N=12000；公开固定N实验仍严格用各自N。真值用65位实轴积分并由后向高精度递推交叉验证。高斯稳态解二维Ornstein–Uhlenbeck的Lyapunov方程，复方差为 $\langle|z|^4\rangle-|\langle z^2\rangle|^2$；由Wick关系计算四阶矩，不把独立样本需求等同MCMC步数。
tasks/qft-15/instruction.md:28:运行环境 Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0；4CPU、4GiB、0GPU，agent720秒，隔离verifier120秒无网络。仅answer.json参与评分，所需计算均可在本地CPU完成。参考答案和独立真值不进入agent镜像。
tasks/qft-18/tests/private/truth.json:90:        0.23981157201094386,
tasks/qft-14/tests/private/truth.json:21:        -2.1606733981287205e-17,
tasks/qft-14/tests/private/truth.json:69:        -0.22590127205663796,
tasks/qft-14/tests/private/truth.json:73:        0.22590127205663801,

exit_code=0
```

### 2026-11-16T22:48:26.209429+08:00

```bash
python3 tools/write_qft13_19_status.py
```

```text
Wrote seven validation reports and planning/status-qft-13-19.md from saved all-pass Linux evidence.

exit_code=0
```

### 2026-11-16T22:48:26.296882+08:00

```bash
python3 -c 'import json,tomllib; from pathlib import Path; root=Path("."); rows=[]; for_ids=range(13,20); exec("for i in for_ids:\n t=f\"qft-{i:02d}\"\n c=tomllib.loads((root/\"tasks\"/t/\"task.toml\").read_text())\n r=json.loads((root/\"checks\"/(t+\"-calibration.json\")).read_text())\n assert c[\"agent\"][\"timeout_sec\"]==720 and c[\"verifier\"][\"timeout_sec\"]==120\n assert all(r[\"checks\"].values())\n rows.append((t,len(r[\"checks\"]),c[\"agent\"][\"timeout_sec\"]+c[\"verifier\"][\"timeout_sec\"]))"); print(rows); print("seven-task limit sum:",sum(x[2] for x in rows))'
```

```text
[('qft-13', 18, 840.0), ('qft-14', 15, 840.0), ('qft-15', 17, 840.0), ('qft-16', 17, 840.0), ('qft-17', 18, 840.0), ('qft-18', 18, 840.0), ('qft-19', 17, 840.0)]
seven-task limit sum: 5880.0

exit_code=0
```

### 2026-11-16T22:48:57.978659+08:00

```bash
cat planning/work-order-build-qft-13-19.md
```

```text
# 实施任务：QFT-13 至 QFT-19

用户要求实际完成整个50题Harbor benchmark。你负责 qft-13 至 qft-19 共7题，不能只做选题。

先读 planning/qft-expansion-20-selection.json、qft-expansion-20-audit.md 和来源评审；原书已提取在planning/source-notes/qft-gelis-all.txt。参照 tasks/qft-04 的独立Harbor结构，每题交付题面、固定依赖环境、公开模型和反馈、参考代码及推导、合理朴素baseline、课程原版quality_score、独立私有真值和评分器、校准和错误/等价/空提交回归。参考与真值不能同源函数重算。

QFT13 complex Langevin分支；14 Wong路径序；15 large-N颜色拓扑；16色守恒软天线；17限定单一构型族并用边界绕数和体积拓扑荷双路线；18六点NMHV；19 D维cuts的一圈有理项。完整来源和研究判断，非换参数重复；QFT16不能将角序当作总辐射逐点硬零，QFT19不能将四维cuts零当振幅零。

每题4CPU4GiB0GPU，agent暂720秒、verifier120秒，整体50题<=43200秒；必要时报告具体实测后重新分配。只写本组tasks及专属tools/checks/provenance，状态 planning/status-qft-13-19.md。所有shell执行前commentary展示，统一 python3 tools/run_logged.py --log checks/qft-13-19-command-log.md -- COMMAND。本地Mac/Docker，不连远程、不用GPU、不推送、不停止他人容器。

需实际做完7题并Linux校准，而非空目录。每完成一题继续下一题。oracle不伪称正式Codex3次测评。共享manifest/README由主代理写。

exit_code=0
```
