## 记录器启用前的只读命令

以下实际读取已在对话中展示，补记于统一日志：

```bash
rg -n '陀螺|章动|进动|对称陀螺|重力矩|Euler|欧拉角' planning/source-notes/tm-all.txt | head -80
rg -n '===== PDF PAGE (4[3-5][0-9]) =====' planning/source-notes/tm-all.txt | tail -20
```

### 2026-11-16T16:14:03.388671+08:00

```bash
python3 -c 'from pathlib import Path; s=Path('"'"'planning/source-notes/tm-all.txt'"'"').read_text().splitlines(); print('"'"'\n'"'"'.join(s[20700:21420]))'
```

```text
（9）

===== PDF PAGE 434 =====
6.3 习题解答
•425
6.28
轮船上的一个飞轮绕水平轴线转动，角速度为w.飞轮相对于其转轴的
转动惯量为1.轮船正以速率通过曲率半径为R 的航线，试求两轴承上的动反
作用力.两轴承相距1，飞轮位于它们的中点.
解法1 飞轮的运动是一般运动，它等价于飞轮的质心的平动及绕质心的定
点运动的叠加.这里我们仅需考虑定点运动部分.O，是空间坐标系的原点.O为
飞轮的质心所在位置，可以建立坐标原点在O但相对于原点在01 点的空间坐标
系作平动的坐标系 O- g '及固定的体坐标系0-wyz（题6.28 图）.在图示的瞬间，
2 轴与？重合，z与2'轴重合，而轴则与z'重合.在随后的运动中，2总是在
' 平面内.根据题意可知
0=z，中一觉：好=心
将上列关系代入欧拉运动学方程，得
wa =dcosy +psinOsiny=号siny，
wy =-Asiny+$sin0cosy = 元 Cost，
wx=4+pcost=w.
（1）
由式（1）可得
wx一元WCOsV，by =-万wsind， is =0.
将上述结果代入欧拉动力学方程并考虑到i=12,1=1，可得
ba-1%wcosd，ho=-fwsind
L≥=0，
（2）
（3）
一 卡
o,
题6.28图

===== PDF PAGE 435 =====
•426•
第6章 刚体力学
这里的力矩La，Ly，L：是由于轴承在A和 B 点对轴的作用力 NA和 NB而引起
的，因为飞轮位于两轴承的中点，有 NA=NB=N. 力矩的大小为
L=V +场+=1元
（4）
两轴承上的动反作用力为
解法 2 建立部分固定的体坐标系 O-zyz，这里x轴是刚体的对称轴，而心和
轴位于飞轮的平面内，它不参与刚体的自旋，即将通常的固定体坐标系中的自旋
部分去掉即得这种部分固定的坐标系.于是，由题意得刚体的角速度为
4一元十ck，
所以
w2=0,W3=w.
（5）
在部分固定的体坐标系中，主转动惯量为13=1，L =12. 我们将使用部分固定的
体坐标系下的欧拉动力学方程（参见式（6.43））
[2ừz - [w1|[w1=[z
（6）
Isws - liwila + lawzl = L3，
其中的02为部分固定的体坐标系相对于空间坐标系仅做章动和旋进的角速度在体
坐标系中的分量，由题意知，所选的体坐标系 O-ry》 没有章动，仅有旋进，即
½==0，
瓦
（7）
将式（5）、式（7）代入式（6）得
I1=0. Is=-Iuğ Is=0.
所以两轴承上的动反作用力大小为
N=La
Ivw
=RI：
解法 3 当轮船转弯的角速度大小 员比飞轮的自转角速度w小得多时，可
以应用关于高速陀螺的近似理论.在该理论中可以认为飞轮的总角速度就等于自
转角速度，方向沿飞轮的对称轴，从而总的角动量也沿对称轴方向，即总角动量为
J=1w.在轮船拐弯时，J的方向随着发生改变，由角动量定理知必有附加的外力
矩工作用在飞轮上，有
L= XJ.
该力矩来自于用来固定飞轮的轴的轴承所施加于轴的作用力，该作用力的大小为

===== PDF PAGE 436 =====
6.3 习题解答
•427，
6.29 对称刚体做无外加力矩的定点运动.试证明：动量矩J、角速度矢量w
以及刚体的对称轴三者共面.
解 对于对称刚体，设对称轴沿2轴，则主转动惯量有关系五=12=1.系统
的角动量相对于惯量主轴的分量形式为
J=liwli+ lwzj + Iswsk=I（w1i+w2j）+ lgwgk.
另外，刚体的转动角速度为
w=wii+w2j +wgk.
故有
(Jxw)k=[(w1itw2j)xw3k+I3w3kx(w1i+w2j)]•k=0.
因为J，w均是非零矢量，它们也不相互平行，则上式表示 与J×w垂直，但J×w
是与J，w都垂直的，故J、w以及刚体的对称轴 三者共面.
6.30， 对称刚体做无外加力矩的定点运动时，角速度矢量w 在本体坐标系中
绕着对称轴旋进，旋进角速度02为52=18-21
-w3.试证：① 角动量J在本体
坐标系中也以角速度12绕对称轴旋进；②取空间坐标系的>'轴沿角动量J，则
6=0, ly=0，¢=1sws/l_cos0； ③w绕J旋进角速度也为 Lsws/L_cos0. w 与J
的夹角a则由下式给出：
sin a =
11s-Z
-sin B cos d，
I3
3是w与刚体对称轴的夹角.
解 ① 对于对称刚体，设对称轴为体坐标系的。轴，则有=12. 在作无外
加力矩的定点运动时，对称刚体的转动角速度对本体惯量主轴坐标系的分量表示式
为
W1 = wp cos
1-fust+e），
I3-I1
-wst+6),
wz = wp sin
w8=1（常数），
其中，wp，s 为常数，而在此种情况下，刚体相对于定点的角动量在本体惯量主轴坐
标系中的分量表示式为
J=Ji+J +Jk=hwii+ lwaj + Jswsk= Ii（wii+w2j）+lswsk.
由于w3 =常数，所以J在对称轴上的投影 Lgws 也是常数.但J在体坐标系的zy
面上的投影画出圆，其半径的平方为

===== PDF PAGE 437 =====
*428
第6章 刚体力学
可见，这比w画出的圆半径大了倍.由此，J的大小在刚体运动过程中不变，但
方向与w一样绕着对称轴以角速度12旋进.
② 对称刚体做无外加力矩的定点运动时，刚体相对于定点的角动量是守恒量，
因此相对于空间坐标系，J的大小和方向是不变的，故可取J的方向为空间坐标
系的z'轴方向.0为体坐标轴的≥轴与空间坐标系， 轴之间的夹角.由上面的讨
论知
Jcosl=J=1gus=常数，
即在运动过程中，0不变.故
6=0.
由欧拉运动学方程中的前两个方程
w1=øsin0sin4+9cos4,w2=øsinecos-0sin4,
代入6=0，得
则
w1=фsin0sin2, w2 =фsin0 cosv.
tanv - ly =cot (13- 'wstte) =tan (''→lust-c+2).
即
-wzt+V0,
11
其中，40=艺一8.于是由上式知自转角速度大小为
刘=1-2
w3= 0.
11
由欧拉运动学方程中的第三个方程 w3 =少+¢cos0，同时考虑到必=
11-13
Ii
则有
11- 13
$=
w3一砂
cos A
W3 --
-W3
Ізwз
cosA
-=Icost
③ 因为
即
w.J=Jwcosa = (w1i†W2j + w3k) - (J1i† J2j + Jzk)
=Jw1tJ2w2J3w3=(wtw2)+13w3=11w?+I3wg
11w? + I3w3
CosQ =
Jw
w在J上的投影为常数.
又因为
|wx J]= Jwsina= |(wii+w2j +w3k) x (Jii+ Jzj + J3k)||
则有
sin a =
|[1— Із|шзvш}+wz
Jw

===== PDF PAGE 438 =====
6.3 习题解答
•429•
这表明w在垂直于J方向的投影的大小也是一个常数，因为J及ws和Vw？ +w=
wp都是常数，故运动过程中，w与空间坐标系的x'轴的夹角a 不变.
由题6.29知，对于对称刚体，在其做无外加力矩的定点运动时，动量矩J、角
速度矢量w以及刚体的对称轴这三者是共面的.上面已证明了刚体的对称轴以角
速度 =1gws/l1cos0绕J旋进，于是w绕J旋进的角速度也为 Isws/I1 cos0.
因为8是w与刚体对称轴的夹角，则
w? + w3 = w? sin B, w3 = wcosB.
同时，有
代入前面的表示式，有
J3=I3w3=Jcost.
S1nQ=
五一a sin Bcos 8.
6.31 对称刚体做无外加力矩的定点运动，其转动惯量I1=12=213. 对称轴
与J之间的夹角为8=60°.已知其自转角速度v，试求旋进角速度.
解 刚体的运动是无力矩作用的定点运动.取z/
轴为旋进轴，2轴为刚体的对称轴，z，轴垂直于。轴
且固结于刚体上（题6.31 图）.取刚体的重心处为体坐
标系和空间坐标系的共同原点，则有
x
wI =，
w2=¢.
8=60°即为章动角，而6=0.
由关于无外力矩刚体运动的讨论知
W1=2=
11-13
1
题6.31图
-W===Wz
即
wa=261.
又由欧拉运动学方程中的第三式wz =中cos6+4，可知
W2=o 一
2w1 — w1
一=2w1.
cos 60°
6.32 试研究对称重刚体的定点运动的一个特殊情况，其中日=0，这就是说，
对称重刚体的对称轴竖直向上.而刚体绕着竖直的对称轴旋转.证明这种运动的稳
定与否视 4Imgh/Bw小于或大于1而定.
解法 1 0=0的运动是无章动的定点运动.下面确定无章动时的动力学方程.
由式（6.46） 可得关于。的拉格朗日方程为
r0=mghsin8- （po -Li¢cosa）osin 6.
（1）
在无章动时，即6=6=0时，由式（1）可得，
I¢' cosBo -pyt+ mgh=0.
（2）

===== PDF PAGE 439 =====
•430 -
考虑到 pw =Js= 1gwz，则式（2）可写为
$3c0s00-ws+ mgh=0.
由此可解得
¢=
今 土 （今 ）”
4mgh
- costo
2cos0o
要使。有意义，则它应是实的，即上式中根号内的表示式的值不小于零，
- cos Đo,
第6章 刚体力学
(3)
也即
4mghI cos 0o
（4）
当6=0时，则有
4mghI
Twg ≤1.
可见，要有稳定的旋进，则上述条件必须满足，此即睡陀螺的问题.
解法 2 通过设刚体的对称轴偏离竖直方向较小的角度6，由此确定运动过程
中日保持小值的条件求出稳定的条件.
在对称重刚体的运动过程中，有三个运动积分，其中两个分别为
当V+Gsn20）+当発+mghcos0-B， lasin?0+ JecosB=J：，
（5）
其中，J=P+.由上两式消去¢，得
1（Jz1 — Js cos.0）2
I sin?0
+mghcos8+
=E.
(6)
213
当8=0=0时，式（5） 给出
J= ，B=25
尽+mgh
在式（6）中考虑到日为小量，对含日的各项作 Taylor 展开并仅保留到日的二次项，
同时利用上列两式可得
5+（
J
；-gmgh）o=0.
（7）
对式（7）再求一次时间t的导数，得
10+（鉴-mgh）0=0.
当要求刚体绕竖直轴的旋转是稳定的，则日应是围绕0=0的小振动，由上式可知
应有 器-mgh>0，即
4Imgh
一<1.
但Js=1gwz，所以稳定的条件为

===== PDF PAGE 440 =====
6.3 习题解答
•431：
4Imgh
写哈<1
解法3 有效势能方法 在0=0处陀螺运动的稳定性也可以由式（6.51）的
有效势能是取极大值或极小值来确定，而这又取决于B，和 Bu 的值.如果有效势能
Va（0）对0的二阶导数在6=0处是为正的，即Ver @）在该处有极小值，则相应的
运动是稳定的.
在0=0附近，可以令Bw =B+，则式（6.51）的有效势能可以改写为
BZ (1 - cOS0)2
Vef（0）=
21 sin2 0
- +mgh cosA =
4 tan2！
Ni+mghcost.
(8)
有效势能的一阶导数力
dVem(0)
de
B3 tan 2- mgh sin,
2I
cos??
（9）
二阶导数沩
d°Veft(0)
d02
2J
2c0s4員
cos3 2
路1+2sin2g
=-
4I
cost 2
- mgh cos0.
- mgh cos0
（10）
故有
dºVem(O)|
d02
18=0
4I
- mgh.
有效势能的二阶导数为正要求有条件
4I
-mgh>0，
注意到 Bw = Igwz，上述条件即为
4Imgh
1<L.
1w2
6.33 将对称刚体的对称轴装在一个环上，环可绕一根轴线转动，这使得刚体
的对称轴只能在一平面里，这平面就叫作轴面，使这装置的轴面与水平面重合，并
使刚体绕其对称轴自转.刚体还参与了地球的自转，试利用欧拉方程证明，如刚体
的自转远比地球的自转力快，则对称轴将在子午线左右来回摆动，从而可以指示南
北方向.

===== PDF PAGE 441 =====
・432・
第6章 刚体力学
解 这是刚体定点转动问题.刚体仅有自转和旋进，没有章动.如题6.33图，
由于刚体相对于其自身的转轴是对称的，取i，j，k分别为部分固定的坐标系的三个
坐标轴方向的单位矢量，这种坐标系不参与刚体的自转，即z，g轴不是固定在刚体
上的.但2，3,2 轴均随地球转动而改变方向.图中k为刚体的自转轴的方向，而；
从地球中心指向外，即刚体所在地的竖直方向.32为地球的自转角速度.N为纬度
入处的正北方向.N，i和k位于同一平面内.k 与 N之间的夹角a为任一时刻刚
体的自转轴与北方的偏离角.
2
N
A2
22 sin 1
Q coslå
$2 sin 2
题6.33 图
将52向部分固定坐标系的三个坐标轴方向分解，得分量式为
S = -1 cos 1 sin ai + S2 sin \j + S cos 1 cosak.
当刚体的自转轴 k以角速度aj 相对于地球转动时，则考虑到地球自转，部分
固定坐标系 Oryz 相对空间坐标系的角速度在部分固定坐标系中的分量形式为
2'=-R cos 入sin oi + （a + J2 sin 入）i+J2 cos 入 cos ak.
它实际上就是不计刚体自转时刚体相对于空间坐标系的角速度.如果设刚体的沿k
的自转角速度 w。和地球角速度在k方向的分量的总和用s表示，s=.12 cos 入cos Q+
w0，则刚体相对于空间坐标系的角速度在部分固定坐标系中的分量形式为
w = -S cos Asin oi + （a+ 1sin A）j+sk.
由此可得刚体相对于其质心的角动量为
J=-10cos Asinai + I（d+ 12 sin入）j+Jssk，
其中，1,1，ls是刚体相对于部分固定坐标系各轴 2，，&的转动惯量，其中考虑到了
刚体对于×轴具有旋转对称性，因而各坐标轴是惯量主轴.
由于受到约束，刚体的自转轴仅能在水平面内运动，则支架的作用力有一个沿
方向的力矩，记为Lai，于是由相对于刚体质心的角动量定理，得

===== PDF PAGE 442 =====
6.3 习题解答
：433•
dJ
dt
-ID cos Acosaai + laj + lsk+ DxJ= Lai.
上式的分量形式为
(I3s- 2IS2 cos 1 cosa)a - IS sin \ cos 1 cosa + Izs2 sin \ = Lx,
Tä- IS' cos? ) sin a cosa + I3s/ cos 1 sin a = 0,
I35 = 0.
地球转动的角速度的量级为7.29×10-5rad/s，而刚体自转角速度的量级约为
102rad/s，则可将 22视为无限小量，并仅保留到它的线性项.假设c也是小量，也仅
保留到它的线性项，这相当于假定刚体的自转轴在所有时刻近似地指向北方，在上
述假定下，上列方程化为
(I3s - 2IS cos 1)å + I3sS sin 1 = Lx,
Iä+IзsПcos1a =0,
lss=0.
（1）
从式（1）的最后一个方程可看出刚体自转角速度为常数，从而式（1）的第二个方程
a+w&=0，
（2）
I3S2s cos 1
其中，Wi=
=常数.方程式（2）表明，刚体的自转轴围绕北方做简谱
振动，于是自转轴的方向指向北方.一旦由式（2）求出了 ~，则由式（1）中的第一个
方程可求出 La
6.34 对称重刚体绕其竖立的对称轴做稳定的旋转，在距离支点为d的地方
以垂直于对称轴的冲量了施加于刚体，求证此后最大章动角近似为 2arctan Toug
解 本题是对称重刚体的定点运动问题，对刚体的冲击提供了刚体随后运动
的初始条件、建立题6.34 图所示的体坐标系O-ry 和空间坐标系O- 。设陀螺
受到冲量作用后，以角速度0。离开竖直方向.根据对定点 ◎的角动量定理，可得
A.J=1100=jd，
即有初始条件为
0=%
同样，由于冲量作用的时间很短，故还有初始条件
00=0，¢=0，
4=w3，
其中，ws 是初始时刚体自转的角速度.
(1)
(2)

===== PDF PAGE 443 =====
・434・
第6章別体力学
mg
N
題6.34冬
刚体在冲击后的运动中受到重力和定点 O处
约束力的作用，所受外力相对于O的力矩为
I = mgl(sin cos v/i - sin 0 sin vj),
其中，1为刚体质心到支点O的距离，要求解对称重
刚体的运动，可从欧拉动力学方程出发并结合欧拉
运动学方程解出各欧拉角随时间的变化规律．但是，
根据对重刚体问题的研究，这样的系统在运动过程
中有三个守恒量，它们可以简化问题的求解.三个
守恒量分别为：① 相对于空间坐标系的2'轴和体
坐标系的。轴（刚体的对称轴）的角动量守恒，即
(11 sin? 0 + I3 cos 0)ф + I3i} cos0 = Bф,
（3）
I3(v+фc0sĐ)=Iзw==Ba-
② 系统的机械能守恒
E=T＋V=
54（82+62sin26）+
[I3(Ý+фcOs0)?+mglcos0
将初始条件式（1）和式（2）代入式（3） 和式（4），得积分常数分别为
Pp
by=b¢=13w3，
E= 211
+51863+mgl.
将秋分常数代回式（3）和式（4）得
Ii¢sin20= 1sws（1 - cose），
V+ ØcOsA= w31
îz22
2：（88 +895in20）= T4
-+2mgi（1-cos8）.
由式（5）的第一式解出。再代入式（5）的第三式，得
L.02+
- +2mgl(1- cos0),
（4）
（5）
sin A
即
1962+1808 tan2号（1-420g
- cos??
=Ta.
巧好
（6）
当日取最大值时，有6=0. 另外，因ws很大，则式（6）中括号中的第二项可忽略，
则得到
6.35
0 = 2 arctan (
13w3
由做定点运动的对称重刚体的欧拉方程
Hea =（1-13）uyus + mglsin 8 cos7，
Lw=(I3-11)wxW=-mgl sin 0 sin 4,
1588=0，
(1)

===== PDF PAGE 444 =====
6.3 习题解答
Ф Щ [Ö = mgl sin 0 - ф(Jз sin0 -[ıфsin0coş0).
解 将方程式（1）中的第一式乘以 cosw，第二式乘以 sinz并相减，得
11(Wx COS/- Wysin /)= mglsin0+ (11 - I3)wz (wy COS 2) + Wx sin v).
由欧拉运动学方程
wx =Öcos4+фsin 0 sin,
wy=-Ôsiny + øsin e cos 4,
Wx =4 +фcoso,
对其中的第一和第二式分别求时间的导数，得
wx = Ö cos y - Ôy sin v + Ø sin 0 sin y + фê cos 0 sin y + Øự sin f cos 4,
wy=-dsiny-bj cosy +osindcosy + odcosacosy- pe sin Bsiny.
由此两式可得
wacosy-wy siny =6+puisin 0.
又由式（3）中的前两式消去白可得
wasiny + wycosy = ösine.
将式（4）和式（5） 代入式（2）得
[Ö =mgl sin0—IзwzФsin0 +lıфsin9(wz —v).
利用欧拉运动学方程（3）的第三式，上式即可化为
1,0 = mgl sin0 - $(J3 sin 9 - Iøsin 0 cos0),
其中，J=1gwz：
6.36 用欧拉动力学方程求解习题 1.47.
解尺 AOB 做定点运动，定点为 O.建立题
6.36 图所示的体坐标系 O-ayz，其中2轴正方向垂
直于纸面向外.各坐标轴是惯量主轴，相应的主转
动惯量分别为
•435•
（2）
（3）
(4)
(5)
1=五+互=言ml+言m =言e+6），
其中，p为质量密度，由于尺 OA 边与竖直线的夹
角a 不变，则它转动的角速度为
w = -wcosai - wsinaj,
即有
wa=-wcoSQ, wy =-wsin o, wz =0.
外力对O点的力矩的分量式为
题6.36 图

===== PDF PAGE 445 =====
・436・
第6章 刚体力学
Lx =Ly=0,
1
1
bz=-pimaglz cosa +omgh sina= zpg（-h cosa + lf sin a）.
将上列各式代入欧拉动力学方程中的第三个方程 Igws 一（L-12）wauy =Lz，可得
-3P(13- 1)wsinacosa = [P9(-B cosa + l} sin a).
由上式可解得
w？=
3g(1½ cos a - l} sin a)
2(lz - 13) sin a cos a
这就是所要求的转动角速度.
注 本题的非惯性系解法和动力学普遍方程解法分别见习题1.47和习题2.24.
6.37 一根长为1，质量为m. 的均质细杆，一端以铰链与以匀角速12转动的
竖直轴相连，如题6.37 图所示，试求以角日表示的系统的运动微分方程及其解，设
日 可作労小量.
2
TII
解法 1 矢量力学方法 细杆作定点运动，
取题 6.37 图所示体坐标系 0-zyz，2 轴正方向垂
直于纸面向外，则相应的主转动惯量分别为
ムニノュニョml, 12 =0.
杆转动的角速度可表示为
w=n+0k，
于是有
题6.37图
Wa=-Dsin8, wy＝-cosl, Wx=8.
细杆受到重力以及竖直轴对它的约束力的作用，这些外力对O点的力矩的分量
式为
La=Ly=0, La=smgl sinB.
将上列几式代入欧拉力学方程中的第三介方程 13wュー（1ュー 12）waliy=しュ井整
理可得
6+（当9 0200s0） sin0=0.
(1)
这就是杆的运动微分方程.
当日很小肘、有cos日～1,sin日～8、于是得
6+（
当-02）0=0.
当々満足3-2>0，即
3g
R<V21
（2）

===== PDF PAGE 446 =====
6.3 习题解答
•437•
时，杆的运动是角频率为V/当
-D2的简谐振动.
解法 2 拉格朗日方法 取杆为系统，它有一个自由度.取日为广义坐标，则
系统的动能为
T=元（T0%+190%+ 1gu%）= ml（n2sin20+82）.
系统所受主动力为重力.以O所在水平面为重力势能零势面，则系统的势能为
V=-smglcos0.
系统的拉格朗日函数为
（3）
d aL
дL
将L代入拉格朗日方程
dt 00
де
=0，可得
1
-ml'ö-
3
gmln'sin @cosl+pmglsin@=0.
将上式整理即得解法1中的方程式（1）. 余下的分析见解法 1.
说明 ① 如果求系统运动过程中的可能平衡位置，此时有6=6=0，则由式
（1） 可得
3g
sin0 = 0, cost =
2122'
即
3g
6=0，士，士arccos一
21.022°
（4）
仅当22≥
3g
21
时，平衡位置日=土arccos
21022是可以实现的，于是存在一个临界
的转动角速度 JPc
3g
当 S> Sc，杆在竖直方向的平衡位置变为不稳定的.如果无限地提高转速12，则杆
的平衡位置将趋近于水平位置.
杆的平衡位置的稳定性可通过有效势能 Ver 来加以分析.系统的有效势能为
Vin=-当mglcos0-dme:p2si?0，
其中，第二项是转动引起的所谓离心势.平衡条件为
dVeft = 0=5mglsin6- zmlD"sin0cosB，
d2 Veft
由此所得的结果与式（4） 相同. 平衡位置的稳定性由
-的符号确定.因为
dVeff
d82
=）
Nmg/.cos 0 -gml-.D° cos（20），
则有
d'Veff,
-0=0三
-ml12--
=一
5mi（n一昭），

===== PDF PAGE 447 =====
•438.
第6章 刚体力学
可见，当22<12时
dEVe1o-o>0，
d02
即0=0的平衡位置是稳定的.当12>12时
d2VeFt 0-0 <0，
d'Veft
d02
d02
0=+arccos 23>0，
即随着Q的增加，0=0的平衛位置变为不稳定的，而0一士arcos_2。为稳定的
平衡位置.
在0=士处，有
d'Veft
d02
0=士 =
pimgl-
aml”2‘<0.
因此，无论12 为何值，在8=士 处杆的平衡总是不稳定的.
② 由于系统的拉格朗日函数L 不显含时间t，则有 Jacobi积分
h=T To+V=
me62-gum8.g2 st20-mjmglcsd.
（5）
如果在相平面（0,6）上讨论系统的运动行为，则上面的平衡点是相平面上的奇点四
而方程（5）确定系统运动时在相平面上的轨迹，对不同的初始条件，即不同的h，可
以有不同的轨迹.
在0=0附近，方程 （5）. 中的日可视为小量.对式（5） 关于0作 Taylor 展开，
保留到日的二阶项，即作近似sin0~ 0,cos0~1-
20，则式（5）可化为
（6）
当12<P。时，方程（6）是相平面内的椭圈，（6=0,6=0）为椭圆的中心，该平衡点
也称为中心.当12＞1时，方程（6） 是相平面内的双曲线，平衡点是鞍点.
在0=士arccos
2102
附近，令
0=00+5
3g
其中，00=士arccos
21.522
今可视为小量.将式（5）在 0o展开并保留到§的二阶
项，有
ml?c2
因为在这种情况下，12＞Dc，上式是相平面内的椭圆方程，（00,0）为椭圆的中心
10 较详细的讨论可参见第8 章的有关内容及其习题 8.31，习题 8.32，习题 8.33.

===== PDF PAGE 448 =====
6.3 习题解答
•439•
结合① 的讨论可知，鞍点是不稳定平衡点，而中心是稳定平衡点．这个结论可
以进行一般性的证明，可参见有关非线性振动方面的专著.
6.38 如果拉格朗日陀螺开始时 0=60°，6=0， =2//
mgl
3mgl
37,wa=TsV
试证明在以后的运动过程中，8满足的方程式为
解 在拉格朗日陀螺运动过程中有三个运动积分，即式（6.47）、式（6.48）和式
（6.49）.由题设条件，可以求出运动积分常数分别为
Ba= V3mgtl, Bu = V3mgtl, E = (1+ 31) mgl
当）mgk
将这些常数分别代回式（6.47）、式（6.48）和式（6.49），有
Iфsin 0+I3wzcos0=v3mgIl,
ls（¢+¢cos0） = 1swz= V3mgll，
当1（02+ sin20）+岁B00%+mglcos0= （1+
乳）
mgl.
（1）
（2）
（3）
式（2） 表明在运动过程中w是不变的.为得到关于9的方程式，在式（1）和式（3）
中消去•.由式（1）得
$=76026 （VSmgll- Ja4: c0s0）.
将上式代入式（3）并整理可得
IỞ? + 2mgl(1 - cos 0) (3 - sin? 0) - 3mglsin? 0 = 0,
其中利用了式（②2）.令a2=mg
产，将式（4）改写为
2
（4）
sin
62 = 02
（1-4s2g），
即
cos 블 40
aim을 (1-40?을)
= adt.
再令：二sin分，上式变为

===== PDF PAGE 449 =====
•440•
第6章 刚体力学
（5）
2 da
=adt.
2V1-4a2
利用积分公式
dx
a+ vaz -x2
= -In
zVa2-22
对式（5）积分可得
-21nL+VI-42
2z
=at+C，
其中，C为积分常数，考虑到初始条件t=0时，6=60°，代入上式得C=0. 所
以，有
1+V1-422
-2In—
-= at.
2z
对上式整理，可得
注意到 sec 0=
1
cos A
e-at/2
a sin i+e-at
i-2sin2Q，利用上面求得的sin号的表示式，有
(1 +e-at)2
2e-at
sec 0 =
=1+
1 +e=2at
i+e-208 -1 + sech（at）=1+ sech（V
这就是要证明的结论.
6.39 边长为a 的均质正方形薄板的一个顶点可绕固定点O运动，而其一边

exit_code=0
```

### 2026-11-16T16:15:21.319102+08:00

```bash
mkdir -p checks/tm-03-source-pages
```

```text

exit_code=0
```

### 2026-11-16T16:15:21.349826+08:00

```bash
pdftoppm -f 438 -l 440 -scale-to 1400 -png '/Users/ai4s/Downloads/理论力学学习指导与习题解析(理科用)(第二版)-鞠国兴.pdf' checks/tm-03-source-pages/top
```

```text

exit_code=0
```

### 2026-11-16T16:16:49.596022+08:00

```bash
rg --files tasks/tm-03
```

```text

### 2026-11-16T16:16:49.596022+08:00

```bash
python3 -c 'from pathlib import Path; s=Path('"'"'planning/source-notes/tm-all.txt'"'"').read_text().splitlines(); print('"'"'\n'"'"'.join(s[17915:18070]))'
```

```text
rg: tasks/tm-03: IO error for operation on tasks/tm-03: No such file or directory (os error 2)

exit_code=2
```
所谓的不变平面或称潘索平面，其位置由初始条件确定.不变平面与中心惯量椭球
相切于P点.O户 方向为瞬时转动轴的方向，也即角速度w 的方向.刚体运动时，
P 点位置将不断改变.但因P点速度 2，=w×OP=0，即P点是瞬心，中心惯量
椭球只能在不变平面上作无滑滚动.P 点在椭球上画出的轨迹为本体瞬心迹，在不
变平面上描出的轨迹为空间瞬心迹（图 6-14）.
惯量椭球
本体瞬心迹
J
图6-14 欧拉陀螺运动的几何图像
4） 刚体自由转动的稳定性
刚体绕某一主轴做自由转动时的稳定性是指，如果给系统一个小的扰动，则运
动或者回到扰动前的模式，或者绕原来的位置做小振动.
经过计算，有如下结论：绕主转动惯量为最大或最小的主轴的转动是稳定的，

===== PDF PAGE 375 =====
•366
第6章 刚体力学
而绕转动惯量居中的主轴的转动是不稳定的，但如果转动惯量中有两个相等，如
11 =12，则只有绕x轴（对该轴的转动惯量为1s）的运动才是稳定的，不论1s是大
于还是小于 1= 12.
2. 对称重刚体的运动特征
重刚体指的是除了使它做定点运动的约束力外，刚体所受到的其他力仅有重
力，对称是指刚体有动力对称轴，重心位于该轴上.假定重心和定点不重合，两者
之间的距离设为1.描述对称重刚体系统的拉格朗日函数为
I=I - V=]I(Ö+Ởºsin"O)+·1s(l+$c050)?-mglcos0.
（6.46）
1） 运动积分
对于对称重刚体，在做定点运动时该系统有三个运动积分，分别为
（1）相对于 x轴的角动量 pob守恒，即
дL
P=
= （Isin20 + 1s cos2a）¢+ lsycos0= Bo.
（6.47）
дф
（2）相对于2轴（刚体的对称轴）的角动量pw守恒，即
дL
Pe=
=18（4+¢cos0）=lswz=Bw-
Oy
(6.48)
（3） 系统的机械能守恒，即
（6.49）
从矢量力学的角度看，因为重力的力矩沿节线 ON 方向，它与Oz/和 Oz均垂
直，因而沿这两个轴的角动量的分量是运动常量，系统所受外力为重力，它是保守
力，因而刚体运动过程中机械能守恒.
从分析力学的角度看，存在三个运动积分是因为拉格朗日函数（6.46）不显含少
和4，即它们是可遗坐标，则对应的广义动量是运动积分.又因拉格朗日函数不显
含时间，并且系统是自然系统，则有广义能量积分，在该情况下即为系统的机械能
守恒.
2）运动特征
系统的运动情况可以通过求解动力学方程或者用有效势能的方法进行分析，有
效势能方法比较简单直观，其基本思路类似于有心力问题中的讨论：利用运动积分，
将问题化为等效的一维问题.通过该等效一维问题中的等效势能确定系统运动的范
围及其运动特点.

===== PDF PAGE 376 =====
6.1 基本内容
利用式（6.47）和式（6.48）将式（6.49）写为
• 367
(6.50)
这是等效一维问题的能量方程，其中 Ver 为有效势能
Vef（0）=-
(Рф - By cos 0)2
21 sin? 0
- + mglcosf.
(6.51)
积分上式得
de
t=
(6.52)
VF（CE-Var）
原则上，由上式可解出0=8（t），然后代入方程式（6.47）和式（6.48） 并积分可求出
中二中（t）及必二4（t）。
有效势能 Veft 的曲线如图6-15所示.从能量方程式（6.50）可以看出，物理上
有意义的运动要求 E'≥（Va）min-
Ven(e)A
터
0e.
0.
图6-15 对称重刚体的有效势能曲线
（1） E'=E>（Va）min 时（图6-15），运动限制在01 ≤8≤02之间.
可以用几何图形直观地描述刚体的运动.以定点 O为原点，单位长度为半径
作一球面.以竖直方向为空间坐标系的2'轴，则刚体的体坐标系的，轴既有旋进
又有章动，它在球面上的投影轨迹有如下三种情况：①在01 ≤6≤02 区间内，如
果 Bs-Bu.cos0不改变符号，则旋进角速度。也不改变符号，即刚体沿一个方向
旋进，轨迹如图 6-16（a）所示；② 如果旋进角速度•在两个极限值01和02之间
改变符号，则在6=01和日=02处，旋进角速度方向必相反，章动和旋进运动必
导致对称轴的回线运动，轨迹如图 6-16（b）所示；③ 如果（Bb-Bu cosB）as =0，则
中o_=0,0. =0. 轨迹为如图6-16（c）所示的尖齿形运动.

===== PDF PAGE 377 =====
-368．
第6章 刚体力学
（2） E=歐=（Vef）min 时（图6-15），0=6o，即刚体以一固定倾角作稳定运动，
此时无章动，是为规则旋进.
在日0处，d8
当40-0 0，則由式（05） 可約到关于w=B6-Bp c0w0。的二阶
代数方程，该方程有实的w解的条件，也即刚体有稳定规则旋进的条件为
1-
4gl/.cosd >0.
(6.53)
如果 B≤令并考患到 10 -7002，则由式（6.3g））科
W= ≥ 3, Vmgll cosdo
（6.54）
e,
（a） 单调旋进
（b） 回线运动
（c） 尖齿形运动
图 6-16 对称重刚体的运动图像
式（6.54）表明，仅当刚体自旋角速度大于式（6.54）所给出的极限值时，才可能存在
倾角 0o固定不变的规则旋进.
如果 4mglI cosBo «降，则旋进角速度
mgl
$=20-2u.cosd0
慢旋进，
I sin? 0o
（6.55）
Lswz
~Tc0s0，快旋进.
故当 wx很大时（即所谓快陀螺），旋进角速度有两个值，分别相应于快旋进和慢
旋进.
如果 0>”，即定点位于刚体重心之上，此时刚体悬挂在固定点上，条件式
（6.53） 总满足，即对wz无限制.

===== PDF PAGE 378 =====
6.1
基本内容
•369，
6.1.5
刚体的碰撞
1. 碰撞的特点和分类
1） 碰撞的特点和过程
碰撞过程持续的时间很短，但物体的速度变化很大，相互碰撞的物体受到远大
于普通力的巨大瞬时力（称为碰撞力）的作用，碰撞过程中，相碰的物体发生形
变②. 通常碰撞伴随机械能的损失.
碰撞过程可分为两个阶段，即压缩（或称为变形）阶段和恢复阶段，当两个物
体达到相同的运动状态，则第一个阶段结束，第二个阶段开始.
2） 碰撞的类型
根据两物体碰撞点的公法线与两物体质心的连线的关系可分为：①对心碰撞，
此时公法线方向沿质心连线；② 偏心碰撞，公法线方向与质心连线不一致.
按照碰撞物体在碰撞过程中的相对速度方向与公法线方向的关系又可分为：
① 正碰撞，两个方向相同；② 斜碰撞.
由碰撞的第二个阶段的性质可将碰撞分为三类：① 完全弹性碰撞.两个物体
在第一个阶段所产生的变形在第二阶段可以完全恢复；②完全非弹性碰撞（或称完
全塑性碰撞）.碰撞过程仅有第一个阶段，而无恢复阶段.碰撞结束后，两个物体在
碰撞点完全粘合在一起；③ 非完全弹性碰撞.在恢复阶段，两物体的变形没有完全
恢复.可以用恢复系数e来表征这三类情况，分别对应于e=1,e=0和O<e<1.
恢复系数定义为压缩阶段的碰撞冲量和恢复阶段的碰撞冲量 之比，即
I'
e=T
（6.56）
e 主要取决于碰撞物体的材料.
约束的突然施加或解除之类的问题也归结为碰撞问题.完全弹性碰撞可视为特
珠的散射.
2. 碰撞问题的处理方法及其近似

exit_code=0
```

### 2026-11-16T16:19:12.228925+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qm03:dev python tools/tm03_explore.py
```

```text
{"z0": 0.5, "phidot": 0.3, "thetadot": 0.5, "p": 3, "l": 1.725, "e": 0.65875, "roots": [0.31061585423989463, 0.6332548261673656, 4.21487931959274], "zero": 0.5750000000000001, "mode": "reversing"}
{"z0": 0.5, "phidot": 1.0, "thetadot": 0.2, "p": 3, "l": 2.25, "e": 0.895, "roots": [0.4870210923394925, 0.8223174621915799, 4.085661445468924], "zero": 0.75, "mode": "reversing"}
{"z0": 0.5, "phidot": 0.0, "thetadot": 0.0, "p": 3, "l": 1.5, "e": 0.5, "roots": [0.29743758102333634, 0.5000000000000001, 4.202562418976661], "zero": 0.5, "mode": "reversing"}
{"z0": 0.2, "phidot": -0.5, "thetadot": 0.4, "p": 1.5, "l": -0.17999999999999994, "e": 0.4, "roots": [-0.7703479055635181, 0.24272144004794427, 2.0526264655155733], "zero": -0.11999999999999995, "mode": "reversing"}
{"z0": 0.6, "phidot": 0.4, "thetadot": 0.3, "p": -2, "l": -0.944, "e": 0.6961999999999999, "roots": [-0.1787720017506052, 0.6223777240294779, 2.252594277721128], "zero": 0.472, "mode": "reversing"}
{"z0": 0.5, "phidot": 0.8, "thetadot": 0.7, "p": 1.5, "l": 1.35, "e": 0.985, "roots": [-0.06342214243470673, 0.952182770781619, 1.221239371653087], "zero": 0.9, "mode": "reversing"}
{"z0": 0.1, "phidot": 0.5, "thetadot": 0.2, "p": 0.8, "l": 0.575, "e": 0.24375, "roots": [-0.5860503457849505, 0.13142602645226653, 1.0183743193326849], "zero": 0.7187499999999999, "mode": "monotone"}

exit_code=0
```

### 2026-11-16T16:19:12.573972+08:00

```bash
pdftoppm -f 375 -l 377 -scale-to 1400 -png '/Users/ai4s/Downloads/理论力学学习指导与习题解析(理科用)(第二版)-鞠国兴.pdf' checks/tm-03-source-pages/invariants
```

```text

exit_code=0
```

### 2026-11-16T16:26:39.841812+08:00

```bash
python3 tools/tm03_author.py
```

```text
tm-03 package implementation written

exit_code=0
```

### 2026-11-16T16:26:39.924955+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qm03:dev python tasks/tm-03/solution/solve.py --data-root tasks/tm-03/environment/public --output checks/tm-03-reference-draft.json
```

```text
{"trajectories": [{"id": "top-01", "motion": "periodic", "precession": "reversing", "theta_min": 0.8850448042562793, "theta_max": 1.254955460492659, "period": 2.2972570733578386, "delta_phi": 0.782693604031203, "delta_psi": 11.222059347636232}, {"id": "top-02", "motion": "periodic", "precession": "positive", "theta_min": 1.4389889796744402, "theta_max": 2.196972061481704, "period": 4.045589306425685, "delta_phi": 3.523965511296338, "delta_psi": 5.126000018030629}, {"id": "top-03", "motion": "periodic", "precession": "cusp", "theta_min": 1.0471975511965976, "theta_max": 1.2687886873544298, "period": 2.2783019976887386, "delta_phi": 0.786521243768659, "delta_psi": 11.115649645500381}, {"id": "top-04", "motion": "periodic", "precession": "reversing", "theta_min": 0.8990194966159698, "theta_max": 1.7505345316083245, "period": 3.14092630070307, "delta_phi": -1.3831479657997219, "delta_psi": -9.187078068652902}, {"id": "top-05", "motion": "periodic", "precession": "positive", "theta_min": 0.006761296592931754, "theta_max": 1.445455536495791, "period": 20.146181759872118, "delta_phi": 16.55517171981814, "delta_psi": 36.701353479690255}, {"id": "top-06", "motion": "separatrix", "precession": "positive", "theta_min": 0.0, "theta_max": 1.4454684956268313, "period": null, "delta_phi": null, "delta_psi": null}], "sleeping_tops": [{"id": "sleep-01", "stability": "stable", "frequency_squared": 1.25, "frequency": 1.118033988749895, "growth_rate": 0.0}, {"id": "sleep-02", "stability": "unstable", "frequency_squared": -0.4375, "frequency": 0.0, "growth_rate": 0.6614378277661477}, {"id": "sleep-03", "stability": "critical", "frequency_squared": 0.0, "frequency": 0.0, "growth_rate": 0.0}, {"id": "sleep-04", "stability": "stable", "frequency_squared": 0.3125, "frequency": 0.5590169943749475, "growth_rate": 0.0}], "method": "cubic root factorization and nonsingular period/phase quadrature; critical spin linearization"}

exit_code=0
```

### 2026-11-16T16:29:17.318527+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qm03:dev python tools/build_tm03_truth.py
```

```text
{"id": "top-01", "maximum_turning_energy_residual": "2.3738919364399496868683105673904892885552414584049862415699449977e-66", "maximum_quadrature_partition_difference": "3.3715854120724250818530414281832384287278483342813264004323990047e-44", "precession": "reversing", "period": 2.2972570733578386}
{"id": "top-02", "maximum_turning_energy_residual": "6.8249393172648553497463928812476567045963191929143354445135918684e-66", "maximum_quadrature_partition_difference": "1.5878318110755427446210914104429965290341255386384603583128152337e-43", "precession": "positive", "period": 4.045589306425687}
{"id": "top-03", "maximum_turning_energy_residual": "1.1869459682199748434341552836952446442776207292024931207849724989e-66", "maximum_quadrature_partition_difference": "3.8273556936999968777567627144982028217878062961295015581658320089e-43", "precession": "cusp", "period": 2.278301997688738}
{"id": "top-04", "maximum_turning_energy_residual": "1.1869459682199748434341552836952446442776207292024931207849724989e-66", "maximum_quadrature_partition_difference": "2.2832997541255610933539269765415514505871645513407321937351515162e-44", "precession": "reversing", "period": 3.1409263007030703}
{"id": "top-05", "maximum_turning_energy_residual": "1.1869459682199748434341552836952446442776207292024931207849724989e-66", "maximum_quadrature_partition_difference": "2.0354091710731636566577053326360304682724705445670679245134858103e-42", "precession": "positive", "period": 20.146181759865698}
{"id": "top-06", "motion": "separatrix", "outer_turning_residual": "0.0", "polar_quadratic_coefficient": "-0.21875"}
tm-03 independent truth saved

exit_code=0
```

### 2026-11-16T16:29:56.639616+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qm03:dev python tools/run_tm03_checks.py --calibrate
```

```text
{
  "metric": {
    "kind": "continuous",
    "metric_name": "平均重陀螺章动相位与稳定性误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 12.01273063805162,
    "reference": 2.2464708776158673e-12,
    "tolerance": 1e-05
  },
  "scores": {
    "baseline": {
      "raw_metric": 12.01273063805162,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 2.2464708776158673e-12,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 2.2464708776158673e-12,
      "score": 1.0,
      "status": "completed"
    },
    "wrong": {
      "raw_metric": 85.95055101975004,
      "score": 0.0,
      "status": "completed"
    },
    "finite_separatrix": {
      "raw_metric": 9.20833333333558,
      "score": 0.23345210920099502,
      "status": "completed"
    },
    "modulo_phase": {
      "raw_metric": 11.192139034108697,
      "score": 0.06831016433047818,
      "status": "completed"
    },
    "wrong_classification": {
      "raw_metric": 4.250000000002246,
      "score": 0.6462086657850746,
      "status": "completed"
    },
    "unstable_as_stable": {
      "raw_metric": 3.0000000000022466,
      "score": 0.7502649405541703,
      "status": "completed"
    },
    "malformed": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "duplicate_id": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "infinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "null_periodic": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.1436419169999681,
    "reference_seconds": 0.12103895800009923
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_improves_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "equivalent_reordering_same": true,
    "wrong_answer_penalized": true,
    "reversing_cusp_monotone_present": true,
    "negative_spin_signed_phase": true,
    "near_separatrix_long_finite_period": true,
    "separatrix_infinite_cycle_encoded_null": true,
    "finite_separatrix_penalized": true,
    "unwrapped_phase_required": true,
    "wrong_motion_class_penalized": true,
    "sleeping_stable_unstable_critical": true,
    "unstable_as_stable_penalized": true,
    "invalid_answers_rejected": true,
    "verifier_reference_one_empty_invalid": true,
    "public_feedback_works": true,
    "course_quality_score_unchanged": true
  }
}

exit_code=0
```

### 2026-11-16T16:33:28.769855+08:00

```bash
docker build -t theory-physics-tm03:dev tasks/tm-03/environment
```

```text
#0 building with "desktop-linux" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile: 460B done
#1 DONE 0.0s

#2 [internal] load metadata for mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#2 DONE 0.2s

#3 [internal] load .dockerignore
#3 transferring context: 69B done
#3 DONE 0.0s

#4 [1/5] FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#4 resolve mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2 done
#4 DONE 0.0s

#5 [internal] load build context
#5 transferring context: 6.11kB done
#5 DONE 0.0s

#6 [2/5] COPY requirements.txt /tmp/requirements.txt
#6 CACHED

#7 [3/5] RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt  && useradd --uid 1000 --create-home student  && mkdir -p /app/data /app/output  && chown -R student:student /app
#7 CACHED

#8 [4/5] COPY public/ /app/data/
#8 DONE 0.0s

#9 [5/5] WORKDIR /app
#9 DONE 0.0s

#10 exporting to image
#10 exporting layers 0.0s done
#10 exporting manifest sha256:48b43bd702297981fdd686426e2c621dbfcee13bd0c08fc5a4bd488f4c48402a done
#10 exporting config sha256:5bc38e05e1184a275df672147d9383158e9735c99e5d0402d2ef954dc1fa6058 done
#10 exporting attestation manifest sha256:caaf4abaff68a2e8bbab75a890bfdf20af831fe63c042f8f0866975bd15b65ac done
#10 exporting manifest list sha256:f1987f3b03178cebf76d23b9be4cf960d005075a4250b43af7f1a51ca8d0a45a done
#10 naming to docker.io/library/theory-physics-tm03:dev done
#10 unpacking to docker.io/library/theory-physics-tm03:dev 0.0s done
#10 DONE 0.1s

exit_code=0
```

### 2026-11-16T16:33:29.480467+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g theory-physics-tm03:dev python /app/data/feedback.py --case top-01 --theta 1.0
```

```text
{"effective_potential": 0.5479536097604903, "available_nutation_energy": 0.1107963902395096, "phi_rate": 0.14700888313161248}

exit_code=0
```

### 2026-11-16T16:33:29.745445+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g theory-physics-tm03:dev python /app/data/feedback.py --case top-02 --theta 1.0
```

```text
{"effective_potential": 0.5546933918630894, "available_nutation_energy": -0.3109433918630894, "phi_rate": 0.20161490549039662}

exit_code=0
```

### 2026-11-16T16:34:02.453725+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-tm03:dev python tools/run_tm03_checks.py
```

```text
{
  "metric": {
    "kind": "continuous",
    "metric_name": "平均重陀螺章动相位与稳定性误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 12.01273063805162,
    "reference": 2.2464708776158673e-12,
    "tolerance": 1e-05
  },
  "scores": {
    "baseline": {
      "raw_metric": 12.01273063805162,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 2.2464708776158673e-12,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 2.2464708776158673e-12,
      "score": 1.0,
      "status": "completed"
    },
    "wrong": {
      "raw_metric": 85.95055101975004,
      "score": 0.0,
      "status": "completed"
    },
    "finite_separatrix": {
      "raw_metric": 9.20833333333558,
      "score": 0.23345210920099502,
      "status": "completed"
    },
    "modulo_phase": {
      "raw_metric": 11.192139034108697,
      "score": 0.06831016433047818,
      "status": "completed"
    },
    "wrong_classification": {
      "raw_metric": 4.250000000002246,
      "score": 0.6462086657850746,
      "status": "completed"
    },
    "unstable_as_stable": {
      "raw_metric": 3.0000000000022466,
      "score": 0.7502649405541703,
      "status": "completed"
    },
    "malformed": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "duplicate_id": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "infinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "null_periodic": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.17380133400001796,
    "reference_seconds": 0.17707308300009572
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_improves_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "equivalent_reordering_same": true,
    "wrong_answer_penalized": true,
    "reversing_cusp_monotone_present": true,
    "negative_spin_signed_phase": true,
    "near_separatrix_long_finite_period": true,
    "separatrix_infinite_cycle_encoded_null": true,
    "finite_separatrix_penalized": true,
    "unwrapped_phase_required": true,
    "wrong_motion_class_penalized": true,
    "sleeping_stable_unstable_critical": true,
    "unstable_as_stable_penalized": true,
    "invalid_answers_rejected": true,
    "verifier_reference_one_empty_invalid": true,
    "public_feedback_works": true,
    "course_quality_score_unchanged": true
  }
}

exit_code=0
```

### 2026-11-16T16:34:03.110610+08:00

```bash
python3 -c 'import json; from pathlib import Path; print(json.loads(Path('"'"'checks/tm-03-truth-validation.json'"'"').read_text())['"'"'elapsed_seconds'"'"'])'
```

```text
1.981992751000007

exit_code=0
```

### 2026-11-16T16:34:43.827942+08:00

```bash
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' tm-03 --macos-compat
```

```text
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-tm-03-harbor-57bf8fm9/tm-03 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-tm-03-harbor-57bf8fm9/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:27 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 27s
Results written to 
/tmp/physics-tm-03-harbor-57bf8fm9/runs/oracle/2026-11-16__16-34-44/result.json
Inspect results by running `harbor view 
/tmp/physics-tm-03-harbor-57bf8fm9/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-tm-03-harbor-57bf8fm9/runs/oracle/2026-11-16__16-34-44`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-tm-03-harbor-57bf8fm9/tm-03 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-tm-03-harbor-57bf8fm9/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-tm-03-harbor-57bf8fm9/runs/nop/2026-11-16__16-35-16/result.json
Inspect results by running `harbor view 
/tmp/physics-tm-03-harbor-57bf8fm9/runs/nop`
Share results by running `harbor upload 
/tmp/physics-tm-03-harbor-57bf8fm9/runs/nop/2026-11-16__16-35-16`

{
  "task_id": "tm-03",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-tm-03-harbor-57bf8fm9/tm-03",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-tm-03-harbor-57bf8fm9/tm-03",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-tm-03-harbor-57bf8fm9/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T08:34:43.866874+00:00",
      "archive": "runs/tm-03/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__16-34-44/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "tm-03__pZxh7WD"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-tm-03-harbor-57bf8fm9/tm-03",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-tm-03-harbor-57bf8fm9/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T08:35:16.103161+00:00",
      "archive": "runs/tm-03/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__16-35-16/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "tm-03__AF8nQA7"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}

exit_code=0
```
