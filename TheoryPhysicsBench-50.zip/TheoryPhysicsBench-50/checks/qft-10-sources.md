# 来源与本地改造

François Gelis，*Problems in Quantum Field Theory*，原题 11。

PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5

页码（PDF / 印刷）: [{"pdf": [55, 61], "printed": [43, 49], "role": "完整题面与解答"}]

原书工作：用散射算符端点简并子空间及幺正性，证明完整初末不可分辨态求和消除红外奇异；有明确连续谱及简并集合假设。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

补充过程：Ellis, Ross & Terrano, Nucl.Phys.B178 (1981) 421–456, DOI 10.1016/0550-3213(81)90165-6（e+e− three-jet 矩阵元及NLO）；此题使用单一O(αs)过程，未使用多维有限矩阵代替散射。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。
