
### 2026-11-16T18:23:46.723683+08:00

```bash
python3 -c 'from pathlib import Path; p=Path.cwd(); print("\n".join(str(x/"AGENTS.md")+"\n"+(x/"AGENTS.md").read_text() for x in [p,*p.parents] if (x/"AGENTS.md").exists()))'
```

```text


exit_code=0
```
