
### 2026-11-16T17:47:10.595108+08:00

```bash
cat /Users/ai4s/.codex/plugins/cache/openai-primary-runtime/pdf/26.1112.11217/skills/pdf/SKILL.md
```

```text

### 2026-11-16T17:47:10.595108+08:00

```bash
cat planning/source-notes/qft-expansion-inventory.json
```

```text

### 2026-11-16T17:47:10.595111+08:00

```bash
cat planning/implementation-qft.md
```

```text
# 量子场论五题制作任务

在本项目实际制作 qft-01 至 qft-05，五个独立理论物理问题。先完成一题的全链路再下一题。只写 tasks/qft-*、checks/qft-*、tools/*qft*；不要写根 README 或其他题。

先读 ../../00-老师原始材料/科研探索课程项目/课程大作业说明.md 与附件一、二。题数30和单人是用户与助教另行沟通过的安排，不改老师原始文件。现有 qm-01、ed-01、sp-01 是封装参照；课程 tests/quality_score.py 必须逐字复制老师 tools/quality_score.py。

源材料为用户 Downloads 中《量子场论试题详解》PDF，已提取 planning/source-notes/qft-all.txt。先查索引定位相关知识；确实查看过原页才声称视觉核对，不编造页码。按需要使用 PDF skill。每题记来源、改造和已有 benchmark 区别。任务必须具有数值判断/研究选择，不能仅一道公式代入，不将工况算独立题。

可选方向（可以按源材料调整）：
1. 重整化真空极化的阈值与解析延拓，低能展开对完整复振幅；
---
2. 不同质量衰变三体相空间，近阈值端点和归一化；
[
3. 树图QED散射的干涉、有限质量及角截断下截面；
name: "pdf"
  {
4. RG流的阈值匹配与跨尺度运行，单一beta近似对完整分段流；
description: "Read, create, inspect, render, and verify PDF files where visual layout matters, including fillable AcroForms. Use Poppler rendering plus Python tools such as reportlab, pdfplumber, and pypdf for generation and extraction."
5. 有效势的真空分支、局部/全局稳定性与相变，需与统计物理sp-01的简单平均场三次方程有实质区别。若源材料不支持，换成Ward恒等式/一圈费曼参数积分的另一独立对象。

    "key": "qft-problem-book",
---
    "source": "/Users/ai4s/Downloads/Problem Book in Quantum Field Theory.pdf",

    "pages": 241,
每题交付：中文 instruction.md（物理约定、全部公开输入、反馈、产物schema、完整评价公式、4CPU4GB0GPU agent1200/verifier120秒）；task.toml；environment/Dockerfile（复用qm-01固定依赖）、requirements.txt、.dockerignore、public/下模型与可运行反馈；solution/下合理朴素baseline.py、solve.py/solve.sh、详细推导README；tests/score.py、test.sh、课程原版quality_score.py、metric.json、private真值；tools/build_qftXX_truth.py、run_qftXX_checks.py。基线不能故意弄错物理或用强方案充当基线。参考解只读公开材料，私有真值独立生成且不导入参考求解核心，支持合法等价答案。固定实例可完全公开输入。
# PDF Skill

    "sha256": "26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db",

    "index": "planning/source-notes/qft-problem-book-all.txt",
实际运行本地数值检查，记录平台，不假称Linux；不运行Docker/Harbor，主代理统一运行。若本机缺scipy，用现成 /Users/ai4s/.local/share/uv/tools/harbor/bin/python 或查看可用python；不要安装大量库。每条shell命令写 checks/qft-XX-command-log.md（工具输入也可在最终汇总提供），每题完成就向主代理汇报命令，不等待全部五题。请持续完成实际代码，别停在规划或反复询问权限。
    "total_extracted_characters": 271897,
## When To Use
    "pages_with_under_50_characters": [

      1,
- Read or review PDF content where layout and visuals matter.
      4,
- Create PDFs programmatically with reliable formatting.
      9,
- Fill and validate interactive PDF forms.
      62,

exit_code=0
```
      67
- Validate final rendering before delivery.
    ]

  },
## Tools + Contract Requirements

  {
    "key": "qft-gelis",
Immediately before the first create/edit authoring command, run `mark_artifact_operation_started.mjs` successfully exactly once using the command below. Do not run it for read-only work. For edits, replace `create` with `edit`; adjust the expected count and output format to match the requested outputs.
    "source": "/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf",

    "pages": 375,

    "sha256": "7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5",

    "index": "planning/source-notes/qft-gelis-all.txt",
```bash
    "total_extracted_characters": 740055,
node container_tools/mark_artifact_operation_started.mjs --operation-kind create --expected-output-count 1 --output-format pdf
    "pages_with_under_50_characters": [
```
      1,

      2,
## Workflow
      12,

      236,
1. Prefer visual review: render PDF pages to PNGs and inspect them.
      238
   - Use `pdftoppm` from the bundled runtime or system Poppler when available.
    ]
   - If unavailable, install Poppler or ask the user to review the output locally.
  }
2. Use `reportlab` to generate PDFs when creating new documents.
]
3. Use `pdfplumber` or `pypdf` for text extraction and quick checks; do not rely on text extraction for layout fidelity.
4. After each meaningful update, re-render pages and verify alignment, spacing, and legibility.

## Fill And Validate AcroForms

Visual review alone is not a correctness check for a fillable PDF. A page `/Widget` annotation can render a value from its appearance stream while the canonical `/AcroForm/Fields` tree is missing or contains a stale value.

1. Keep the result interactive by default; set `flatten=True` only when the user explicitly requests a completed, static form. Preserve the source PDF, and do not flatten a signed PDF without an explicit workflow decision.

exit_code=0
```
2. Inspect both representations before filling: enumerate fields from `reader.get_fields()` and `/Widget` annotations from every page's `/Annots`, following `/Parent` and `/Kids`. If a widget and a canonical field have the same name but are distinct objects with no `/Parent` relationship, do not call `reattach_fields()` blindly: it can create a second top-level field with the same name. Report the ambiguity or produce a static result.
3. Recover genuinely orphaned widgets, fill all pages, and write the result with `pypdf`:

```python
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject

reader = PdfReader(input_pdf)
writer = PdfWriter()
writer.clone_document_from_reader(reader)

# Restores widgets that are missing from /AcroForm/Fields.
writer.reattach_fields()
fields = writer.get_fields() or {}
missing = set(expected_values) - set(fields)
if missing:
    raise ValueError(f"Form fields not found after repair: {sorted(missing)}")

values_to_write = dict(expected_values)
if flatten:
    # Paint every existing value before removing every widget.
    values_to_write = {
        name: field.get("/V", "/Off" if field.get("/FT") == "/Btn" else "")
        for name, field in fields.items()
    }
    values_to_write.update(expected_values)

writer.update_page_form_field_values(
    None, values_to_write, auto_regenerate=False, flatten=flatten
)

if flatten:
    # pypdf's flatten=True paints appearances but does not remove widgets.
    writer.remove_annotations(subtypes="/Widget")
    writer.root_object.pop(NameObject("/AcroForm"), None)

with open(output_pdf, "wb") as stream:
    writer.write(stream)
```

4. Reopen the written PDF before delivery. For an interactive result, require every expected field to be present in `get_fields()` with the expected `/V`, enumerate page widgets again, and confirm their effective `/V` (the widget value or inherited `/Parent` value) agrees. Confirm each updated widget has a non-empty `/AP` `/N` appearance and render the final pages to catch stale or clipped appearances. Do not rely on `/NeedAppearances` or a successful PNG render as proof that logical field data was updated.
5. For a flattened result, require zero `/Widget` annotations and no remaining `/AcroForm` field tree after reopening, then render the final pages. Keep an editable copy when the user may need to revise the form.

## Temp And Output Conventions

- Use `tmp/pdfs/` for intermediate files; delete them when done.
- Write final artifacts under `output/pdf/` when working in this repo.
- Keep filenames stable and descriptive.

## Dependencies

Prefer the Codex bundled workspace/runtime dependencies when available. The primary runtime is expected to include:

- Python packages: `reportlab`, `pdfplumber`, `pypdf`
- Rendering tools: `pdftoppm` and `pdfinfo` from Poppler

If a dependency is missing, install only what is needed.

Python packages:

```bash
uv pip install reportlab pdfplumber pypdf
```

If `uv` is unavailable:

```bash
python3 -m pip install reportlab pdfplumber pypdf
```

System tools for rendering:

```bash
# macOS (Homebrew)
brew install poppler

# Ubuntu/Debian
sudo apt-get install -y poppler-utils
```

If installation is not possible in this environment, tell the user which dependency is missing and how to install it locally.

## Environment

No required environment variables.

## Rendering Command

```bash
pdftoppm -png "$INPUT_PDF" "$OUTPUT_PREFIX"
```

## Quality Expectations

- Maintain polished visual design: consistent typography, spacing, margins, and section hierarchy.
- Avoid rendering issues: clipped text, overlapping elements, broken tables, black squares, or unreadable glyphs.
- Charts, tables, and images must be sharp, aligned, and clearly labeled.
- Use ASCII hyphens only. Avoid U+2011 and other Unicode dashes.
- Citations and references must be human-readable; never leave tool tokens or placeholder strings.

## Final Checks

- Do not deliver until the latest PNG inspection shows zero visual or formatting defects.
- Confirm headers, footers, page numbering, and section transitions look polished.
- Keep intermediate files organized or remove them after final approval.

## Final response

### Final Response Citations

- **Create/edit:** for created or edited PDFs, cite each final deliverable exactly once with `purpose="output"`, in its own paragraph. Briefly describe the result without repeating its filename, path, or link. Never put output directives inside prose or list items.
- **Q&A and summaries:** Every file whose contents you summarize or use to support an answer MUST receive a `:codex-file-citation{...}` with `purpose="source"` in the final response. Use the source citation in place of the filename, wherever the filename would appear. Do not write the filename separately and append its citation at the end. Files merely inspected but not used in the answer need no citation. Do not emit output citations for unchanged files or read-only answers.

- Emit `:codex-file-citation{...}` directly, without backticks, code fences, or a Markdown-link wrapper. Use verified targets only. No need to cite or reference intermediate work.

For file citations, set `path` to the verified absolute file path on the task host. Omit `mode`.

Some illustrative examples, real responses use verified targets outside code fences.

```text
:codex-file-citation{path="/absolute/path/review.pdf" purpose="output"}
```

```text
The review of :codex-file-citation{path="/absolute/path/review.pdf" purpose="source"} is due Friday.
```


### Additional Citation Guidance

For PDF Q&A, inspect complete relevant pages and preserve material headings, table/figure labels, footnotes, sources, and sample sizes. PDF citations support only plain file citations; do not add `artifact_kind`, `page_number`, or other locators.

exit_code=0
```

### 2026-11-16T17:47:27.789082+08:00

```bash
rg -n '^===== PDF PAGE|4\.33|5\.18|10\.10|11\.8|11\.12|11\.13|11\.14' planning/source-notes/qft-problem-book-all.txt
```

```text

### 2026-11-16T17:47:27.789051+08:00

```bash
rg --files tasks/qft-01 tasks/qft-02 tasks/qft-03 tasks/qft-04
```

```text
tasks/qft-04/task.toml
tasks/qft-02/task.toml
tasks/qft-01/task.toml
2:===== PDF PAGE 1 =====
tasks/qft-03/task.toml
5:===== PDF PAGE 2 =====
tasks/qft-03/environment/public/metric.json
12:===== PDF PAGE 3 =====
tasks/qft-03/environment/public/physics.py
39:===== PDF PAGE 4 =====
tasks/qft-03/environment/public/feedback.py
42:===== PDF PAGE 5 =====
tasks/qft-03/environment/public/model.json
76:===== PDF PAGE 6 =====
tasks/qft-03/environment/Dockerfile
87:===== PDF PAGE 7 =====
tasks/qft-03/environment/requirements.txt
106:===== PDF PAGE 8 =====
tasks/qft-03/instruction.md
119:===== PDF PAGE 9 =====
tasks/qft-02/environment/public/metric.json
123:===== PDF PAGE 10 =====
tasks/qft-02/environment/public/physics.py
188:===== PDF PAGE 11 =====
tasks/qft-02/environment/public/feedback.py
224:===== PDF PAGE 12 =====
tasks/qft-02/environment/public/model.json
274:===== PDF PAGE 13 =====
tasks/qft-02/environment/Dockerfile
317:===== PDF PAGE 14 =====
tasks/qft-02/environment/requirements.txt
356:===== PDF PAGE 15 =====
tasks/qft-02/instruction.md
392:===== PDF PAGE 16 =====
tasks/qft-03/solution/solve.py
446:===== PDF PAGE 17 =====
tasks/qft-03/solution/solver_core.py
467:===== PDF PAGE 18 =====
tasks/qft-03/solution/README.md
533:===== PDF PAGE 19 =====
tasks/qft-03/solution/solve.sh
568:===== PDF PAGE 20 =====
tasks/qft-03/solution/baseline.py
610:===== PDF PAGE 21 =====
tasks/qft-03/tests/score.py
625:===== PDF PAGE 22 =====
tasks/qft-03/tests/test.sh
664:===== PDF PAGE 23 =====
tasks/qft-03/tests/metric.json
700:===== PDF PAGE 24 =====
tasks/qft-04/environment/public/metric.json
744:===== PDF PAGE 25 =====
tasks/qft-04/environment/public/physics.py
tasks/qft-04/environment/public/feedback.py
tasks/qft-04/environment/public/model.json
tasks/qft-04/environment/Dockerfile
tasks/qft-04/environment/requirements.txt
tasks/qft-04/instruction.md
tasks/qft-03/tests/private/truth.json
tasks/qft-03/tests/quality_score.py
tasks/qft-03/tests/development_cases.py
790:===== PDF PAGE 26 =====
tasks/qft-01/environment/public/metric.json
tasks/qft-04/solution/solve.py
830:===== PDF PAGE 27 =====
tasks/qft-01/environment/public/physics.py
879:4.33. L e ta ne l e c t r o nm o v ei nap o t e n t i a lh o l e2a wide andV deep. Consider
tasks/qft-01/environment/public/feedback.py
887:===== PDF PAGE 28 =====
tasks/qft-01/environment/public/model.json
938:===== PDF PAGE 29 =====
tasks/qft-01/environment/Dockerfile
965:===== PDF PAGE 30 =====
tasks/qft-01/environment/requirements.txt
1004:===== PDF PAGE 31 =====
tasks/qft-01/instruction.md
1064:===== PDF PAGE 32 =====
tasks/qft-02/solution/solve.py
1114:===== PDF PAGE 33 =====
tasks/qft-02/tests/score.py
1166:===== PDF PAGE 34 =====
tasks/qft-02/solution/solver_core.py
1177:5.18. In general, the canonical energy–momentum tensor is not symmetric
tasks/qft-02/solution/README.md
1210:===== PDF PAGE 35 =====
tasks/qft-02/solution/solve.sh
1222:===== PDF PAGE 36 =====
tasks/qft-02/solution/baseline.py
1253:===== PDF PAGE 37 =====
tasks/qft-04/solution/solver_core.py
1291:===== PDF PAGE 38 =====
tasks/qft-04/solution/README.md
1343:===== PDF PAGE 39 =====
tasks/qft-04/solution/solve.sh
1352:===== PDF PAGE 40 =====
tasks/qft-04/solution/baseline.py
1392:===== PDF PAGE 41 =====
tasks/qft-02/tests/test.sh
1430:===== PDF PAGE 42 =====
tasks/qft-02/tests/metric.json
1464:5.18. Instead of the classical ﬁeld, use the corresponding operator. Prove the
tasks/qft-01/solution/solve.py
1475:===== PDF PAGE 43 =====
tasks/qft-01/solution/solver_core.py
1517:===== PDF PAGE 44 =====
tasks/qft-01/solution/README.md
1559:===== PDF PAGE 45 =====
tasks/qft-01/solution/solve.sh
1606:===== PDF PAGE 46 =====
tasks/qft-01/solution/baseline.py
1657:===== PDF PAGE 47 =====
tasks/qft-02/tests/development_cases.py
1704:===== PDF PAGE 48 =====
tasks/qft-02/tests/quality_score.py
1748:===== PDF PAGE 49 =====
tasks/qft-01/tests/score.py
1794:===== PDF PAGE 50 =====
tasks/qft-04/tests/score.py
1836:===== PDF PAGE 51 =====
tasks/qft-01/tests/test.sh
1883:===== PDF PAGE 52 =====
tasks/qft-01/tests/metric.json
1924:===== PDF PAGE 53 =====
tasks/qft-04/tests/test.sh
1973:===== PDF PAGE 54 =====
tasks/qft-04/tests/metric.json
2008:===== PDF PAGE 55 =====
tasks/qft-04/tests/private/truth.json
2040:whereMij was found in Problem 5.18.
tasks/qft-01/tests/private/truth.json
2055:===== PDF PAGE 56 =====
tasks/qft-04/tests/quality_score.py
2114:===== PDF PAGE 57 =====
tasks/qft-04/tests/development_cases.py
2165:===== PDF PAGE 58 =====
tasks/qft-01/tests/development_cases.py
2202:===== PDF PAGE 59 =====
tasks/qft-01/tests/quality_score.py
2246:===== PDF PAGE 60 =====
tasks/qft-02/tests/private/truth.json
2285:10.10. Calculate the cross section per unit volume for the creation of electron–
2290:===== PDF PAGE 61 =====
2325:===== PDF PAGE 62 =====
2330:===== PDF PAGE 63 =====
2396:===== PDF PAGE 64 =====
2458:===== PDF PAGE 65 =====
2484:11.8. The Lagrangian density is given by
2514:===== PDF PAGE 66 =====

exit_code=0
```
2523:11.12. The Lagrangian density for the pseudoscalar Yukawa theory is given
2539:11.13. Consider massless two–dimensional QED, the so–called Schwinger mo-
2543:11.14. Considerφ3 theory in six–dimensional spacetime, with the Lagrangian
2558:===== PDF PAGE 67 =====
2562:===== PDF PAGE 68 =====
2588:===== PDF PAGE 69 =====
2627:===== PDF PAGE 70 =====
2738:===== PDF PAGE 71 =====
2791:===== PDF PAGE 72 =====
2841:===== PDF PAGE 73 =====
2880:===== PDF PAGE 74 =====
2924:===== PDF PAGE 75 =====
3009:===== PDF PAGE 76 =====
3045:===== PDF PAGE 77 =====
3058:===== PDF PAGE 78 =====
3098:===== PDF PAGE 79 =====
3166:===== PDF PAGE 80 =====
3222:===== PDF PAGE 81 =====
3267:===== PDF PAGE 82 =====
3319:===== PDF PAGE 83 =====
3385:===== PDF PAGE 84 =====
3456:===== PDF PAGE 85 =====
3576:===== PDF PAGE 86 =====
3622:===== PDF PAGE 87 =====
3661:===== PDF PAGE 88 =====
3702:===== PDF PAGE 89 =====
3743:===== PDF PAGE 90 =====
3799:===== PDF PAGE 91 =====
3835:===== PDF PAGE 92 =====
3889:===== PDF PAGE 93 =====
3977:===== PDF PAGE 94 =====
4019:===== PDF PAGE 95 =====
4093:===== PDF PAGE 96 =====
4213:===== PDF PAGE 97 =====
4253:===== PDF PAGE 98 =====
4349:===== PDF PAGE 99 =====
4405:===== PDF PAGE 100 =====
4470:===== PDF PAGE 101 =====
4527:===== PDF PAGE 102 =====
4629:===== PDF PAGE 103 =====
4701:===== PDF PAGE 104 =====
4709:iσμSRΛμν∂νψR(x)= mSLψL(x), (4.33)
4711:By multiplying Equation (4.33) byS−1L from left, and (4.34) byS−1R also
4763:===== PDF PAGE 105 =====
4801:===== PDF PAGE 106 =====
4849:===== PDF PAGE 107 =====
4928:===== PDF PAGE 108 =====
5012:===== PDF PAGE 109 =====
5089:===== PDF PAGE 110 =====
5193:===== PDF PAGE 111 =====
5195:4.33
5278:===== PDF PAGE 112 =====
5316:===== PDF PAGE 113 =====
5322:===== PDF PAGE 114 =====
5387:===== PDF PAGE 115 =====
5454:===== PDF PAGE 116 =====
5505:===== PDF PAGE 117 =====
5543:===== PDF PAGE 118 =====
5642:===== PDF PAGE 119 =====
5722:===== PDF PAGE 120 =====
5772:===== PDF PAGE 121 =====
5814:===== PDF PAGE 122 =====
5879:===== PDF PAGE 123 =====
5940:===== PDF PAGE 124 =====
5988:===== PDF PAGE 125 =====
6047:===== PDF PAGE 126 =====
6068:5.18
6099:===== PDF PAGE 127 =====
6151:===== PDF PAGE 128 =====
6200:===== PDF PAGE 129 =====
6242:d4x′ =e −4ρd4x ≈ (1 − 4ρ)d4x, (5.18)
6249:===== PDF PAGE 130 =====
6287:===== PDF PAGE 131 =====
6315:===== PDF PAGE 132 =====
6351:===== PDF PAGE 133 =====
6417:===== PDF PAGE 134 =====
6488:===== PDF PAGE 135 =====
6551:===== PDF PAGE 136 =====
6599:===== PDF PAGE 137 =====
6674:===== PDF PAGE 138 =====
6774:===== PDF PAGE 139 =====
6807:===== PDF PAGE 140 =====
6880:===== PDF PAGE 141 =====
6942:===== PDF PAGE 142 =====
7009:===== PDF PAGE 143 =====
7062:===== PDF PAGE 144 =====
7101:===== PDF PAGE 145 =====
7164:===== PDF PAGE 146 =====
7218:===== PDF PAGE 147 =====
7269:===== PDF PAGE 148 =====
7321:===== PDF PAGE 149 =====
7395:===== PDF PAGE 150 =====
7462:===== PDF PAGE 151 =====
7544:===== PDF PAGE 152 =====
7597:===== PDF PAGE 153 =====
7659:===== PDF PAGE 154 =====
7726:===== PDF PAGE 155 =====
7781:===== PDF PAGE 156 =====
7855:===== PDF PAGE 157 =====
7924:===== PDF PAGE 158 =====
7961:===== PDF PAGE 159 =====
8015:===== PDF PAGE 160 =====
8112:===== PDF PAGE 161 =====
8169:===== PDF PAGE 162 =====
8267:===== PDF PAGE 163 =====
8334:===== PDF PAGE 164 =====
8388:===== PDF PAGE 165 =====
8448:===== PDF PAGE 166 =====
8509:===== PDF PAGE 167 =====
8544:===== PDF PAGE 168 =====
8588:===== PDF PAGE 169 =====
8654:===== PDF PAGE 170 =====
8715:===== PDF PAGE 171 =====
8783:===== PDF PAGE 172 =====
8845:===== PDF PAGE 173 =====
8880:===== PDF PAGE 174 =====
8913:===== PDF PAGE 175 =====
8948:===== PDF PAGE 176 =====
8958:===== PDF PAGE 177 =====
9022:===== PDF PAGE 178 =====
9070:===== PDF PAGE 179 =====
9118:===== PDF PAGE 180 =====
9208:===== PDF PAGE 181 =====
9259:lem 5.18 using the Nether technique. It follows that (in the Coulomb gauge)
9264:===== PDF PAGE 182 =====
9336:===== PDF PAGE 183 =====
9424:===== PDF PAGE 184 =====
9496:===== PDF PAGE 185 =====
9551:===== PDF PAGE 186 =====
9633:===== PDF PAGE 187 =====
9785:===== PDF PAGE 188 =====
9879:===== PDF PAGE 189 =====
9920:===== PDF PAGE 190 =====
10009:===== PDF PAGE 191 =====
10078:===== PDF PAGE 192 =====
10097:+ 24(iΔF(x −y))4 . (10.10)
10114:===== PDF PAGE 193 =====
10186:===== PDF PAGE 194 =====
10225:===== PDF PAGE 195 =====
10294:===== PDF PAGE 196 =====
10339:===== PDF PAGE 197 =====
10375:===== PDF PAGE 198 =====
10457:===== PDF PAGE 199 =====
10530:===== PDF PAGE 200 =====
10546:10.10 The initial state is vacuum |0⟩, while the ﬁnal state is
10602:===== PDF PAGE 201 =====
10695:===== PDF PAGE 202 =====
10745:===== PDF PAGE 203 =====
10820:===== PDF PAGE 204 =====
10875:===== PDF PAGE 205 =====
10938:===== PDF PAGE 206 =====
10993:===== PDF PAGE 207 =====
11058:===== PDF PAGE 208 =====
11073:===== PDF PAGE 209 =====
11126:===== PDF PAGE 210 =====
11200:===== PDF PAGE 211 =====
11219:dte−ttz−1 . (11.8)
11226:By using the deﬁnition of number e, the integral (11.8) becomes
11283:===== PDF PAGE 212 =====
11304:. (11.12)
11309:n − 1 . (11.13)
11312:=1 −γϵ +o(ϵ). (11.14)
11363:===== PDF PAGE 213 =====
11451:===== PDF PAGE 214 =====
11516:===== PDF PAGE 215 =====
11624:===== PDF PAGE 216 =====
11737:===== PDF PAGE 217 =====
11802:===== PDF PAGE 218 =====
11875:===== PDF PAGE 219 =====
11930:11.8 The vertices in this theory are shown in Fig. 11.2.
11941:===== PDF PAGE 220 =====
12000:===== PDF PAGE 221 =====
12045:===== PDF PAGE 222 =====
12107:===== PDF PAGE 223 =====
12158:===== PDF PAGE 224 =====
12214:===== PDF PAGE 225 =====
12261:11.12
12280:===== PDF PAGE 226 =====
12327:===== PDF PAGE 227 =====
12386:===== PDF PAGE 228 =====
12457:===== PDF PAGE 229 =====
12517:===== PDF PAGE 230 =====
12573:===== PDF PAGE 231 =====
12606:11.13 In this problem dimension of spacetime isD =2 −ϵ.
12647:===== PDF PAGE 232 =====
12697:11.14 The dimension of spacetime isD =6 −ϵ.
12706:===== PDF PAGE 233 =====
12726:in Figure 11.8.
12727:Fig. 11.8. Feynman rules in φ3 theory
12732:===== PDF PAGE 234 =====
12808:===== PDF PAGE 235 =====
12868:===== PDF PAGE 236 =====
12904:===== PDF PAGE 237 =====
12940:===== PDF PAGE 238 =====
12954:===== PDF PAGE 239 =====
13019:===== PDF PAGE 240 =====
13112:===== PDF PAGE 241 =====

exit_code=0
```

### 2026-11-16T17:49:07.838967+08:00

```bash
sed -n '870,925p;1168,1205p;2280,2315p;2475,2575p;5190,5245p;6060,6100p;10080,10130p;10535,10595p;11920,11995p;12250,12315p;12590,12730p' planning/source-notes/qft-problem-book-all.txt
```

```text
{ 0,z < 0
V, z> 0 .
Calculate the coeﬃcients of reﬂection and transmission.
4.32. Find the coeﬃcients of reﬂection andtransmission for an electron mov-
ing in a potential barrier:
−eA0 =
{0,z < 0,z>a
V, 0<z<a .
The energy of the electron isE, while its helicity is 1/2.
4.33. L e ta ne l e c t r o nm o v ei nap o t e n t i a lh o l e2a wide andV deep. Consider
only bound states of the electron.
(a) Find the dispersion relations.
(b) Determine the relation betweenV anda if there areN bound states. Take
V< 2m. If there is only one bound state present in the spectrum, is it
odd or even?
(c) Give a rough description of the dispersion relations forV> 2m.

===== PDF PAGE 28 =====
Chapter 4. The Dirac equation 23
4.34. Determine the energy spectrum of a n electron in a constant magnetic
ﬁeld B =Bez.
4.35. Show that ifψ(x) is a solution of the Dirac equation in an electromag-
netic ﬁeld, then it satisﬁes the ”generalize” Klein-Gordon equation:
[(∂μ − ieAμ)(∂μ − ieAμ) −e
2σμνFμν +m2]ψ(x)=0 ,
whereFμν =∂μAν −∂νAμ is the ﬁeld strength tensor.
4.36. Find the nonrelativistic approximation of the Dirac Hamiltonian H =
α · (p +eA) −eA0 +mβ, including terms of order v2
c2 .
4.37. IfVμ(x)= ¯ψ(x)γμψ(x) is a vector ﬁeld, show thatVμ is a real quantity.
Find the transformation properties of this quantity under proper orthochro-
nous Lorentz transformations, charge conjugation C,p a r i t yP and time re-
versalT.
4.38. Investigate the transformation properties of the quantity Aμ(x)=
¯ψ(x)γμγ5ψ(x), under proper orthochronous Lorentz transformations and the
discrete transformationsC,P andT.
4.39. Prove that the quantity ¯ψ(x)γμ∂μψ(x) is a Lorentz scalar. Find its
transformation rules under the discrete transformations.
4.40. Using the Dirac equation, show that C¯uT (p,s )= v(p,s ), where C is
charge conjugation. Also, prove the above relation in a concrete representa-
tion.
4.41. The matrixC is deﬁned by
CγμC−1 = −γTμ .
Prove that if matricesC′ andC′′ satisfy the above relation, then C′ =kC ′′,
wherek is a constant.
4.42. If
ψ(x)= Np
⎛
⎜⎜⎝
(
1
0
)
σ3p
Ep +m
(
whereσ is a scalar ﬁeld, π is a three–component scalar ﬁeld,Ψ a doublet of
spinor ﬁelds, while τ are Pauli matrices. Prove that the Lagrangian density
L has the symmetry:
σ(x) →σ(x),
π(x) → π(x) − α × π(x),
Ψ(x) →Ψ(x)+i α · τ
2 Ψ(x),
where α is an inﬁnitesimal constant vector. Find the corresponding conserved
current.
5.18. In general, the canonical energy–momentum tensor is not symmetric
under the permutation of indices. The energy–momentum tensor is not unique:
a new equivalent energy–momentum tensor can be deﬁned by adding a four-
divergence
˜Tμν =Tμν +∂ρχρμν ,
whereχρμν = −χμρν. The two energy–momentum tensors are equivalent since
they lead to the same conserved charges, i.e. both satisfy the continuity equa-
tion. If we take that the tensorχμνρ is given by1
χμνρ = 1
2
(
− ∂L
∂(∂μφr)(Iρν)rs + ∂L
∂(∂ρφr)(Iμν)rs + ∂L
∂(∂νφr)(Iμρ)rs
)
then ˜Tμν is symmetric2. The quantities (Iρν)rs in the previous formula are
deﬁned by the transformation law of ﬁelds under Lorentz transformations:
δφr ≡φ′r(x′) −φr(x)= 1
2ωμν(Iμν)rsφs(x).
(a) Find the energy–momentum and angular momentum tensors for scalar,
Dirac and electromagnetic ﬁelds employing the Noether theorem.
(b) Applying the previously describedprocedure, ﬁnd the symmetrized (or Be-
linfante) energy–momentum tensors for the Dirac and the electromagnetic
ﬁeld.
5.19. Under dilatations the coordinates are transformed as
x →x′ =e −ρx.
The corresponding transformation rule for a scalar ﬁeld is given by
φ(x) →φ′(x′)=e ρφ(x),
external electromagnetic ﬁeld (a,g,k are constants)
(a)Aμ(x)=( ae−k2x2, 0, 0, 0),
(b)Aμ(x)=( 0, 0, 0, g
r e−r/a).
The initial electron is moving alongz–axis.
10.10. Calculate the cross section per unit volume for the creation of electron–
positron pairs by the electromagnetic potential
Aμ =( 0, 0,a e−iωt, 0),
whereω anda are constants.

===== PDF PAGE 61 =====
Chapter 10. Processes in the lowest order of perturbation theory 59
10.11. Find the diﬀerential cross section f or the scattering of an electron in
the external potential
Aμ =( 0, 0, 0,a e−k2x2 ),
for a theory which is the same as QED except the fact that the vertex ieγμ is
replaced by ieγμ(1 −γ5). The initial electron is moving alongz–axis.
10.12. Find the diﬀerential cross section f or the scattering of a positron in
the external potential
Aμ =( g
r, 0, 0, 0),
whereg is a constant. TheS–matrix element is given by
Sﬁ =ie
∫
d4x ¯ψf(x)∂μψi(x)Aμ(x).
10.13. Calculate the cross section for the scattering of an electron with posi-
tive helicity in the electromagnetic potential
Aμ =(aδ(3)(x), 0, 0, 0),
wherea is a constant.
10.14. Calculate the diﬀerential cross section for scattering ofe− and a muon
μ+
e−μ+ →e−μ+ ,
in the center–of–mass system. Assume that initial particles have negative he-
licity, while the spin states of ﬁnal particles are arbitrary.
10.15. Consider the theory of interaction of a spinor and scalar ﬁeld:
L = 1
(c) Prove that
ImΠ(M 2)= −MΓ.
11.7. Consider the theory
L = 1
2(∂μφ)2 −m2
2 φ2 − g
3!φ3 − λ
4!φ4 .
Find the expression for the self–energy and the mass shiftδm.
11.8. The Lagrangian density is given by
L = 1
2(∂μσ)2 + 1
2(∂μπ)2 −m2
2 σ2 −λvσ3 −λvσπ2 −λ
4 (σ2 +π2)2 ,
whereσ andπ are scalar ﬁelds, and v2 = m2
2λ is constant. Classically,π ﬁeld
is massless. Show that it also remains massless when the one–loop corrections
are included.
11.9. Find the divergent part of the diagram
Prove that this diagram cancels with the diagram of the reverse orientation
inside the fermion loop.
11.10. The polarization of vacuum in QED has form
−iΠμν(q)= −i(qμqν −q2gμν)Π(q2).
Prove the following expression:
ImΠ(q2)= − e2
12π
(
1+ 2m2
q2
)√
1 − 4m2
q2 θ
(
1 − 4m2
q2
)
.

===== PDF PAGE 66 =====
64 Problems
11.11. In scalar electrodynamics two diagrams give contribution to the po-
larization of vacuum. Using dimensional regularization derive the following
expression for the divergent part of the vacuum polarization:
ie2
24π2
1
ϵ (pμpν −p2gμν).
11.12. The Lagrangian density for the pseudoscalar Yukawa theory is given
by
L = 1
2(∂φ)2 −m2
2 φ2 + ¯ψ(iγμ∂μ −M)ψ − ig ¯ψγ5ψφ − λ
4!φ4 .
(a) Find the superﬁcial degree of divergence for this theory and the corre-
sponding divergent amplitudes. Write the bare Lagrangian density as a
sum of the initial Lagrangian density and counterterms. Write out the
Feynman rules in the renormalized theory.
(b) Find the self–energy of the spinor ﬁeld at one–loop and determine the
corresponding counterterms.
(c) Find the self–energy of the scalar ﬁeld at one–loop and determine the
corresponding counterterms.
(d) Calculate the one–loop vertex correctionφ ¯ψψ andδg.
(e) Calculate the one–loop vertex correctionφ4 andδλ.
11.13. Consider massless two–dimensional QED, the so–called Schwinger mo-
del.
(a) Calculate the vacuum polarization at one–loop.
(b) Find the full photon propagator and read oﬀ the mass of the photon.
11.14. Considerφ3 theory in six–dimensional spacetime, with the Lagrangian
density given by
L = 1
2(∂φ)2 −m2
2 φ2 − g
3!φ3 −hφ.
(a) Determine the superﬁcial divergent amplitudes. Write the renormalized
Lagrangian density and derive the Feynman rules.
(b) Calculate the tadpole one–loop diagram and explain why the contribution
of the tadpole diagrams can be ignored.
(c) Calculate the propagator correction at one–loop order and determine δZ
andδm. Use the minimal subtraction (MS) scheme.
(d) Calculate the vertex correction and ﬁndδg.
(e) Derive the relationsm0 =m0(m,g,ϵ )a n dg0 =g0(m,g,ϵ ).

===== PDF PAGE 67 =====
Part II
Solutions

===== PDF PAGE 68 =====
1
Lorentz and Poincar´e symmetries
1.1 The square of the length of a four–vector, x isx2 =gμνxμxν. By substi-
tutingx′μ =Λμρxρ into the conditionx′2 =x2 one obtains:
gμνΛμρΛνσxρxσ =gρσxρxσ . (1.1)
Since (1.1) is valid for any vector x ∈ M4,w eg e tΛμρgμνΛνσ = gρσ. The
previous condition can be rewritten in the following form
(ΛT )ρμgμνΛνσ =gρσ ⇒ΛTgΛ =g, (1.2)
and we have obtained the requested expression.
Now, we shall show that the Lorentz transformations form a group. If
Λ1 andΛ2 are Lorentz transformations then their product, Λ1Λ2 is Lorentz
transformation because it satisﬁes the condition (1.2):
(Λ1Λ2)Tg(Λ1Λ2)= ΛT2 (ΛT1gΛ1)Λ2 =ΛT2gΛ2 =g.
E+m
E+m−V .

===== PDF PAGE 111 =====
110 Solutions
4.33
(a) The wave function is
ψI =
⎛
⎜⎝
B
B′
−iκσ3
(E+m)
(
B
B′
)
⎞
⎟⎠ eκz,z < −a,
ψII =
⎛
⎜⎝
C
C′
qσ3
(E+m+V )
(
C
C′
)
⎞
⎟⎠eiqz (4.71)
+
⎛
⎜⎝
D
D′
−qσ3
(E+m+V )
(
D
D′
)
⎞
⎟⎠e−iqz, −a<z<a,
ψIII =
⎛
⎜⎝
F
F ′
iκσ3
(E+m)
(
F
F ′
∂(∂μ ¯Ψi)
= −ϵabcαb∂μπaπc − 1
2
¯ΨiγμαaτaijΨj .
The ﬁnal result has the form
jμ = π ×∂μπ + 1
2
¯ΨγμτΨ.
5.18
(a) For translations, we haveδxμ =ϵμ, while the total variations of the ﬁelds
equal zero. The Noether current is
Tμν = ∂L
∂(∂μφr)
∂φr
∂xν
−Lgμν . (5.2)
The indexν in (5.2) comes from the group of translations. For a real scalar
ﬁeld, from (5.2) we obtain
Tμν =∂μφ∂νφ − 1
2
[
(∂φ)2 −m2φ2]gμν . (5.3)
The conserved charges are the Hamiltonian (forν =0 ) ,
H =
∫
d3xT 00 = 1
2
∫
d3x[(∂0φ)2 +( ∇φ)2 +m2φ2] , (5.4)
and the momentum (forν =i)
Pi =
∫
d3xT 0i =
∫
d3x∂0φ∂iφ. (5.5)
For the Dirac ﬁeld the energy–momentum tensor is given by
Tμν =i ¯ψγμ∂νψ −Lgμν .
The Hamiltonian and momentum are given by

===== PDF PAGE 127 =====
Chapter 5. Classical ﬁelds and symmetries. 127
φ(y)′s . The obtained result has to be multiplied by 6, because this is
the number of ways in which two ﬁeldsφ(x) can be chosen from the four
possible. Thus, there are 4 · 3 · 6 = 72 possible contractions of this type.
There are three mutual contractions between two ﬁelds φ(x), the similar
is obtained for ﬁeldsφ(y), so the corresponding coeﬃcient is 9. Thus,
⟨0|T(φ4(x)φ4(y)) |0⟩) = 24(⟨0|T(φ(x)φ(y)) |0⟩)4
+7 2 ⟨0|T(φ(x)φ(x)) |0⟩⟨0|T(φ(y)φ(y)) |0⟩(⟨0|T(φ(x)φ(y)) |0⟩)2
+9 (⟨0|T(φ(x)φ(x)) |0⟩)2(⟨0|T(φ(y)φ(y)) |0⟩)2
= 24(iΔF(x −y))4 + 72(iΔF(x −x))iΔF(y −y)(iΔF(x −y))2
+9 ( iΔF(x −x))2(iΔF(y −y))2 .
The last expression can be represented by the following diagram:
24· yx +72· x y
+9· x y
(b) Here, the equal–time contractions are forbidden. The result is
T(:φ4(x): :φ4(y): )=1 6: φ3(x)φ3(y):i ΔF(x −y)
+7 2: φ2(x)φ2(y):( iΔF(x −y))2
+9 6: φ(x)φ(y):( iΔF(x −y))3
+ 24(iΔF(x −y))4 . (10.10)
(c) By applying Wick’s theorem for fermions one obtains
⟨0|T( ¯ψ(x)ψ(x) ¯ψ(y)ψ(y)) |0⟩
=iSF(x −x)iSF(y −y) − iSF(x −y)iSF(y −x).
10.5
(a) The given diagram is obtained from the expression
−iλ
4!
∫
d4y ⟨0|T(φ(x1)φ(x2)φ4(y)) |0⟩ ,
whereφ(x1) is to be contracted with one φ(y) (there are four ways to do
this) and φ(x2) with one of the remaining three φ(y)′s. The symmetry
factor is 1
4!4 ·3= 1
2 . This result can be easily checked by using the formula
given in the problem, whereg =1,α =0a n dβ =1 .

===== PDF PAGE 193 =====
Chapter 10. Processes in the lowest order of the perturbation theory 195
(b) This diagram is one of the terms in
1
2!
(
−iλ
4!
)2 ∫
d4y1d4y2 ⟨0|T(φ(x1)φ(x2)φ4(y1)φ4(y2)) |0⟩ ,
whereφ(x1) is contracted with one of the fourφ(y1)′s (there are four ways
to do this); φ(x2) with one of the remaining φ(y1) ﬁelds (there are three
ways to do this). It is necessary to make two more contractions between
φ(y1)a n dφ(y2)w h i c hc a nb ed o n ei n4· 3=1 2w a y s .T h u sw eh a v e :
S−1 =2 ! 1
2!
( 1
V 2EiEf
1
(
q2 + 1
a2
)2δ(Ef −Ei)(EiEf + |pi||pf | sinθ −m2).
The diﬀerential cross section is:
dσ
dΩ =2e2g2 (E2 −m2)(1 + cosθ)
( 1
a2 +2 (E2 −m2)(1 − cosθ))2 .
10.10 The initial state is vacuum |0⟩, while the ﬁnal state is
|f⟩ =c
†
(p1,r )d
†
(p2,s ) |0⟩ .
The transition amplitude is
Sﬁ = ie
V
∫
d4x∑
r′s′
∫
d3q1d3q2
√
 m
Eq1
√
 m
Eq2
⟨0|d(p2,s )c(p1,r )
× (c
†
(q1,r ′)d† (q2,s ′)¯u(q1,r ′)γμAμ(x)v(q2,s ′)eiq1 ·x+iq2 ·x +... ) |0⟩ ,
where we have dropped the vanishing terms. After reducing the last expression
one obtains
Sﬁ =ie ma
V √
E1E2
∫
d4x ¯u(p1,r )γ2v(p2,s )ei(p2+p1 )·xe−iωt
=ie(2π)4 ma
V √
E1E2
× ¯u(p1,r )γ2v(p2,s )δ(3)(p1 + p2)δ(E1 +E2 −ω).
The average value of the squared transition amplitude is
⟨
|Sﬁ|2⟩ =( 2π)4TVδ (3)(p1 + p2)δ(E1 +E2 −ω)
× e2a2
4V 2E1E2 tr[(/p1 +m)γ2(/p2 −m)γ2]
=( 2π)4Tδ (3)(p1 + p2)δ(E1 +E2 −ω) e2a2
VE 1E2
× (E1E2 + |p1||p2|− 2|p1||p2| sin2θ cos2φ +m2),
since the four-momenta are:
pμ1 =(E1,p 1 sinθ cosφ,p 1 sinθ sinφ,p 1 cosθ),
pμ2 =(E2, −p2 sinθ cosφ, −p2 sinθ sinφ, −p2 cosθ).
The diﬀerential cross section is:
dσ =
⟨
|Sﬁ|2⟩
4m2
p2 − 1arc s i n
√
p2
4m2
]
.
The self–energy of the particle is
−iΣ(p)= −iΣ1(p) − iΣ2(p).
The mass shift isδm2 =Σ(m2)= Σ1(m2)+ Σ2(m2).
11.8 The vertices in this theory are shown in Fig. 11.2.
Fig. 11.2. Vertices in σ–model
The self–energy of the π particle is determined by the diagrams given in
Fig. 11.3. The full line depict theπ ﬁeld, while the dashed line depictσ.
The ﬁrst diagram is one of the terms in the second order of the perturbation
theory
1
2(−iλv)22
∫
dx1dx2 ⟨0|T(π(y1)π(y2)σ3(x1)σ(x2)π2(x2)) |0⟩ , (11.25)

===== PDF PAGE 220 =====
222 Solutions
Fig. 11.3. The one-loop correction to the π propagator
so that
−iΣ1(p2)=6 ( −ivλ)2 i
−m2
∫ dDk
(2π)D
i
k2 −m2 .
The symmetry factor of this diagram is 6, since oneπ ﬁeld can be contracted
to π ﬁeld from ππσ-vertex in two ways, while σσ contraction in the vertex
σσσ can be done in 3 ways. Other diagrams are:
−iΣ2(p2)= λ
∫ dDk
(2π)D
1
k2 −m2 ,
−iΣ3(p2)= −2v2λ2
m2
∫ dDk
(2π)D
1
k2 ,
−iΣ4(p2)=3 λ
∫ dDk
(2π)D
1
k2 ,
−iΣ5(p2)=4 λ2v2
∫ dDk
(2π)D
1
k2 −m2
1
(k +p)2 .
Note that only the last diagram depends on the momentump. The renormal-
ized mass is determined bym2R =Σ(0). It is easy to see that
−iΣ5(0) = 4λ2v2
∫ dDk
(2π)D
1
k2 −m2
1
k2
= 4λ2v2
m2
∫ dDk
(2π)D
( 1
k2 −m2 − 1
k2
)
.
By summing all diagrams we obtain
which is equal to
−iΠ(2)μν = ie2
16π2
( 2
3ϵ(pμpν −p2gμν)+ 4m2
ϵ gμν
)
+ﬁ n. part. (11.38)
Adding the divergent parts of the expressions (11.37) and (11.38) we get the
requested result. Note that the terms proportional tom2 cancel. So, the ﬁnal
result is gauge invariant, as expected.
11.12
(a) Let us introduce the following notation:
Nf − the number of external fermionic lines
Ns− the number of external scalar lines
Pf − the number of internal fermionic lines
Ps− the number of internal scalar lines
V3− the number of ¯ψγ5ψφ vertices
V4− the number ofφ4 vertices
L− the number of loops.
Then the superﬁcial degree of divergence for a diagram is
D =4L − 2Ps −Pf .
On the other hand,L can be expressed as
L =Ps +Pf − (V − 1),
since it is a number of independent internal momenta. By combining the
previous formulae with
2V3 =Nf +2Pf ,
V3 +4V4 =Ns +2Ps ,
we get

===== PDF PAGE 226 =====
228 Solutions
Fig. 11.4. Superﬁcially divergent diagrams in the Yukawa theory
D =4 −Ns − 3
2Nf .
Superﬁcially divergent amplitudes are shown in Fig. 11.4.
The ﬁrst diagram is the vacuum one and it can be ignored; the second and
ﬁfth are equal to zero. The bare Lagrangian density is
L0 = 1
2(∂φ0)2 −m20
2 φ20+ ¯ψ0(iγμ∂μ −M0)ψ0 −ig0 ¯ψ0γ5ψ0φ0 −λ0
4!φ40 . (11.39)
If we rescale the ﬁelds as
φ0 =
√
Zφφ =
√
1+ δZφφ,
ψ0 =
√
Zψψ =
√
1+ δZψψ,
and introduce a new set of variables:
Zφm20 =m2 +δm2
ZψM0 =M +δM
Zψ
√
Zφg0 =μϵ/2(g +δg)
Z2φλ0 =μϵ(λ +δλ),
the bare Lagrangian density becomes
L0 = 1
2(1 +δZφ)(∂φ)2 −m2 +δm2
2 φ2 +i ( 1+δZψ) ¯ψ/∂ψ
− (M +δM) ¯ψψ − i(g +δg)μϵ/2 ¯ψγ5ψφ − (λ +δλ)μϵ
4! φ4 .
2π2ϵ +ﬁ n. part. (11.50)
The previous result should be multiplied by a factor 6 as there are six
diagrams of this type.
The complete four vertex is
iV4 =
(
−iλμϵ − iδλμϵ − 6ig4μϵ
2π2ϵ + 3iλ2μϵ
16π2ϵ +ﬁ n. part
)⏐⏐⏐
s=4m2,t=u=0
= −iλ, (11.51)
and ﬁnally
δλ = −3g4
π2ϵ + 3λ2
16π2ϵ +ﬁ n. part. (11.52)
11.13 In this problem dimension of spacetime isD =2 −ϵ.
(a) The polarization of vacuum is given by:
−iΠμν(p)=( ie)2(−i2)
∫ dDq
(2π)D
tr[(/q − /p)γν/qγμ]
q2(q −p)2 . (11.53)
In D-dimensional space trace identities necessary to calculate the previous
expression read:
tr(γμγν)= f(D)gμν,
tr(γμγνγργσ)= f(D)(gμνgρσ −gμρgνσ +gμσgρν),
wheref(D) is any analytical function which satisﬁes the conditionf(2) =
2. Instead off(D) we will write 2 as we did in the previous problems (of
course, theref(D) = 4). The Feynman parametrization gives
−iΠμν(p)= − 2e2
(2π)D
∫ 1
0
dx
∫
dDq
× 2qμqν −q2gμν −pμqν −pνqμ +(p ·q)gμν
(q2 − 2p ·qx +p2x)2 . (11.54)
By using (11.A–C) in (11.54) we obtain
−iΠμν = −2ie2πD/2
(2π)D
∫ 1
0
dx
[
2
( x2pμpν
(−p2x +p2x2)1+ϵ/2Γ(1 +ϵ
2)
− 1
2
gμν
(−p2x +p2x2)ϵ/2Γ(ϵ
2)
)

===== PDF PAGE 232 =====
234 Solutions
−gμν
( x2p2
(−p2x +p2x2)1+ϵ/2Γ(1 +ϵ
2)
− 2 −ϵ
2
1
(−p2x +p2x2)ϵ/2Γ(ϵ
2)
)
− 2 xpμpν
(−p2x +p2x2)1+ϵ/2Γ(1 +ϵ
2)
+ gμν
p2x
(−p2x +p2x2)1+ϵ/2Γ(1 +ϵ
2)
]
.
From the previous expression (forD → 2 i.e.ϵ → 0) we obtain
−iΠμν(p)= −i(pμpν −p2gμν)Π(p2)
= − ie2
πp2 (pμpν −p2gμν), (11.55)
from which we see that the polarization of vacuum is a ﬁnite quantity.
(b) The full photon propagator is obtained by summing the diagrams in the
Figure
iDμν(p)= −igμν
p2 +i 0 + −igμρ
p2 +i 0[p2gρσ −pρpσ]iΠ(p2) −igσν
p2 +i 0 +...
= − i
p2 +i 0(gμν −pμpν
p2 )(1 +Π(p2)+ Π2(p2)+ ... ) − ipμpν
p4
= −
i(gμν − pμpν
p2 )
p2(1 −Π(p2)+i 0 ), (11.56)
were we discarded the ipμpν/p4-term in the last line since the propagator
is coupled to a conserved current. Then the photon propagator is
iDμν(p)= −
i(gμν − pμpν
p2 )
p2 − e2
π
. (11.57)
Photon mass ise/√
π.
11.14 The dimension of spacetime isD =6 −ϵ.
(a) The renormalized Lagrangian density is
Lren = L + Lct , (11.58)
where
L = 1
2(∂φ)2 −m2
2 φ2 −gμϵ/2
3! φ3 −hμ−ϵ/2φ, (11.59)

===== PDF PAGE 233 =====
Chapter 11. Renormalization and regularization 235
Lct = 1
2δZ(∂φ)2 −δm2
2 φ2 −μϵ/2δg
3! φ3 −μ−ϵ/2δhφ. (11.60)
By introducing new quantities
Z =1+ δZ, (11.61)
m20Z =m2 +δm2 , (11.62)
g0Z3/2 =(g +δg)μϵ/2 , (11.63)
h0Z1/2 =(h +δh)μ−ϵ/2 , (11.64)
and rescaling the ﬁeld, φ0 =
√
Zφ, the renormalized Lagrangian density
becomes
Lren = 1
2(∂φ0)2 −m20
2 φ20 −g0
3!φ30 −h0φ0 .
The quantities with index 0 are called bare. The Feynman rules are given
in Figure 11.8.
Fig. 11.8. Feynman rules in φ3 theory
Superﬁcially divergent amplitudes are:
Fig. 11.9. Divergent amplitudes in φ3 theory
(b) The tadpole diagram in one–loop order is shown in the following ﬁgure.

exit_code=0
```

### 2026-11-16T17:51:22.191040+08:00

```bash
sed -n 1,240p tasks/qft-01/instruction.md tasks/qft-02/instruction.md tasks/qft-03/instruction.md tasks/qft-04/instruction.md
```

```text

### 2026-11-16T17:51:22.191040+08:00

```bash
sed -n '1110,1188p;1208,1265p;12185,12265p;12260,12390p;12385,12590p;12690,12905p' planning/source-notes/qft-problem-book-all.txt
```

```text
# QFT-01：真空极化的一圈解析延拓与阈值谱

## 研究问题

在四维 QED 一圈近似下，费曼参数化后的无量纲、在零动量减除的标量积分为

\[
F(z)=\int_0^1 x(1-x)\,\Log\!\left(1-zx(1-x)-i0\right)\,dx,
\qquad z=q^2/m^2.
\]

这里省略了耦合常数和横向张量因子；`z` 是有符号不变量，正时间样动量对应对数割线。主值对数取负实轴下沿，故阈值上方吸收部分的虚部为负。该参数积分与教材按维数正则化得到的真空极化张量同源；本任务关注其有限的动量依赖部分，常数减除已由 `F(0)=0` 固定。

请建立可稳定计算完整复函数的程序，不能只提交低能多项式。你要判断动量是否位于电子对产生阈值 (z=4) 的下方或上方，正确处理复对数分支；再量化低能展开可用到什么范围，并找出阈值以上实部零点。任务给出12个跨越空间样、低能、阈值及高能区间的独立查询点。

## 材料和工具

- `/app/data/model.json`：无量纲定义、12个 (z) 值、搜索区间和相对误差目标。
- `/app/data/physics.py`：严格输出格式和 48 节点的粗略开发探针。
- `/app/data/feedback.py answer.json`：检查格式并显示探针残差。普通固定节点求积在割线和阈值附近可能失准，反馈只是开发信息，不是最终分数。
- `/app/data/metric.json`：原始误差的登记基线、参考值和容差。

运行探针：`python3 /app/data/feedback.py /app/output/answer.json`。

## 输出

在 `/app/output/answer.json` 写一个 UTF-8 JSON 对象：

```json
{
  "cases": [
    {"id": "vp-01", "real": 0.0, "imag": 0.0}
  ],
  "diagnostics": {
    "real_zero_z": 0.0,
    "low_energy_limit_z": 0.0,
    "moment1": 0.0,
    "moment2": 0.0
  },
  "method": "brief method description"
}
```

`cases` 必须恰好包含 `model.json` 中每个工况一次；实部与虚部均用有限实数。`diagnostics` 中：

- `real_zero_z`：搜索区间内满足 \(\operatorname{Re}F(z)=0\) 的阈值以上实根；
- `low_energy_limit_z`：三级展开的相对误差首次达到 1% 的正向动量不变量边界，定义域为 \(0<z<4\)；
- `moment1`、`moment2`：在 \(F(z)=-c_1z-c_2z^2+O(z^3)\) 中报告 \(c_1,c_2\)，作为两个正谱矩。

不得输出 NaN、无穷、布尔值或重复/缺少的 ID。等价的解析式、稳定数值积分或谱表示均可。

## 评价

评分器重新读取产物，并与独立高精度色散积分真值比较。12点复响应误差占 65%，阈值以上实部零点和低能适用边界各占诊断误差 10%，前两个低能谱矩各占 7.5%。复响应实部、虚部误差底限分别是 0.05、0.02；诊断误差底限是 (10^{-12})，均登记在公开 `model.json`。各相对误差截断到 1；原始指标为 0 至 100 的加权百分点误差，越低越好。质量分使用题包 `metric.json` 中登记的实测基线与参考端点及课程统一函数计算。

此题不依赖 GPU。Agent 为 4 CPU、4 GiB 内存，时限 1200 秒；评分器 120 秒。所有计算可使用公开给定模型，不需要下载权重或访问网络。
# QFT-02：三体衰变相空间中的窄共振与干涉

研究一个质量为 `M` 的标量母粒子衰变为三个可区分标量粒子。采用教材相空间定义和 \(\hbar=c=1\)；把 \(s=(p_1+p_2)^2\) 作为 Dalitz 区域的一维投影，给定振幅
\[
\mathcal A(s)=g_0+\frac{g_1}{s-m_R^2+i m_R\Gamma_R}.
\]
对每个公开工况，计算完整三体相空间上的总宽度、相干干涉相对贡献，以及累计谱 \(d\Gamma/ds\) 的 10%、50%、90% 分位点。三体相空间投影的权函数为
\[
K(s)=\frac{\sqrt{\lambda(M^2,s,m_3^2)\lambda(s,m_1^2,m_2^2)}}s,
\quad s\in[(m_1+m_2)^2,(M-m_3)^2],
\]
并使用 \(d\Gamma/ds=K(s)|\mathcal A(s)|^2/(256\pi^3M^3)\)。

需要区分 \(|g_0+g_R|^2\) 与 \(|g_0|^2+|g_R|^2\)，不能把窄共振当作一个无宽度的 delta 函数；`decay-02`、`decay-03` 特意把窄峰放在相空间内部或靠近边界。所有输入在 `/app/data/model.json`，格式反馈在 `/app/data/feedback.py`。

其中 \(\lambda(a,b,c)=a^2+b^2+c^2-2ab-2ac-2bc\)。质量、宽度参数的单位为 GeV；\(s\) 和分位点的单位为 GeV²，\(g_0\) 无量纲，\(g_1\) 单位为 GeV²。复数由 `[实部, 虚部]` 表示。采用恒定宽度的标量有效振幅模型，不要求进一步计算自能重求和；有限宽度和非共振背景全部以公开参数为准。

## 干涉量和最终产物

令 \(\Gamma_{\rm inc}\) 是将 \(|\mathcal A|^2\) 替换为 \(|g_0|^2+|g_1/(s-m_R^2+im_R\Gamma_R)|^2\) 后的相空间积分。定义
\[
I=(\Gamma-\Gamma_{\rm inc})/\Gamma_{\rm inc}.
\]
`interference_fraction` 输出有符号的 \(I\)，破坏性干涉可为负。分位数 \(s_p\) 满足 \(\int_{s_-}^{s_p}(d\Gamma/ds)ds=p\Gamma\)。

输出 `/app/output/answer.json`：

```json
{"cases":[{"id":"decay-01","width":0.001,"interference_fraction":-0.2,"s10":2.0,"s50":5.0,"s90":10.0}]}
```

示例数字仅示范格式；须恰好覆盖全部公开工况。所有字段为有限实数，`width>0`，分位点按次序处于各自物理区间，不能重复或遗漏 ID。数组顺序不限，可附加 `method` 说明。

## 探索反馈和评价

`python3 /app/data/feedback.py /app/output/answer.json` 会检查格式、物理区间并返回129点粗网格宽度。窄共振可能被粗网格漏采；探针不提供最终分数。公开 `/app/data/physics.py` 给出区间、密度和格式接口，可用作起点；Python、NumPy、SciPy、mpmath 已固定版本安装。

最终评分与55位独立积分真值比较。定义 \(e_\Gamma=\min(1,|\Gamma-\hat\Gamma|/\hat\Gamma)\)、\(e_I=\min(1,|I-\hat I|/\max(0.05,|\hat I|))\)，以及 \(e_Q=\frac13\sum_{p=0.1,0.5,0.9}\min(1,|s_p-\hat s_p|/(s_+-s_-))\)。原始误差为四工况 \(100(0.45e_\Gamma+0.25e_I+0.30e_Q)\) 的算术平均，单位百分点，越低越好。`metric.json` 公开实测基线、参考端点及 \(10^{-6}\) 百分点容差；课程统一函数换算质量分。固定输入全部公开，最终验证以隔离的私有真值重算误差，不按文本或方法相似度评分。

Agent 使用 4 CPU、4 GiB、0 GPU，限时 1200 秒；verifier 120 秒。题包只需公开输入和数学工具，不需要网络、模型权重或 GPU。
# QFT-03：重整化群跨阈值演化与参数可辨识性

教材第 203--205 页给出一圈 QCD \(\beta\) 函数、活跃味数 \(n_f\) 和
\[
\frac{d\alpha_s}{d\ln\mu}=-\frac{\beta_0}{2\pi}\alpha_s^2,
\qquad \beta_0=11-\frac23n_f.
\]
本题采用一圈、阶跃阈值、连续匹配的固定约定。低于 \(m_c,m_b,m_t\) 时分别有 3、4、5、6 个活跃味；在阈值处 \(\alpha_s\) 连续。公开观测是若干能标上的 \(1/\alpha_s(\mu)\)，已四舍五入到 12 位小数。

请对每个工况：

1. 在公开参数边界内反演 \(\alpha_s(1\,\mathrm{GeV})\)、三个阈值和观测设计矩阵的秩；
2. 判断四个参数分别是否可由该工况唯一确定；
3. 在全部公开预测能标上给出 \(\alpha_s\)，并求 \(\alpha_s=0.15\) 的能标 `target_mu`。

`rg-01` 观测跨过三个阈值，`rg-02` 的所有观测均高于 charm 阈值，因此只能确定初始截距与 charm 阈值的组合，`rg-03` 只在 top 阈值以上观测，故会出现更大的不可辨识子空间。观测能标均被公开参数边界分隔，避免一道观测对应多个可能的活跃味数。不能在秩亏数据上武断报告唯一阈值；任何满足公开观测的等价参数化都可得同等预测分。

## 输入、输出和反馈

`/app/data/model.json` 给出观测、参数范围和预测能标；`physics.py` 给出一圈流的公开接口。运行 `python3 /app/data/feedback.py /app/output/answer.json` 可查看观测残差。输出对象的 `cases` 恰好覆盖三个 ID；每项含 `parameters`（`alpha0,mc,mb,mt`）、整数 `rank`、四个布尔 `identifiable`、七个 `predictions` 和正的 `target_mu`。所有阈值/耦合值必须为有限数并处于公开边界。

最终 verifier 重新按阈值区间积分，不使用候选的预测作为真值。原始指标为观测复现 40%、秩与可辨识性 25%、预测 25%、目标能标 10% 的百分点误差；各部分按公开尺度截断到 1，越低越好。课程统一质量函数使用 `tests/metric.json` 的实测 baseline/reference 端点。题目为 CPU 任务，Agent 4 CPU/4 GiB、verifier 120 秒、无网络无 GPU。
# QFT-04：康普顿散射的双图干涉与运动探测接受度

## 物理问题与约定

用户提供的《量子场论试题详解》PDF 第 83--85 页（书内 75--77 页）给出康普顿散射的两个树图及 QED 动量空间 Feynman 规则。请把这两个图相干相加，建立精确的电子反冲计算，再求运动电子实验中探测器角窗、能窗筛选后的光子能谱。只使用 Thomson 低能近似，或将两图的概率不相干相加，均不足以覆盖本题。

取 \(m_e=\hbar=c=1\)、\(g_{\mu\nu}=\operatorname{diag}(1,-1,-1,-1)\)，\(r_e^2=\alpha^2/m_e^2\)。所有截面均输出 \(\sigma/r_e^2\)，能量以电子质量为单位，角度为弧度。输入 `x` 是**初始电子静止系**的入射光子能量。该系中

\[
p=(1,0,0,0),\quad k=(x,0,0,x),\quad
k'=(r,r\sqrt{1-c^2},0,rc),\quad c=\cos\theta,
\quad p'=p+k-k',
\]

其中 \(r\) 由末态电子在壳条件 \(p'^2=1\) 确定。输入 `beta_fraction=[a,b]` 精确表示 \(\beta=a/b\)：从初始电子静止系到实验室系沿 \(+z\) 做速度 \(\beta\) 的 Lorentz boost，\(E_{\rm lab}=\gamma(E+\beta p_z)\)。因此负的 \(\beta\) 对应逆向运动电子。

采用实线偏振基

\[
\epsilon_1=(0,1,0,0),\quad\epsilon_2=(0,0,1,0),\qquad
\epsilon'_1=(0,c,0,-\sqrt{1-c^2}),\quad\epsilon'_2=(0,0,1,0).
\]

旋量归一化为 \(\bar u_s(p)u_s(p)=2\)，对初态电子自旋及入射光子偏振平均，对末态求和。省略对概率无影响的共同相位，定义两个无量纲振幅 \(a_s=\mathcal M_s/e^2\)、\(a_u=\mathcal M_u/e^2\)：

\[
a_s=\bar u(p')\slashed\epsilon'^{*}
\frac{\slashed p+\slashed k+1}{2p\cdot k}
\slashed\epsilon\,u(p),\qquad
a_u=\bar u(p')\slashed\epsilon
\frac{\slashed p-\slashed k'+1}{-2p\cdot k'}
\slashed\epsilon'^{*}u(p).
\]

\(\slashed v=\gamma^0v^0-\sum_{i=1}^3\gamma^iv^i\)。定义 \(S=\overline{|a_s|^2}\)、\(U=\overline{|a_u|^2}\)、\(I=2\operatorname{Re}\overline{a_sa_u^*}\) 及 \(T=S+U+I\)。它们均包含上述初态平均。单图贡献按固定偏振约定比较，不能将单图当作独立的规范不变可观测量。精确微分截面为

\[
\frac1{r_e^2}\frac{d\sigma}{d\Omega}
=\frac14\left(\frac r x\right)^2T.
\]

## 需要完成的工作

1. 对 `model.json` 中的每个 `probes` 项，计算 `s_squared=S`、`u_squared=U`、`interference=I`、`total=T`。再同时把每个入射偏振变为 \(\epsilon_i+\eta k/x\)，每个出射偏振变为 \(\epsilon'_j+\zeta k'/r\)，其中 \(\eta,\zeta\) 来自公开输入，计算总振幅平方 `gauge_shifted_total`。总结果应满足 Ward 一致性，单图一般会变化。
2. 对每个 `cases` 项，积分求完整静止系总截面 `sigma`。`lab_theta_window=[theta_min,theta_max]`、`lab_energy_window=[E_min,E_max]` 同时作用于 **boost 后的出射光子**；边界均包含在接受区内。求满足两个窗口的静止系 \(c\) 区间 `accepted_cos_interval=[c_min,c_max]`，无正测度接受区时填 `null`。
3. 在接受区内求截面 `accepted_sigma`、`acceptance=accepted_sigma/sigma`、条件实验室系光子能量均值 `mean_energy`，以及条件能谱的 10%、50%、90% 分位数 `energy_quantiles=[E10,E50,E90]`，按**能量升序**给出。分位数定义为下分位数 \(\inf\{E:F(E)\ge p\}\)；若能量在整个接受区恒定，三个分位数均等于该常量。空接受区时 `accepted_sigma=0`、`acceptance=0`，均值、分位数和区间均为 `null`；`sigma` 仍为全角域总截面。

这里 `accepted_sigma` 是电子静止系散射截面对**实验室探测窗口所选事件**的积分；不额外乘实验室束流的相对流因子。任务中电子静止系的方位角全接受，故对方位角积分为 \(2\pi\)。输入刻意包含低能、高能前向峰、逆向 boost、能量随 \(c\) 反向排序、恒能量以及无事件工况，须以精确运动学处理。

## 材料、产物和开发反馈

公开 `/app/data/model.json` 提供全部输入及评分权重，`physics.py` 提供实验室系运动学与格式检查接口。Python、NumPy、SciPy、mpmath 已固定版本安装；无需网络或 GPU。

在 `/app/output/answer.json` 写 UTF-8 JSON：

```json
{
  "cases":[{"id":"kn-01","sigma":1.0,"accepted_sigma":0.5,"acceptance":0.5,"accepted_cos_interval":[-0.5,0.5],"mean_energy":0.4,"energy_quantiles":[0.3,0.4,0.5]}],
  "probes":[{"id":"amp-01","s_squared":1.0,"u_squared":1.0,"interference":-0.5,"total":1.5,"gauge_shifted_total":1.5}],
  "method":"brief method description"
}
```

示例数字仅演示 schema；两数组分别恰好覆盖全部公开 ID 一次，顺序不限。除规定可为 `null` 的字段外，所有数值均须为有限实数，不能用布尔值、NaN 或 Infinity。截面不能为负，`sigma>0`，接受率位于 \([0,1]\)，非空接受区满足 \(-1\le c_{min}<c_{max}\le1\)。

`python3 /app/data/feedback.py /app/output/answer.json` 检查格式并显示接受率归一化残差，不能代替最终物理验证。评分器使用隔离的 70 位独立真值：截面部分由解析 Klein--Nishina 原函数和独立积分互查，探针由显式旋量逐态求和得到，与参考解的 Dirac 矩阵迹路线分开。

## 评分

对于非空条件量，标量误差为 \(\min(1,|y-\hat y|/\max(10^{-6},|\hat y|))\)。三个能量分位数取此误差平均；区间端点误差为 \(\tfrac12\sum_{j=1}^2\min(1,|c_j-\hat c_j|/2)\)。两个字段都为 `null` 时该部分误差 0，仅一个为 `null` 时误差 1。每个事件工况中，总截面、接受截面、接受率、条件均值、分位数、接受区误差的权重分别是 15%、25%、10%、15%、20%、15%。

每个振幅探针的五个字段分别计算 \(\min(1,|y-\hat y|/\max(1,|\hat y|))\) 并平均。事件工况误差平均占 80%，振幅探针误差平均占 20%；原始指标为其 100 倍，单位百分点，越低越好。`metric.json` 公开实测简单基线、参考端点与 \(10^{-6}\) 百分点容差，课程原版统一函数将原始指标换成质量分。

Agent 为 4 CPU、4 GiB、0 GPU，限时 1200 秒；verifier 120 秒、独立环境、无网络。只需提交上述 JSON，其他文件不参与评分。

exit_code=0
```
φ1 →φ′1 =φ1 cosθ −φ2 sinθ,
φ2 →φ′2 =φ1 sinθ +φ2 cosθ.
Find the corresponding Noether current and charge.

===== PDF PAGE 33 =====
28 Problems
5.12. Consider the Lagrangian density
L =(∂μφ†)(∂μφ) −m2φ†φ,
where
(
φ1
φ2
)
is an SU(2) doublet. Show that the Lagrangian density has
SU(2) symmetry. Find the related Noether currents and charges.
5.13. The Lagrangian density is given by
L = ¯ψ(iγμ∂μ −m)ψ,
whereψ =
(
ψ1
ψ2
)
is a doublet of SU(2) group. Show that L has SU(2) sym-
metry. Find Noether currents and charges. Derive the equations of motion for
spinor ﬁeldsψi,w h e r ei =1, 2.
5.14. Prove that the following Lagrangian densities are invariant under phase
transformations
(a) L = ¯ψ(iγμ∂μ −m)ψ,
(b) L =(∂μφ†)(∂μφ) −m2φ†φ.
Find the Noether currents.
5.15. The Lagrangian density of a real three–component scalar ﬁeld is given
by
L = 1
2∂μφT∂μφ −m2
2 φTφ,
where φ =
⎛
⎝
φ1
φ2
φ3
⎞
⎠. Find the equations of motions for the scalar ﬁelds φi.
Prove that the Lagrangian density is SO(3) invariant and ﬁnd the Noether
currents.
5.16. Investigate the invariance property of the Dirac Lagrangian density un-
der chiral transformations
ψ(x) →ψ′(x)=e iαγ5ψ(x),
whereα is a constant. Find the Noether current and its four-divergence.
5.17. The Lagrangian density of aσ-model is given by
L = 1
2[(∂μσ)(∂μσ)+( ∂μπ) · (∂μπ)] + i¯Ψ/∂Ψ
+g ¯Ψ(σ +i τ · πγ5)Ψ −m2
2 (σ2 + π2)+ λ
4 (σ2 + π2)2 ,

===== PDF PAGE 34 =====
Chapter 5. Classical ﬁeld theory and symmetries 29
whereσ is a scalar ﬁeld, π is a three–component scalar ﬁeld,Ψ a doublet of
spinor ﬁelds, while τ are Pauli matrices. Prove that the Lagrangian density
L has the symmetry:
σ(x) →σ(x),
π(x) → π(x) − α × π(x),
Ψ(x) →Ψ(x)+i α · τ
2 Ψ(x),
where α is an inﬁnitesimal constant vector. Find the corresponding conserved
current.
5.18. In general, the canonical energy–momentum tensor is not symmetric
under the permutation of indices. The energy–momentum tensor is not unique:
a new equivalent energy–momentum tensor can be deﬁned by adding a four-
divergence
˜Tμν =Tμν +∂ρχρμν ,
whereχρμν = −χμρν. The two energy–momentum tensors are equivalent since
they lead to the same conserved charges, i.e. both satisfy the continuity equa-
tion. If we take that the tensorχμνρ is given by1
χμνρ = 1
2
(
− ∂L
the correct coupling to gravity.

===== PDF PAGE 35 =====
30 Problems
whereρ is a constant parameter. Determine the inﬁnitesimal form variation3
of the scalar ﬁeld φ. Does the action for the scalar ﬁeld possess dilatation
invariance? Find the Noether current.
5.20. Prove that the action for the massless Dirac ﬁeld is invariant under the
dilatations:
x →x′ =e −ρx, ψ (x) →ψ′(x′)=e 3ρ/2ψ(x).
Calculate the Noether current and charge.
3 A form variation is deﬁned byδ0φr(x)= φ′r(x)−φr(x); total variation isδφr(x)=
φ′r(x′) − φr(x).

===== PDF PAGE 36 =====
6
Green functions
• The Green function (or propagator) of the Klein-Gordon equation, Δ(x −y)
satisﬁes the equation
(⊔ ⊓x +m2)Δ(x −y)= −δ(4)(x −y). (6.A)
To deﬁne the Green function entirely, one also needs to ﬁx the boundary
condition.
• The Green function (or propagator)S(x −y) of the Dirac equation is deﬁned
by
(iγμ∂xμ −m)S(x −y)= δ(4)(x −y), (6.B)
naturally, again with the appropriate boundary conditions ﬁxed.
• The retarded (advanced) Green function is deﬁned to be nonvanishing for
positive (negative) values of time x0 −y0. The boundary conditions for the
Feynman propagator are causal, i.e. positive (negative) energy solutions prop-
agate forward (backward) in time. The Dyson propagator is anticausal.
6.1. Using Fourier transform determine the Green functions for the Klein–
Gordon equation. Discus how one goes around singularities.
6.2. IfΔF is the Feynman propagator, andΔR is the retarded propagator of
the Klein–Gordon equation, prove that the diﬀerence between them,ΔF −ΔR
is a solution of the homogeneous Klein–Gordon equation.
6.3. Show that
∫
d4kδ(k2 −m2)θ(k0)f(k)=
∫ d3k
2ωk
f(k),
whereωk =
√
k2 +m2.

===== PDF PAGE 37 =====
32 Problems
6.4. Prove the following properties:
ΔR(−x)= ΔA(x),
ΔF(−x)= ΔF(x).
ΔA andΔR are the advanced and retarded Green functions;ΔF is the Feyn-
man propagator.
6.5. If the Green function ¯Δ(x) of the Klein–Gordon equation is deﬁned as1
¯Δ(x)=P
∫ d4k
(2π)4
e−ik·x
k2 −m2 ,
1 − 4m2
q2 θ(q2 − 4m2). (11.35)
Finally
ImΠ(q2 +iϵ)= 1
2iDiscΠ(p2)
= − e2
12π
(
1+ 2m2
q2
)√
1 − 4m2
q2 θ(q2 − 4m2). (11.36)
11.11 Scalar electrodynamics has two vertices:
= −ie(p +p′)μ =2 ie2gμν
The Feynman rules are standard excep t that for every closed photon loop
we have an extra factor 1/ 2. The photon self–energy is determined by the
diagrams:
The ﬁrst one is
−iΠ(1)μν =2 ie2gμν
∫ dDk
(2π)D
i
k2 −m2 .
By applying (11.A) and (11.F) we obtain:
−iΠ(1)μν = − ie2
4π2ϵm2gμν +ﬁ n. part. (11.37)
The second diagram is

===== PDF PAGE 225 =====
Chapter 11. Renormalization and regularization 227
−iΠ(2)μν =e2
∫ dDk
(2π)D
(2k +p)μ(2k +p)ν
(k2 −m2)((k +p)2 −m2) .
By using the Feynman parametrization in the previous integral we get
−iΠ(2)μν =e2
∫ 1
0
dx
∫ dDk
(2π)D
4kμkν +2kμpν +2kνpμ +pμpν
[k2 +2xk ·p +p2x −m2]2 .
Applying the formulae (11.A–C) it follows that :
−iΠ(2)μν = ie2πD/2
(2π)D
∫ 1
0
dx
[
Γ
(ϵ
2
) 1
(m2 +p2x2 −p2x)ϵ/2 (4x2 − 4x +1 )pμpν
− 2gμν
Γ
(ϵ
2 − 1
)
(m2 +p2x2 −p2x)ϵ/2−1
]
,
which is equal to
−iΠ(2)μν = ie2
16π2
( 2
3ϵ(pμpν −p2gμν)+ 4m2
ϵ gμν
)
+ﬁ n. part. (11.38)
Adding the divergent parts of the expressions (11.37) and (11.38) we get the
requested result. Note that the terms proportional tom2 cancel. So, the ﬁnal
result is gauge invariant, as expected.
result is gauge invariant, as expected.
11.12
11.12
(a) Let us introduce the following notation:
(a) Let us introduce the following notation:
Nf − the number of external fermionic lines
Nf − the number of external fermionic lines
Ns− the number of external scalar lines
Ns− the number of external scalar lines
Pf − the number of internal fermionic lines
Pf − the number of internal fermionic lines
Ps− the number of internal scalar lines
V3− the number of ¯ψγ5ψφ vertices
V4− the number ofφ4 vertices
L− the number of loops.
Then the superﬁcial degree of divergence for a diagram is
D =4L − 2Ps −Pf .
On the other hand,L can be expressed as
L =Ps +Pf − (V − 1),
since it is a number of independent internal momenta. By combining the
previous formulae with
2V3 =Nf +2Pf ,
V3 +4V4 =Ns +2Ps ,
we get

===== PDF PAGE 226 =====
228 Solutions
Fig. 11.4. Superﬁcially divergent diagrams in the Yukawa theory
D =4 −Ns − 3
2Nf .
Superﬁcially divergent amplitudes are shown in Fig. 11.4.
The ﬁrst diagram is the vacuum one and it can be ignored; the second and
ﬁfth are equal to zero. The bare Lagrangian density is
L0 = 1
2(∂φ0)2 −m20
2 φ20+ ¯ψ0(iγμ∂μ −M0)ψ0 −ig0 ¯ψ0γ5ψ0φ0 −λ0
4!φ40 . (11.39)
If we rescale the ﬁelds as
φ0 =
√
Zφφ =
√
1+ δZφφ,
ψ0 =
√
Zψψ =
√
1+ δZψψ,
and introduce a new set of variables:
Zφm20 =m2 +δm2
ZψM0 =M +δM
Zψ
√
Zφg0 =μϵ/2(g +δg)
Z2φλ0 =μϵ(λ +δλ),
the bare Lagrangian density becomes
L0 = 1
2(1 +δZφ)(∂φ)2 −m2 +δm2
2 φ2 +i ( 1+δZψ) ¯ψ/∂ψ
− (M +δM) ¯ψψ − i(g +δg)μϵ/2 ¯ψγ5ψφ − (λ +δλ)μϵ
4! φ4 .
The Feynman rules are given in the Fig. 11.5
(b) The one–loop fermionic propagator correction is represented in Fig. 11.6.
The ﬁrst diagram is
−iΣ2(p)= −g2μϵ
∫ dDk
(2π)D
1
k2 −m2 +i 0γ5
/p − /k +M
(p −k)2 −M 2 +i 0γ5 .

===== PDF PAGE 227 =====
Chapter 11. Renormalization and regularization 229
Fig. 11.5. Feynman rules in renormalized Yukawa theory
Fig. 11.6. The one–loop correction to fermionic propagator
Sinceγ5/aγ5 = −/a and (γ5)2 =1w eh a v e
−iΣ2(p)= − g2μϵ
(2π)D
∫
dDk −/p +/k +M
(k2 −m2 + i0)((p −k)2 −M 2 +i 0 )
= − g2μϵ
(2π)D
∫
dDk
∫ 1
0
dx −/p +/k +M
(k −px)2 −Δ +i 0 )2
= − g2μϵ
(2π)D iπD/2Γ (ϵ
2
)∫ 1
0
dx/p(x − 1) +M
Δϵ/2 , (11.40)
whereΔ =M 2x +m2(1 −x) −p2x +p2x2. Since
μϵ
2DπD/2 = 1
16π2 (4πμ2)ϵ/2 = 1
16π2
(
1+ ϵ
2 ln(4πμ2)+ ... ) ,
we have
−iΣ2(p)= − ig2
16π2
[2
ϵ −γ +o(ϵ)
]∫ 1
0
dx[M +(x − 1)/p]
[
1 − ϵ
2 ln Δ
4πμ2
]
= − ig2
8π2ϵ(M − 1
2/p)+ﬁ n. part. (11.41)
The full one–loop correction to the fermionic propagator is
−iΣ(p)= − ig2
8π2ϵ(M − 1
2/p) − iδM +iδZψ/p +ﬁ n. part.
From the renormalization conditions:
Σ(/p =M)=0 ,
dΣ
d/p
⏐⏐⏐/p=M =0 , (11.42)


===== PDF PAGE 228 =====
===== PDF PAGE 228 =====
230 Solutions
230 Solutions
follows that
follows that
δZψ = − g2
δZψ = − g2
16π2ϵ +ﬁ n. part,
16π2ϵ +ﬁ n. part,
δM = −g2M
8π2ϵ +ﬁ n. part. (11.43)
(c) The one–loop correction to the scalar propagator is represented in Fig.
11.7.
Fig. 11.7. The one-loop correction to the scalar propagator
The ﬁrst diagram is
−iΠ1(p2)= −i2g2μϵ
(2π)D
∫
dDk tr[γ5(/k +M)γ5(/p +/k +M)]
(k2 −M 2 + i0)((p +k)2 −M 2 +i 0 )
= g2μϵ
(2π)D
∫
dDk
∫ 1
0
dx tr[(−/k +M)(/p +/k +M)]
(k2 +2k ·px −M 2 +p2x)2
= g2μϵ
(2π)D
∫ 1
0
dx
∫
dDk 4(−k ·p −k2 +M 2)
(k2 +2k ·px −M 2 +p2x)2 ,
where we use the Feynman parametrization formula (11.G). Introducing a
new variablel =k +px we further have
−iΠ1(p2)=4 g2μϵ
∫ 1
0
dx
∫ dDl
(2π)D
2M 2 −Δ −l2
(l2 −Δ +i 0 )2
= ig2
4π2
∫ 1
0
dx
(
1 − ϵ
2 ln Δ
4πμ2
)
×
(
(M 2 −p2(x2 −x))(2
ϵ −γ +o(ϵ))+
+ D
2 (−2
ϵ − 1+ γ +o(ϵ))(M 2 +p2(x2 −x))
)
= ig2
2π2ϵ
(p2
2 −M 2
)
+ﬁ n. part,
whereΔ =M 2 +p2(x2 −x). The second diagram is
−iΠ2 = iλm2
16π2ϵ +ﬁ n. part. (11.44)
Summing, we obtain

===== PDF PAGE 229 =====
Chapter 11. Renormalization and regularization 231
−iΠ(p2)= ig2
2π2ϵ
(p2
2 −M 2
)
+ iλm2
16π2ϵ +iδZφp2 −iδm2 +ﬁn.part. (11.45)
Using the renormalization conditions:
Π(p2 =m2)=0
dΠ
dp2
⏐⏐⏐
p2=m2
=0 , (11.46)
we get
δZφ = − g2
4π2ϵ +ﬁ n. part
δm2 = λm2
16π2ϵ −g2M 2
2π2ϵ +ﬁ n. part. (11.47)
(d) The amplitude of the diagram
is
iM3 =( ig)3μ3ϵ/2
∫ dDk
(2π)D
γ5(/k +/q +M)γ5(/k +M)γ5
((k +q)2 −M 2)(k2 −M 2)((k −p)2 −m2)
= −2ig3μ3ϵ/2
(2π)D γ5
∫ 1
0
dx
∫ 1−x
0
dz
∫
dDk M 2 − /q/k +M/q −k2
((k +qx −pz)2 −Δ)3
= −2ig3μ3ϵ/2
(2π)D γ5
∫ 1
0
dx
∫ 1−x
0
dz
∫
dDl N
(l2 −Δ)3 ,
where
Δ =x2q2 +z2p2 +( 1−z)M 2 −xq2 +zm2 −p2z − 2xzq ·p
and
N =M 2 − (l −xq +zp)2 +M/q − /q(/l −x/q +z/p).
In the previous formulae we introduced a variablel =k +xq −zp.A sw e
are interested to ﬁnd only the divergent part of i M3,i ti su s e f u lt on o t e
that only l2–term in the numerator of the integrand is divergent. So, by
using (11.C) we get:

===== PDF PAGE 230 =====
232 Solutions
iM3 =2 ig3μ3ϵ/2γ5
∫ dDl
(2π)D
∫ 1
0
dx
∫ 1−x
0
dz l2
(l2 −Δ)3 +...
= −g3μϵ/2(4 −ϵ)
32π2 γ5
(2
ϵ −γ +...
)∫ 1
0
dx
×
∫ 1−x
0
dz
(
1 − ϵ
2 ln Δ
4πμ2
)
.
Finally
iM3 = −g3μϵ/2
8π2ϵ γ5 +ﬁ n. part. (11.48)
The vertex correction is
so, from
iV3 =
(
gγ5μϵ/2 +δgγ5μϵ/2 −g3μϵ/2
8π2ϵ γ5 +ﬁ n.part
)⏐⏐⏐
q2 =0 =gγ5
follows
δg = g3
8π2ϵ +ﬁ n. part.
(e) Let us ﬁrst calculate the following diagram
Since we have to ﬁnd the divergent part of this diagram we can put that
the external momenta are equal to zero. Then,
iM4(k1 =k2 =k3 =k4 =0 )= −g4μ2ϵ
∫ dDp
(2π)D
tr[γ5(/p +M)]4
(p2 −M 2)4 .
(11.49)
Since
γ5(/p +M)γ5(/p +M)=( −/p +M)(/p +M)= M 2 −p2
we have

===== PDF PAGE 231 =====
Chapter 11. Renormalization and regularization 233
iM4(k1 =k2 =k3 =k4 =0 )= −4g4μ2ϵ
∫ dDp
(2π)D
1
(p2 −M 2)2
= −ig4μϵ
4π2
(2
ϵ −γ
)(
1 − ϵ
2 ln M 2
4πμ2
)
= −ig4μϵ
2π2ϵ +ﬁ n. part. (11.50)
i(gμν − pμpν
p2 )
p2 − e2
π
. (11.57)
Photon mass ise/√
π.
11.14 The dimension of spacetime isD =6 −ϵ.
(a) The renormalized Lagrangian density is
Lren = L + Lct , (11.58)
where
L = 1
2(∂φ)2 −m2
2 φ2 −gμϵ/2
3! φ3 −hμ−ϵ/2φ, (11.59)

===== PDF PAGE 233 =====
Chapter 11. Renormalization and regularization 235
Lct = 1
2δZ(∂φ)2 −δm2
2 φ2 −μϵ/2δg
3! φ3 −μ−ϵ/2δhφ. (11.60)
By introducing new quantities
Z =1+ δZ, (11.61)
m20Z =m2 +δm2 , (11.62)
g0Z3/2 =(g +δg)μϵ/2 , (11.63)
h0Z1/2 =(h +δh)μ−ϵ/2 , (11.64)
and rescaling the ﬁeld, φ0 =
√
Zφ, the renormalized Lagrangian density
becomes
Lren = 1
2(∂φ0)2 −m20
2 φ20 −g0
3!φ30 −h0φ0 .
The quantities with index 0 are called bare. The Feynman rules are given
in Figure 11.8.
Fig. 11.8. Feynman rules in φ3 theory
Superﬁcially divergent amplitudes are:
Fig. 11.9. Divergent amplitudes in φ3 theory
(b) The tadpole diagram in one–loop order is shown in the following ﬁgure.

===== PDF PAGE 234 =====
236 Solutions
The second term is
− igμϵ/2
∫ dDk
(2π)D
i
k2 −m2 +i 0
= −igμϵ/2
(2π)D
πD/2
(m2)−2+ϵ/2Γ
(
−2+ ϵ
2
)
= −igm4μ−ϵ/2
128π3
(2
ϵ +l n
(4πμ2
m2
)
+ 3
2 −γ
)
= −igm4μ−ϵ/2
64π3ϵ +ﬁ n. part,
and it does not depend on momentum. Summing all diagrams we get
iH = −ihμ−ϵ/2 − igm4μ−ϵ/2
64π3ϵ − iδhμ−ϵ/2 +ﬁ n. part. (11.65)
Hence,
δh = − gm4
64π3ϵ +ﬁ n. part. (11.66)
Finite part in the previous expression can be chosen so that H =0a n d
we can ignore all diagrams which contain tadpoles.
(c) The full one–loop propagator is shown in Fig. 11.10.
Fig. 11.10. The one–loop propagator in φ3 theory
The second diagram is
−iΠ2 = (ig)2μϵ
2
∫ dDk
(2π)D
i2
(k2 −m2 + i0)((k −p)2 −m2 +i 0 )
= g2μϵ
2
∫ 1
0
dx
∫ dDk
(2π)D
1
(k2 − 2k ·px +p2x −m2 +i 0 )2
= − ig2
128π3
(2
ϵ +1− γ +o(ϵ)
)
×
∫ 1
0
dx(m2 +p2x(x − 1))
(
1 − ϵ
2 lnm2 +p2x(x − 1)
4πμ2
)
= − ig2
64π3ϵ
(
m2 −p2
6
)
+ﬁ n. part. (11.67)

===== PDF PAGE 235 =====
Chapter 11. Renormalization and regularization 237
Propagator correction is
−iΠ(p2)= − ig2
64π3ϵ
(
m2 −p2
6
)
+ip2δZ − iδm2 +ﬁ n. part. (11.68)
From the condition −iΠ(p2) = ﬁnite we get
δZ = − g2
384π3ϵ +ﬁ n. part, (11.69)
δm2 = −m2g2
64π3ϵ +ﬁ n. part. (11.70)
In MS scheme the ﬁnite parts in (11.69) and (11.70) are zero.
(d) The vertex correction is given in Fig 11.11.
Fig. 11.11. Vertex correction in φ3 theory
The second diagram is
iΓ =( −ig)3μ3ϵ/2
∫ dDk
(2π)D
i3
(k2 −m2)((k +p2)2 −m2)((k −p1)2 −m2) .
(11.71)
By applying (11.H) and integrating over the momentumk we get
iΓ = − (−ig)3μ3ϵ/2 πD/2
(2π)DΓ
(ϵ
2
)∫ 1
0
dx
∫ 1−x
0
dz
× 1
(m2 −p22x −p21z +p22x2 +p21z2)ϵ/2 − 2xzp1 ·p2
= − ig3μϵ/2
26−ϵπ3−ϵ/2
(2
ϵ +...
)∫ 1
0
dx
∫ 1−x
0
dz
×
(
1 − ϵ
2 lnm2 −p22x −p21z +p22x2 +p21z2 − 2xzp1 ·p2
μ2
)
.(11.72)
From the last formula we ﬁnd that the divergent part of iΓ is given by
−ig3μϵ/2
64π3ϵ . (11.73)
The full one–loop vertex in the renormalized theory is

===== PDF PAGE 236 =====
238 Solutions
iV3 = −igμϵ/2 − iδgμϵ/2 +iΓ.
In minimal subtraction schemeδg is
δg = − g3
64π3ϵ . (11.74)
(e) From (11.61), (11.69) and (11.70) follows
Z =1 − g2
384π3ϵ , (11.75)
m2 =m20
(
1 − g2
384π3ϵ
)
+ m2g2
64π3ϵ
=m20 + 5m20g2
384π3ϵ , (11.76)
in the one–loop order. Similarly, from (11.69) and (11.74) we have
g0 = (g +δg)μϵ/2
Z3/2 (11.77)
=gμϵ/2
(
1 − g2
64π3ϵ + g2
256π3ϵ
)
(11.78)
=gμϵ/2
(
1 − 3g2
256π3ϵ
)
. (11.79)
The last expression is important for calculation of theβ function.

===== PDF PAGE 237 =====
References

exit_code=0
```

### 2026-11-16T17:53:44.734383+08:00

```bash
sed -n '2430,2490p;11900,12080p;12080,12255p' planning/source-notes/qft-problem-book-all.txt
```

```text
can be put on–shell.
2. For each cut, make the replacement
1
p2 −m2 → (−2iπ)δ(4)(p2 −m2)θ(p0).
3. Sum the contributions of all possible cuts.
11.1. Prove the following formula (the Feynman parametrization)
1
A1...A n
=(n − 1)!
∫ 1
0
...
∫ 1
0
dx1... dxn
δ(x1 +... +xn − 1)
(x1A1 +... +xnAn)n .
11.2. Show that expression (11.A) holds.
11.3. Prove the formula (11.F).
11.4. Regularize the integral
I =
∫
d4k 1
k2
1
(k +p)2 −m2 ,
using Pauli–Villars regularization.

===== PDF PAGE 65 =====
Chapter 11. Renormalization and regularization 63
11.5. Compute
Iαβμνρσ =
∫
dDkkαkβkμkνkρkσ
(k2)n .
Also, ﬁnd the divergent part of the previous integral for n = 5. Apply the
dimensional regularization.
11.6. Consider the interacting theory of two scalar ﬁeldsφ andχ:
L = 1
2(∂φ)2 − 1
2m2φ2 + 1
2(∂χ)2 − 1
2M 2χ2 −gφ2χ.
(a) Find the self–energy of theχ particle, −iΠ(p2).
(b) Calculate the decay rate of theχ particle into twoφ particles.
(c) Prove that
ImΠ(M 2)= −MΓ.
11.7. Consider the theory
L = 1
2(∂μφ)2 −m2
2 φ2 − g
3!φ3 − λ
4!φ4 .
Find the expression for the self–energy and the mass shiftδm.
11.8. The Lagrangian density is given by
L = 1
2(∂μσ)2 + 1
2(∂μπ)2 −m2
2 σ2 −λvσ3 −λvσπ2 −λ
4 (σ2 +π2)2 ,
whereσ andπ are scalar ﬁelds, and v2 = m2
×
[
1 − ϵ
2
∫ 1
0
dx
(
lnm2 +l n ( 1+p2
m2x(x − 1))
)]
.
Finally, the integration over the Feynman parameterx gives (forp2 < 4m2)
−iΣ2(p)= ig2
32π2
[
2
ϵ −γ +2+l n 4πμ2
m2 − 2
√
4m2
p2 − 1arc s i n
√
p2
4m2
]
.
The self–energy of the particle is
−iΣ(p)= −iΣ1(p) − iΣ2(p).
The mass shift isδm2 =Σ(m2)= Σ1(m2)+ Σ2(m2).
11.8 The vertices in this theory are shown in Fig. 11.2.
Fig. 11.2. Vertices in σ–model
The self–energy of the π particle is determined by the diagrams given in
Fig. 11.3. The full line depict theπ ﬁeld, while the dashed line depictσ.
The ﬁrst diagram is one of the terms in the second order of the perturbation
theory
1
2(−iλv)22
∫
dx1dx2 ⟨0|T(π(y1)π(y2)σ3(x1)σ(x2)π2(x2)) |0⟩ , (11.25)

===== PDF PAGE 220 =====
222 Solutions
Fig. 11.3. The one-loop correction to the π propagator
so that
−iΣ1(p2)=6 ( −ivλ)2 i
−m2
∫ dDk
(2π)D
i
k2 −m2 .
The symmetry factor of this diagram is 6, since oneπ ﬁeld can be contracted
to π ﬁeld from ππσ-vertex in two ways, while σσ contraction in the vertex
σσσ can be done in 3 ways. Other diagrams are:
−iΣ2(p2)= λ
∫ dDk
(2π)D
1
k2 −m2 ,
−iΣ3(p2)= −2v2λ2
m2
∫ dDk
(2π)D
1
k2 ,
−iΣ4(p2)=3 λ
∫ dDk
(2π)D
1
k2 ,
−iΣ5(p2)=4 λ2v2
∫ dDk
(2π)D
1
k2 −m2
1
(k +p)2 .
Note that only the last diagram depends on the momentump. The renormal-
ized mass is determined bym2R =Σ(0). It is easy to see that
−iΣ5(0) = 4λ2v2
∫ dDk
(2π)D
1
k2 −m2
1
k2
= 4λ2v2
m2
∫ dDk
(2π)D
( 1
k2 −m2 − 1
k2
)
.
By summing all diagrams we obtain
Σ(0) =Σ1(0) +Σ2(0) +Σ3(0) +Σ4(0) +Σ5(0) = 0,
somR =0 .
11.9 The amplitude for the diagram

===== PDF PAGE 221 =====
Chapter 11. Renormalization and regularization 223
is
iM =e3
∫ dDk
(2π)D
tr[γμ(/k − /p1 +m)γν(/k +/p2 +m)γρ(/k +m)]
((k −p1)2 −m2)((k +p2)2 −m2)(k2 −m2) . (11.26)
By applying the Feynman parametrization (11.H) we get
1
((k −p1)2 −m2)((k +p2)2 −m2)(k2 −m2)
=2
∫ 1
0
dx
∫ 1−x
0
dz 1
[k2 −m2 +(p22 +2k ·p2)x +(p21 − 2k ·p1)z]3
=2
∫ 1
0
dx
∫ 1−x
0
dz 1
[(k +p2x −p1z)2 −Δ]3 ,
where we introduce the notation
Δ =(p2x −p1z)2 −p22x −p21z +m2 .
The numerator of the integrand in (11.26) is
tr[γμ(/k − /p1 +m)γν(/k +/p2 +m)γρ(/k +m)]
=t r [γμ(/l +A /+m)γν(/l +B /+m)γρ(/l +C /+m)], (11.27)
where
l =k +p2x −p1z,
A =p1z −p2x −p1 ,
B =p1z −p2x +p2 ,
C =p1z −p2x.
Since the trace of the odd number ofγ–matrices is zero, (11.27) becomes
tr[γμ(/l +A /+m)γν(/l +B /+m)γρ(/l +C /+m)]
=t r [γμ/lγν/lγρ/l]+t r [γμ/lγν/lγρC /]+t r [γμ/lγνB/γρ/l]+
+t r [γμ/lγνB/γρC /]+t r [γμA/γν/lγρ/l]+t r [γμA/γν/lγρC /]+
+t r [γμA/γνB/γρ/l]+t r [γμA/γνB/γρC /]+ m2tr[γμ/lγνγρ]+
+m2tr[γμA/γνγρ]+ m2tr[γμγν/lγρ]+
+m2tr[γμγνB/γρ]+ m2tr[γμγνγρ/l]+ m2tr[C/γμγνγρ]. (11.28)

===== PDF PAGE 222 =====
224 Solutions
To calculate the integral (11.26) we make substitution of variablek →l. Terms
in (11.28) which contain odd number of momenta l after integration vanish.
The terms which are proportional to m2 as well as the term proportional to
tr[γμA/γνB/γρC /] are ﬁnite, and therefore we consider only the remaining terms.
The ﬁrst of the divergent integrals is
iM1 =8e3
∫ 1
0
dx
∫ 1−x
0
dz
∫ dDl
(2π)D
[2lν(lμCρ −gμρC ·l +lρCμ)
(l2 −Δ)3 −
− l2(gμνCρ −gμρCν +gνρCμ)
(l2 −Δ)3
]
,
since
tr[γμ/lγν/lγρ/C]=2 lνtr[γμ/lγρ/C] −l2tr[γμγνγρ/C].
By integrating overl (using (11.C)) we get
iM1 = 4ie3
(4π)D/2Γ
(ϵ
2
)∫ 1
0
dx
∫ 1−x
0
dz
[
[
1 − ϵ
2 lnΔ +o(ϵ2)]
× (1 −D
2 )(gμνCρ −gμρCν +gνρCμ).
The divergent part of this integral is
iM1|div = − ie3
2π2ϵ
∫ 1
0
dx
∫ 1−x
0
dz(gμνCρ −gμρCν +gνρCμ).
The other two integrals can be evaluated in the same way. The ﬁnal result is
iM|div = − ie3
2π2ϵ
[1
6 (gμν(p1 −p2)ρ +gμρ(p1 −p2)ν +gρν(p1 −p2)μ)+
+ 1
2 (gμν(p1 +p2)ρ +gμρ(p2 −p1)ν −gρν(p1 +p2)μ)] .
The diagram where the orientation in the loop is opposite is shown in the
following ﬁgure.
The amplitude is the same as in (11.26) except that the trace in (11.26) should
be replaced by
tr[γρ(−/k − /p2 +m)γν(/p1 − /k +m)γμ(−/k +m)].

===== PDF PAGE 223 =====
Chapter 11. Renormalization and regularization 225
By putting C−1C in the previous expression, where matrix C is the charge
conjugation matrix (4.K), we get
tr[CγρC−1C(−/k − /p2 +m)C−1CγνC−1C
× (/p1 − /k +m)C−1CγμC−1C(−/k +m)C−1].
By using (4.K) we have
tr[γρ(−/k − /p2 +m)γν(/p1 − /k +m)γμ(−/k +m)]
=( −)3tr[γρ(/k +m)γμ(/k − /p1 +m)γν(/k +/p2 +m)],
from which the we get the requested result. The statement is valid for all
diagrams of this type with the odd number of vertices and this is called the
Furry theorem.
11.10 The vacuum polarization in QED is
−iΠμν(q)= −e2
∫ d4k
(2π)4
tr[(/k +m)γμ(/k +/q +m)γν]
(k2 −m2)((k +q)2 −m2) . (11.29)
From the Ward identity we know that this expression has the following form
−iΠμν(q)= −(qμqν −q2gμν)iΠ(q2).
By multiplying the previous expression bygμν and using (11.29) we get
iΠ(q2)= − 1
3q2 igμνΠμν
= −4e2
3q2
∫ d4k
(2π)4
−2k · (k +q)+4 m2
(k2 −m2)((k +q)2 −m2) . (11.30)
Discontinuity in the expression Π(q2) can be calculated by applying the
Cutkosky rule. Then
DiscΠ(q2)= 4ie2
3q2
1
(2π)4 (−2πi)2
∫
d4k(4m2 − 2k · (k +q))δ(4)(k2 −m2)
×δ(4)((k +q)2 −m2)θ(−k0)θ(k0 +q0). (11.31)
By using
δ(x2 −a2)= 1
2|a|(δ(x −a)+ δ(x +a))
and takingqμ =(q0, 0)w eg e t
DiscΠ(q2)= −16iπ2e2
3q2
1
(2π)4
∫
d4k(4m2 − 2k · (k +q))
× 1
4ω2kδ(k0 +ωk)δ(k0 +q0 −ωk). (11.32)

===== PDF PAGE 224 =====
226 Solutions
Integration overk0 gives
DiscΠ(q2)= −4iπ2e2
3q2
1
(2π)4
∫
d3k(2m2 +2q0ωk) 1
ω2kδ(q0 − 2ωk). (11.33)
Since d3k = |k|ωkdωk sinθdφdθ we have
DiscΠ(q2)= − ie2
3πq2
∫ ∞
m
dωk
2m2 +2q0ωk
ωk
√
ω2k −m2δ(q0 − 2ωk). (11.34)
Integration overωk gives
DiscΠ(q2)= e2
6πi
(
1+ 2m2
q2
)√
1 − 4m2
q2 θ(q2 − 4m2). (11.35)
Finally
ImΠ(q2 +iϵ)= 1
2iDiscΠ(p2)
= − e2
12π
(
1+ 2m2
q2
)√
1 − 4m2
q2 θ(q2 − 4m2). (11.36)
11.11 Scalar electrodynamics has two vertices:
= −ie(p +p′)μ =2 ie2gμν
The Feynman rules are standard excep t that for every closed photon loop
we have an extra factor 1/ 2. The photon self–energy is determined by the
diagrams:
The ﬁrst one is
−iΠ(1)μν =2 ie2gμν
∫ dDk
(2π)D
i
k2 −m2 .
By applying (11.A) and (11.F) we obtain:
−iΠ(1)μν = − ie2
4π2ϵm2gμν +ﬁ n. part. (11.37)
The second diagram is

===== PDF PAGE 225 =====
Chapter 11. Renormalization and regularization 227
−iΠ(2)μν =e2
∫ dDk
(2π)D
(2k +p)μ(2k +p)ν
(k2 −m2)((k +p)2 −m2) .
By using the Feynman parametrization in the previous integral we get
−iΠ(2)μν =e2
∫ 1
0
dx
∫ dDk
(2π)D
4kμkν +2kμpν +2kνpμ +pμpν
[k2 +2xk ·p +p2x −m2]2 .
Applying the formulae (11.A–C) it follows that :
−iΠ(2)μν = ie2πD/2
(2π)D
∫ 1
0
dx
[
Γ
(ϵ
2
) 1
(m2 +p2x2 −p2x)ϵ/2 (4x2 − 4x +1 )pμpν
− 2gμν
Γ
(ϵ
2 − 1
)
(m2 +p2x2 −p2x)ϵ/2−1
]
,
which is equal to
−iΠ(2)μν = ie2
16π2
( 2
3ϵ(pμpν −p2gμν)+ 4m2
ϵ gμν

exit_code=0
```

### 2026-11-16T17:56:02.751139+08:00

```bash
rg -n '11\.6|11\.8|11\.12|11\.13|11\.14|4\.33|5\.18|10\.10' planning/source-notes/qft-problem-book-all.txt
```

```text
879:4.33. L e ta ne l e c t r o nm o v ei nap o t e n t i a lh o l e2a wide andV deep. Consider
1177:5.18. In general, the canonical energy–momentum tensor is not symmetric
1464:5.18. Instead of the classical ﬁeld, use the corresponding operator. Prove the
2040:whereMij was found in Problem 5.18.
2285:10.10. Calculate the cross section per unit volume for the creation of electron–
2467:11.6. Consider the interacting theory of two scalar ﬁeldsφ andχ:
2484:11.8. The Lagrangian density is given by
2523:11.12. The Lagrangian density for the pseudoscalar Yukawa theory is given
2539:11.13. Consider massless two–dimensional QED, the so–called Schwinger mo-
2543:11.14. Considerφ3 theory in six–dimensional spacetime, with the Lagrangian
4709:iσμSRΛμν∂νψR(x)= mSLψL(x), (4.33)
4711:By multiplying Equation (4.33) byS−1L from left, and (4.34) byS−1R also
5195:4.33
6068:5.18
6242:d4x′ =e −4ρd4x ≈ (1 − 4ρ)d4x, (5.18)
9259:lem 5.18 using the Nether technique. It follows that (in the Coulomb gauge)
10097:+ 24(iΔF(x −y))4 . (10.10)
10546:10.10 The initial state is vacuum |0⟩, while the ﬁnal state is
11146:(−q2E −m2 −p2 +iϵ)n . (11.6)
11219:dte−ttz−1 . (11.8)
11226:By using the deﬁnition of number e, the integral (11.8) becomes
11304:. (11.12)
11309:n − 1 . (11.13)
11312:=1 −γϵ +o(ϵ). (11.14)
11466:11.6 InD–dimensional space the interaction term takes the form−gμϵ/2χφ2.
11930:11.8 The vertices in this theory are shown in Fig. 11.2.
12261:11.12
12317:(b) The one–loop fermionic propagator correction is represented in Fig. 11.6.
12330:Fig. 11.6. The one–loop correction to fermionic propagator
12606:11.13 In this problem dimension of spacetime isD =2 −ϵ.
12697:11.14 The dimension of spacetime isD =6 −ϵ.
12711:3! φ3 −μ−ϵ/2δhφ. (11.60)
12713:Z =1+ δZ, (11.61)
12714:m20Z =m2 +δm2 , (11.62)
12715:g0Z3/2 =(g +δg)μϵ/2 , (11.63)
12716:h0Z1/2 =(h +δh)μ−ϵ/2 , (11.64)
12726:in Figure 11.8.
12727:Fig. 11.8. Feynman rules in φ3 theory
12762:64π3ϵ − iδhμ−ϵ/2 +ﬁ n. part. (11.65)
12765:64π3ϵ +ﬁ n. part. (11.66)
12806:+ﬁ n. part. (11.67)
12817:+ip2δZ − iδm2 +ﬁ n. part. (11.68)
12820:384π3ϵ +ﬁ n. part, (11.69)
12823:In MS scheme the ﬁnite parts in (11.69) and (11.70) are zero.
12874:(e) From (11.61), (11.69) and (11.70) follows
12886:in the one–loop order. Similarly, from (11.69) and (11.74) we have

exit_code=0
```

### 2026-11-16T17:56:55.846146+08:00

```bash
sed -n 11435,11530p planning/source-notes/qft-problem-book-all.txt
```

```text
whereC is a constant. In order to determineC we will compute the contraction
gαβgμνgρσIαβμνρσ . It is easy to get
gαβgμνgρσIαβμνρσ =C(D3 +6D2 +8D).
On the other hand
gαβgμνgρσIαβμνρσ =
∫ dDk
(k2)n−3 = limμ→0
∫ dDk
(k2 −μ2)n−3
= lim
μ→0
i(−1)n−3π2Γ(n − 3 − D
2 )
Γ(n − 3) (μ2)3−n+ D
2 ,

===== PDF PAGE 214 =====
216 Solutions
whereμ is a infrared parameter. Comparing these results we get
C = 1
D3 +6D2 +8D limμ→0 i(−1)n−3π2Γ(n − 3 − D
2 )
Γ(n − 3) (μ2)3−n+ D
2 .
Specially, forn = 5 the divergent part of the integralIαβμνρσ is
Iαβμνρσ |div = iπ2
96ϵ[gαβ(gμνgρσ +gμρgνσ +gμσgνρ)
+gαμ(gβνgρσ +gβρgνσ +gβσgνρ)
+gαν(gβμgρσ +gβρgμσ +gβσgμρ)
+gαρ(gβμgνσ +gβνgμσ +gβσgνμ)
+gασ(gβμgνρ +gβνgμρ +gβρgμν).
11.6 InD–dimensional space the interaction term takes the form−gμϵ/2χφ2.
(a) The self–energy of theχ particle is determined by the diagram
p
k
k
p
p+
from which we read
−iΠ(p2)=2 g2μϵ
∫ dDk
(2π)D
1
k2 −m2 +i 0
1
(k +p)2 −m2 +i 0. (11.16)
By introducing the Feynman parametrization (11.G) and integrating over
the momentumk we get:
−iΠ(p2)= ig2
8π2
(2
ϵ −γ −
∫ 1
0
dxlnm2 +p2x(x − 1) − i0
4πμ2
)
= ig2
8π2
[2
ϵ −γ − ln m2
4πμ2
−
∫ 1
0
dxln
(
1+ p2
m2x(x − 1) − i0
)]
. (11.17)
As we know from the complex analysis the logarithm function, w =l nz
has a branch cut along the positivex–axis which starts at the branch point
z = 0. This branch cut is necessary if we want that branches of logarithm
function to be single valued and holomorphic functions. Let us ﬁnd the
branch point for function
ln[1 + p2
m2x(x − 1)].
It is the smallest value ofp2 for which the argument of logarithm function
vanishes:

===== PDF PAGE 215 =====
Chapter 11. Renormalization and regularization 217
1+ p2
m2 (x2 −x)=0 ,
i.e.
∂p2
∂x =m2 2x − 1
(x2 −x)2 =0 ,
from which we getx = 1
2 .T h ep o i n tp2 =4m2, which is step energy for the
decayχ → 2φ, is the branch point. A branch cut starts at this point and
goes alongx–axis in the positive direction to the inﬁnity. Let us introduce
the following notation
I = g2
8π2

exit_code=0
```

### 2026-11-16T17:58:44.991002+08:00

```bash
sed -n 11520,11650p planning/source-notes/qft-problem-book-all.txt
```

```text
i.e.
∂p2
∂x =m2 2x − 1
(x2 −x)2 =0 ,
from which we getx = 1
2 .T h ep o i n tp2 =4m2, which is step energy for the
decayχ → 2φ, is the branch point. A branch cut starts at this point and
goes alongx–axis in the positive direction to the inﬁnity. Let us introduce
the following notation
I = g2
8π2
∫ 1
0
dxln
(
1+ p2
m2x(x − 1) − iδ
)
.
We shall calculate ﬁrst this integral in the case p2 > 4m2.F o rX> 0w e
have
log[−X − i0] = log|X|− iπ.
The zeroes of 1 + p2
m2x(x − 1) are
x1,2 =
1 ±
√
1 − 4m2
p2
2 .
Forx1 <x<x 2 the expression 1 + p2
m2 (x2 −x) is negative, otherwise it is
positive. Then
I = g2
8π2
[∫ x1
0
dxln
(
1+ p2
m2x(x − 1)
)
+
∫ 1
x2
dxln
(
1+ p2
m2x(x − 1)
)
+
∫ x2
x1
dxln
(
−1 − p2
m2x(x − 1)
)
− iπ(x2 −x1)
]
. (11.18)
By doing partial integration we have
I = g2
8π2
[
xln
(
1+ p2
m2x(x − 1)
)⏐⏐⏐x1
0
− p2
m2
∫ x1
0
dx x(2x − 1)
1+ p2(x2 −x)/m2
+xln
(
1+ p2
m2x(x − 1)
)⏐⏐⏐1
x2
− p2
m2
∫ 1
x2
dx x(2x − 1)
1+ p2(x2 −x)/m2
+xln
(
−1 − p2
m2x(x − 1)
)⏐⏐⏐x2
x1
− p2
m2
∫ x2
x1
dx x(2x − 1)
1+ p2(x2 −x)/m2
− iπ(x2 −x1)] . (11.19)
Combining the terms in the previous formula we get

===== PDF PAGE 216 =====
218 Solutions
I = g2
8π2
[
−iπ(x2 −x1) − p2
m2
∫ 1
0
dx x(2x − 1)
1+ p2(x2 −x)/m2
]
. (11.20)
The integral in the previous formula can be simpliﬁed by introducing the
new variablet =2x − 1. The result is (see [9])
I = −ig2
8π
√
1 − 4m2
p2 − g2
4π2
⎡
⎣1+ 1
2
√
1 − 4m2
p2 ln

exit_code=0
```

### 2026-11-16T18:00:05.877169+08:00

```bash
sed -n '5193,5322p;6047,6250p;10530,10700p;11620,11805p' planning/source-notes/qft-problem-book-all.txt
```

```text
===== PDF PAGE 111 =====
110 Solutions
4.33
(a) The wave function is
ψI =
⎛
⎜⎝
B
B′
−iκσ3
(E+m)
(
B
B′
)
⎞
⎟⎠ eκz,z < −a,
ψII =
⎛
⎜⎝
C
C′
qσ3
(E+m+V )
(
C
C′
)
⎞
⎟⎠eiqz (4.71)
+
⎛
⎜⎝
D
D′
−qσ3
(E+m+V )
(
D
D′
)
⎞
⎟⎠e−iqz, −a<z<a,
ψIII =
⎛
⎜⎝
F
F ′
iκσ3
(E+m)
(
F
F ′
)
⎞
⎟⎠e−κz,z>a ,
where κ =
√
m2 −E2 and q = √
(E +V )2 −m2. Since there is no spin
ﬂip, we can takeB′ =C′ =D′ =F ′ = 0. From the boundary conditions
ψI(−a)= ψII (−a)a n dψII (a)= ψIII (a), it follows that
e−κaB =e −iqaC +e iqaD
e−κaF =e iqaC +e −iqaD
−ire−κaB =e −iqaC − eiqaD
ire−κaF =e iqaC − e−iqaD,
wherer = κ
q
E+m+V
E+m . By combining previous equations we obtain
e−κa(B −F)=2 is i n (qa)(D −C)
ire−κa(B −F)=2c o s (qa)(D −C)
e−κa(B +F)=2c o s (qa)(D +C)
re−κa(B +F)=2s i n (qa)(D +C).
Further, we will distinguish two classes of solutions: odd and even. IfB =F
andC =D, the third and the fourth equations give the following dispersion
relation:
tan(qa)= κ
q
E +m +V
E +m .
These solutions satisfy the following property: ψ′(z)= γ0ψ(−z)= ψ(z);
thus they are even. On the other hand, if B = −F and C = −D,t h e
dispersion relation is

===== PDF PAGE 112 =====
Chapter 4. The Dirac equation 111
cot(qa)= −κ
q
E +m +V
E +m .
This class of solutions satisfy ψ′(z)= γ0ψ(−z)= −ψ(z), and therefore
they are odd.
(b) The dispersion relations are transcendental equations and they cannot be
solved analytically. We can analyze them graphically.
For even solutions, the dispersion relation has the form
q tan(qa)= f(q), (4.72)
where
f(q)=
√
2V
√
q2 +m2 −q2 −V 2 m +
√
q2 +m2
m +
√
q2 +m2 −V ,
and its graphical solution is given in Fig. 4.1.
Fig. 4.1. Graphical solution of Equation (4.72) for even states (V< 2m)
In the case of odd solutions, the dispersion relation
q cot(qa)= −f(q) (4.73)
is shown in Fig. 4.2. From these ﬁgures we see that the spectrum of electron
bound states will containN states if the condition
(N − 1)π
2a ≤
√
V (V +2m)< Nπ
2a
is satisﬁed. It is easy to see that ifN = 1 then this solution is even.
(c) Graphical solutions for odd and even part of spectrum are given in Fig.
4.3 and Fig. 4.4.

===== PDF PAGE 113 =====
112 Solutions
Fig. 4.2. Graphical solution of Equation (4.73) for odd states (V< 2m)
Fig. 4.3. Graphical solution for odd states (V> 2m)
Fig. 4.4. Graphical solution for even states (V> 2m)

===== PDF PAGE 114 =====
===== PDF PAGE 126 =====
126 Solutions
L→ ψ†e−iαγ5γ0(iγμ∂μ −m)eiαγ5ψ
=( c o s2α +s i n2α) ¯ψiγμ∂μψ −m ¯ψ(cosα +iγ5 sinα)2ψ
= ¯ψiγμ∂μψ −m ¯ψ(cos 2α +iγ5 sin2α)ψ.
From the previous expression we can conclude that the Lagrangian density
is invariant only for massless fermions. The Noether current isjμ = ¯ψγμγ5ψ.
Prove that∂μjμ is proportional to the massm of the ﬁeld.
5.17 The current is given by
jμ = ∂L
∂(∂μσ)δσ + ∂L
∂(∂μπa)δπa + ∂L
∂(∂μΨi)δΨi +δ ¯Ψi ∂L
∂(∂μ ¯Ψi)
= −ϵabcαb∂μπaπc − 1
2
¯ΨiγμαaτaijΨj .
The ﬁnal result has the form
jμ = π ×∂μπ + 1
2
¯ΨγμτΨ.
5.18
(a) For translations, we haveδxμ =ϵμ, while the total variations of the ﬁelds
equal zero. The Noether current is
Tμν = ∂L
∂(∂μφr)
∂φr
∂xν
−Lgμν . (5.2)
The indexν in (5.2) comes from the group of translations. For a real scalar
ﬁeld, from (5.2) we obtain
Tμν =∂μφ∂νφ − 1
2
[
(∂φ)2 −m2φ2]gμν . (5.3)
The conserved charges are the Hamiltonian (forν =0 ) ,
H =
∫
d3xT 00 = 1
2
∫
d3x[(∂0φ)2 +( ∇φ)2 +m2φ2] , (5.4)
and the momentum (forν =i)
Pi =
∫
d3xT 0i =
∫
d3x∂0φ∂iφ. (5.5)
For the Dirac ﬁeld the energy–momentum tensor is given by
Tμν =i ¯ψγμ∂νψ −Lgμν .
The Hamiltonian and momentum are given by

===== PDF PAGE 127 =====
Chapter 5. Classical ﬁelds and symmetries. 127
H =
∫
d3x ¯ψ[−iγ∇ +m]ψ, (5.6)
P = −i
∫
d3xψ†∇ψ. (5.7)
For electromagnetic ﬁeld the energy–momentum tensor is
Tμν = ∂L
∂(∂μAρ)
∂Aρ
∂xν
−Lgμν
from which we obtain
Tμν = −Fμρ∂νAρ + 1
4F 2gμν . (5.8)
For the Lorentz transformationsδxν =ωνρxρ and
δφ =0 ,δψ = − i
4σνρωνρψ, δAμ =ω νμ Aν ,
The Noether currents for scalar, spinor and electromagnetic ﬁeld are
jμ =[xνTμρ −xρTμν]ωνρ ,
jμ =[ 1
2
¯ψγμσνρψ + xνTμρ −xρTμν]ωνρ , (5.9)
jμ =[FμρAν −FμνAρ +(xνTμρ −xρTμν)]ωνρ .
Dropping the parameters of the Lorentz transformations ωνρ, the con-
served currents have the formMμνρ, and they are given by the expression
in square brackets in (5.9). The angular-momentum isMνρ =
∫
d3xM0νρ.
(b) As we see, the energy–momentum tensors for Dirac and electromagnetic
ﬁelds are not symmetric. To ﬁnd the symmetrized energy–momentum ten-
sors we employ the procedure given in the problem. For the Dirac ﬁeld we
have
χρμν = 1
4(− ¯ψγμσρνψ + ¯ψγρσμνψ + ¯ψγνσμρψ)
= i
8
¯ψ(4gμνγρ − 4gρνγμ +γμγνγρ −γργνγμ)ψ.
Using (4.43) we ﬁnd
∂ρχρμν = − i
4∂ν ¯ψγμψ − i
4∂μ ¯ψγνψ − 3i
4
¯ψγμ∂νψ
+ i
4
¯ψγν∂μψ +gμν i
2(∂ν ¯ψγνψ + ¯ψ/∂ψ).
The symmetrized energy–momentum tensor for Dirac ﬁeld is

===== PDF PAGE 128 =====
128 Solutions
˜Tμν = i
4( ¯ψγν∂μψ + ¯ψγμ∂νψ −∂μ ¯ψγνψ −∂ν ¯ψγμψ)
−gμν
(
− i
2∂ν ¯ψγνψ + i
2
¯ψ/∂ψ −m ¯ψψ
)
.
Similarly we determine the symmetrized energy–momentum tensor for the
electromagnetic ﬁeld. From transformation rule of the electromagnetic po-
tential with respect to Lorentz transformations
δAα =ωαβAβ ≡ 1
2ωμν(Iμν)αβAβ ,
follows that
(Iμν)αβ =gμαgνβ −gμβgνα .
Thenχρμν =FμρAν and the new energy–momentum tensor is
˜Tμν = −FμρFνρ + 1
4F 2gμν . (5.10)
If we introduce the electric and magnetic ﬁelds: F 0i = −Ei, Fij =
−ϵijkBk, then the components of energy–momentum tensor are:
˜T 00 = −F 0iF 0i + 1
4(2F0iF 0i +FijFij)
= E2 + 1
4(−2E2 +2 B2)
= 1
2(E2 + B2),
˜T 0i = −F 0jFij
=ϵijkEjBk
=( E × B)i , (5.11)
˜Tij = −EiEj +ϵiklϵjknBlBn + 1
2(E2 − B2)δij
= −
(
EiEj +BiBj −δij ˜T00
)
.
From the expression (5.11) we conclude that ˜T00 ˜T 0i, − ˜Tij are the energy
density of electromagnetic ﬁeld, the Poynting vector, and the components
of the Maxwell stress tensor.
5.19 The variation of form is deﬁned byδ0φ(x)= φ′(x) −φ(x). From
δ0φ =δφ −∂μφδxμ,
whereδφ =φ′(x′) −φ(x) is the total variation of a ﬁeld, it follows that the
inﬁnitesimal form variation ofφ is
δ0φ =ρ(φ(x)+ xμ∂μφ). (5.12)

===== PDF PAGE 129 =====
Chapter 5. Classical ﬁelds and symmetries. 129
The induced change of the action is
S′ −S = 1
2
∫
d4x′ [(∂′φ′)2 −m2φ′2(x′)] − 1
2
∫
d4x[(∂φ)2 −m2φ2(x)] .
(5.13)
The transformed volume of integration is given by
d4x′ = |J|d4x = det(e−ρI)d4x =e −4ρd4x. (5.14)
The ﬁeld derivative is changed according to the following rule:
∂μφ(x) → ∂φ′
∂x′μ = ∂xν
∂x′μ
∂
∂xν (eρφ)=e 2ρ∂μφ. (5.15)
Thus, the change of the action is
S′ −S = 1
2
∫
d4xe−4ρ [e4ρ(∂φ)2 −m2e2ρφ2(x)]
− 1
2
∫
d4x[(∂φ)2 −m2φ2(x)]
= 1
2m2(1 − e−2ρ)
∫
d4xφ2(x).
For an inﬁnitesimal dilatation (ρ ≪ 1), the variation of the action is
δS =m2ρ
∫
d4xφ2(x). (5.16)
From (5.16) it is clear that the theory of massless scalar ﬁeld is invariant under
dilatations.
The conserved current is
jμ = −φ∂μφ −xν∂μφ∂νφ + Lxμ . (5.17)
By calculating∂μjμ one obtains that∂μjμ is proportional to the massm.
5.20 From
d4x′ =e −4ρd4x ≈ (1 − 4ρ)d4x, (5.18)
and
¯ψ′(x′)γμ∂′μψ′(x′)=e 4ρ ¯ψγμ∂μψ ≈ (1 + 4ρ) ¯ψγμ∂μψ, (5.19)
it follows that this transformation leaves the action unchanged. The Noether
current isjμ = − 3
2 i ¯ψγμψ − ixν ¯ψγμ∂νψ +xμL.

===== PDF PAGE 130 =====
6
===== PDF PAGE 200 =====
202 Solutions
The average value of the squared transition amplitude is:
⟨
|Sﬁ|2⟩ = 16π3e2g2T
V 2EiEf
1
(
q2 + 1
a2
)2δ(Ef −Ei)(EiEf + |pi||pf | sinθ −m2).
The diﬀerential cross section is:
dσ
dΩ =2e2g2 (E2 −m2)(1 + cosθ)
( 1
a2 +2 (E2 −m2)(1 − cosθ))2 .
10.10 The initial state is vacuum |0⟩, while the ﬁnal state is
|f⟩ =c
†
(p1,r )d
†
(p2,s ) |0⟩ .
The transition amplitude is
Sﬁ = ie
V
∫
d4x∑
r′s′
∫
d3q1d3q2
√
 m
Eq1
√
 m
Eq2
⟨0|d(p2,s )c(p1,r )
× (c
†
(q1,r ′)d† (q2,s ′)¯u(q1,r ′)γμAμ(x)v(q2,s ′)eiq1 ·x+iq2 ·x +... ) |0⟩ ,
where we have dropped the vanishing terms. After reducing the last expression
one obtains
Sﬁ =ie ma
V √
E1E2
∫
d4x ¯u(p1,r )γ2v(p2,s )ei(p2+p1 )·xe−iωt
=ie(2π)4 ma
V √
E1E2
× ¯u(p1,r )γ2v(p2,s )δ(3)(p1 + p2)δ(E1 +E2 −ω).
The average value of the squared transition amplitude is
⟨
|Sﬁ|2⟩ =( 2π)4TVδ (3)(p1 + p2)δ(E1 +E2 −ω)
× e2a2
4V 2E1E2 tr[(/p1 +m)γ2(/p2 −m)γ2]
=( 2π)4Tδ (3)(p1 + p2)δ(E1 +E2 −ω) e2a2
VE 1E2
× (E1E2 + |p1||p2|− 2|p1||p2| sin2θ cos2φ +m2),
since the four-momenta are:
pμ1 =(E1,p 1 sinθ cosφ,p 1 sinθ sinφ,p 1 cosθ),
pμ2 =(E2, −p2 sinθ cosφ, −p2 sinθ sinφ, −p2 cosθ).
The diﬀerential cross section is:
dσ =
⟨
|Sﬁ|2⟩
T
V d3p1
(2π)3
V d3p2
(2π)3 .

===== PDF PAGE 201 =====
Chapter 10. Processes in the lowest order of the perturbation theory 203
By integrating over p2 and p1 one obtains the scattering cross section (per
unit volume)
σ = e2a2
3πω (ω2 +2m2)
√
ω2
4 −m2 .
10.11 The transition amplitude is
Sﬁ = ieam
V
1
√
EiEf
¯u(pf,s )γ3(1 −γ5)u(pi,r )
∫
d4xe−ipi ·x+ipf ·xe−k2x2 .
By integrating overt and x we get
Sﬁ =iea
√
 m
EiV
√
 m
EfV
(π
k2
)3/2
e−
(pi −pf )2
4k2
× 2πδ(Ei −Ef)¯u(pf,s )γ3(1 −γ5)u(pi,r ).
The average value of the squared transition amplitude is:
⟨
|Sﬁ|2⟩ = e2a2m2
V 2EiEf 2πTδ (Ei −Ef)
(π
k2
)3
e−
(pi −pf )2
2k2
⟨
|M|2⟩ ,
where
⟨
|M|2⟩ = 1
2
2∑
r,s=1
|¯u(pf,s )γ3(1 −γ5)u(pi,r )|2
= 1
2
1
4m2 tr [(/pf +m)γ3(1 −γ5)(/pi +m)(1 +γ5)γ3]
= 1
m2 (2p3fp3i +pi ·pf).
The diﬀerential cross section is:
dσ
dΩ = e2a2π
4k6
(
E2i + |pi|2 cosθ) e− 1
k2 |pi |2(1−cos θ) .
10.12 We shall present the expression for the transition amplitude and ﬁnal
result for the diﬀerential cross section only:
Sﬁ =ie m
V √
EiEf
¯v(pi,s )v(pf,r )
∫
d4x(iEf ) g
|x|e−i(pi−pf )·x ,
dσ
dΩ = e2g2E2(E2 +m2 − p2 cosθ)
2|p|4(1 − cosθ)2 .
10.13 The transition amplitudeSﬁ is
Sﬁ =iea
√
 m
VE i
√
 m
VE f
¯u(pf,s f)γ0u(pi,s i)
∫
d4xδ(3)(x)e−i(pi−pf )·x
=iea m
V √
EiEf
(2π)δ(Ei −Ef)¯u(pf,s f)γ0u(pi,s i),

===== PDF PAGE 202 =====
204 Solutions
wheresi isf are initial and ﬁnal electron polarizations. In order to calculate
|Sﬁ|2 it is necessary to compute squared spin-part of the amplitude. Since
u(p,s )¯u(p,s )= 1+ γ5/s
2
1+ p2(x2 −x)/m2
− iπ(x2 −x1)] . (11.19)
Combining the terms in the previous formula we get

===== PDF PAGE 216 =====
218 Solutions
I = g2
8π2
[
−iπ(x2 −x1) − p2
m2
∫ 1
0
dx x(2x − 1)
1+ p2(x2 −x)/m2
]
. (11.20)
The integral in the previous formula can be simpliﬁed by introducing the
new variablet =2x − 1. The result is (see [9])
I = −ig2
8π
√
1 − 4m2
p2 − g2
4π2
⎡
⎣1+ 1
2
√
1 − 4m2
p2 ln
1 −
√
1 − 4m2
p2
1+
√
1 − 4m2
p2
⎤
⎦ .
For 0<p 2 < 4m2 we get [9]
I = g2
4π2
[
−1+
√
4m2
p2 − 1arc s i n
√
p2
4m2
]
.
The ﬁnal result for the vacuum polarization, −iΠ(p2)i s
−iΠ(p2)= ig2
8π2
(2
ϵ −γ − ln m2
4πμ2 +2
)
+π(p2), (11.21)
where
π(p2)= − ig2
4π2
√
4m2
p2 − 1arc s i n
√
p2
4m2
for 0<p 2 < 4m2 and
π(p2)= ig2
8π2
⎛
⎝i
√
1 − 4m2
p2 +
√
1 − 4m2
p2 ln
1 −
√
1 − 4m2
p2
1+
√
1 − 4m2
p2
⎞
⎠
forp2 > 4m2.
(b) In the lowest order of the perturbation theory the transition amplitude is
given by
Sfi = −ig
∫
d4x ⟨p1, p2|χ(x)φ(x)φ(x) |M, p =0 ⟩
=( 2π)4δ(4)(p −p1 −p2)
√
1
2VM
√
1
2VE 1
√
1
2VE 2
(−2ig),
where p1,2 are the momenta of the decay products. Also we take that χ
particle is in the rest. The decay rate is
dΓ = |Sfi |2
T
V 2d3p1d3p2
(2π)6 .
By integrating over the momentum p2 we get:

===== PDF PAGE 217 =====
Chapter 11. Renormalization and regularization 219
Γ = 4g2
(2π)2
∫
dEpE 1
8ME 2δ(M − 2E)
∫ π
0
dθ
∫ π
0
dφ,
and the space angle integration gives 2π (not 4π, because the ﬁnal particles
are identical). The ﬁnal result is given by:
Γ = g2
4πM 2
√
M 2
4 −m2 .
(c) The imaginary part ofΠ(p2) can be read oﬀ the part (a):
ImΠ(p2)= −g2
8π
√
1 − 4m2
p2 θ(p2 − 4m2). (11.22)
This result also can be obtained using Cutkosky rule . The expression
(11.16) can be rewritten in the following form
−iΠ(p2)=2 g2
∫ d4k
(2π)4
1
(−k)2 −m2 +i 0
1
(k +p)2 −m2 +i 0. (11.23)
The discontinuity of the amplitude
DiscΠ(p2)= Π(p2 +iϵ) −Π(p2 − iϵ),
is obtained by making the substitution
1
p2 −m2 → (−2iπ)δ(4)(p2 −m2)θ(p0),
in the expression (11.23). Since Π(p2) is a Lorentz scalar we shall take
that pμ =( p0, p = 0) i.e. we shall calculate it in the rest frame of the
particleχ.I nt h i sw a yw eo b t a i n
DiscΠ(p2)=2 ig2(−2iπ)2
∫ d4k
(2π)4δ(4)(k2 −m2)
×δ(4)((k +p)2 −m2)θ(−k0)θ(k0 +p0)
= −g2i
8π2
∫
d4k 1
ω2kδ(k0 +ωk)δ(k0 +p0 −ωk)
= − ig2
8π2
∫
d3kδ(p0 − 2ωk)
ω2k . (11.24)
By performing the integration over the momentum k we get
DiscΠ(p2)= −ig2
4π
√
1 − 4m2
p2 .
Since

===== PDF PAGE 218 =====
220 Solutions
Im Π(p2)= 1
2iDisc Π(p2),

exit_code=0
```

### 2026-11-16T18:09:01.955479+08:00

```bash
python3 -c 'from pathlib import Path; import subprocess; out=Path("checks/qft-expansion-radovanovic-source-pages"); out.mkdir(parents=True, exist_ok=True); src="/Users/ai4s/Downloads/Problem Book in Quantum Field Theory.pdf"; [subprocess.run(["pdftoppm","-f",str(p),"-l",str(p),"-singlefile","-scale-to","1600","-png",src,str(out/("page-%03d"%p))],check=True) for p in (65,66,220,226,232,235)]'
```

```text

exit_code=0
```

### 2026-11-16T18:11:24.422765+08:00

```bash
sed -n 11800,11825p planning/source-notes/qft-problem-book-all.txt
```

```text

### 2026-11-16T18:11:24.422806+08:00

```bash
rg -n '^#|^\| [0-9]' planning/qft-expansion-radovanovic-review.md
```

```text
Since

===== PDF PAGE 218 =====
220 Solutions
Im Π(p2)= 1
2iDisc Π(p2),
we again obtain the result (11.22). From the expressions forΓ andΠ(M 2)
we immediately see that the relation which was given in problem is valid.
This relation is a consequence of the optic theorem.
11.7 InD =4 −ϵ dimensional spacetime the dimension of a scalar ﬁeld is
D/2 − 1, while the dimensions of the coupling constants are the same as in
four dimensions: [λ]=0 , [g] = 1. The dimension of the Lagrangian density
must be [L]= D,s oi ti sg i v e nb y
L = 1
2(∂μφ)2 −m2
2 φ2 −gμϵ/2
3! φ3 −λμϵ
4! φ4 ,
where we introduced the parameterμ which has the dimension of mass. The
self–energy is determined by diagrams shown in Fig. 11.1.
Fig. 11.1. The one-loop contribution to the self–energy of φ ﬁeld
The contribution of the ﬁrst one is
−iΣ1 = −iλ
2μϵ
∫ dDk
(2π)D

exit_code=0
```
1:# Radovanović 习题集：新增 QFT 题目候选核读评审
5:## 来源与核读范围
16:| 11.8 | 65 / 63 | 219–220 / 221–222 | 优先保留：Goldstone 一圈保护机制 |
17:| 11.12 | 66 / 64 | 225–231 / 227–233 | 优先保留：完整 Yukawa 重整化闭合 |
18:| 11.13 | 66 / 64 | 231–232 / 233–234 | 保留但必须扩展：Schwinger 动态质量与响应 |
19:| 11.14 | 66 / 64 | 232–236 / 234–238 | 优先保留：六维 φ³ 的局域减除与裸量闭合 |
20:| 11.6 | 65 / 63 | 214–218 / 216–220 | 有条件候选：光学定理；与现有题重复风险较高 |
21:| 4.33 | 27 / 22 | 111–113 / 110–112 | 后备：严格说是相对论量子力学，非本轮优先 |
22:| 5.18 | 34 / 29 | 126–128 / 126–128 | 不建议本轮独立计题：常规 Noether 推导 |
23:| 10.10 | 60 / 58 | 200–201 / 202–203 | 不建议：标准一阶外场对产生；让位于 Gelis 80 |
25:## 1. 原题 11.8：Goldstone 模式的一圈质量保护
41:## 2. 原题 11.12：赝标量 Yukawa 理论的重整化闭合
63:## 3. 原题 11.13：Schwinger 模型的动态光子质量
79:## 4. 原题 11.14：六维 φ³ 理论的局域减除与裸量闭合
102:## 5. 原题 11.6：光学定理、相同粒子因子与多阈值谱（有条件候选）
110:## 6. 原题 4.33：有限深 Dirac 势阱（后备）
118:## 7. 原题 5.18：Belinfante 能动张量（不建议独立计题）
124:## 8. 原题 10.10：振荡均匀外场的一阶对产生（不建议）
130:## 推荐给主清单的取舍

exit_code=0
```

### 2026-11-16T18:21:41.242868+08:00

```bash
cat planning/work-order-radovanovic-next.md
```

```text
# Gelis 有限温、格点与强场候选核读

这是主代理分配的当前子任务。只做来源评审，不修改现有题包。

读取 `planning/source-notes/qft-gelis-all.txt` 中 Problem 69、70、72、73、75、80、82 的完整题面与解答。页码以 `===== PDF PAGE N =====` 为准，逐页确认印刷页。本书扫描件章节重排，不能使用全书统一偏移。

写入 `planning/qft-expansion-gelis-thermal-review.md`。每题列：原题号与准确 PDF/印刷页范围；已完整核读范围；核心物理工作及关键关系；容易误述的边界；有研究判断的原创 benchmark 改造；结构化交付与客观评分；两条独立真值路线；相互独立性。80 是标量 QED，不是费米子 QED。70 作为增强独立性的候选，与另一本六维 phi^3 比较。

起始页线索：69 PDF161；70 PDF163；72 PDF171；73 PDF176；75 PDF183；80 PDF209；82 PDF225。以实际题目开始结束为准。必要时视觉检查原页。

每完成两题先落盘，再继续。不要等全部结束才保存。不声称未实际做过的核读、渲染或测评。所有 shell 命令执行前在 commentary 展示，用 `python3 tools/run_logged.py --log checks/qft-expansion-gelis-thermal-command-log.md -- COMMAND ...` 记录。

exit_code=0
```
