# tm-01 校准与验证记录

日期：2026-11-16（Asia/Shanghai）

## 学科与来源

本题是理论力学中的多自由度小振动逆问题，核心为简正振动时域响应、刚度矩阵和参数反演。弹簧链模型参考鞠国兴《理论力学学习指导与习题解析（理科用）（第二版）》第 5 章习题 5.8；准确页码及改造见 [来源说明](tm-01-sources.md)，推导和算法见 [参考解说明](../tasks/tm-01/solution/README.md)。

## 基线、专家解与评分检查

使用 `tools/run_tm01_checks.py` 在公开数据上运行基线与参考解，再由题目独立 verifier 计算指标。默认模式只核对已有指标；`--calibrate` 在全部检查通过后，同步更新 `tasks/tm-01/tests/metric.json` 和公开的 `tasks/tm-01/environment/public/metric.json`。

| 答案类型 | 综合识别误差 | 课程得分 | 结果 |
|---|---:|---:|---|
| 公开数据粗网格基线 | 17.9136068754 | 0 | 两根软化弹簧定位正确，刚度仍有离散网格误差 |
| 有界连续优化参考解 | 0.1187179938 | 1 | 参数 MAPE 0.0497069%，隐藏响应 NRMSE 0.222235%，位置 F1=1 |
| 格式有效但软化位置错误 | 78.5121165773 | 0 | 独立构造的错误答案，位置 F1=0 |
| 缺字段提交 | 无效 | 0 | 拒绝缺少必要字段的 JSON |
| 刚度与位置标签矛盾 | 无效 | 0 | 拒绝互相矛盾的产物 |
| 等价位置顺序 | 0.1187179938 | 1 | 与参考解同分 |

参考解对粗搜索起点对应的损伤对施加连续优化边界，确保最终刚度严格满足“恰有两根比例低于 0.8”的题目约束。JSON 结果、参数分指标、实际课程得分及自动检查布尔值保存在 [校准记录](tm-01-calibration.json)。

本次记录的 11 项检查全部通过：参考改善、参考合法、实质错误受罚、格式错误拒绝、矛盾标签拒绝、等价顺序同分、两个登记端点一致，以及基线、参考/等价答案、错误/无效答案的得分正确。

## Docker Linux 校准

实际使用环境为 `Linux-6.12.76-linuxkit-aarch64-with-glibc2.36`、Python 3.12.13、NumPy 2.1.3；4 CPU、4 GB 内存。基线耗时 0.1849 秒，参考解耗时 1.6684 秒，不含镜像构建与容器启停。

在项目根目录执行的校准命令：

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 \
  --env PYTHONDONTWRITEBYTECODE=1 --env OPENBLAS_NUM_THREADS=1 \
  --mount "type=bind,source=$PWD,target=/work" --workdir /work \
  theory-physics-tm01:dev python tools/run_tm01_checks.py --calibrate
```

该校准在 Docker 的 `--network none` 下完成。公开镜像另经检查：能读取 `/app/data/metric.json`，包含固定版本 NumPy；不包含 `/tests/private/truth.json` 或 `/solution`。指标配置已经同时保存到公开数据区与 verifier 区。

## Harbor 联调

Harbor 0.24.0、Python 3.12、Docker Linux 容器、4 CPU、4 GB 内存，单并发、单次、无重试：

| Agent | Reward | 异常 | 运行记录 |
|---|---:|---:|---|
| `oracle` | 1.0 | 0 | `runs/tm-01/harbor-macos-compat/oracle/2026-11-16__11-39-32/` |
| `nop` | 0.0 | 0 | `runs/tm-01/harbor-macos-compat/nop/2026-11-16__11-39-53/` |

macOS Docker Desktop 不支持 Harbor verifier `no-network` 所需 egress-control。因而上述运行使用了 `/private/tmp/theory-physics-tm01-harbor/task/tm-01` 临时副本，将 verifier 网络设为 `public` 以检验 Docker、oracle/nop、产物收集和评分链路；正式题包的 `task.toml` 仍设为 `no-network`。课程 Linux 环境应以正式配置复跑。

从含 `%` 的课程路径直接启动 Harbor 会触发 Docker Compose URL 解析错误。本次将题目复制到不含 `%` 的 `/private/tmp` 路径运行；除上述临时副本的 verifier 网络设置外，题面、解法、数据和评分均使用正式题包版本。路径失败记录也保存在 `runs/tm-01/harbor-path-failure/oracle/2026-11-16__11-38-25/`。

两次 Harbor 记录生成于公开 `metric.json` 加入镜像前；随后已重新构建镜像并通过上述公开材料检查。数值校准记录来自包含公开指标配置的版本。

## 解释边界

`oracle=1.0` 仅表示参考解达到登记的专家端点，`nop=0.0` 表示空提交被拒绝；这两项是评分链路检查，不是 Codex 难度测评。指定 Codex 的三次独立正式运行应在题集冻结后进行。
