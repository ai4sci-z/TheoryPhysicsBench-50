
### 2026-11-16T22:52:40.252558+08:00

```bash
python3 -
```

```text
. ['README.md', 'benchmark.json', 'checks', 'docs', 'planning', 'provenance', 'runs', 'tasks', 'tmp', 'tools']
checks ['benchmark-50-command-log.md', 'benchmark-50-index.md', 'benchmark-50-inventory.json', 'benchmark-50-preflight.json', 'continuation-state-log.md', 'course-score-recheck', 'ed-01-calibration.json', 'ed-01-command-log.md', 'ed-01-materials-and-fairness.md', 'ed-01-sources.md', 'ed-01-truth-validation.json', 'ed-01-validation.md', 'ed-02-calibration.json', 'ed-02-command-log.md', 'ed-02-development-answers', 'ed-02-materials-and-fairness.md', 'ed-02-source-pages', 'ed-02-sources.md', 'ed-02-truth-validation.json', 'ed-02-validation.md', 'ed-03-calibration.json', 'ed-03-command-log.md', 'ed-03-development-answers', 'ed-03-source-pages', 'ed-03-sources-and-fairness.md', 'ed-03-truth-validation.json', 'ed-03-validation.md', 'ed-04-calibration.json', 'ed-04-command-log.md', 'ed-04-development-answers', 'ed-04-public-start.json', 'ed-04-source-pages', 'ed-04-sources.md', 'ed-04-truth-validation.json', 'ed-04-validation.md', 'ed-05-calibration.json', 'ed-05-command-log.md', 'ed-05-development-answers', 'ed-05-source-pages', 'ed-05-sources-and-fairness.md', 'ed-05-truth-validation.json', 'ed-05-validation.md', 'formal50-command-log.md', 'gr-01-calibration.json', 'gr-01-command-log.md', 'gr-01-source-pages', 'gr-01-sources-and-fairness.md', 'gr-01-truth-validation.json', 'gr-01-validation.md', 'gr-02-calibration.json', 'gr-02-command-log.md', 'gr-02-observation-generation.json', 'gr-02-review-work-order.md', 'gr-02-source-pages', 'gr-02-sources-and-fairness.md', 'gr-02-truth-validation.json', 'gr-02-validation.md', 'gr-03-calibration.json', 'gr-03-command-log.md', 'gr-03-development-answers', 'gr-03-observation-generation.json', 'gr-03-source-pages', 'gr-03-sources-and-fairness.md', 'gr-03-truth-validation.json', 'gr-03-validation.md', 'gr-04-calibration.json', 'gr-04-command-log.md', 'gr-04-development-answers', 'gr-04-source-pages', 'gr-04-sources-and-fairness.md', 'gr-04-truth-validation.json', 'gr-04-validation.md', 'gr-05-calibration.json', 'gr-05-command-log.md', 'gr-05-development-answers', 'gr-05-source-pages', 'gr-05-sources-and-fairness.md', 'gr-05-truth-validation.json', 'gr-05-validation.md', 'gr-05-work-order.md', 'harbor-new-tasks-command-log.md', 'integration-command-log.md', 'package-command-log.md', 'qft-01-calibration.json', 'qft-01-command-log.md', 'qft-01-materials-and-fairness.md', 'qft-01-sources.md', 'qft-01-truth-validation.json', 'qft-01-validation.md', 'qft-02-calibration.json', 'qft-02-command-log.md', 'qft-02-materials-and-fairness.md', 'qft-02-sources.md', 'qft-02-truth-validation.json', 'qft-03-calibration.json', 'qft-03-command-log.md', 'qft-03-sources.md', 'qft-03-truth-validation.json', 'qft-04-calibration.json', 'qft-04-command-log.md', 'qft-04-materials-and-fairness.md', 'qft-04-source-pages', 'qft-04-sources.md', 'qft-04-truth-validation.json', 'qft-04-validation.md', 'qft-05-calibration-command-log.md', 'qft-05-calibration.json', 'qft-05-command-log.md', 'qft-05-materials-and-fairness.md', 'qft-05-sources.md', 'qft-05-truth-validation.json', 'qft-05-validation.md', 'qft-06-12-command-log.md', 'qft-06-calibration.json', 'qft-06-command-log.md', 'qft-06-sources.md', 'qft-06-truth-validation.json', 'qft-06-validation.md', 'qft-07-calibration.json', 'qft-07-command-log.md', 'qft-07-sources.md', 'qft-07-truth-validation.json', 'qft-07-validation.md', 'qft-08-calibration.json', 'qft-08-command-log.md', 'qft-08-sources.md', 'qft-08-truth-validation.json', 'qft-08-validation.md', 'qft-09-calibration.json', 'qft-09-command-log.md', 'qft-09-sources.md', 'qft-09-truth-validation.json', 'qft-09-validation.md', 'qft-10-calibration.json', 'qft-10-command-log.md', 'qft-10-sources.md', 'qft-10-truth-validation.json', 'qft-10-validation.md', 'qft-11-calibration.json', 'qft-11-command-log.md', 'qft-11-sources.md', 'qft-11-truth-validation.json', 'qft-11-validation.md', 'qft-12-calibration.json', 'qft-12-command-log.md', 'qft-12-sources.md', 'qft-12-truth-validation.json', 'qft-12-validation.md', 'qft-13-19-command-log.md', 'qft-13-calibration.json', 'qft-13-command-log.md', 'qft-13-materials-and-fairness.md', 'qft-13-validation.md', 'qft-14-calibration.json', 'qft-14-command-log.md', 'qft-14-materials-and-fairness.md', 'qft-14-validation.md', 'qft-15-calibration.json', 'qft-15-command-log.md', 'qft-15-materials-and-fairness.md']
runs ['ed-01', 'ed-02', 'ed-03', 'ed-04', 'ed-05', 'gr-01', 'gr-02', 'gr-03', 'gr-04', 'gr-05', 'qft-01', 'qft-02', 'qft-03', 'qft-04', 'qft-05', 'qft-06', 'qft-07', 'qft-08', 'qft-09', 'qft-10', 'qft-11', 'qft-12', 'qft-13', 'qft-14', 'qft-15', 'qft-16', 'qft-17', 'qft-18', 'qft-19', 'qft-20', 'qft-21', 'qft-22', 'qft-23', 'qft-24', 'qft-25', 'qm-01', 'qm-02', 'qm-03', 'qm-04', 'qm-05', 'sp-01', 'sp-02', 'sp-03', 'sp-04', 'sp-05', 'tm-01', 'tm-02', 'tm-03', 'tm-04', 'tm-05']
tools ['__pycache__', 'author_gr03.py', 'author_gr04.py', 'author_gr05.py', 'author_qft13_19.py', 'author_qft20_25.py', 'author_qft_06_12.py', 'author_remaining_five.py', 'build_ed01_truth.py', 'build_ed02_truth.py', 'build_ed03_truth.py', 'build_ed04_truth.py', 'build_ed05_truth.py', 'build_gr01_truth.py', 'build_gr02_truth.py', 'build_gr03_truth.py', 'build_gr04_truth.py', 'build_gr05_truth.py', 'build_qft01_truth.py', 'build_qft02_truth.py', 'build_qft03_truth.py', 'build_qft04_truth.py', 'build_qft05_truth.py', 'build_qft20_25_truth.py', 'build_qft_06_12_truth.py', 'build_qm01_truth.py', 'build_qm02_truth.py', 'build_qm03_truth.py', 'build_qm04_truth.py', 'build_qm05_truth.py', 'build_sp01_truth.py', 'build_sp02_truth.py', 'build_sp03_truth.py', 'build_sp04_truth.py', 'build_sp05_truth.py', 'build_tm02_truth.py', 'build_tm03_truth.py', 'build_tm04_truth.py', 'build_tm05_truth.py', 'check_benchmark50.py', 'course', 'course_quality_score.py', 'document_qft20_25.py', 'enrich_remaining_five.py', 'explore_gr04.py', 'extract_qft_expansion_sources.py', 'finalize_qft20_25.py', 'finalize_qft_06_12.py', 'init_task_shell.py', 'integrate_benchmark50.py', 'ocr_pdf_pages.swift', 'qft20_25_reference.py', 'qm02_explore.py', 'qm02_write_package.py', 'qm03_author.py', 'read_qft_source_pages.py', 'recheck_course_score.py', 'render_qft_expansion_selection.py', 'run_ed01_checks.py', 'run_ed02_checks.py', 'run_ed03_checks.py', 'run_ed04_checks.py', 'run_ed05_checks.py', 'run_formal_benchmark50.py', 'run_gr01_checks.py', 'run_gr02_checks.py', 'run_gr03_checks.py', 'run_gr04_checks.py', 'run_gr05_checks.py', 'run_harbor_local_checks.py', 'run_logged.py', 'run_pending_harbor.py', 'run_qft01_checks.py', 'run_qft02_checks.py', 'run_qft03_checks.py', 'run_qft04_checks.py', 'run_qft13_19_checks.py', 'run_qft20_25_checks.py', 'run_qft_06_12_checks.py', 'run_qm01_checks.py', 'run_qm02_checks.py', 'run_qm03_checks.py', 'run_remaining_five_checks.py', 'run_sp01_checks.py', 'run_sp02_checks.py', 'run_sp03_checks.py', 'run_sp04_checks.py', 'run_sp05_checks.py', 'run_tm01_checks.py', 'run_tm02_checks.py', 'run_tm03_checks.py', 'task_status.py', 'test_formal_benchmark50.py', 'tm03_author.py', 'tm03_explore.py', 'write_qft13_19_status.py']
checks/benchmark-50-harbor-evidence.json 尚未生成
.gitignore 尚未生成
---
name: prevent-subject-agent-secret-leaks
description: Prevent and diagnose credential leakage across this research-agent repository, Git history, environment examples, Docker Compose, deployment transfer, browser bundles, API errors, logs, test artifacts, and AI observability. Use when adding provider keys, deploying, committing, rotating credentials, sharing logs, or investigating suspected exposure.
---

# Prevent Subject Agent Secret Leaks

Read [references/secret-lifecycle.md](references/secret-lifecycle.md) before rotating or responding to a real exposure.

## Workflow

1. Map secrets by provider, environment, consumer container, owner, rotation path, and allowed storage location.
2. Scan tracked files, staged changes, Git history, built frontend assets, Docker build context, reports, screenshots, and logs. Redact findings in all output.
3. Require examples to contain empty values or unmistakable placeholders. Never copy production values into tests.
4. Ensure deployment sync excludes local `.env` files and preserves the server-owned `deploy/.env.production` with mode 600.
5. Pass each secret explicitly only to the container that needs it. Do not use frontend build arguments, image layers, command-line echo, or public health responses.
6. Add a CI gate with Gitleaks or an equivalent deterministic scanner. Treat allowlists as reviewed exceptions, never as a way to silence unknown findings.
7. Scan production logs using match counts only; never print matching lines.
8. If exposure is confirmed, revoke first, issue a new credential, update source-controlled variable plumbing, recreate affected containers, verify, and document only fingerprints/timestamps.

## Rules

- Never expose a complete key, cookie, token, JWT secret, database URL, OAuth secret, HMAC user-isolation value, prompt, answer, or provider error body.
- Do not rewrite shared Git history without explicit coordination.
- Do not assume a historical credential is inactive; verify with the provider or rotate it.
- Do not store scanner reports containing secret material in Git.
- A secret present in `.env.production` but absent from Compose is a failed deployment, not a configured integration.

## Release gates

- Tracked and staged scans return zero unresolved secrets.
- Frontend assets contain no provider host/key/private model metadata beyond approved public labels.
- Container environment presence is checked as boolean/length only.
- Backend logs have zero matches for project key patterns, authorization headers, raw provider errors, prompt/answer fields, and pseudonymous provider user IDs.


exit_code=0
```

### 2026-11-16T22:53:16.090650+08:00

```bash
python3 -
```

```text

### 2026-11-16T22:53:16.090639+08:00

```bash
rg -n '^(from|import) |ROOT/|ROOT /|planning|source-notes|provenance|checks/' tools/run_ed01_checks.py tools/run_ed02_checks.py tools/run_ed03_checks.py tools/run_ed04_checks.py tools/run_ed05_checks.py tools/run_gr01_checks.py tools/run_gr02_checks.py tools/run_gr03_checks.py tools/run_gr04_checks.py tools/run_gr05_checks.py tools/run_harbor_local_checks.py tools/run_qft01_checks.py tools/run_qft02_checks.py tools/run_qft03_checks.py tools/run_qft04_checks.py tools/run_qft13_19_checks.py tools/run_qft20_25_checks.py tools/run_qft_06_12_checks.py tools/run_qm01_checks.py tools/run_qm02_checks.py tools/run_qm03_checks.py tools/run_remaining_five_checks.py tools/run_sp01_checks.py tools/run_sp02_checks.py tools/run_sp03_checks.py tools/run_sp04_checks.py tools/run_sp05_checks.py tools/run_tm01_checks.py tools/run_tm02_checks.py tools/run_tm03_checks.py tools/build_ed01_truth.py tools/build_ed02_truth.py tools/build_ed03_truth.py tools/build_ed04_truth.py tools/build_ed05_truth.py tools/build_gr01_truth.py tools/build_gr02_truth.py tools/build_gr03_truth.py tools/build_gr04_truth.py tools/build_gr05_truth.py tools/build_qft01_truth.py tools/build_qft02_truth.py tools/build_qft03_truth.py tools/build_qft04_truth.py tools/build_qft05_truth.py tools/build_qft20_25_truth.py tools/build_qft_06_12_truth.py tools/build_qm01_truth.py tools/build_qm02_truth.py tools/build_qm03_truth.py tools/build_qm04_truth.py tools/build_qm05_truth.py tools/build_sp01_truth.py tools/build_sp02_truth.py tools/build_sp03_truth.py tools/build_sp04_truth.py tools/build_sp05_truth.py tools/build_tm02_truth.py tools/build_tm03_truth.py tools/build_tm04_truth.py tools/build_tm05_truth.py
```

```text
tools/run_ed01_checks.py:2:import argparse
tools/run_ed01_checks.py:3:import importlib.util
tools/run_ed01_checks.py:4:import json
tools/run_ed01_checks.py:5:import os
tools/run_ed01_checks.py:6:import platform
tools/run_ed01_checks.py:7:import subprocess
tools/run_ed01_checks.py:8:import sys
tools/run_ed01_checks.py:9:import tempfile
tools/run_ed01_checks.py:10:import time
tools/run_ed01_checks.py:11:from pathlib import Path
tools/run_ed01_checks.py:14:TASK=ROOT/"tasks/ed-01"
tools/run_ed01_checks.py:79:    (ROOT/"checks/ed-01-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/run_ed01_checks.py:80:    outputroot=ROOT/"runs/ed-01/development-answers";outputroot.mkdir(parents=True,exist_ok=True)
tools/run_ed05_checks.py:2:import argparse
tools/run_ed05_checks.py:3:import importlib.util
tools/run_ed05_checks.py:4:import json
tools/run_ed05_checks.py:5:import os
tools/run_ed05_checks.py:6:from pathlib import Path
tools/run_ed05_checks.py:7:import platform
tools/run_ed05_checks.py:8:import subprocess
tools/run_ed05_checks.py:9:import sys
tools/run_ed05_checks.py:10:import tempfile
tools/run_ed05_checks.py:11:import time
tools/run_ed05_checks.py:14:TASK = ROOT / "tasks/ed-05"
tools/run_ed05_checks.py:87:        "course_quality_unmodified": (TESTS / "quality_score.py").read_bytes() == (ROOT / "tools/course_quality_score.py").read_bytes(),
tools/run_ed05_checks.py:98:    (ROOT / "checks/ed-05-calibration.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
tools/run_ed05_checks.py:99:    out = ROOT / "checks/ed-05-development-answers"
tools/run_gr04_checks.py:1:import argparse
tools/run_gr04_checks.py:2:import hashlib
tools/run_gr04_checks.py:3:import importlib.util
tools/run_gr04_checks.py:4:import json
tools/run_gr04_checks.py:5:import os
tools/run_gr04_checks.py:6:import platform
tools/run_gr04_checks.py:7:import subprocess
tools/run_gr04_checks.py:8:import sys
tools/run_gr04_checks.py:9:import tempfile
tools/run_gr04_checks.py:10:import time
tools/run_gr04_checks.py:11:from pathlib import Path
tools/run_gr04_checks.py:12:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/"tasks/gr-04";DATA=TASK/"environment/public";TESTS=TASK/"tests";sys.path.insert(0,str(TESTS))
tools/run_gr04_checks.py:36:    (ROOT/"checks/gr-04-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
tools/run_gr04_checks.py:37:    out=ROOT/"checks/gr-04-development-answers";out.mkdir(exist_ok=True)
tools/run_gr03_checks.py:1:import argparse
tools/run_gr03_checks.py:2:import hashlib
tools/run_gr03_checks.py:3:import importlib.util
tools/run_gr03_checks.py:4:import json
tools/run_gr03_checks.py:5:import os
tools/run_gr03_checks.py:6:import platform
tools/run_gr03_checks.py:7:import subprocess
tools/run_gr03_checks.py:8:import sys
tools/run_gr03_checks.py:9:import tempfile
tools/run_gr03_checks.py:10:import time
tools/run_gr03_checks.py:11:from pathlib import Path
tools/run_gr03_checks.py:12:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/"tasks/gr-03";DATA=TASK/"environment/public";TESTS=TASK/"tests";sys.path.insert(0,str(TESTS))
tools/run_gr03_checks.py:36:    (ROOT/"checks/gr-03-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
tools/run_gr03_checks.py:37:    out=ROOT/"checks/gr-03-development-answers";out.mkdir(exist_ok=True)
tools/run_ed03_checks.py:2:import argparse
tools/run_ed03_checks.py:3:import importlib.util
tools/run_ed03_checks.py:4:import json
tools/run_ed03_checks.py:5:import os
tools/run_ed03_checks.py:6:from pathlib import Path
tools/run_ed03_checks.py:7:import platform
tools/run_ed03_checks.py:8:import subprocess
tools/run_ed03_checks.py:9:import sys
tools/run_ed03_checks.py:10:import tempfile
tools/run_ed03_checks.py:11:import time
tools/run_ed03_checks.py:13:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/ed-03'
tools/run_ed03_checks.py:67:            'course_quality_unmodified':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
tools/run_ed03_checks.py:74:    (ROOT/'checks/ed-03-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
tools/run_ed03_checks.py:75:    out=ROOT/'checks/ed-03-development-answers';out.mkdir(parents=True,exist_ok=True)
tools/run_gr05_checks.py:1:import argparse,hashlib,importlib.util,json,os,platform,subprocess,sys,tempfile,time
tools/run_gr05_checks.py:2:from pathlib import Path
tools/run_gr05_checks.py:3:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/"tasks/gr-05";DATA=TASK/"environment/public";TESTS=TASK/"tests";sys.path.insert(0,str(TESTS))
tools/run_gr05_checks.py:32:    (ROOT/"checks/gr-05-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
tools/run_gr05_checks.py:33:    out=ROOT/"checks/gr-05-development-answers";out.mkdir(exist_ok=True)
tools/run_gr01_checks.py:2:import argparse
tools/run_gr01_checks.py:3:import hashlib
tools/run_gr01_checks.py:4:import importlib.util
tools/run_gr01_checks.py:5:import json
tools/run_gr01_checks.py:6:import os
tools/run_gr01_checks.py:7:import platform
tools/run_gr01_checks.py:8:import subprocess
tools/run_gr01_checks.py:9:import sys
tools/run_gr01_checks.py:10:import tempfile
tools/run_gr01_checks.py:11:import time
tools/run_gr01_checks.py:12:from pathlib import Path
tools/run_gr01_checks.py:14:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/"tasks/gr-01"
tools/run_gr01_checks.py:71:    (ROOT/"checks/gr-01-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/run_gr01_checks.py:72:    output=ROOT/"runs/gr-01/development-answers";output.mkdir(parents=True,exist_ok=True)
tools/run_gr02_checks.py:2:import argparse
tools/run_gr02_checks.py:3:import hashlib
tools/run_gr02_checks.py:4:import importlib.util
tools/run_gr02_checks.py:5:import json
tools/run_gr02_checks.py:6:import os
tools/run_gr02_checks.py:7:import platform
tools/run_gr02_checks.py:8:import subprocess
tools/run_gr02_checks.py:9:import sys
tools/run_gr02_checks.py:10:import tempfile
tools/run_gr02_checks.py:11:import time
tools/run_gr02_checks.py:12:from pathlib import Path
tools/run_gr02_checks.py:14:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/"tasks/gr-02";DATA=TASK/"environment/public";TESTS=TASK/"tests"
tools/run_gr02_checks.py:67:    (ROOT/"checks/gr-02-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/run_gr02_checks.py:68:    output=ROOT/"runs/gr-02/development-answers";output.mkdir(parents=True,exist_ok=True)
tools/run_ed04_checks.py:2:import argparse
tools/run_ed04_checks.py:3:import importlib.util
tools/run_ed04_checks.py:4:import json
tools/run_ed04_checks.py:5:import os
tools/run_ed04_checks.py:6:from pathlib import Path
tools/run_ed04_checks.py:7:import platform
tools/run_ed04_checks.py:8:import subprocess
tools/run_ed04_checks.py:9:import sys
tools/run_ed04_checks.py:10:import tempfile
tools/run_ed04_checks.py:11:import time
tools/run_ed04_checks.py:13:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/ed-04'
tools/run_ed04_checks.py:65:            'course_quality_unmodified':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
tools/run_ed04_checks.py:72:    (ROOT/'checks/ed-04-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
tools/run_ed04_checks.py:73:    out=ROOT/'checks/ed-04-development-answers';out.mkdir(parents=True,exist_ok=True)
tools/run_ed02_checks.py:2:import argparse
tools/run_ed02_checks.py:3:import importlib.util
tools/run_ed02_checks.py:4:import json
tools/run_ed02_checks.py:5:import os
tools/run_ed02_checks.py:6:from pathlib import Path
tools/run_ed02_checks.py:7:import platform
tools/run_ed02_checks.py:8:import subprocess
tools/run_ed02_checks.py:9:import sys
tools/run_ed02_checks.py:10:import tempfile
tools/run_ed02_checks.py:11:import time
tools/run_ed02_checks.py:14:TASK=ROOT/"tasks/ed-02"
tools/run_ed02_checks.py:70:            "course_quality_unmodified":(TESTS/"quality_score.py").read_bytes()==(ROOT/"tools/course_quality_score.py").read_bytes()}
tools/run_ed02_checks.py:77:    (ROOT/"checks/ed-02-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/run_ed02_checks.py:78:    out=ROOT/"checks/ed-02-development-answers";out.mkdir(parents=True,exist_ok=True)
tools/run_harbor_local_checks.py:4:import argparse
tools/run_harbor_local_checks.py:5:import datetime
tools/run_harbor_local_checks.py:6:import json
tools/run_harbor_local_checks.py:7:import platform
tools/run_harbor_local_checks.py:8:import re
tools/run_harbor_local_checks.py:9:import shlex
tools/run_harbor_local_checks.py:10:import shutil
tools/run_harbor_local_checks.py:11:import subprocess
tools/run_harbor_local_checks.py:12:import tempfile
tools/run_harbor_local_checks.py:13:from pathlib import Path
tools/run_harbor_local_checks.py:25:    source = ROOT / "tasks" / args.task_id
tools/run_harbor_local_checks.py:43:    destination = ROOT / "runs" / args.task_id / mode
tools/run_qft04_checks.py:2:import argparse
tools/run_qft04_checks.py:3:import importlib.util
tools/run_qft04_checks.py:4:import json
tools/run_qft04_checks.py:5:import os
tools/run_qft04_checks.py:6:from pathlib import Path
tools/run_qft04_checks.py:7:import platform
tools/run_qft04_checks.py:8:import subprocess
tools/run_qft04_checks.py:9:import sys
tools/run_qft04_checks.py:10:import tempfile
tools/run_qft04_checks.py:11:import time
tools/run_qft04_checks.py:13:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qft-04';DATA=TASK/'environment/public';TESTS=TASK/'tests'
tools/run_qft04_checks.py:66:        'course_quality_score_unchanged':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
tools/run_qft04_checks.py:74:    (ROOT/'checks/qft-04-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
tools/run_qft04_checks.py:75:    saved=ROOT/'runs/qft-04/development-answers';saved.mkdir(parents=True,exist_ok=True)
tools/run_qft_06_12_checks.py:2:import argparse
tools/run_qft_06_12_checks.py:3:import copy
tools/run_qft_06_12_checks.py:4:import importlib.util
tools/run_qft_06_12_checks.py:5:import json
tools/run_qft_06_12_checks.py:6:import math
tools/run_qft_06_12_checks.py:7:import os
tools/run_qft_06_12_checks.py:8:from pathlib import Path
tools/run_qft_06_12_checks.py:9:import platform
tools/run_qft_06_12_checks.py:10:import subprocess
tools/run_qft_06_12_checks.py:11:import sys
tools/run_qft_06_12_checks.py:12:import tempfile
tools/run_qft_06_12_checks.py:13:import time
tools/run_qft_06_12_checks.py:89:        task=ROOT/'tasks'/identifier;data=task/'environment/public';tests=task/'tests';private=tests/'private';model=json.loads((data/'model.json').read_text())
tools/run_qft_06_12_checks.py:139:            'course_quality_score_unchanged':(tests/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
tools/run_qft_06_12_checks.py:146:        saved=ROOT/'runs'/identifier/'development-answers';saved.mkdir(parents=True,exist_ok=True)
tools/run_qft_06_12_checks.py:149:        (ROOT/'checks'/f'{identifier}-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
tools/run_qft20_25_checks.py:2:import argparse,copy,hashlib,importlib.util,json,os,platform,subprocess,sys,tempfile,time
tools/run_qft20_25_checks.py:3:from pathlib import Path
tools/run_qft20_25_checks.py:4:import numpy as np
tools/run_qft20_25_checks.py:14:        task=ROOT/f'tasks/qft-{n}';data=task/'environment/public';tests=task/'tests';model=json.loads((data/'model.json').read_text());sys.path.insert(0,str(data));sys.path.insert(0,str(tests));sys.modules.pop('physics',None)
tools/run_qft20_25_checks.py:67:            'course_scorer_original':(tests/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
tools/run_qft20_25_checks.py:98:        (ROOT/f'checks/qft-{n}-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
tools/run_qft20_25_checks.py:103:        saved=ROOT/f'runs/qft-{n}/development-answers';saved.mkdir(parents=True,exist_ok=True)
tools/run_qft13_19_checks.py:2:import argparse
tools/run_qft13_19_checks.py:3:import copy
tools/run_qft13_19_checks.py:4:import hashlib
tools/run_qft13_19_checks.py:5:import importlib.util
tools/run_qft13_19_checks.py:6:import json
tools/run_qft13_19_checks.py:7:import os
tools/run_qft13_19_checks.py:8:from pathlib import Path
tools/run_qft13_19_checks.py:9:import platform
tools/run_qft13_19_checks.py:10:import subprocess
tools/run_qft13_19_checks.py:11:import sys
tools/run_qft13_19_checks.py:12:import tempfile
tools/run_qft13_19_checks.py:13:import time
tools/run_qft13_19_checks.py:16:sys.path.insert(0,str(ROOT/'tools'))
tools/run_qft13_19_checks.py:17:import author_qft13_19 as author
tools/run_qft13_19_checks.py:23:    ident=f'qft-{i:02d}';task=ROOT/'tasks'/ident;data=task/'environment/public';tests=task/'tests';model=json.loads((data/'model.json').read_text());ns={}
tools/run_qft13_19_checks.py:58:    checks={'linux_environment':platform.system()=='Linux','reference_matches_independent_truth':raw['reference']<metric['tolerance'],'reference_improves_baseline':raw['baseline']-raw['reference']>metric['tolerance'],'course_quality_unchanged':(tests/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
tools/run_qft13_19_checks.py:148:    (ROOT/'checks'/(ident+'-calibration.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
tools/run_qft13_19_checks.py:149:    saved=ROOT/'runs'/ident/'development-answers';saved.mkdir(parents=True,exist_ok=True)
tools/run_qm01_checks.py:4:import argparse
tools/run_qm01_checks.py:5:import copy
tools/run_qm01_checks.py:6:import importlib.util
tools/run_qm01_checks.py:7:import json
tools/run_qm01_checks.py:8:import os
tools/run_qm01_checks.py:9:import platform
tools/run_qm01_checks.py:10:import subprocess
tools/run_qm01_checks.py:11:import sys
tools/run_qm01_checks.py:12:import tempfile
tools/run_qm01_checks.py:13:import time
tools/run_qm01_checks.py:14:from pathlib import Path
tools/run_qm01_checks.py:17:TASK=ROOT/"tasks/qm-01"
tools/run_qm01_checks.py:71:    (ROOT/"checks/qm-01-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/run_qm01_checks.py:72:    saved=ROOT/"runs/qm-01/development-answers";saved.mkdir(parents=True,exist_ok=True)
tools/run_qft02_checks.py:2:import argparse
tools/run_qft02_checks.py:3:import importlib.util
tools/run_qft02_checks.py:4:import json
tools/run_qft02_checks.py:5:import os
tools/run_qft02_checks.py:6:from pathlib import Path
tools/run_qft02_checks.py:7:import platform
tools/run_qft02_checks.py:8:import subprocess
tools/run_qft02_checks.py:9:import sys
tools/run_qft02_checks.py:10:import tempfile
tools/run_qft02_checks.py:11:import time
tools/run_qft02_checks.py:14:TASK, DATA, TESTS = ROOT / 'tasks/qft-02', ROOT / 'tasks/qft-02/environment/public', ROOT / 'tasks/qft-02/tests'
tools/run_qft02_checks.py:65:        'course_quality_score_unchanged': (TESTS / 'quality_score.py').read_bytes() == (ROOT / 'tools/course_quality_score.py').read_bytes(),
tools/run_qft02_checks.py:73:    (ROOT / 'checks/qft-02-calibration.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
tools/run_qft02_checks.py:74:    saved = ROOT / 'runs/qft-02/development-answers'; saved.mkdir(parents=True, exist_ok=True)
tools/run_qm02_checks.py:2:import argparse
tools/run_qm02_checks.py:3:import importlib.util
tools/run_qm02_checks.py:4:import json
tools/run_qm02_checks.py:5:import os
tools/run_qm02_checks.py:6:from pathlib import Path
tools/run_qm02_checks.py:7:import platform
tools/run_qm02_checks.py:8:import subprocess
tools/run_qm02_checks.py:9:import sys
tools/run_qm02_checks.py:10:import tempfile
tools/run_qm02_checks.py:11:import time
tools/run_qm02_checks.py:13:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qm-02';DATA=TASK/'environment/public';TESTS=TASK/'tests'
tools/run_qm02_checks.py:51:        'course_score_exact':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
tools/run_qm02_checks.py:59:    (ROOT/'checks/qm-02-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
tools/run_qm02_checks.py:61:    saved=ROOT/'checks/qm-02-development-answers';saved.mkdir(exist_ok=True)
tools/run_qft03_checks.py:2:import argparse
tools/run_qft03_checks.py:3:import importlib.util
tools/run_qft03_checks.py:4:import json
tools/run_qft03_checks.py:5:import os
tools/run_qft03_checks.py:6:from pathlib import Path
tools/run_qft03_checks.py:7:import platform
tools/run_qft03_checks.py:8:import subprocess
tools/run_qft03_checks.py:9:import sys
tools/run_qft03_checks.py:10:import tempfile
tools/run_qft03_checks.py:11:import time
tools/run_qft03_checks.py:14:TASK = ROOT / 'tasks/qft-03'
tools/run_qft03_checks.py:92:            'course_quality_score_unchanged': (TESTS / 'quality_score.py').read_bytes() == (ROOT / 'tools/course_quality_score.py').read_bytes(),
tools/run_qft03_checks.py:103:        (ROOT / 'checks/qft-03-calibration.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
tools/run_qft03_checks.py:104:        saved = ROOT / 'runs/qft-03/development-answers'
tools/run_sp03_checks.py:2:import argparse
tools/run_sp03_checks.py:3:from copy import deepcopy
tools/run_sp03_checks.py:4:import importlib.util
tools/run_sp03_checks.py:5:import json
tools/run_sp03_checks.py:6:import os
tools/run_sp03_checks.py:7:from pathlib import Path
tools/run_sp03_checks.py:8:import platform
tools/run_sp03_checks.py:9:import subprocess
tools/run_sp03_checks.py:10:import sys
tools/run_sp03_checks.py:11:import tempfile
tools/run_sp03_checks.py:12:import time
tools/run_sp03_checks.py:14:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-03';DATA=TASK/'environment/public';TESTS=TASK/'tests';sys.path.insert(0,str(TESTS))
tools/run_sp03_checks.py:70:            'shell_cutoff_converged':maxcut<1e-12,'course_quality_unmodified':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
tools/run_sp03_checks.py:77:    (ROOT/'checks/sp-03-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');out=ROOT/'checks/sp-03-development-answers';out.mkdir(parents=True,exist_ok=True)
tools/run_qft01_checks.py:2:import argparse
tools/run_qft01_checks.py:3:import importlib.util
tools/run_qft01_checks.py:4:import json
tools/run_qft01_checks.py:5:import os
tools/run_qft01_checks.py:6:from pathlib import Path
tools/run_qft01_checks.py:7:import platform
tools/run_qft01_checks.py:8:import subprocess
tools/run_qft01_checks.py:9:import sys
tools/run_qft01_checks.py:10:import tempfile
tools/run_qft01_checks.py:11:import time
tools/run_qft01_checks.py:14:TASK=ROOT/"tasks/qft-01"
tools/run_qft01_checks.py:71:            "course_quality_unmodified":(TESTS/"quality_score.py").read_bytes()==(ROOT/"tools/course_quality_score.py").read_bytes()}
tools/run_qft01_checks.py:78:    (ROOT/"checks/qft-01-calibration.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/run_qft01_checks.py:79:    out=ROOT/"runs/qft-01/development-answers";out.mkdir(parents=True,exist_ok=True)
tools/run_qm03_checks.py:2:import argparse
tools/run_qm03_checks.py:3:import importlib.util
tools/run_qm03_checks.py:4:import json
tools/run_qm03_checks.py:5:import os
tools/run_qm03_checks.py:6:from pathlib import Path
tools/run_qm03_checks.py:7:import platform
tools/run_qm03_checks.py:8:import subprocess
tools/run_qm03_checks.py:9:import sys
tools/run_qm03_checks.py:10:import tempfile
tools/run_qm03_checks.py:11:import time
tools/run_qm03_checks.py:13:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qm-03';DATA=TASK/'environment/public';TESTS=TASK/'tests'
tools/run_qm03_checks.py:52:        'course_quality_score_unchanged':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
tools/run_qm03_checks.py:60:    (ROOT/'checks/qm-03-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');saved=ROOT/'checks/qm-03-development-answers';saved.mkdir(exist_ok=True)
tools/run_sp05_checks.py:2:import argparse
tools/run_sp05_checks.py:3:from copy import deepcopy
tools/run_sp05_checks.py:4:import importlib.util
tools/run_sp05_checks.py:5:import json
tools/run_sp05_checks.py:6:import os
tools/run_sp05_checks.py:7:from pathlib import Path
tools/run_sp05_checks.py:8:import platform
tools/run_sp05_checks.py:9:import subprocess
tools/run_sp05_checks.py:10:import sys
tools/run_sp05_checks.py:11:import tempfile
tools/run_sp05_checks.py:12:import time
tools/run_sp05_checks.py:14:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-05';DATA=TASK/'environment/public';TESTS=TASK/'tests';sys.path.insert(0,str(TESTS));sys.path.insert(0,str(DATA))
tools/run_sp05_checks.py:85:      'course_quality_unmodified':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
tools/run_sp05_checks.py:92:    (ROOT/'checks/sp-05-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');out=ROOT/'checks/sp-05-development-answers';out.mkdir(parents=True,exist_ok=True)
tools/run_tm01_checks.py:4:from __future__ import annotations
tools/run_tm01_checks.py:6:import importlib.util
tools/run_tm01_checks.py:7:import argparse
tools/run_tm01_checks.py:8:import json
tools/run_tm01_checks.py:9:import platform
tools/run_tm01_checks.py:10:import subprocess
tools/run_tm01_checks.py:11:import sys
tools/run_tm01_checks.py:12:import tempfile
tools/run_tm01_checks.py:13:import time
tools/run_tm01_checks.py:14:from pathlib import Path
tools/run_tm01_checks.py:18:TASK = ROOT / "tasks/tm-01"
tools/run_tm01_checks.py:23:CHECKS = ROOT / "checks"
tools/run_sp04_checks.py:2:import argparse
tools/run_sp04_checks.py:3:from copy import deepcopy
tools/run_sp04_checks.py:4:import importlib.util
tools/run_sp04_checks.py:5:import json
tools/run_sp04_checks.py:6:import os
tools/run_sp04_checks.py:7:from pathlib import Path
tools/run_sp04_checks.py:8:import platform
tools/run_sp04_checks.py:9:import subprocess
tools/run_sp04_checks.py:10:import sys
tools/run_sp04_checks.py:11:import tempfile
tools/run_sp04_checks.py:12:import time
tools/run_sp04_checks.py:14:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-04';DATA=TASK/'environment/public';TESTS=TASK/'tests';sys.path.insert(0,str(TESTS))
tools/run_sp04_checks.py:69:            'course_quality_unmodified':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
tools/run_sp04_checks.py:76:    (ROOT/'checks/sp-04-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');out=ROOT/'checks/sp-04-development-answers';out.mkdir(parents=True,exist_ok=True)
tools/run_tm02_checks.py:4:from __future__ import annotations
tools/run_tm02_checks.py:6:import argparse
tools/run_tm02_checks.py:7:import copy
tools/run_tm02_checks.py:8:import importlib.util
tools/run_tm02_checks.py:9:import json
tools/run_tm02_checks.py:10:import math
tools/run_tm02_checks.py:11:import os
tools/run_tm02_checks.py:12:import platform
tools/run_tm02_checks.py:13:import subprocess
tools/run_tm02_checks.py:14:import sys
tools/run_tm02_checks.py:15:import tempfile
tools/run_tm02_checks.py:16:import time
tools/run_tm02_checks.py:17:from pathlib import Path
tools/run_tm02_checks.py:20:TASK = ROOT / "tasks/tm-02"
tools/run_tm02_checks.py:109:    (ROOT / "checks/tm-02-calibration.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
tools/run_tm02_checks.py:110:    outputs = ROOT / "runs/tm-02/development-answers"
tools/run_tm03_checks.py:2:import argparse
tools/run_tm03_checks.py:3:import importlib.util
tools/run_tm03_checks.py:4:import json
tools/run_tm03_checks.py:5:import os
tools/run_tm03_checks.py:6:from pathlib import Path
tools/run_tm03_checks.py:7:import platform
tools/run_tm03_checks.py:8:import subprocess
tools/run_tm03_checks.py:9:import sys
tools/run_tm03_checks.py:10:import tempfile
tools/run_tm03_checks.py:11:import time
tools/run_tm03_checks.py:12:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/tm-03';DATA=TASK/'environment/public';TESTS=TASK/'tests';sys.path.insert(0,str(TESTS))
tools/run_tm03_checks.py:51:        'course_quality_score_unchanged':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
tools/run_tm03_checks.py:59:    (ROOT/'checks/tm-03-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');saved=ROOT/'checks/tm-03-development-answers';saved.mkdir(exist_ok=True)
tools/build_ed05_truth.py:2:import json
tools/build_ed05_truth.py:3:from pathlib import Path
tools/build_ed05_truth.py:4:import time
tools/build_ed05_truth.py:6:import mpmath as mp
tools/build_ed05_truth.py:9:TASK = ROOT / "tasks/ed-05"
tools/build_ed05_truth.py:150:    (ROOT / "checks/ed-05-truth-validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
tools/run_sp02_checks.py:2:import argparse
tools/run_sp02_checks.py:3:import importlib.util
tools/run_sp02_checks.py:4:import json
tools/run_sp02_checks.py:5:import os
tools/run_sp02_checks.py:6:from pathlib import Path
tools/run_sp02_checks.py:7:import platform
tools/run_sp02_checks.py:8:import subprocess
tools/run_sp02_checks.py:9:import sys
tools/run_sp02_checks.py:10:import tempfile
tools/run_sp02_checks.py:11:import time
tools/run_sp02_checks.py:13:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-02';DATA=TASK/'environment/public';TESTS=TASK/'tests';sys.path.insert(0,str(TESTS))
tools/run_sp02_checks.py:60:            'course_quality_unmodified':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
tools/run_sp02_checks.py:67:    (ROOT/'checks/sp-02-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');out=ROOT/'checks/sp-02-development-answers';out.mkdir(parents=True,exist_ok=True)
tools/run_sp01_checks.py:4:import argparse
tools/run_sp01_checks.py:5:import copy
tools/run_sp01_checks.py:6:import importlib.util
tools/run_sp01_checks.py:7:import json
tools/run_sp01_checks.py:8:import os
tools/run_sp01_checks.py:9:import platform
tools/run_sp01_checks.py:10:import subprocess
tools/run_sp01_checks.py:11:import sys
tools/run_sp01_checks.py:12:import tempfile
tools/run_sp01_checks.py:13:import time
tools/run_sp01_checks.py:14:from pathlib import Path
tools/run_sp01_checks.py:17:TASK = ROOT / "tasks/sp-01"
tools/run_sp01_checks.py:104:    (ROOT / "checks/sp-01-calibration.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
tools/run_sp01_checks.py:105:    outputs = ROOT / "runs/sp-01/development-answers"
tools/run_remaining_five_checks.py:2:import argparse
tools/run_remaining_five_checks.py:3:import copy
tools/run_remaining_five_checks.py:4:import importlib.util
tools/run_remaining_five_checks.py:5:import json
tools/run_remaining_five_checks.py:6:import os
tools/run_remaining_five_checks.py:7:from pathlib import Path
tools/run_remaining_five_checks.py:8:import platform
tools/run_remaining_five_checks.py:9:import subprocess
tools/run_remaining_five_checks.py:10:import sys
tools/run_remaining_five_checks.py:11:import tempfile
tools/run_remaining_five_checks.py:12:import time
tools/run_remaining_five_checks.py:21:    identifier=a.task_id;task=ROOT/'tasks'/identifier;data=task/'environment/public';tests=task/'tests'
tools/run_remaining_five_checks.py:69:        (ROOT/f'checks/{identifier}-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
tools/run_remaining_five_checks.py:74:        (ROOT/f'checks/{identifier}-validation.md').write_text(f'''# {identifier}开发验收
tools/build_gr02_truth.py:7:import argparse
tools/build_gr02_truth.py:8:import json
tools/build_gr02_truth.py:9:import platform
tools/build_gr02_truth.py:10:from pathlib import Path
tools/build_gr02_truth.py:11:import mpmath as mp
tools/build_gr02_truth.py:13:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/"tasks/gr-02"
tools/build_gr02_truth.py:88:    (ROOT/"checks/gr-02-observation-generation.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/build_gr02_truth.py:116:    (ROOT/"checks/gr-02-truth-validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print(json.dumps(report,ensure_ascii=False,indent=2))
tools/build_gr04_truth.py:2:import json
tools/build_gr04_truth.py:3:import platform
tools/build_gr04_truth.py:4:from pathlib import Path
tools/build_gr04_truth.py:5:import mpmath as mp
tools/build_gr04_truth.py:8:TASK=ROOT/"tasks/gr-04"
tools/build_gr04_truth.py:78:    (ROOT/"checks/gr-04-truth-validation.json").write_text(json.dumps(report,indent=2)+"\n")
tools/build_gr05_truth.py:2:import json,platform
tools/build_gr05_truth.py:3:from pathlib import Path
tools/build_gr05_truth.py:4:import mpmath as mp
tools/build_gr05_truth.py:5:ROOT=Path(__file__).resolve().parents[1];T=ROOT/"tasks/gr-05"
tools/build_gr05_truth.py:59:    (ROOT/"checks/gr-05-truth-validation.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps({k:v for k,v in report.items() if k not in ("records","summaries")},indent=2))
tools/build_qft_06_12_truth.py:2:import argparse
tools/build_qft_06_12_truth.py:3:import json
tools/build_qft_06_12_truth.py:4:import math
tools/build_qft_06_12_truth.py:5:from pathlib import Path
tools/build_qft_06_12_truth.py:6:import mpmath as mp
tools/build_qft_06_12_truth.py:7:import numpy as np
tools/build_qft_06_12_truth.py:8:from scipy.integrate import solve_ivp, quad
tools/build_qft_06_12_truth.py:203:        task=ROOT/'tasks'/identifier;model=json.loads((task/'environment/public/model.json').read_text())
tools/build_qft_06_12_truth.py:209:        (ROOT/'checks'/f'{identifier}-truth-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
tools/build_ed01_truth.py:3:import json
tools/build_ed01_truth.py:4:import platform
tools/build_ed01_truth.py:5:from decimal import Decimal, localcontext
tools/build_ed01_truth.py:6:from pathlib import Path
tools/build_ed01_truth.py:9:TASK=ROOT/"tasks/ed-01"
tools/build_ed01_truth.py:118:        (ROOT/"checks/ed-01-truth-validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/build_gr01_truth.py:5:import json
tools/build_gr01_truth.py:6:import platform
tools/build_gr01_truth.py:7:from pathlib import Path
tools/build_gr01_truth.py:8:import mpmath as mp
tools/build_gr01_truth.py:11:TASK=ROOT/"tasks/gr-01"
tools/build_gr01_truth.py:76:    (ROOT/"checks/gr-01-truth-validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/build_qft05_truth.py:2:import mpmath as mp
tools/build_qft05_truth.py:35:    (root/'checks/qft-05-truth-validation.json').write_text(json.dumps({'method':'参考解三角域变换为嵌套双积分；真值解析积掉一个参数后55位单积分和高精度微分。','cases':checks},ensure_ascii=False,indent=2)+'\n');print(json.dumps(checks,ensure_ascii=False,indent=2))
tools/build_gr03_truth.py:2:import argparse
tools/build_gr03_truth.py:3:import json
tools/build_gr03_truth.py:4:import platform
tools/build_gr03_truth.py:5:from pathlib import Path
tools/build_gr03_truth.py:6:import mpmath as mp
tools/build_gr03_truth.py:7:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/"tasks/gr-03"
tools/build_gr03_truth.py:19:            (ROOT/"checks/gr-03-observation-generation.json").write_text(json.dumps({"kind":"deterministic synthetic circular-orbit measurements, not telescope observations","mass":float(mass),"offset":float(offset),"rounding":"14 significant digits","truth":"least-squares fit of rounded public observations, not generating constants"},indent=2)+"\n")
tools/build_gr03_truth.py:45:    (ROOT/"checks/gr-03-truth-validation.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))
tools/build_qm03_truth.py:6:import json
tools/build_qm03_truth.py:7:from pathlib import Path
tools/build_qm03_truth.py:8:import time
tools/build_qm03_truth.py:9:import mpmath as mp
tools/build_qm03_truth.py:11:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qm-03'
tools/build_qm03_truth.py:97:    (ROOT/'checks/qm-03-truth-validation.json').write_text(json.dumps({'precision_decimal_digits':60,'reference_core_imported':False,'elapsed_seconds':time.perf_counter()-started,'cases':reports},indent=2)+'\n')
tools/build_qft01_truth.py:5:import json
tools/build_qft01_truth.py:6:from pathlib import Path
tools/build_qft01_truth.py:7:import time
tools/build_qft01_truth.py:8:import mpmath as mp
tools/build_qft01_truth.py:11:TASK=ROOT/"tasks/qft-01"
tools/build_qft01_truth.py:110:    (ROOT/"checks/qft-01-truth-validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/build_qft20_25_truth.py:2:import itertools,json,math,time
tools/build_qft20_25_truth.py:3:from pathlib import Path
tools/build_qft20_25_truth.py:4:import mpmath as mp
tools/build_qft20_25_truth.py:5:import numpy as np
tools/build_qft20_25_truth.py:6:from scipy.integrate import quad,solve_ivp
tools/build_qft20_25_truth.py:7:from scipy.linalg import solve
tools/build_qft20_25_truth.py:8:from scipy.optimize import brentq,minimize
tools/build_qft20_25_truth.py:172:        task=ROOT/f'tasks/qft-{n}';model=json.loads((task/'environment/public/model.json').read_text());secret=json.loads((task/'tests/private/generation.json').read_text());start=time.perf_counter();rows,check=globals()[f'truth{n}'](model,secret)
tools/build_qft20_25_truth.py:173:        (task/'tests/private/truth.json').write_text(json.dumps({'results':rows},ensure_ascii=False,indent=2)+'\n');check['generation_seconds']=time.perf_counter()-start;(ROOT/f'checks/qft-{n}-truth-validation.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'task':n,**check},ensure_ascii=False),flush=True)
tools/build_ed03_truth.py:2:import json
tools/build_ed03_truth.py:3:from pathlib import Path
tools/build_ed03_truth.py:4:import time
tools/build_ed03_truth.py:5:import mpmath as mp
tools/build_ed03_truth.py:7:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/ed-03'
tools/build_ed03_truth.py:68:    (ROOT/'checks/ed-03-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
tools/build_ed02_truth.py:6:import json
tools/build_ed02_truth.py:7:from pathlib import Path
tools/build_ed02_truth.py:8:import time
tools/build_ed02_truth.py:9:import mpmath as mp
tools/build_ed02_truth.py:12:TASK=ROOT/"tasks/ed-02"
tools/build_ed02_truth.py:91:    (ROOT/"checks/ed-02-truth-validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tools/build_tm04_truth.py:2:import numpy as np
tools/build_tm04_truth.py:26:    (root/'checks/tm-04-truth-validation.json').write_text(json.dumps({'method':'参考解自适应DOP853；真值独立固定步RK4、步长加倍及Richardson外推，另验能量和角动量模长。','cases':checks},ensure_ascii=False,indent=2)+'\n');print(json.dumps(checks,ensure_ascii=False,indent=2))
tools/build_qm01_truth.py:3:import json
tools/build_qm01_truth.py:4:from pathlib import Path
tools/build_qm01_truth.py:5:import mpmath as mp
tools/build_qm01_truth.py:8:TASK = ROOT/"tasks/qm-01"
tools/build_qm01_truth.py:51:    (ROOT/"checks/qm-01-truth-validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
tools/build_qm04_truth.py:2:import numpy as np
tools/build_qm04_truth.py:3:from scipy.integrate import solve_ivp
tools/build_qm04_truth.py:27:    (root/'checks/qm-04-truth-validation.json').write_text(json.dumps({'method':'参考解旋转框架解析SU(2)及Fréchet导数；私有真值独立积分实验室系Schrodinger方程和参数灵敏度ODE。','cases':checks},ensure_ascii=False,indent=2)+'\n');print(json.dumps(checks,ensure_ascii=False,indent=2))
tools/build_qm02_truth.py:6:import json
tools/build_qm02_truth.py:7:from pathlib import Path
tools/build_qm02_truth.py:8:import time
tools/build_qm02_truth.py:9:import mpmath as mp
tools/build_qm02_truth.py:11:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qm-02'
tools/build_qm02_truth.py:90:    (ROOT/'checks/qm-02-truth-validation.json').write_text(json.dumps(report,indent=2)+'\n')
tools/build_sp05_truth.py:2:import json
tools/build_sp05_truth.py:3:from pathlib import Path
tools/build_sp05_truth.py:4:import time
tools/build_sp05_truth.py:5:import mpmath as mp
tools/build_sp05_truth.py:7:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-05'
tools/build_sp05_truth.py:64:    (ROOT/'checks/sp-05-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
tools/build_sp03_truth.py:2:import json
tools/build_sp03_truth.py:3:from pathlib import Path
tools/build_sp03_truth.py:4:import time
tools/build_sp03_truth.py:5:import mpmath as mp
tools/build_sp03_truth.py:7:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-03'
tools/build_sp03_truth.py:79:    (ROOT/'checks/sp-03-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
tools/build_ed04_truth.py:2:import json
tools/build_ed04_truth.py:3:from pathlib import Path
tools/build_ed04_truth.py:4:import time
tools/build_ed04_truth.py:5:import mpmath as mp
tools/build_ed04_truth.py:7:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/ed-04'
tools/build_ed04_truth.py:49:    (ROOT/'checks/ed-04-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
tools/build_tm05_truth.py:2:import numpy as np
tools/build_tm05_truth.py:3:from scipy.integrate import quad,solve_ivp
tools/build_tm05_truth.py:30:    (root/'checks/tm-05-truth-validation.json').write_text(json.dumps({'method':'参考解椭圆积分阻力+log(s)独立变量；真值直接接触角积分+时间域v/s ODE，并独立核对耗散与机械能差。','cases':checks},ensure_ascii=False,indent=2)+'\n');print(json.dumps(checks,ensure_ascii=False,indent=2))
tools/build_sp04_truth.py:2:import json
tools/build_sp04_truth.py:3:from pathlib import Path
tools/build_sp04_truth.py:4:import time
tools/build_sp04_truth.py:5:import mpmath as mp
tools/build_sp04_truth.py:7:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-04'
tools/build_sp04_truth.py:66:    (ROOT/'checks/sp-04-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
tools/build_tm02_truth.py:4:import json
tools/build_tm02_truth.py:5:import math
tools/build_tm02_truth.py:6:import platform
tools/build_tm02_truth.py:7:from pathlib import Path
tools/build_tm02_truth.py:9:import numpy as np
tools/build_tm02_truth.py:10:import scipy
tools/build_tm02_truth.py:11:from scipy.integrate import solve_ivp
tools/build_tm02_truth.py:12:from scipy.optimize import brentq
tools/build_tm02_truth.py:15:TASK = ROOT / "tasks/tm-02"
tools/build_tm02_truth.py:67:    (ROOT / "checks/tm-02-truth-validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
tools/build_qft02_truth.py:2:import json
tools/build_qft02_truth.py:3:from pathlib import Path
tools/build_qft02_truth.py:4:import time
tools/build_qft02_truth.py:5:import mpmath as mp
tools/build_qft02_truth.py:8:TASK = ROOT / 'tasks/qft-02'
tools/build_qft02_truth.py:88:    (ROOT/'checks/qft-02-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
tools/build_qm05_truth.py:2:import numpy as np
tools/build_qm05_truth.py:3:from scipy.sparse import diags
tools/build_qm05_truth.py:4:from scipy.sparse.linalg import eigsh
tools/build_qm05_truth.py:29:    (root/'checks/qm-05-truth-validation.json').write_text(json.dumps({'method':'参考解180维优化振子Rayleigh–Ritz；真值为独立实空间8阶差分，2200/3000网格收敛互查。','cases':checks},ensure_ascii=False,indent=2)+'\n');print(json.dumps(checks,ensure_ascii=False,indent=2))
tools/build_qft03_truth.py:2:import json
tools/build_qft03_truth.py:3:from pathlib import Path
tools/build_qft03_truth.py:4:import mpmath as mp
tools/build_qft03_truth.py:6:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qft-03'
tools/build_qft03_truth.py:87:    (ROOT/'checks/qft-03-truth-validation.json').write_text(json.dumps({'precision_digits':70,'method':'independent RREF rank/nullspace and high-precision normal equations for rounded public observations','cases':details},ensure_ascii=False,indent=2)+'\n')
tools/build_sp01_truth.py:3:import json
tools/build_sp01_truth.py:4:import platform
tools/build_sp01_truth.py:5:from pathlib import Path
tools/build_sp01_truth.py:6:import mpmath as mp
tools/build_sp01_truth.py:9:TASK = ROOT/"tasks/sp-01"
tools/build_sp01_truth.py:52:    (ROOT/"checks/sp-01-truth-validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
tools/build_sp02_truth.py:2:import json
tools/build_sp02_truth.py:3:from pathlib import Path
tools/build_sp02_truth.py:4:import time
tools/build_sp02_truth.py:5:import mpmath as mp
tools/build_sp02_truth.py:7:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/"tasks/sp-02"
tools/build_sp02_truth.py:82:    (ROOT/"checks/sp-02-truth-validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print(json.dumps(report,ensure_ascii=False,indent=2))
tools/build_tm03_truth.py:5:import json
tools/build_tm03_truth.py:6:from pathlib import Path
tools/build_tm03_truth.py:7:import time
tools/build_tm03_truth.py:8:import mpmath as mp
tools/build_tm03_truth.py:10:ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/tm-03';mp.mp.dps=65
tools/build_tm03_truth.py:98:    (ROOT/'checks/tm-03-truth-validation.json').write_text(json.dumps({'precision_decimal_digits':65,'reference_core_imported':False,'elapsed_seconds':time.perf_counter()-started,'trajectories':reports},indent=2)+'\n')
tools/build_qft04_truth.py:2:import json
tools/build_qft04_truth.py:3:from pathlib import Path
tools/build_qft04_truth.py:4:import mpmath as mp
tools/build_qft04_truth.py:7:TASK=ROOT/'tasks/qft-04'
tools/build_qft04_truth.py:151:    (ROOT/'checks/qft-04-truth-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')

exit_code=0
```

===== tools/run_qft13_19_checks.py =====
"""Linux physical calibration and verifier checks, qft-13 through qft-19."""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import author_qft13_19 as author

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def check_one(i,calibrate):
    ident=f'qft-{i:02d}';task=ROOT/'tasks'/ident;data=task/'environment/public';tests=task/'tests';model=json.loads((data/'model.json').read_text());ns={}
    exec(author.source_for(i,True),ns)
    start=time.perf_counter();truth=ns['truth'](model);truth_seconds=time.perf_counter()-start
    answers={};runtime={}
    for key,base in [('reference',False),('baseline',True)]:
        start=time.perf_counter();answers[key]=ns['solve'](model,base);runtime[key+'_seconds']=time.perf_counter()-start
    schema={'records':[],'metric':'100 times mean bounded normalized field error','version':1}
    for r in truth['records']:
        opts=[]
        for lab in r['labels']:
            choices=next((g for g in [['stable','unstable'],['zero','nonzero'],['singlet','color_conserved_three_line'],['finite_action','invalid_asymptotic'],['selfdual','not_selfdual'],['rational_nonzero','rational_zero'],['four_dimensional_cuts_incomplete','four_dimensional_cuts_complete']] if lab in g),[lab])
            opts.append(choices)
        floors=[1e-6]*len(r['values'])
        if i==13 and r['id'].startswith('quartic'):
            floors=[1e-7]*8+[1e-5]+[1e-8]*4
        schema['records'].append({'id':r['id'],'length':len(r['values']),'label_options':opts,'scale_floor':floors})
    if calibrate:
        (tests/'private/truth.json').write_text(json.dumps(truth,ensure_ascii=False,indent=2)+'\n');(data/'schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n')
    else:
        old=json.loads((tests/'private/truth.json').read_text())
        if old!=truth:raise RuntimeError(ident+' truth changed on rerun')
    sys.path.insert(0,str(tests));score=load(ident.replace('-','')+'_score',tests/'score.py');quality=load(ident.replace('-','')+'_quality',tests/'quality_score.py')
    raw={}
    for key,a in answers.items():raw[key],_=score.evaluate(a,data,tests/'private')
    metric={'kind':'continuous','metric_name':author.TASKS[i]['title']+'：归一化误差','unit':'百分点','direction':'minimize','baseline':raw['baseline'],'reference':raw['reference'],'tolerance':2e-5}
    if not calibrate:metric=json.loads((tests/'metric.json').read_text())
    quality.validate_metric(metric)
    print(ident, 'raw/reference/baseline', raw, 'runtime',runtime,'truth_s',truth_seconds,flush=True)
    diffs=[]
    for r,t in zip(answers['reference']['records'],truth['records']):
        if len(r['values'])!=len(t['values']):raise RuntimeError('shape mismatch')
        for k,(x,y) in enumerate(zip(r['values'],t['values'])):
            er=abs(x-y)/max(1e-6,abs(y))
            if er>2e-6:diffs.append({'id':r['id'],'field':k,'reference':x,'truth':y,'relative':er})
        if r['labels']!=t['labels']:diffs.append({'id':r['id'],'reference_labels':r['labels'],'truth_labels':t['labels']})
    checks={'linux_environment':platform.system()=='Linux','reference_matches_independent_truth':raw['reference']<metric['tolerance'],'reference_improves_baseline':raw['baseline']-raw['reference']>metric['tolerance'],'course_quality_unchanged':(tests/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
    if diffs:print(json.dumps(diffs,ensure_ascii=False,indent=2),flush=True)
    if calibrate:
        for path in (data/'metric.json',tests/'metric.json'):path.write_text(json.dumps(metric,ensure_ascii=False,indent=2)+'\n')
    elif any(abs(raw[k]-metric[k])>metric['tolerance'] for k in ('baseline','reference')):checks['registered_endpoints_match']=False
    else:checks['registered_endpoints_match']=True
    answers['independent_truth']=truth
    answers['reordered']=copy.deepcopy(answers['reference']);answers['reordered']['records'].reverse()
    for key in ('boolean','nan','huge_integer','duplicate','missing','malformed','wrong_values','wrong_labels'):
        a=copy.deepcopy(answers['reference'])
        if key=='boolean':a['records'][0]['values'][0]=True
        if key=='nan':a['records'][0]['values'][0]=float('nan')
        if key=='huge_integer':a['records'][0]['values'][0]=10**400
        if key=='duplicate':a['records'][-1]=copy.deepcopy(a['records'][0])
        if key=='missing':a['records'][0]['values'].pop()
        if key=='malformed':a={'records':'wrong'}
        if key=='wrong_values':
            for r in a['records']:r['values']=[0.]*len(r['values'])
        if key=='wrong_labels':
            for r,decl in zip(a['records'],schema['records']):
                for k,options in enumerate(decl['label_options']):r['labels'][k]=next(x for x in options if x!=r['labels'][k])
        answers[key]=a
    cases={}
    for key,a in answers.items():
        r,d=score.evaluate(a,data,tests/'private');status='invalid' if r is None else 'completed';cases[key]={'raw_metric':r,'status':status,'score':quality.quality_score(metric,r,status)}
    checks.update(baseline_zero_reference_one=cases['baseline']['score']==0 and cases['reference']['score']==1,independent_truth_full_credit=cases['independent_truth']['score']>1-1e-6,reordered_same_score=cases['reordered']['raw_metric']==cases['reference']['raw_metric'],invalid_rejected=all(cases[n]['status']=='invalid' and cases[n]['score']==0 for n in ('boolean','nan','huge_integer','duplicate','missing','malformed')),wrong_values_penalized=cases['wrong_values']['raw_metric']>raw['reference']+.1)
    if any(r['labels'] for r in truth['records']):checks['wrong_labels_penalized']=cases['wrong_labels']['raw_metric']>raw['reference']+.1
    entries={}
    with tempfile.TemporaryDirectory(prefix=ident+'-') as temp:
        temp=Path(temp)
        for key in ('reference','baseline','missing','huge_integer'):
            p=temp/(key+'.json');p.write_text(json.dumps(answers[key]));logs=temp/('logs-'+key)
            env=dict(os.environ,TASK_DATA_ROOT=str(data),TASK_PRIVATE_ROOT=str(tests/'private'),TASK_TESTS_ROOT=str(tests),TASK_ANSWER_PATH=str(p),VERIFIER_LOG_ROOT=str(logs))
            subprocess.run(['bash',str(tests/'test.sh')],check=True,env=env,capture_output=True,text=True);entries[key]=json.loads((logs/'metrics.json').read_text())
        ref=temp/'reference.json'
        feedback=json.loads(subprocess.run([sys.executable,str(data/'feedback.py'),str(ref)],check=True,capture_output=True,text=True).stdout)
        checks['feedback_accepts_reference']=feedback['valid'];checks['verifier_entrypoint']=entries['reference']['score']==1 and entries['baseline']['score']==0 and entries['missing']['status']=='invalid' and entries['huge_integer']['status']=='invalid'
        explorer=json.loads(subprocess.run([sys.executable,str(data/'explore.py'),str(ref)],check=True,capture_output=True,text=True).stdout)
        checks['public_physical_explorer_runs']=bool(explorer['records']) and all('constraints' in r for r in explorer['records'])
        # Exercise the installed reference command and baseline CLI independently of in-process execution.
        for base,script in [(False,'solve.py'),(True,'baseline.py')]:
            p=temp/(script+'.json');subprocess.run([sys.executable,str(task/'solution'/script),'--data-root',str(data),'--output',str(p)],check=True,capture_output=True,text=True);got=json.loads(p.read_text());r,_=score.evaluate(got,data,tests/'private');checks[script+'_cli']=abs(r-raw['baseline' if base else 'reference'])<metric['tolerance']
    if i==18:
        import numpy as np
        checks['on_shell_momentum_conservation']=all(np.linalg.norm(sum(np.outer(ns['matrix'](c['lambda'])[j],ns['matrix'](c['tilde'])[j]) for j in range(6)))<1e-12 for c in model['cases'])
        checks['little_group_covariance']=all(abs(complex(*r['values'][:2])-complex(*r['values'][8:10]))<1e-8*max(1,abs(complex(*r['values'][:2]))) for r in answers['reference']['records'])
        br=ns['br'];soft_ratios=[];residues=[]
        for c,r in zip(model['cases'],answers['reference']['records']):
            la=ns['matrix'](c['lambda']);ti=ns['matrix'](c['tilde']);amp=complex(*r['values'][:2])
            if c.get('family')=='soft_positive6':
                five=br(ti[3],ti[4])**4/np.prod([br(ti[k],ti[(k+1)%5]) for k in range(5)])
                soft=br(la[4],la[0])/(br(la[4],la[5])*br(la[5],la[0]));soft_ratios.append(amp/(soft*five))
            if c.get('family')=='factorization234':
                inv=np.linalg.det(sum(np.outer(la[j],ti[j]) for j in (1,2,3)));residues.append(inv*amp)
        print('soft ratios',soft_ratios,'s234 residues',residues,flush=True)
        checks['soft_limit_converges']=abs(soft_ratios

===== tools/run_tm01_checks.py =====
#!/usr/bin/env python3
"""Calibrate tm-01 and exercise its verifier against required answer classes."""

from __future__ import annotations

import importlib.util
import argparse
import json
import platform
import subprocess
import sys
import tempfile
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TASK = ROOT / "tasks/tm-01"
DATA = TASK / "environment/public"
PRIVATE = TASK / "tests/private"
SOLUTION = TASK / "solution"
TESTS = TASK / "tests"
CHECKS = ROOT / "checks"
sys.path.insert(0, str(TESTS))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def run_solver(script: Path, output: Path) -> tuple[dict, float]:
    started = time.perf_counter()
    subprocess.run(
        [sys.executable, str(script), "--data-root", str(DATA), "--output", str(output)],
        check=True,
    )
    return json.loads(output.read_text(encoding="utf-8")), time.perf_counter() - started


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--calibrate", action="store_true", help="Update both metric copies only after every check passes")
    args = parser.parse_args()
    score_module = load_module("tm01_score", TESTS / "score.py")
    with tempfile.TemporaryDirectory(prefix="theory-physics-tm01-check-") as temp_dir:
        temp = Path(temp_dir)
        baseline, baseline_seconds = run_solver(SOLUTION / "baseline.py", temp / "baseline.json")
        reference, reference_seconds = run_solver(SOLUTION / "solve.py", temp / "reference.json")

        baseline_raw, baseline_metrics = score_module.evaluate(baseline, DATA, PRIVATE)
        reference_raw, reference_metrics = score_module.evaluate(reference, DATA, PRIVATE)

        model = json.loads((DATA / "model.json").read_text(encoding="utf-8"))
        nominal = model["nominal_stiffness_n_per_m"]
        wrong_stiffness = list(nominal)
        wrong_stiffness[1] *= 0.5
        wrong_stiffness[6] *= 0.6
        wrong = {
            "stiffness_n_per_m": wrong_stiffness,
            "softened_springs": [2, 7],
            "method": "valid but deliberately wrong damage-pair assignment",
        }
        wrong_raw, wrong_metrics = score_module.evaluate(wrong, DATA, PRIVATE)

        alternative = dict(reference)
        alternative["softened_springs"] = list(reversed(reference["softened_springs"]))
        alternative_raw, alternative_metrics = score_module.evaluate(alternative, DATA, PRIVATE)
        malformed_raw, malformed_metrics = score_module.evaluate({"stiffness_n_per_m": []}, DATA, PRIVATE)
        inconsistent = dict(reference)
        inconsistent["softened_springs"] = [2, 7]
        inconsistent_raw, inconsistent_metrics = score_module.evaluate(inconsistent, DATA, PRIVATE)

    measured_metric = {
        "kind": "continuous",
        "metric_name": "综合识别误差",
        "unit": "百分点",
        "direction": "minimize",
        "baseline": baseline_raw,
        "reference": reference_raw,
        "tolerance": 0.01,
    }
    quality_score = load_module("tm01_quality_score", TESTS / "quality_score.py")
    metric = measured_metric if args.calibrate else json.loads((TESTS / "metric.json").read_text(encoding="utf-8"))
    quality_score.validate_metric(metric)
    def case(raw, details, answer=None):
        status = "invalid" if raw is None else "completed"
        result = {"raw_metric": raw, **details, "status": status,
                  "score": quality_score.quality_score(metric, raw, status)}
        if answer is not None:
            result["answer"] = answer
        return result

    cases = {
        "baseline": case(baseline_raw, baseline_metrics, baseline),
        "reference": case(reference_raw, reference_metrics, reference),
        "substantively_wrong_valid_answer": case(wrong_raw, wrong_metrics, wrong),
        "malformed_answer": case(malformed_raw, malformed_metrics),
        "inconsistent_location_label": case(inconsistent_raw, inconsistent_metrics),
        "legal_equivalent_order": case(alternative_raw, alternative_metrics),
    }

    checks = {
        "reference_improves_over_baseline": reference_raw is not None and baseline_raw is not None and baseline_raw - reference_raw > metric["tolerance"],
        "reference_is_valid_and_exactly_two_softened": reference_raw is not None and len(reference["softened_springs"]) == 2,
        "wrong_answer_is_valid_but_penalized": wrong_raw is not None and wrong_metrics["location_f1"] == 0.0 and wrong_raw >= 10.0,
        "malformed_answer_is_invalid": malformed_raw is None,
        "inconsistent_location_label_is_invalid": inconsistent_raw is None,
        "equivalent_location_order_scores_identically": alternative_raw == reference_raw,
        "measured_baseline_matches_metric": abs(baseline_raw - metric["baseline"]) <= metric["tolerance"],
        "measured_reference_matches_metric": abs(reference_raw - metric["reference"]) <= metric["tolerance"],
        "baseline_quality_is_zero": abs(cases["baseline"]["score"]) < 1e-8,
        "reference_and_equivalent_quality_are_one": all(abs(cases[name]["score"] - 1.0) < 1e-8 for name in ("reference", "legal_equivalent_order")),
        "wrong_and_invalid_quality_are_zero": all(cases[name]["score"] == 0.0 for name in ("substantively_wrong_valid_answer", "malformed_answer", "inconsistent_location_label")),
    }
    report = {
        **cases,
        "metric": metric,
        "measured_metric": measured_metric,
        "runtime": {"platform": platform.platform(), "python": platform.python_version(),
                    "numpy": score_module.np.__version__, "baseline_seconds": baseline_seconds,
                    "reference_seconds": reference_seconds},
        "checks": checks,
    }
    CHECKS.mkdir(parents=True, exist_ok=True)
    (CHECKS / "tm-01-calibration.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not all(checks.values()):
        raise SystemExit("one or more tm-01 checks failed")
    if args.calibrate:
        for path in (TESTS / "metric.json", DATA / "metric.json"):
            path.write_text(json.dumps(metric, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    elif json.loads((DATA / "metric.json").read_text(encoding="utf-8")) != metric:
        raise SystemExit("public and verifier metric copies differ")


if __name__ == "__main__":
    main()


===== tools/build_qft20_25_truth.py =====
"""Independent physical truth, without importing any task solution."""
import itertools,json,math,time
from pathlib import Path
import mpmath as mp
import numpy as np
from scipy.integrate import quad,solve_ivp
from scipy.linalg import solve
from scipy.optimize import brentq,minimize
ROOT=Path(__file__).resolve().parents[1]


def truth20(m,secret):
    mp.mp.dps=45;out=[];check={}
    for fam,params in zip(m['families'],secret):
        r,b,g=map(lambda x:mp.mpf(str(params[x])),('rho','b','gap'));sig=mp.pi*r if g==0 else mp.mpf(0)
        divergent=any(s['zero_modes']>0 for s in fam['spectra'])
        out.append({'id':fam['id']+'-inference','values':list(map(float,[r,b,g,sig,not divergent,divergent]))})
        for sp in fam['spectra']:
            edge=mp.mpf(str(sp['edge']));V=sp['V'];lv=list(map(lambda x:mp.mpf(str(x)),sp['positive_eigenvalues']))
            for mass in fam['masses']:
                mm=mp.mpf(str(mass));tail=2*mm*mp.mpf(str(fam['uv_density_coefficient']))*mp.quad(lambda x:1/((1+x*x)*(x*x+mm*mm)),[edge,mp.inf])
                paired=2*mm*mp.fsum(1/(x*x+mm*mm) for x in lv)/V+tail;zero=mp.mpf(sp['zero_modes'])/(mm*V)
                dtheta=mp.atan(edge/mm)-mp.atan(g/mm)
                cont=2*mm*r*((1+b*(g*g-mm*mm))*dtheta/mm+b*(edge-g)-b*g*mp.log((edge*edge+mm*mm)/(g*g+mm*mm)))+tail
                integral=2*mm*mp.quad(lambda x:r*(1+b*(x-g)**2)/(x*x+mm*mm),[g,edge])+tail
                check[f"{fam['id']}-{V}-{mass}"]=float(abs(cont-integral))
                corr=paired-cont;bound=abs(corr)+zero+abs(cont-sig)
                out.append({'id':f"{fam['id']}-V{V}-m{mass:g}",'values':list(map(float,[paired+zero,zero,corr,cont,bound,bound<=fam['window_target']]))})
    assert max(check.values())<1e-35
    return out,{'analytic_primitive_vs_45_digit_quad_max':max(check.values()),'paired_spectrum':'full +/- pairs plus explicit exact zero modes','density_normalization':'per unit four-volume, each signed branch density rho'}


def truth21(m,secret):
    out=[];residual=[];net=[]
    for c in m['cases']:
        rr=[]
        for a in c['a']:
            # z=e^{iq}: sin q + a sin 2q = (z^2-1)(a z^2+z+a)/(2 i z^2).
            coeff=[a,1,a] if a else [1,0]
            roots=np.roots(coeff);angles=[-math.pi,0.]
            for z in roots:
                if abs(abs(z)-1)<1e-7:
                    q=(math.atan2(z.imag,z.real)+math.pi)%(2*math.pi)-math.pi
                    if all(abs((q-x+math.pi)%(2*math.pi)-math.pi)>1e-6 for x in angles):angles.append(q)
            rr.append(sorted(angles))
        rows=[]
        for q in itertools.product(*rr):
            pp=np.empty(4);pp[0]=q[0]
            for i in range(1,4):pp[i]=(q[i]-c['shear'][i-1]*math.sin(pp[i-1])+math.pi)%(2*math.pi)-math.pi
            G=np.eye(4)
            for i in range(1,4):G[i,i-1]=c['shear'][i-1]*math.cos(pp[i-1])
            qv=np.array(q);d=np.cos(qv)+2*np.array(c['a'])*np.cos(2*qv);J=np.diag(d)@G;deg=bool(np.any(abs(d)<1e-9));idx=1
            for aa,x,dd in zip(c['a'],q,d):
                value=dd if abs(dd)>1e-9 else (-math.cos(x)-8*aa*math.cos(2*x))/6
                idx*=1 if value>0 else -1
            qq=pp.copy()
            for i in range(1,4):qq[i]+=c['shear'][i-1]*math.sin(pp[i-1])
            residual.append(float(max(abs(np.sin(qq)+np.array(c['a'])*np.sin(2*qq)))))
            rows.append([*pp,float(np.linalg.det(J)),float(idx),float(deg)])
        rows.sort(key=lambda r:tuple(round(x,10) for x in r[:4]));out.append({'id':c['id'],'values':rows});net.append(sum(r[5] for r in rows))
    assert max(residual)<1e-10 and all(x==0 for x in net)
    return out,{'polynomial_root_max_residual':max(residual),'index_sums':net,'completeness':'all unit-circle roots of explicit factored Laurent polynomial; triangular torus change has det=1'}


def truth22(m,secret):
    out=[];checks=[]
    z=np.exp(2j*math.pi*np.arange(3)/3)
    for e in m['ensembles']:
        def free(y):
            xx=np.r_[y,1-sum(y)]
            if min(xx)<=0:return 1e5+sum(np.minimum(xx,0)**2)
            return float(np.dot(xx,np.log(xx))-e['J']*np.dot(xx,xx)/2-e['h']*np.dot(xx,z.real))
        sols=[]
        for start in ([1/3,1/3],[.88,.06],[.06,.88],[.06,.06]):
            fit=minimize(free,start,method='Nelder-Mead',options={'xatol':2e-13,'fatol':1e-14,'maxiter':3000});sols.append((fit.fun,fit.x))
        f,x=min(sols,key=lambda t:t[0]);xx=np.r_[x,1-sum(x)];r2=abs(xx@z)**2;phase=2 if e['h']!=0 else int(r2>1e-8)
        for N in e['volumes']:
            vec=[];logs=[]
            for n0 in range(N+1):
                for n1 in range(N-n0+1):
                    n2=N-n0-n1;LL=(n0+n1*z[1]+n2*z[2])/N
                    multiplicity=math.comb(N,n0)*math.comb(N-n0,n1)
                    logs.append(math.log(multiplicity)+e['J']*(n0*n0+n1*n1+n2*n2)/(2*N)+e['h']*N*LL.real);vec.append(LL)
            a=max(logs);ww=np.exp(np.array(logs)-a);partition=ww.sum();ww/=partition;vv=np.array(vec);mean=ww@vv;m2=ww@abs(vv)**2;m4=ww@abs(vv)**4
            values=[mean.real,mean.imag,m2,(N*m2-1)/(N-1),1-m4/(2*m2*m2),(a+math.log(partition))/N,phase,r2,f]
            out.append({'id':f"{e['id']}-V{N}",'values':list(map(float,values))})
            if N==12:
                cfg=np.array(list(itertools.product(range(3),repeat=N)),dtype=np.uint8);ns=np.stack([(cfg==j).sum(axis=1) for j in range(3)],axis=1);ll=ns@z/N;weights=np.exp(e['J']*np.sum(ns*ns,axis=1)/(2*N)+e['h']*N*ll.real);weights/=weights.sum()
                checks.append(float(abs(np.sum(weights*abs(ll)**2)-m2)))
    for chain in m['chains']:
        # Independent explicit index contraction instead of BLAS ordered product.
        U=[np.array(a)[...,0]+1j*np.array(a)[...,1] for a in chain['links']]
        val=0j
        for i,j,k,l in itertools.product(range(3),repeat=4):val+=U[3][i,j]*U[2][j,k]*U[1][k,l]*U[0][l,i]/3
        zz=np.exp(2j*math.pi*chain['twist']/3);keep=[float(all((j*n)%3==0 for n in chain['matter_nalities'])) for j in range(3)]
        out.append({'id':chain['id'],'values':[val.real,val.imag,(zz*val).real,(zz*val).imag,*keep]})
    assert max(checks)<1e-12
    return out,{'N12_full_configuration_vs_occupation_m2_max':max(checks),'thermodynamic_truth':'independent two-dimensional constrained free-energy minimization, all three sectors'}


def truth23(m,secret):
    out=[]
    def integ(x,weight):
        if abs(x)<1:
            real=-quad(weight,-1,1,weight='cauchy',wvar=x,epsabs=2e-13,epsrel=2e-13)[0];imag=-math.pi*weight(x)
            return complex(real,imag)
        return complex(quad(lambda u:weight(u)/(x-u),-1,1,epsabs=1e-12,epsrel=1e-12,limit=300)[0])
    def pi(x):return 1-x*integ(x,lambda u:1)/2,x*integ(x,lambda u:1-u*u)/4
    for c in m['queries']:
        x=c['x'];a,b=pi(x);resp=1/(c['k']**2+a)
        out.append({'id':c['id'],'values':[a.real,a.imag,b.real,b.imag,(x*a).real,(x*a).imag,(x*x*a).real,(x*x*a).imag,resp.real,resp.imag]})
    for k in m['mode_k']:
        wl=brentq(lambda w:k*k+pi(w/k)[0].real,k*(1+1e-12),k+4,xtol=8e-15);wt=brentq(lambda w:w*w-k*k-pi(w/k)[1].real,k*(1+1e-12),k+4,xtol=8e-15)
        x=wl/k;d0=-integ(x,lambda u:1).real/2+x*quad(lambda u:1/(x-u)**2,-1,1,epsabs=1e-12)[0]/2
        x=wt/k;dt=integ(x,lambda u:1-u*u).real/4-x*quad(lambda u:(1-u*u)/(x-u)**2,-1,1,epsabs=1e-12)[0]/4
        out.append({'id':f'mode-k{k:g}','values':[wl,wt,k/d0,1/(2*wt-dt/k)]})
    debye_coefficient=4/math.pi**2*quad(lambda p:p/(math.exp(p)+1),0,60,epsabs=1e-13,epsrel=1e-13)[0]
    out.append({'id':'limits','values':[1.,0.,0.,1/3,debye_coefficient]})
    return out,{'truth_route':'Cauchy principal-value velocity quadrature plus exact on-shell delta imaginary part; derivatives integrated independently','normalization':'mD^2=1; omega and k in mD units'}


def truth24(m,secret):
    out=[];checks=[]
    for c in m['cases']:
        M=c['M'];h=c['spacing'];ind=np.arange(M);ii,jj=np.meshgrid(ind,ind,indexing='ij');points=np.stack([ii.ravel(),jj.ravel()],axis=1);p=(points-M//2)*h;p2=np.sum(p*p,axis=1)
        delta=(points[:,None,:]-points[None,:,:]+M//2)%M-M//2;l2=np.sum((h*delta)**2,axis=2);K=np.zeros_like(l2);nz=l2>0;K[nz]=h*h/(2*math.pi)**2/(l2[nz]*(l2[nz]+1))
        C=np.diag(K.sum(axis=1))-K;D=c['a']*(c['mass']**2+p2);source=p[:,0]*np.exp(-p2/(2*c['source_width']**2));A=C+1j*np.diag(D);f=solve(A,source,assume_a='gen');g=source/D;bh=float(h*h*g@C@g);rate=float(h*h*source@f.real)
        # Independent real 2n block solve and matrix Fourier-spectrum positivity.
        block=np.block([[C,-np.diag(D)],[np.diag(D),C]]);fb=solve(block,np.r_[source,np.zeros_like(source)]);checks.append(float(np.max(abs(f-(fb[:len(f)]+1j*fb[len(f):])))))
        eig=np.linalg.eigvalsh(C);assert min(eig)>-1e-12
        diff=float(np.sum(K[0]*l2[0])/4);lap=np.zeros_like(C)
        for a,(i,j) in enumerate(points):
            lap[a,a]=4/(h*h)
            for di,dj in ((1,0),(-1,0),(0,1),(0,-1)):lap[a,((i+di)%M)*M+(j+dj)%M]-=1/(h*h)
        fd=solve(diff*lap+1j*np.diag(D),source);rd=float(h*h*source@fd.real);err=abs(r
tm-01 ['harbor-path-failure', 'harbor-macos-compat', 'harbor-path-failure/oracle', 'harbor-macos-compat/oracle', 'harbor-macos-compat/nop', 'harbor-path-failure/oracle/2026-11-16__11-38-25', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB', 'harbor-path-failure/oracle/2026-11-16__11-38-25/job.log', 'harbor-path-failure/oracle/2026-11-16__11-38-25/lock.json', 'harbor-path-failure/oracle/2026-11-16__11-38-25/result.json', 'harbor-path-failure/oracle/2026-11-16__11-38-25/config.json', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/artifacts', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/lock.json', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/result.json', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/config.json', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/agent', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/trial.log', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/exception.txt', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/verifier', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/artifacts/app', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/artifacts/logs', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/artifacts/manifest.json', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/artifacts/app/output', 'harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/artifacts/logs/artifacts', 'harbor-macos-compat/oracle/2026-11-16__11-39-32', 'harbor-macos-compat/nop/2026-11-16__11-39-53', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/job.log', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/lock.json', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/result.json', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/config.json', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/artifacts', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/lock.json', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/result.json', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/config.json', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/agent', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/trial.log', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/verifier', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/artifacts/app', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/artifacts/logs', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/artifacts/manifest.json', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/agent/oracle.txt', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/verifier/metrics.json', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/verifier/test-stdout.txt', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/verifier/reward.txt', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/artifacts/app/output', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/artifacts/logs/artifacts', 'harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/artifacts/app/output/answer.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/job.log', 'harbor-macos-compat/nop/2026-11-16__11-39-53/lock.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/result.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP', 'harbor-macos-compat/nop/2026-11-16__11-39-53/config.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/artifacts', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/lock.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/result.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/config.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/agent', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/trial.log', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/verifier', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/artifacts/app', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/artifacts/logs', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/artifacts/manifest.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/verifier/metrics.json', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/verifier/test-stdout.txt', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/verifier/reward.txt', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/artifacts/app/output', 'harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/artifacts/logs/artifacts']
qft-13 ['harbor-macos-compat', 'development-answers', 'harbor-macos-compat/session-20261116-224252.json', 'harbor-macos-compat/oracle', 'harbor-macos-compat/nop', 'development-answers/independent_truth.json', 'development-answers/boolean.json', 'development-answers/reordered.json', 'development-answers/wrong_labels.json', 'development-answers/reference.json', 'development-answers/wrong_values.json', 'development-answers/baseline.json', 'development-answers/missing.json', 'development-answers/malformed.json', 'development-answers/huge_integer.json', 'development-answers/duplicate.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54', 'harbor-macos-compat/nop/2026-11-16__22-42-23', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/job.log', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/lock.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/result.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/config.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/artifacts', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/lock.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/result.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/config.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/agent', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/trial.log', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/verifier', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/artifacts/app', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/artifacts/logs', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/artifacts/manifest.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/agent/oracle.txt', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/verifier/metrics.json', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/verifier/test-stdout.txt', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/verifier/reward.txt', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/artifacts/app/output', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/artifacts/logs/artifacts', 'harbor-macos-compat/oracle/2026-11-16__22-41-54/qft-13__qjBY9Nt/artifacts/app/output/answer.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/job.log', 'harbor-macos-compat/nop/2026-11-16__22-42-23/lock.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/result.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/config.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/artifacts', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/lock.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/result.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/config.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/agent', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/trial.log', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/verifier', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/artifacts/app', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/artifacts/logs', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/artifacts/manifest.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/verifier/metrics.json', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/verifier/test-stdout.txt', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/verifier/reward.txt', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/artifacts/app/output', 'harbor-macos-compat/nop/2026-11-16__22-42-23/qft-13__JaSJYd8/artifacts/logs/artifacts']
checks/root bytes 8191482
runs bytes 3832665

exit_code=0
```

### 2026-11-16T22:57:01.915665+08:00

```bash
python3 -
```

```text

### 2026-11-16T22:57:01.915665+08:00

```bash
python3 tools/test_package_benchmark50.py
```

```text
test_allowlist_excludes_books_ocr_credentials_and_caches (__main__.PackageTests.test_allowlist_excludes_books_ocr_credentials_and_caches) ... ok
test_draft_roundtrip_and_source_preservation (__main__.PackageTests.test_draft_roundtrip_and_source_preservation) ... ok
test_evidence_missing_reference_rejected (__main__.PackageTests.test_evidence_missing_reference_rejected) ... ok
test_final_mode_refuses_missing_evidence (__main__.PackageTests.test_final_mode_refuses_missing_evidence) ... ok
test_mutation_detected_after_packaging (__main__.PackageTests.test_mutation_detected_after_packaging) ... ok
test_scanner_reports_only_path_type_count (__main__.PackageTests.test_scanner_reports_only_path_type_count) ... ok
test_symlink_is_not_followed (__main__.PackageTests.test_symlink_is_not_followed) ... ok
test_zip_path_traversal_rejected (__main__.PackageTests.test_zip_path_traversal_rejected) ... ok

----------------------------------------------------------------------
Ran 8 tests in 0.053s

OK

exit_code=0
```
{
  "file_count": 3377,
  "bytes": 9464225,
  "has_book_or_ocr": false,
  "has_local_course_env": false
}

exit_code=0
```

### 2026-11-16T22:57:33.328694+08:00

```bash
python3 tools/package_benchmark50.py --draft --output-dir tmp/package-selfcheck
```

```text
{
  "passed": true,
  "release_kind": "draft",
  "directory": "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tmp/package-selfcheck/draft-20261116T145734583626Z/TheoryPhysicsBench-50",
  "zip": "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tmp/package-selfcheck/draft-20261116T145734583626Z/TheoryPhysicsBench-50-draft.zip",
  "archive_sha256": "28d691f5743958569b2635fb7947f145260c87668fa4c834470207337c4c3ca2",
  "directory_verification": {
    "passed": true,
    "file_count": 3392,
    "total_bytes": 10128114,
    "credential_scan": {
      "schema_version": 1,
      "files_scanned": 3392,
      "passed": true,
      "findings": [],
      "scope": "Deterministic credential patterns and sensitive local file names; findings never contain matching values."
    }
  },
  "zip_verification": {
    "passed": true,
    "archive_sha256": "28d691f5743958569b2635fb7947f145260c87668fa4c834470207337c4c3ca2",
    "file_count": 3392,
    "total_bytes": 10128114,
    "credential_scan": {
      "schema_version": 1,
      "files_scanned": 3392,
      "passed": true,
      "findings": [],
      "scope": "Deterministic credential patterns and sensitive local file names; findings never contain matching values."
    }
  }
}

exit_code=0
```

### 2026-11-16T22:59:00.721975+08:00

```bash
python3 -
```

```text

### 2026-11-16T22:59:00.721975+08:00

```bash
python3 tools/test_package_benchmark50.py
```

```text
evidence top-level: ['schema_version', 'created_utc', 'scope', 'task_count', 'verified_count', 'needs_rerun', 'all_verified', 'tasks']
passed: None needs_rerun: ['ed-04', 'qft-05', 'qm-01', 'tm-01']

exit_code=0
```
test_allowlist_excludes_books_ocr_credentials_and_caches (__main__.PackageTests.test_allowlist_excludes_books_ocr_credentials_and_caches) ... ok
test_draft_roundtrip_and_source_preservation (__main__.PackageTests.test_draft_roundtrip_and_source_preservation) ... ok
test_evidence_missing_reference_rejected (__main__.PackageTests.test_evidence_missing_reference_rejected) ... ok
test_final_mode_refuses_missing_evidence (__main__.PackageTests.test_final_mode_refuses_missing_evidence) ... ok
test_mutation_detected_after_packaging (__main__.PackageTests.test_mutation_detected_after_packaging) ... ok
test_scanner_reports_only_path_type_count (__main__.PackageTests.test_scanner_reports_only_path_type_count) ... ok
test_symlink_is_not_followed (__main__.PackageTests.test_symlink_is_not_followed) ... ok
test_zip_path_traversal_rejected (__main__.PackageTests.test_zip_path_traversal_rejected) ... ok

----------------------------------------------------------------------
Ran 8 tests in 0.053s

OK

exit_code=0
```

### 2026-11-16T22:59:28.448519+08:00

```bash
python3 -
```

```text
{
  "id": "ed-01",
  "final_task_sha256": "88ca3c7911e5ac9e43fbd81c36d8b17137f263fa962e2343df97acb99c4a4311",
  "final_files_sha256": {
    "environment/.dockerignore": "60c9bdd905fcf45ac485c680d32e9773962cf061b6f041dcddd033911558a672",
    "environment/Dockerfile": "69a59e7846082f9086d193762580a6da80a1de99c2b794f58dc43d769949d284",
    "environment/public/feedback.py": "0a872abb69ac4c08bb2b3cf8166a94d212b9333e692e0f043fb70a7fc3d66585",
    "environment/public/metric.json": "319a0ba9ade356dccd4585abaec7015a0df1885ac463eff18a4e6f02a95ff5bb",
    "environment/public/model.json": "58e21be00cfb99a0bb83adb66b226fb4a69cb27c8068d2952f413cf77eebeb17",
    "environment/public/physics.py": "94f965d32ab0455b4cf7508f7bca7d4210ddca73be7c868e6a0258bf96c7704b",
    "environment/requirements.txt": "ac82f30dd3fdd1345f01dca4d702d20257d6aa8c6d94106499c8e005ef9eed50",
    "instruction.md": "eb540a1a848fc83c3f4fcfb12354740edaa658091e20b0c1e0dae62c8633590d",
    "solution/README.md": "adbf1cff3d6732c03f317ad154637161c1f48964d61e95fb0791a131655a7ee4",
    "solution/baseline.py": "d714fcf3961a0d601d734e6ad0f3ecfd9a6a0028c0c0d75e2902c8f7391c476b",
    "solution/solve.py": "59a852fa1a1f2e3bba8b4379391a0968315f6c555e9267700095e348d5edd0cf",
    "solution/solve.sh": "268e57f8f4715e9ef936c8dbcf0a273ffa1f06c7a925b6d67f9548714d5b4bed",
    "solution/solver_core.py": "e84e19df8dd9fbc5d5a2717dcca74ad8f7427fdbfd9406ac1d6a0cc3b594564f",
    "task.toml": "0540eae8e89d937c41a4cd846386879e8bc87e6e4f794f29f7652e950b684d5c",
    "tests/development_cases.py": "79e53a93c3a43c881252cf56561859272dd41aa99d72952226ef8213945a1707",
    "tests/metric.json": "319a0ba9ade356dccd4585abaec7015a0df1885ac463eff18a4e6f02a95ff5bb",
    "tests/private/truth.json": "8808b625fab8956e821ea2c3eea7443388a567dc7f243e471ba7a4340bc27b62",
    "tests/quality_score.py": "797343b693d5676a4bd0dd13a8270038d2f879bcb41f863ec87563ead807def4",
    "tests/score.py": "b3694804728fdcc236448bbe3ef8ad0c2be479936047e4c747cbc54fb9a60d72",
    "tests/test.sh": "7482ce760c719b9c8eb05e12a7f475831e5abe7c879ac50e91b81a9b119fa25c"
  },
  "final_core_sha256": "42e2fac58b220becde1502806bcaff1cdd2c62f5ae82d4b41df977bc80979a30",
  "verified": true,
  "needs_rerun": false,
  "selected": {
    "snapshot_path": "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
    "runs": {
      "oracle": {
        "agent": "oracle",
        "job": "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37",
        "trial": "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs",
        "trial_id": "4f181881-3efa-4201-8849-033fa4306781",
        "finished_at": "2026-11-16T05:42:05.554356Z",
        "passed": true,
        "errors": [],
        "expected_reward": 1.0,
        "actual_reward": 1.0,
        "raw_metric": 8.157061168934074e-10,
        "metric_status": "completed",
        "snapshot_path": "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
        "harbor_task_checksum": "d25af280a904992fe5637f6c64e85f081e9cacfc0d9e73c0cf91d2dbf455919a",
        "evidence_files_sha256": {
          "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/result.json": "c28fdb36e40656841f2797858d92b252d076cae94f1c71685aafc4705ed62827",
          "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/config.json": "a0c1e39d2e6effc6fe8a457cbebf1dc8d649404251bb3dc1b055a14123c3922e",
          "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs/result.json": "ee96507292a4cbdcd0fa2886975d007a23cff6ad013ad860ffc66784289628b8",
          "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs/verifier/metrics.json": "fa656f71f4b1c03d5dd8f31f15cabf249222c3db48b2427a9549033b350caeb9",
          "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs/verifier/reward.txt": "5717e7c840171019a4eeab5b79a7f894a4986eaff93d04ec5b12c9a189f594bf"
        }
      },
      "nop": {
        "agent": "nop",
        "job": "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10",
        "trial": "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78",
        "trial_id": "a606ae29-0400-4fd5-9f9f-f9ca7f43bfa0",
        "finished_at": "2026-11-16T05:42:37.738756Z",
        "passed": true,
        "errors": [],
        "expected_reward": 0.0,
        "actual_reward": 0.0,
        "raw_metric": null,
        "metric_status": "invalid",
        "snapshot_path": "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
        "harbor_task_checksum": "d25af280a904992fe5637f6c64e85f081e9cacfc0d9e73c0cf91d2dbf455919a",
        "evidence_files_sha256": {
          "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/result.json": "d39aa8d22dba2ed2eb61c1b5a80c3e625fc184127c8b9d060ef781b3bc4b59c3",
          "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/config.json": "c80cb881c43896629be2a49080cf40dc146c04238fec3063aac406f6b359cb6f",
          "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/result.json": "ed4cb3ad070aedc6b0507822311835beebbcdc38c2cfa72f17c17142807e9224",
          "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/verifier/metrics.json": "957e58ff49342f4d113a279021afdbee08072201d7757f8ca5c04acd6af1a2f2",
          "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/verifier/reward.txt": "51ff0d2f0d3a5d61edec31785532ea0d570f8c348d58b15b94ff9c2ca6e926a4"
        }
      }
    },
    "errors": [],
    "snapshot_files_sha256": {
      "environment/.dockerignore": "60c9bdd905fcf45ac485c680d32e9773962cf061b6f041dcddd033911558a672",
      "environment/Dockerfile": "69a59e7846082f9086d193762580a6da80a1de99c2b794f58dc43d769949d284",
      "environment/public/feedback.py": "0a872abb69ac4c08bb2b3cf8166a94d212b9333e692e0f043fb70a7fc3d66585",
      "environment/public/metric.json": "319a0ba9ade356dccd4585abaec7015a0df1885ac463eff18a4e6f02a95ff5bb",
      "environment/public/model.json": "58e21be00cfb99a0bb83adb66b226fb4a69cb27c8068d2952f413cf77eebeb17",
      "environment/public/physics.py": "94f965d32ab0455b4cf7508f7bca7d4210ddca73be7c868e6a0258bf96c7704b",
      "environment/requirements.txt": "ac82f30dd3fdd1345f01dca4d702d20257d6aa8c6d94106499c8e005ef9eed50",
      "instruction.md": "95dad195e8f724e75f41c8b5cc1e49155cbafe4b6ee72b1a03db7e2080189b04",
      "solution/README.md": "adbf1cff3d6732c03f317ad154637161c1f48964d61e95fb0791a131655a7ee4",
      "solution/baseline.py": "d714fcf3961a0d601d734e6ad0f3ecfd9a6a0028c0c0d75e2902c8f7391c476b",
      "solution/solve.py": "59a852fa1a1f2e3bba8b4379391a0968315f6c555e9267700095e348d5edd0cf",
      "solution/solve.sh": "268e57f8f4715e9ef936c8dbcf0a273ffa1f06c7a925b6d67f9548714d5b4bed",
      "solution/solver_core.py": "e84e19df8dd9fbc5d5a2717dcca74ad8f7427fdbfd9406ac1d6a0cc3b594564f",
      "task.toml": "a432ef75bedf7698ef15a53803a1ef70608c4fa92b34feab1fec1a3e656f9254",
      "tests/development_cases.py": "79e53a93c3a43c881252cf56561859272dd41aa99d72952226ef8213945a1707",
      "tests/metric.json": "319a0ba9ade356dccd4585abaec7015a0df1885ac463eff18a4e6f02a95ff5bb",
      "tests/private/truth.json": "8808b625fab8956e821ea2c3eea7443388a567dc7f243e471ba7a4340bc27b62",
      "tests/quality_score.py": "797343b693d5676a4bd0dd13a8270038d2f879bcb41f863ec87563ead807def4",
      "tests/score.py": "b3694804728fdcc236448bbe3ef8ad0c2be479936047e4c747cbc54fb9a60d72",
      "tests/test.sh": "7482ce760c719b9c8eb05e12a7f475831e5abe7c879ac50e91b81a9b119fa25c"
    },
    "snapshot_harbor_sha256": "d25af280a904992fe5637f6c64e85f081e9cacfc0d9e73c0cf91d2dbf455919a",
    "differences": [
      {
        "path": "instruction.md",
        "snapshot_sha256": "95dad195e8f724e75f41c8b5cc1e49155cbafe4b6ee72b1a03db7e2080189b04",
        "final_sha256": "eb540a1a848fc83c3f4fcfb12354740edaa658091e20b0c1e0dae62c8633590d",
        "permitted": true,
        "reasons": [
          "instruction deadline synchronized 1200 to 720 seconds only"
        ]
      },
      {
        "path": "task.toml",
        "snapshot_sha256": "a432ef75bedf7698ef15a53803a1ef70608c4fa92b34feab1fec1a3e656f9254",
        "final_sha256": "0540eae8e89d937c41a4cd846386879e8bc87e6e4f794f29f7652e950b684d5c",
        "permitted": true,
        "reasons": [
          "macOS verifier public override; final package no-network",
          "agent deadline reduced 1200 to 720 seconds; no formal-model timing claim"
        ]
      }
    ],
    "snapshot_core_sha256": "42e2fac58b220becde1502806bcaff1cdd2c62f5ae82d4b41df977bc80979a30",
    "core_equal": true,
    "compatible": true,
    "latest_finished_at": "2026-11-16T05:42:37.738756Z"
  },
  "attempts": [
    {
      "agent": "oracle",
      "job": "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37",
      "trial": "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs",
      "trial_id": "4f181881-3efa-4201-8849-033fa4306781",
      "finished_at": "2026-11-16T05:42:05.554356Z",
      "passed": true,
      "errors": [],
      "expected_reward": 1.0,
      "actual_reward": 1.0,
      "raw_metric": 8.157061168934074e-10,
      "metric_status": "completed",
      "snapshot_path": "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
      "harbor_task_checksum": "d25af280a904992fe5637f6c64e85f081e9cacfc0d9e73c0cf91d2dbf455919a",
      "evidence_files_sha256": {
        "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/result.json": "c28fdb36e40656841f2797858d92b252d076cae94f1c71685aafc4705ed62827",
        "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/config.json": "a0c1e39d2e6effc6fe8a457cbebf1dc8d649404251bb3dc1b055a14123c3922e",
        "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs/result.json": "ee96507292a4cbdcd0fa2886975d007a23cff6ad013ad860ffc66784289628b8",
        "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs/verifier/metrics.json": "fa656f71f4b1c03d5dd8f31f15cabf249222c3db48b2427a9549033b350caeb9",
        "runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs/verifier/reward.txt": "5717e7c840171019a4eeab5b79a7f894a4986eaff93d04ec5b12c9a189f594bf"
      }
    },
    {
      "agent": "nop",
      "job": "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10",
      "trial": "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78",
      "trial_id": "a606ae29-0400-4fd5-9f9f-f9ca7f43bfa0",
      "finished_at": "2026-11-16T05:42:37.738756Z",
      "passed": true,
      "errors": [],
      "expected_reward": 0.0,
      "actual_reward": 0.0,
      "raw_metric": null,
      "metric_status": "invalid",
      "snapshot_path": "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
      "harbor_task_checksum": "d25af280a904992fe5637f6c64e85f081e9cacfc0d9e73c0cf91d2dbf455919a",
      "evidence_files_sha256": {
        "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/result.json": "d39aa8d22dba2ed2eb61c1b5a80c3e625fc184127c8b9d060ef781b3bc4b59c3",
        "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/config.json": "c80cb881c43896629be2a49080cf40dc146c04238fec3063aac406f6b359cb6f",
        "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/result.json": "ed4cb3ad070aedc6b0507822311835beebbcdc38c2cfa72f17c17142807e9224",
        "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/verifier/metrics.json": "957e58ff49342f4d113a279021afdbee08072201d7757f8ca5c04acd6af1a2f2",
        "runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/verifier/reward.txt": "51ff0d2f0d3a5d61edec31785532ea0d570f8c348d58b15b94ff9c2ca6e926a4"
      }
    }
  ],
  "reason": null
}
"""Bind raw Harbor development results to the final 50-task package.

Collection uses surviving task snapshots. Validation of an already collected
report uses only package files, saved snapshot digests and archived raw records.
This is an audit, not a replacement for formal Codex evaluation.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import tomllib

ROOT = Path(__file__).resolve().parents[1]
REPORT = 'checks/benchmark-50-harbor-evidence.json'
EXPECTED = {f'{p}-{i:02}' for p,n in [('tm',5),('ed',5),('sp',5),('qm',5),('qft',25),('gr',5)] for i in range(1,n+1)}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ignored(p):
    return '__pycache__' in p.parts or p.name == '.DS_Store' or p.suffix == '.pyc'


def file_manifest(folder, *, filtered=False):
    result = {}
    if folder.is_symlink() or not folder.is_dir():
        raise ValueError(f'not a real task directory: {folder}')
    for p in sorted(folder.rglob('*')):
        if p.is_symlink():
            raise ValueError(f'symlink in snapshot: {p}')
        if p.is_file() and not (filtered and ignored(p)):
            result[p.relative_to(folder).as_posix()] = sha(p.read_bytes())
    return result


def manifest_digest(files):
    """Portable digest of paths and SHA256 content digests."""
    return sha(json.dumps(files, sort_keys=True, separators=(',', ':')).encode())


def harbor_digest(files):
    """dirhash default name/data SHA256 protocol, reconstructed from file hashes.

    Empty directories are ignored, as in Harbor 0.24 Task.checksum. Symlinks
    are rejected before collection. Descriptors follow dirhash Protocol.
    """
    tree = {}
    for name, digest in files.items():
        parts = Path(name).parts
        if not parts or Path(name).is_absolute() or '..' in parts:
            raise ValueError('unsafe manifest path')
        node = tree
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = digest
    def visit(node):
        descriptors = []
        for name, value in node.items():
            if isinstance(value, dict):
                descriptors.append('dirhash:' + visit(value) + '\0name:' + name)
            else:
                descriptors.append('data:' + value + '\0name:' + name)
        return sha('\0\0'.join(sorted(descriptors)).encode())
    return visit(tree)


def course_digest(folder):
    h = hashlib.sha256()
    for p in sorted(folder.rglob('*')):
        if p.is_symlink():
            raise ValueError('task symlink')
        if p.is_file() and not ignored(p):
            h.update(p.relative_to(folder).as_posix().encode())
            h.update(b'\0' + p.read_bytes() + b'\0')
    return h.hexdigest()


def core_manifest(files):
    return {p:h for p,h in files.items() if not ignored(Path(p)) and p not in
            {'task.toml', 'instruction.md', 'solution/README.md'}}


def config_changes(old, final):
    old, final = tomllib.loads(old), tomllib.loads(final)
    changes = []
    if old.get('verifier', {}).get('network_mode') == 'public' and final.get('verifier', {}).get('network_mode') == 'no-network':
        old['verifier']['network_mode'] = 'no-network'
        changes.append('macOS verifier public override; final package no-network')
    if old.get('agent', {}).get('timeout_sec') == 1200 and final.get('agent', {}).get('timeout_sec') == 720:
        old['agent']['timeout_sec'] = 720
        changes.append('agent deadline reduced 1200 to 720 seconds; no formal-model timing claim')
    return old == final, changes


def compare_snapshot(snapshot, final, old_files, final_files):
    differences = []
    for name in sorted(set(old_files) | set(final_files)):
        if ignored(Path(name)) or old_files.get(name) == final_files.get(name):
            continue
        permitted, reasons = False, []
        if name == 'solution/README.md' and name in old_files and name in final_files:
            permitted, reasons = True, ['reference derivation documentation only']
        elif name == 'task.toml' and name in old_files and name in final_files:
            permitted, reasons = config_changes((snapshot/name).read_text(), (final/name).read_text())
        elif name == 'instruction.md' and name in old_files and name in final_files:
            before, after = (snapshot/name).read_text(), (final/name).read_text()
            permitted = re.sub(r'1200(?=\s*秒)', '720', before) == after
            if permitted:
                reasons = ['instruction deadline synchronized 1200 to 720 seconds only']
        if not permitted:
            reasons = ['material/code/data/metric/feedback or unapproved instruction change; rerun required']
        differences.append({'path':name, 'snapshot_sha256':old_files.get(name),
                            'final_sha256':final_files.get(name), 'permitted':permitted, 'reasons':reasons})
    return differences


def read_object(path):
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f'not a JSON object: {path}')
    return value


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def within(root, relative):
    p = root / relative
    if Path(relative).is_absolute() or '..' in Path(relative).parts or p.is_symlink() or not p.resolve().is_relative_to(root.resolve()):
        raise ValueError('unsafe archived evidence path')
    return p


def inspect_job(root, job, identifier, agent):
    expected = 1.0 if agent == 'oracle' else 0.0
    files, errors = {}, []
    def load(path):
        files[path.relative_to(root).as_posix()] = sha(path.read_bytes())
        return read_object(path)
    try:
        result, config = load(job/'result.json'), load(job/'config.json')
        stats = result.get('stats', {})
        if not result.get('finished_at') or result.get('n_total_trials') != 1:
            errors.append('job not finished or not a single trial')
        for name,value in [('n_completed_trials',1),('n_errored_trials',0),('n_running_trials',0),('n_pending_trials',0),('n_cancelled_trials',0)]:
            if stats.get(name) != value:
                errors.append('job stats '+name)
        evaluations = stats.get('evals', {})
        if len(evaluations) != 1 or agent+'__adhoc' not in evaluations:
            errors.append('wrong job evaluation identity')
        else:
            evaluation = evaluations[agent+'__adhoc']
            if evaluation.get('n_trials') != 1 or evaluation.get('n_errors') != 0:
                errors.append('evaluation trial/error count')
            metrics = evaluation.get('metrics', [])
            if len(metrics) != 1 or metrics[0].get('mean') != expected:
                errors.append('job reward mean')
        if config.get('n_concurrent_trials') != 1:
            errors.append('job concurrency not one')
        trial_paths = sorted(p for p in job.glob('*/result.json') if p.parent.is_dir())
        if len(trial_paths) != 1:
            raise ValueError('job must have exactly one archived trial')
        trial_path = trial_paths[0]
        trial = load(trial_path)
        metrics_path, reward_path = trial_path.parent/'verifier/metrics.json', trial_path.parent/'verifier/reward.txt'
        metrics = load(metrics_path)
        files[reward_path.relative_to(root).as_posix()] = sha(reward_path.read_bytes())
        reward = float(reward_path.read_text().strip())
        trial_config = trial.get('config', {})
        if trial.get('exception_info') is not None or not trial.get('finished_at'):
            errors.append('trial exception or unfinished')
        if trial.get('task_name') != 'theory-physics-bench/'+identifier:
            errors.append('wrong task name')
        if trial.get('agent_info', {}).get('name') != agent or trial_config.get('agent', {}).get('name') != agent:
            errors.append('wrong trial agent')
        if trial_config.get('job_id') != result.get('id'):
            errors.append('trial/job id mismatch')
        if trial.get('verifier_environment_mode') != 'separate':
            errors.append('verifier not separate')
        phase_seconds = {}
        for stage in ['agent_execution','verifier']:
            if not trial.get(stage, {}).get('started_at') or not trial.get(stage, {}).get('finished_at'):
                errors.append('missing phase times: '+stage)
            else:
                phase = trial[stage]
                seconds = (datetime.fromisoformat(phase['finished_at'].replace('Z','+00:00'))-
                           datetime.fromisoformat(phase['started_at'].replace('Z','+00:00'))).total_seconds()
                phase_seconds[stage] = seconds
                if seconds < 0 or seconds > (720 if stage == 'agent_execution' else 120):
                    errors.append('phase outside final registered deadline: '+stage)
        trial_reward = trial.get('verifier_result', {}).get('rewards', {}).get('reward')
        if not finite(trial_reward) or trial_reward != expected or reward != expected or metrics.get('score') != expected:
            errors.append('trial/reward.txt/metrics reward disagreement')
        if agent == 'oracle' and (metrics.get('status') != 'completed' or not finite(metrics.get('raw_metric'))):
            errors.append('oracle metric not finite/completed')
        if agent == 'nop' and metrics.get('status') not in ['invalid','completed']:
            errors.append('unexpected nop status')
        task_path = trial.get('task_id', {}).get('path')
        if task_path != trial_config.get('task', {}).get('path'):
            errors.append('task paths disagree')
        if not isinstance(task_path, str) or not task_path:
            errors.append('missing snapshot path')
        trial_name = trial_path.parent.name
        if not errors:
            reward_stats = next(iter(evaluations.values())).get('reward_stats', {}).get('reward', {})
            if reward_stats.get(str(expected)) != [trial_name]:
                errors.append('job reward stats do not identify actual trial')
        return {'agent':agent, 'job':job.relative_to(root).as_posix(),
                'trial':trial_path.parent.relative_to(root).as_posix(), 'trial_id':trial.get('id'),
                'finished_at':trial.get('finished_at'), 'passed':not errors, 'errors':errors,
                'expected_reward':expected, 'actual_reward':reward, 'raw_metric':metrics.get('raw_metric'),
                'metric_status':metrics.get('status'), 'phase_seconds':phase_seconds, 'snapshot_path':task_path,
                'harbor_task_checksum':trial.get('task_checksum'), 'evidence_files_sha256':files}
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as exc:
        return {'agent':agent, 'job':job.relative_to(root).as_posix(), 'passed':False,
                'errors':errors+[str(exc)], 'evidence_files_sha256':files}


def collect(root):
    records = []
    for identifier in sorted(EXPECTED):
        final = root/'tasks'/identifier
        final_files = file_manifest(final, filtered=True)
        candidates = {}
        attempts = []
        for agent in ['oracle','nop']:
            for path in sorted((root/'runs'/identifier).glob('**/'+agent+'/*/result.json')):
                item = inspect_job(root, path.parent, identifier, agent)
                attempts.append(item)
                if item['passed']:
                    group = candidates.setdefault(item['snapshot_path'], {'oracle':[], 'nop':[]})
                    group[agent].append(item)
        eligible, pairs = [], []
        for snapshot_name, group in candidates.items():
            if not group['oracle'] or not group['nop']:
                continue
            pair = {agent:max(items,key=lambda i:i.get('finished_at') or '') for agent,items in group.items()}
            snapshot = Path(snapshot_name)
            evaluation = {'snapshot_path':snapshot_name, 'runs':pair, 'errors':[]}
            try:
                old_files = file_manifest(snapshot)
                old_harbor = harbor_digest(old_files)
                if any(item['harbor_task_checksum'] != old_harbor for item in pair.values()):
                    evaluation['errors'].append('surviving snapshot does not match original Harbor task_checksum')
                differences = compare_snapshot(snapshot, final, old_files, final_files)
                if any(not d['permitted'] for d in differences):
                    evaluation['errors'].append('final package has unapproved changes since run')
                evaluation.update(snapshot_files_sha256=old_files, snapshot_harbor_sha256=old_harbor,
                                  differences=differences,
                                  snapshot_texts={name:(snapshot/name).read_text() for name in
                                                  ['instruction.md','task.toml'] if (snapshot/name).is_file()},
                                  snapshot_core_sha256=manifest_digest(core_manifest(old_files)),
                                  core_equal=core_manifest(old_files)==core_manifest(final_files))
            except (OSError, ValueError, TypeError) as exc:
                evaluation['errors'].append(str(exc))
            evaluation['compatible'] = not evaluation['errors']
            evaluation['latest_finished_at'] = max(i['finished_at'] for i in pair.values())
            pairs.append(evaluation)
            if evaluation['compatible']:
                eligible.append(evaluation)
        selected = max(eligible or pairs, key=lambda p:p['latest_finished_at']) if eligible or pairs else None
        records.append({'id':identifier, 'final_task_sha256':course_digest(final),
                        'final_files_sha256':final_files,
                        'final_core_sha256':manifest_digest(core_manifest(final_files)),
                        'verified':bool(eligible), 'needs_rerun':not bool(eligible),
                        'selected':selected, 'attempts':attempts,
                        'reason':None if eligible else ('no compatible successful oracle/nop snapshot pair' if selected else 'no successful pair with common snapshot')})
    return {'schema_version':1, 'created_utc':datetime.now(timezone.utc).isoformat(),
            'scope':'Harbor development oracle/nop; not formal course Codex model results. macOS verifier public overrides are explicitly recorded.',
            'task_count':len(records), 'verified_count':sum(r['verified'] for r in records),
            'needs_rerun':[r['id'] for r in records if r['needs_rerun']],
            'all_verified':all(r['verified'] for r in records), 'tasks':records}


def validate_saved_evidence(root, report=None):
    """Return errors using package and saved evidence only; never reads /tmp."""
    root = Path(root)
    report = read_object(root/REPORT) if report is None else report
    errors = []
    records = report.get('ta

exit_code=0
```

### 2026-11-16T23:00:18.675065+08:00

```bash
python3 tools/test_package_benchmark50.py
```

```text
test_allowlist_excludes_books_ocr_credentials_and_caches (__main__.PackageTests.test_allowlist_excludes_books_ocr_credentials_and_caches) ... ok
test_draft_roundtrip_and_source_preservation (__main__.PackageTests.test_draft_roundtrip_and_source_preservation) ... ok
test_evidence_missing_reference_rejected (__main__.PackageTests.test_evidence_missing_reference_rejected) ... ok
test_final_mode_refuses_missing_evidence (__main__.PackageTests.test_final_mode_refuses_missing_evidence) ... ok
test_mutation_detected_after_packaging (__main__.PackageTests.test_mutation_detected_after_packaging) ... ok
test_scanner_reports_only_path_type_count (__main__.PackageTests.test_scanner_reports_only_path_type_count) ... ok
test_symlink_is_not_followed (__main__.PackageTests.test_symlink_is_not_followed) ... ok
test_zip_path_traversal_rejected (__main__.PackageTests.test_zip_path_traversal_rejected) ... ok

----------------------------------------------------------------------
Ran 8 tests in 0.046s

OK

exit_code=0
```

### 2026-11-16T23:01:56.165599+08:00

```bash
python3 tools/test_package_benchmark50.py
```

```text

### 2026-11-16T23:01:56.165586+08:00

```bash
python3 -
```

```text
def validate_saved_evidence(root, report=None):
    """Return errors using package and saved evidence only; never reads /tmp."""
    root = Path(root)
    report = read_object(root/REPORT) if report is None else report
    errors = []
    records = report.get('tasks', [])
    spec = importlib.util.spec_from_file_location('evidence_quality', root/'tools/course/quality_score.py')
    quality = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(quality)
    if len(records) != 50 or {r.get('id') for r in records} != EXPECTED:
        return ['evidence does not register exactly the 50 expected tasks']
    for record in records:
        identifier = record['id']
        try:
            final = root/'tasks'/identifier
            current = file_manifest(final, filtered=True)
            if course_digest(final) != record.get('final_task_sha256') or current != record.get('final_files_sha256'):
                raise ValueError('final task changed since evidence collection')
            if manifest_digest(core_manifest(current)) != record.get('final_core_sha256'):
                raise ValueError('final core hash mismatch')
            selected = record.get('selected')
            if not record.get('verified') or record.get('needs_rerun') or not selected or not selected.get('compatible'):
                raise ValueError('needs rerun')
            snapshot_files = selected['snapshot_files_sha256']
            original_harbor = harbor_digest(snapshot_files)
            if original_harbor != selected.get('snapshot_harbor_sha256'):
                raise ValueError('snapshot manifest/Harbor hash mismatch')
            if not selected.get('core_equal') or core_manifest(snapshot_files) != core_manifest(current):
                raise ValueError('runtime code/data/feedback core differs')
            if any(not d.get('permitted') for d in selected.get('differences', [])):
                raise ValueError('unapproved difference')
            # Rebuild all permitted differences from hash-bound original text;
            # do not trust the stored "permitted" flag by itself.
            originals = selected.get('snapshot_texts', {})
            actual_differences = {name for name in set(snapshot_files)|set(current)
                                  if not ignored(Path(name)) and snapshot_files.get(name) != current.get(name)}
            saved_differences = {d['path'] for d in selected.get('differences', [])}
            if actual_differences != saved_differences:
                raise ValueError('incomplete saved difference list')
            for name in actual_differences:
                if name == 'solution/README.md':
                    continue
                if name not in {'instruction.md','task.toml'} or name not in originals:
                    raise ValueError('non-document change is not permitted')
                before = originals[name]
                if sha(before.encode()) != snapshot_files.get(name):
                    raise ValueError('snapshot text does not match original file hash')
                after = (final/name).read_text()
                if name == 'task.toml':
                    allowed, _ = config_changes(before, after)
                else:
                    allowed = re.sub(r'1200(?=\s*秒)', '720', before) == after
                if not allowed:
                    raise ValueError('saved snapshot text has unapproved semantic difference')
            metric = read_object(final/'tests/metric.json')
            for agent in ['oracle','nop']:
                saved = selected['runs'][agent]
                job = within(root, saved['job'])
                actual = inspect_job(root, job, identifier, agent)
                if not actual['passed'] or actual.get('evidence_files_sha256') != saved.get('evidence_files_sha256'):
                    raise ValueError(agent+': raw archived evidence changed or invalid')
                if actual['harbor_task_checksum'] != original_harbor or actual['snapshot_path'] != selected['snapshot_path']:
                    raise ValueError(agent+': original snapshot binding mismatch')
                if quality.quality_score(metric, actual['raw_metric'], actual['metric_status']) != actual['expected_reward']:
                    raise ValueError(agent+': current course quality function does not reproduce raw score')
        except (OSError, ValueError, TypeError, KeyError, AttributeError) as exc:
            errors.append(identifier+': '+str(exc))
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=ROOT)
    parser.add_argument('--verify-saved',action='store_true',help='Validate portable evidence without reading temporary snapshots')
    args = parser.parse_args()
    root = args.directory.resolve()
    if args.verify_saved:
        errors = validate_saved_evidence(root)
        print(json.dumps({'passed':not errors,'errors':errors},ensure_ascii=False,indent=2))
        raise SystemExit(bool(errors))
    report = collect(root)
    (root/REPORT).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['task_count','verified_count','needs_rerun','all_verified']},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()


exit_code=0
```
test_allowlist_excludes_books_ocr_credentials_and_caches (__main__.PackageTests.test_allowlist_excludes_books_ocr_credentials_and_caches) ... ok
test_draft_roundtrip_and_source_preservation (__main__.PackageTests.test_draft_roundtrip_and_source_preservation) ... ok
test_evidence_missing_reference_rejected (__main__.PackageTests.test_evidence_missing_reference_rejected) ... ok
test_final_mode_refuses_missing_evidence (__main__.PackageTests.test_final_mode_refuses_missing_evidence) ... ok
test_mutation_detected_after_packaging (__main__.PackageTests.test_mutation_detected_after_packaging) ... ok
test_scanner_reports_only_path_type_count (__main__.PackageTests.test_scanner_reports_only_path_type_count) ... ok
test_symlink_is_not_followed (__main__.PackageTests.test_symlink_is_not_followed) ... ok
test_zip_path_traversal_rejected (__main__.PackageTests.test_zip_path_traversal_rejected) ... ok

----------------------------------------------------------------------
Ran 8 tests in 0.047s

OK

exit_code=0
```
