# 来源与本地改造

François Gelis，*Problems in Quantum Field Theory*，原题 26。

PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5

页码（PDF / 印刷）: [{"pdf": [282, 285], "printed": [111, 114], "role": "完整题面与解答"}]

原书工作：引入辅助场、积分费米子并重整化有效势，得到非解析质量尺度和leading large-N真空。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。
