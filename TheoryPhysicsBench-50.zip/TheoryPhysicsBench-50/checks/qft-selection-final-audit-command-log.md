
### 2026-11-16T18:40:08.611997+08:00

```bash
cat planning/work-order-qft-selection-final-audit.md planning/work-order-qft-selection-audit-now.md
```

```text
# 新增20题选题独立性审核

只审核选题，不改题包、不跑实验。读取本项目来源评审文件及即将生成的 `planning/qft-expansion-20-selection.json` 和 `.md`。

最终拟选20题：Radovanovic 11.8、11.12、11.13；Gelis 5、11、24+25（合一题）、26、29、37、42、43、49、52、67、69、70、72、73、75、80。

重点：是否恰好20个实质独立对象；Gelis80为标量QED；不采用原书82关于Born衰减就证明局域化的结论；不同时选11.14以免UV减除过密；42需完整源题核读才能声称已读。检查我们提出的可评分任务是否退化为背公式、任意增加复杂度、把证明题完全变成无物理的代数题。针对最薄弱者给具体收敛建议。

先读 `planning/source-notes/qft-gelis-all.txt` PDF342–346（实际题边界须核实）中第42题完整题面和解答，记录准确PDF/印刷页和关键公式。将核读与审核写 `planning/qft-expansion-final-audit.md`。没有生成最终表时先写42核读，随后通知主代理。每条shell命令执行前展示，并用 `tools/run_logged.py --log checks/qft-expansion-final-audit-command-log.md -- ...` 记录。只写这个审计文件，不修改主清单。
# 当前任务：新增20题遴选审核

读取 `planning/qft-expansion-20-selection.json` 和 `.md`（主代理正在生成，若尚不存在先审阅下列来源评审），以及 `planning/qft-expansion-radovanovic-review.md`、`planning/qft-expansion-gelis-review.md`、`planning/qft-expansion-gelis-thermal-review.md`。

拟选20题：Radovanovic 11.8、11.12、11.13；Gelis 5、11、24+25（一道）、26、29、37、42、43、49、52、67、69、70、72、73、75、80。新增ID qft-06 至 qft-25。

审核数量、来源页码、实质独立性、研究判断是否被公式代入代替、评分能否接受等价正确解、来源与原创扩展是否区分、资源规划是否当成实测值。尤其审查11、42、72和11.13这些相对薄弱的设计，提出具体修正，不要只说没完成。只写 `planning/qft-expansion-20-audit.md`，不改主清单和现有tasks。

第42题源文本 `planning/source-notes/qft-gelis-all.txt` PDF342–346 / 印刷171–175，完整题面和解答已由主代理核读。若需要可用 `python3 tools/read_qft_source_pages.py gelis 342:346` 核对。每条shell命令执行前向用户展示，用 `tools/run_logged.py --log checks/qft-expansion-20-audit-command-log.md -- COMMAND ...` 记录。不要读机密文件、不要连接服务器、不要运行模型测评。尽快给出可行动的审核并落盘。

exit_code=0
```
