
### 2026-11-16T18:40:24.845695+08:00

```bash
python3 tools/read_qft_source_pages.py gelis 342:346
```

```text

===== PDF PAGE 342 =====
42 LARGE- N EXPANSION IN SU(N) YANG–MILLS THEORY 171
• we apply the gauge transformation to both φ1 andφ2 in the inner product. This means
that, in the LSZ formulas, we must also use the gauge transformed plane waves, i.e.,
Φikp(x)= Ω†ij(x)δjk e−ip·x, Aμacλp(x)= Ω†ab(x)δbc ϵμλ (p)e−ip·x,
Ψi+ksp(x)= Ω†ij(x)δjk us(p)e−ip·x,Ψ i−ksp(x)= Ω†ij(x)δjk vs(p)e+ip·x,
respectively
• we limit ourselves to gauge transformations that become time-independent at large|x0|
(this property is necessary for theΩ to go through the time derivative). In other words,
asymptotically, the ﬁelds and their conjugate momenta must transform in the same way.
(In the case of gauge bosons, after theΩ’s have canceled, the extra term∂μθb cancels when
contracted with physical polarization vectors.)
42. Large- N Expansion in SU(N) Yang–Mills Theory Consider anSU(N) Yang–Mills
theory (i.e., a non-Abelian gauge theory without matter ﬁelds). The goal of this problem is
to study the behavior of graphs whenN → +∞, and to relate this behavior to a topological
property of these graphs. (Although we consider the example of vacuum to vacuum graphs in
this problem, the result is more general.)
42.a Draw all the one-particle-irreducible vacuum-to-vacuum graphs made only of gluons
up to three loops (explain why ghosts and gluons contribute similarly to the leading-N
behavior), and determine their leading behavior at largeN. Explain why this limit can
be obtained by replacing each gluon line by a double quark–antiquark line.
42.b Find a rescaling of the gauge ﬁeld in the Lagrangian so that the coupling constant g
appears as an overall prefactorg−2. For later convenience, introduce λ ≡ g2N.H o wd o
the various objects in the Feynman rules scale withλ andN?
42.c Determine the scaling withλ andN of a generic vacuum graph in terms of its numbers
of loops, vertices, propagators and faces (we call every closed quark loop in the double
line representation a face).
42.d Explain why χ ≡ (number of vertices)−( number of edges)+( number of faces) de-
pends only on the genus of the closed surface on which the graph is embedded, but not
on the other details of the graph.
42.e What is the value ofχ for a sphere, for a torus with a single handle, and for a torus with
h handles?


===== PDF PAGE 343 =====
172 3 NON-ABELIAN FIELDS
42.a Let us ﬁrst note that the ghost–antighost–gluon vertex has the same color dependence as
the three-gluon vertex. Likewise, the ghost propagator is identical to the gluon one as far as the
color factors are concerned. Therefore, graphs containing ghosts have the same color structure
as graphs of the same topology with the ghosts replaced by gluons. For this reason, we do
not need to consider ghosts in this discussion. Up to three loops, the one-particle-irreducible
vacuum graphs made only of gluons are the following:
∼O (N2), ∼O ((g2N)N2), ∼O ((g2N)N2),
∼O ((g2N)2N2), ∼O ((g2N)2N2), ∼O ((g2N)2N2),
∼O ((g2N)2N2), ∼O ((g2N)2N2), ∼O ((g2N)2).
(3.47)
The scaling of the ﬁrst graph is simply that of a gluon propagator with the two endpoints
connected to each other. The sum over the contracted color indices of this propagator gives a
factorδaa = N2 −1 ∼O (N2). For the other graphs, we ﬁrst use the following identity:
ifabc = 2 tr (taf tbf tcf )− 2 tr (tbf taf tcf ),
in order to view the color structure of the three-gluon vertex as that of a quark loop. The
next step is to use the su(N) Fierz identity in order to perform all the contractions taf ··· taf .
Recalling the diagrammatic representation of this identity,
(taf )ij(taf )kl =
kl
ji
= 12 − 12N ,
the leading term inN is obtained by replacing the gluon line by a pair of “quark–antiquark” lines
(i.e., the ﬁrst term of the Fierz identity). When we apply this procedure to vacuum diagrams,
we obtain only closed “quark” or “antiquark” loops, which in this estimate correspond to the
trace of the identity matrix in the fundamental representation, and therefore provide a factor N.
For instance, we have
∼ ∼O (N2), ∼ ∼O (g2N3).
The only missing rule to this recipe is how to handle the four-gluon vertices. For these, it is
sufﬁcient to note that the color structure of a four-gluon vertex is equivalent to that of graphs
with a pair of three-gluon vertices:
=
a b
cd
+
a b
cd
+
a b
cd
a b
cd
(3.48)


===== PDF PAGE 344 =====
42 LARGE- N EXPANSION IN SU(N) YANG–MILLS THEORY 173
42.b Interestingly, in the examples listed in (3.47), the ﬁrst eight graphs are of the form
N2(g2N)p, while the last one is of the form N0(g2N)p. Let us now try to understand this
pattern more generally. Recall the form of the Yang–Mills action,
SYM =− 12 ∫ d4x tr(FμνFμν), withFμν ≡ ∂μAν −∂νAμ −ig [Aμ,Aν].
Let us deﬁne ~Aμ ≡ gAμ. In terms of these rescaled ﬁelds, the Yang–Mills action becomes
SYM =− 12g2
∫
d4x tr(~Fμν~Fμν), with~Fμν ≡ ∂μ~Aν −∂ν~Aμ −i [~Aμ,~Aν].
With this rescaling, the coupling constantg appears only in an overall prefactor of the action,
and no longer in the ﬁeld strength. In view of the observations made on the examples of (3.47),
it is useful to rewrite it as
SYM =− N2λ ∫ d4x tr(~Fμν~Fμν), withλ ≡ g2N.
(λ is known as the ’t Hooft coupling.) In terms of these rescaled ﬁelds and couplings, the
various ingredients of the Feynman rules scale as
propagator ←→ λ/N,
vertex ←→ N/λ.
(Note that, after this rescaling, the behaviors of three-gluon and four-gluon vertices are the
same.) In addition, in the large-N limit, each gluon line is replaced by a double quark line.
Each closed quark line brings a factorN:
quark or antiquark loop ←→ N.
Each closed quark line corresponds to a face of the diagram, so we may equivalently count the
faces of the diagram. In order to properly account for the factorN coming from the outer quark
line, we must also count as one face the domain external to the graph (for instance, the ﬁrst
graph of (3.47) has two faces according to this prescription). Topologically, this is equivalent
to viewing a vacuum graph as a polytope embedded in three-dimensional space and counting
its faces, the propagators being the edges of the polytope.
42.c We are now equipped for counting the powers ofλ andN in a generic graph. Let us
denote by nV the number of vertices, bynI the number of internal propagators, and by nF the
number of faces of a vacuum graphG.W eh a v e
G∼ λnI −nV NnV −nI +nF ∼ λnL −1 Nχ(G), (3.49)
wherenL ≡ nI −nV +1 is the number of loops of the graph (i.e., the number of unconstrained
internal momenta). We have also deﬁnedχ(G) ≡ nV −nI +nF . This quantity is called the
Euler characteristic of the graph. Before we discuss its properties, note that in (3.49) it was not
necessary to introduce a distinction between three-gluon and four-gluon vertices. Indeed, if
we replace every four-gluon vertex by a pair of three-gluon vertices according to (3.48), we
increase bothnV andnI by one unit (whilenF remains unchanged), but this does not change
nL , norχ(G).


===== PDF PAGE 345 =====
174 3 NON-ABELIAN FIELDS
Figure 3.4 Illustration of the invariance of the Euler characteristic when a face of a polytope is
split into two faces.
χ = 2 χ = 2 χ = 2 χ = 2 χ = 2
Figure 3.5 Polytopes with the Euler characteristic of a2-sphere.
42.d The most important property of the Euler characteristic is that it is invariant under the
addition of lines to a graph, provided the new lines do not cross the existing ones, as illustrated
in Figure 3.4. In the left image, we show one face of a graph (here, a pentagonal face), with the
rest of the graph – in the shaded area – not represented. In the second image from the left, we
have added one line inside this face, connecting two of the existing vertices. When this is done,
the numbers of vertices, lines and faces vary byδnV = 0,δnI = 1,δnF = 1, respectively, and
the Euler characteristic does not change, δχ = 0. In the third image, the new line connects an
existing vertex and a newly created vertex. Thus, we have δnV = 1,δnI = 2,δnF = 1,b u t
stillδχ = 0. And in the last image, we have δnV = 2,δnI = 3,δnF = 1, and againδχ = 0.
This property of being unchanged when lines that do not lead to crossings are added
implies that the Euler characteristic does not depend on the details of the graph, but is in fact a
topological property of the minimal closed surface on which we can embed the graph without
line crossings. For instance, the ﬁrst ﬁve graphs of equation (3.47) can be embedded on a
2-sphere (recall that we must count as a face the domain outside the graph), while the last one
requires a torus.
42.e Conversely, we may use this invariance in order to compute the Euler characteristic of
all closed surfaces, as follows
• A tetrahedron (nV = 4,nI = 6,nF = 4) is topologically equivalent to a two-dimen-
sional sphere. Therefore, χ = 2 for the sphere, and for all the graphs whose minimal
embedding is the sphere. Figure 3.5 illustrates the invariance of the Euler characteristic
as one reﬁnes the triangulation of a surface.
• If we take a polytope and remove one of its faces to create a hole (while keeping the
edges and vertices on the boundary of the hole), we decrease the Euler characteristic
by one unit, since this operation corresponds to δnV = 0,δnI = 0,δnF =− 1.I fw e


===== PDF PAGE 346 =====
43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 175
χ = 2 χ = 1 χ = 0 χ = −1
Figure 3.6 Euler characteristics of polytopes with faces removed (indicated as hatched
triangles).
Figure 3.7 Deformation of a polytope with two holes into a torus. The Euler characteristic
does not change in the process.
remove two faces in order to create two holes, we haveδχ =− 2, etc. In Figure 3.6, we
have indicated the removed faces by hatched areas. Note that removing just the face, or
the face as well as the vertices and edges on the boundary, leads to the sameχ (indeed,
the boundary of a triangle has equal numbers of vertices and edges).
• If we create two holes and then bend the polytope to glue the boundaries of these holes,
we also haveδχ =− 2, as illustrated in Figure 3.7 (we show three stages of this process;
the Euler characteristic is equal to χ = 0 at all stages). However, this manipulation
creates a handle in the polytope: for instance, it transforms a sphere into a torus with
one handle, a torus with one handle into a torus with two handles, etc. Therefore, the
Euler characteristic of a closed surface withh handles isχ = 2 −2h.
Thus, the formula (3.49) provides a one-to-one correspondence between the order in N of
a vacuum graph (after we have absorbed a factor N in the deﬁnition of λ) and the genus of
the surface on which the graph may be embedded without line crossings. If we consider the
limit of largeN at ﬁxedλ, the leading graphs are those that can be embedded on a sphere (the
standard QFT terminology for these graphs is to call them planar graphs, because the sphere is
topologically equivalent to a plane if we remove its north pole; the large-N limit is also called
the planar approximation), the next-to-leading ones are those that can be embedded on a torus,
etc.
43. Soft Radiation and Antenna Effects in QCD The goal of this problem is to study soft
gluon radiation from a hard QCD process. The main result is that when a soft gluon is emitted
from a quark–antiquark pair in a color-singlet state, its emission at large angles is forbidden.


exit_code=0
```
