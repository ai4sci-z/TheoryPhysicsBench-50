# tm-05开发验收

平台：Linux-6.12.76-linuxkit-aarch64-with-glibc2.36，实际Docker Linux，无GPU。22项检查全部通过。

实测简单基线原始误差 1.04099141564 百分点；参考误差 1.22807294158e-08 百分点；容差 2e-05 百分点。参考执行 0.2906秒；基线 0.4012秒。

验证包含独立真值、基线/参考、空提交、ID重排、舍入等价解、全零错误物理解、缺失/重复工况、非有限和错误类型、反馈及真实评分入口。详见同名calibration.json和truth-validation.json。

Harbor oracle/nop另存runs目录；课程指定Codex三次正式测评没有由上述开发检查替代。
