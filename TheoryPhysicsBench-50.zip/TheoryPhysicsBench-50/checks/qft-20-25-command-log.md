
### 2026-11-16T21:56:59.290743+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(str(p) for p in Path(".").resolve().parents for p in [p/"AGENTS.md"] if p.exists()))'
```

```text

### 2026-11-16T21:56:59.290695+08:00

```bash
cat README.md planning/qft-expansion-20-audit.md tools/run_qft04_checks.py
```

```text
# TheoryPhysicsBench-30

面向课程指定 Codex 的理论物理科学任务集。题目来自用户提供的六门课程教材与习题材料，通过物理建模、数值计算、参数反演等任务改造，交付可独立验证的 Harbor 题包。

## 题集规模

| 学科 | 编号前缀 | 计划题数 | 已有完整开发题包 |
|---|---|---:|---|
| 理论力学 | tm | 5 | tm-01、tm-02 |
| 电动力学 | ed | 5 | ed-01 |
| 热力学与统计物理 | sp | 5 | sp-01 |
| 量子力学 | qm | 5 | qm-01 |
| 量子场论 | qft | 5 | — |
| 广义相对论 | gr | 5 | — |

共 30 道独立问题。理论力学属于理论物理，`tm-01` 的固定端质点链与简正振动辨识保留在本题集中。各题需要不同的物理推理和计算工作，不将同一道题的换参数版本计为多道。

## 已完成开发验证的题目

**tm-01：局部振动观测下的弹簧链损伤辨识。** 从三组含噪位移记录恢复八质点链的九个非均匀刚度与两处软化位置，以参数精度、隐藏运动预测和位置识别共同评分。

- [题面](tasks/tm-01/instruction.md)
- [物理推导和参考解](tasks/tm-01/solution/README.md)
- [教材出处及已有评测对照](checks/tm-01-sources.md)
- [公开材料与隐藏验证划分](checks/tm-01-materials-and-fairness.md)
- [Docker / Harbor 验证记录](checks/tm-01-validation.md)
- [完整校准数据](checks/tm-01-calibration.json)

已完成 Docker Linux 的基线、参考解与评分样例验证，11 项检查全部通过；Harbor 0.24.0 的 oracle=1、nop=0。参考解在此次 4 CPU/4 GB 容器内耗时约 1.67 秒，无需 GPU。

课程指定 Codex 的每题三次独立正式测评在题集冻结后执行。`oracle` 记录用于核对参考解和评分链路，正式模型结果单独保存。

**tm-02：非开普勒中心势中束缚轨道的拱点进动。** 从有效势求转折点、径向周期与完整方位角，处理端点奇性，并与独立运动方程积分核对。近圆近似基线误差 10.4201 个百分点，完整轨道积分参考误差约 1.07e-11；11 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/tm-02/instruction.md)、[推导](tasks/tm-02/solution/README.md)、[验证记录](checks/tm-02-validation.md)。

**sp-01：平均场铁磁体的多分支平衡与亚稳态。** 找全驻点，区分局部稳定性与平衡态，计算分支磁化率。Landau 基线误差 3.1082，完整参考约 9.49e-14；13 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/sp-01/instruction.md)、[推导](tasks/sp-01/solution/README.md)、[验收记录](checks/sp-01-validation.md)。

**qm-01：非对称双 δ 势阱的束缚态与空间局域化。** 恢复全部负能态及左半轴概率，处理近阈值浅态和非对称混合。弱耦合基线误差 41.8244，完整参考约 1.00e-13；11 项检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/qm-01/instruction.md)、[推导](tasks/qm-01/solution/README.md)、[验收记录](checks/qm-01-validation.md)。

**ed-01：点电荷与介质核壳球的反作用、自力反号及径向平衡。** 由多极边界匹配计算极化能、自力和全部径向平衡点，以尾界保证近表面收敛。偶极基线误差 65.6807，完整参考约 8.16e-10；14 项 Linux 检查通过，Harbor oracle=1、nop=0。见 [题面](tasks/ed-01/instruction.md)、[推导](tasks/ed-01/solution/README.md)、[验收记录](checks/ed-01-validation.md)。

## 目录

```text
tasks/       Harbor 任务；每题含题面、环境、参考解和 verifier
checks/      出处、校准、材料划分与验收证据
runs/        已保存的 Harbor 运行记录
planning/    教材 OCR 索引和选题笔记
tools/       本地制作与检查工具
```

Agent 镜像只带该题的公开材料；`solution/` 与 `tests/private/` 供参考解及独立 verifier 使用。原始教材保留在原路径，题包不附扫描教材或习题答案页。
# 新增 20 道量子场论题：独立选题审核

日期：2026-11-16。审计对象是新增选题与研究任务设计，不代表 20 道 Harbor 包已实现、通过测试或完成课程模型测评。

## 结论

`qft-06` 至 `qft-25` 在来源题号、连续编号和数量上成立：Radovanović 3 道、Gelis 17 道；Gelis 24 与 25 合并为一道，因此没有把同一 Casimir 现象拆分计数。候选覆盖微扰重整化、解析结构、红外安全、边界量子场论、非微扰真空、规范场颜色结构、拓扑、格点、热场论与外场产对。它们不是 20 个参数变体，核心可观测量和判定依据大多互不相同。

这份清单适合作为“20 道高难候选题的遴选结果”，尚不足以宣称“20 道均已形成高质量、独立可运行的 benchmark 任务”。其中 17 题可进入逐题规格化；`qft-22` 应先落实中心有效系综及公开相判据；`qft-10` 与 `qft-24` 为高工程风险候选，必须先完成可独立复现的题目核心，再保留在最终20题内。`qft-17` 也应收窄为一个场构型族，避免将两项独立作业硬装进同题。

## 数量、来源与核读范围

- 清单 JSON 有且仅有 20 项，ID 连续为 `qft-06` 至 `qft-25`，没有重复源题；Gelis 24+25 按一题计。
- Radovanović 来源为 11.8、11.12、11.13；Gelis 来源为 5、11、24、25、26、29、37、42、43、49、52、67、69、70、72、73、75、80。
- 页码格式明确区分 PDF 实际页和书页。所有 Gelis 页码均在 PDF 375 页范围内；Gelis 章节有重排，逐题登记而非套用统一偏移。
- 本次独立重新读取 Gelis PDF 342–346。42 题原文明确给出固定 `λ=g²N` 时 `G ∼ λ^(nL−1)N^χ`、`χ=nV−nI+nF`，并由闭曲面亏格得 `χ=2−2h`；这与主清单来源页码相符。指定有限图集、精确 SU(N) 收缩和有限 N 误差是本项目的原创扩展，不能归称原书结论。
- 对其余原题范围与页码，依据三份完整来源核读评审核查；不是声称本次重新逐页渲染了两本书全部选中页。
- 主清单把资源写为计划值且 `measured:false`，没有把 CPU、内存或时限冒充实测。题目难度也注明尚未完成课程统一配置下的 Codex 三次独立测评。

## 逐题独立性审核

| ID | 审核意见 |
|---|---|
| QFT-06 | 保留。逐图抵消 Goldstone 自能，和 QFT-12 的大 N 动力学质量隙不同；须核完五图与非零动量减除。 |
| QFT-07 | 保留。多场赝标量 Yukawa 的一圈算符闭合，不等同 QFT-03 已知 beta 函数的 RG 演化。需锁定 `γ5`、维数和减除约定。 |
| QFT-08 | 保留。二维 Schwinger 模型的调节极限、横向极化与守恒源响应，不与 QFT-25 的外场标量 Bogoliubov 产对重复。 |
| QFT-09 | 保留。Landau 方程分支的完备性和物理夹挤，与 QFT-01 固定谱积分不同；评分真值必须区分必要条件和真实奇点。 |
| QFT-10 | 有条件保留，优先级 C。Gelis 11 的核心是简并态求和与红外消除，原题没有给出本清单所需的具体 NLO 辐射过程。必须先推导并公开同一自洽过程的实/虚贡献、相空间和局部减除；若最后只有有限矩阵恒等式或软定理口号，则应剔除，不能计入高难 QFT 题。 |
| QFT-11 | 保留。两道原题围绕同一边界真空相互作用，合并合理。有限 δ 壁强度及弱/强耦合插值是原创扩展，需由匹配条件推导并用两条独立路线验证。 |
| QFT-12 | 保留。Gross–Neveu 模型的行列式、非解析质量尺度与真空选择，与 QFT-06 微扰 Ward 抵消不同；必须标清 leading large-N，而非有限 N 精确结果。 |
| QFT-13 | 保留。复杂作用量的矩递推分支、截断动力学稳定性和强相消采样问题具有独立判别对象；应把随机采样统计误差与确定性矩真值分开。 |
| QFT-14 | 保留。Wong 方程沿固定轨迹的非阿贝尔路径序输运，与 QFT-17 的空间拓扑分类不同；固定轨迹需标为 eikonal 近似。 |
| QFT-15 | 保留。大 N 颜色收缩和 ribbon 图亏格，与 QFT-16 的软辐射及 QFT-21 的格点手征指数不同。限于真正来自规范理论的图，并把双线拓扑项与完整图颜色因子分开。 |
| QFT-16 | 保留。软天线的色守恒、干涉和角接受度，与 QFT-10 的红外安全测量函数不同。应坚持完整硬事件；非单态 `q q̄` 不能单独承担守恒色流。 |
| QFT-17 | 保留但收窄规格。映射绕数与四维场拓扑荷通过边界关系相联，主题成立；当前“映射族 + 多个四维场构型 + BPST”可能扩成数道题。限定一个公开场构型族，以独立绕数和体积分作为同一拓扑荷的双重验证；BPST/action bound 只在补齐来源与推导后纳入。 |
| QFT-18 | 保留。六点 NMHV 树振幅的递推、shift 等价性和物理因子化，和 QFT-19 的一圈有理项不同。控制复在壳动量生成器与伪极点误差即可。 |
| QFT-19 | 保留。D 维切割所携带的额外维信息和有限有理项，和普通 UV 反项或树递推有实质区别。必须区分无尺度积分的 UV/IR 极点与完整积分，公开 regulator。 |
| QFT-20 | 保留。随机背景 Dirac 低谱、热力学/手征极限和 Banks–Casher 关系，不同于 QFT-12 的辅助场 gap 方程。必须公开完整正负谱、体积归一化及零模规则。 |
| QFT-21 | 保留。格点动量核所有 Weyl 零点的手征指数与物种倍增是动量空间全局约束，不与 QFT-17 的实空间规范场绕数重复。选根可证明完备的解析核族。 |
| QFT-22 | 有条件保留，优先级 B。有限体积扇区平均可使 Polyakov 环期望为零，不能直接当作禁闭；这是有价值的判断题。必须给出明确可枚举的中心有效系综、转移矩阵或权重和物相规则，否则会退化为矩阵乘法和概念辨析。结论不得外推为真实 QCD 相变数据。 |
| QFT-23 | 保留。热平衡介质的 retarded HTL 集体响应、Landau 阻尼与色散根区别于 QFT-01 的零温阈值，也区别于 QFT-24 的碰撞重求和。固定各向同性和光锥/静态极限处方。 |
| QFT-24 | 有条件保留，优先级 C。LPM 形成时间内多次散射与 QFT-23 的无碰撞 HTL、QFT-16 的真空天线都不同，物理主题足够独立；实现工作量显著高。需先固定正定差分核与变量约定，分别让动量空间与冲击参数路线收敛，校正原书扩散展开的符号问题，并实测 CPU/内存。未通过双路线检验前不能宣称题包完成。 |
| QFT-25 | 保留。Gelis 80 明确是标量 QED 外场产对；玻色 Bogoliubov 关系、模对统计和相干双脉冲区别于 QFT-08 的动态光子质量。评分应以规范不变量/固定相位基为准，不能使用费米子归一化或 Poisson 分布。 |

## 最终纳入建议

建议把这 20 题继续保留为新增 QFT 候选题库，并按以下门槛处理：

1. `qft-10`：完整 NLO 过程、独立实虚抵消和出处落实后才冻结；不能落实则从20题中换出。
2. `qft-22`：明确有限体积系综、扇区混合生成方式及可判定分类，避免只有单环计算。
3. `qft-24`：核符号、方程边界、双路线收敛和实测资源全部完成后才冻结；不得把扩散近似当完整核真值。
4. `qft-17`：一道题只用一个拓扑场构型族；把映射积分和场强积分作为交叉验证，不并列加入未经范围控制的 BPST 证明任务。
5. 其余 16 道进入逐题规格化时，也要从题包材料和 verifier 明确题面来源与原创扩展；这份遴选审核本身不替代题包级正确性、资源测试或模型评测。

来源评审：[`qft-expansion-radovanovic-review.md`](qft-expansion-radovanovic-review.md)、[`qft-expansion-gelis-review.md`](qft-expansion-gelis-review.md)、[`qft-expansion-gelis-thermal-review.md`](qft-expansion-gelis-thermal-review.md)。主清单：[`qft-expansion-20-selection.md`](qft-expansion-20-selection.md)。
"""Local Linux calibration and physical regression checks for qft-04."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/qft-04';DATA=TASK/'environment/public';TESTS=TASK/'tests'
sys.path.insert(0,str(TESTS))


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--calibrate',action='store_true');args=parser.parse_args()
    scorer=load('qft04_score',TESTS/'score.py');quality=load('qft04_quality',TESTS/'quality_score.py')
    answers={};cases={};runtime={}
    with tempfile.TemporaryDirectory(prefix='qft04-check-') as directory:
        temp=Path(directory)
        for name,script in (('baseline','baseline.py'),('reference','solve.py')):
            output=temp/f'{name}.json';started=time.perf_counter()
            subprocess.run([sys.executable,str(TASK/'solution'/script),'--data-root',str(DATA),'--output',str(output)],check=True,capture_output=True,text=True)
            runtime[f'{name}_seconds']=time.perf_counter()-started;answers[name]=json.loads(output.read_text())
        answers.update(load('qft04_cases',TESTS/'development_cases.py').make_cases(answers['reference']))
        answers['independent_truth']=json.loads((TESTS/'private/truth.json').read_text())
        for name,answer in answers.items():
            raw,detail=scorer.evaluate(answer,DATA,TESTS/'private');cases[name]={'raw_metric':raw,**detail,'status':'invalid' if raw is None else 'completed'}
        measured={'kind':'continuous','metric_name':'康普顿相干振幅与实验室接受能谱误差','unit':'百分点','direction':'minimize','baseline':cases['baseline']['raw_metric'],'reference':cases['reference']['raw_metric'],'tolerance':1e-6}
        metric=measured if args.calibrate else json.loads((TESTS/'metric.json').read_text());quality.validate_metric(metric)
        for item in cases.values():item['score']=quality.quality_score(metric,item['raw_metric'],item['status'])
        testroot=temp/'tests';testroot.mkdir();(testroot/'metric.json').write_text(json.dumps(metric));entries={}
        for name in ('reference','empty','missing_empty_field','huge_integer'):
            if name not in ('reference','empty'):(temp/f'{name}.json').write_text(json.dumps(answers[name]))
            logs=temp/f'logs-{name}'
            env=dict(os.environ,TASK_DATA_ROOT=str(DATA),TASK_PRIVATE_ROOT=str(TESTS/'private'),TASK_TESTS_ROOT=str(testroot),TASK_ANSWER_PATH=str(temp/f'{name}.json'),VERIFIER_LOG_ROOT=str(logs))
            subprocess.run(['bash',str(TESTS/'test.sh')],env=env,check=True,capture_output=True,text=True)
            entries[name]=json.loads((logs/'metrics.json').read_text())
        feedback=json.loads(subprocess.run([sys.executable,str(DATA/'feedback.py'),str(temp/'reference.json')],check=True,capture_output=True,text=True).stdout)
    checks={
        'reference_matches_independent_truth':measured['reference']<metric['tolerance'],
        'reference_improves_baseline':measured['baseline']-measured['reference']>metric['tolerance'],
        'registered_endpoints_match':all(abs(measured[k]-metric[k])<metric['tolerance'] for k in ('baseline','reference')),
        'baseline_zero_reference_one':cases['baseline']['score']==0 and cases['reference']['score']==1,
        'equivalent_order_same':cases['equivalent']['raw_metric']==cases['reference']['raw_metric'],
        'independent_truth_full_credit':cases['independent_truth']['score']==1,
        'wrong_physics_penalized':cases['wrong']['raw_metric']>measured['reference']+1,
        'missing_interference_penalized':cases['no_interference']['raw_metric']>measured['reference']+.1,
        'wrong_boost_penalized':cases['no_boost']['raw_metric']>measured['reference']+.1,
        'wrong_energy_quantiles_penalized':cases['wrong_quantile_order']['raw_metric']>measured['reference']+.01,
        'false_nonempty_penalized':cases['fake_nonempty']['raw_metric']>measured['reference']+.1,
        'false_empty_constant_spectrum_penalized':cases['false_empty']['raw_metric']>measured['reference']+.1,
        'invalid_answers_rejected':all(cases[n]['status']=='invalid' and cases[n]['score']==0 for n in ('duplicate','boolean','nonfinite','malformed','missing_empty_field','huge_integer')),
        'constant_energy_quantiles_correct':max(answers['reference']['cases'][4]['energy_quantiles'])-min(answers['reference']['cases'][4]['energy_quantiles'])==0,
        'empty_window_conditions_undefined':answers['reference']['cases'][5]['mean_energy'] is None and answers['reference']['cases'][5]['energy_quantiles'] is None,
        'ward_identity_total_invariant':all(abs(item['total']-item['gauge_shifted_total'])<1e-9 for item in answers['reference']['probes']),
        'verifier_reference_one_empty_zero':entries['reference']['score']==1 and entries['empty']['score']==0 and entries['empty']['status']=='invalid',
        'verifier_malformed_boundary_cases_zero':all(entries[n]['score']==0 and entries[n]['status']=='invalid' for n in ('missing_empty_field','huge_integer')),
        'public_feedback_works':feedback['valid'] and len(feedback['cases'])==7,
        'course_quality_score_unchanged':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes(),
    }
    report={'metric':metric,'cases':cases,'runtime':{'platform':platform.platform(),'python':platform.python_version(),**runtime},'checks':checks,'verifier_entries':entries}
    print(json.dumps({'metric':metric,'scores':{k:{f:v[f] for f in ('raw_metric','score','status')} for k,v in cases.items()},'runtime':report['runtime'],'checks':checks},ensure_ascii=False,indent=2))
    if not all(checks.values()):raise SystemExit('qft-04 checks failed')
    if args.calibrate:
        for path in (DATA/'metric.json',TESTS/'metric.json'):path.write_text(json.dumps(metric,ensure_ascii=False,indent=2)+'\n')
    elif json.loads((DATA/'metric.json').read_text())!=metric:raise SystemExit('metric copies differ')
    (ROOT/'checks/qft-04-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    saved=ROOT/'runs/qft-04/development-answers';saved.mkdir(parents=True,exist_ok=True)
    for name,answer in answers.items():(saved/f'{name}.json').write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()

exit_code=0
```


exit_code=0
```

### 2026-11-16T21:57:14.997697+08:00

```bash
cat tasks/qft-04/task.toml tasks/qft-04/environment/Dockerfile tasks/qft-04/tests/test.sh tasks/qft-04/tests/score.py tools/run_pending_harbor.py
```

```text

### 2026-11-16T21:57:14.997719+08:00

```bash
python3 -c 'from pathlib import Path; import json; d=json.loads(Path("planning/qft-expansion-20-selection.json").read_text()); print(json.dumps(d,ensure_ascii=False,indent=2))'
```

```text
schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/qft-04"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 1200.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "no-network"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2

COPY requirements.txt /tmp/requirements.txt
RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
 && useradd --uid 1000 --create-home student \
 && mkdir -p /app/data /app/output \
 && chown -R student:student /app

COPY public/ /app/data/
WORKDIR /app
USER student
#!/bin/bash
set -euo pipefail
python3 "$(dirname -- "$0")/score.py"
import json
import os
from pathlib import Path
import sys
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get('TASK_DATA_ROOT','/app/data'));private=Path(private_root or os.environ.get('TASK_PRIVATE_ROOT','/tests/private'))
    sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    model=load_model(data);parsed,reason=validate_answer(answer,model)
    if reason:return None,{'reason':reason}
    truth=json.loads((private/'truth.json').read_text());scoring=model['scoring'];floor=scoring['relative_floor'];details=[]
    def relative(actual,expected):return min(1,abs(actual-expected)/max(floor,abs(expected)))
    for expected in truth['cases']:
        actual=parsed['cases'][expected['id']]
        parts={name:relative(actual[name],expected[name]) for name in ('sigma','accepted_sigma','acceptance')}
        for name in ('mean_energy','energy_quantiles','accepted_cos_interval'):
            a,b=actual[name],expected[name]
            if a is None or b is None:parts[name]=float(a!=b)
            elif name=='accepted_cos_interval':parts[name]=sum(min(1,abs(x-y)/2) for x,y in zip(a,b))/2
            elif isinstance(b,list):parts[name]=sum(relative(x,y) for x,y in zip(a,b))/len(b)
            else:parts[name]=relative(a,b)
        error=sum(scoring['case_parts'][name]*value for name,value in parts.items());details.append({'id':expected['id'],'error':error,'parts':parts})
    probe_details=[]
    for expected in truth['probes']:
        actual=parsed['probes'][expected['id']]
        errors={name:min(1,abs(actual[name]-expected[name])/max(scoring['probe_floor'],abs(expected[name]))) for name in ('s_squared','u_squared','interference','total','gauge_shifted_total')}
        probe_details.append({'id':expected['id'],'error':sum(errors.values())/len(errors),'parts':errors})
    error=scoring['case_weight']*sum(x['error'] for x in details)/len(details)+scoring['probe_weight']*sum(x['error'] for x in probe_details)/len(probe_details)
    return 100*error,{'cases':details,'probes':probe_details}


def main():
    logs=Path(os.environ.get('VERIFIER_LOG_ROOT','/logs/verifier'));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get('TASK_TESTS_ROOT','/tests'));answer=Path(os.environ.get('TASK_ANSWER_PATH','/app/output/answer.json'));metric=json.loads((tests/'metric.json').read_text())
    try:payload=json.loads(answer.read_text())
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{'reason':'没有有效 JSON 产物'}
    else:raw,details=evaluate(payload)
    status='invalid' if raw is None else 'completed';score=quality_score(metric,raw,status)
    details.update(raw_metric=raw,score=score,status=status)
    (logs/'metrics.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n');(logs/'reward.txt').write_text(f'{score}\n')


if __name__=='__main__':main()
"""Sequential local oracle/nop checks for tasks already calibrated."""
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
for identifier in sys.argv[1:]:
    command=[sys.executable,str(root/'tools/run_logged.py'),'--log',f'checks/{identifier}-command-log.md',
             '--',sys.executable,str(root/'tools/run_harbor_local_checks.py'),identifier,'--macos-compat']
    subprocess.run(command,cwd=root,check=True)

exit_code=0
```
{
  "name": "TheoryPhysicsBench：新增20道量子场论任务遴选",
  "schema_version": 1,
  "status": "selected_for_development_not_frozen",
  "research_goal": "在受控量子场论模型中，从理论约束与公开材料构造可计算方案，辨别物理分支、近似适用性和数值伪解，以独立物理量验证推断。",
  "scope": "原30题开发计划保留；本清单新增qft-06至qft-25，不是课程正式benchmark.json。",
  "difficulty_status": "按理论工作量与研究判断筛选，尚无课程统一Codex三次测评难度结果。",
  "resource_plan": {
    "cpu": 4,
    "memory_gib": 4,
    "gpu": 0,
    "agent_timeout_seconds": 1200,
    "verifier_timeout_seconds": 120,
    "measured": false
  },
  "sources": {
    "R": {
      "author": "Voja Radovanović",
      "title": "Problem Book in Quantum Field Theory",
      "edition": "Second Edition, 2008",
      "path": "/Users/ai4s/Downloads/Problem Book in Quantum Field Theory.pdf",
      "sha256": "26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db",
      "review": "planning/qft-expansion-radovanovic-review.md"
    },
    "G": {
      "author": "François Gelis",
      "title": "Problems in Quantum Field Theory",
      "path": "/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf",
      "sha256": "7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5",
      "review": "planning/qft-expansion-gelis-review.md",
      "thermal_review": "planning/qft-expansion-gelis-thermal-review.md",
      "page_warning": "PDF章节重排，页码按实际文件逐段登记，不用全书统一偏移。"
    }
  },
  "tasks": [
    {
      "id": "qft-06",
      "title": "Goldstone 模式的一圈质量保护与漏图诊断",
      "source": "R",
      "problems": [
        "11.8"
      ],
      "pages": [
        {
          "pdf": [
            65,
            65
          ],
          "printed": [
            63,
            63
          ],
          "role": "题面"
        },
        {
          "pdf": [
            219,
            220
          ],
          "printed": [
            221,
            222
          ],
          "role": "解答"
        }
      ],
      "reading": "完整题面与相关解答已核读；关键原页已视觉核对。",
      "original_work": "移位后的两标量模型中枚举五类一圈贡献，含真空tadpole，用同一正则化和真空条件证明Σπ(0)=0。",
      "task_design": "从公开拉氏量和图拓扑重建各图系数，计算零动量抵消证书和空间样动量处的有限响应；诊断三组删图或错因子方案产生的伪质量。",
      "public_materials": "固定模型、顶点归一化、欧氏外动量、共同减除方案和待诊断方案；不公开正确系数表。",
      "deliverables": [
        "各图master-integral系数",
        "零动量抵消与真空条件残差",
        "有限动量响应",
        "错误方案的伪质量及故障位置"
      ],
      "verification": [
        "独立Wick组合与符号系数核算",
        "高精度参数积分及对称性关系交叉检查"
      ],
      "baseline": "逐图直接积分但使用有限精度和朴素减除；漏图模型只作错误对照，不充当故意降分的基线。",
      "difficulty": "图组合、真空移位、对称因子与对称性约束必须同时自洽，背诵Goldstone定理不能完成非零动量结果。",
      "independence": "区别既有真空极化阈值、树图Ward检查及qft-12的非微扰有效势。",
      "implementation_gate": "独立核对全部五图系数、有限响应的UV减除与合法等价表示。"
    },
    {
      "id": "qft-07",
      "title": "赝标量 Yukawa 理论的反项闭合与有限振幅",
      "source": "R",
      "problems": [
        "11.12"
      ],
      "pages": [
        {
          "pdf": [
            66,
            66
          ],
          "printed": [
            64,
            64
          ],
          "role": "题面"
        },
        {
          "pdf": [
            225,
            231
          ],
          "printed": [
            227,
            233
          ],
          "role": "解答"
        }
      ],
      "reading": "完整题面与解答已核读；关键原页已视觉核对。",
      "original_work": "由幂计数及一圈费米子/标量两点、Yukawa三点和标量四点图，构造闭合的局域反项，包括费米盒图排列和耦合混合。",
      "task_design": "判断几个候选算符基是否重整化闭合，独立提取全部UV极点多项式，构造明确MS方案下的有限欧氏响应，定位删除φ⁴反项后的剩余发散。",
      "public_materials": "拉氏量、γ5与维数约定、非例外运动学、允许算符和图枚举规则。",
      "deliverables": [
        "发散振幅及最小反项基",
        "UV极点系数",
        "有限两点/三点/四点响应",
        "方案闭合性证书"
      ],
      "verification": [
        "Gamma函数Laurent展开及独立Dirac迹/排列计数",
        "独立参数积分和改变减除尺度的一致性检验"
      ],
      "baseline": "直接维数积分加低阶参数求积的完整一圈起点。",
      "difficulty": "多场结构、闭费米环符号、γ5和六个盒图排列共同决定反项混合；不拆小问计题。",
      "independence": "qft-03只演化已给beta函数，本题从图构造反项；六维φ³不同时入选。",
      "implementation_gate": "固定ε和MS约定，重新推导不能机械抄用书中的质量壳有限项。"
    },
    {
      "id": "qft-08",
      "title": "二维 Schwinger 模型的质量生成与守恒源响应",
      "source": "R",
      "problems": [
        "11.13"
      ],
      "pages": [
        {
          "pdf": [
            66,
            66
          ],
          "printed": [
            64,
            64
          ],
          "role": "题面"
        },
        {
          "pdf": [
            231,
            232
          ],
          "printed": [
            233,
            234
          ],
          "role": "解答"
        }
      ],
      "reading": "完整题面与解答已核读；关键原页已视觉核对。",
      "original_work": "保留D=2−ε的张量结构计算横向极化，再Dyson求和，在守恒源响应中得到mγ²=e²/π。",
      "task_design": "重建调节后极化和横向传播子，计算有限时间守恒源的频域与时域响应；比较规范参数变化及提前取二维极限的错误方案。",
      "public_materials": "二维QED作用量、retarded处方、由流函数生成的守恒源、查询网格与分布约定。",
      "deliverables": [
        "极化张量及横向残差",
        "质量极点与留数",
        "规范不变源响应",
        "有限时域响应与错误极限诊断"
      ],
      "verification": [
        "保留ε的张量参数积分与Laurent极限",
        "横向谱表示和独立因果初值响应"
      ],
      "baseline": "有明确时间窗和粗离散的谱积分响应。",
      "difficulty": "有限质量来自调节极限，纵向规范项只能在守恒源投影后消去；单报e/√π不得满分。",
      "independence": "不同于qft-01的四维阈值谱，也不同于qft-25的外场标量产对。",
      "implementation_gate": "固定源、边界与极点处方，推导有限响应后再校准，避免靠人为超严容差制造难度。"
    },
    {
      "id": "qft-09",
      "title": "Landau 方程的物理奇点分支与夹挤证书",
      "source": "G",
      "problems": [
        "5"
      ],
      "pages": [
        {
          "pdf": [
            34,
            40
          ],
          "printed": [
            22,
            28
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "推导Feynman参数在壳条件和逐圈方程，找出无质量三角图两条共线支、一条软支，以Coleman–Norton图像排除伪分支。",
      "task_design": "对同一研究任务中的有限图集枚举物理奇点分支，给非负参数、在壳与闭环证书，区分可绕过的分母零点、端点和夹挤。",
      "public_materials": "动量定向、质量和外线运动学、Feynman参数约束、候选缩图及明确分子。",
      "deliverables": [
        "完整分支列表与分类",
        "归一化参数证书",
        "在壳与逐圈残差",
        "被排除分支的不可行条件"
      ],
      "verification": [
        "有理消元及边界分支枚举",
        "评分器代回方程并检查正性、物理域和完整性"
      ],
      "baseline": "多初值数值找根与残差过滤，不承诺完整枚举。",
      "difficulty": "数值零点不等于实际奇点，物理域、端点和分子抵消必须区别。",
      "independence": "研究分支结构而非重复qft-01固定一圈函数的求积。",
      "implementation_gate": "为选定图族建立可证明完备的分支真值；Landau必要条件不直接当充分条件。"
    },
    {
      "id": "qft-10",
      "title": "简并态、探测分辨率与红外安全可观测量",
      "source": "G",
      "problems": [
        "11"
      ],
      "pages": [
        {
          "pdf": [
            55,
            61
          ],
          "printed": [
            43,
            49
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；具体辐射过程为待推导原创扩展。",
      "original_work": "用散射算符端点简并子空间及幺正性，证明完整初末不可分辨态求和消除红外奇异；有明确连续谱及简并集合假设。",
      "task_design": "在单一中性源到无质量带电费米子对的受控NLO辐射模型中，比较软/共线安全和不安全的测量函数；组合真实与虚修正，选择探测分辨率，重建有限inclusive量及残余调节器对数。",
      "public_materials": "一套完整且自洽的实/虚修正、相空间、局部减除起点及测量函数定义；所需初态是否须平均由具体过程明定。",
      "deliverables": [
        "测量函数的软/共线极限证书",
        "inclusive修正",
        "调节器扫描及对数残项",
        "安全性分类和分辨率下的物理预测"
      ],
      "verification": [
        "局部减除的独立有限积分",
        "相空间切片法加解析软/共线抵消，逐步外推切片参数"
      ],
      "baseline": "固定相空间切片与普通求积的物理完整起点。",
      "difficulty": "局部实虚相消、测量定义和实验不可分辨性共同决定有限答案，不能仅验证矩阵范数恒等式。",
      "independence": "qft-16研究规范完整的非阿贝尔真空角分布；本题研究inclusive可观测量及调节器消除。",
      "implementation_gate": "优先级C：先独立推导一个完整具体NLO过程并补来源；若只完成有限矩阵玩具或软口号则不计作完成题。"
    },
    {
      "id": "qft-11",
      "title": "Casimir 相互作用的双路线重构与有限壁强度",
      "source": "G",
      "problems": [
        "24",
        "25"
      ],
      "pages": [
        {
          "pdf": [
            274,
            277
          ],
          "printed": [
            103,
            106
          ],
          "role": "24题完整题面与解答"
        },
        {
          "pdf": [
            278,
            281
          ],
          "printed": [
            107,
            110
          ],
          "role": "25题完整题面与解答"
        }
      ],
      "reading": "两题完整相关段落已核读；合为一道。",
      "original_work": "零点模和减去体积项，用Euler–Maclaurin得到能量与应力；以δ壁的泛函行列式和ζ函数独立复现强壁极限。",
      "task_design": "构造有限正壁强度的标量真空相互作用，减去孤立壁自能，计算距离依赖的能量和力，比较弱壁及Dirichlet极限并证明调节独立性。",
      "public_materials": "δ壁作用量、跳跃匹配条件、减除定义、无量纲壁强度和距离查询。",
      "deliverables": [
        "相互作用能与力",
        "匹配/谱条件证书",
        "强壁与弱壁误差",
        "应力与能量导数的一致性"
      ],
      "verification": [
        "独立反射系数的Euclidean行列式积分",
        "谱密度/相移或调节模和减除，强壁用原书解析结果校验"
      ],
      "baseline": "固定截断的谱或积分求积。",
      "difficulty": "必须正确分离不可观测壁自能与有限壁间力，不能只抄−π²/(1440a³)。",
      "independence": "边界真空相互作用，区别现有ED腔波导的经典传播及有限温统计题。",
      "implementation_gate": "有限强度公式须由匹配条件独立推导，不归称原书已完成。"
    },
    {
      "id": "qft-12",
      "title": "Gross–Neveu 行列式、质量隙与真空选择",
      "source": "G",
      "problems": [
        "26"
      ],
      "pages": [
        {
          "pdf": [
            282,
            285
          ],
          "printed": [
            111,
            114
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "引入辅助场、积分费米子并重整化有效势，得到非解析质量尺度和leading large-N真空。",
      "task_design": "从带明确减除约定的行列式输入恢复质量隙与全局真空，比较两种重整化约定，跟踪小显式源下分支及曲率。",
      "public_materials": "1+1维作用量、large-N保持量、两种减除条件、积分起点及源项。",
      "deliverables": [
        "全部驻点及稳定性",
        "质量隙、真空能和曲率",
        "方案转换下的不变量",
        "源变形的物理解分支"
      ],
      "verification": [
        "高精度fermion determinant积分与减除",
        "独立gap方程和势能比较"
      ],
      "baseline": "直接粗网格有效势和局部极小值搜索。",
      "difficulty": "非微扰指数尺度、近原点数值消减及全局真空选择；有限N不能误称精确。",
      "independence": "区别qft-06逐图Goldstone抵消、qft-20谱密度外推和SP的多项式平均场。",
      "implementation_gate": "源项gap方程另行推导，限制尺度范围以满足CPU资源。"
    },
    {
      "id": "qft-13",
      "title": "复杂 Langevin 的正确分支与相消误差诊断",
      "source": "G",
      "problems": [
        "29"
      ],
      "pages": [
        {
          "pdf": [
            294,
            300
          ],
          "printed": [
            123,
            129
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；高斯定点关键原页已视觉核对。",
      "original_work": "复四次作用量的矩递推、无穷远边界、截断动力学稳定性及高斯例子的强相消采样问题。",
      "task_design": "恢复中低阶复矩，诊断满足局部递推却属错误支的候选，选择截断深度与精度，分离采样误差、离散误差和边界偏差。",
      "public_materials": "复作用量参数、候选矩及固定模拟记录、有限预算反馈；不强制Langevin单一算法。",
      "deliverables": [
        "复矩",
        "候选正确性分类及可计算误差证据",
        "截断收敛记录",
        "相消与精度需求"
      ],
      "verification": [
        "高精度实轴复权积分",
        "独立后向递推/解析特殊函数与高斯矩校验"
      ],
      "baseline": "固定深度三对角矩递推。",
      "difficulty": "小递推残差并不保证物理解，正采样权重也不能消除观测量相消。",
      "independence": "考查符号问题和数值方案正确性，不是普通积分参数扫描。",
      "implementation_gate": "避开未说明的配分函数零点，不能要求用随机误差证明严格正确。"
    },
    {
      "id": "qft-14",
      "title": "Wong 方程中的色荷输运、路径序与规范协变",
      "source": "G",
      "problems": [
        "37"
      ],
      "pages": [
        {
          "pdf": [
            322,
            325
          ],
          "printed": [
            151,
            154
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "由非阿贝尔Lorentz力和电流协变守恒推出色荷的Wong演化，色荷随背景发生非交换旋转。",
      "task_design": "在固定高能轨迹上输运SU(2)/SU(3)色荷，处理分段非对易背景，比较路径顺序并验证时变规范变换后的终点协变性及物理力。",
      "public_materials": "生成元归一化、固定轨迹、背景场及规范变换、初始色荷和查询时刻。",
      "deliverables": [
        "Wilson输运与终点色荷",
        "不变量和守恒残差",
        "规范变换后的物理力",
        "顺序互换的效应"
      ],
      "verification": [
        "参考用Wong矩阵ODE",
        "真值用独立高精度分段矩阵指数，连续段另作收敛"
      ],
      "baseline": "固定步长保持Hermiticity的颜色演化。",
      "difficulty": "路径序、色荷共轭变换和规范不变量须共同正确，不能将颜色当常数。",
      "independence": "颜色沿路径的输运不同于空间拓扑qft-17和有限温环qft-22。",
      "implementation_gate": "固定轨迹属于eikonal受控近似，不把轨迹忽略反作用说成完整耦合解。"
    },
    {
      "id": "qft-15",
      "title": "大 N Yang–Mills 图的颜色拓扑与平面近似",
      "source": "G",
      "problems": [
        "42"
      ],
      "pages": [
        {
          "pdf": [
            342,
            346
          ],
          "printed": [
            171,
            175
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "主代理已完整核读题面与相关解答。",
      "original_work": "双线图与Fierz恒等式给颜色幂次；固定λ=g²N时G∼λ^(L−1)N^(V−E+F)，闭定向连通真空图χ=2−2h。",
      "task_design": "对公开旋转系统表示的规范图，解析颜色收缩、枚举允许双线取向并识别抵消，比较准确SU(N)色因子与大N首项，判断平面截断在给定N下的误差。",
      "public_materials": "少量三/四胶子连通1PI图、半边配对和顶点循环顺序、Fierz规则、规范固定后的颜色约定及目标误差。",
      "deliverables": [
        "每个颜色项的面数/亏格",
        "准确颜色多项式",
        "完整图首项及抵消证书",
        "平面截断误差与适用N"
      ],
      "verification": [
        "置换循环计算ribbon faces和独立符号Fierz收缩",
        "若干小N显式SU(N)生成元收缩核验多项式"
      ],
      "baseline": "leading-color双线计数，不保留次领先SU(N)项。",
      "difficulty": "同一抽象图可有不同ribbon嵌入，图首项可能抵消，不能对给定V/E/F套Euler公式就算完成。",
      "independence": "规范图颜色组合与受控large-N误差，不重复qft-16实辐射或qft-21格点手征拓扑。",
      "implementation_gate": "需把ribbon项和完整规范图分开，孤立退化零色因子按精确零处理；不合物理的任意ribbon图不伪称Yang–Mills图。"
    },
    {
      "id": "qft-16",
      "title": "QCD 天线辐射的色守恒、角序与模型辨析",
      "source": "G",
      "problems": [
        "43"
      ],
      "pages": [
        {
          "pdf": [
            346,
            354
          ],
          "printed": [
            175,
            183
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "推导单态qq̄软流和干涉，正确角平均下出现角序；八重态对必须包括其他有色外线才能满足色荷守恒。",
      "task_design": "恢复规范完整qq̄和qq̄g事件的软角分布及有限角窗辐射；诊断缺外线和不相干模型，按公开分离度指标选择最有鉴别力的角窗。",
      "public_materials": "自洽硬事件、色张量、软能区间、共线角截断和可选探测窗。",
      "deliverables": [
        "角分布及接受窗积分",
        "完整色流与Ward残差",
        "候选模型偏差",
        "最优鉴别窗与效应量"
      ],
      "verification": [
        "显式颜色矩阵和物理极化求和",
        "独立偶极表达式和高精度角积分"
      ],
      "baseline": "保持规范完整但使用leading-color天线近似。",
      "difficulty": "独立辐射直觉会遗漏干涉与负的次领先偶极项；角序不是总辐射逐点硬零。",
      "independence": "非阿贝尔真空颜色相干，不重复qft-24介质多碰撞或qft-10实虚抵消。",
      "implementation_gate": "公布截断和鉴别指标，确保不把非守恒八重态两线模型当合法真值。"
    },
    {
      "id": "qft-17",
      "title": "Yang–Mills 纯规范绕数与瞬子拓扑荷",
      "source": "G",
      "problems": [
        "49"
      ],
      "pages": [
        {
          "pdf": [
            368,
            370
          ],
          "printed": [
            197,
            199
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "空间无穷远紧化为S³，纯规范以π3(SU(N))分类，四维拓扑荷为初末Cartan–Maurer绕数之差。",
      "task_design": "对有解析边界的SU(2)映射与指定四维场，重建绕数、拓扑荷及边界差；检查规范变换、取向和光滑变形，拒绝不满足边界的伪瞬子。",
      "public_materials": "场构型及径向profile、ε/迹归一化、有限边界误差界；若用BPST则另附完整公开定义与来源。",
      "deliverables": [
        "绕数及收敛证书",
        "四维拓扑荷",
        "边界差残差",
        "自对偶残差及作用量（采用BPST扩展时）"
      ],
      "verification": [
        "解析角积分和独立高精度径向积分",
        "独立场强构造与四维/球对称积分、边界绕数互检"
      ],
      "baseline": "固定网格直接拓扑密度求积。",
      "difficulty": "边界、方向和规范归一化决定整数，粗积分四舍五入不能构成证书。",
      "independence": "四维场拓扑与真空跃迁，不是量子力学双阱，也不是Wong颜色旋转。",
      "implementation_gate": "BPST与作用量界属于补充内容须独立推导，允许只选择物理闭合的拓扑/边界核心。"
    },
    {
      "id": "qft-18",
      "title": "六胶子 NMHV 树振幅的递推与因子化",
      "source": "G",
      "problems": [
        "52"
      ],
      "pages": [
        {
          "pdf": [
            93,
            94
          ],
          "printed": [
            215,
            216
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；已核实不从PDF92起题。",
      "original_work": "3、4线的合法BCFW位移将---+++振幅归结为两个非零递推图，得到紧凑表达式。",
      "task_design": "构建可执行六点在壳递推器，在合法复动量上比较不同shift，并检测物理极点因子化、软极限及伪极点抵消。",
      "public_materials": "旋量/耦合约定、合法动量构造器、低点振幅与输出接口。",
      "deliverables": [
        "可执行求值器",
        "通道及内部螺旋贡献",
        "代表性复振幅",
        "物理极限及伪极点残差"
      ],
      "verification": [
        "BCFW独立位移递推",
        "独立Berends–Giele/显式颜色有序树递推及极点留数"
      ],
      "baseline": "直接颜色有序树递推的双精度实现。",
      "difficulty": "复在壳运动学、内部螺旋选择、归一化与不稳定伪极点必须一致。",
      "independence": "高多重度在壳因子化，不重复QFT-04双图散射；树振幅不等同qft-19一圈有理项。",
      "implementation_gate": "生成器严格保证动量守恒，误差按已剥离物理奇异因子定义；不得靠极端病态点人为制造失败。"
    },
    {
      "id": "qft-19",
      "title": "D 维幺正切割与全正螺旋一圈有理项",
      "source": "G",
      "problems": [
        "67"
      ],
      "pages": [
        {
          "pdf": [
            139,
            145
          ],
          "printed": [
            261,
            267
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读。",
      "original_work": "四维外线与D维环动量分解；μ⁴盒系数和零三角系数由cuts重构，O(ε)乘UV极点产生有限有理项。",
      "task_design": "从公开树子振幅/cut接口识别所需积分基，重建盒/三角系数和有限振幅，诊断只做四维cuts、过早置μ=0及遗漏ε项的方案。",
      "public_materials": "复标量圈、loop measure与颜色有序约定、D=4−2ε、cut查询和master积分定义。",
      "deliverables": [
        "master系数",
        "ε展开与有限残项",
        "多点复振幅",
        "错误重构的缺失信息"
      ],
      "verification": [
        "独立D维张量/维数位移积分",
        "重算cut和参考Feynman参数Laurent展开"
      ],
      "baseline": "只用严格四维cut的标准起点，作为方法能力下限；同时明示其已知信息缺失。",
      "difficulty": "四维cuts为零不代表振幅为零，有限项来自额外维与发散极点相乘。",
      "independence": "重点是有限rational remainder的遗漏信息，不是一般反项账本或树图递推。",
      "implementation_gate": "使用含质量或非零外动量的IR定义提取UV系数，不把无尺度积分的UV pole和完整积分混用。"
    },
    {
      "id": "qft-20",
      "title": "Dirac 低谱的 Banks–Casher 凝聚与极限次序",
      "source": "G",
      "problems": [
        "69"
      ],
      "pages": [
        {
          "pdf": [
            161,
            163
          ],
          "printed": [
            283,
            285
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "配对谱将凝聚化为m/(λ²+m²)积分，先取体积无穷再取零质量得到−πρ(0)。",
      "task_design": "对受控谱族分离拓扑零模和广延近零模，恢复有限质量凝聚，选择满足公开误差目标的缩放窗口并判断非零手征极限。",
      "public_materials": "多体积成对低谱、已知UV尾、误差模型和谱族生成约束；明确为受控模型而非真实QCD观测。",
      "deliverables": [
        "凝聚与零模分量",
        "有限体积修正",
        "缩放窗口及误差界",
        "两种极限次序与ρ(0)"
      ],
      "verification": [
        "高精度离散谱求和及解析尾",
        "独立连续谱积分和有限体积求和公式"
      ],
      "baseline": "固定质量窗口的朴素外推。",
      "difficulty": "有限体积、零模与热力学极限不交换，局部直方图不能独自证明凝聚。",
      "independence": "低谱统计和极限推断，不重复qft-12辅助场质量生成及qft-21动量零点拓扑。",
      "implementation_gate": "统一完整正负谱及每体积归一化；不假定所有背景无精确零模。"
    },
    {
      "id": "qft-21",
      "title": "格点费米子零点、手征指数与物种倍增",
      "source": "G",
      "problems": [
        "70"
      ],
      "pages": [
        {
          "pdf": [
            163,
            168
          ],
          "printed": [
            285,
            290
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "周期动量环面上的连续局域核零点携带手征指数，总指数由χ(T⁴)=0限制。",
      "task_design": "对可证完备的Fourier动量核族找全Brillouin区零点，判断Jacobians、手征与临界生成/湮灭，识别漏掉doublers或放弃定理假设的方案。",
      "public_materials": "核的有限Fourier表达、周期坐标、参数区间、定理假设和允许的退化情形。",
      "deliverables": [
        "周期去重零点集",
        "Jacobian和局部指数",
        "简并点与物种数",
        "全局指数及假设诊断"
      ],
      "verification": [
        "半角有理化后的完备实根隔离与边界检查",
        "独立解析枚举/同伦和局部映射度"
      ],
      "baseline": "多初值找根加周期去重。",
      "difficulty": "找全所有零点及精确识别临界退化比找几个根困难，必须服从全局拓扑约束。",
      "independence": "动量空间Weyl零点的手征障碍，不是qft-17空间场绕数或qft-20凝聚密度。",
      "implementation_gate": "选择根可证明完备的核，不笼统声称所有格点手征实现均不可能。"
    },
    {
      "id": "qft-22",
      "title": "中心对称、Polyakov 环与有限体积扇区混合",
      "source": "G",
      "problems": [
        "72"
      ],
      "pages": [
        {
          "pdf": [
            171,
            175
          ],
          "printed": [
            293,
            297
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "有限温边界允许中心扭曲，Polyakov环按中心变换；重色源自由能与物质N-ality决定序参量解释及显式破缺。",
      "task_design": "在受控非对易时间链与精确定义中心有效系综中，重建holonomy、相关函数和残余中心，区分对称分布、扇区混合的有序分布与显式破缺。",
      "public_materials": "SU(N)时间连接、有效系综权重、体积序列、N-ality与可判定物相规则；不伪称真实QCD相变数据。",
      "deliverables": [
        "有序holonomy和变换规律",
        "均值、模平方及远距相关",
        "残余中心集合",
        "有限体积与热力学判断"
      ],
      "verification": [
        "高精度有序乘积与有限系综穷举",
        "独立中心字符求和和转移矩阵关联计算"
      ],
      "baseline": "单点Polyakov环均值的朴素分类，并提供其有限体积局限。",
      "difficulty": "⟨L⟩=0可能来自扇区抵消，不足以判禁闭；路径顺序和全局对称性必须分清。",
      "independence": "全局中心与静态色源，不重复Wong开放路径输运或SP多项式极值。",
      "implementation_gate": "优先级B：落实转移矩阵模型与公开物相判据，不能退化为一次SU(N)矩阵相乘。"
    },
    {
      "id": "qft-23",
      "title": "热光子 HTL 的因果响应、屏蔽与集体模",
      "source": "G",
      "problems": [
        "73"
      ],
      "pages": [
        {
          "pdf": [
            176,
            179
          ],
          "printed": [
            298,
            301
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "线性Vlasov诱导流产生规范不变HTL有效作用和极化，单无质量Dirac物种mD²=e²T²/3。",
      "task_design": "从速度角响应计算retarded极化，跨空间样和时间样区域恢复Landau阻尼，求纵横集体模及留数，比较静态和均匀极限。",
      "public_materials": "弱耦合软外动量条件、分布与简并度、retarded处方、守恒源和查询尺度。",
      "deliverables": [
        "复极化分量与Ward残差",
        "屏蔽质量",
        "纵横色散根及留数",
        "非交换极限和源响应"
      ],
      "verification": [
        "解析因果复对数与隐函数根",
        "独立主值/δ角积分和时域Vlasov响应"
      ],
      "baseline": "有限角网格速度求积和固定宽度η。",
      "difficulty": "真实热介质的解析处方、光锥极限、Landau阻尼和色散根不能用实对数一律代替。",
      "independence": "零温QFT-01与经典ED题没有热占据硬环；本题无碰撞，区别qft-24。",
      "implementation_gate": "限制至各向同性平衡模型，明确k=0解析极限和离光锥距离。"
    },
    {
      "id": "qft-24",
      "title": "LPM 多次散射重求和与辐射近似选择",
      "source": "G",
      "problems": [
        "75"
      ],
      "pages": [
        {
          "pdf": [
            183,
            190
          ],
          "printed": [
            305,
            312
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键扩散页已视觉核对。",
      "original_work": "形成时间内多次软散射同阶，差分碰撞核需重求和；leading-log扩散解仅在受控层次有效。",
      "task_design": "求旋转对称m=1角谐波的完整横动量响应，比较单碰撞和扩散近似，按公开误差目标选择适用区并恢复软频率标度。",
      "public_materials": "无量纲完整碰撞核、边界/尾部、质量与Debye比、光子能量网格和率归一化。",
      "deliverables": [
        "发射函数及独立残差",
        "Bethe–Heitler抑制比",
        "两种近似误差与适用域",
        "小频率指数"
      ],
      "verification": [
        "保持红外差分抵消的动量空间Nyström/有限体积",
        "独立impact-parameter径向复边值问题"
      ],
      "baseline": "单碰撞Bethe–Heitler起点，另列leading-log近似为对照。",
      "difficulty": "非局域核、红外抵消、复响应和形成时间干涉须自洽；扩散近似不能冒充完整真值。",
      "independence": "介质碰撞相干重求和，区别无碰撞HTL和真空天线。",
      "implementation_gate": "优先级C：从正定差分算子重推扩散符号，双路线收敛后量测CPU/内存，不先承诺既定耗时。"
    },
    {
      "id": "qft-25",
      "title": "标量强场产对的 Bogoliubov 谱与粒子数统计",
      "source": "G",
      "problems": [
        "80"
      ],
      "pages": [
        {
          "pdf": [
            209,
            217
          ],
          "printed": [
            331,
            339
          ],
          "role": "完整题面与解答"
        }
      ],
      "reading": "完整相关题段已核读；关键原页已视觉核对。",
      "original_work": "标量QED中正负频模混合满足|α|²−|β|²=1，压缩真空的模产对数服从几何统计，logP0=−Σlog(1+n)。",
      "task_design": "求单/双平滑电场脉冲的模式演化和动量谱，判断非相干相加的失效；从同一谱构建有限盒产对均值、方差、真空存活率和异号配对关联。",
      "public_materials": "标量KG方程、脉冲profile与渐近常势、canonical/kinetic动量约定、有限盒模集和误差尺度。",
      "deliverables": [
        "occupation谱与Wronskian残差",
        "双脉冲干涉比",
        "log真空存活率",
        "均值/方差及配对协方差",
        "规范平移后kinetic谱一致性"
      ],
      "verification": [
        "高精度二阶KG复ODE与渐近投影",
        "独立一阶Bogoliubov/quantum kinetic演化，单脉冲解析结果再校验"
      ],
      "baseline": "绝热近似或局域常场近似，并明确适用层次。",
      "difficulty": "渐近频率、相干相位和玻色统计共同决定结果，不能套费米子归一化或Poisson统计。",
      "independence": "非微扰外场真空到多粒子映射，不重复二维Schwinger模型质量生成；简单单频一阶产对不另计。",
      "implementation_gate": "统计量从数算符重推，有限时间窗与极小谱尾用绝对容差，不按规范相关裸相位唯一判分。"
    }
  ],
  "excluded_or_reserve": [
    {
      "source": "R",
      "problem": "11.14",
      "reason": "六维φ³为强后备，但与11.12局域UV减除能力重合；优先保留格点倍增等不同机制。"
    },
    {
      "source": "R",
      "problem": "11.6",
      "reason": "与既有真空极化阈值和衰变相空间交集大。"
    },
    {
      "source": "R",
      "problem": "4.33",
      "reason": "相对论单粒子势阱，偏量子力学且与既有QM谱题相近。"
    },
    {
      "source": "R",
      "problem": "5.18",
      "reason": "原样为标准Noether代数推导，不足以独立形成高难研究任务。"
    },
    {
      "source": "R",
      "problem": "10.10",
      "reason": "单频一阶产对较简单，保留更完整的G80，不双计。"
    },
    {
      "source": "G",
      "problem": "48",
      "reason": "量子力学双阱瞬子可能与原QM计划重复，采用Yang–Mills瞬子。"
    },
    {
      "source": "G",
      "problem": "68",
      "reason": "不以四点换五点增加独立题数，与G67同机制。"
    },
    {
      "source": "G",
      "problem": "74",
      "reason": "不以QED换QCD重复增加HTL题数。"
    },
    {
      "source": "G",
      "problem": "82/83",
      "reason": "G82的Born平均传播子衰减本身不证明局域化；真实输运扩展需额外材料，不作为本轮20题。"
    }
  ]
}

exit_code=0
```

### 2026-11-16T21:57:28.577227+08:00

```bash
python3 tools/read_qft_source_pages.py gelis 161:190
```

```text

### 2026-11-16T21:57:28.577343+08:00

```bash
cat planning/qft-expansion-gelis-thermal-review.md tools/read_qft_source_pages.py tools/course_quality_score.py tasks/qft-04/environment/requirements.txt
```

```text
# Gelis：格点、有限温与强场候选核读评审

日期：2026-11-16。来源核读和原创改造设计，未封装成 Harbor 任务，未进行正式模型测评。

来源：François Gelis, *Problems in Quantum Field Theory*，用户文件 `/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256 `7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。本 PDF 有章节重排，以下页码逐页依据页标登记，不使用全书统一偏移。文本索引 `planning/source-notes/qft-gelis-all.txt`。

视觉核对记录：已实际渲染并查看 PDF161（书283）、164（书286）、171（书293）、179（书301）、188（书310）、209（书331）、217（书339）、228（书350）；图片保存在 `checks/qft-expansion-gelis-thermal-source-pages/`。下文“未逐页视觉核对”表示完整相关文本已读、但没有把解答每一页都渲染查看，不表示这些抽查原页未看。

## Problem 69：Banks–Casher Relation

- **范围与阅读状态：** 题面 PDF161 / 书283；完整相关解答 PDF162–163 / 书284–285（止于70题开始前）。已读全部相关文本；尚未逐页视觉核对。
- **原题主要工作：** 把手征凝聚写成有限体积 Euclidean Dirac 算子逆的迹，利用 γ5 对称性配对 ±λ 本征值，得到 `⟨ψ̄ψ⟩=−lim(V→∞)∫dλ mρV(λ)/(λ²+m²)`。随后先取热力学极限，再取 `m→0+`，以 Poisson 核的分布极限得到 `Σ=−πρ(0)`。谱密度按单位四维体积、完整正负谱定义。
- **容易误述的边界：** 有限体积的离散谱不能直接在零点做平滑密度估计后声称严格自发破缺；极限顺序不能互换。精确拓扑零模会贡献 `N0/(mV)`，不能笼统假定每个有限体积背景必有严格谱隙，也不能把它与广延近零模凝聚混为一谈。原题证明在形式化连续理论层面；输入有限维谱不等于已经模拟完整 QCD。UV 发散/减除必须在改造模型中明定。
- **原创 benchmark 设计：** 给定数个体积、质量和成对本征值的可复现谱族（含非零近原点密度、伪谱隙、次广延拓扑零模三类），要求计算凝聚、识别能支持稳定手征极限的缩放窗口、区分先取 m 极限和先取 V 极限的结果，并从有明确误差模型的低谱观测反演 `ρ(0)`。可使用源自谱密度的固定生成模型，必须称“受控谱模型”，不可伪称格点 QCD 数据。要有离散低模和已知 UV 尾两部分，不能仅做直方图读值。
- **产物与客观评分：** 每个谱族输出各 `(V,m)` 的 condensate、zero_mode_contribution、finite_volume_correction、所选 scaling_window、热力学手征极限及可辨识性。数值按固定绝对/相对尺度评分，窗口由明确误差上界及覆盖性判定，不按文字偏好评分。任何满足相同精度的外推方法应等价得分。
- **两条独立真值：** ① 直接高精度成对本征值求和加解析 UV 尾；② 从设计的连续 `ρ(λ)` 独立积分并用 Euler–Maclaurin/已知谱求和式获得有限体积修正。零模项另算、极限分别取，交叉验证而不共用拟合算法。
- **独立性：** 核心是低谱密度、极限非交换与序参量，不是11.8的逐图 Goldstone 抵消，也不是一般矩阵对角化。与70同属格点相关，但任务对象及物理问题不同。
- **结论：** 优先候选；原题定理本身不够编程难，必须落实上述谱族、误差和极限判断。

## Problem 70：Nielsen–Ninomiya Theorem

- **范围与阅读状态：** 题面 PDF163–164 / 书285–286；完整解答（含 Poincaré–Hopf 证明草图和图）PDF164–168 / 书286–290，止于71题开始前。已完整核读相关文本；尚未逐页视觉核对。
- **原题主要工作：** 无限平移不变格点的动量空间是 `T⁴`，逆 Weyl 传播子由实连续周期矢量 `Fμ(p)` 构成。非退化线性零点给质量为零的费米子；每反转一个局部方向，γ 矩阵相似变换使手征翻转。非退化零点的指数与局部 Jacobian 行列式符号相联系，在四维与左/右手性相对应；Poincaré–Hopf 给总指数 `χ(T⁴)=0`，所以在这些假设下净手征数零。
- **容易误述的边界：** 结论依赖周期动量空间、局域性/足够连续性、Hermiticity、合适的 Dirac 结构和孤立非退化零点；不能写成任何格点理论都绝不可能含手征费米子。Wilson 破坏朴素手征对称性，Ginsparg–Wilson 等更改手征实现，均不能被简单“找一个零点”否定。对一般耦合 `F`，应直接用 `sign det J` 和映射度，不假定它总是全局某个势函数的梯度；简并零点要单独检测，不能硬判符号。
- **原创 benchmark 设计：** 给出有有限 Fourier 表示的周期、局域格点动量核族，含可严格枚举的基准、各向异性高次谐波、可解的三角耦合变形以及零点生成/湮灭的临界参数。要求完整找出 Brillouin 区内的零点（周期边界去重）、线性化矩阵、手征/指数和总指数，并判断哪些“单手征”候选实际有未发现的 doublers，哪些通过放弃明确假设避开了原定理。高难度来自完整性和拓扑边界，不是一次随机找根。
- **产物与客观评分：** 零点数组（坐标模2π规范化）、残差、`det J`、chirality、degenerate 标记、各参数区间物种数和净指数。评分使用周期距离的最优匹配，完整性和误判简并单独计分；不因等价坐标/排序扣分。输入族必须允许给出根完备性的证书，不能用不可保证找到所有根的私有随机算法充当真值。
- **两条独立真值：** ① 对设计的 Fourier 家族用 `t=tan(p/2)` 化为有理多项式，隔离全部实根并单独查 `p=π` 边界，以区间法验证 Jacobian 非零；② 独立解耦/同伦坐标变换解析枚举，并在各零点邻域计算映射度或数值积分包围面验证指数，检查全局和为零。临界面用结果式/解析判别条件而非把很小行列式当严格零。
- **独立性与比较：** 明显区别于 Radovanović 11.14 的六维 φ³ 局域 UV 减除，也区别于已有 QFT-01–04 的积分、相空间、RG和树图散射。若题库同含11.12和11.14导致重整化主题偏密，70更值得入选。与69共同使用“谱”概念，但70考核动量核零点的拓扑/手征障碍，69考核随机背景低谱的热力学极限。
- **结论：** 强烈推荐优先入选；需要选择可证明根完备性的动量核族，避免只靠高维随机搜索。

## Problem 72：Center Symmetry and Deconfinement

- **范围与阅读状态：** 题面 PDF171–172 / 书293–294；完整相关解答 PDF172–175 / 书294–297，止于73题开始前。题面(a)–(e)、重夸克自由能推导和基本/伴随表示的讨论均已全文核读；尚未逐页视觉核对。
- **原题主要工作：** 证明 `center(SU(N))=Z_N`；有限温 Euclidean 时间边界条件允许 `Ω(β,x)=ξΩ(0,x)` 保持纯规范场周期性；Polyakov 环在此变换下乘中心元素 `L→ξL`，故是区别于普通规范冗余的全局对称性。用无限重夸克传播子沿虚时间的 Wilson 线，联系 Polyakov 环和静态色源自由能，得到其纯 Yang–Mills 去禁闭序参量解释。基本表示的动力学夸克破坏反周期边界条件从而显式破坏中心对称性，伴随表示则不破坏。
- **容易误述的边界：** 必须区别单个构型的 `tr W/N` 和取热平均后的序参量。有限体积没有严格自发破缺，若不同中心扇区混合，去禁闭模型的 `⟨L⟩` 也可因抵消而为零；不能据此直接断言禁闭。`Fq=−T log|⟨L⟩|` 有重色源自能减除/归一化以及扇区或无穷体积极限的约定；不能把未重整化格点环的绝对值当成普适自由能。书中纯规范结论不能不加条件推广到有基本表示夸克的 QCD。一般物质的显式破缺由 N-ality 决定，伴随与基本仅为两个例子。
- **原创 benchmark 设计：** 给定小型 SU(N) 非对易时间链的精确连接矩阵，以及由明定有效中心模型产生的构型/中心扇区样本，要求按正确路径次序计算 holonomy，检查周期规范变换和中心变换；再根据 `⟨L⟩`、`⟨|L|²⟩`、远距环相关函数及体积缩放，判断“中心对称分布”“扇区混合的有序分布”和“显式破缺”三者。增加指定 N-ality 的物质，求仍保持边界条件的残余中心子群。不得声称这些小型有效模型已测得真实 QCD 的相变温度。
- **产物与客观评分：** 每条时间链输出复 holonomy trace、变换后 trace、规范不变残差；每个系综输出精确权重均值/相关量、残余中心元素和在公开判据下的结论。数值用复距离评分，子群按集合评分，物相标签必须有公开、可判定的模型定义。避免把题目退化为给出 `Z_N` 的一次群论代入。
- **两条独立真值：** ① 独立高精度有序矩阵乘积与有限系综直接穷举；② 用 Wilson 线端点协变性简化变换，用中心字符/单位根求和及有效模型的转移矩阵计算平均和相关函数。群边界、长程极限和权重归一化分别核验，参考解不能读取真值构型标签。
- **独立性：** 这是有限温规范场的全局对称性、静态色源与物相识别，和69的手征低谱、70的doublers拓扑均不同；也不是SP-01的单变量平均场极值问题。若只有矩阵相乘或一条环的自由能公式，难度不足。
- **结论：** 有条件保留；要完成“扇区混合不等于禁闭”的研究判断和可控有效模型设计，原题纯证明直接封装不算高难数值任务。

## Problem 73：Photon Hard Thermal Loop from Classical Particles

- **范围与阅读状态：** 题面与解答 PDF176–179 / 书298–301，止于74题开始前；(a)–(e)全部核读，含有效作用量变分、径向积分和角积分。尚未逐页视觉核对。
- **原题主要工作：** 用无质量带电粒子运动方程与 Liouville 定理推得无碰撞 Vlasov 方程。将分布展开 `f=f0+f1+…`，形式求解 `(p·∂)f1=e pμFμν∂f0/∂pν`，再算诱导流、生成该流的规范不变二次有效作用量和 HTL 极化。电子/正电子各两自旋给 `f0=4/(exp(βp)+1)`。各向同性时径向积分因子为 `e²T²/6`，最后 `Πμμ=e²T²/3`，`Π00=(e²T²/3)[1−ω/(2k) log| (ω+k)/(ω−k) |]`（书中展示的是实角积分形式）。
- **容易误述的边界：** HTL 是硬粒子动量约T、软外动量约eT的弱耦合/超相对论近似；不是任意T、任意外动量的完整一圈函数。粒子轨道中忽略辐射反作用及碰撞。形式算子 `(p·∂)⁻¹` 需要边界条件；为 retarded 响应必须明确 `ω→ω+i0`，书中实绝对值对数不能替代 Landau 区域的复函数。各向异性改造可能出现不稳定性，不能继续无说明套用平衡标量分解。有效作用量在书中推导使用外场源远离、背景源不参与动力学的假设，不应把中间步骤视为任意源的证明。
- **原创 benchmark 设计：** 在明确单一无质量 Dirac 物种、各向同性平衡分布和 retarded 处方下，要求从线性 Vlasov 响应重构 `Π00` 与横向函数，跨空间样/时间样/光锥附近计算复响应，提取 Debye 静态屏蔽尺度、纵/横等离子体色散根及留数，并比较 `ω→0` 和 `k→0` 的非交换极限。选择有限频宽的守恒外源计算响应可进一步防止只背公式。数值任务同时检查电荷守恒/横向性、retarded 分支和根的物理可达性。
- **产物与客观评分：** 公开查询点的复极化分量、Ward残差、两支色散根/留数、静态与动态极限，外源响应（若采用）。按无量纲 `mD²=e²T²/3` 归一化，明确 `k=0` 的解析极限而非让Agent除零。近光锥点必须离开奇点一个公开非零距离，分布值/边界极限不能混用；等价解析与数值方法同分。
- **两条独立真值：** ① 解析复对数和独立的隐函数求根/导数；② retarded `ω+iη` 下的速度角积分，加解析主值/δ项提取，η外推并由时域 Vlasov 初值响应或谱表示交叉核验。不能用同一对数函数的不同封装冒充独立真值。
- **独立性：** 与QFT-01的零温真空对产生阈值谱不同，此处是热介质的碰撞无关集体响应、Landau阻尼和等离子体色散。与75的多次散射LPM也不同，73的线性无碰撞响应不能代替75的形成时间干涉积分方程；不再同时从74仅换QED为QCD增列一题。
- **结论：** 优先保留，尤其适合考查解析处方、守恒约束和尺度近似。

## Problem 75：Landau–Pomeranchuk–Migdal Effect

- **范围与阅读状态：** 题面 PDF183 / 书305；完整解答 PDF184–190 / 书306–312，止于76题开始前。已全文核读(a)–(f)，包括热光子率、线性碰撞项、HTL和规则、形成时间估计、扩散近似及 Laplace 解尾部的极限处方；尚未逐页视觉核对。
- **原题主要工作：** 从 retarded 光子自能的虚部得到热光子发射率，用外场诱导电流重构自能，并把电子/正电子分布线性化为同一响应函数 `F`。软横向转移的碰撞算子具有差分结构 `F(p)−F(p−ℓ⊥)`，核为 `mD²/[ℓ⊥²(ℓ⊥²+mD²)]`。当 `K·v≈k0(m²+p⊥²)/(2pz²)` 与碰撞尺度同阶时，各阶散射不可逐次截断，须解积分方程。`1/(K·v)` 是形成时间：一束光子的形成时间内发生多次散射，辐射振幅产生破坏性干涉，软谱相较 Bethe–Heitler 极限受抑制。附加(f)在 `m≫mD` 且对数大时作 leading-log 扩散近似，得到复常微分方程和 Laplace 解，软极限自能虚部正比 `√k0`，结合 Bose 因子后软光子谱为 `1/√k0`。
- **容易误述的边界：** 差分碰撞算子的红外抵消不能被拆成各自发散的两个积分后随意截断。扩散近似只在给定尺度层次/大对数下适用；不能在 `m~mD` 把扩散解当完整核的真值。形成时间是相干时间，不应把 `1/(e²T)` 和所有定义下的总散射平均自由程混为一谈，软库仑散射的红外约定需固定。光子率的 `Π`、`−iΠ` 约定和符号须明示。书中对 `F(p)−F(p−ℓ)` 的 Taylor 行出现正二阶项；按通常对称核的 Taylor 展开二阶应为负号，最终扩散方程的符号和 Fourier 约定必须从原始正定碰撞算子重推，不能将扫描文字直接当代码。
- **原创 benchmark 设计：** 在公开、无量纲化的弱耦合热介质模型中，解固定横动量核的 retarded 线性响应积分方程，输出若干 photon-energy 和 mass/Debye 比下的发射函数；同时构造一次散射近似及 leading-log 扩散近似，量化各自适用区间。任务应至少含一个 diffusion 近似不够准的工况和一个形成时间内多重散射不可忽略的工况，要求据公开误差目标选择近似/求解方案。可以限定至旋转对称的角谐波 `m=1` 径向问题，以维持 CPU 可复现性；该角谐波编号与电子质量不要使用相同变量名。
- **产物与客观评分：** 固定能量查询的复杂响应或规范化发射函数、独立计算的方程残差、相对 Bethe–Heitler 的抑制比、给定误差目标下 diffusion/单碰撞的可用范围及小频率指数。评价真值是完整核收敛解，近似误差标签由明确阈值决定。网格截断、尾部条件与核在 `ℓ=0` 的对称差分处理须在公开输入中精确定义，避免不同物理模型互相评分。
- **两条独立真值：** ① 保持差分抵消的动量空间角谐波 Nyström/有限体积离散，进行网格和截断收敛并验证碰撞算子正性；② 横向 impact-parameter Fourier 变换，把卷积差分变为局域势，解独立复径向边值方程，再变换/积分得到同一发射率。仅在 `m≫mD` 的受控工况使用书中 Laplace/扩散解析解做第三项近似核验，不能将它冒充完整碰撞核的独立真值。
- **独立性：** 与73无碰撞HTL的介质极化不同，此题是形成时间内碰撞相干重求和；与43真空软辐射antenna也不同，不能把“有干涉”作为重复的充分理由。与80外场真空产生的驱动/统计分布也不同。保留完整核与近似选择才具有实质难度。
- **结论：** 高质量优先候选，工程量比单积分题大；先做精确核模型和双路线收敛，不应只抄一个 `√k0` 标度充当任务。

## Problem 80：Schwinger Mechanism from Bogoliubov Transformations

- **范围与阅读状态：** 题面 PDF209 / 书331；完整解答与附加离散模概率讨论 PDF210–217 / 书332–339，止于81题开始前。已完整核读(a)–(d)、归一化和 per-mode 几何分布；尚未逐页视觉核对。PDF209页上半是79题结尾，不属于80题。
- **原题主要工作：** 研究复标量场与预先给定经典电磁外场，即**标量 QED**，不是费米子 QED。选 temporal gauge `A0=0`，由正则 Hamiltonian 得到线性 Klein–Gordon 演化；自相互作用、光子环和外场反作用均未包含。时变、空间均匀外场不混合 canonical 动量 `k`，正负频模之间发生 Bogoliubov 混合，系数满足 `|αk|²−|βk|²=1`。in真空在out Fock基中是成对的两模压缩真空，`nk=|βk|²`，每个 `(k,−k)` 模对的产对数服从 `Pk(r)=[1/(1+nk)][nk/(1+nk)]^r`。真空存活率 `log P0=−Σk log(1+nk)`，一般不等于 `−Σk nk`；同模玻色增强/异号配对相关性不能以独立 Poisson 产生代替。
- **容易误述的边界：** canonical 动量和可观测 kinetic 动量不同；即使渐近电场为零，`Ain`和`Aout`也可为不同常量，所以渐近频率要用各自协变动量。`Aout=0`只是方便的残余规范选择，不是物理电场必须零积分。用费米子关系 `|α|²+|β|²=1` 会根本改变数目统计。独立 canonical 模对中粒子与反粒子相关，同号不同模不相关；不能把单模几何分布称普通相干态的 Poisson 分布。书中将配对指数态称 generalized coherent state，现代术语宜明确为两模 squeezed vacuum。正负频分解和系数相位依赖模基约定；评分必须比较不变量或固定相位基。PDF216等式中同号双谱的δ参数存在疑似排版错误，应由数算符定义重推，勿复制 `δ(p−p)`。
- **原创 benchmark 设计：** 给定单/双Sauter型电场脉冲和一组canonical动量，求解 `ü_k+[m²+k⊥²+(kz+eAz(t))²]u_k=0` 的入/出频率投影，计算 `nk`、模归一化残差和动量谱。双脉冲保留两次产生振幅的相位干涉；Agent须判断何时把两脉冲粒子数简单相加失效。对指定有限盒模集再计算总均值、方差、`P0`和粒子—反粒子数协方差，区分几何统计与 Poisson 近似。将 canonical 坐标平移和背景常势平移一起做规范一致性探针，比较同一 kinetic 谱。
- **产物与客观评分：** 每个脉冲/模的occupation、Bogoliubov模长和Wronskian残差；有限模集合的`log_vacuum_survival`、均值/方差与配对协方差；固定区间的谱积分及双脉冲相干比。物理统计必须来自同一模谱。禁止私有评分把规范相关的裸相位视为唯一答案。设置可合理计算的occupation和极小尾部绝对容差，避免在浮点消减处要求无意义的相对精度。
- **两条独立真值：** ① 高精度二阶KG模方程的直接复ODE积分，渐近频率解析投影并延长时间窗；② 独立一阶Bogoliubov演化/quantum kinetic方程，检验`SU(1,1)`不变量，与单Sauter脉冲可解析的Gamma函数结果交叉核验。多脉冲可另用匹配转移矩阵的组合验证相位。参考解与私有真值不能共用同一ODE核心和投影函数。
- **独立性：** 与 Radovanović10.10单频一阶对产生重复风险高，因此建议保留80、剔除10.10。与11.13二维Schwinger模型的动态光子质量机制完全不同，必须在题名标明“标量外场产对”以免只凭Schwinger名称混淆。与QM势垒散射虽都有ODE/转移矩阵，QFT核心产物为真空—多粒子Bogoliubov映射和玻色数统计。
- **结论：** 高质量优先候选；脉冲族和统计量应共同成一道完整题，不按单/双脉冲拆题。

## Problem 82：Anderson Localization（须纠正原解解释后才能采用）

- **范围与阅读状态：** 题面 PDF225 / 书347；完整解答 PDF226–228 / 书348–350，止于83题开始前。已全文核读(a)–(c)，并补读相邻83题及其解答 PDF229–230 / 书351–352，确认其讨论维数及无序强度的边界。已视觉查看 PDF228 的公式和结论，其余相关页为全文文本核读。
- **原题实际完成的工作：** 从 Dirac 方程消去非相对论小分量，得到含 Pauli 磁项的非相对论 Hamiltonian；对静态纯电势写出 Dyson 方程，再对时间不变、空间 δ 相关的 Gaussian 无序势做二阶 Born 自能。在三维、相应符号约定下，书中得到在壳 `ImΣR=−e²σ m p/(2π)`，而实部具有 UV 发散。将1PI自能重复插入得到平均单粒子传播子的衰减。
- **来源中的实质限制：** PDF228最后数段把非零 `ImΣ` 导致的平均传播子衰减直接解释为“电子不能传播、任意能量不能导电、Anderson定域”。这个推断不足以成立：无序平均的振幅因弹性散射和相位平均衰减，并不单独证明本征态指数定域、直流电导为零或存在特定 localization length。扩散金属也有有限单粒子弹性寿命。真正的定域涉及路径相干与两粒子/输运相关，不能仅由有限阶1PI Born自能判定；三维尤其不能由非零无序一概断言绝缘。相邻83题承认维数/强度区别，但其引用82的同一长度仍不构成独立证明。也不能把 `1/|ImΣ|` 直接当长度：它先给时间尺度，空间振幅/强度衰减还涉及群速度和因子2的定义。静态无序的相关 δ 是空间δ，频率转移为零，不是时空白噪声。
- **原创 benchmark 设计：** 以82的场论无序平均/自能为基础，并明确补充真实可计算的1D非相互作用 Anderson tight-binding链及理想引线。提供固定无序样本数组、边界、自能约定和多个长度/能量；要求比较平均单粒子Green函数、逐样本透射率、`⟨log T⟩`、有限长度Lyapunov指数及本征态participation指标，判断哪些证据只能支持“弹性散射”，哪些支持题目明定范围内的“有限样本指数定域”。保留无序平均单粒子响应和真实透射之间的差别，避免退化为一般随机矩阵对角化。可以给出Born近似作为待诊断的候选模型，不以它的错误物理结论设真值。
- **产物与客观评分：** 每个固定样本/能量输出透射率（或避免下溢的`log T`）、端到端 retarded Green值和Lyapunov指数；每个固定系综输出均值/典型值及公开规则下的判别。IPR需说明选态能窗与退化处理。有限样本的斜率/置信规则必须预先定义，不能要求从有限数据严格证明热力学定域。若只保留原题三维Born传播子，应更名为“无序介质的Born自能与相干衰减”，不得把正确答案设为“所有三维无序均为绝缘体”。
- **两条独立真值：** ① QR/稳定散射矩阵连乘的逐样本传输计算，独立长链Lyapunov递推；② 带解析引线自能的三对角 resolvent/recursive Green函数，利用`T=ΓLΓR|G1N|²`验证同一有限链透射，并用独立本征求解核对态参与率。两条路线要在强衰减/共振处分别收敛和避免溢出。Born自能只能作为近似对照，不充当定域指标真值。
- **独立性：** 相比现有QM-03周期Bloch能带，本题关键是无序平均、典型/平均差异和输运定域；相比Gelis69低谱手征凝聚、70动量核拓扑均不同。但新1D输运模型、参与率及真实定域判据超出82的实际一圈工作，必须如实记录原创扩展与补充依据，不能写成“原题已经严格推出这些结论”。
- **结论：** **不建议原样入选高难20题。** 若缺少独立主题，可采用上述纠错/输运改造并补充可靠定域来源；若已有20道更直接且物理闭合的候选，82应保留为后备。

## 七题取舍与相互独立性

| 原题 | 核心对象 | 推荐级别 | 与其他候选的主要区别 |
|---|---|---|---|
| 69 | Dirac低谱、手征凝聚、极限次序 | 优先 | 非逐图Goldstone、非动量核doublers |
| 70 | 格点Weyl零点、指数/手征、物种倍增 | 强烈优先 | 可替代第二道相近的UV重整化题 |
| 72 | 中心扇区、Polyakov环、色源自由能 | 有条件保留 | 全局中心对称与手征对称不同；需系综/扇区判断 |
| 73 | 无碰撞热介质HTL响应与Landau区 | 优先 | 有限温集体响应，区别零温阈值谱 |
| 75 | 多碰撞、形成时间干涉与LPM抑制 | 优先 | 不把碰撞核简化为73的无碰撞响应 |
| 80 | 标量QED外场产对、压缩真空与几何统计 | 优先 | 不是二维Schwinger质量生成，替代简单10.10 |
| 82 | 无序自能、相干衰减与真实定域的区别 | 后备/实质改造 | 纠正有限阶单粒子衰减的解释，需真实输运指标 |

若主清单允许调整，建议优先70而非再增加与11.12相近的11.14；若要求两者均保留，必须分别考查“多场反项混合”和“六维线性源/裸量闭合”，而不能都只给一组一圈反项系数。72和82的原题本身都不足以自然形成高难数值探索包，是否入选应取决于原创模型是否真正落实，而不是题名的知名度。
"""Read exact page spans from the already extracted source indexes (no PDF mutation)."""
import argparse
from pathlib import Path
import re

parser = argparse.ArgumentParser()
parser.add_argument("source", choices=["gelis", "problem-book"])
parser.add_argument("spans", help="One-based PDF page ranges, e.g. 34:40,55:61")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
raw = (root / "planning/source-notes" / f"qft-{args.source}-all.txt").read_text()
parts = re.split(r"\n===== PDF PAGE (\d+) =====\n", raw)
pages = {int(parts[i]): parts[i+1] for i in range(1, len(parts), 2)}
selected = []
for span in args.spans.split(","):
    bounds = [int(x) for x in span.split(":")]
    if len(bounds) == 1:
        bounds *= 2
    if len(bounds) != 2 or bounds[0] > bounds[1]:
        raise ValueError(f"Invalid page span {span}")
    selected.extend(range(bounds[0], bounds[1] + 1))
for number in selected:
    print(f"\n===== PDF PAGE {number} =====\n{pages[number]}")
"""课程统一质量分：简单基线0、专家参考1，逐次换算后取平均。"""
import math

VALID_FAILURES = {"invalid", "agent_error", "timeout"}


def finite_number(value, name):
    if type(value) not in (int, float):
        raise ValueError(f"{name}须为有限数值")
    try:
        result = float(value)
    except OverflowError as exc:
        raise ValueError(f"{name}须为有限数值") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name}须为有限数值")
    return result


def validate_metric(metric):
    if metric.get("kind") == "binary":
        baseline = finite_number(metric.get("baseline"), "baseline")
        reference = finite_number(metric.get("reference"), "reference")
        if baseline != 0 or reference != 1:
            raise ValueError("二元题须实测简单基线0、参考解1，否则不构成有效的参考提升")
        return
    if metric.get("kind") != "continuous":
        raise ValueError("kind须为binary或continuous")
    direction = metric.get("direction")
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction须为maximize或minimize")
    baseline = finite_number(metric.get("baseline"), "baseline")
    reference = finite_number(metric.get("reference"), "reference")
    tolerance = finite_number(metric.get("tolerance"), "tolerance")
    if tolerance < 0:
        raise ValueError("原始指标容差不能为负")
    improvement = reference - baseline if direction == "maximize" else baseline - reference
    if not math.isfinite(improvement) or improvement <= tolerance:
        raise ValueError("参考解相对基线的改善须超过原始指标容差；请先核查设置")


def quality_score(metric, raw_metric, status="completed"):
    validate_metric(metric)
    if status in VALID_FAILURES:
        return 0.0
    if status != "completed":
        raise ValueError("基础设施或评分器故障不能填0；请先处理并补跑")
    value = finite_number(raw_metric, "raw_metric")
    if metric["kind"] == "binary":
        if value not in {0.0, 1.0}:
            raise ValueError("二元任务的实测结果须为0或1")
        return value
    baseline = float(metric["baseline"])
    reference = float(metric["reference"])
    fraction = (value - baseline) / (reference - baseline)
    return max(0.0, min(1.0, fraction))
numpy==2.1.3
scipy==1.14.1
mpmath==1.3.0

exit_code=0
```

===== PDF PAGE 161 =====
69 BANKS–CASHER RELATION 283
69. Banks–Casher Relation Quantum chromodynamics, if restricted to the up and down
quarks, has a nearly exact chiral symmetry thanks to the very small masses of these quarks.
The three pions (π0,π±) are also much lighter than the other hadrons, a property which is
understood as a consequence of them being the Nambu–Goldstone bosons that result from the
spontaneous breaking of chiral symmetry (fromSU(2)×SU(2) toSU(2), hence three pions
corresponding to the three broken symmetries – note that their masses are not exactly zero,
because the symmetry was not exact to begin with). The goal of this problem is to establish a
relationship, known as the Banks–Casher relation, between the value of the chiral condensate⟨
ψψ
⟩
(which should be zero if chiral symmetry holds, and which may be viewed as the order
parameter for its spontaneous breaking) and the spectral density at zero energy of the Dirac
operator. Consider Euclidean QCD in the continuum.
69.a Show that the expectation value
⟨
ψ(x)ψ(x)
⟩
can be written as
⟨
ψ(x)ψ(x)
⟩
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM [A] det (i/D −m) trV
[ 1
i/D −m
]
,
whereV is a four-dimensional Euclidean volume to which the trace is restricted, andZ
is the same integral without the trace and the prefactor1/V.
69.b Recalling the properties of the Euclidean Dirac operator, write the trace as follows:
trV
[ 1
i/D −m
]
=
∑
n
1
iλn −m =−
∑
n
m
λ2n +m2,
where theλn are real numbers.
69.c Show that
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
69.d Show that, in the limits of inﬁnite volume and zero quark mass, we have⟨
ψ(x)ψ(x)
⟩
=− π limV→∞ ρV (0).


===== PDF PAGE 162 =====
284 5 LATTICE, FINITE T , STRONG FIELDS
69.a Note ﬁrst that the equal-point correlation function
⟨
ψ(x)ψ(x)
⟩
is independent of the
pointx thanks to translation invariance. Therefore, we may write
⟨
ψ(x)ψ(x)
⟩
= lim
V→∞
1
V
∫
V
d4x⟨ψ(x)ψ(x)⟩,
where V is a ﬁnite volume in Euclidean R 4. Then, it admits the following path integral
representation:
⟨
ψ(x)ψ(x)
⟩
= 1ZV ∫ [DAμDψDψ] e−SYM −SD ∫V d4x ψ(x)ψ(x)
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM det (i/D −m)
∫
V
d4x⟨x⏐⏐ 1i/D −m⏐⏐x⟩
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM det (i/D −m) trV
[ 1
i/D −m
]
, (5.18)
where Z ≡
∫
[DAμDψDψ] e−SYM −SD.
In this formula, it is implicitly understood that the integrand is calculated for a ﬁnite volume
theory, in which the spectrum of the Dirac operator is discrete. The limit V →∞ ensures that
we recover the original theory in the end.
69.b The Euclidean Dirac matrices are anti-Hermitian,γμ† =− γμ, as is the derivative∂μ.
Therefore, the Euclidean Dirac operator is Hermitian, and it can therefore be diagonalized in
an orthonormal basis with real eigenvalues:
/Dψn(x)= λnψn(x),λ n ∈ R ,
∫
V
d4xψ∗m(x)ψn(x)= δmn.
(Note that the eigenvalues depend implicitly on the background gauge ﬁeldAμ.) The trace of
the inverse of the Dirac operator can be expressed in terms of these eigenvalues as follows:
trV
[ 1
i/D −m
]
=
∑
n
1
iλn −m.
On the other hand, sinceγ5γμγ5 = γμ† =− γμ, we can write
trV
[ 1
i/D −m
]
= trV
[
γ5γ5 1i/D −m] = trV [γ5 1i/D −mγ5]
= trV
[ 1
−i/D −m
]
=
∑
n
1
−iλn −m.
By taking the half-sum of the two representations of the trace, we arrive at
trV
[ 1
i/D −m
]
=−
∑
n
m
λ2n +m2 =−
∫
dλ
[ ∑
n
δ(λ −λn)
] m
λ2 +m2.


===== PDF PAGE 163 =====
70 NIELSEN–NINOMIYA THEOREM 285
69.c Inserting this expression in (5.18), we immediately get
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
The integrand in the deﬁnition ofρV (λ) is a distribution that has a delta peak at each eigenvalue
of the ﬁnite volume Dirac operator, and its integral over some range [λ1,λ2] counts the number
of eigenvalues in that range, per unit of volume V. The average over all conﬁgurations of
the gauge ﬁeldAμ washes out the delta peaks and turnsρV (λ) into a smooth distribution that
provides the average density of eigenvalues of the Dirac operator:
∫λ2
λ1
dλ ρV (λ)=
⟨# of eigenvalues in [λ1,λ2]
V
⟩
A
.
Note that this distribution has a gap at the lower end of the spectrum because of the ﬁnite
volume.
69.d As the volume increases, the gap at the lower end decreases, andρV (λ) has support in
the entire range [0, +∞) in the inﬁnite-volume limit. Moreover, when the quark mass goes to
zero, we have
lim
m→0+
m
λ2 +m2 = πδ (λ).
Therefore, we have
lim
m→0+
⟨
ψ(x)ψ(x)
⟩
=− π lim
V→∞
ρV (0).
This relation is known as the Banks–Casher relation. The left hand side is a quantity known
as the chiral condensate. In the massless limit, the Dirac Lagrangian is invariant under chiral
transformations, since it does not contain an operator ψψ (which breaks chiral symmetry).
A non-zero expectation value of this operator therefore signals that the ground state of the
theory breaks chiral symmetry. The Banks–Casher formula relates the chiral condensate, which
quantiﬁes the spontaneous breaking of chiral symmetry, to the spectral density at the lower
end of the spectrum of the Dirac operator (the latter is controlled by how quickly eigenvalues
accumulate nearλ = 0 when the volume becomes inﬁnite).
Source: Banks, T. and Casher, A. (1980), Nucl Phys B 169: 103.
70. Nielsen–Ninomiya Theorem The goal of this problem is to prove theNielsen–Ninomiya
theorem, an obstruction to the construction of chiral gauge theories on the lattice. Consider
an inﬁnite square lattice of spacing a. The conjugate momenta pμ are continuous variables
with components in the range
[
− πa, +πa] and any function ofpμ is periodic with period 2π/a.In other words, we may view momentum space as a four-dimensional torusT4. The inverse
propagator of a massless left-handed fermion can be written as S−1(p)= ∑μ γμPLFμ(p),
whereFμ(p) is a real continuous vector ﬁeld onT4 andPL ≡ (1 −γ5)/2.


===== PDF PAGE 164 =====
286 5 LATTICE, FINITE T , STRONG FIELDS
70.a Explain why such a fermion exists if the vector ﬁeldFμ(p) has a zeropμ∗ in the vicinity
of which it behaves asFμ(p)=( p −p∗)μ +O((p −p∗)2). Note that the ﬁeld lines of
Fμ are all pointing away fromp∗.
70.b Consider now a zero ofFμ(p) at which the ﬁeld lines are incoming in one direction and
outgoing in the other three directions, such asFμ(p)=( − 1)δμ1 (p−p∗)μ +O((p−p∗)2).
Show that this zero in fact describes a right-handed particle. Hint: apply a similarity
transformation γ1γ5. Use this result to explain why, in one dimension, there must be
equal numbers of left-handed and right-handed fermions in the spectrum of the lattice
Dirac operator.
70.c More generally, explain the relationship between the handedness of a fermion and the
number of “ingoing directions” of the vector ﬁeldFμ at a zerop∗.
70.d The index of a zero of a vector ﬁeld is deﬁned as (−1)n, where n is the number of
dimensions along which the ﬁeld lines are ﬂowing away from the zero. The Poincar´e–
Hopf theorem states that the sum of the indices of the zeroes of a vector ﬁeld is equal to
the Euler characteristic of the manifold on which it is deﬁned, which is zero for a torus.
Use this result to conclude that this lattice setup in fact has equal numbers of left-handed
and right-handed fermions.
70.a The form S−1(p)= ∑μ γμPLFμ(p) for the inverse propagator assumes (discrete)
translation invariance on the lattice, and that the lattice is inﬁnite, so that the conjugate
momentum space is continuous rather than discrete. Because of the ﬁnite lattice spacing, the
momentumpμ is deﬁned on a four-dimensional torusT4 (each component of the momentum is
bounded, and the bounds in the positive and negative directions are identiﬁed) rather than R 4.
The functionFμ(p) is real if the Lagrangian is Hermitian, and is continuous provided the theory
is quasi-local (i.e., when the action is written as S ≡ ∑x,y ψ(x)h(x,y)ψ(y), the function
h(x,y) should decrease fast enough). Since Fμ(p) has as many components (μ = 1,2,3,4 )a s
its argumentp, it is a vector ﬁeld. Moreover, Fμ(p) may be viewed locally as the gradient of a
scalar function F(p),Fμ(p)= ∂pμF(p).
A massless fermion corresponds to a momentump∗ where the inverse Dirac propagator
vanishes linearly (think of the propagatori//p in the continuous theory). This means that all
the components ofFμ(p) vanish simultaneously atp∗,
Fμ(p) ∼ fμν(p −p∗)ν.
By an appropriate change of coordinates, the matrix of coefﬁcientsfμν can be made diagonal,
with only positive coefﬁcients. Up to a rescaling (by positive factors) of the components of pμ,
this implies the announced behavior nearp∗. These zeroes of the vector ﬁeldFμ(p) correspond
to minima of F(p). About such a zero, the ﬁeld lines of Fμ are all oriented outwards fromp∗.
Note that, because we have included an explicit projectorPL in the deﬁnition of the inverse
propagator, these zeroes describe left-handed fermions.


===== PDF PAGE 165 =====
70 NIELSEN–NINOMIYA THEOREM 287
70.b Let us now ﬂip the orientation of the ﬁeld lines along one direction, i.e., consider a zero
for which the ﬁeld lines are ﬂowing away along three directions and into the zero along the
remaining direction (for instance the directionμ = 1):
Fμ(p)=( − 1)δμ1 (p −p∗)μ +O((p −p∗)2).
As suggested in the statement of the problem, we should study the following combination:
(γ1γ5)−1(−1)δμ1γμPL (γ1γ5)= γ5γ1(−1)δμ1γμPLγ1γ5
=
{
μ = 1 :− γ5γ1γ1PLγ1γ5 = γ1PR
μ ⁄= 1 :+ γ5γ1γμPLγ1γ5 = γμPR
}
= γμPR.
(Note that we also have (γ1γ5)−1(−1)δμ1γμPR (γ1γ5)= γμPL .) Therefore, this type of zero
describes (in disguise, i.e., up to a similarity) a massless fermion of right-handed chirality. This
observation is sufﬁcient to prove the Nielsen–Ninomiya theorem in one dimension: indeed, a
smooth vector ﬁeld on a circle must have an equal number of zeroes where the ﬁeld lines go
towards the zero (corresponding to left-handed fermions) and zeroes where the ﬁeld lines go
away from the zero (corresponding to right-handed fermions).
70.c Consider now a zero such that the vector ﬁeld is ﬂowing into the zero along two
directions and away from it along two directions. If the two dimensions along which the ﬁeld
is ﬂowing inwards areμ = 1,2 , we need now to considerFμ(p)=( − 1)δμ1 (−1)δμ2 (p −p∗)μ.
We have
(γ2γ5)−1(−1)δμ2
[
(γ1γ5)−1(−1)δμ1γμPL (γ1γ5)](γ2γ5)
=( γ2γ5)−1(−1)δμ2γμPR (γ2γ5)= γμPL.
Thus, this zero corresponds to a left-handed fermion. The pattern should be clear by now:
the chirality of the fermion ﬂips every time we add a direction along which the vector ﬁeld is
ﬂowing into the corresponding zero. In more mathematical terms, if a1,...,a p are distinct
integers in [1,4 ],w eh a v e
(γapγ5)−1 ··· (γa1γ5)−1
[
(−1)μa1 ··· (−1)μapγμPL
]
(γa1γ5)··· (γapγ5)
=
{γμPL ifp is even,
γμPR ifp is odd.
In words, the zero describes a left-handed fermion if the ﬁeld lines are ﬂowing into the
zero along an even number of directions, and a right-handed fermion for an odd number of
directions.
70.d The index of a zero of a vector ﬁeld is deﬁned as (−1)n, where n is the number
of dimensions along which the ﬁeld lines are ﬂowing away from the zero (see Figure 5.1).
Therefore, ind dimensions, we have the following correspondence between the index of a zero


===== PDF PAGE 166 =====
288 5 LATTICE, FINITE T , STRONG FIELDS
Figure 5.1 Two-dimensional vector ﬁelds with zeroes of index +1 (Left: Fμ(p)= pμ) and −1
(Right: Fμ(p)=( − 1)δμ1pμ).
ofFμ and the chirality of the fermion it describes:
index= (−1)d ←→ left-handed,
index= (−1)d+1 ←→ right-handed.
The usefulness of this concept in the present discussion stems from thePoincar´e–Hopf theorem,
which relates the sum of the indices of the zeroes of a smooth vector ﬁeld deﬁned on a manifold
M without boundary to a topological invariant of this manifold, namely its Euler characteristic,
denoted byχ(M):
∑
zeroesz∗
index (z∗)= χ(M).
For two-dimensional manifolds, the Euler characteristic can be easily visualized and calculated
from any triangulation of the surface, since it is given by
χ(M)=( number of vertices)−( number of edges)+( number of faces).
(See Problem 42 for a discussion of the main properties of this quantity, in particular the fact
that it does not depend on the chosen triangulation.) From this deﬁnition, one may see that the
Euler characteristic of a2-sphere isχ = 2 and that it isχ = 0 for a two-dimensional torus with
one handle. This implies that any smooth vector ﬁeld on such a torus must have equal numbers
of zeroes of index +1 and −1, as illustrated in Figure 5.2. In the discussion of chiral fermions
on the lattice, this result implies that any such propagator would in fact describe equal numbers
of left-handed and right-handed fermions in two dimensions, despite the fact that we have put
an explicit projectorPL in it. This obstruction to the possibility of deﬁning chiral fermions on
the lattice is known as the Nielsen–Ninomiya theorem.
The Euler characteristic is in fact zero for one-holed tori in any dimension (but this is harder
to visualize in dimensions higher than two), in particular for the torusT4 on which the vector
Fμ(p) that enters in the inverse fermion propagator is deﬁned. Thus, the Nielsen–Ninomiya
theorem is also valid in four dimensions.


===== PDF PAGE 167 =====
70 NIELSEN–NINOMIYA THEOREM 289
Figure 5.2 Illustration of the Poincar´e–Hopf theorem: smooth vector ﬁeld on a torus in two
dimensions with a zero of index +1 (open circle) and a zero of index −1 (ﬁlled circle).
Sketch of a Proof of the Poincar ´e–Hopf Theorem: The ﬁrst step in proving the Poincar´e–
Hopf theorem is to show that the sum of the indices of the zeroes is the same for all the
smooth vector ﬁelds. In fact, one can show (see, for instance, Milnor, J. W. (1997),Topology
from the Differentiable Viewpoint (Princeton University Press)) that the sum of the indices
of any smooth vector ﬁeld on a d-dimensional manifold M is equal to twice the degree of
the Gauss mapping fromM to the sphereSd (loosely speaking, this degree counts how many
times the Gauss mapping wraps around Sd), and is therefore a property of M itself. Then one
could invoke the Gauss–Bonnet theorem (see Problem 22) to relate this quantity to the Euler
characteristic.
A more elementary approach is to construct a special vector ﬁeld on M for which it is
easy to relate the sum of the indices to the Euler characteristic χ(M). For this, we start from a
triangulation of the manifoldM. For a two-dimensional manifold, this is a decomposition of
M into planar triangles, while in three dimensions it is a decomposition into tetrahedrons, and
more generally a decomposition ind-simplices ind dimensions. Note that, in a triangulation,
d-dimensional simplices meet at a (d −1)-dimensional simplex, etc. On such a triangulation,
consider the vector ﬁeld of Figure 5.3 (illustrated here in two dimensions). In this ﬁgure, the
triangle in boldface shows the conﬁguration of the ﬁeld lines in one cell of the triangulation,
and all the other triangles simply replicate the same pattern. This ﬁeld has zeroes at all the
vertices of the triangulation, at the midpoints of all the edges, and at the centers of all the
triangles. Moreover, if we count the number of dimensions along which the ﬁeld lines are
oriented away from these zeroes, we have
index (vertex)=+ 1,
index (edge midpoint)=− 1,
index (face center)=+ 1,
and the sum of the indices at all these zeroes reads
∑
zeroesz∗
index (z∗)=( number of vertices)−( number of edges)+( number of faces),
which is nothing but the deﬁnition of the Euler characteristic for a two-dimensional manifold.


===== PDF PAGE 168 =====
290 5 LATTICE, FINITE T , STRONG FIELDS
Figure 5.3 Special vector ﬁeld used in the proof of the Poincar´e–Hopf theorem (here, in two
dimensions). Left: layout of the main ﬁeld lines on top of a triangulation of the surface. Right:
detail of the ﬁeld lines in one elementary triangle.
In higher dimensions, one may construct a similar vector ﬁeld, with zeroes at the centers of
all thek-simplices (k ≤ d) that make up the triangulation, and the above pattern generalizes to
index (center ofk-dim simplex)=( − 1)k.
Therefore, for such a ﬁeld conﬁguration ind dimensions, we have
∑
zeroesz∗
index (z∗)=
d∑
k=0
(−1)k × (number ofk-dim simplices),
which is again the deﬁnition of the Euler characteristic of a d-dimensional manifold. Al-
though explicit, the right-hand side of this equation is less practical for calculating the Euler
characteristic in dimensions greater than two because it is hard to visualize triangulations of
higher-dimensional manifolds.
Source: Karsten, L. H. (1981), Phys Lett B 104: 315.
71. Wigner Transform of a Convolution Product The Wigner transform of a two-point
functionF(x,y ) is a function F(X,p ) obtained by Fourier transformingF(x,y ) with respect to
the differencex −y while keeping the dependence on the midpoint coordinateX ≡ (x +y)/2:
F(X,p ) ≡
∫
ddse ip·s F(X + s2,X − s2 ).
Consider a pair of two-point functionsF(x,y ) andG(x,y ) and their convolutionH(x,y ) ≡∫
ddzF (x,z )G(z,y ). Show that their respective Wigner transforms are related by
H(X,p )= F(X,p ) exp
{i
2
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]}
G(X,p ). (5.19)
This result plays a role in the derivation of the Boltzmann equation from the Kadanoff–Baym
equations. It is also an important ingredient in the formulation of quantum mechanics in


===== PDF PAGE 169 =====
71 WIGNER TRANSFORM OF A CONVOLUTION PRODUCT 291
phase-space, proposed by Moyal and Groenewold (Groenewold, H. J. (1946), Physica 12: 405;
Moyal, J. E. and Bartlett, M. S. (1949),Math Proc Cambridge Philos Soc 45: 99). Hint: one
may instead prove an equivalent relationship between the operators F,G,H obtained from
F, G, Hvia Weyl mapping (see Problem 18).
The formula announced in the statement of the problem is intimately related to Weyl
quantization prescription and to the fact that the Wigner transform is the inverse of Weyl
mapping (this result is shown in Problem 18). Note ﬁrst that a two-point function like F(x,y )
may always be viewed as the coordinate representation of an operatorF (in this problem, we
use boldface letters for quantum operators). In particular, we have
F(x,z )=
⟨
x
⏐⏐F⏐⏐z⟩,G (z,y )= ⟨z⏐⏐G⏐⏐y⟩,
H(x,y )=
∫
ddz⟨x⏐⏐F⏐⏐z⟩⟨z⏐⏐G⏐⏐y⟩ =⟨x⏐⏐FG⏐⏐y⟩.
The last equality uses the completeness of the position eigenstates, and shows that the function
H(x,y ), deﬁned as the convolution product ofF andG, is the coordinate space representation
of the product of operatorsFG.
In order to streamline the notation, let us collectively denote the phase-space coordinates
byu ≡ (X,p ), and do the same with the corresponding quantum operators, denoting them by
u ≡ (X,p). The commutators among these operators have the following generic form:
[um,un]= iθmn,
where the θmn are commuting numbers. Let us also denote ∂m ≡ ∂/∂um. Equipped with this
notation, the “product” on the right-hand side of (5.19) can be rewritten compactly as
F(X,p ) exp
{i
2
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]}
G(X,p )= F(u)e
i
2θmn
←
∂m
→
∂nG(u)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ (F⋆G)(u)
.
The ⋆ operation is known as the Moyal product. The identity we wish to prove is that the
Wigner transform of a product of operators is equal to the Moyal product of their respective
Wigner transforms:
(5.19) ⇐⇒ Wigner
(
FG
)
= Wigner
(
F
)
⋆ Wigner
(
G
)
.
Since the Wigner transform is the inverse of Weyl mapping (see Problem 18), this identity is
equivalent to
Weyl(F ⋆G)= Weyl(F)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
F
Weyl(G)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
G
,
where Weyl(·) denotes the Weyl mapping of a function deﬁned on the classical phase-space.
In terms of the compact notation we have introduced, the Weyl mapping of a functionA can
be written in two steps,
~A(τ) ≡
∫ d2du
(2π)2d e−iu·τ A(u), Weyl(A)(u) ≡
∫
d2dτe iu·τ ~A(τ).
The ﬁrst step is a Fourier transform whose result is an ordinary function of the variables τ
(Fourier conjugates of the classical phase-space variables). The second one looks like the


===== PDF PAGE 170 =====
292 5 LATTICE, FINITE T , STRONG FIELDS
inverse Fourier transform, but this time one uses the quantum operatorsu instead ofu, and the
result is an operator.
Then, we can rearrange the expression for the Moyal product as follows:
(F ⋆G)(u)= F(u)e
i
2θmn
←
∂m
→
∂n G(u)
=
∫
d2dτd2dσ~F(τ)~G(σ) eiu·τ ei2θmn←∂m→∂n eiu·σ
=
∫
d2dτd2dσ~F(τ)~G(σ) eiu·τ ei2θmn(iτm)(iσn) eiu·σ
=
∫
d2dτd2dσ~F(τ)~G(σ) eiu·(τ+σ) e−i2θmnτmσn.
Let us now calculate the Weyl mapping of this function. In fact, since it is already written as a
Fourier integral, this just amounts to replacing the phase-space coordinatesu by the quantum
operatorsu in the integrand:
Weyl(F ⋆G)(u)=
∫
d2dτd2dσ~F(τ)~G(σ) eiu·(τ+σ) e−i2θmnτmσn. (5.20)
To simplify this expression, we use the Baker–Campbell–Hausdorff formula to write
eiu·(τ+σ) = eiu·τ eiu·σ e12 [um,un]τmσn = eiu·τ eiu·σ ei2θmnτmσn.
We see that the last factor of this formula cancels the last factor of (5.20), so that the result in
fact factorizes:
Weyl(F ⋆G)(u)=
( ∫
d2dτe iu·τ~F(τ)
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Weyl(F)(u)
)
×
( ∫
d2dσe iu·σ ~G(σ)
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Weyl(G)(u)
)
,
which proves the announced result.
Quantum Mechanics in Phase-Space: The Moyal product in fact allows a complete refor-
mulation of quantum mechanics in terms of functions that depend on the classical phase-space
variables:
Phase-space function: Operator:
F(X,p )
Weyl mapping
−−−−−−−−−−−−−→ F←−−−−−−−−−−−−−Wigner transform
F(X,p ) ⋆G(X,p ) ←−−−−−−−−−−−→ FG
In this framework, known as the Moyal–Groenewold quantization, quantum operators are
replaced by classical phase-space functions obtained via the Wigner transform, the product of
operators is replaced by the Moyal product of phase-space functions, and their commutator
is replaced by a Moyal commutator, [F, G]⋆ ≡ F ⋆ G − G ⋆ F. Although this formalism is
technically challenging to work with, it offers a more intuitive picture of what “quantization”
means, since the Moyal commutator is a deformation of the classical Poisson bracket{F, G}


===== PDF PAGE 171 =====
72 CENTER SYMMETRY AND DECONFINEMENT 293
controlled by the continuously varying parameter ¯h. Indeed, from the expression for the Moyal
product, the Moyal commutator reads
F ⋆G −G ⋆F = 2i¯h F sin {i ¯h2 [ ←∂X →∂p − →∂X ←∂p ]}G
= {F, G} + ¯h2
24 F
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]3 G +··· .
(We have reinstated Planck’s constant in this formula, using the fact that it has the dimensions
of an action.) From this expression, we also see that
F ⋆G −G ⋆F = {F, G}
if at least one of the functions F, Gis a polynomial of degree two in X,p . Thus, the Moyal–
Groenewold quantization of a theory with a quadratic Hamiltonian (e.g., a harmonic oscillator)
is particularly simple: its phase-space density obeys the classical Liouville evolution equation
even when ¯h ⁄= 0.
72. Center Symmetry and Deconfinement The goal of this problem is to study an
extension of gauge symmetry called center symmetry,i na SU(N) Yang–Mills theory at ﬁnite
temperature in the imaginary time formalism. In particular, we show that the deconﬁnement
transition may be viewed as a breaking of center symmetry.
72.a The center of a gauge group is the subgroup made of the elements that commute with the
entire group. In the case of SU(N), show that the center is Z N ≡ {e2iπk/N}0≤k<N, i.e.,
the set of theN-th roots of unity (multiplied by the identity matrix). Hint: ﬁrst, show
that the center of U(N) is the complex unit circle.
72.b At ﬁnite temperature, legitimate gauge transformations should be singled-valued in
imaginary time, i.e., beβ-periodic,Ω(β,x)= Ω(0,x). Consider now a more general
transformation, called a center transformation, deﬁned as a gauge transformation with a
non-periodicΩ. Instead, Ω(τ,x) is assumed to obeyΩ(β,x)= ξΩ(0,x) withξ ∈ Z N.
Show that center transformations also preserve the periodicity of the gauge ﬁeld.
72.c A Polyakov loop is the trace of a Wilson loop that wraps around the imaginary time
direction, at ﬁxed positionx:
L(x) ≡ N−1 tr⟨Pe x p∫β
0
dτA0(τ,x)⟩.
Show that L(x) is invariant under the usual (periodic) gauge transformations, but not
invariant under center transformations. What does this imply for the center transforma-
tions?
72.d Explain whyL(x) is related to the free energyFq of an inﬁnitely massive quark added
to the system at the pointx by
⏐⏐L(x)⏐⏐ = e−βFq (i.e., the energy necessary for bringing
the quark from inﬁnity, arbitrarily slowly). From this interpretation, conclude thatL(x)
should be zero in the conﬁning phase of Yang–Mills theory, and that one may view
deconﬁnement as a breaking of the center symmetry.


===== PDF PAGE 172 =====
294 5 LATTICE, FINITE T , STRONG FIELDS
72.e Why is the center symmetry explicitly broken if dynamical quarks in the fundamental
representation are added to the theory? What about adding matter ﬁelds in the adjoint
representation?
72.a Consider ﬁrst the case of the group U(N) ofN×N unitary matrices. A matrix A is
in the center ofU(N) ifA = PAP−1 for all unitary matricesP. Since A is unitary, it can be
diagonalized by a unitary transformation, which implies that we can reduce the discussion to
diagonal matrices. Therefore, let us now assume that A is diagonal, but not proportional to the
identity. This means that there exists a pair of indicesi ⁄= j such thatAii ⁄= Ajj. Now, denote
byQ the matrix obtained by swapping the columnsi,j of the identity, and deﬁneB ≡ QAQ−1.
Note that Q = Q† = Qt and QQ = 1, hence Q is unitary. A simple calculation shows that
Bii = Ajj andBjj = Aii, which implies thatB ⁄= A, i.e.,
QAQ−1 ⁄= A,
in contradiction to the fact that A was assumed to be in the center of the group. Thus, our
hypothesis thatA is not proportional to the identity was inconsistent, and we conclude that
center
(
U(N)
)
=
{
c·1N×N,|c| = 1
}
.
(The constraint on the modulus ofc is necessary to have unitary matrices.)
Consider now the case of SU(N). It is useful to recall that any matrix of U(N) can be
written as the product of a phase by a matrix ofSU(N):
U = eiθV, U ∈ U(N),V ∈ SU(N),θ ∈ R .
IfA is in the center ofSU(N) andU is inU(N),w eh a v e
UAU−1 = VAV−1/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= A
= A.
Therefore A is also in the center of U(N) and must be of the form c · 1N×N . Since the
determinant of such a matrix is cN,c must be one of the N-th roots of unity in order to have a
matrix ofSU(N). This group is denoted Z N.
72.b Consider a transformationΩ(τ,x) that has the following boundary condition:
Ω(β,x)= ξΩ (0,x), withξ ∈ Z N.
Calculate the transformed gauge ﬁeld atτ = β (assuming that the gauge ﬁeld wasβ-periodic
before applying the transformation):


===== PDF PAGE 173 =====
72 CENTER SYMMETRY AND DECONFINEMENT 295
Ω†(β,x)Aμ(β,x)Ω(β,x)+ igΩ†(β,x)∂μΩ(β,x)
= Ω†(0,x)ξ∗Aμ(0,x)ξΩ(0,x)+ igΩ†(0,x)ξ∗∂μξΩ(0,x)
= Ω†(0,x)Aμ(0,x)Ω(0,x)+ igΩ†(0,x)∂μΩ(0,x).
In the ﬁnal step, theξ andξ∗ cancel because we are allowed to move them throughAμ since
they belong to the center of SU(N). Despite the fact that this transformation is not β-periodic,
it nevertheless preserves the periodicity of the gauge ﬁelds. Therefore, these more general
transformations may be viewed as an extended symmetry of Yang–Mills theory (called center
symmetry) at ﬁnite temperature.
72.c Recall that a Wilson line Wγ(y,x ) along any path γ between the points x and y
transforms into Ω(y)Wγ(y,x )Ω†(x) under a gauge transformation. Therefore, the trace of
a Wilson loop is gauge invariant (and the Polyakov loop is just a special kind of Wilson
loop). But the cancellation of Ω(β,x) withΩ†(0,x) inside the trace works only whenΩ is
β-periodic, and therefore it fails with the generalized transformations considered above. In this
case, the Polyakov loop is not invariant, but is multiplied by an elementξ ∈ Z N of the center:
L(x) → ξL (x).
Since the Polyakov loop is gauge invariant, it should be considered as an observable of the
theory. Thus, the center transformations can alter the physical content of the system (i.e., they
are not just a reparameterization of redundant degrees of freedom). The only exception to this
statement occurs when L(x)= 0, since this value of the Polyakov loop is left invariant by
center transformations.
72.d The energy gainFq of the system due to bringing (inﬁnitely slowly, to avoid disturbing
the system) a heavy quark of massM at the pointx from inﬁnity may be written as follows:
e−β(Fq+M) =
∑
α
⟨
α +q(x)
⏐⏐e−βH⏐⏐α +q(x)⟩∑
α
⟨
α
⏐⏐e−βH⏐⏐α⟩
(the factore−βM, that contains the rest energy of the quark, has been explicitly added so that
Fq measures only the energy due to the interactions of the quark with its environment), where⏐⏐α +q(x)⟩ denotes the pure gluon state⏐⏐α⟩ to which a quark (of spin s and colori) is added
at the locationx:
⏐⏐α +q(x)⟩ ≡ ∫ d3p(2π)32Ep e−ip·x f(p)vs(p)b†sip/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ ψsi(x)
⏐⏐α⟩.
The functionf(p) is a wave-packet normalized according to


===== PDF PAGE 174 =====
296 5 LATTICE, FINITE T , STRONG FIELDS
∫ d3p
(2π)3
⏐⏐f(p)⏐⏐2 = 1,
which ensures that
⟨
α +q(x)
⏐⏐α +q(x)⟩ =⟨α⏐⏐α⟩. Interpreting the canonical density operator
as an imaginary time evolution, we can write
ψ†si(τ,x)e−βH = e−βH ψ†si(τ +β,x),
and the quark free energy becomes
e−β(Fq+M) = tr (e−βH ψ†si(β,x)ψsi(0,x))tr (e−βH) .
(Note that there is no sum on the spins and the colori in this expression.) Loosely speaking,
the right-hand side is the thermal expectation value of the propagator of the heavy quark
between the times τ = 0 and τ = β (the problem is translation invariant, and we may thus
choose the ﬁrst time to be0). To promoteψsi(x) to a time-dependent object, we use Dirac’s
equation. In the limit of large mass, M →∞ , wherep0 ≈ M,|p| ≪ M, the Dirac equation
simpliﬁes to
((∂τ −gA0)γ0 −M)ψ = 0.
Moreover, in this kinematical limit, we also haveγ0vs(p)=− vs(p). Therefore, for a spinor
proportional tovs(p), the Dirac equation becomes
(∂τ −gA0 +M)ψ = 0,
whose solution reads
ψ(τ,x)= e−Mτ Te x p(g ∫τ
0
dτ′ A0(τ′,x))
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ U(τ,x)
ψ(0,x).
(The time ordering is necessary becauseA0 is a matrix in su(N).) Therefore, we can write
ψsi(τ,x) ≡ e−Mτ ∑
j
Uij(τ,x)
∫ d3p
(2π)32Ep e−ip·x f(p)vs(p)b†sjp,
which leads to
e−βFq = eβM ∑
j
tr (e−βH ψ†sj(0,x)Uji(β,x)e−βMψsi(0,x))
tr (e−βH)
= 1N ∑i,j tr (e−βH ψ†sj(0,x)Uji(β,x)ψsi(0,x))tr (e−βH) .
In the last equality, we have used the fact that the free energy is independent of the quark color
i in order to introduce an average overi. In the evaluation of this expectation value, the product


===== PDF PAGE 175 =====
73 PHOTON HARD THERMAL LOOP FROM CLASSICAL PARTICLES 297
of the two free spinors simply yields
ψ†sj(0,x)ψsi(0,x)=
∫ d3pd3q
(2π)64EpEq ei(p−q)·x bsjpb†siq/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−b†siqbsjp+(2π)32Epδijδ(p−q)
f∗(p)f(q)v†s(p)vs(q).
The term in −b†siqbsjp gives zero when inserted in the trace, because it has a fermion
annihilation operator acting to the right on a pure gluonic state. Thus, only the term in
(2π)32Epδijδ(p −q) contributes:
ψ†sj(0,x)ψsi(0,x) → δij
∫ d3p
(2π)32Ep
⏐⏐f(p)⏐⏐2 v†s(p)vs(p)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 2Ep
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 1
= δij.
The factorδij then leads precisely to the trace of the Polyakov loop over its color indices.
In the conﬁning phase, isolated quarks cannot exist; in other words, it would cost an inﬁnite
amount of energy to bring one from inﬁnity (i.e., Fq =+ ∞). Therefore, the expectation value
of the Polyakov loop should be zero in this phase, and center symmetry is preserved (since
zero times any element of Z N is still zero). On the other hand, isolated quarks cost only a ﬁnite
energy in the deconﬁned phase, and the center symmetry is broken since the expectation value
of Polyakov loops is not zero. Therefore, one may view the expectation value of the Polyakov
loop as an order parameter for the deconﬁnement transition in pure Yang–Mills theory.
72.e Under the transformationΩ(τ,x), a fermion in the fundamental representation trans-
forms as
ψ(τ,x) → Ω†(τ,x)ψ(τ,x).
Therefore, the center transformations do not preserve the β-anti-periodicity of the spinors,
implying that the center symmetry is explicitly broken by the presence of dynamical quarks in
the fundamental representation. Therefore, in QCD with quarks, the expectation value of the
Polyakov loop is no longer a good order parameter for the deconﬁnement transition.
IfΦa is a ﬁeld in the adjoint representation, it transforms as
Φa → ΩabΦb, i.e., Φatar → Ω†rΦatar Ωr.
In the second form, it is clear that the ξ ∈ Z N of the center transformation cancels out, leaving
a transformed ﬁeld which is still β-periodic (or anti-periodic if it is a fermion). Therefore,
a theory with matter ﬁelds in the adjoint representation would be invariant under the center
symmetry.
Source: McLerran, L. D. and Svetitsky, B. (1981), Phys Rev D 24: 450.


===== PDF PAGE 176 =====
298 5 LATTICE, FINITE T , STRONG FIELDS
73. Photon Hard Thermal Loop from Classical Particles In this problem, we use
the concept of a classical particle developed in Problem 31 in order to derive the effective
Lagrangian that generates hard thermal loops in QED. This derivation illustrates the classical
nature of hard thermal loops, and is also a good workout in preparation for the QCD case (see
Problem 74).
73.a Find a suitable generalization of the equations of motion discussed in Problem 37 to
describe the evolution of the position and momentum of a massless charged particle in
an external electromagnetic ﬁeld.
73.b Consider a collection of classical electrons and positrons, with a phase-space density
f(x,p ). Why do we have df/dτ = 0? Using the equations of motion of the classical
particles, turn this equation into a kinetic equation.
73.c Consider now an expansion off,f = f0 +f1 +··· , wheref0 is a distribution independent
of the external ﬁeld. Formally solve the kinetic equation in order to obtain the ﬁrst
correction in the external ﬁeld,f1.
73.d Determine the electromagnetic current Jμ induced by f1 (assume that f0 produces no
current). Then, determine an effective LagrangianLeff such thatJμ = ∂Leff/∂Aμ.
73.e Show that its second derivative, −δLeff/δAμδAν, is the photon polarization tensorΠμνHTL
in the hard thermal loop approximation.
73.a In the classical particle approximation of Problem 37, the charged particles feel the
effect of the background electromagnetic ﬁeld, but their own radiation is not considered.
Therefore, the particles do not feed the electromagnetic ﬁeld, and there are no interactions
between the charged particles. Since we are going to consider the ultra-relativistic limit, we
need to adapt the equations of motion to the case of massless particles. Formally, we can start
from the equations obtained in Problem 37, and deﬁneτ ≡ t/m before completely eliminating
m. This leads to
pμ = dxμ
dτ , dpμdτ = eFμνpν.
Note that since the particles are massless, τ is not really a time but simply some parameter that
maps the trajectory of a particle (in fact, this parameter has the dimensions of a squared time).
73.b Let us denote by f(x,p ) the phase-space density of these charged particles. By the
Liouville theorem,f is constant along the trajectories in phase-space (equivalently, the volume
in phase-space is preserved by a Hamiltonian ﬂow). Then, we can rewrite the time derivative
off more explicitly:
0 = dfdτ = dxμdτ ∂f∂xμ + dpμdτ ∂f∂pμ = pμ ∂f∂xμ +eFμνpν ∂f∂pμ
= pμ
( ∂
∂xμ −eFμν ∂∂pν)f.
This type of kinetic equation is known as a Vlasov equation. The ﬁrst term, p·∂xf, describes
the free streaming of particles, i.e., the motion at constant momentum of free particles. The


===== PDF PAGE 177 =====
73 PHOTON HARD THERMAL LOOP FROM CLASSICAL PARTICLES 299
second term describes the deﬂection of their trajectories due to the force the particles feel from
the external ﬁeld in which they propagate.
73.c The Vlasov equation can be solved iteratively by writing
f = f0 +f1 +··· ,
where f0 is some distribution of free particles (it must obey p · ∂xf0 = 0), f1 is the ﬁrst
correction due to the external ﬁeld, etc. In the ﬁrst iteration, we have
p·∂xf1 = epμFμν ∂f0∂pν.
Indeed, iff1 is the correction of ﬁrst order in the external ﬁeld, we do not need to keep it on the
right-hand side, so that the left- and right-hand sides have the same order ine. This equation
can be solved formally to give
f1 = epμ
1
p·∂x
Fμν ∂f0
∂pν.
73.d The next step is to deﬁne the electromagnetic current associated with the distribution f:
Jμ(x) ≡ e
∫ d3p
(2π)3
pμ
p f(x,p ).
One may check that this current is conserved iff obeys the Vlasov equation:
∂μJμ = e
∫ d3p
(2π)3p (p·∂)f = e2
∫ d3p
(2π)3ppμFμν ∂f∂pν =− e2
∫ d3p
(2π)3p
∂pμ
∂pν
/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
gμν
Fμν
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 0
f = 0.
With the iterative solution obtained above, the current reads
Jμ = e
∫ d3p
(2π)3p pμ
(
f0 +epρ
1
p·∂x
Fρν ∂f0
∂pν +···
)
.
If we assume that the free distributionf0 does not produce any current, the ﬁrst term is zero
(physically, this is realized when the free distributionf0 has equal distributions of electrons
and positrons). Therefore, at order one in the external ﬁeld, the current reads
Jμ = e2
∫ d3p
(2π)3p
pμpρ
p·∂x
Fρν ∂f0
∂pν =− e2
∫ d3p
(2π)3p
∂
∂pν
(pμpρ
p·∂x
)
Fρν f0
=− e2
∫ d3p
(2π)3p
(δνμpρ
p·∂x
+ pμgνρ
p·∂x/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
→0
− pμpρ∂ν
(p·∂x)2
)
Fρν f0.
Note that the middle term gives zero after contraction with the antisymmetric tensor Fρν.N o w ,
we would like to determine an effective LagrangianLeff such that
Jμ = ∂Leff
∂Aμ
.
SinceJμ is linear in the external ﬁeld, this effective Lagrangian must have one more power of
A. Moreover, in order to be gauge invariant, this additionalA dependence should arise via a


===== PDF PAGE 178 =====
300 5 LATTICE, FINITE T , STRONG FIELDS
power of the ﬁeld strength. In order to ﬁnd this Lagrangian, recall ﬁrst that
∂Fαβ
∂Aμ
= ∂(∂αAβ −∂βAα)∂Aμ = δβμ ∂α −δαμ ∂β.
Then, consider
∂
∂Aμ
(
Fνβ
pβpρ
(p·∂)2Fρν
)
=( δβμ∂ν −δνμ∂β) pβpρ(p·∂)2Fρν +Fνβ pβpρ(p·∂)2 (gμν∂ρ −gρμ∂ν)
= pμpρ
(p·∂)2
(
∂νFρν +Fρν∂ν) −2 pρp·∂Fρμ
=− pμpρ
(p·∂)2
(
∂νFρν/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
0
)
−2
(δνμpρ
p·∂ − pμpρ∂ν(p·∂)2)Fρν.
(Note that the derivatives act on everything located to their right, including the zeroth-order
phase-space distribution f0, not yet included in this formula. To obtain the ﬁnal line, we
usedFρν∂ν ··· = ∂νFρν ··· −(∂νFρν)··· . Finally, we have∂νFρν = 0 because the charged
particles are not feeding the external ﬁeld in this approximation (and we assume that the
sources producing this ﬁeld are far away). Up to a factor2, we recognize the structure of the
integrand in the currentJμ. Therefore, the effective Lagrangian whose derivative givesJμ reads
Leff = e22 ∫ d3p(2π)3p Fνβ pβpρ(p·∂)2Fρν f0.
73.e Let us now consider
Πμν =− ∂Jμ
∂Aν
= e2
∫ d3p
(2π)3p
(
gμν − pμ∂ν +pν∂μ
p·∂ + pμpν∂2(p·∂)2) f0.
To recover the HTL result, we replacef0 by the equilibrium fermion distribution,
f0(x,p )= 2×2× 1eβ|p0| +1
(the two prefactors2 account for electrons and anti-electrons, and for the fact they have two
spin states), and we Fourier transform the external coordinates (which simply amounts to the
replacement∂ → ik), so that
Πμν(k)= 4e2
∫ d3p
(2π)3p
(
gμν − pμkν +pνkμ
p·k + pμpνk2(p·k)2) 1eβp +1
(p0 = p in this equation). Note that the factor between the parentheses is homogeneous
of degree zero in p, and therefore depends only on the orientation ˆp of p. By writing


===== PDF PAGE 179 =====
74 GLUON HARD THERMAL LOOP FROM COLORED CLASSICAL PARTICLES 301
d3p = p2dpd2ˆp, we can easily factorize the radial and angular integrals:
Πμν(k)= 2e2
∫ +∞
0
dp p
π2
1
eβp +1 ×
∫ d2ˆp
4π
(
gμν − ˆPμkν +ˆPνkμ
ˆP·k +
ˆPμˆPνk2
(ˆP·k)2
)
,
whereˆP ≡ (1,ˆp). The radial integral reads
2e2
∫ +∞
0
dp p
π2
1
eβp +1 = 2e2T2π2 ∫ +∞0 dx x(e−x −e−2x +e−3x −e−4x +··· )
= 2e2T2
π2
( 1
12 − 122 + 132 −··· ) = 2e2T2π2 ζ(2)2 = e2T26 .
In order to compare with the known results for the photon hard thermal loop, it is enough to
check the component Π00 and the trace Πμμ. The angular integration reduces to three basic
integrals,
∫ d2ˆp
4π = 1,
∫ d2ˆp
4π
1
ˆP·k = 12k ln⏐⏐⏐k0 +kk0 −k⏐⏐⏐,∫ d2ˆp
4π
1
(ˆP·k)2
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
− ∂∂k0 1ˆP·k
= 1
(k0)2 −k2,
and we obtain
Πμμ(k)= e2T26 ∫ d2ˆp4π (4 −2ˆP·kˆP·k +
0/bracehtipdownleft/bracehtipupright/bracehtipupleft/bracehtipdownright
ˆP2 k2
(ˆP·k)2
)
= e2T2
3 ,
Π00(k)= e2T2
6
∫ d2ˆp
4π
(
1 −2 k0
ˆP·k + k2(ˆP·k)2) = e2T23 (1 − k02k ln⏐⏐⏐k0 +kk0 −k⏐⏐⏐).
These results provide the two independent terms that enter into the photon hard thermal loop.
Although the gain provided by this approach to calculating the HTL contribution to the photon
polarization tensor is marginal, it becomes appreciable when applied to the case of QCD, and
does not require much more effort (as opposed to an approach in terms of Feynman diagrams).
Moreover, the present discussion highlights the fact that, in the HTL approximation, the particle
running in the loop is in fact classical.
74. Gluon Hard Thermal Loop from Colored Classical Particles This problem is a
continuation of Problem 73. Extend the method of that problem (with the help of the results
of Problem 37) in order to compute the gluon polarization tensor in the hard thermal loop


===== PDF PAGE 180 =====
302 5 LATTICE, FINITE T , STRONG FIELDS
approximation. Hint: note that the current must now be deﬁned by
Jμ ≡
∫ d3p
(2π)3
∫
dQ Qpμ
p f(x,p,Q ),
whereQ is the “non-Abelian classical charge” introduced in Problem 37, and show that the
phase-space distribution obeys the following Vlasov equation:
pμ
( ∂
∂xμ −QaFaμν ∂∂pν +ig(Aadjμ )abQb ∂∂Qa)f = 0.
Since the method is the same as in Problem 73, our derivation will just go through the
main steps and will skip some details. The starting point is the equation of motion for classical
colored particles:
pμ = dxμ
dτ , dpμdτ = Qa Fμνa pν.
The classical chargesQa obey the Wong equations:
dQa
dτ = igpμ(Aadjμ )abQb.
An important difference compared to QED is that, since the charge Q is not constant, the
phase-space distribution may depend on Q as if it were a standard coordinate, f(x,p,Q ).
Again, the Liouville theorem implies that the distribution is constant along phase-space
trajectories, which can be rewritten as
0 = dfdτ =(dxμdτ ∂∂xμ + dpμdτ ∂∂pμ + dQadτ ∂∂Qa)f
= pμ
( ∂
∂xμ −QaFaμν ∂∂pν +ig(Aadjμ )abQb ∂∂Qa)f.
Compared to the QED case, the Vlasov equation contains an additional term because the
classical color charge is not constant in an external ﬁeld.
Then, we expand f ≡ f0 + f1 + ··· , assuming that f0 obeys the free Vlasov equation,
(p·∂)f0 = 0. The solution at order one in the external ﬁeld is then given by
f1 = pμp·∂(QaFaμν ∂∂pν −ig(Aadjμ )abQb ∂∂Qa)f0.
Anticipating the fact that at a later stage f0 will be replaced by an equilibrium distribution, we
can assume thatf0 does not depend onQa and therefore drop the last term, to obtain
f1 = pμp·∂ Qa[Faμν]abel. ∂∂pν f0.
Note that, to be consistent with the expansion in powers of the external ﬁeld, we must keep
only the Abelian part of the ﬁeld strength, since the commutator is of higher order in the gauge


===== PDF PAGE 181 =====
74 GLUON HARD THERMAL LOOP FROM COLORED CLASSICAL PARTICLES 303
ﬁeld. From f1, we get the following current:
Jμb =
∫ d3pdQ
(2π)3p Qb pμpρp·∂ Qa[Faρν]abel. ∂∂pν f0
=−
∫ d3pdQ
(2π)3p Qb ∂∂pν(pμpρp·∂) Qa[Faρν]abel. f0
=
∫ d3pdQ
(2π)3p Qb
(pμpρ∂ν
(p·∂)2 − gνμpρp·∂ ) Qa[Faρν]abel. f0.
At this point, we need only one property of the integration over the color chargeQ, namely
that the integration of QaQb is diagonal in color, and proportional to the trace of a pair of
generators in the representation of the particles under consideration,
∫
dQ QaQb = g2 Nr δab (Nf = 12,Nadj = N),
which gives
Jμa = g2
∫ d3p
(2π)3p
(pμpρ∂ν
(p·∂)2 − gνμpρp·∂ )[Faρν]abel. ∑r Nrf0r, (5.21)
where we have included a sum over the representations, in order to include both gluons and
quarks (we denote byf0r the corresponding equilibrium distributions).
Then, the gluon polarization tensor reads
Πμa,νb =− ∂Jμa
∂Abν = g2
∫ d3p
(2π)3p
(gμσpρ
p·∂ − pμpρ∂σ(p·∂)2) ∂[Faρσ]abel.∂Abν ∑r Nrf0r.
Therefore, we have
Πμa,νb(k)= g2δab
∫ d3p
(2π)3p
(gμσpρ
p·k − pμpρkσ(p·k)2) (δσνkρ −δρνkσ) ∑r Nrf0r
= g2δab
∫ d3p
(2π)3p
(
gμν − pμkν +pνkμ
p·k + pμpνk2(p·k)2) ∑r Nrf0r.
The structure of this integral is very similar to the Abelian case, the only modiﬁcation being
the phase-space distribution. WithNf ﬂavors of quarks in the fundamental representation and
with gluons, we have
∑
r
Nrf0r = 2Neβ|p0| −1 + 2Nfeβ|p0| +1.
(For gluons, there are two polarization states andNadj = N. For quarks, there is a factor 2Nf
due toNf ﬂavors of quarks and antiquarks, a factor2 for their two spin states, and Nf = 12 .)


===== PDF PAGE 182 =====
304 5 LATTICE, FINITE T , STRONG FIELDS
After factorizing the radial and angular integrals, we obtain
Πμa,νb(k)= 2g2δab
∫ +∞
0
dp p
π2
( Nf/2
eβp +1 + N/2eβp −1)
×
∫ d2ˆp
4π
(
gμν − ˆPμkν +ˆPνkμ
ˆP·k +
ˆPμˆPνk2
(ˆP·k)2
)
.
The angular integral is the same as in the Abelian case. In the radial integral, the term with the
Fermi–Dirac distribution is also the same, except for the changee2 → g2δabNf2 ,
g2δabNf
∫ +∞
0
dp p
π2
1
eβp +1 = g2T2Nf12 δab,
and we just need to calculate the second term in the radial integral:
g2δabN
∫ +∞
0
dp p
π2
1
eβp −1 = g2T2Nπ2 δab ∫ +∞0 dx x 1ex −1
= g2T2Nπ2 δab ∫ +∞0 dx x(e−x +e−2x +e−3x +··· )/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
1
12 + 122 + 133 +···=ζ(2)=π26
= g2T2N6 δab.
Therefore, the HTL gluon polarization tensor is identical to that of the photon, with only the
following change of prefactor:
e2T2
6 → g2T26 (N + Nf2 )δab.
In the non-Abelian case, the present approach based on classical transport has a very clear
advantage over the calculation of Feynman graphs (there are four of them). Moreover, from
the current in Eq. (5.21), we can guess an effective Lagrangian whose derivative with respect
to the ﬁeld gives the current:
Leff = g22 ∫ d3p(2π)3p [Faνβ]abel. pβpρ(p·∂)2[Fρνa ]abel. ∑r Nrf0r.
This effective Lagrangian is sufﬁcient to recover the polarization tensor by taking two deriva-
tives. But we can get a lot more out of it by noticing that it is not gauge invariant, but can be
promoted into a gauge invariant one by very simple substitutions:
[
Faνβ]abel. → Faνβ,p ·∂ → p·D,
which leads to
Leff = g22 ∫ d3p(2π)3p Faνβ[ pβpρ(p·D)2]ab Fρνb ∑r Nrf0r.
Note that this effective Lagrangian now contains terms of arbitrarily high order in the gauge
ﬁeld. In fact, by differentiating itn times with respect to the ﬁeld, it provides then-gluon HTL


===== PDF PAGE 183 =====
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 305
vertex. The main reason why it is possible to capture the HTL results in such a simple setting
is that when the momentum circulating in the loop is much larger than the external momenta,
then all the couplings of the external lines to the loop become eikonal, and therefore universal
(in particular, independent of the spin). In this approximation, the only thing that distinguishes
the various ﬁelds that can circulate in the loop is their phase-space distribution, their color
representation and the corresponding number of degrees of freedom, while all the kinematical
dependence is universal.
Sources: Kelly, P. F., Liu, Q., Lucchesi, C. and Manuel, C. (1994),Phys Rev Lett 72: 3461;
Pisarski, R. D. (1998), Kinetic theory of hot gauge theories: Overview, details & extensions, in
S´anchez, N. and Zichichi, A. (eds.), Current Topics in Astrofundamental Physics: Primordial
Cosmology, NATO ASI Series, vol. 511 (Springer), p. 195.
75. Landau–Pomeranchuk–Migdal Effect The goal of this problem is to study the
emission of soft photons by a hot plasma of electrons and anti-electrons, and in particular
to discuss the Landau–Pomeranchuk–Migdal effect, an interference effect that reduces the
emission of soft photons in a hot medium.
75.a Recall the relationship between the photon emission rate and the imaginary part of the
retarded photon self-energy.
75.b Explain why this self-energy can be obtained as
−iΠijR (x,y )=− δJiind(x)δAj(y),
where Jiind is the electromagnetic current induced by the application of an external
potentialAj. Write this current in terms of the deviations from equilibriumδfe,δf ¯e of
the electron and anti-electron distributions.
75.c Show thatδfe obeys the following Boltzmann–Vlasov equation:
(v·∂x)δfe − eT (v·E)nF (p)(1 −nF (p)) = δCe,p[δf],
whereδCe,p is a collision term andnF is the Fermi–Dirac distribution.
75.d By explicitly writing the collision term with two-body collisions, show that
δCe,p =− e3nF (p)(1−nF (p))
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥+m2D )
[
F(x,p)− F(x,p −𝓁⊥)
]
,
wheremD is the photon Debye mass andδfe ≡ eT nF (1 −nF )F.
75.e Apply a Fourier transform to thex dependence, and discuss qualitatively the effect of
the integral on𝓁⊥ in the collision term.
75.f Extra: in the regime where m ≫ mD , transform the Boltzmann–Vlasov equation into a
diffusion equation that one may solve analytically.


===== PDF PAGE 184 =====
306 5 LATTICE, FINITE T , STRONG FIELDS
75.a We consider a hot plasma of electrically charged electrons and anti-electrons of massm
(this could be their in-vacuum mass or, at very high temperature, the mass they acquire in the
plasma due to their interactions with their environment), interacting via photon exchanges (this
point is not crucial and one could easily generalize this discussion to interactions via gluon
exchanges). The photon emission rate from a sample of this plasma can be obtained from the
in-medium photon self-energy, as follows:
2k0(2π)3 dNγd4xd3k = ∑pol. λϵ(λ)μ (k)ϵ(λ)ν (k)2 Im( −iΠμνR (K))eβk0 −1 .
There are various variants of this formula, differing in which form of the self-energy is used.
Here, we choose the formula that involves the retarded self-energy, because we will want later
to obtain it from linear response theory. To be deﬁnite, let us choose the photon momentumk
to be aligned with thex3 direction. For on-shell photons, the sum over the polarizations simply
produces a projector on the planex1,x2 transverse to the photon momentum:
∑
pol. λ
ϵ(λ)μ (k)ϵ(λ)ν (k)Πμν(K)= ∑
i=1,2
Πii(K).
75.b The retarded photon self-energy can be viewed as a retarded correlation function
between a pair of electromagnetic currents (this is correct in linear gauges, where there is no
spurious triple or quartic photon coupling). Then, by the same reasoning as for the derivation
of Kubo’s formula (see, for instance, Mahan, G. D. (2000), Many-Particle Physics (Kluwer
Academic)), the retarded current–current correlator can be obtained by looking at the induced
current (the response) that appears in the system when we apply an external ﬁeld Aj (the
source):
−iΠijR (x,y )=− δJiind(x)δAj(y), with Jiind ≡ e⟨ψγiψ⟩.
Since we want the photon self-energy in equilibrium, we need only consider arbitrarily small
external ﬁelds (in other words, we calculate the induced current only at linear order in the
applied external ﬁeld).
In thermal equilibrium, there are no net currents in the system (since the fermions and
anti-fermions have opposite charges and the same momentum distribution). The induced
current can be obtained as
Jiind(x)= 2e
∫ d3p
(2π)3 vi(δfe(x,p)− δf¯e(x,p)),
where vi ≡ pi/Ep andδfe (resp. δf¯e) is the deviation from Fermi–Dirac of the electron (resp.
anti-electron) distribution induced by the external ﬁeld (think of an electric ﬁeld, which pulls
electrons and anti-electrons in opposite directions). The prefactor 2 is due to the two spin
states of an electron.
75.c The external ﬁeld acts on the fermions of the system via the Lorentz force. The other
effect that affects the fermion distribution is their collisions, which are responsible for the


===== PDF PAGE 185 =====
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 307
relaxation to equilibrium. Therefore, the equation that controls f and ¯f is a Boltzmann–Vlasov
equation:
(v·∂x)fe
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
free streaming
+e
(
E +v×B
)
· ∇pfe
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Vlasov term
= Ce,p[fe,f ¯e]/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
collisions
,
wherevμ ≡ (1,vi). The Vlasov term, proportional to the Lorentz force, is responsible for the
change of the momenta of the particles as they move in the external ﬁeld. The anti-electron
distribution obeys the same equation with the changee → −e to account for the fact that they
feel the opposite Lorentz force. In this problem, we need only consider small deviations of the
distribution about the equilibrium Fermi–Dirac distribution, fe ≡ nF +δfe, f¯e ≡ nF +δf¯e,
and we can linearize the above Boltzmann–Vlasov equation in δfe,δf ¯e. Recalling that the
deviationsδfe,δf ¯e are of the same order as the external electromagnetic ﬁeldE,B, and that
the collision term vanishes when evaluated with the equilibrium Fermi–Dirac distribution, we
obtain
(v·∂x)δfe +e
(
E +v×B
)
· ∇pnF/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1T nF (1−nF )v
= δCe,p[δf],
where we denote by δC the linearized collision term. Since the Fermi–Dirac distribution is
isotropic, its derivative with respect to momentum is proportional to the velocity v, imply-
ing that only the electric ﬁeld E contributes. In the following, it will prove convenient to
parameterize the deviationsδf2,δf ¯e as follows:
δfe(x,p) ≡ eT nF (p)(1 −nF (p))F(x,p),
δf¯e(x,p) ≡ −eT nF (p)(1 −nF (p))F(x,p),
where the functionF(x,p) is the same in both cases.
75.d Before linearization, the collision term with two-body collisionspq → p′q′ reads
Ce,p[f, ¯f]= ∑
α=e,¯e
∫
p′,q,q′
(2π)4δ(p +q −p′ −q′) 116EpEp′EqEq′
⏐⏐⏐Mpq→p′q′⏐⏐⏐2
×
{
(1−fe(x,p))fe(x,p′)(1−fα(x,q))fα(x,q′)
−fe(x,p)(1−fe(x,p′))fα(x,q)(1−fα(x,q′))},
where we have used the shorthand
∫
q ≡
∫ d3q
(2π)3 . Note that we sum over the two kinds of
scattering partners, electrons and anti-electrons. Next, we expand the distribution functions
about nF , keeping only terms linear in the deviations. Since δfe and δf¯e are opposite, the
deviations of the distributionfα of the scattering partner cancel when we sum over electrons
and anti-electrons. Therefore, we get
δCe,p =− 2eT ∫p′,q,q′ (2π)4δ(p +q −p′ −q′) 116EpEp′EqEq′ ⏐⏐⏐Mpq→p′q′⏐⏐⏐2
×nF (p)(1−nF (p′))nF (q)(1−nF (q′))[F(x,p)−F(x,p′)].
Note that the momentum transfer 𝓁 ≡ p −p′ = q′ −q is soft (of the order of the Debye mass,
i.e., ∼ eT) compared to the typical momentum of the electrons and anti-electrons (of the order


===== PDF PAGE 186 =====
308 5 LATTICE, FINITE T , STRONG FIELDS
of the temperatureT). This implies that the scattering amplitude is dominated by the t-channel
diagram. Consequently, there is no difference between scattering off an electron and off an
anti-electron, hence the prefactor2. Then, in order to rewrite the integrals in the collision terms
in terms of𝓁, we can use
∫ d3p′
(2π)22Ep′
d3q
(2π)22Eq
d3q′
(2π)22Eq′ (2π)4δ(p +q −p′ −q′)
≈
∫ d4𝓁
(2π)4
d3q
(2π)32Eq
1
4EpEq
(2π)2δ(𝓁0 −𝓁·v)δ(𝓁0 −𝓁·vq),
where we have neglected terms quadratic in the soft momentum 𝓁 and where we denote
vq ≡ q/Eq. We can also use the approximation
nF (p)(1−nF (p′)) ≈ nF (p)(1−nF (p)),
nF (q)(1−nF (q′) ≈ nF (q)(1−nF (q),
and note that the integrated squared matrix element (at ﬁxed transfer 𝓁) can be expressed in
terms of the hard thermal loop spectral function (i.e., the imaginary part of the HTL photon
propagator):
2
∫ d3q
(2π)3 2πδ(𝓁0 −𝓁·vq)nF (q)(1−nF (q)
⏐⏐Mpq→p′q′⏐⏐2
16E2pE2q ≈ e2 T𝓁0vμvν ρμνHTL (𝓁),
with
ρμνHTL (𝓁) ≡ ∑
α=T,L
Pμνα (𝓁) 2 ImΠα(𝓁)(𝓁2 − ReΠα(𝓁))2 +( ImΠα(𝓁))2
(vμ ≡ (1,vi), and the projectors PμνT,L were deﬁned following Eq. (5.14)). Therefore, thelinearized collision term becomes
δCe,p =− e3T nF (p)(1−nF (p))
×
∫ d4𝓁
(2π)4 2πδ(𝓁0 −𝓁·v)T𝓁0vμvν ρμνHTL (𝓁)[F(x,p)− F(x,p −𝓁)].
Here, it is important to recognize thatF(x,p) is strongly peaked whenp is aligned with the
photon momentum, i.e., with the z axis. As a consequence, the variations of F are much faster


===== PDF PAGE 187 =====
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 309
when p varies in the transverse direction than in the longitudinal direction, implying that
F(x,p)− F(x,p −𝓁) ≈ F(x,p)− F(x,p −𝓁⊥).
For the same reason, we can approximateδ(𝓁0 −𝓁·v) ≈ δ(𝓁0 −𝓁z). Using the explicit form
of the projectorsPμνT,L(𝓁),w eh a v e
vμvνPμνL (𝓁)=− vμvνPμνT (𝓁)=𝓁0=𝓁z 𝓁2⊥𝓁20 +𝓁2⊥.
It is convenient to introduce the variablex ≡ 𝓁0/|𝓁|, since the HTL photon self-energies depend
only onx. The Jacobian of this change of variable is given by
d𝓁0d2𝓁⊥
𝓁0
𝓁2⊥
𝓁20 +𝓁2⊥ = dxd2𝓁⊥x .
Therefore, the collision term reads
δCe,p =− e3nF (p)(1−nF (p))
∫ d2𝓁⊥
(2π)2
[
F(x,p)− F(x,p −𝓁⊥)
]
× 2π ∫10 dxx { ImΠL (x)(𝓁2⊥+ReΠL (x))2+(ImΠL (x))2 − ImΠT (x)(𝓁2⊥+ReΠT (x))2+(ImΠT (x))2 }/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=
m2D
𝓁2⊥(𝓁2⊥+m2D )
.
The identity used in the second line, wheremD is the Debye screening mass, is an exact sum
rule satisﬁed by the photon HTL self-energies.
75.e Combining the above results, the Boltzmann–Vlasov equation can be written as follows
in terms ofF:
(v·∂x)F(x,p)+ e2T
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
[
F(x,p)− F(x,p −𝓁⊥)
]
= v·E.
Using E ≡ −∂tA and applying a Fourier transform to turn x into the photon momentum K,
this equation leads to
δF(K,p)
δAj(K) = k0vjK·v +i e2TK·v ∫ d2𝓁⊥(2π)2 m2D𝓁2⊥(𝓁2⊥ +m2D )[δF(K,p)δAj(K) −δF(K,p−𝓁⊥)δAj(K) ] (5.22)
(recall thatv ≡ p/Ep), whose solution must be inserted into
Im
(
−iΠijR (K)) =− 4e2T ∫ d3p(2π)3 nF (p)(1 −nF (p))vi Im(δF(K,p)δAj(K) ).
The integral term in (5.22) takes into account the collisions of the emitter with the other
particles in the plasma, while the ﬁrst term on the right-hand side of this equation would give
the contribution of the processe → eγ. Note that this collisionless contribution gives a purely


===== PDF PAGE 188 =====
310 5 LATTICE, FINITE T , STRONG FIELDS
real δF/δAj and therefore does not contribute to the photon yield, as expected from trivial
kinematics.
The equation (5.22) could in principle be solved iteratively in powers ofe2, by inserting
inside the integral the solution obtained at the previous order. Assuming thatδF/δAj is of order
one as in the collisionless limit, then the integral in (5.22) is also of order one (the typical𝓁⊥ is
of the order of the Debye mass mD ). We therefore see that multiple collisions all contribute to
the same order ifv·K ≲ e2T. On the other hand, simple kinematics leads to
v·K ≈ k0
m2 +p2⊥
2p2z . (5.23)
Note that v · K can be interpreted as the inverse of the photon formation time , i.e., the
time necessary for the photon wave-packet to become separated from that of its emitter. In
more physical terms, multiple scatterings are important when the photon formation time is
comparable to or larger than the mean free path, i.e., the distance traveled by the emitter
between two successive collisions (in this process, the relevant collisions are small-angle
collisions, separated by (e2T )−1). This effect is known as the Landau–Pomeranchuk–Migdal
effect. In this regime, there is no point in solving (5.22) perturbatively as a series ine2 because
all orders are in fact comparable. From (5.23), we see thatv·K may be small when the electron
momentum is much larger than its mass,pz ≫ m, and its transverse momentump⊥ is small
(quasi-collinear emission of the photon). This is precisely what happens in a plasma at very
high temperature, where the relevant mass is a thermal mass of order m ∼ eT, the typical pz is
of orderT, and photon emission happens predominantly at small anglesθ ∼ e (i.e.,p⊥ ∼ eT).
The effect of these multiple scatterings on the photon spectrum can be estimated roughly
as follows. On the one hand, the photon formation length is 𝓁 ∼ 1/v·K. On the other hand, the
transverse momentum accumulated by the emitter over this distance isp2⊥ ∼ m2D𝓁/λ, whereλis the electron mean free path. This leads to
𝓁
λ ∼ pzmD√k0λ ≫k0→0 1.
This implies that it takes a large number (growing like 1/√k0) of collisions to produce a
single soft photon. In other words, the soft photon spectrum is reduced by a factor √k0
compared to what one would obtain by multiplying the one-collision spectrum by the number
of collisions (this is known as the Bethe–Heitler limit). This suppression is a quantum effect,
due to the destructive interference between photon emissions occurring at various points along
the trajectory of the emitting electron (the photon formation length controls how far apart two
emissions that still interfere can be); see Figure 5.4 for an illustration.
75.f This discussion can be made more quantitative analytically whenm ≫ mD (for this to
be true, the bare mass of the electron must dominate over its thermal mass). In this case, we
may write
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
[δF(K,p)
δAj(K) −δF(K,p−𝓁⊥)δAj(K) ]
≈
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
1
2
(
𝓁⊥ · ∇p
)2δF(K,p)
δAj(K) ≈ m2D8π ln( mmD )∇2pδF(K,p)δAj(K) .
Here, we have used the separation of scale between the typicalp⊥ ∼ m and the Debye mass
mD in order to make a leading logarithmic approximation of the integral over𝓁⊥ (the logarithm


===== PDF PAGE 189 =====
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 311
Figure 5.4 Left: illustration of the Landau–Pomeranchuk–Migdal effect. Right: the Feynman
graphs contributing to the photon self-energy in the LPM regime (the black dots on the
internal photons indicate the hard thermal loop re-summation).
must be large for this approximation to be justiﬁed). In this approximation, the equation (5.22)
that sums the multiple collisions of the emitter becomes a diffusion equation in the transverse
velocity space (v⊥ ≡ p⊥/p):
ik0
(
1
2
(
v2⊥ + m2p2 ) δFδAj −vj) +D∇2v⊥ δFδAj = 0,
where the diffusion constant is deﬁned as D ≡
e2Tm 2D
8πp2 ln(m/mD ). In order to solve this
diffusion equation, let us deﬁneδF/δAj ≡ vj(ϕ(s)+ 1)/s withs ≡ 12v2⊥ (note that we musthaveϕ(0)=− 1 for this to be deﬁned at v⊥ = 0). In terms of ϕ ands,w eh a v e
sϕ′′ +i(α +βs)ϕ +iα = 0, with α ≡ k0m24Dp2 ,β ≡ k02D.
This is a differential equation with polynomial coefﬁcients, which may be solved by taking a
Laplace transform,
v(λ) ≡
∫ ∞
0
dse −λsϕ(s).
First, we obtain a differential equation forv(λ):
v′ + 2λ −iαλ2 +iβ v + 1 −iαλλ2 +iβ = 0.
Since this is a ﬁrst-order equation, it can be solved analytically:
v(λ)=− 1λ21 −λ2(λ1 +λλ1 −λ)μ ∫λ1λ dξ(1 −iαξ)(λ1 −ξλ1 +ξ)μ,
withλ1 ≡ √βe−iπ/4 andμ ≡ (α/2√β)e−iπ/4. In terms of this function, we have


===== PDF PAGE 190 =====
312 5 LATTICE, FINITE T , STRONG FIELDS
∑
i=1,2
Im
(
−iΠiiR (K)) =− 23e2T2 Imv(λ = 0)
= 23 e2T2β Re limλ→0
∫λ1
λ
dξ
(
1 −iαξ)(λ1 −ξλ1 +ξ)μ
= 23 e2T2β Re limλ→0
{
λ1
∫1
0
dx
(1−x
1+x
)μ
−iα
∫1
0
dx
x
[(1−x
1+x
)μ
−1
]
−iα ln
(λ1
λ
)}
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
∼√β whenk0 → 0
∝
k0→0
√
k0.
In the penultimate line, we have directly setλ = 0 in the terms that are regular in this limit, and
isolated a term that has a logarithmic singularity. But note that the singularity only contributes
to the imaginary part, so that the real part has a ﬁnite limit (λ should approach zero along the
positive real axis in order to obtain the correct result). When we combine this result with the
soft limit of the Bose–Einstein factor that multiplies Im (−iΠiiR (K)) in the photon emission
spectrum, we obtain a spectrum in 1/√k0, instead of 1/k0 for bremsstrahlung induced by
a single scattering. Thus, the effect of multiple scatterings is to reduce the emission of soft
photons by a factor√k0, as we had anticipated from our earlier qualitative discussion.
Let us ﬁnish with a general remark about the approach employed here to derive this effect.
Naively, it may seem paradoxical to be able to derive a quantum interference effect by means
of kinetic theory, which assumes that electrons behave completely classically. But in the LPM
effect, the only object whose coherence matters is the photon wavefunction, while the electron
can be totally classical.
Sources: Baym, G., Blaizot, J.-P., Gelis, F. and Matsui, T. (2007),Phys Lett B 644: 48; Migdal,
A. B. (1956), Phys Rev 103: 1811.
76. Microcanonical Equilibration in φ4 Scalar Theory Consider a massless scalar ﬁeld
theory withφ4 interaction in four spacetime dimensions. The goal of this problem is to study
some aspects of classical dynamics in this ﬁeld theory, in relation to thermal equilibration.
76.a What is the canonical energy–momentum tensor in this theory? What is its trace?
76.b What is the equation of state relating pressure to energy density for a scale invariant
system in statistical equilibrium?
76.c Consider a spatially homogeneous classical ﬁeld in this theory. Show that this ﬁeld is a
periodic function of time, and ﬁnd the relationship between the period and the amplitude
of the ﬁeld oscillations. Show that the trace of the energy–momentum tensor is non-zero
for this ﬁeld, but vanishes when averaged over one period.
76.d Consider now a statistical ensemble of such homogeneous classical ﬁelds, obtained by
choosing an ensemble of initial conditions and letting the ﬁelds evolve according to
the classical equation of motion. How does the expectation value of the trace of the
energy–momentum tensor evolve with time?


exit_code=0
```

### 2026-11-16T21:57:54.791078+08:00

```bash
cat tasks/qft-04/instruction.md tasks/qft-04/solution/README.md tasks/qft-04/solution/solve.py tasks/qft-04/environment/public/physics.py tasks/qft-04/environment/public/metric.json tasks/qft-04/tests/quality_score.py
```

```text

### 2026-11-16T21:57:54.791246+08:00

```bash
find tasks/qft-04 -maxdepth 4 -type f
```

```text
# QFT-04：康普顿散射的双图干涉与运动探测接受度

## 物理问题与约定

用户提供的《量子场论试题详解》PDF 第 83--85 页（书内 75--77 页）给出康普顿散射的两个树图及 QED 动量空间 Feynman 规则。请把这两个图相干相加，建立精确的电子反冲计算，再求运动电子实验中探测器角窗、能窗筛选后的光子能谱。只使用 Thomson 低能近似，或将两图的概率不相干相加，均不足以覆盖本题。

取 \(m_e=\hbar=c=1\)、\(g_{\mu\nu}=\operatorname{diag}(1,-1,-1,-1)\)，\(r_e^2=\alpha^2/m_e^2\)。所有截面均输出 \(\sigma/r_e^2\)，能量以电子质量为单位，角度为弧度。输入 `x` 是**初始电子静止系**的入射光子能量。该系中

\[
p=(1,0,0,0),\quad k=(x,0,0,x),\quad
k'=(r,r\sqrt{1-c^2},0,rc),\quad c=\cos\theta,
\quad p'=p+k-k',
\]

其中 \(r\) 由末态电子在壳条件 \(p'^2=1\) 确定。输入 `beta_fraction=[a,b]` 精确表示 \(\beta=a/b\)：从初始电子静止系到实验室系沿 \(+z\) 做速度 \(\beta\) 的 Lorentz boost，\(E_{\rm lab}=\gamma(E+\beta p_z)\)。因此负的 \(\beta\) 对应逆向运动电子。

采用实线偏振基

\[
\epsilon_1=(0,1,0,0),\quad\epsilon_2=(0,0,1,0),\qquad
\epsilon'_1=(0,c,0,-\sqrt{1-c^2}),\quad\epsilon'_2=(0,0,1,0).
\]

旋量归一化为 \(\bar u_s(p)u_s(p)=2\)，对初态电子自旋及入射光子偏振平均，对末态求和。省略对概率无影响的共同相位，定义两个无量纲振幅 \(a_s=\mathcal M_s/e^2\)、\(a_u=\mathcal M_u/e^2\)：

\[
a_s=\bar u(p')\slashed\epsilon'^{*}
\frac{\slashed p+\slashed k+1}{2p\cdot k}
\slashed\epsilon\,u(p),\qquad
a_u=\bar u(p')\slashed\epsilon
\frac{\slashed p-\slashed k'+1}{-2p\cdot k'}
\slashed\epsilon'^{*}u(p).
\]

\(\slashed v=\gamma^0v^0-\sum_{i=1}^3\gamma^iv^i\)。定义 \(S=\overline{|a_s|^2}\)、\(U=\overline{|a_u|^2}\)、\(I=2\operatorname{Re}\overline{a_sa_u^*}\) 及 \(T=S+U+I\)。它们均包含上述初态平均。单图贡献按固定偏振约定比较，不能将单图当作独立的规范不变可观测量。精确微分截面为

\[
\frac1{r_e^2}\frac{d\sigma}{d\Omega}
=\frac14\left(\frac r x\right)^2T.
\]

## 需要完成的工作

1. 对 `model.json` 中的每个 `probes` 项，计算 `s_squared=S`、`u_squared=U`、`interference=I`、`total=T`。再同时把每个入射偏振变为 \(\epsilon_i+\eta k/x\)，每个出射偏振变为 \(\epsilon'_j+\zeta k'/r\)，其中 \(\eta,\zeta\) 来自公开输入，计算总振幅平方 `gauge_shifted_total`。总结果应满足 Ward 一致性，单图一般会变化。
2. 对每个 `cases` 项，积分求完整静止系总截面 `sigma`。`lab_theta_window=[theta_min,theta_max]`、`lab_energy_window=[E_min,E_max]` 同时作用于 **boost 后的出射光子**；边界均包含在接受区内。求满足两个窗口的静止系 \(c\) 区间 `accepted_cos_interval=[c_min,c_max]`，无正测度接受区时填 `null`。
3. 在接受区内求截面 `accepted_sigma`、`acceptance=accepted_sigma/sigma`、条件实验室系光子能量均值 `mean_energy`，以及条件能谱的 10%、50%、90% 分位数 `energy_quantiles=[E10,E50,E90]`，按**能量升序**给出。分位数定义为下分位数 \(\inf\{E:F(E)\ge p\}\)；若能量在整个接受区恒定，三个分位数均等于该常量。空接受区时 `accepted_sigma=0`、`acceptance=0`，均值、分位数和区间均为 `null`；`sigma` 仍为全角域总截面。

这里 `accepted_sigma` 是电子静止系散射截面对**实验室探测窗口所选事件**的积分；不额外乘实验室束流的相对流因子。任务中电子静止系的方位角全接受，故对方位角积分为 \(2\pi\)。输入刻意包含低能、高能前向峰、逆向 boost、能量随 \(c\) 反向排序、恒能量以及无事件工况，须以精确运动学处理。

## 材料、产物和开发反馈

公开 `/app/data/model.json` 提供全部输入及评分权重，`physics.py` 提供实验室系运动学与格式检查接口。Python、NumPy、SciPy、mpmath 已固定版本安装；无需网络或 GPU。

在 `/app/output/answer.json` 写 UTF-8 JSON：

```json
{
  "cases":[{"id":"kn-01","sigma":1.0,"accepted_sigma":0.5,"acceptance":0.5,"accepted_cos_interval":[-0.5,0.5],"mean_energy":0.4,"energy_quantiles":[0.3,0.4,0.5]}],
  "probes":[{"id":"amp-01","s_squared":1.0,"u_squared":1.0,"interference":-0.5,"total":1.5,"gauge_shifted_total":1.5}],
  "method":"brief method description"
}
```

示例数字仅演示 schema；两数组分别恰好覆盖全部公开 ID 一次，顺序不限。除规定可为 `null` 的字段外，所有数值均须为有限实数，不能用布尔值、NaN 或 Infinity。截面不能为负，`sigma>0`，接受率位于 \([0,1]\)，非空接受区满足 \(-1\le c_{min}<c_{max}\le1\)。

`python3 /app/data/feedback.py /app/output/answer.json` 检查格式并显示接受率归一化残差，不能代替最终物理验证。评分器使用隔离的 70 位独立真值：截面部分由解析 Klein--Nishina 原函数和独立积分互查，探针由显式旋量逐态求和得到，与参考解的 Dirac 矩阵迹路线分开。

## 评分

对于非空条件量，标量误差为 \(\min(1,|y-\hat y|/\max(10^{-6},|\hat y|))\)。三个能量分位数取此误差平均；区间端点误差为 \(\tfrac12\sum_{j=1}^2\min(1,|c_j-\hat c_j|/2)\)。两个字段都为 `null` 时该部分误差 0，仅一个为 `null` 时误差 1。每个事件工况中，总截面、接受截面、接受率、条件均值、分位数、接受区误差的权重分别是 15%、25%、10%、15%、20%、15%。

每个振幅探针的五个字段分别计算 \(\min(1,|y-\hat y|/\max(1,|\hat y|))\) 并平均。事件工况误差平均占 80%，振幅探针误差平均占 20%；原始指标为其 100 倍，单位百分点，越低越好。`metric.json` 公开实测简单基线、参考端点与 \(10^{-6}\) 百分点容差，课程原版统一函数将原始指标换成质量分。

Agent 为 4 CPU、4 GiB、0 GPU，限时 1200 秒；verifier 120 秒、独立环境、无网络。只需提交上述 JSON，其他文件不参与评分。
# QFT-04 物理推导与计算方法

## 两图、反冲与规范不变性

教材 PDF 第 83--85 页的 QED 树图有 \(s\) 和 \(u\) 两种电子传播次序，不能把各图概率不相干相加。参考解按题面度规构造 Dirac 表象四个 gamma 矩阵，以

\[
\overline{|a|^2}=\frac14\sum_{\lambda,\lambda'}
\operatorname{tr}[(\slashed p'+1)A(\slashed p+1)\gamma^0A^\dagger\gamma^0]
\]

得到各单图与干涉项；只对两个初始电子自旋及两个入射光子偏振平均，最终态求和。出射电子在壳给出
\[
r=\frac{x}{1+x(1-c)},\qquad
T=2\left[\frac r x+\frac x r-(1-c^2)\right],
\]
从而再现 Klein--Nishina 分布
\[
\frac1{r_e^2}\frac{d\sigma}{dc}
=\pi\left(\frac r x\right)^2
\left[\frac r x+\frac x r-(1-c^2)\right].
\]
参考积分实际调用矩阵迹，不读独立真值或套用其解析截面原函数。全振幅在 \(\epsilon\to\epsilon+\eta k/x\)、\(\epsilon'\to\epsilon'+\zeta k'/r\) 下不变；单图平方及干涉项各自依赖规范选择。

## 实验室窗口与退化能谱

对出射光子沿 z 轴 boost，
\[
\cos\theta_{lab}=\frac{c+\beta}{1+\beta c},\qquad
E_{lab}(c)=\frac{\gamma x(1+\beta c)}{1+x(1-c)}.
\]
角度变换在 \(-1<c<1\) 单调；能量导数符号由 \(D=x+\beta(1+x)\) 决定。当 \(D=0\) 时整个角区间对应同一能量，不能用可逆变量替换或对能量根盲目求解。`kn-05`/`kn-06` 正是 \(x=5/4,\beta=-5/9\)，分别接受或拒绝这个恒定能量；`kn-07` 有 \(D<0\)，能量分位数需要反向累计角度概率。

参考解先反演角窗得到 \(c\) 区间，再用连续单调能量及 Brent 求根裁剪能窗。对 \(D\simeq0\) 独立处理常量；非空区间使用自适应积分计算截面与能量矩。求能量 p 分位点时，若能量递减，则求角度累计概率 \(1-p\) 的根。空区间明确输出 `null` 条件统计。

## 基线、独立真值

朴素基线是具有明确低能物理适用范围的 Thomson 近似：\(r=x\)、\(d\sigma/dc=\pi(1+c^2)\)，仍按其近似能量作正确 boost 和接受区筛选。其振幅诊断采用单图概率相加，因此保留单图但漏掉图间干涉与规范抵消。基线能生成格式合法的答案，不靠输出错误制造分差。

`tools/build_qft04_truth.py` 不导入参考解。它用 70 位精度下 \(t=1+x(1-c)\) 的解析原函数生成截面，以 mpmath 直接积分核对；接受区用代数方程求交，能谱用高精度二分；振幅探针用显式正能 Dirac 自旋子逐态求和，不用参考解的自旋迹。全部结果再用 45 位复算比较，证据写入 `checks/qft-04-truth-validation.json`。
import argparse
import json
from pathlib import Path
from solver_core import solve_case,probe

def main(baseline=False):
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',type=Path,default=Path('/app/data'));parser.add_argument('--output',type=Path,default=Path('/app/output/answer.json'));args=parser.parse_args()
    model=json.loads((args.data_root/'model.json').read_text())
    answer={'cases':[solve_case(case,baseline) for case in model['cases']],'probes':[probe(item,baseline) for item in model['probes']],'method':'Thomson and incoherent graph baseline' if baseline else 'Dirac trace, coherent graphs, exact recoil and boosted detector cuts'}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,indent=2)+'\n')
    print(json.dumps(answer))

if __name__=='__main__':main()
"""Public kinematics and strict submission schema, not a reference solution."""
import json
import math
from pathlib import Path


def load_model(root='/app/data'):
    return json.loads((Path(root)/'model.json').read_text())


def boost(case):
    beta=case['beta_fraction'][0]/case['beta_fraction'][1]
    return beta,1/math.sqrt(1-beta*beta)


def lab_observables(case,c):
    beta,gamma=boost(case)
    r=case['x']/(1+case['x']*(1-c))
    return (c+beta)/(1+beta*c),gamma*r*(1+beta*c)


def finite(value):
    if type(value) not in (int,float):return False
    try:return math.isfinite(value)
    except OverflowError:return False


def validate_answer(answer,model):
    if not isinstance(answer,dict):return None,'答案须为 JSON 对象'
    parsed={}
    for section in ('cases','probes'):
        values=answer.get(section);expected={item['id']:item for item in model[section]}
        if not isinstance(values,list) or len(values)!=len(expected):return None,section+'须恰好覆盖全部工况'
        mapping={}
        for item in values:
            if not isinstance(item,dict) or type(item.get('id')) is not str:return None,'工况缺少字符串 id'
            key=item['id']
            if key not in expected or key in mapping:return None,'未知或重复 id'
            if section=='probes':
                if not all(finite(item.get(name)) for name in ('s_squared','u_squared','interference','total','gauge_shifted_total')):return None,'振幅探针字段须为有限实数'
                if any(item[name]<0 for name in ('s_squared','u_squared','total','gauge_shifted_total')):return None,'振幅平方不能为负'
            else:
                required=('sigma','accepted_sigma','acceptance','accepted_cos_interval','mean_energy','energy_quantiles')
                if any(name not in item for name in required):return None,'事件工况须显式包含全部字段，包括 null 条件统计'
                if not all(finite(item.get(name)) for name in ('sigma','accepted_sigma','acceptance')):return None,'截面与接受率须为有限实数'
                if item['sigma']<=0 or item['accepted_sigma']<0 or not 0<=item['acceptance']<=1:return None,'截面或接受率越过物理范围'
                interval=item.get('accepted_cos_interval')
                if interval is None:
                    if item.get('mean_energy') is not None or item.get('energy_quantiles') is not None or item['accepted_sigma']!=0 or item['acceptance']!=0:return None,'空接受区的条件统计须为 null，截面和接受率须为0'
                else:
                    if not isinstance(interval,list) or len(interval)!=2 or not all(finite(x) for x in interval) or not -1<=interval[0]<interval[1]<=1:return None,'接受区须为非零长度的合法 cos 区间或 null'
                    q=item.get('energy_quantiles')
                    if not finite(item.get('mean_energy')) or item['mean_energy']<=0:return None,'条件均值须为正有限实数'
                    if not isinstance(q,list) or len(q)!=3 or not all(finite(x) and x>0 for x in q) or not q[0]<=q[1]<=q[2]:return None,'能量分位数须为正有限有序数组'
            mapping[key]=item
        parsed[section]=mapping
    return parsed,None
{
  "kind": "continuous",
  "metric_name": "康普顿相干振幅与实验室接受能谱误差",
  "unit": "百分点",
  "direction": "minimize",
  "baseline": 55.40229668995407,
  "reference": 5.46829428869829e-13,
  "tolerance": 1e-06
}
"""课程统一质量分：简单基线0、专家参考1，逐次换算后取平均。"""
import math

VALID_FAILURES = {"invalid", "agent_error", "timeout"}


def finite_number(value, name):
    if type(value) not in (int, float):
        raise ValueError(f"{name}须为有限数值")
    try:
        result = float(value)
    except OverflowError as exc:
        raise ValueError(f"{name}须为有限数值") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name}须为有限数值")
    return result


def validate_metric(metric):
    if metric.get("kind") == "binary":
        baseline = finite_number(metric.get("baseline"), "baseline")
        reference = finite_number(metric.get("reference"), "reference")
        if baseline != 0 or reference != 1:
            raise ValueError("二元题须实测简单基线0、参考解1，否则不构成有效的参考提升")
        return
    if metric.get("kind") != "continuous":
        raise ValueError("kind须为binary或continuous")
    direction = metric.get("direction")
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction须为maximize或minimize")
    baseline = finite_number(metric.get("baseline"), "baseline")
    reference = finite_number(metric.get("reference"), "reference")
    tolerance = finite_number(metric.get("tolerance"), "tolerance")
    if tolerance < 0:
        raise ValueError("原始指标容差不能为负")
    improvement = reference - baseline if direction == "maximize" else baseline - reference
    if not math.isfinite(improvement) or improvement <= tolerance:
        raise ValueError("参考解相对基线的改善须超过原始指标容差；请先核查设置")


def quality_score(metric, raw_metric, status="completed"):
    validate_metric(metric)
    if status in VALID_FAILURES:
        return 0.0
    if status != "completed":
        raise ValueError("基础设施或评分器故障不能填0；请先处理并补跑")
    value = finite_number(raw_metric, "raw_metric")
    if metric["kind"] == "binary":
        if value not in {0.0, 1.0}:
            raise ValueError("二元任务的实测结果须为0或1")
        return value
    baseline = float(metric["baseline"])
    reference = float(metric["reference"])
    fraction = (value - baseline) / (reference - baseline)
    return max(0.0, min(1.0, fraction))

exit_code=0
```
tasks/qft-04/tests/development_cases.py
tasks/qft-04/tests/quality_score.py
tasks/qft-04/tests/private/truth.json
tasks/qft-04/tests/metric.json
tasks/qft-04/tests/test.sh
tasks/qft-04/tests/score.py
tasks/qft-04/solution/baseline.py
tasks/qft-04/solution/solve.sh
tasks/qft-04/solution/README.md
tasks/qft-04/solution/solver_core.py
tasks/qft-04/solution/solve.py
tasks/qft-04/instruction.md
tasks/qft-04/environment/requirements.txt
tasks/qft-04/environment/Dockerfile
tasks/qft-04/environment/.dockerignore
tasks/qft-04/environment/public/model.json
tasks/qft-04/environment/public/feedback.py
tasks/qft-04/environment/public/physics.py
tasks/qft-04/environment/public/metric.json
tasks/qft-04/task.toml

exit_code=0
```

### 2026-11-16T22:04:12.091814+08:00

```bash
python3 -c 'import sys,numpy,scipy,mpmath; print(sys.executable,numpy.__version__,scipy.__version__,mpmath.__version__)'
```

```text

### 2026-11-16T22:04:12.091848+08:00

```bash
docker info --format '{{.ServerVersion}}'
```

```text
Traceback (most recent call last):
  File "<string>", line 1, in <module>
ModuleNotFoundError: No module named 'numpy'

exit_code=1
```
29.6.1

exit_code=0
```

### 2026-11-16T22:11:14.775932+08:00

```bash
/Users/ai4s/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 tools/author_qft20_25.py
```

```text
Traceback (most recent call last):
  File "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/author_qft20_25.py", line 8, in <module>
    from scipy.linalg import expm
ModuleNotFoundError: No module named 'scipy'

exit_code=1
```

### 2026-11-16T22:11:28.390962+08:00

```bash
cat tools/build_qft04_truth.py
```

```text

### 2026-11-16T22:11:28.390999+08:00

```bash
docker image ls --format '{{.Repository}}:{{.Tag}}'
```

```text
"""Independent arbitrary-precision KN primitives and explicit-spinor amplitudes."""
import json
from pathlib import Path
import mpmath as mp

ROOT=Path(__file__).resolve().parents[1]
TASK=ROOT/'tasks/qft-04'


def scalar(value):return mp.mpf(str(value))


def build_case(case):
    x=scalar(case['x']);bn,bd=case['beta_fraction'];beta=mp.mpf(bn)/bd;gamma=1/mp.sqrt(1-beta*beta)
    A=1-2*(1+x)/x**2;B=(1+2*x)/x**2
    def primitive(c):
        t=1+x*(1-c)
        return -mp.pi/x*(A*mp.log(t)-B/t-1/(2*t*t)+t/x**2)
    def integral(a,b):return primitive(b)-primitive(a)
    def density(c):
        t=1+x*(1-c)
        return mp.pi/t**2*(t+1/t-(1-c*c))
    def energy(c):return gamma*x*(1+beta*c)/(1+x*(1-c))
    def costheta(theta):
        if abs(theta-mp.pi)<mp.mpf('1e-14'):return -mp.mpf(1)
        return mp.cos(theta)
    theta0,theta1=map(scalar,case['lab_theta_window'])
    inv=lambda mu:(mu-beta)/(1-beta*mu)
    left=max(-mp.mpf(1),inv(costheta(theta1)));right=min(mp.mpf(1),inv(costheta(theta0)))
    el,eh=map(scalar,case['lab_energy_window']);cuts=[left,right]
    D=x+beta*(1+x)
    if abs(D)<mp.mpf('1e-60'):
        valid=left<right and el<=energy(0)<=eh
    else:
        for e in (el,eh):
            denominator=x*(e+gamma*beta)
            if abs(denominator)>mp.mpf('1e-60'):
                crossing=(e*(1+x)-gamma*x)/denominator
                if left<crossing<right:cuts.append(crossing)
        cuts=sorted(cuts);segments=[(a,b) for a,b in zip(cuts[:-1],cuts[1:]) if a<b and el<=energy((a+b)/2)<=eh]
        valid=bool(segments)
        if valid:left,right=segments[0][0],segments[-1][1]
    total=integral(-1,1)
    # A separate direct integrator verifies the analytic primitive.
    total_quad=mp.quad(density,[-1,0,mp.mpf('.9'),mp.mpf('.99'),1])
    difference=abs(total-total_quad)
    result={'id':case['id'],'sigma':total}
    if not valid:return {**result,'accepted_sigma':mp.mpf(0),'acceptance':mp.mpf(0),'mean_energy':None,'energy_quantiles':None,'accepted_cos_interval':None},difference
    accepted=integral(left,right)
    mean=mp.quad(lambda c:density(c)*energy(c),[left,(left+right)/2,right])/accepted
    if abs(D)<mp.mpf('1e-60'):quantiles=[energy(0)]*3
    else:
        quantiles=[]
        for p in map(mp.mpf,('.1','.5','.9')):
            probability=p if D>0 else 1-p
            a,b=left,right
            for _ in range(230):
                c=(a+b)/2
                if integral(left,c)/accepted<probability:a=c
                else:b=c
            quantiles.append(energy((a+b)/2))
    return {**result,'accepted_sigma':accepted,'acceptance':accepted/total,'mean_energy':mean,'energy_quantiles':quantiles,'accepted_cos_interval':[left,right]},difference


def spinor_probes(probe):
    x=scalar(probe['x']);c=scalar(probe['cos_theta']);r=x/(1+x*(1-c));sn=mp.sqrt(1-c*c)
    pauli=[mp.matrix([[0,1],[1,0]]),mp.matrix([[0,-mp.j],[mp.j,0]]),mp.matrix([[1,0],[0,-1]])]
    g0=mp.diag([1,1,-1,-1]);gammas=[g0]
    for sigma in pauli:
        matrix=mp.zeros(4)
        for a in range(2):
            for b in range(2):matrix[a,b+2]=sigma[a,b];matrix[a+2,b]=-sigma[a,b]
        gammas.append(matrix)
    def slash(v):
        result=v[0]*gammas[0]
        for j in range(1,4):result-=v[j]*gammas[j]
        return result
    p=mp.matrix([1,0,0,0]);k=mp.matrix([x,0,0,x]);kp=mp.matrix([r,r*sn,0,r*c]);pp=p+k-kp
    def spinor(momentum,spin):
        chi=mp.matrix([int(spin==0),int(spin==1)])
        sigma_p=sum((momentum[j+1]*pauli[j] for j in range(3)),mp.zeros(2))
        top=mp.sqrt(momentum[0]+1)*chi;bottom=sigma_p*chi/mp.sqrt(momentum[0]+1)
        return mp.matrix([top[0],top[1],bottom[0],bottom[1]])
    incoming=[mp.matrix([0,1,0,0]),mp.matrix([0,0,1,0])]
    outgoing=[mp.matrix([0,c,0,-sn]),mp.matrix([0,0,1,0])]
    def parts(eta,zeta):
        values=[mp.mpf(0)]*3
        for ei in incoming:
            for eo in outgoing:
                inslash=slash(ei+eta*k/x);outslash=slash(eo+zeta*kp/r)
                s=outslash*(slash(p+k)+mp.eye(4))*inslash/(2*x)
                u=inslash*(slash(p-kp)+mp.eye(4))*outslash/(-2*r)
                for a in range(2):
                    for b in range(2):
                        initial=spinor(p,a);final=spinor(pp,b);bar=final.H*g0
                        ms=(bar*s*initial)[0];mu=(bar*u*initial)[0]
                        values[0]+=abs(ms)**2/4;values[1]+=abs(mu)**2/4;values[2]+=mp.re(ms*mp.conj(mu))/2
        return values
    ordinary=parts(0,0);shifted=parts(scalar(probe['incoming_gauge_shift']),scalar(probe['outgoing_gauge_shift']))
    expected=2*((r/x)+(x/r)-(1-c*c))
    check={'id':probe['id'],'ward_residual':str(abs(sum(ordinary)-sum(shifted))),'kn_residual':str(abs(sum(ordinary)-expected))}
    return {'id':probe['id'],'s_squared':ordinary[0],'u_squared':ordinary[1],'interference':ordinary[2],'total':sum(ordinary),'gauge_shifted_total':sum(shifted)},check


def serialize(value,digits=False):
    if value is None or isinstance(value,(str,bool,int)):return value
    if isinstance(value,dict):return {k:serialize(v,digits) for k,v in value.items()}
    if isinstance(value,list):return [serialize(v,digits) for v in value]
    return str(value) if digits else float(value)


def build(model,precision):
    with mp.workdps(precision):
        cases=[];differences=[]
        for item in model['cases']:
            result,error=build_case(item);cases.append(result);differences.append(str(error))
        probes=[];checks=[]
        for item in model['probes']:
            result,check=spinor_probes(item);probes.append(result);checks.append(check)
        return {'cases':serialize(cases,True),'probes':serialize(probes,True)}, {'primitive_quad_differences':differences,'amplitude_checks':checks}


def numbers(value):
    if isinstance(value,dict):return {k:numbers(v) for k,v in value.items()}
    if isinstance(value,list):return [numbers(v) for v in value]
    if isinstance(value,str):
        try:return float(value)
        except ValueError:return value
    return value


def compare(a,b):
    if isinstance(a,dict):return max([compare(a[k],b[k]) for k in a]+[mp.mpf(0)])
    if isinstance(a,list):return max([compare(x,y) for x,y in zip(a,b)]+[mp.mpf(0)])
    if a is None or isinstance(a,(bool,int)):return mp.mpf(0) if a==b else mp.inf
    try:return abs(mp.mpf(a)-mp.mpf(b))/max(1,abs(mp.mpf(a)))
    except ValueError:return mp.mpf(0) if a==b else mp.inf


def main():
    model=json.loads((TASK/'environment/public/model.json').read_text())
    truth,validation=build(model,70);check,_=build(model,45)
    with mp.workdps(80):difference=compare(truth,check)
    if difference>mp.mpf('1e-38'):raise ArithmeticError('precision cross-check failed')
    for item in validation['amplitude_checks']:
        if max(mp.mpf(item['ward_residual']),mp.mpf(item['kn_residual']))>mp.mpf('1e-60'):raise ArithmeticError('amplitude identity failed')
    for error in validation['primitive_quad_differences']:
        if mp.mpf(error)>mp.mpf('1e-60'):raise ArithmeticError('independent integral failed')
    (TASK/'tests/private/truth.json').write_text(json.dumps(numbers(truth),ensure_ascii=False,indent=2)+'\n')
    validation.update(precision_digits=70,recheck_digits=45,max_relative_precision_difference=str(difference),truth_digits=truth,method='analytic KN primitive with direct mp.quad check; exact rational beta, algebraic cut intersection, explicit-spinor amplitudes')
    (ROOT/'checks/qft-04-truth-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'max_relative_precision_difference':str(difference),'validation':{k:v for k,v in validation.items() if k!='truth_digits'},'truth':numbers(truth)},ensure_ascii=False,indent=2))


if __name__=='__main__':main()

exit_code=0
```
theory-physics-sp05:dev
theory-physics-sp04:dev
theory-physics-sp03:dev
theory-physics-sp02:dev
theory-physics-qft04:dev
theory-physics-ed05:dev
theory-physics-qft03:dev
theory-physics-ed04:dev
theory-physics-ed03:dev
theory-physics-tm03:dev
theory-physics-qft02:dev
theory-physics-qm03:dev
theory-physics-ed02:dev
theory-physics-qm02:dev
theory-physics-qft01:dev
theory-physics-ed01:dev
theory-physics-qm01:dev
theory-physics-sp01:dev
theory-physics-tm02:dev
theory-physics-tm01:dev
mechanics-inverse-task01:dev
gbplanner2-course:local
gbplanner2-course-fortress:local
gbplanner2-course-base:local
gbplanner2-humble:local
iquest-benchmark-sqlite-db-truncate:20261019
iquest-benchmark-git-leak-recovery:20261019
iquest-benchmark-openssl-selfsigned-cert:20261019
iquest-benchmark-log-summary-date-ranges:20261019
iquest-benchmark-regex-log:20261019
iquest-benchmark-cancel-async-tasks:20261019
iquest-benchmark-base:20261019
mirror.gcr.io/library/ros:humble-ros-base-jammy
subject-agent-searxng:latest
subject-agent-searxng:alpine-clean
subject-agent-searxng:alpine-fixed
subject-agent-searxng:alpine
subject-agent-searxng:trixie
subject-agent-mysql:8.0
deploy-word-worker:latest
deploy-image-sanitizer:latest
deploy-ops:latest
deploy-migrate:latest
deploy-backend:latest
subject-agent-d04-amd64-image:local
subject-agent-d04-amd64-word:local
subject-agent-d04-amd64-frontend:local
subject-agent-d04-amd64-backend:local
deploy-frontend:latest
subject-agent-d04-image-local:latest
subject-agent-d04-word-local:latest
subject-agent-d04-backend-local:latest
subject-agent-d04-builder-local:latest
subject-agent-d04-backend:local
subject-agent-d04-builder:local
subject-agent-d04-word:local
subject-agent-d04-image:local
subject-agent-security:word-current
subject-agent-security:image-current
subject-agent-security:backend-current
subject-agent-d04-frontend-local:latest
subject-agent-security:frontend-current
subject-agent-d04-frontend:local
cgr.dev/chainguard/python:latest
mirror.gcr.io/library/python:3.14-slim-bookworm
mirror.gcr.io/library/python:3.14-slim-trixie
mirror.gcr.io/library/python:3.14-alpine
subject-agent-security:frontend-resilient-20260924
deploy-frontend-builder:resilient-current
subject-agent-security:frontend-20260924
nginx:1.30.5-alpine3.24
subject-agent-nginx-verified:20260924
mirror.gcr.io/library/nginx:<none>
redis:8-alpine
subject-agent-security:word-d1a408d-20260919
subject-agent-security:image-d1a408d-20260919
subject-agent-security:backend-d1a408d-20260919
subject-agent-security:frontend-d1a408d-20260919
subject-agent-security:builder-d1a408d-20260919
node:24-alpine
mirror.gcr.io/library/node:24-alpine
mirror.gcr.io/library/python:3.12.13-slim-bookworm
ollama/ollama:latest
searxng/searxng:latest
nginx:alpine
mirror.gcr.io/library/python:3.14-alpine3.22
mysql:8.0
mirror.gcr.io/library/mysql:8.0
alpine:<none>
hello-world:latest
nginx:1.27-alpine
gcr.io/distroless/python3-debian13:latest

exit_code=0
```

### 2026-11-16T22:11:59.043223+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/author_qft20_25.py
```

```text
Built skeleton, models, reference and verifier for six real tasks; truth/metrics follow separately.

exit_code=0
```

### 2026-11-16T22:14:19.631710+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/build_qft20_25_truth.py
```

```text
{"task": 20, "analytic_primitive_vs_45_digit_quad_max": 3.503246160812043e-46, "paired_spectrum": "full +/- pairs plus explicit exact zero modes", "density_normalization": "per unit four-volume, each signed branch density rho", "generation_seconds": 0.4842515839999919}
{"task": 21, "polynomial_root_max_residual": 1.631675202522618e-15, "index_sums": [0.0, 0.0, 0.0, 0.0, 0.0], "completeness": "all unit-circle roots of explicit factored Laurent polynomial; triangular torus change has det=1", "generation_seconds": 0.008146624999994856}
{"task": 22, "N12_full_configuration_vs_occupation_m2_max": 2.220446049250313e-16, "thermodynamic_truth": "independent two-dimensional constrained free-energy minimization, all three sectors", "generation_seconds": 0.5780671249999614}
/work/tools/build_qft20_25_truth.py:106: IntegrationWarning: The maximum number of subdivisions (50) has been achieved.
  If increasing the limit yields no improvement it is advised to analyze 
  the integrand in order to determine the difficulties.  If the position of a 
  local difficulty can be determined (singularity, discontinuity) one will 
  probably gain from splitting up the interval and calling the integrator 
  on the subranges.  Perhaps a special-purpose integrator should be used.
  return complex(quad(lambda u:weight(u)/(x-u),-1,1,epsabs=1e-13,epsrel=1e-13)[0])
{"task": 23, "truth_route": "Cauchy principal-value velocity quadrature plus exact on-shell delta imaginary part; derivatives integrated independently", "normalization": "mD^2=1; omega and k in mD units", "generation_seconds": 0.0030498329999772977}
{"task": 24, "direct_momentum_dense_vs_real_block_max": 1.0658719261875216e-14, "kernel": "complete explicitly regulated periodic transfer kernel, no diffusion substitution", "positive_collision_operator": true, "continuum_claim": false, "generation_seconds": 0.07807345800000576}
{"task": 25, "bogoliubov_identity_max": 8.149037000748649e-14, "single_Sauter_analytic_max": 6.328271240363392e-15, "route": "one-order adiabatic Bogoliubov system; reference uses second-order KG", "statistics": "bosonic geometric per independent canonical mode pair", "generation_seconds": 0.25202479199998606}

exit_code=0
```

### 2026-11-16T22:16:20.828504+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft20_25_checks.py --calibrate
```

```text
Traceback (most recent call last):
  File "/work/tools/run_qft20_25_checks.py", line 107, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "/work/tools/run_qft20_25_checks.py", line 15, in main
    score=load(f'qft{n}_score',tests/'score.py');quality=load(f'qft{n}_quality',tests/'quality_score.py');answers={};runtime={};cases={}
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/work/tools/run_qft20_25_checks.py", line 7, in load
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
                                                                                                   ^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "<frozen importlib._bootstrap_external>", line 999, in exec_module
  File "<frozen importlib._bootstrap>", line 488, in _call_with_frames_removed
  File "/work/tasks/qft-20/tests/score.py", line 5, in <module>
    from quality_score import quality_score
ModuleNotFoundError: No module named 'quality_score'

exit_code=1
```

### 2026-11-16T22:16:46.414235+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft20_25_checks.py --calibrate
```

```text
{"task": 20, "metric": {"kind": "continuous", "metric_name": "Dirac 低谱、Banks–Casher 凝聚与极限次序的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 27.22528003601866, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.10549925000003668, "reference_seconds": 0.12998362499996574}}
{"task": 21, "metric": {"kind": "continuous", "metric_name": "格点费米子倍增、完整零点与局部指数的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 60.0, "reference": 2.0377089988825485e-13, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.10671920900000487, "reference_seconds": 0.10199587500000007}}
{"task": 22, "metric": {"kind": "continuous", "metric_name": "中心对称、有限体积扇区混合与 Polyakov 环的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 5.331703298002835, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.11046699999997145, "reference_seconds": 0.10535983300002272}}
{"task": 23, "metric": {"kind": "continuous", "metric_name": "热光子 HTL 的因果响应与集体模的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 8.105952610749402, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.10060145900001771, "reference_seconds": 0.09817483399996263}}
{"task": 24, "metric": {"kind": "continuous", "metric_name": "完整差分碰撞核下的 LPM 响应与近似选择的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 39.43072557423114, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.12386812500000133, "reference_seconds": 0.12256529199999022}}
{"task": 25, "metric": {"kind": "continuous", "metric_name": "标量强场产对、相干脉冲与玻色统计的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 1.3076931957474827, "reference": 0.0, "tolerance": 1e-06}, "checks": 24, "passed": true, "runtime": {"baseline_seconds": 0.2632715839999946, "reference_seconds": 0.4105245830000399}}

exit_code=0
```

### 2026-11-16T22:23:15.920860+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/author_qft20_25.py
```

```text
Built skeleton, models, reference and verifier for six real tasks; truth/metrics follow separately.

exit_code=0
```

### 2026-11-16T22:23:16.588252+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/build_qft20_25_truth.py
```

```text
{"task": 20, "analytic_primitive_vs_45_digit_quad_max": 3.503246160812043e-46, "paired_spectrum": "full +/- pairs plus explicit exact zero modes", "density_normalization": "per unit four-volume, each signed branch density rho", "generation_seconds": 0.5716910829999051}
{"task": 21, "polynomial_root_max_residual": 1.631675202522618e-15, "index_sums": [0.0, 0.0, 0.0, 0.0, 0.0], "completeness": "all unit-circle roots of explicit factored Laurent polynomial; triangular torus change has det=1", "generation_seconds": 0.010405875000060405}
{"task": 22, "N12_full_configuration_vs_occupation_m2_max": 2.220446049250313e-16, "thermodynamic_truth": "independent two-dimensional constrained free-energy minimization, all three sectors", "generation_seconds": 0.7092478340000525}
/work/tools/build_qft20_25_truth.py:107: IntegrationWarning: The occurrence of roundoff error is detected, which prevents 
  the requested tolerance from being achieved.  The error may be 
  underestimated.
  return complex(quad(lambda u:weight(u)/(x-u),-1,1,epsabs=1e-12,epsrel=1e-12,limit=300)[0])
{"task": 23, "truth_route": "Cauchy principal-value velocity quadrature plus exact on-shell delta imaginary part; derivatives integrated independently", "normalization": "mD^2=1; omega and k in mD units", "generation_seconds": 0.00501962500004538}
{"task": 24, "direct_momentum_dense_vs_real_block_max": 1.0658719261875216e-14, "kernel": "complete explicitly regulated periodic transfer kernel, no diffusion substitution", "positive_collision_operator": true, "continuum_claim": false, "generation_seconds": 0.09283045899996978}
{"task": 25, "bogoliubov_identity_max": 8.149037000748649e-14, "single_Sauter_analytic_max": 6.328271240363392e-15, "route": "one-order adiabatic Bogoliubov system; reference uses second-order KG", "statistics": "bosonic geometric per independent canonical mode pair", "generation_seconds": 0.273048708000033}

exit_code=0
```

### 2026-11-16T22:23:57.747790+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft20_25_checks.py --calibrate
```

```text

### 2026-11-16T22:23:58.895043+08:00

```bash
cat tools/run_harbor_local_checks.py
```

```text
#!/usr/bin/env python3
"""Run oracle/nop locally and archive raw jobs, including unsuccessful runs."""

import argparse
import datetime
import json
import platform
import re
import shlex
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("task_id")
    parser.add_argument("--macos-compat", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z]+-[0-9]{2}", args.task_id):
        parser.error("invalid task id")
    source = ROOT / "tasks" / args.task_id
    if not source.is_dir():
        parser.error("task directory does not exist")
    harbor = shutil.which("harbor")
    if not harbor:
        raise SystemExit("harbor executable not found")
    # Avoid '%' URL handling in Harbor/Compose, retaining the exact task contents.
    stage = Path(tempfile.mkdtemp(prefix=f"physics-{args.task_id}-harbor-", dir="/tmp"))
    task = stage / args.task_id
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"))
    if args.macos_compat:
        config = task / "task.toml"
        original = config.read_text(encoding="utf-8")
        needle = 'environment_mode = "separate"\nnetwork_mode = "no-network"'
        if needle not in original:
            raise SystemExit("expected verifier network declaration missing")
        config.write_text(original.replace(needle, 'environment_mode = "separate"\nnetwork_mode = "public"'), encoding="utf-8")
    mode = "harbor-macos-compat" if args.macos_compat else "harbor-linux"
    destination = ROOT / "runs" / args.task_id / mode
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for agent in ("oracle", "nop"):
        jobs = stage / "runs" / agent
        command = [harbor, "run", "-p", str(task), "-a", agent,
                   "--n-attempts", "1", "--n-concurrent", "1", "--max-retries", "0",
                   "--jobs-dir", str(jobs)]
        print("$ " + shlex.join(command), flush=True)
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(command, text=True)
        job_results=sorted(jobs.glob('*/result.json'))
        summaries=[]
        for result_path in job_results:
            payload=json.loads(result_path.read_text(encoding='utf-8'))
            stats=payload.get('stats',{})
            expected=1.0 if agent=='oracle' else 0.0
            evaluations=stats.get('evals',{})
            passed=(stats.get('n_errored_trials')==0 and stats.get('n_completed_trials')==1
                    and len(evaluations)==1)
            for evaluation in evaluations.values():
                passed=passed and evaluation.get('n_trials')==1 and evaluation.get('n_errors')==0
                metrics=evaluation.get('metrics',[])
                passed=passed and len(metrics)==1 and metrics[0].get('mean')==expected
            summaries.append({'result':str(result_path.relative_to(jobs)), 'passed':passed,
                              'expected_reward':expected, 'stats':stats})
        archive = destination / agent
        archive.mkdir(parents=True, exist_ok=True)
        if jobs.exists():
            shutil.copytree(jobs, archive, dirs_exist_ok=True)
        records.append({"agent": agent, "command": command, "returncode": result.returncode,
                        "started_utc": started, "archive": str(archive.relative_to(ROOT)),
                        "verified_results":summaries,
                        "passed":result.returncode==0 and len(summaries)==1 and all(s['passed'] for s in summaries)})
    report = {"task_id": args.task_id, "host": platform.platform(), "temporary_task": str(task),
              "macos_verifier_network_override": args.macos_compat, "runs": records}
    output = destination / ("session-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    if any(not record['passed'] for record in records):
        raise SystemExit("Harbor trial/reward verification failed; original jobs have been archived")


if __name__ == "__main__":
    main()

exit_code=0
```
{"task": 20, "metric": {"kind": "continuous", "metric_name": "Dirac 低谱、Banks–Casher 凝聚与极限次序的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 27.22528003601866, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.15413720800006558, "reference_seconds": 0.21316441600004055}}
{"task": 21, "metric": {"kind": "continuous", "metric_name": "格点费米子倍增、完整零点与局部指数的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 60.0, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.11469229200008613, "reference_seconds": 0.1207513750000544}}
{"task": 22, "metric": {"kind": "continuous", "metric_name": "中心对称、有限体积扇区混合与 Polyakov 环的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 2.7777774999999996, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.1540716250000287, "reference_seconds": 0.10987499999998818}}
{"task": 23, "metric": {"kind": "continuous", "metric_name": "热光子 HTL 的因果响应与集体模的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 8.105952610749412, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.11497145900000305, "reference_seconds": 0.10423408400004064}}
{"task": 24, "metric": {"kind": "continuous", "metric_name": "完整差分碰撞核下的 LPM 响应与近似选择的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 39.43072557423114, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.1238965410000219, "reference_seconds": 0.12397162499996739}}
{"task": 25, "metric": {"kind": "continuous", "metric_name": "标量强场产对、相干脉冲与玻色统计的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 1.3076931957474827, "reference": 0.0, "tolerance": 1e-06}, "checks": 24, "passed": true, "runtime": {"baseline_seconds": 0.2798744159999842, "reference_seconds": 0.46300129200005813}}

exit_code=0
```

### 2026-11-16T22:24:48.582891+08:00

```bash
python3 tools/document_qft20_25.py
```

```text
Wrote six complete statements, method notes, source/fairness records.

exit_code=0
```

### 2026-11-16T22:24:48.691253+08:00

```bash
python3 tools/run_pending_harbor.py qft-20 qft-21 qft-22 qft-23 qft-24 qft-25
```

```text
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-20 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-20-harbor-smrlexxy/qft-20 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-20-harbor-smrlexxy/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:27 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 27s
Results written to 
/tmp/physics-qft-20-harbor-smrlexxy/runs/oracle/2026-11-16__22-24-49/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-20-harbor-smrlexxy/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-20-harbor-smrlexxy/runs/oracle/2026-11-16__22-24-49`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-20-harbor-smrlexxy/qft-20 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-20-harbor-smrlexxy/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-20-harbor-smrlexxy/runs/nop/2026-11-16__22-25-20/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-20-harbor-smrlexxy/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-20-harbor-smrlexxy/runs/nop/2026-11-16__22-25-20`

{
  "task_id": "qft-20",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-20-harbor-smrlexxy/qft-20",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-20-harbor-smrlexxy/qft-20",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-20-harbor-smrlexxy/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:24:48.790491+00:00",
      "archive": "runs/qft-20/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-24-49/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-20__QyhMJw7"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-20-harbor-smrlexxy/qft-20",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-20-harbor-smrlexxy/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:25:20.264748+00:00",
      "archive": "runs/qft-20/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-25-20/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-20__pC6LfMA"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-21 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-21-harbor-u7pfrje5/qft-21 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-21-harbor-u7pfrje5/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:27 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 27s
Results written to 
/tmp/physics-qft-21-harbor-u7pfrje5/runs/oracle/2026-11-16__22-25-51/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-21-harbor-u7pfrje5/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-21-harbor-u7pfrje5/runs/oracle/2026-11-16__22-25-51`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-21-harbor-u7pfrje5/qft-21 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-21-harbor-u7pfrje5/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-21-harbor-u7pfrje5/runs/nop/2026-11-16__22-26-22/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-21-harbor-u7pfrje5/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-21-harbor-u7pfrje5/runs/nop/2026-11-16__22-26-22`

{
  "task_id": "qft-21",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-21-harbor-u7pfrje5/qft-21",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-21-harbor-u7pfrje5/qft-21",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-21-harbor-u7pfrje5/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:25:51.084786+00:00",
      "archive": "runs/qft-21/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-25-51/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-21__rQif2uP"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-21-harbor-u7pfrje5/qft-21",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-21-harbor-u7pfrje5/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:26:22.317795+00:00",
      "archive": "runs/qft-21/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-26-22/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-21__mH7TUna"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-22 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-22-harbor-7g1umnzk/qft-22 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-22-harbor-7g1umnzk/runs/oracle

### 2026-11-16T22:27:09.213317+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft20_25_checks.py 22 --calibrate
```

```text
{"task": 22, "metric": {"kind": "continuous", "metric_name": "中心对称、有限体积扇区混合与 Polyakov 环的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 5.115397663299489, "reference": 0.0, "tolerance": 1e-06}, "checks": 23, "passed": true, "runtime": {"baseline_seconds": 0.1614380420000998, "reference_seconds": 0.1374796250001964}}

exit_code=0
```
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-22-harbor-7g1umnzk/runs/oracle/2026-11-16__22-26-53/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-22-harbor-7g1umnzk/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-22-harbor-7g1umnzk/runs/oracle/2026-11-16__22-26-53`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-22-harbor-7g1umnzk/qft-22 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-22-harbor-7g1umnzk/runs/nop

### 2026-11-16T22:27:45.277177+08:00

```bash
python3 tools/document_qft20_25.py
```

```text
Wrote six complete statements, method notes, source/fairness records.

exit_code=0
```
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-22-harbor-7g1umnzk/runs/nop/2026-11-16__22-27-24/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-22-harbor-7g1umnzk/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-22-harbor-7g1umnzk/runs/nop/2026-11-16__22-27-24`

{
  "task_id": "qft-22",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-22-harbor-7g1umnzk/qft-22",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-22-harbor-7g1umnzk/qft-22",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-22-harbor-7g1umnzk/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:26:53.193367+00:00",
      "archive": "runs/qft-22/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-26-53/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-22__TvE2F5i"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-22-harbor-7g1umnzk/qft-22",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-22-harbor-7g1umnzk/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:27:24.328846+00:00",
      "archive": "runs/qft-22/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-27-24/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-22__QjgvmGm"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-23 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-23-harbor-d219fja7/qft-23 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-23-harbor-d219fja7/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-23-harbor-d219fja7/runs/oracle/2026-11-16__22-27-54/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-23-harbor-d219fja7/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-23-harbor-d219fja7/runs/oracle/2026-11-16__22-27-54`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-23-harbor-d219fja7/qft-23 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-23-harbor-d219fja7/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-23-harbor-d219fja7/runs/nop/2026-11-16__22-28-24/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-23-harbor-d219fja7/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-23-harbor-d219fja7/runs/nop/2026-11-16__22-28-24`

{
  "task_id": "qft-23",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-23-harbor-d219fja7/qft-23",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-23-harbor-d219fja7/qft-23",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-23-harbor-d219fja7/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:27:54.142997+00:00",
      "archive": "runs/qft-23/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-27-54/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-23__qsGycRk"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-23-harbor-d219fja7/qft-23",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-23-harbor-d219fja7/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:28:24.286699+00:00",
      "archive": "runs/qft-23/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-28-24/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-23__rZPgdoY"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-24 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-24-harbor-xzyo2yy1/qft-24 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-24-harbor-xzyo2yy1/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-24-harbor-xzyo2yy1/runs/oracle/2026-11-16__22-28-53/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-24-harbor-xzyo2yy1/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-24-harbor-xzyo2yy1/runs/oracle/2026-11-16__22-28-53`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-24-harbor-xzyo2yy1/qft-24 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-24-harbor-xzyo2yy1/runs/nop

### 2026-11-16T22:29:39.643951+08:00

```bash
python3 -c 'import json; from pathlib import Path; p=Path("tasks/qft-25/environment/public/model.json"); m=json.loads(p.read_text()); [(b.update(offset=1.2 if b["id"] in ("first","second") else 0.0)) for b in m["backgrounds"]]; p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+"\n")'
```

```text

exit_code=0
```

### 2026-11-16T22:29:39.759163+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/build_qft20_25_truth.py 25
```

```text
{"task": 25, "bogoliubov_identity_max": 8.149037000748649e-14, "single_Sauter_analytic_max": 8.631984016460592e-15, "route": "one-order adiabatic Bogoliubov system; reference uses second-order KG", "statistics": "bosonic geometric per independent canonical mode pair", "generation_seconds": 0.2637724169999274}

exit_code=0
```
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qft-24-harbor-xzyo2yy1/runs/nop/2026-11-16__22-29-23/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-24-harbor-xzyo2yy1/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-24-harbor-xzyo2yy1/runs/nop/2026-11-16__22-29-23`

{
  "task_id": "qft-24",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-24-harbor-xzyo2yy1/qft-24",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-24-harbor-xzyo2yy1/qft-24",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-24-harbor-xzyo2yy1/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:28:53.313457+00:00",
      "archive": "runs/qft-24/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-28-53/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-24__K24cTUA"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-24-harbor-xzyo2yy1/qft-24",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-24-harbor-xzyo2yy1/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:29:23.251277+00:00",
      "archive": "runs/qft-24/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-29-23/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-24__zbbdT56"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-25 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-25-harbor-7_gn5f7n/qft-25 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-25-harbor-7_gn5f7n/runs/oracle

### 2026-11-16T22:30:03.869539+08:00

```bash
docker run --rm --network none --cpus 2 --memory 2g --user 0 -e OPENBLAS_NUM_THREADS=1 -e OMP_NUM_THREADS=1 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/work' -w /work theory-physics-qft04:dev python3 tools/run_qft20_25_checks.py 25 --calibrate
```

```text
{"task": 25, "metric": {"kind": "continuous", "metric_name": "标量强场产对、相干脉冲与玻色统计的归一化物理误差", "unit": "百分点", "direction": "minimize", "baseline": 1.1994053966841303, "reference": 0.0, "tolerance": 1e-06}, "checks": 24, "passed": true, "runtime": {"baseline_seconds": 0.25149083400015115, "reference_seconds": 0.4318526250001469}}

exit_code=0
```
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:27 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 27s
Results written to 
/tmp/physics-qft-25-harbor-7_gn5f7n/runs/oracle/2026-11-16__22-29-53/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-25-harbor-7_gn5f7n/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-25-harbor-7_gn5f7n/runs/oracle/2026-11-16__22-29-53`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-25-harbor-7_gn5f7n/qft-25 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-25-harbor-7_gn5f7n/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-25-harbor-7_gn5f7n/runs/nop/2026-11-16__22-30-24/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-25-harbor-7_gn5f7n/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-25-harbor-7_gn5f7n/runs/nop/2026-11-16__22-30-24`

{
  "task_id": "qft-25",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-25-harbor-7_gn5f7n/qft-25",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-25-harbor-7_gn5f7n/qft-25",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-25-harbor-7_gn5f7n/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:29:52.753987+00:00",
      "archive": "runs/qft-25/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-29-53/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-25__JXXrawx"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-25-harbor-7_gn5f7n/qft-25",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-25-harbor-7_gn5f7n/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:30:23.756564+00:00",
      "archive": "runs/qft-25/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-30-24/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-25__8dWcFpE"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}

exit_code=0
```

### 2026-11-16T22:30:57.425451+08:00

```bash
python3 tools/document_qft20_25.py
```

```text
Wrote six complete statements, method notes, source/fairness records.

exit_code=0
```

### 2026-11-16T22:30:57.526262+08:00

```bash
python3 -c 'from pathlib import Path; import json; root=Path("."); required=["instruction.md","task.toml","environment/Dockerfile","environment/public/model.json","environment/public/metric.json","solution/solve.sh","solution/solve.py","solution/README.md","tests/test.sh","tests/score.py","tests/quality_score.py","tests/private/truth.json"]; print(json.dumps({f"qft-{i}":{p:(root/"tasks"/f"qft-{i}"/p).is_file() for p in required} for i in range(20,26)},indent=2))'
```

```text
{
  "qft-20": {
    "instruction.md": true,
    "task.toml": true,
    "environment/Dockerfile": true,
    "environment/public/model.json": true,
    "environment/public/metric.json": true,
    "solution/solve.sh": true,
    "solution/solve.py": true,
    "solution/README.md": true,
    "tests/test.sh": true,
    "tests/score.py": true,
    "tests/quality_score.py": true,
    "tests/private/truth.json": true
  },
  "qft-21": {
    "instruction.md": true,
    "task.toml": true,
    "environment/Dockerfile": true,
    "environment/public/model.json": true,
    "environment/public/metric.json": true,
    "solution/solve.sh": true,
    "solution/solve.py": true,
    "solution/README.md": true,
    "tests/test.sh": true,
    "tests/score.py": true,
    "tests/quality_score.py": true,
    "tests/private/truth.json": true
  },
  "qft-22": {
    "instruction.md": true,
    "task.toml": true,
    "environment/Dockerfile": true,
    "environment/public/model.json": true,
    "environment/public/metric.json": true,
    "solution/solve.sh": true,
    "solution/solve.py": true,
    "solution/README.md": true,
    "tests/test.sh": true,
    "tests/score.py": true,
    "tests/quality_score.py": true,
    "tests/private/truth.json": true
  },
  "qft-23": {
    "instruction.md": true,
    "task.toml": true,
    "environment/Dockerfile": true,
    "environment/public/model.json": true,
    "environment/public/metric.json": true,
    "solution/solve.sh": true,
    "solution/solve.py": true,
    "solution/README.md": true,
    "tests/test.sh": true,
    "tests/score.py": true,
    "tests/quality_score.py": true,
    "tests/private/truth.json": true
  },
  "qft-24": {
    "instruction.md": true,
    "task.toml": true,
    "environment/Dockerfile": true,
    "environment/public/model.json": true,
    "environment/public/metric.json": true,
    "solution/solve.sh": true,
    "solution/solve.py": true,
    "solution/README.md": true,
    "tests/test.sh": true,
    "tests/score.py": true,
    "tests/quality_score.py": true,
    "tests/private/truth.json": true
  },
  "qft-25": {
    "instruction.md": true,
    "task.toml": true,
    "environment/Dockerfile": true,
    "environment/public/model.json": true,
    "environment/public/metric.json": true,
    "solution/solve.sh": true,
    "solution/solve.py": true,
    "solution/README.md": true,
    "tests/test.sh": true,
    "tests/score.py": true,
    "tests/quality_score.py": true,
    "tests/private/truth.json": true
  }
}

exit_code=0
```

### 2026-11-16T22:32:19.193012+08:00

```bash
python3 tools/finalize_qft20_25.py
```

```text
{
  "all_passed": false,
  "development_checks": 139,
  "tasks": [
    {
      "id": "qft-20",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-21",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-22",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": false,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-23",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-24",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-25",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": false,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    }
  ]
}
Delivery audit failed; see exact mismatch in report

exit_code=1
```

### 2026-11-16T22:32:33.797350+08:00

```bash
python3 tools/run_pending_harbor.py qft-22 qft-25
```

```text
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-22 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-22-harbor-e0ao5v44/qft-22 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-22-harbor-e0ao5v44/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-22-harbor-e0ao5v44/runs/oracle/2026-11-16__22-32-34/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-22-harbor-e0ao5v44/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-22-harbor-e0ao5v44/runs/oracle/2026-11-16__22-32-34`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-22-harbor-e0ao5v44/qft-22 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-22-harbor-e0ao5v44/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-22-harbor-e0ao5v44/runs/nop/2026-11-16__22-33-05/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-22-harbor-e0ao5v44/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-22-harbor-e0ao5v44/runs/nop/2026-11-16__22-33-05`

{
  "task_id": "qft-22",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-22-harbor-e0ao5v44/qft-22",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-22-harbor-e0ao5v44/qft-22",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-22-harbor-e0ao5v44/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:32:33.886639+00:00",
      "archive": "runs/qft-22/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-32-34/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-22__iJhwYjo"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-22-harbor-e0ao5v44/qft-22",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-22-harbor-e0ao5v44/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:33:05.147576+00:00",
      "archive": "runs/qft-22/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-33-05/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-22__eizLKwu"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' qft-25 --macos-compat
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-25-harbor-xgslfy9e/qft-25 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-25-harbor-xgslfy9e/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:27 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 27s
Results written to 
/tmp/physics-qft-25-harbor-xgslfy9e/runs/oracle/2026-11-16__22-33-34/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-25-harbor-xgslfy9e/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-25-harbor-xgslfy9e/runs/oracle/2026-11-16__22-33-34`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-25-harbor-xgslfy9e/qft-25 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-25-harbor-xgslfy9e/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:27 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 27s
Results written to 
/tmp/physics-qft-25-harbor-xgslfy9e/runs/nop/2026-11-16__22-34-04/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-25-harbor-xgslfy9e/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-25-harbor-xgslfy9e/runs/nop/2026-11-16__22-34-04`

{
  "task_id": "qft-25",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-25-harbor-xgslfy9e/qft-25",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-25-harbor-xgslfy9e/qft-25",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-25-harbor-xgslfy9e/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:33:34.109381+00:00",
      "archive": "runs/qft-25/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-33-34/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-25__woYN6vq"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-25-harbor-xgslfy9e/qft-25",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-25-harbor-xgslfy9e/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:34:03.723891+00:00",
      "archive": "runs/qft-25/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-34-04/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-25__WXx3auW"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}

exit_code=0
```

### 2026-11-16T22:34:40.651448+08:00

```bash
python3 tools/finalize_qft20_25.py
```

```text
{
  "all_passed": true,
  "development_checks": 139,
  "tasks": [
    {
      "id": "qft-20",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-21",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-22",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-23",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-24",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    },
    {
      "id": "qft-25",
      "checks": {
        "all_development_checks_passed": true,
        "actual_harbor_oracle_and_nop_passed": true,
        "tested_runtime_files_match_delivery": true,
        "course_scorer_unchanged": true,
        "source_and_method_docs_present": true,
        "delivery_no_network_verifier": true
      }
    }
  ]
}

exit_code=0
```

### 2026-11-16T22:39:09.906207+08:00

```bash
python3 -c 'from pathlib import Path; p=Path("planning/work-order-qft20-25-next.md"); print(p.read_text() if p.exists() else "新工作单尚未生成")'
```

```text
新工作单尚未生成

exit_code=0
```

### 2026-11-16T22:40:49.465384+08:00

```bash
python3 -c 'from pathlib import Path; p=Path("planning/work-order-qft20-25-next.md"); print(p.read_text() if p.exists() else "工作单不存在")'
```

```text
工作单不存在

exit_code=0
```

### 2026-11-16T22:41:25.440100+08:00

```bash
python3 -c 'from pathlib import Path; files=sorted(Path("planning").glob("*work*"),key=lambda p:p.stat().st_mtime,reverse=True); print("\n".join(str(p) for p in files[:15]))'
```

```text
planning/work-order-formal50.md
planning/work-order-build-qft-20-25.md
planning/work-order-build-qft-13-19.md
planning/work-order-build-qft-06-12.md
planning/work-order-qft-selection-audit-now.md
planning/work-order-qft-selection-final-audit.md
planning/work-order-gelis-selection.md
planning/work-order-radovanovic-next.md
planning/work-order-sp02.md
planning/work-order-qm04-tm04.md
planning/work-order-ed03.md
planning/work-order-gr03.md
planning/work-order-ed02.md
planning/work-order-gr02.md
planning/work-order-tm03.md

exit_code=0
```

### 2026-11-16T22:41:39.706316+08:00

```bash
cat planning/work-order-formal50.md planning/work-order-build-qft-20-25.md
```

```text
# 50题统一正式测评入口

只修改新增 tools/run_formal_benchmark50.py、tools/test_formal_benchmark50.py 和 docs/formal-evaluation.md，不修改题包及共享README/manifest。

读取课程原版 tools/course/正式测评.sh、汇总结果.py、检查提交.py，原版文件保持不变。

实现独立50题扩展入口：

- 安全解析无凭据course.env，只允许MODEL/REASONING_EFFORT/CLI_VERSION，禁止执行shell配置。强制gpt-6.1-sol/max、非空助教CLI_VERSION。
- 实际运行前检查Harbor版本0.24.0，调用check_benchmark50.py --require-calibrated。
- 默认dry-run（展示将要执行的命令）；只有--execute运行正式模型。不要在开发中运行付费模型。
- 三次独立attempts、并发1、max-retries0，拒绝覆盖runs/codex或runs/ta-codex（--ta）。保留全部原始记录。
- 记录manifest与逐题冻结哈希。根路径可能含中文空格及百分号：使用无百分号安全暂存副本作为Harbor任务路径，逐文件核对副本一致，源题内容不可改；jobs写到源runs中如Harbor路径不兼容则安全暂存后完整归档。
- 汇总调用课程原版汇总结果.py，可通过--summarize单独汇总，不得伪造results.csv。
- 输出失败退出码，检查运行后源题包未变；作答只接收公开环境，不把checks/参考解混进agent镜像。
- 明确这是用户与助教沟通过的50题扩展入口，不宣称课程原版10–20题限制已经改变；同一逐题合同和43200秒预算保留。
- 自检覆盖配置解析（拒绝shell执行/未知字段/错误模型/空版本）、默认dry-run、三次/并发/重试命令参数、拒绝覆盖、哈希一致性。无网络、无正式模型。

每条shell命令先在commentary展示，并用python3 tools/run_logged.py --log checks/formal50-command-log.md -- COMMAND记录。完成后落盘planning/status-formal50.md，注明真实测试。
# 实施任务：QFT-20 至 QFT-25

用户要求实际完成整个50题Harbor benchmark。你负责 qft-20 至 qft-25 共6题，须实际封装与验证，非只选题。

读 planning/qft-expansion-20-selection.json、qft-expansion-20-audit.md、来源评审和 tasks/qft-04 示例。原书已提取planning/source-notes/qft-gelis-all.txt，可tools/read_qft_source_pages.py按页读。每题完整Harbor：题面、task.toml、固定依赖Docker公开环境、公开材料与有效反馈、合理baseline、参考solve.py/solve.sh/推导、课程原版quality_score、独立private真值及生成器、评分器、Linux校准及空/错/合法替代解验证。

20 Banks-Casher极限次序，完整正负谱和零模；21格点倍增所有根完备性；22明确可枚举中心有效系综和物相判断，不能只算单环；23 retarded HTL；24 LPM差分核红外消除，必须核符号并双路线验证，不能把扩散近似当完整核；25玻色标量产对，不能费米子/Poisson。

4CPU4GiB0GPU，agent暂720秒、verifier120秒，使50题总时限<=43200秒；必要时报告实测重新分配。只修改本组题和专属tools/checks，状态planning/status-qft-20-25.md，主代理写总manifest/README。每条shell执行前commentary展示，用python3 tools/run_logged.py --log checks/qft-20-25-command-log.md -- COMMAND记录。只Mac/Docker，不连接远程、不用GPU、不推送、不停止他人容器。

每完成一题继续到6题做完；原书问题难以落地时自主收窄为可核验的独立物理任务，记录改造，不能空交。正式Codex三次测评不要与oracle混淆。

exit_code=0
```
