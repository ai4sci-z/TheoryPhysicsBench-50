# qft-17 材料与验证划分

本题是固定公开实例，研究对象、查询、约定、输出schema、指标和约束反馈全部位于instruction与environment/public。不存在声称泛化却复用测试标签的开发划分。

参考解使用同一公开model.json和4CPU/4GiB/0GPU条件；私有truth.json由独立数值/符号路线离线构建，agent镜像只COPY environment/public，不包含solution、tests或作者脚本。课程quality_score.py原样复制。题目来源与原创扩展见provenance/qft-17.md。

同一场强构造，有限球采用24个径向中点直接求积。专家用适应性积分并与解析边界通量和径向积分交叉验证。

评分只检查提交JSON的物理结果，不要求代码文字相似；合法记录重排、独立真值结果均验过。类型、布尔值、NaN、巨大整数、缺字段、重复ID和错误物理值有独立检查。各类错误不转为基础设施故障；评分器本身异常保留供修复。
