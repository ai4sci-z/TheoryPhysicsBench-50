# 来源与本地改造

Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.12。

PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db

页码（PDF / 印刷）: [{"pdf": [66, 66], "printed": [64, 64], "role": "题面"}, {"pdf": [225, 231], "printed": [227, 233], "role": "解答"}]

原书工作：由幂计数及一圈费米子/标量两点、Yukawa三点和标量四点图，构造闭合的局域反项，包括费米盒图排列和耦合混合。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。
