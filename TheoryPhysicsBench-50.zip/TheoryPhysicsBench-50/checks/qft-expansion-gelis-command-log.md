
### 2026-11-16T17:42:40.312847+08:00

```bash
python3 -c 'from pathlib import Path; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); print(t[:18000])'
```

```text

===== PDF PAGE 1 =====


===== PDF PAGE 2 =====
To Kanako, Nathan and Simon.

===== PDF PAGE 3 =====
Reality is that which, when you stop believing in it, doesn’t go away.
PHILIP K. D ICK
How to build a universe that doesn’t fall apart two days later (1978)

===== PDF PAGE 4 =====
Contents
List of Figures and Tables x
Preface xii
Acknowledgements xiv
Notation and Conventions xv
1 Quantum Field Theory Basics 1
Introduction 1
1 Relationship between the Equations of Motion of φ and φin 11
2 Little-Group Elements for Massless Particles 12
3 S-matrix in Terms of φin and φout 15
4 Constraints on the S-matrix from Causality 17
5 Landau Equations for Soft and Collinear Singularities 22
6 Multi-loop Integration in D Dimensions 28
7 Weinberg Convergence Theorem 31
8 Electron Anomalous Magnetic Moment 34
9 Ward–Takahashi Identities and Lorentz Invariance 38
10 Equivalence Principle and Lorentz Invariance 41
11 Lee–Nauenberg Theorem 42
12 Classical External Field Approximation 49
13 Subleading Soft Radiation in Scalar QED 53
14 Low–Burnett–Kroll Theorem 57
15 Coherent States in Quantum Field Theory 62
16 Running Couplings in a Two-Field Scalar Field Theory 64

===== PDF PAGE 5 =====
viii CONTENTS
17 Solution of the Running Equation at Two Loops 68
2 Functional Methods 71
Introduction 71
18 Weyl Quantization 77
19 Combinatorial Interpretation of the Legendre Transform 79
20 Coherent State Path Integral 83
21 Coherent State Path Integral (Continued) 86
22 Spin Coherent States and the Berry Phase 90
23 Zeta Function Regularization of the Klein–Gordon Operator 101
24 Casimir Zero-Point Energy 103
25 The Feynman Diagrams behind the Casimir Force 106
26 Gross–Neveu Model 110
27 D’Hoker–Gagn´ e Formula 114
28 Stochastic Quantization 118
29 Complex Langevin Equation 123
3 Non-Abelian Fields 130
Introduction 130
30 Basic su(n) Identities 137
31 More su(n) Identities 138
32 More su(n) Identities (Continued) 140
33 An su(2) Identity 142
34 Area Derivative of a Wilson Loop 144
35 Endpoint Derivative of a Wilson Line 145
36 Makeenko–Migdal Loop Equation 148
37 Classical Non-Abelian Particles and the Wong Equations 151
38 Wong Equations from the Worldline Formalism 154
39 Non-Abelian Stokes’s Theorem 157
40 QED in the ’t Hooft–Veltman Gauge 162
41 LSZ Reduction Formula and Gauge Invariance 167
42 Large- N Expansion in SU(N) Yang–Mills Theory 171
43 Soft Radiation and Antenna Effects in QCD 175
44 An Identity Obeyed by On-Shell QCD Amplitudes 183
45 Low–Burnett–Kroll Theorem in QCD 184
46 Globally Gauge Invariant Operators 188
47 Banks–Zaks Fixed Points 191
48 Instantons and Tunneling in Quantum Mechanics 193
49 Instantons as Transitions between Pure Gauges in Yang–Mills Theory 196
50 Vacua of Yang–Mills Theory 199

===== PDF PAGE 6 =====
CONTENTS ix
4 Scattering Amplitudes 205
Introduction 205
51 Enumeration of Tree Graphs 212
52 Six-Point −−−+++ Amplitude 214
53 Two Spinor-Helicity Identities 216
54 Auxiliary Vector Dependence of the Polarization Vectors 218
55 Polarization Sum in the Spinor-Helicity Formalism 220
56 Photon Decoupling Identity 221
57 Scalar–Antiscalar–Gluon Amplitudes 223
58 Color Decomposition with a Quark–Antiquark Pair 226
59 Quark–Antiquark–Gluon Amplitudes 229
60 Quark–Antiquark–Gluon Amplitudes (Continued) 233
61 Gluon–Gluon Scattering in the Spinor-Helicity Framework 238
62 Soft Limit of Gluon Amplitudes 242
63 Collinear Limit of Gluon Amplitudes 247
64 Enumeration of One-Loop Graphs 252
65 Ultraviolet Finiteness of One-Loop All-Plus Amplitudes 258
66 Rationality of One-Loop All-Plus Amplitudes 259
67 One-Loop Four-Point ++++ Amplitude from Generalized Unitarity 261
68 One-Loop Five-Point +++++ Amplitude from Generalized Unitarity 267
5 Lattice, Finite T , Strong Fields 276
Introduction 276
69 Banks–Casher Relation 283
70 Nielsen–Ninomiya Theorem 285
71 Wigner Transform of a Convolution Product 290
72 Center Symmetry and Deconfinement 293
73 Photon Hard Thermal Loop from Classical Particles 297
74 Gluon Hard Thermal Loop from Colored Classical Particles 301
75 Landau–Pomeranchuk–Migdal Effect 305
76 Microcanonical Equilibration in φ4 Scalar Theory 312
77 Combinatorics of Multi-particle Production 315
78 Generating Functional for Particle Production 320
79 Correlations in the Schwinger Mechanism 324
80 Schwinger Mechanism from Bogoliubov Transformations 331
81 Unruh Effect, Hawking Radiation 339
82 Anderson Localization 347
83 Scaling Theory of Anderson Localization 350
Index 353

===== PDF PAGE 7 =====
Figures and Tables
Figures
1.1 Domains Ω1 andΩ2, withΩ2 under the causal inﬂuence ofΩ1.1 9
1.2 Domains Ω1,2, such thatΩ2 does not causally inﬂuenceΩ1.1 9
1.3 Space-like separated domains and their transformation under boosts. 20
1.4 One-loop example of application of the Landau equations. 26
1.5 The β function that controls the running of the ratioρ/λ.6 8
2.1 Notation for the angles of the spherical triangle (ˆnˆn′ˆn0).9 4
2.2 Geometrical interpretation of the Berry phase. 95
2.3 Derivation of the area of a spherical triangle. Triangulation of a pentagon by
three spherical triangles. 97
2.4 Triangulations of a sphere. 98
2.5 Deﬁnition of the angle θv at a vertexv of a triangulation. 99
2.6 Gauss mapping of a vertex of the triangulation of a surface. 100
2.7 Setup for the calculation of the Casimir energy. 104
2.8 Diagrams contributing to the free energy in the presence of two walls. 108
2.9 Moments obtained from the ﬁxed point of the Fokker–Planck equation. 126
3.1 Addition of a small appendix ~γ to a loopγ, at the base pointx. 144
3.2 Closed path γ with a self-intersection at the pointx. 150
3.3 Setup for the non-Abelian Stokes’s theorem. 158
3.4 Topological invariance of the Euler characteristic. 174
3.5 Polytopes with the Euler characteristic of a 2-sphere. 174
3.6 Euler characteristics of polytopes with faces removed. 175

===== PDF PAGE 8 =====
LIST OF FIGURES AND TABLES xi
3.7 Deformation of a polytope with two holes into a torus. 175
3.8 Allowed regions for soft gluon emission from a singlet dipole. 179
3.9 Sketch of a β function withβ0 <0 andβ1 >0 . 192
3.10 Double-well potential. Classical solution of the Euclidean time equation of
motion. 195
4.1 Contributions to the six-point color-ordered amplitude 1−2−3−4+5+6+. 215
4.2 Color-ordered amplitude with a quark–antiquark line. 227
4.3 Cuts of the one-loop four-point ++++ amplitude. 260
4.4 Color-ordered graphs contributing to the amplitude Ascalar4 (1+2+3+4+). 267
5.1 Two-dimensional vector ﬁelds with zeroes of index +1 and −1. 288
5.2 Illustration of the Poincar ´e–Hopf theorem in two dimensions. 289
5.3 Special vector ﬁeld used in the proof of the Poincar ´e–Hopf theorem. 290
5.4 Illustration of the Landau–Pomeranchuk–Migdal effect. Feynman graphs
contributing to the photon self-energy. 311
5.5 Phase-space evolution of an ensemble of classical ﬁelds. 315
5.6 Illustration of Rindler space. 341
5.7 β function for the conductance ind = 1,2,3 dimensions. 352
Tables
4.1 Number of graphs contributing to n-point tree amplitudes. 213
4.2 Couplings of a gluon to an on-shell quark–antiquark current. 231
4.3 Number of n-point one-loop graphs. 255
4.4 Number of n-gluon graphs with a ghost or quark loop. 256
4.5 Numbers of tree and one-loop n-gluon color-ordered graphs. 258

===== PDF PAGE 9 =====
Preface
This project grew out as an extension to my previous Quantum Field Theory book (hereafter
referred to as book I), in the form of an additional set of solved problems. The starting
observation was that most textbooks (and mine is no exception) have a general inclination
towards the exposition of the concepts, rather than the more practical aspects. This is of course
quite understandable for such a vast subject, where one needs to absorb a quite large volume
of concepts before becoming operational. The intended goal of the present book is to help ﬁll
the gap between theory and applications by providing a text almost exclusively geared towards
actual practice (but occasionally new concepts are also introduced).
The set of problems included in this book cover most of the subjects treated in book I,
and expose the reader to a broad variety of techniques. Occasionally, the same question is
addressed by various methods, in order to shed light on it from different perspectives. The
problems proposed in this set cover a broad range of difﬁculties and fall into several categories:
• More sophisticated and lengthier applications of the techniques and results of book I,
that are too long to be treated as examples in a textbook
• Problems that extend book I towards new topics and concepts that are too specialized to
ﬁt reasonably in a textbook
• Classic results of quantum ﬁeld theory (QFT) presented in a more modern fashion and
with uniform notation, with the goal of making them more accessible than from a reading
of the original literature
• More recent results, presented in a way that is accessible to the readers of book I; these
are meant to be a bridge between the material of a typical textbook and contemporary
research articles.
When deciding which problems to include in this collection, I made the deliberate choice to
keep almost exclusively problems that can be worked out analytically “by hand” in a reasonable
amount of time. Occasionally, straightforward but tedious calculations have been avoided by
the use of a computer algebra system (for these problems, PYTHON notebooks will be provided
as a separate online resource). This prejudice is of course an important limitation since these

===== PDF PAGE 10 =====
PREFACE xiii
computer tools are a common aid in contemporary theoretical research, but my impression is
that the didactical virtue of working out simpler problems by hand is higher.
Although this book has an obvious lineage with book I (e.g., the two books share the
same notation), a signiﬁcant effort has been made to ensure that it is self-contained and can
be used on its own. Each chapter starts with a reminder of the important concepts and tools
relevant for the problems of that chapter, but an important word of caution is in order here:
these introductions are meant to be a concise refresher for a reader who has already studied the
corresponding subjects, but they are not an appropriate source for learning a subject for the ﬁrst
time. This book is also self-contained by the inclusion of detailed solutions to all the problems.
When necessary, a quick exposition of some relevant mathematical tools is included in the
solutions, to avoid a detour via a mathematical textbook (this is intended to give plausibility
to a given mathematical statement, not to provide a thorough and rigorous description of the
underlying mathematics).
The intended readership of this book is of course primarily students who are in the process
of learning quantum ﬁeld theory, as well as their instructors. Roughly speaking, Chapters
1 and 2 cover the topics one would usually learn in a ﬁrst QFT course. Chapter 3, on non-
Abelian gauge theories, tends to be a bit more advanced and is often treated in a second course.
Chapters 4 and 5 deal with more specialized subjects, respectively the newly developed tools
for calculating scattering amplitudes, and aspects of quantum ﬁeld theory that are on the border
of many-body physics. Hopefully, more experienced readers will also ﬁnd the book useful,
both for the discussion of these more advanced topics and for a more modern treatment of
some classic QFT results.

===== PDF PAGE 11 =====
Notation and Conventions
We list here some notation and conventions that are used throughout this book:
• c = 1 : length = time, energy = momentum = mass
•¯h = 1 : momentum = wavenumber, energy = frequency
• pμ ≡ (p0,p) : 4-momentum; p : three-dimensional spatial components
• Ep ≡
√
p2 +m2 : positive on-shell energy of a particle of momentum p and massm
• L : Lagrangian density (more rarely, the Lagrangian itself)
• H : Hamiltonian; S : action
• μ,ν,ρ,σ,... (more rarelyα,β,γ,... ): Lorentz indices in Minkowski space
• i,j,k,l,... : Lorentz indices in Euclidean space
• a,b,c,d,... : group indices in the adjoint representation
• i,j,k,l,... : group indices in the fundamental representation
• ϵμνρ··· : Levi–Civita symbol. In situations where it makes sense to raise or lower the
indices (e.g., for Lorentz indices in Minkowski space), the normalization convention is
with lowered indices,ϵ012··· =+ 1
• The normalization of creation and annihilation operators is deﬁned so that the canonical
commutation relation reads [ap,a†q]=( 2π)32Epδ(p −q) (except in Problems 80 and
81, where it is convenient to omit the factor2Ep). Their dimension is (mass)−1.

===== PDF PAGE 12 =====


===== PDF PAGE 13 =====
CHAPTER 1
Quantum Field Theory Basics
Introduction
This chapter is devoted to basic aspects of quantum ﬁeld theory, ranging from the foundations to
perturbation theory and renormalization, and is limited to the canonical formalism (functional
methods are treated in Chapter 2) and to the traditional workﬂow (Lagrangian→ Feynman rules
→ time-ordered products of ﬁelds → scattering amplitudes) for the calculation of scattering
amplitudes (the spinor-helicity formalism and on-shell recursion are considered in Chapter
4). The problems of this chapter deal with questions in scalar ﬁeld theory and quantum
electrodynamics, while non-Abelian gauge theories are discussed in Chapter 3.
Non-interacting Field Theory
A non-interacting ﬁeld theory may be deﬁned by a quadratic Lagrangian. In the simplest case
of a scalar ﬁeld theory, it reads
L ≡
∫
d3x {12(∂μφ)(∂μφ)− 12m2φ2}. (1.1)
Such a Lagrangian deﬁnes a dynamical system with inﬁnitely many degrees of freedom, corre-
sponding to the values taken byφ(x) at every pointx of space. The momentum canonically
conjugate toφ(x) is given by
Π(x) ≡ ∂L∂(∂0φ(x)) = ∂0φ(x), (1.2)
which leads to the Hamiltonian
H ≡
∫
d3x Π(x)∂0φ(x)− L =
∫
d3x {12Π2 + 12(∇φ)2 + 12m2φ2}. (1.3)

===== PDF PAGE 14 =====
2 1 QUANTUM FIELD THEORY BASICS
From the Hamiltonian or Lagrangian, one obtains the equation of motion of the ﬁeld, which in
the present example reads
(
□x +m2)φ(x)= 0, (1.4)
known as the Klein–Gordon equation . Generic real solutions of this linear equation are
superpositions of plane waves:
φ(x)=
∫ d3k
(2π)32Ek
{
α∗k e−ik·x +αk eik·x
}
, (1.5)
where Ek ≡
√
p2 +m2 is the dispersion relation associated with the wave equation (1.4),
andαk is a function of momentum that depends on the boundary conditions imposed on the
solution.
Canonical quantization consists in promoting the coefﬁcientsαk,α∗k into annihilation and
creation operatorsak,a†k that obey the following commutation relations:
[
ap,a†q] ≡ (2π)32Ep δ(p −q). (1.6)
The normalization in Eqs. (1.5) and (1.6) is chosen so that
[
H,a†p] = Epa†p and[H,ap] =
−Epap, which means thata†p increases the energy of the system byEp whileap decreases it
by the same amount. As a consequence, this setup describes a collection of non-interacting
particles. The commutation relation (1.6) implies the following equal-time commutation
relation between the ﬁeld operator and its conjugate momentum:
[
φ(x),Π (y)
]
=
x0=y0
iδ (x −y), (1.7)
which one may view as the quantum version of the classical Poisson bracket between a
coordinate and its conjugate momentum.
Interacting Field Theory and Interaction Representation
Interactions are introduced via terms of degree higher than two in the Lagrangian:
L ≡
∫
d3x { 12(∂μφ)(∂μφ)− 12m2φ2/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
L0, non-interacting theory
−V(φ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
interactions
}
. (1.8)
(In order to have a causal theory, the potentialV(φ) must be a local function of the ﬁeld φ(x);
see Problem 4.) In the presence of interactions, the Klein–Gordon equation of motion becomes
(
□x +m2)φ(x)+ V′(φ(x)) = 0. (1.9)
Since the degree ofV(φ) is higher than two, this equation is non-linear, which induces a mixing
between the Fourier modes of the ﬁeld and prevents writing its solutions as superpositions of
plane waves.
By assuming that the interactions are turned off at large times, x0 → ±∞, we may
deﬁne free ﬁelds φin and φout that coincide with the interacting ﬁeld φ of the Heisenberg

===== PDF PAGE 15 =====
INTRODUCTION 3
representation, respectively when x0 → −∞ and x0 → +∞. For instance, φ and φin are
related by
φ(x)= U(−∞,x0)φin(x)U(x0, −∞),
U(t2,t1) ≡ Te x p
(
−i
∫t2
t1
dx0d3x V(φin(x))
)
. (1.10)
In this representation, the time dependence of the ﬁeldφ(x) is split into a trivial one that comes
from the free ﬁeld φin and the time evolution operator U that depends on the interactions.
Since they are free ﬁelds obeying Eq. (1.4),φin andφout can be written as superpositions of
plane waves, with coefﬁcients ap,in,a†p,in and ap,out,a†p,out, respectively. These two sets of
creation and annihilation operators deﬁne two towers of Fock states, i.e., states with a deﬁnite
particle content atx0 =− ∞ andx0 =+ ∞, respectively.
Lehmann–Symanzik–Zimmermann Reduction Formulas
Experimentally measurable quantities, such as cross-sections, may be related to correlation
functions of the ﬁeld operator as follows. An intermediate step involves the transition ampli-
tudes between in and out states,
⟨
q1 ··· qnout
⏐⏐p1 ··· pmin⟩ ≡ (2π)4δ( ∑
i
pi −
∑
j
qj
)
T(q1···n|p1···m), (1.11)
in terms of which a cross-section in the center of momentum frame is given by
σ12→1···n
⏐⏐⏐ center of
momentum
= 14√s|p1| ∫ dΓn(p1,2)⏐⏐⏐T(q1,···,n|p1,2)⏐⏐⏐2, (1.12)
with dΓn(p1,2) ≡
∏
j
d3qj
(2π)32Eqj (2π)4δ(p1 +p2 − ∑j qj),s ≡ (p1 +p2)2.
In turn, the transition amplitudes from in to out states are expressed in terms of expectation
values of time-ordered products of ﬁeld operators by the Lehmann–Symanzik–Zimmermann
(LSZ) reduction formulas:
⟨
q1 ··· qn out
⏐⏐p1 ··· pm in⟩ = im+n
Z
m+n
2
∫ m∏
i=1
d4xj e−ipi·xi (□xi +m2)
×
∫ n∏
j=1
d4yj eiqj·yj (□yj +m2)⟨0out⏐⏐Tφ(x1)··· φ(xm)φ(y1)··· φ(yn)⏐⏐0in⟩, (1.13)
whereZ is the wavefunction renormalization factor.
Generating Functional, Feynman Propagator


exit_code=0
```

### 2026-11-16T17:43:12.195713+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); pages={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; ranges=[(34,39),(54,60),(281,285),(294,300)]; [(print("\nPDF PAGE",i,"\n",pages[i])) for a,b in ranges for i in range(a,b+1)]'
```

```text

PDF PAGE 34 
 22 1 QUANTUM FIELD THEORY BASICS
use of (1.41). It is straightforward to check that
δ
δλ(y)
(
δS[λ]
δλ(x) S†[λ]
)
= S2(x,y )+ S1(x)S†1(y)+ O(λ).
Therefore, at lowest order, (1.41) tells us that
S2(x,y )=− S1(x)S†1(y)= S1(x)S1(y) ify is not in the future light-cone ofx.
Using the fact thatS2(x,y ) should be symmetric, we also have
S2(x,y )= S2(y,x )= S1(y)S1(x) ifx is not in the future light-cone ofy.
(Note that these two conditions onx,y are both satisﬁed if their separation is space-like. For
such a space-like separation, we could thus use either of the two formulas. This does not
lead to any contradiction, provided thatS1(x) is a local function of the ﬁeld operator and its
derivatives.) Therefore, the answer valid for anyx,y can be written as
S2(x,y )= T (S1(x),S1(y)).
(One may check a posteriori that the unitarity constraint is satisﬁed.) Using the same constraints,
one could show by induction that the coefﬁcient of ordern,Sn(x1,...,x n), is the time-ordered
product ofn factorsS1. Therefore, we see that unitarity and causality provide an almost closed
form for theS-matrix,
S[λ]= Te x p
( ∫
d4xS 1(x)λ(x)),
in which the only remaining unknown is the ﬁrst coefﬁcientS1(x). The latter can be related to
the interaction Lagrangian by considering aλ(x) which is non-zero in an inﬁnitesimal region
of spacetime. Therefore, regardless of the microscopic details of a given theory – which control
the ﬁrst coefﬁcientS1 –, the general structure of theS-matrix is governed to a large extent by
the constraints provided by unitarity and causality.
5. Landau Equations for Soft and Collinear Singularities The goal of this problem is to
study the singularities that may occur in a Feynman integral due to vanishing denominators
(not to be confused with ultraviolet divergences, due to an integrand that decreases too slowly
at large momentum). Consider a Feynman integral with L loops andm denominators:
I({pi}) ≡
∫ L∏
j=1
dD𝓁j
(2π)D
N({pi},{𝓁j})
(q21 −m21 +i0+)··· (q2m −m2m +i0+).
In this integral, the pi are the external momenta, the 𝓁j the loop momenta, and the qr the
momenta of the propagators in the loops, i.e., linear combinations of loop momenta and
external momenta of the formqr ≡ ∑Lj=1 ϵrj𝓁j +Δr (where the coefﬁcientsϵrj take values in
{−1,0, +1} and theΔr depend only on the external momenta).


PDF PAGE 35 
 5 LANDAU EQUATIONS FOR SOFT AND COLLINEAR SINGULARITIES 23
5.a Use Feynman parametersxr to combine them denominators into a single one,Dm.
5.b By considering the following elementary examples,
∫ +1
−1
dx
x +i0+,
∫ +1
0
dx
x +i0+,
∫ +1
−1
dx
(x +i0+)(x −i0+),
explain why singularities occur only when a pole is located on the boundary of the
integration manifold, or when multiple poles “pinch” the integration manifold.
5.c Study the variations of D as a function of the loop momenta 𝓁j, and explain why the
zeroes of D must also be extrema ofD in order to produce singularities.
5.d Now study the dependence with respect to the Feynman parameters and show that, for
eachr, one must have eitherxr = 0 orq2r = m2r in order to have a singularity.
5.e Conclude that the conditions for a singularity are given by the Landau equations:
For each propagatorr: xr(q2r −m2r )= 0; For each loopj:
m∑
r=1
ϵrjxrqμr = 0.
5.f Determine the singularities of the one-loop
Feynman diagram shown on the right (assume
k2 = k′2 = 0, (k +k′)2 >0 and all internal
particles are massless)
q2
q1=𝓁
q3
k
k'
k+k'
5.a Consider a Feynman integral withL loops and m denominators. Generically, such an
integral may be written as
I({pi}) ≡
∫ L∏
j=1
dD𝓁j
(2π)D
N({pi},{𝓁j})
(q21 −m21 +i0+)··· (q2m −m2m +i0+),
where thepi are the momenta external to the loops and the𝓁j areL independent loop momenta.
The momentaqr are the momenta carried by the various propagators along the loops. They are
all of the form
qr ≡
L∑
j=1
ϵrj𝓁j +Δr,
where the coefﬁcientsϵrj take values in{−1,0, +1} (a propagator may belong to a loop or not,
and may be oriented in the same way as the loop momentum or in the opposite direction) and
where the Δr depend only on the external momenta (they are thus constants from the point
of view of evaluating the loop integrals). N({pi},{𝓁j}) is a numerator that comprises all the
momentum dependence that may arise, e.g., from three-gluon vertices in QCD or from the
Dirac traces if there are fermion loops. This factor plays no role in analyzing the singularities of


PDF PAGE 36 
 24 1 QUANTUM FIELD THEORY BASICS
the integral, except in those rare situations where a singularity due to a vanishing denominator
may be canceled by an accidental concomitant vanishing of the numerator.
The ﬁrst step is to combine the m denominators into a single one thanks to Feynman
parameterization:
I({pi})= Γ (m)
∫ L∏
j=1
dD𝓁j
(2π)D
∫
xr≥0
m∏
r=1
dxr δ
(
1−
∑
r
xr
) N({pi},{𝓁j})(
D({qr},{xr})+i0+)m, (1.42)
D({qr},{xr}) ≡
m∑
r=1
xr(q2r −m2r ).
5.b In this problem, we assume that the ultraviolet divergences have been properly disposed of
by some regularization, and we are chieﬂy interested in the possibility of additional singularities
that may arise from a vanishing denominator. Obviously, that the equation
D({qr},{xr})= 0
has solutions in the integration domain is a necessary condition for having such singularities.
But a zero of the denominator of the integrand does not always lead to a singularity in the
integral. In order to see this, let us consider the following toy examples:
∫ +1
−1
dx
x +i0+ =
∫ +1
−1
dx
(
P
(1
x
)
−iπδ (x)
)
=− iπ,
∫ +1
0
dx
x +i0+ = ∞,
∫ +1
−1
dx
(x +i0+)(x −i0+) = limε→0+
∫ +1
−1
dx
x2 +ε2 = ∞.
In the ﬁrst example, the integral is ﬁnite despite the fact that denominator vanishes atx = 0,
because the integration contour is slightly shifted from the singularity by the presence of the
i0+. An inﬁnite result would be obtained when it is impossible to shift the contour to avoid
the pole. In the second example, we cannot avoid the singularity because the pole occurs on
the boundary (here, at an endpoint) of the integration domain. In the third example, there are
two poles in the interior of the integration range, but these poles pinch the integration contour,
which prevents moving the contour to avoid the poles and also leads to an inﬁnite result.
5.c Although the conditions of occurrence of a genuine singularity are the same, the situ-
ation we have to analyze is arguably more complex than these toy examples because of the
multivariate nature of the denominator. For a multi-dimension integral, the above condition is
that the poles of the integrand cannot be avoided by deforming the integration manifold. We
can make the following observations:
• Note ﬁrst that the fact thatD is raised to them-th power in (1.42) is irrelevant for this
discussion: every zero of D leads to a pole of order m of the integrand, but this is
equivalent to having m poles all on the same side of the integration domain, so this
cannot produce a pinch.


PDF PAGE 37 
 5 LANDAU EQUATIONS FOR SOFT AND COLLINEAR SINGULARITIES 25
• For theL loop momenta𝓁j, the integration domain is R DL. We may add to this domain
a point at inﬁnity (assuming an ultraviolet regularization, the integrand goes to zero in
all directions at inﬁnity), which leads to an integration domain topologically equivalent
to aDL-dimensional sphereSDL . This domain is boundaryless and therefore the only
possibility of singularities when integrating over the loop momenta is to have a pinch.
• For the Feynman parameters xr, the integration domain is a (m − 1)-dimensional
simplex,
{
(x1,...,x m)
⏐⏐⏐xr ≥ 0, ∑
r
xr = 1
}
,
i.e., a line segment for m = 2, a triangle for m = 3, a tetrahedron for m = 4, etc.
Clearly, this domain has a boundary and therefore endpoint singularities may occur.
Let us now study the behavior of the denominator D. This function is quadratic in the loop
momenta, and linear in the Feynman parameters. Note also that, after a Wick rotation of the
loop momenta, D is a negative deﬁnite quadratic form in the Euclidean loop momenta, at ﬁxed
{xr} (this is obvious from the fact that the second-degree part ofD is a sum of squares weighted
by the negative coefﬁcients −xr). Therefore, when varying the loop momenta at ﬁxed {xr}, the
denominatorD has a maximum. We can distinguish the following cases:
• If max{𝓁j}(D) <0 , the denominator is always non-zero and there is no singularity.
• If max{𝓁j}(D) >0 , the denominator can vanish, but the zeroes are simple zeroes that
cannot pinch the integration manifold for the variables{𝓁j}. The integral is also ﬁnite in
this case.
• The dangerous situation is when max{𝓁j}(D)= 0, because the location of the maximum
is then a double zero (as in the third of the toy examples considered earlier) in all the 𝓁μj
variables.
Therefore, we are seeking zeroes of D that are also extrema of its dependence with respect to
all the loop momenta:
D = 0, ∂D∂𝓁μj = 0.
Note that these conditions are still not sufﬁcient for a genuine singularity since we have only
discussed what happens at ﬁxed {xr}, and we have not yet analyzed whether it may be avoided
by a deformation of the integration domain for thexr’s. This discussion can be divided into
two cases:
• First, note that if q2r ⁄= m2r , a small variation ofxr will change the value ofD and move
the denominator away from zero. For xr in the interior of its allowed range, this means
that there is no actual singularity. The only exception is atxr = 0, since this is on the
boundary of the integration range.
• In contrast, when q2r = m2r , the denominator D is independent of xr, and a zero of D
persists at all values ofxr.


PDF PAGE 38 
 26 1 QUANTUM FIELD THEORY BASICS
q2
q1=𝓁
q3
k
k'
k+k'
Figure 1.4 One-loop example of application of the Landau equations.
5.d We now have all the information to give the conditions of occurrence of a singularity in
the Feynman integralI({pi}):
D = 0, ∂D∂𝓁μj = 0; for eachr, eitherxr = 0 orq2r = m2r.
(Note that the last condition can be phrased as xr(q2r − m2r )= 0 for each r, which makes
the ﬁrst one, D = 0, redundant.) These conditions are known as the Landau equations.B y
explicitly evaluating the derivative of the denominator with respect to the loop momenta, these
conditions can be written as
for each propagatorr: xr(q2r −m2r )= 0; for each loopj:
m∑
r=1
ϵrjxrqμr = 0.
5.e Consider now the example of Figure 1.4. The corresponding Landau equations read
x1𝓁2 = x2(𝓁 +k′)2 = x3(𝓁 −k)2 = 0, x 1𝓁μ +x2(𝓁μ +k′μ)+ x3(𝓁μ −kμ)= 0.
A ﬁrst solution is obtained for
𝓁2 =( 𝓁 −k)2 = 0, x 2 = 0, x 1𝓁μ +x3(𝓁μ −kμ)= 0,
which (since we have assumed thatk2 = 0) is equivalent to
𝓁2 = k2 = 𝓁·k = 0, 𝓁 μ = x3
x1 +x3
kμ.
This type of singularity is called a collinear singularity, since it occurs when the loop momen-
tum is aligned with one of the external momenta. A similar type of singularity is obtained at
x3 = 0, i.e.,
𝓁2 = k′2 = 𝓁·k′ = 0, 𝓁 μ =− x2
x1 +x2
k
′μ.
Another way to fulﬁll the Landau equations is to have 𝓁μ ≪ kμ,k′μ. In this limit, the ﬁrst
three conditions are automatically satisﬁed, and the last one becomes x2k
′μ = x3kμ. Since kμ
andk
′μ are a priori not collinear, this implies thatx2 = x3 = 0. This last type of singularity
is called a soft or infrared singularity, since it occurs when all the components of the loop
momentum go to zero.


PDF PAGE 39 
 5 LANDAU EQUATIONS FOR SOFT AND COLLINEAR SINGULARITIES 27
Coleman–Norton Interpretation: A more intuitive physical interpretation of the Landau
equations was found by Coleman and Norton (see Coleman, S. and Norton, R. E. (1965),
Nuovo Cimento 38: 438). They propose to interpret a Feynman graph literally, as if the
graph represents a process in spacetime, with the vertices being the locations where some
instantaneous interactions happen. They further propose that the spacetime separation dxμr
between two vertices is parallel to the momentum qμr , and proportional to the Feynman
parameterxr:
dxμr = xrqμr.
(The constant of proportionality could be different from 1, but should be the same for all
propagators. Its value is not important, as one may freely rescale the entire diagram without
affecting the Landau equations.) Based on this identiﬁcation, one may make the following
observations:
• If a singularity happens atxr = 0, the spacetime separation is zero, and we may shrink
the corresponding propagator to a point. The resulting graph is called a reduced graph.
A similar reduction is possible ifqμr = 0, in the case of a soft divergence.
• Ifxr ⁄= 0, the Landau equations tell us that we should haveq2r = m2r instead. Thus, in
this interpretation, the propagators of a reduced graph represent the on-shell propagation
of a particle between two interactions. In this case, we may also write
xr = dx0rq0r ,d x μr = dx0r qμrq0r , i.e., dxμrdx0r = qμrq0r = vμr,
wherevμr is the4-velocity of an on-shell particle of momentumqμr .
• The last of the Landau equations becomes
∑
r
ϵrj dxμr = 0, for every loopj.
This equation is consistent with dxμr being a separation in spacetime, since adding these
separations along a closed loop should obviously give zero. This also implies that the
spacetime separation between two vertices does not depend on which path we follow on
the graph to connect them, as it should for this interpretation to make sense.
As an illustration, let us show the reduced diagrams for the three singularities we have found
for the triangle one-loop graph studied above:
𝓁
𝓁−k
k
k'
𝓁
𝓁+k'
k
k'
k
k'
In more complicated cases, where solving the Landau equations may be difﬁcult, the Coleman–
Norton interpretation and the associated reduced diagrams can be used as guidance for identi-
fying the possible solutions. This is based on the fact that there is a one-to-one correspondence


PDF PAGE 54 
 42 1 QUANTUM FIELD THEORY BASICS
from the propagators of the other external lines (fermions, scalars, etc.). Therefore, (1.50)
becomes
Mμν(k;p1,...,p n)=k→0 M(p1,...,p n)
n∑
i=1
gi pμi pνi
pi ·k , (1.52)
wheregi is the strength of the coupling of a soft graviton to the particle on thei-th external
line.
10.b Thanks to Eq. (1.51) and the results of Problem 9, the Lorentz transform of the polar-
ization tensor of a graviton is given by
[
Λ−1]μρ[Λ−1]νσ ϵρ±(Λk)ϵσ±(Λk)= e∓2iθ ϵμ±(k)ϵν±(k)
+ terms inkμϵν±,ϵμ±kν orkμkν.
Then, the reasoning of Problem 9 indicates that S-matrix elements with external gravitons
are Lorentz invariant (up to a phase), provided that the corresponding amplitude satisﬁes the
following identities:
kμ Mμν(k,... )= kν Mμν(k,... )= 0.
Specializing to the case where the graviton is soft and all other external lines are hard, we can
use (1.52), and this becomes
n∑
i=1
gipνi = 0. (1.53)
This identity must be true for any allowed conﬁguration of the momentapi of the hard external
lines. Obviously, this holds if we have gi = const (the identity then follows from energy–
momentum conservation). This corresponds to the situation where soft gravitons couple to all
other ﬁelds with the same strength, i.e., to the equivalence principle. Thus, we have shown that
the equivalence principle implies the Lorentz invariance of cross-sections involving gravitons.
As in Problem 9, the converse is also true. Indeed, g = const is the only way to satisfy
(1.53) for allpi. Therefore, the Lorentz invariance of cross-sections with soft external gravitons
implies the equivalence principle for long-distance gravitational interactions. (Here, “long-
distance” should be understood as long compared to the other distance scales of the process,
but certainly short compared to the size of the Universe, since translation invariance does not
hold on such large scales.) This observation was ﬁrst made by Weinberg (see Weinberg, S.
(1964), Phys Rev 135: 1049).
Higher Spins: This argument can be extended in order to exclude the possibility of inter-
acting higher-spin massless particles. For instance, for a spin- 3 massless particle, Lorentz
invariance would imply
n∑
i=1
gi pμi pνi = 0.
One may check that the only way this can be true for all pi’s and allμ,ν is to have gi = 0.
(But interacting massive spin-3 particles fall out of the scope of this argument, and are in fact
allowed.)


PDF PAGE 55 
 11 LEE–NAUENBERG THEOREM 43
11. Lee–Nauenberg Theorem In quantum mechanics and quantum ﬁeld theory, there exist
states that are practically undistinguishable (e.g., states that differ by features that are too dim to
be experimentally detected). Transition amplitudes with such initial or ﬁnal states are in general
plagued by singularities. The goal of this problem is to discuss these pathologies in the simple
setting of quantum mechanics, and to show that they can be avoided by averaging transition
probabilities over all degenerate states. To that end, consider a Hamiltonian H = H0 +V
decomposed into a free Hamiltonian H0 and an interaction potential V. We recall that the
scattering matrixS can be written as
Sβα = δβα −2πiδ (Eα −Eβ)Tβα,
withTβα ≡ Vβα +
∫
dγ VβγTγα
Eα −Eγ +i0+,V βα ≡
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψ(0)α ⟩,
where theEα’s and
⏐⏐Ψ(0)α ⟩’s are the eigenvalues and eigenstates ofH0.
11.a Show that
(
Ωin
)
βα ≡ δβα + TβαEα−Eβ+i0+ is a unitary matrix. Hint: deﬁne ⏐⏐Ψα,in⟩ ≡∫
dγ
(
Ωtin)αγ⏐⏐Ψ(0)γ ⟩ and consider the matrix element ⟨Ψβ,in⏐⏐V⏐⏐Ψα,in⟩.
11.b Solve formally the equation forTβα, to obtain
Tβα = Vβα +
+∞∑
n=1
∫
dγ1 ··· dγn
VβγnVγnγn−1 ··· Vγ1α
(Eα −Eγ1 +i0+)··· (Eα −Eγn +i0+).
11.c Denote byD(α) the set of states obtained fromα by adding/removing ultrasoft particles,
by splitting collinearly hard massless particles or by recombining collinear particles,
i.e., the set of states that are undistinguishable from the stateα. Explain why Tβα has
divergences if γ1,γ2,...,γ i all belong to D(α) or if γi,γi+1,...,γ n all belong to
D(β).
11.d IntroducePα,Pβ,P3, the projectors on D(α),D(β) and on the rest of the Hilbert space,
respectively. Show that squared matrix elements ofT become ﬁnite if they are summed
over all the states inD(α) andD(β), i.e., ∑
a∈D(α),b∈D(β)
⏐⏐Tba⏐⏐2 < ∞.
Reminders on Scattering Theory in Quantum Mechanics: The setting of this study is the
formulation of scattering in quantum mechanics. Let us consider a Hamiltonian H, which we
decompose into a free Hamiltonian and an interaction potential:
H = H0 +V.
Denote by
⏐⏐Ψ(0)α ⟩ the eigenstates of the free Hamiltonian,


PDF PAGE 56 
 44 1 QUANTUM FIELD THEORY BASICS
H0
⏐⏐Ψ(0)α ⟩ = Eα⏐⏐Ψ(0)α ⟩,
and by
⏐⏐Ψα⟩ those of the full Hamiltonian,
H
⏐⏐Ψα⟩ = Eα⏐⏐Ψα⟩.
The eigenvalues of the free and interacting Hamiltonians are the same, provided we disregard
the formation of bound states that may happen with certain interactions, and provided the free
Hamiltonian is expressed in terms of the physical masses of the particles. The last equation
may be rewritten as
(Eα −H0)
⏐⏐Ψα⟩ = V⏐⏐Ψα⟩. (1.54)
Note that the operatorEα −H0 is not invertible, since
⏐⏐Ψ(0)α ⟩ lies in its kernel (as well as any
other state degenerate with it). Consider the following states:
⏐⏐Ψα,in⟩ ≡⏐⏐Ψ(0)α ⟩ +(Eα −H0 +i0+)−1 V⏐⏐Ψα,in⟩,⏐⏐Ψα,out⟩ ≡⏐⏐Ψ(0)α ⟩ +(Eα −H0 −i0+)−1 V⏐⏐Ψα,out⟩.
These states are obviously solutions of (1.54). These states are time-independent (i.e., they are
states in the Heisenberg representation), but may look different to observers in different frames.
In particular, in a frame that differs by a translation by a timeT, these states are multiplied by
e−iHT . Since they are energy eigenstates, the action of this operator is just a multiplication by
an irrelevant phase exp(−iEαT ). But these phases have a non-trivial effect on superpositions
of states. Consider, for instance,
⏐⏐Ψh,in⟩ ≡ ∫ dα h(α)⏐⏐Ψα,in⟩
(the notationdα is a shorthand for the integration/summation measure over all the quantum
numbers of the particles in the stateα, such as3-momenta, spins, etc.), whereh(α) is a smooth
function that spans a small range of energiesEα. Under such a translation in time, this state
becomes
⏐⏐Ψh,in⟩ →⏐⏐Ψh,in⟩T = ∫ dα h(α) e−iEαT ⏐⏐Ψα,in⟩
= e−iH0T ⏐⏐Ψ(0)h ⟩+∫ dαh (α) e−iEαT(Eα −H0 +i0+)−1 V⏐⏐Ψα,in⟩.
(1.55)
In the second term, we must close the contour for the integral over the energyEα in the upper
half-plane in order to ensure its convergence if T<0 . Then, the theorem of residues gives
the integral in terms of the singularities of the integrand. Except for the denominator, the
other factors generically have their singularities at ﬁnite imaginary part, Im (Eα) >0 (because
interactions typically lead to a ﬁnite lifetime for the particles), and their contribution vanishes
whenT → −∞. The denominator leads to poles located at Eα = E∗ −i0+, i.e., below the real
axis, and therefore it does not contribute to the result. Thus, we have
e−iHT ⏐⏐Ψh,in⟩ =T →−∞ e−iH0T ⏐⏐Ψ(0)h ⟩,e −iHT ⏐⏐Ψh,out⟩ =T →+∞ e−iH0T ⏐⏐Ψ(0)h ⟩.
Note that, since the operators exp(−iHT ) and exp(−iH0T ) are unitary, the states
⏐⏐Ψh,in⟩ and⏐⏐Ψh,out⟩ are normalized like the states ⏐⏐Ψ(0)h ⟩. Since this is true for any function h(α), the


PDF PAGE 57 
 11 LEE–NAUENBERG THEOREM 45
states
⏐⏐Ψα,in⟩ and⏐⏐Ψα,out⟩ each form an orthonormal set of states. In other words, the in and
out states become identical to the eigenstates of the free Hamiltonian in frames translated by
a time T → −∞ or T → +∞, respectively. Thus, the physical interpretation of the (time-
independent) state
⏐⏐Ψα,in⟩ is that it encodes all the possible outcomes of an interacting system
initialized at T =− ∞ in the free state
⏐⏐Ψ(0)α ⟩. Likewise, ⏐⏐Ψα,out⟩ encodes all the possible
histories that lead to the free state
⏐⏐Ψ(0)α ⟩ atT =+ ∞. Therefore, the transition amplitude from
a stateα to a stateβ should be deﬁned as
Sβα ≡
⟨
Ψβ,out
⏐⏐Ψα,in⟩.
Note that the deﬁnition of the state
⏐⏐Ψα,in⟩ can be rewritten as
⏐⏐Ψα,in⟩ = ∫ dβ(δβα + TβαEα −Eβ +i0+/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ Ωβα
)⏐⏐Ψ(0)β ⟩, withTβα ≡⟨Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩
(δβα is the combination of delta functions and Kronecker symbols such that
∫
dβf (β)δβα =
f(α)). Inserting the deﬁnition of
⏐⏐Ψα,in⟩ inTβα, we obtain an integral equation forT:
Tβα = Vβα +
∫
dγ VβγTγα
Eα −Eγ +i0+ =
∫
dγ Vβγ Ωγα, (1.56)
withVβα ≡
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψ(0)α ⟩. This equation, known as the Lipmann–Schwinger equation, shows
how the matrix elements ofT are obtained from the matrix elements of the interaction potential
in the free basis.
11.a Given the above discussion, we have
⏐⏐Ψα,in⟩ =T →−∞ eiHT e−iH0T ⏐⏐Ψ(0)α ⟩,
which implies thatΩβα = limT →−∞
⟨
Ψ(0)β ⏐⏐eiHT e−iH0T⏐⏐Ψ(0)α ⟩. In this form, we see immedi-
ately that theΩβα’s are the matrix elements of a unitary operator.
Alternatively, we can reach the same conclusion using only the information provided in
the statement of the problem. For this, it is convenient to write
Ω ≡ 1 +Δ, T βα =( Eα −Eβ +i0+)Δβα,
⏐⏐Ψα,in⟩ =⏐⏐Ψ(0)α ⟩ + ∫ dγΔtαγ⏐⏐Ψ(0)γ ⟩ (Δtαγ ≡ Δγα).
Given the integral equation that relatesVβα andTβα and the deﬁnition of
⏐⏐Ψα,in⟩, we have also
Tβα =
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩.
Then, the matrix element
⟨
Ψβ,in
⏐⏐V⏐⏐Ψα,in⟩ can be written in two ways, depending on whether


PDF PAGE 58 
 46 1 QUANTUM FIELD THEORY BASICS
we expand the state on the left or the state on the right:
⟨
Ψβ,in
⏐⏐V⏐⏐Ψα,in⟩ =⟨Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Tβα
+
∫
dγΔ†βγ ⟨Ψ(0)γ ⏐⏐V⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Tγα
=
⟨
Ψβ,in
⏐⏐V⏐⏐Ψ(0)α ⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
T∗αβ
+
∫
dγ
⟨
Ψβ,in
⏐⏐V⏐⏐Ψ(0)γ ⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
T∗γβ=T†βγ
Δγα.
Equating these two expressions for the matrix element leads to
T∗αβ −Tβα =
∫
dγ
(
Δ†βγTγα −T†βγΔγα
)
=( Eα −Eβ +i0+)
∫
dγ Δ†βγΔγα,
i.e.,Δ +Δ† +Δ†Δ = 0. From this relationship, we conclude that Ω = 1 +Δ is unitary.
S-matrix: The matrix element Sβα can also be expressed in terms of Tβα. In order to obtain
this relationship, let us start again from (1.55), but this time we take the limit T → +∞. Since
T>0 , we must close the integration contour in the lower half-plane. In the limit T → +∞,
the only term that survives when we apply the theorem of residues comes from the zero in the
denominator, and we get
⏐⏐Ψh,in⟩T =T →+∞ e−iH0T ⏐⏐Ψ(0)h ⟩ −2πi ∫ dαdβ h(α)e−iEβT δ(Eα −Eβ)Tβα⏐⏐Ψ(0)β ⟩
=
T →+∞
∫
dαdβ h(α)e−iEβT
(
δβα −2πiδ (Eα −Eβ)Tβα
)⏐⏐Ψ(0)β ⟩.
Alternatively, we can also write
⏐⏐Ψh,in⟩T = ∫ dα h(α)e−iEαT ⏐⏐Ψα,in⟩
=
∫
dα h(α)e−iEαT
∫
dβ
⏐⏐Ψβ,out⟩⟨Ψβ,out⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Sβα
=
T →+∞
∫
dαdβ h(α)e−iEβT Sβα⏐⏐Ψ(0)β ⟩.
(In the last line, we also used the fact that Sβα is proportional to a delta function of energy
conservation to changeEα intoEβ in the exponential.) By comparing the two formulas, we
conclude that
Sβα = δβα −2πiδ (Eα −Eβ)Tβα.


PDF PAGE 59 
 11 LEE–NAUENBERG THEOREM 47
11.b The Lipmann–Schwinger equation (1.56) can be solved iteratively, leading to the
following series in powers of the interaction potential:
Tβα = Vβα +
+∞∑
n=1
∫
dγ1 ··· dγn
VβγnVγnγn−1 ··· Vγ1α
(Eα −Eγ1 +i0+)··· (Eα −Eγn +i0+).
The physical interpretation of this expression is that the system starts in the stateα and evolves
to the stateβ, undergoing a sequence of interactions that take it through the intermediate states
γ1,γ2,...,γ n.
11.c In this formula, the matrix elements ofV are regular, and the only potential singularities
come from the poles in the other factors under the integral. However, these poles do not always
lead to a divergence in the result. This can be seen, for instance, in the following two toy
examples:
+1∫
−1
dx
x +i0+ =− iπ,
+1∫
0
dx
x +i0+ = ∞.
In these examples, we see that in order to lead to a divergence, the pole should be at one of
the endpoints of the integration domain; otherwise we may deform the integration contour
to completely avoid the pole. Another conﬁguration leading to an unavoidable divergence is
when the integrand has a pair of poles “pinching” the integration contour so that it cannot be
deformed.
Two statesα andγ may accidentally have the same energy when one varies the momentum
of a particle. However, when varying the stateγ, these accidental degeneracies occur in the
middle of the allowed domain of the variables that parameterizeγ. The corresponding pole in
(Eα −Eγ +i0+)−1 is therefore avoidable by deforming the integration contour, and this does
not lead to a divergence.
The state γ also has the same energy as α if it differs from α by one or more ultrasoft
particles. In this situation, the resulting pole in (Eα −Eγ +i0+)−1 occurs when the energy of
these extra particles goes to zero, which is on the boundary of the integration domain for γ,
and therefore produces an actual divergence in the result. Another situation whereγ has the
same energy asα is when a hard massless particle in one of the two states is replaced in the
other state by two or more collinear particles with the same total momentum. This case also
leads to a divergence, because the pole is reached on the boundary of the angular integration
domain.
In order to keep track of these two problematic situations, let us denote byD(α) the set
of states that are degenerate withα, excluding the accidental degeneracies. Consider now the
sequence of states
α → γ1 → ··· → γi−1 → γi → γi+1 → ··· → γn → β.
Each stateγi in this sequence is related to the preceding and following states by an elementary
interactionV. Obviously, in order to produce a pole, the state γi must have the same energy as
α. But for this pole to lead to a divergence, a stronger condition should be satisﬁed: the pole
must occur on the boundary of the integration domain of γi, which is made of the states in
D(γi−1) or in D(γi+1).


PDF PAGE 60 
 48 1 QUANTUM FIELD THEORY BASICS
Assume for instance that γi ∈ D(γi−1), and has the same energy as α. But this implies
thatγi−1 also has the same energy asα, which happens on a harmless zero measure subset of
the phase-space ofγi−1 unlessγi−1 itself belongs to the degeneracy set ofγi−2, D(γi−2).B y
repeating this inductive argument, we see that this divergence occurs only if all ofγ1,γ2,...,γ i
belong to D(α). If instead we make the assumption that γi ∈ D(γi+1), then it is the entire
chain γi,γi+1,...,γ n that must be in D(β) in order to have a divergence. This result is
consistent with the well-known fact that infrared divergences happen when soft photons are
attached to the external legs of a hard process, but not when one attaches the soft photon to a
hard internal line of a graph. The same is true of the divergences due to collinear splittings.
11.d We assume now that the initial and ﬁnal states are not degenerate, i.e., thatD(α) and
D(β) do not overlap. Then, we introduce projectors Pα,Pβ andP3 that project respectively on
D(α),o n D(β) and on the remaining portion of the Hilbert space. Since the union of these
sets is the complete Hilbert space, the sum of these projectors is the identity
Pα +Pβ +P3 = 1.
Moreover, we assume that the volume ofD(α) andD(β) is very small (this is controlled by
what is experimentally meant by “soft” or “collinear”) compared to the rest, implying that we
may neglect these states except when they produce a divergence. In terms of these projectors,
the matrix elementTβα can be written as
Tβα =
+∞∑
n=0
[
V
( Pα +Pβ +P3
Eα −H0 +i0+V
)n]
βα
.
This formula is still exact. The next step is to expand this expression, and to dropPα andPβ
unless they occur in conﬁgurations that produce a divergence. Thus we keep thePα’s if they
form an uninterrupted chain on the right of the product, and thePβ’s if they form a chain on
the left of the product:
Tβα =sing.
+∞∑
r,s,n=0
[(
V Pβ
Eα −H0 +i0+
)s
V
( P3
Eα −H0 +i0+V
)n( Pα
Eα −H0 +i0+V
)r]
βα
,
which can be written compactly as
Tβα =
(
U†β,out T3 Uα,in
)
βα
, with T3 ≡ V
+∞∑
n=0
( P3
Eα −H0 +i0+V
)n
,
and
Uα,in ≡
+∞∑
r=0
( Pα
Eα −H0 +i0+V
)r
,U β,out ≡
+∞∑
s=0
( Pβ
Eα −H0 −i0+V
)s
.
The factorsUα,in andUβ,out contain divergences, while the factorT3 is divergence-free.
Note now that the operatorUα,in is the restriction to the subspace D(α) of the operatorΩ
that we introduced just above (1.56), and that we have shown to be unitary. Therefore,Uα,in is


PDF PAGE 281 
 110 2 FUNCTIONAL METHODS
25.c The heat kernel (see Problem 23) ofgσ − □E is then given by
Hgσ−□ (x,x ′;τ) ≡ 2a ∑n≥1 ∫ d3k(2π)3 e−τ(k2+π2n2/a2) eik·(x−x′) sin(πnx3a ) sin(πnx′3a ).
Evaluating this atx = x′ and integrating overx in a domain of transverse sectionL2 between
the two walls gives
∫
d4xH gσ−□ (x,x ;τ)= βL2 ∑
n≥1
∫ d3k
(2π)3 e−τ(k2+π2n2/a2),
and the corresponding zeta function is therefore
ζgσ−□ (s)= βL2Γ (s) ∫ ∞0 dττ τs ∑n≥1 ∫ d3k(2π)3 e−τ(k2+π2n2/a2).
The integral overk is an elementary Gaussian integral,
∫ d3k
(2π)3 e−τk2 = 18π3/2τ3/2.
Up to a rescaling, the integral overτ gives a gamma function,
∫ ∞
0
dτ
τ τs−32 e−τπ2n2/a2 =( aπn)2s−3 Γ (s − 32 ).
Finally, the sum onn produces a Riemann zeta function. Combining everything, we get
ζgσ−□ (s)= βL28π3/2 (aπ)2s−3 ζ(2s −3)Γ (s − 32 )Γ (s) .
25.d Noting thatΓ (s) ≈ s−1 in the vicinity ofs = 0, its derivative ats = 0 is
ζ′gσ−□ (0)=− ln det(gσ − □E )= π3/2βL28a3 ζ(−3)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 1120
Γ (−32 )/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=43π1/2
= π2βL2
720a3.
Finally, we obtain the following expression for the free energy:
F =− 12β−1ζ′gσ−□ (0)=− π2L21440a3,
which is identical to the expression for the Casimir vacuum energy obtained in Problem 24.
Although the derivation followed here is not technically simpler, it provides a much more
satisfactory handle on how the ﬁelds interact with the walls. In particular, we see explicitly
how the Casimir energy is nothing but the free energy of the two walls (strongly coupled to the
ﬁelds) interacting by the exchange of scalar particles. Technical challenges aside, there would
be no conceptual difﬁculty in extending the present approach to deal with the case where the
ﬁeld–wall interaction has a ﬁnite strength, or walls that have a non-zero thickness, or even
to calculate the ﬁnite-temperature corrections (neglected here because we have replaced the
Matsubara frequencies by a continuousk0).
Source: this problem was inspired by Jaffe, R. L. (2005), Phys Rev D 72: 021301.


PDF PAGE 282 
 26 GROSS–NEVEU MODEL 111
26. Gross–Neveu Model The Gross–Neveu model is a (1 + 1)-dimensional quantum
ﬁeld theory withN species of massless fermions (indexed byn = 1,...,N ), with a quartic
interaction,
L ≡ i
∑
n
ψn/∂ψn + g22 ( ∑n ψnψn)2.
This quantum ﬁeld theory is a toy model for the spontaneous breaking of chiral symmetry, and
also provides an example of the technique of bosonization.
26.a Check that a valid representation of the Dirac matrices in two dimensions isγ0 = σ2,
γ1 = iσ1 (with σ1,2 Pauli matrices). Also deﬁne γ5 ≡ γ0γ1. Check that (γ5)2 = 1,
(γ5)† = γ5, {γ5,γμ} = 0 for μ = 0,1 . Show that L is invariant under ψn → γ5ψn.
Would a mass term be consistent with this symmetry?
According to the power counting, can this theory be renormalizable ind = 2?
26.b Prove the following equality:
∫
[DψDψ]ei
∫
L =
∫
[DψDψDφ]ei
∫ ∑
n ψn(i/∂−φ)ψne− i2g2 ∫φ2,
whereφ is an auxiliary scalar ﬁeld.
26.c We are now interested in the ground state of this theory, in whichφ is constant. Perform
the integration over the fermions in closed form for a constant φ, and show that the
result of this integration is a factor
exp
{
N
∫ d2p
(2π)2 ln(−p2 +φ2)
}
, withp2 ≡ p20 −p21.
26.d Using ln(A)=− ∂α(A−α)α=0, and using dimensional regularization withd = 2 −2ϵ,
show that the integral can be written as
∫ ddp
(2π)d ln(−p2 +φ2)= iφ24π(1ϵ + const +1 − lnφ2 +O(ϵ2)).
Which operator should one renormalize to eliminate the ultraviolet divergence? After
introduction of an appropriate counterterm, show that the effective potential for the ﬁeld
φ can be written as
Veff(φ)= φ22g2 + Nφ24π ( ln(φ2μ2) −1),
whereμ is a constant whose precise value depends on the ﬁnite terms included in the
counterterm besides the pole inϵ−1.
26.e Determine analytically the location of the minimum of Veff(φ). Could this answer have
been found by a perturbative expansion in powers ofg2? What are the consequences for
the fermions of having a non-zero expectation value forφ?
26.f What are the diagrams that would give the result of the above functional calculation?
Why is the answer exact in the limitN →∞ ?


PDF PAGE 283 
 112 2 FUNCTIONAL METHODS
26.a In order to verify that the proposed matrices are valid Dirac matrices in two dimensions,
we just need to verify that
{
γμ,γν} = 2gμν:
(
γ0)2 =(σ2)2 = 1, (γ1)2 =(iσ1)2 =− 1,
γ0γ1 +γ1γ0 = iσ2σ1 +iσ1σ2 = i(−iσ3)+ i(iσ3)= 0.
Deﬁningγ5 ≡ γ0γ1,w eh a v e
(
γ5)2 = γ0γ1γ0γ1 =− γ0 γ1γ1
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1
γ0 =+ 1,
(
γ5)† =( iσ2σ1)† =− iσ1σ2 =+ iσ2σ1 = γ5,
{
γ5,γμ} = γ0γ1γμ +γμγ0γ1 = 0.
(In the ﬁnal equality above, since μ is either 0 or 1, γμ commutes with one of γ0,1 and
anti-commutes with the other one.) Under the transformation ψn → γ5ψn,w eh a v e
ψn → γ5ψn,
ψn ≡ ψ†nγ0 → ψ†n γ5†γ0/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=γ5γ0=−γ0γ5
=− ψnγ5,
ψnψn → −ψnψn,(
ψnψn
)2 →(ψnψn)2,
ψnγμψn → −ψn γ5γμγ5/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−γμ
ψn = ψnγμψn,
hence the invariance of the Lagrangian. Note that a mass term is not allowed by this symmetry
sinceψnψn → −ψnψn under this transformation.
The mass dimension of the ﬁeldψn is 12 ind = 2, and therefore the mass dimension of thecoupling constant g is zero. This theory should therefore be renormalizable in two dimensions
according to the power counting.
26.b In order to check the proposed equality, we proceed by explicitly performing the
integration overφ on the right-hand side. For this, we need
− 12g2 φ2 −φ ∑
n
ψnψn =− 12g2
[
φ2 +2g2φ ∑
n
ψnψn
]
=− 12g2
[(
φ +g2 ∑
n
ψnψn
)2
−g4
( ∑
n
ψnψn
)2]
.
Then, we deﬁne φ′ ≡ φ + g2 ∑n ψnψn and trade the integration variable φ in favor
of φ′. The integral produces a constant prefactor (which we ignore), and leaves a factor
exp(g22 (∑n ψnψn)2), hence the announced equality.


PDF PAGE 284 
 26 GROSS–NEVEU MODEL 113
26.c Whenφ is a constant, we can perform the integration over the fermions explicitly. Each
pair of integralsDψnDψn produces a factor
det
(
i/∂ −φ
)
.
These factors do not depend on the index n, and there are N of them, so the N fermionic
integrations give
[
det
(
i/∂ −φ
)]N
= exp
{
N tr ln
(
i/∂ −φ)
}
= exp
{
N
∫ d2p
(2π)2 tr ln(/p −φ)
}
.
Note that the original trace was over both spacetime and the Dirac indices. In the ﬁnal equality,
we have rewritten the trace over spacetime as a trace over momentum and we keep unchanged
the trace over the Dirac indices. For the latter, we can write
tr ln(/p −φ)= ln det
(
−φi (p0 −p1)
−i(p0 +p1)− φ
)
= ln
(
φ2 −p2).
(We have used the explicit form of the Pauli matrices in the ﬁrst equality.) This gives the
announced formula.
Alternative Proof: It is possible to do this calculation without resorting to any explicit
representation of the Dirac matrices, as follows:
tr ln(/p −φ)= tr ln(−φ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=2 ln(−φ)=ln(φ2)
+tr ln(1 −/p/φ)
= ln(φ2)− ∑
n≥1
1
n tr
([/p
φ
]n)
= ln(φ2)− ∑
p≥1
1
2p tr
([/p
φ
]2p)
= ln(φ2)− ∑
p≥1
1
p
(p2
φ2
)p
= ln(φ2)+ ln(1 −p2/φ2)= ln(φ2 −p2).
(In the third line, we used the fact that/p2p+1 = p2p/p has a null trace, and therefore we keep
only the terms of even order.)
26.d Then, the integration of the momentump proceeds as follows:
∫ ddp
(2π)d ln(−p2 +φ2)=− ∂α
∫ ddp
(2π)d
1
(−p2 +φ2)α
⏐⏐⏐⏐⏐
α=0
=− i∂α
∫ ddpE
(2π)d
1
(p2E +φ2)α
⏐⏐⏐⏐⏐
α=0
=− i∂α
φd−2α
(4π)d/2
Γ (α − d2 )
Γ (α)
⏐⏐⏐⏐⏐
α=0
.
Note thatΓ (α) ≈ α−1 whenα → 0. Therefore, we have


PDF PAGE 285 
 114 2 FUNCTIONAL METHODS
∂α
F(α)
Γ (α)
⏐⏐⏐⏐⏐
α=0
= F(0),
and we obtain
∫ ddp
(2π)d ln(−p2 +φ2)=− i φd(4π)d/2Γ (−d2 )=− iφ2φ−2ϵ(4π)1−ϵ Γ (−1 +ϵ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1ϵ +const+O(ϵ)
= iφ2
4π
[1
ϵ + const +1 − ln(φ2)+ O(ϵ2)]. (2.35)
(We could have written const +1 as some unique constant, but it will be convenient later to
pull out this 1.) The pole in ϵ−1 can be removed by renormalizing the operator φ2. More
precisely, we introduce the counterterm
−iφ2
4π
[1
ϵ + const′
]
,
where const′ is a ﬁnite constant that may be subtracted along with the poleϵ−1. Combining
the original term inφ2 with the result (2.35) and the counterterm, we get
φ2
2g2 + Nφ24π ( ln(φ2μ2) −1)
for the sum of the terms inφ2 inside the exponential.
26.e The derivative of this effective potential is given by
∂
∂φVeff(φ)= 2φ
[ 1
2g2 + N4π ln(φ2μ2)].
This derivative vanishes atφ = 0, but this is a local maximum. The other zero of the derivative
is at
φ∗ ≡ μ exp
(
− πg2N).
One may check that this is a local minimum. Note that the location of this minimum depends
on the renormalization scale, but the minimum is always there, no matter which scale we
choose. Note also that this minimum is non-perturbative since its value is a non-analytic
function of the couplingg (more precisely, it is a function whose Taylor coefﬁcients atg = 0
are all zero). Because of the couplingψnφψn, and the non-zero expectation value of the scalar
ﬁeld, the fermions become massive in the ground state of this theory (this is similar to the
Higgs mechanism), and the chiral symmetry is spontaneously broken.
26.f Diagrammatically, the determinant resulting from the integration over the fermion ﬁelds
corresponds to the sum of all the diagrams with one fermion loop, dressed by insertions of the
scalar ﬁeldφ. By its position inside the exponential, N acts in a similar way to ¯h−1. Taking
the limitN → +∞ has the same effect as taking the limit ¯h → 0, namely eliminating all the
higher-order corrections. For this reason, the results we have derived in this problem do not
receive any higher-order corrections whenN is very large.


PDF PAGE 294 
 29 COMPLEX LANGEVIN EQUATION 123
propagator. By combining contributions of ordersη andη3 in twoϕ’s, we can construct the
following more elaborate example:
ττ
τ' p
k =
∫
dτ′ d4k(2π)4 G(τ,τ ′,p )G(τ′,τ ′,k )G (τ,τ ′, −p)
=
∫τ
0
dτ′ d4k(2π)4 e−(m2+p2)(τ−τ′) −e−(m2+p2)(τ+τ′)p2 +m2
× 1 −e−2(m2+k2)τ′
k2 +m2 e−(m2+p2)(τ−τ′)
=
τ→∞
1
2
1
(p2 +m2)2
∫ d4k
(2π)4
1
k2 +m2.
We again recover the expected perturbative contribution (ultraviolet divergence included).
Source: Damgaard, P. H. and H¨uffel, H. (1987), Phys Rep 152: 227.
29. Complex Langevin Equation This problem is a continuation of Problem 28. Its goal
is to explore within a toy model what happens when the action is complex-valued, leading to
a complex Langevin equation. We consider the “action” S(x) ≡ α2x2 + β4 x4, and write thefollowing Langevin equation:
∂τx =− S′(x)+ η, ⟨η(τ)⟩η = 0, ⟨η(τ)η(τ′)⟩η = 2δ(τ −τ′).
29.a Whenα,β are complex, why can’t the distribution ofx deﬁned from solutions of this
equation be proportional to exp(−S(x))?
29.b Show that the momentsCn ≡
⟨zn(τ)
n!
⟩
η (if they converge) satisfy in the limitτ →∞ the
same three-term recurrence relation,
Cn−2 = αnCn +βn(n +1)(n +2)Cn+2,
as the true moments
∫
dx xnn! exp(−S(x))/ ∫dx exp(−S(x)).
29.c Show that the momentsCn obtained from the complex Langevin equation coincide with
the true moments if we have limn→∞ Cn = 0.
29.d Ifβ ∈ R ∗+, ﬁnd a condition onα that guarantees the convergence of the momentsCn
(use results from Gibson, P. M. (1971),Proc Edinb Math Soc 17(4): 317).
29.e Show that the complex Langevin equation is equivalent to the following Fokker–Planck
equation for a distributionPτ(x,y ) over the complex plane:
∂τPτ(x,y )=
(
∂2x +∂xReS′(x+iy)+∂yImS′(x+iy))Pτ(x,y ).


PDF PAGE 295 
 124 2 FUNCTIONAL METHODS
29.f For β = 0,α ≡ a +ib, show that the ﬁxed point of this Fokker–Planck equation is
Gaussian,
P∞(x,y ) ∝ exp
{
−a
(
x2 + 2ab xy +(1 + 2a2b )y2)}.
Although everything looks ﬁne in this case, what practical problem arises whenb ≫ a ?
29.a As we have seen in Problem 28, when α,β are positive real integers we can view
exp(−S(x)) as a probability distribution on the real axis, and generate an ensemble of x’s that
samples this distribution by solving the following Langevin equation:
∂τx =− S′(x)+ η, ⟨η(τ)⟩ = 0, ⟨η(τ)η(τ′)⟩ = 2δ(τ −τ′). (2.38)
Moreover, the probability distribution Pτ(x) of an ensemble of x’s that obey this Langevin
equation evolves according to a Fokker–Planck equation,
∂τPτ = ∂x
(
∂x +S′(x))Pτ,
that admits exp(−S(x)) as a unique ﬁxed point.
Consider now the case where the coefﬁcients α,β that deﬁne S(x) are complex. In this
case, the weight exp(−S(x)) in the integral is complex-valued and cannot be interpreted as a
probability distribution (moreover, in this case, the integrand has a strong oscillatory behavior
that prevents evaluation by Monte Carlo sampling).
On the other hand, when we solve the Langevin equation (2.38) with a complex action,
it leads to complex solutions even if the initial condition and the noise are real-valued. For
this reason, it is called a complex Langevin equation. Thus, the equilibrium distribution of an
ensemble ofz ≡ x +iy’s obeying this Langevin equation is a positive deﬁnite distribution on
the complex plane, i.e., deﬁnitely not the complex-valued weight exp(−S(x)) of the original
integral.
29.b From the solution of the complex Langevin equation, let us deﬁneτ-dependent moments
by averaging over the noise, as follows:
Cn(τ) ≡ Z−1
∫
[Dη] zn(τ)n! e−14 ∫η2, with Z ≡ ∫ [Dη]e−14 ∫η2.
From this representation, we obtain the derivative of the moments with respect toτ:


PDF PAGE 296 
 29 COMPLEX LANGEVIN EQUATION 125
∂τCn(τ)= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!∂τz(τ) e−14 ∫ η2
= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!
(
−S′(z(τ)) +η(τ)) e−14 ∫ η2
= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!
(
−S′(z(τ)) −2 δδη(τ)) e−14 ∫ η2
=−
⟨xn−1(τ)
(n −1)! S′(x(τ))⟩η +2⟨xn−2(τ)(n −2)! δz(τ)δη(τ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 12
⟩
η
,
i.e.,
∂τCn(τ)= Cn−2 −αnCn −βn(n +1)(n +2)Cn+2. (2.39)
Consider now the true moments of this toy model,
Mn ≡
∫
dx e−S(x) xnn!∫
dx e−S(x) .
A simple integration by parts shows that
Mn−2 = αnMn +βn(n +1)(n +2)Mn+2.
Interestingly, the ﬁxed points of the equation (2.39) (deﬁned by requiring that∂τCn = 0) obey
exactly the same three-term recurrence relation.
This has led to the conjecture that the probability distributionPτ(x,y ) in the complex plane
(we denote byx andy the real and imaginary parts, respectively) followed by an ensemble of
solutions of the complex Langevin equation is such that
lim
τ→∞
∫
dxdy Pτ(x,y )f(x +iy)=?
∫
dx e−S(x) f(x). (2.40)
The remarkable aspect if this equality (if true) is that the left hand side has a positive weight
over C and the test functionf is evaluated at complex numbers, while on the right-hand side
the functionf is evaluated solely on the real axis but weighted with a complex-valued action.
This certainly requires at a minimum that the functionf(z) be analytic so that the values on
the real axis are related to those in the rest of the complex plane (but this limitation should
not be a surprise, since we arrived at this conjecture from considerations on the moments). If
this conjecture were valid (and generalizable from this toy model to a realistic quantum ﬁeld
theory), it would offer the prospect of turning a path integral that has a sign problem (e.g.,
a path integral in Minkowski spacetime) into one that has a positive deﬁnite weight over a
complexiﬁed ﬁeld space (and is thus approachable by Monte Carlo sampling).
The question of the validity of the conjecture (2.40) can in fact be divided into three
sub-questions:
1. If the moments Cn(τ) deﬁned from the complex Langevin equation do converge to a
ﬁxed point, does this ﬁxed point actually give the true momentsMn?


PDF PAGE 297 
 126 2 FUNCTIONAL METHODS
−4
−3
−2
−1
0
1
2
3
4
5
0 500 1000 1500 2000 2500 3000 3500
ρn/2000, ϕn   (Cn,Mn = 10−ρn eiϕn )
n
α = 1+5i, β = 1
true moments
recur. w. C5000=0
Figure 2.9 Comparison of the true momentsMn (evaluated numerically) and the moments
Cn obtained by solving the recurrence with the constraintsC0 = 1,C5000 = 0. The moments
are parameterized as10−ρneiϕn ; the exponentρn (divided by2000, open squares and solid
line) and the phaseϕn (open circles and solid dots) are both shown in the plot.
2. Do they actually converge to a ﬁxed point?
3. In practice one has only a ﬁnite number of solutions of the complex Langevin equation,
which is equivalent to evaluating the left-hand side of (2.40) by Monte Carlo sampling.
Even though the distributionPτ(x,y ) is positive, are there situations where the integral
onx,y cannot be sampled efﬁciently?
29.c The recurrence relation satisﬁed both by the ﬁxed point of the Cn and by the true
moments Mn is not sufﬁcient to uniquely determine the moments, and therefore cannot
guarantee that the Cn and Mn are equal. Since this recurrence is linear and involves three
terms, the space of its solutions is a linear space of dimension two. The zeroth-order moment
is trivially ﬁxed at C0 = M0 = 1 in both cases, which reduces to one the dimension of the
space of solutions. One may check that the true momentsMn go to zero whenn →∞ , thanks
to the factorial included in their deﬁnition. Therefore, if we also had C∞ = 0, the recurrence
would determine a unique sequence of moments, and this sequence would coincide with the
true moments. This is illustrated in Figure 2.9 (for practical reasons related to the numerical
algorithm used to solve the recurrence, we have set C5000 = 0 instead of C∞ = 0), where
we see a perfect agreement (both in norm and in phase) between the true moments and those
obtained by solving the recurrence.
29.d Let us now discuss the convergence of the momentsCn whenτ → +∞. Since C0 = 1
is independent ofτ, and using the fact that the odd moments are zero, we can write the equation
of motion of the higher moments as follows:
∂τC = C∗ +BC,
where we denote


PDF PAGE 298 
 29 COMPLEX LANGEVIN EQUATION 127
C ≡
⎛
⎜⎜⎜⎝
C2
C4
...
C2N
⎞
⎟⎟⎟⎠, C∗ ≡
⎛
⎜⎜⎜⎝
C0
0
...
0
⎞
⎟⎟⎟⎠, B ≡
⎛
⎜⎜⎜⎝
−2α −24β 0 ··· 00
1 −4α −120β ··· 00
... ... ... ... ...
00 0 ··· 1 −2Nα
⎞
⎟⎟⎟⎠.
(Here, we have truncated the recurrence by imposing that C2N+2 = 0. Alternatively, one could
view B as a matrix of inﬁnite size.) The matrix B is invertible, and the ﬁxed point of the
preceding equation is given by
C(∞)=− B−1C∗.
Whether the solution actually converges to this ﬁxed point is controlled by the sign of the real
part of the eigenvalues of the matrix B. A formal solution of the equation of motion of the
moments is
C(τ)= eτB
[
C(0)+
∫τ
0
dτ′ e−τ′B C∗] ,
where C(0) is the initial condition for the moments C2,4,6,.... For this solution to forget its
initial condition, we must have
lim
τ→+∞
eτB = 0,
which requires that all the eigenvalues of B have strictly negative real parts. (The matrix
B is non-Hermitian, and therefore not necessarily diagonalizable. However, the property
exp(τB) → 0 if all eigenvalues have negative real parts remains true, as can be seen by using
the Jordan form of the matrix.) Moreover, when this is the case, we also have
lim
τ→+∞
eτB
∫τ
0
dτ′ e−τ′B =− B−1,
which ensures that the solution converges to the expected ﬁxed point.
Whenβ ∈ R (in this case,β should be positive for the original integral to make sense), we
may use the following theorem (see Gibson, P. M. (1971),Proc Edinb Math Soc 17(4): 317):
given a complex tri-diagonal matrix
Ω ≡
⎛
⎜⎜⎜⎜⎜⎜⎜⎜⎝
b1 c1 0 ··· 00
a1 b2 c2 ··· 00
0a 2 b3 ··· 00
... ... ... ... ...
000 ··· bn−1 cn−1
000 ··· an−1 bn
⎞
⎟⎟⎟⎟⎟⎟⎟⎟⎠,
withai,bi,ci ∈ C ,i faici ∈ R andaici ≤ 0 for all1 ≤ i ≤ n −1, then all the eigenvaluesλ
ofΩ satisfy
min
{
Re (bi)
}
≤ Re (λ) ≤ max
{
Re (bi)
}
.
Therefore, whenβ is real positive, we may conclude that all the eigenvalues ofB have a real
part whose sign is opposite to that of the real part ofα:


PDF PAGE 299 
 128 2 FUNCTIONAL METHODS
•R e (α) >0 : Re (λ) <0 for all eigenvalues, and the moments converge to the ﬁxed
point, in a ﬁctitious time at most τ ∼ (2 Re (α))−1 (this is the inverse of the smallest
possible real part, among all eigenvalues).
•R e (α) <0 : Re (λ) >0 for all eigenvalues, and the moments diverge (but would
converge if we changed the direction of the evolution,τ → −τ).
29.e The derivation of the time evolution of the distribution Pτ(x,y ) can be done by the
same method as the one used in Problem 28, by considering a generic test functionF(x,y ) and
writing
∫
dxdy
(
∂τPτ
)
F = Z−1
∫
[Dη]
{
(∂τx)∂xF +(∂τy)(∂yF)
}
e−14 ∫η2
= Z−1
∫
[Dη]
{
(−ReS′ + η/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
−2 δδη
)∂xF +( −ImS′)(∂yF)}e−14 ∫η2.
Then, we integrate the derivative with respect toη by parts to let it act on∂xF, which gives
2 δδη(τ)∂xF = 2 δx(τ)δη(τ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 12
∂2xF = ∂2xF.
Therefore, we have
∫
dxdy
(
∂τPτ
)
F =
∫
dxdy Pτ
{
∂2xF − ReS′(∂xF)− ImS′(∂yF)}
=
∫
dxdy F
{
∂2x +∂xReS′ +∂yImS′
}
Pτ,
which gives the announced Fokker–Planck equation since this equality must be true for any
test functionF(x,y ).
29.f Let us assume a quadratic action, i.e.,β ≡ 0,α ≡ a +ib. The statement of the problem
announces an asymptotic solution in the form of the exponential of a polynomial of degree
two, of the form
− lnP∞(x,y )= 12(ux2 +vy2 +2wxy).
Fixed points of the Fokker–Planck equation make its right-hand side vanish. With the above
ansatz, this results in the following set of equations for the coefﬁcientsu,v,w :
u2 = au +bw, w 2 = av −bw, 2uw = 2aw +b(v −u),u = 2a.
(The four equations correspond to equating to zero the coefﬁcients ofx2,y2,xy and1, respec-
tively.) Onceu is known, it is straightforward to obtain the other coefﬁcients,
w = 2a2b ,v = 2a(1 + 2a2b2 ).
(One should also check that the fourth equation is satisﬁed by this solution.) Therefore, when
β = 0, we indeed obtain the announced ﬁxed point. This distribution looks completely
innocuous, with rapidly falling tails in all directions of the complex plane.


PDF PAGE 300 
 29 COMPLEX LANGEVIN EQUATION 129
When b ≫ a (i.e., when the original integral suffers from a severe sign problem), this
distribution becomes nearly isotropic in thex,y plane:
P∞(x,y )=a≪b
a
π exp
{
−a
(
x2 +y2)}. (2.41)
(We have restored the proper normalization prefactor.) From this isotropic distribution, we
would predictC0 = 1,C2,4,6,... = 0, while the exact moments are
M2n = 12nn!(a +ib)n ≈ 12nn!bn.
The momentz2n/(2n)! obtained with (2.41) in an angular slice [θ,θ +ϵ] reads
ϵ
∫ ∞
0
dr raπe−ar2 r2ne2inθ(2n)! = ϵπ n!e2inθan(2n)! ≫ M2n.
Had we performed the calculation with the exact distributionP∞(x,y ), we would have
ϵ
∫ ∞
0
dr rP∞(x,y ) r2ne2inθ(2n)! = ϵπ n!e2inθan(2n)! {1⊕ ab ⊕···⊕ anbn/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
order
ofM2n
⊕···
}
.
We see that the correct result forM2n results from cancellations in the angular integration over
θ (thanks to the weight e2inθ), such that the result ∼ a−n in a small angular slice is reduced to
b−n after the angular integration. Thus, the sign problem we sought to circumvent reappears
in a (milder) form that renders difﬁcult the evaluation of high-order moments.


exit_code=0
```

### 2026-11-16T17:43:29.575377+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in list(range(55,61))+list(range(282,286))]'
```

```text

PDF PAGE 55 
 11 LEE–NAUENBERG THEOREM 43
11. Lee–Nauenberg Theorem In quantum mechanics and quantum ﬁeld theory, there exist
states that are practically undistinguishable (e.g., states that differ by features that are too dim to
be experimentally detected). Transition amplitudes with such initial or ﬁnal states are in general
plagued by singularities. The goal of this problem is to discuss these pathologies in the simple
setting of quantum mechanics, and to show that they can be avoided by averaging transition
probabilities over all degenerate states. To that end, consider a Hamiltonian H = H0 +V
decomposed into a free Hamiltonian H0 and an interaction potential V. We recall that the
scattering matrixS can be written as
Sβα = δβα −2πiδ (Eα −Eβ)Tβα,
withTβα ≡ Vβα +
∫
dγ VβγTγα
Eα −Eγ +i0+,V βα ≡
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψ(0)α ⟩,
where theEα’s and
⏐⏐Ψ(0)α ⟩’s are the eigenvalues and eigenstates ofH0.
11.a Show that
(
Ωin
)
βα ≡ δβα + TβαEα−Eβ+i0+ is a unitary matrix. Hint: deﬁne ⏐⏐Ψα,in⟩ ≡∫
dγ
(
Ωtin)αγ⏐⏐Ψ(0)γ ⟩ and consider the matrix element ⟨Ψβ,in⏐⏐V⏐⏐Ψα,in⟩.
11.b Solve formally the equation forTβα, to obtain
Tβα = Vβα +
+∞∑
n=1
∫
dγ1 ··· dγn
VβγnVγnγn−1 ··· Vγ1α
(Eα −Eγ1 +i0+)··· (Eα −Eγn +i0+).
11.c Denote byD(α) the set of states obtained fromα by adding/removing ultrasoft particles,
by splitting collinearly hard massless particles or by recombining collinear particles,
i.e., the set of states that are undistinguishable from the stateα. Explain why Tβα has
divergences if γ1,γ2,...,γ i all belong to D(α) or if γi,γi+1,...,γ n all belong to
D(β).
11.d IntroducePα,Pβ,P3, the projectors on D(α),D(β) and on the rest of the Hilbert space,
respectively. Show that squared matrix elements ofT become ﬁnite if they are summed
over all the states inD(α) andD(β), i.e., ∑
a∈D(α),b∈D(β)
⏐⏐Tba⏐⏐2 < ∞.
Reminders on Scattering Theory in Quantum Mechanics: The setting of this study is the
formulation of scattering in quantum mechanics. Let us consider a Hamiltonian H, which we
decompose into a free Hamiltonian and an interaction potential:
H = H0 +V.
Denote by
⏐⏐Ψ(0)α ⟩ the eigenstates of the free Hamiltonian,


PDF PAGE 56 
 44 1 QUANTUM FIELD THEORY BASICS
H0
⏐⏐Ψ(0)α ⟩ = Eα⏐⏐Ψ(0)α ⟩,
and by
⏐⏐Ψα⟩ those of the full Hamiltonian,
H
⏐⏐Ψα⟩ = Eα⏐⏐Ψα⟩.
The eigenvalues of the free and interacting Hamiltonians are the same, provided we disregard
the formation of bound states that may happen with certain interactions, and provided the free
Hamiltonian is expressed in terms of the physical masses of the particles. The last equation
may be rewritten as
(Eα −H0)
⏐⏐Ψα⟩ = V⏐⏐Ψα⟩. (1.54)
Note that the operatorEα −H0 is not invertible, since
⏐⏐Ψ(0)α ⟩ lies in its kernel (as well as any
other state degenerate with it). Consider the following states:
⏐⏐Ψα,in⟩ ≡⏐⏐Ψ(0)α ⟩ +(Eα −H0 +i0+)−1 V⏐⏐Ψα,in⟩,⏐⏐Ψα,out⟩ ≡⏐⏐Ψ(0)α ⟩ +(Eα −H0 −i0+)−1 V⏐⏐Ψα,out⟩.
These states are obviously solutions of (1.54). These states are time-independent (i.e., they are
states in the Heisenberg representation), but may look different to observers in different frames.
In particular, in a frame that differs by a translation by a timeT, these states are multiplied by
e−iHT . Since they are energy eigenstates, the action of this operator is just a multiplication by
an irrelevant phase exp(−iEαT ). But these phases have a non-trivial effect on superpositions
of states. Consider, for instance,
⏐⏐Ψh,in⟩ ≡ ∫ dα h(α)⏐⏐Ψα,in⟩
(the notationdα is a shorthand for the integration/summation measure over all the quantum
numbers of the particles in the stateα, such as3-momenta, spins, etc.), whereh(α) is a smooth
function that spans a small range of energiesEα. Under such a translation in time, this state
becomes
⏐⏐Ψh,in⟩ →⏐⏐Ψh,in⟩T = ∫ dα h(α) e−iEαT ⏐⏐Ψα,in⟩
= e−iH0T ⏐⏐Ψ(0)h ⟩+∫ dαh (α) e−iEαT(Eα −H0 +i0+)−1 V⏐⏐Ψα,in⟩.
(1.55)
In the second term, we must close the contour for the integral over the energyEα in the upper
half-plane in order to ensure its convergence if T<0 . Then, the theorem of residues gives
the integral in terms of the singularities of the integrand. Except for the denominator, the
other factors generically have their singularities at ﬁnite imaginary part, Im (Eα) >0 (because
interactions typically lead to a ﬁnite lifetime for the particles), and their contribution vanishes
whenT → −∞. The denominator leads to poles located at Eα = E∗ −i0+, i.e., below the real
axis, and therefore it does not contribute to the result. Thus, we have
e−iHT ⏐⏐Ψh,in⟩ =T →−∞ e−iH0T ⏐⏐Ψ(0)h ⟩,e −iHT ⏐⏐Ψh,out⟩ =T →+∞ e−iH0T ⏐⏐Ψ(0)h ⟩.
Note that, since the operators exp(−iHT ) and exp(−iH0T ) are unitary, the states
⏐⏐Ψh,in⟩ and⏐⏐Ψh,out⟩ are normalized like the states ⏐⏐Ψ(0)h ⟩. Since this is true for any function h(α), the


PDF PAGE 57 
 11 LEE–NAUENBERG THEOREM 45
states
⏐⏐Ψα,in⟩ and⏐⏐Ψα,out⟩ each form an orthonormal set of states. In other words, the in and
out states become identical to the eigenstates of the free Hamiltonian in frames translated by
a time T → −∞ or T → +∞, respectively. Thus, the physical interpretation of the (time-
independent) state
⏐⏐Ψα,in⟩ is that it encodes all the possible outcomes of an interacting system
initialized at T =− ∞ in the free state
⏐⏐Ψ(0)α ⟩. Likewise, ⏐⏐Ψα,out⟩ encodes all the possible
histories that lead to the free state
⏐⏐Ψ(0)α ⟩ atT =+ ∞. Therefore, the transition amplitude from
a stateα to a stateβ should be deﬁned as
Sβα ≡
⟨
Ψβ,out
⏐⏐Ψα,in⟩.
Note that the deﬁnition of the state
⏐⏐Ψα,in⟩ can be rewritten as
⏐⏐Ψα,in⟩ = ∫ dβ(δβα + TβαEα −Eβ +i0+/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ Ωβα
)⏐⏐Ψ(0)β ⟩, withTβα ≡⟨Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩
(δβα is the combination of delta functions and Kronecker symbols such that
∫
dβf (β)δβα =
f(α)). Inserting the deﬁnition of
⏐⏐Ψα,in⟩ inTβα, we obtain an integral equation forT:
Tβα = Vβα +
∫
dγ VβγTγα
Eα −Eγ +i0+ =
∫
dγ Vβγ Ωγα, (1.56)
withVβα ≡
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψ(0)α ⟩. This equation, known as the Lipmann–Schwinger equation, shows
how the matrix elements ofT are obtained from the matrix elements of the interaction potential
in the free basis.
11.a Given the above discussion, we have
⏐⏐Ψα,in⟩ =T →−∞ eiHT e−iH0T ⏐⏐Ψ(0)α ⟩,
which implies thatΩβα = limT →−∞
⟨
Ψ(0)β ⏐⏐eiHT e−iH0T⏐⏐Ψ(0)α ⟩. In this form, we see immedi-
ately that theΩβα’s are the matrix elements of a unitary operator.
Alternatively, we can reach the same conclusion using only the information provided in
the statement of the problem. For this, it is convenient to write
Ω ≡ 1 +Δ, T βα =( Eα −Eβ +i0+)Δβα,
⏐⏐Ψα,in⟩ =⏐⏐Ψ(0)α ⟩ + ∫ dγΔtαγ⏐⏐Ψ(0)γ ⟩ (Δtαγ ≡ Δγα).
Given the integral equation that relatesVβα andTβα and the deﬁnition of
⏐⏐Ψα,in⟩, we have also
Tβα =
⟨
Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩.
Then, the matrix element
⟨
Ψβ,in
⏐⏐V⏐⏐Ψα,in⟩ can be written in two ways, depending on whether


PDF PAGE 58 
 46 1 QUANTUM FIELD THEORY BASICS
we expand the state on the left or the state on the right:
⟨
Ψβ,in
⏐⏐V⏐⏐Ψα,in⟩ =⟨Ψ(0)β ⏐⏐V⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Tβα
+
∫
dγΔ†βγ ⟨Ψ(0)γ ⏐⏐V⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Tγα
=
⟨
Ψβ,in
⏐⏐V⏐⏐Ψ(0)α ⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
T∗αβ
+
∫
dγ
⟨
Ψβ,in
⏐⏐V⏐⏐Ψ(0)γ ⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
T∗γβ=T†βγ
Δγα.
Equating these two expressions for the matrix element leads to
T∗αβ −Tβα =
∫
dγ
(
Δ†βγTγα −T†βγΔγα
)
=( Eα −Eβ +i0+)
∫
dγ Δ†βγΔγα,
i.e.,Δ +Δ† +Δ†Δ = 0. From this relationship, we conclude that Ω = 1 +Δ is unitary.
S-matrix: The matrix element Sβα can also be expressed in terms of Tβα. In order to obtain
this relationship, let us start again from (1.55), but this time we take the limit T → +∞. Since
T>0 , we must close the integration contour in the lower half-plane. In the limit T → +∞,
the only term that survives when we apply the theorem of residues comes from the zero in the
denominator, and we get
⏐⏐Ψh,in⟩T =T →+∞ e−iH0T ⏐⏐Ψ(0)h ⟩ −2πi ∫ dαdβ h(α)e−iEβT δ(Eα −Eβ)Tβα⏐⏐Ψ(0)β ⟩
=
T →+∞
∫
dαdβ h(α)e−iEβT
(
δβα −2πiδ (Eα −Eβ)Tβα
)⏐⏐Ψ(0)β ⟩.
Alternatively, we can also write
⏐⏐Ψh,in⟩T = ∫ dα h(α)e−iEαT ⏐⏐Ψα,in⟩
=
∫
dα h(α)e−iEαT
∫
dβ
⏐⏐Ψβ,out⟩⟨Ψβ,out⏐⏐Ψα,in⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Sβα
=
T →+∞
∫
dαdβ h(α)e−iEβT Sβα⏐⏐Ψ(0)β ⟩.
(In the last line, we also used the fact that Sβα is proportional to a delta function of energy
conservation to changeEα intoEβ in the exponential.) By comparing the two formulas, we
conclude that
Sβα = δβα −2πiδ (Eα −Eβ)Tβα.


PDF PAGE 59 
 11 LEE–NAUENBERG THEOREM 47
11.b The Lipmann–Schwinger equation (1.56) can be solved iteratively, leading to the
following series in powers of the interaction potential:
Tβα = Vβα +
+∞∑
n=1
∫
dγ1 ··· dγn
VβγnVγnγn−1 ··· Vγ1α
(Eα −Eγ1 +i0+)··· (Eα −Eγn +i0+).
The physical interpretation of this expression is that the system starts in the stateα and evolves
to the stateβ, undergoing a sequence of interactions that take it through the intermediate states
γ1,γ2,...,γ n.
11.c In this formula, the matrix elements ofV are regular, and the only potential singularities
come from the poles in the other factors under the integral. However, these poles do not always
lead to a divergence in the result. This can be seen, for instance, in the following two toy
examples:
+1∫
−1
dx
x +i0+ =− iπ,
+1∫
0
dx
x +i0+ = ∞.
In these examples, we see that in order to lead to a divergence, the pole should be at one of
the endpoints of the integration domain; otherwise we may deform the integration contour
to completely avoid the pole. Another conﬁguration leading to an unavoidable divergence is
when the integrand has a pair of poles “pinching” the integration contour so that it cannot be
deformed.
Two statesα andγ may accidentally have the same energy when one varies the momentum
of a particle. However, when varying the stateγ, these accidental degeneracies occur in the
middle of the allowed domain of the variables that parameterizeγ. The corresponding pole in
(Eα −Eγ +i0+)−1 is therefore avoidable by deforming the integration contour, and this does
not lead to a divergence.
The state γ also has the same energy as α if it differs from α by one or more ultrasoft
particles. In this situation, the resulting pole in (Eα −Eγ +i0+)−1 occurs when the energy of
these extra particles goes to zero, which is on the boundary of the integration domain for γ,
and therefore produces an actual divergence in the result. Another situation whereγ has the
same energy asα is when a hard massless particle in one of the two states is replaced in the
other state by two or more collinear particles with the same total momentum. This case also
leads to a divergence, because the pole is reached on the boundary of the angular integration
domain.
In order to keep track of these two problematic situations, let us denote byD(α) the set
of states that are degenerate withα, excluding the accidental degeneracies. Consider now the
sequence of states
α → γ1 → ··· → γi−1 → γi → γi+1 → ··· → γn → β.
Each stateγi in this sequence is related to the preceding and following states by an elementary
interactionV. Obviously, in order to produce a pole, the state γi must have the same energy as
α. But for this pole to lead to a divergence, a stronger condition should be satisﬁed: the pole
must occur on the boundary of the integration domain of γi, which is made of the states in
D(γi−1) or in D(γi+1).


PDF PAGE 60 
 48 1 QUANTUM FIELD THEORY BASICS
Assume for instance that γi ∈ D(γi−1), and has the same energy as α. But this implies
thatγi−1 also has the same energy asα, which happens on a harmless zero measure subset of
the phase-space ofγi−1 unlessγi−1 itself belongs to the degeneracy set ofγi−2, D(γi−2).B y
repeating this inductive argument, we see that this divergence occurs only if all ofγ1,γ2,...,γ i
belong to D(α). If instead we make the assumption that γi ∈ D(γi+1), then it is the entire
chain γi,γi+1,...,γ n that must be in D(β) in order to have a divergence. This result is
consistent with the well-known fact that infrared divergences happen when soft photons are
attached to the external legs of a hard process, but not when one attaches the soft photon to a
hard internal line of a graph. The same is true of the divergences due to collinear splittings.
11.d We assume now that the initial and ﬁnal states are not degenerate, i.e., thatD(α) and
D(β) do not overlap. Then, we introduce projectors Pα,Pβ andP3 that project respectively on
D(α),o n D(β) and on the remaining portion of the Hilbert space. Since the union of these
sets is the complete Hilbert space, the sum of these projectors is the identity
Pα +Pβ +P3 = 1.
Moreover, we assume that the volume ofD(α) andD(β) is very small (this is controlled by
what is experimentally meant by “soft” or “collinear”) compared to the rest, implying that we
may neglect these states except when they produce a divergence. In terms of these projectors,
the matrix elementTβα can be written as
Tβα =
+∞∑
n=0
[
V
( Pα +Pβ +P3
Eα −H0 +i0+V
)n]
βα
.
This formula is still exact. The next step is to expand this expression, and to dropPα andPβ
unless they occur in conﬁgurations that produce a divergence. Thus we keep thePα’s if they
form an uninterrupted chain on the right of the product, and thePβ’s if they form a chain on
the left of the product:
Tβα =sing.
+∞∑
r,s,n=0
[(
V Pβ
Eα −H0 +i0+
)s
V
( P3
Eα −H0 +i0+V
)n( Pα
Eα −H0 +i0+V
)r]
βα
,
which can be written compactly as
Tβα =
(
U†β,out T3 Uα,in
)
βα
, with T3 ≡ V
+∞∑
n=0
( P3
Eα −H0 +i0+V
)n
,
and
Uα,in ≡
+∞∑
r=0
( Pα
Eα −H0 +i0+V
)r
,U β,out ≡
+∞∑
s=0
( Pβ
Eα −H0 −i0+V
)s
.
The factorsUα,in andUβ,out contain divergences, while the factorT3 is divergence-free.
Note now that the operatorUα,in is the restriction to the subspace D(α) of the operatorΩ
that we introduced just above (1.56), and that we have shown to be unitary. Therefore,Uα,in is


PDF PAGE 282 
 26 GROSS–NEVEU MODEL 111
26. Gross–Neveu Model The Gross–Neveu model is a (1 + 1)-dimensional quantum
ﬁeld theory withN species of massless fermions (indexed byn = 1,...,N ), with a quartic
interaction,
L ≡ i
∑
n
ψn/∂ψn + g22 ( ∑n ψnψn)2.
This quantum ﬁeld theory is a toy model for the spontaneous breaking of chiral symmetry, and
also provides an example of the technique of bosonization.
26.a Check that a valid representation of the Dirac matrices in two dimensions isγ0 = σ2,
γ1 = iσ1 (with σ1,2 Pauli matrices). Also deﬁne γ5 ≡ γ0γ1. Check that (γ5)2 = 1,
(γ5)† = γ5, {γ5,γμ} = 0 for μ = 0,1 . Show that L is invariant under ψn → γ5ψn.
Would a mass term be consistent with this symmetry?
According to the power counting, can this theory be renormalizable ind = 2?
26.b Prove the following equality:
∫
[DψDψ]ei
∫
L =
∫
[DψDψDφ]ei
∫ ∑
n ψn(i/∂−φ)ψne− i2g2 ∫φ2,
whereφ is an auxiliary scalar ﬁeld.
26.c We are now interested in the ground state of this theory, in whichφ is constant. Perform
the integration over the fermions in closed form for a constant φ, and show that the
result of this integration is a factor
exp
{
N
∫ d2p
(2π)2 ln(−p2 +φ2)
}
, withp2 ≡ p20 −p21.
26.d Using ln(A)=− ∂α(A−α)α=0, and using dimensional regularization withd = 2 −2ϵ,
show that the integral can be written as
∫ ddp
(2π)d ln(−p2 +φ2)= iφ24π(1ϵ + const +1 − lnφ2 +O(ϵ2)).
Which operator should one renormalize to eliminate the ultraviolet divergence? After
introduction of an appropriate counterterm, show that the effective potential for the ﬁeld
φ can be written as
Veff(φ)= φ22g2 + Nφ24π ( ln(φ2μ2) −1),
whereμ is a constant whose precise value depends on the ﬁnite terms included in the
counterterm besides the pole inϵ−1.
26.e Determine analytically the location of the minimum of Veff(φ). Could this answer have
been found by a perturbative expansion in powers ofg2? What are the consequences for
the fermions of having a non-zero expectation value forφ?
26.f What are the diagrams that would give the result of the above functional calculation?
Why is the answer exact in the limitN →∞ ?


PDF PAGE 283 
 112 2 FUNCTIONAL METHODS
26.a In order to verify that the proposed matrices are valid Dirac matrices in two dimensions,
we just need to verify that
{
γμ,γν} = 2gμν:
(
γ0)2 =(σ2)2 = 1, (γ1)2 =(iσ1)2 =− 1,
γ0γ1 +γ1γ0 = iσ2σ1 +iσ1σ2 = i(−iσ3)+ i(iσ3)= 0.
Deﬁningγ5 ≡ γ0γ1,w eh a v e
(
γ5)2 = γ0γ1γ0γ1 =− γ0 γ1γ1
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1
γ0 =+ 1,
(
γ5)† =( iσ2σ1)† =− iσ1σ2 =+ iσ2σ1 = γ5,
{
γ5,γμ} = γ0γ1γμ +γμγ0γ1 = 0.
(In the ﬁnal equality above, since μ is either 0 or 1, γμ commutes with one of γ0,1 and
anti-commutes with the other one.) Under the transformation ψn → γ5ψn,w eh a v e
ψn → γ5ψn,
ψn ≡ ψ†nγ0 → ψ†n γ5†γ0/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=γ5γ0=−γ0γ5
=− ψnγ5,
ψnψn → −ψnψn,(
ψnψn
)2 →(ψnψn)2,
ψnγμψn → −ψn γ5γμγ5/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−γμ
ψn = ψnγμψn,
hence the invariance of the Lagrangian. Note that a mass term is not allowed by this symmetry
sinceψnψn → −ψnψn under this transformation.
The mass dimension of the ﬁeldψn is 12 ind = 2, and therefore the mass dimension of thecoupling constant g is zero. This theory should therefore be renormalizable in two dimensions
according to the power counting.
26.b In order to check the proposed equality, we proceed by explicitly performing the
integration overφ on the right-hand side. For this, we need
− 12g2 φ2 −φ ∑
n
ψnψn =− 12g2
[
φ2 +2g2φ ∑
n
ψnψn
]
=− 12g2
[(
φ +g2 ∑
n
ψnψn
)2
−g4
( ∑
n
ψnψn
)2]
.
Then, we deﬁne φ′ ≡ φ + g2 ∑n ψnψn and trade the integration variable φ in favor
of φ′. The integral produces a constant prefactor (which we ignore), and leaves a factor
exp(g22 (∑n ψnψn)2), hence the announced equality.


PDF PAGE 284 
 26 GROSS–NEVEU MODEL 113
26.c Whenφ is a constant, we can perform the integration over the fermions explicitly. Each
pair of integralsDψnDψn produces a factor
det
(
i/∂ −φ
)
.
These factors do not depend on the index n, and there are N of them, so the N fermionic
integrations give
[
det
(
i/∂ −φ
)]N
= exp
{
N tr ln
(
i/∂ −φ)
}
= exp
{
N
∫ d2p
(2π)2 tr ln(/p −φ)
}
.
Note that the original trace was over both spacetime and the Dirac indices. In the ﬁnal equality,
we have rewritten the trace over spacetime as a trace over momentum and we keep unchanged
the trace over the Dirac indices. For the latter, we can write
tr ln(/p −φ)= ln det
(
−φi (p0 −p1)
−i(p0 +p1)− φ
)
= ln
(
φ2 −p2).
(We have used the explicit form of the Pauli matrices in the ﬁrst equality.) This gives the
announced formula.
Alternative Proof: It is possible to do this calculation without resorting to any explicit
representation of the Dirac matrices, as follows:
tr ln(/p −φ)= tr ln(−φ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=2 ln(−φ)=ln(φ2)
+tr ln(1 −/p/φ)
= ln(φ2)− ∑
n≥1
1
n tr
([/p
φ
]n)
= ln(φ2)− ∑
p≥1
1
2p tr
([/p
φ
]2p)
= ln(φ2)− ∑
p≥1
1
p
(p2
φ2
)p
= ln(φ2)+ ln(1 −p2/φ2)= ln(φ2 −p2).
(In the third line, we used the fact that/p2p+1 = p2p/p has a null trace, and therefore we keep
only the terms of even order.)
26.d Then, the integration of the momentump proceeds as follows:
∫ ddp
(2π)d ln(−p2 +φ2)=− ∂α
∫ ddp
(2π)d
1
(−p2 +φ2)α
⏐⏐⏐⏐⏐
α=0
=− i∂α
∫ ddpE
(2π)d
1
(p2E +φ2)α
⏐⏐⏐⏐⏐
α=0
=− i∂α
φd−2α
(4π)d/2
Γ (α − d2 )
Γ (α)
⏐⏐⏐⏐⏐
α=0
.
Note thatΓ (α) ≈ α−1 whenα → 0. Therefore, we have


PDF PAGE 285 
 114 2 FUNCTIONAL METHODS
∂α
F(α)
Γ (α)
⏐⏐⏐⏐⏐
α=0
= F(0),
and we obtain
∫ ddp
(2π)d ln(−p2 +φ2)=− i φd(4π)d/2Γ (−d2 )=− iφ2φ−2ϵ(4π)1−ϵ Γ (−1 +ϵ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1ϵ +const+O(ϵ)
= iφ2
4π
[1
ϵ + const +1 − ln(φ2)+ O(ϵ2)]. (2.35)
(We could have written const +1 as some unique constant, but it will be convenient later to
pull out this 1.) The pole in ϵ−1 can be removed by renormalizing the operator φ2. More
precisely, we introduce the counterterm
−iφ2
4π
[1
ϵ + const′
]
,
where const′ is a ﬁnite constant that may be subtracted along with the poleϵ−1. Combining
the original term inφ2 with the result (2.35) and the counterterm, we get
φ2
2g2 + Nφ24π ( ln(φ2μ2) −1)
for the sum of the terms inφ2 inside the exponential.
26.e The derivative of this effective potential is given by
∂
∂φVeff(φ)= 2φ
[ 1
2g2 + N4π ln(φ2μ2)].
This derivative vanishes atφ = 0, but this is a local maximum. The other zero of the derivative
is at
φ∗ ≡ μ exp
(
− πg2N).
One may check that this is a local minimum. Note that the location of this minimum depends
on the renormalization scale, but the minimum is always there, no matter which scale we
choose. Note also that this minimum is non-perturbative since its value is a non-analytic
function of the couplingg (more precisely, it is a function whose Taylor coefﬁcients atg = 0
are all zero). Because of the couplingψnφψn, and the non-zero expectation value of the scalar
ﬁeld, the fermions become massive in the ground state of this theory (this is similar to the
Higgs mechanism), and the chiral symmetry is spontaneously broken.
26.f Diagrammatically, the determinant resulting from the integration over the fermion ﬁelds
corresponds to the sum of all the diagrams with one fermion loop, dressed by insertions of the
scalar ﬁeldφ. By its position inside the exponential, N acts in a similar way to ¯h−1. Taking
the limitN → +∞ has the same effect as taking the limit ¯h → 0, namely eliminating all the
higher-order corrections. For this reason, the results we have derived in this problem do not
receive any higher-order corrections whenN is very large.


exit_code=0
```

### 2026-11-16T17:43:44.129125+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in [61]+list(range(322,326))+list(range(364,368))]'
```

```text

PDF PAGE 61 
 12 CLASSICAL EXTERNAL FIELD APPROXIMATION 49
also unitary if restricted toD(α), which means that
Uα,in Pα U†α,in = Pα,U β,out Pβ U†β,out = Pβ.
(We have also written an analogous relationship forUβ,out.) Then, summing the squared matrix
elements over all the states degenerate withα andβ, we obtain
∑
a∈D(α),b∈D(β)
⏐⏐Tba⏐⏐2 = ∑
a∈D(α),b∈D(β)
(
U†β,out T3 Uα,in
)
ba
(
U†α,in T†3 Uβ,out
)
ab
= tr
(
Uβ,out Pβ U†β,out T3 Uα,in Pα U†α,in T†3
)
= tr
(
Pβ T3 Pα T†3
)
=
∑
a∈D(α),b∈D(β)
⏐⏐(T3)ba⏐⏐2,
which is a ﬁnite quantity since it contains only the ﬁnite operator T3. In the second line, we
have rewritten the sum over the states inD(α) and D(β) in the form of a trace by introducing
the appropriate projectors, and we have used the cyclic invariance of the trace to reorder the
factors.
This result, established by Lee and Nauenberg, shows that ﬁnite cross-sections are obtained
provided one sums over all the initial and ﬁnal degenerate states. This is rather natural
in quantum mechanics since all these states are undistinguishable in practice, given the
unavoidable limited resolutions (in energy and in angle) of any detector.
12. Classical External Field Approximation The goal of this problem is to study the
scattering between an electron of charge −e and a large atomic nucleus of chargeZe, and to
show that, in the limit of a recoilless nucleus at rest, the nucleus can be approximated by its
classical Coulomb potential.
12.a Why are multiple scatterings important at largeZ?
12.b We are interested in the limit where the momentum exchangeski are soft. Why is this
the relevant limit for a scattering at large impact parameter? How can we simplify the
treatment of the nucleus in this limit?
12.c Express the lower part A
μσ1···μσn
ss′ (P, P′;{kσi}) of the graph shown below (surroundedby a box) in this limit, for an arbitrary number of exchanged photons.
k1 k2 k3 k4 k5 k6
123456
σ1 σ2 σ3 σ4 σ5 σ6
PP '
Perform the sum explicitly over all the permutationsσ of the attachments of the photons
to the nucleus, in order to obtain
∑
σ∈Sn
A
μσ1···μσn
ss′ (P, P′;{kσi})
≈
ki≪P
2EP δss′ (2π)3δ(P + ∑ki −P′) ∏
i
2π (−iZe)Pμi δ(P·ki).


PDF PAGE 322 
 37 CLASSICAL NON-ABELIAN PARTICLES AND THE WONG EQUATIONS 151
expectation value of a product of Wilson loops amounts to connecting the ﬁelds attached to the
loops in all possible ways, according to the rules deﬁned by the Yang–Mills actionS[A]. In the
case of the double loop shown in the preceding ﬁgure, there are conﬁgurations of these links
that do not mix the two loops. These conﬁgurations correspond in fact to the product of the
expectation values of the two traces:
⟨
tr
(
W[A;γxy]
)⟩⟨
tr
(
W[A;γyx]
)⟩
= ··· +
γxy
γyx
+··· = O(N2).
(In the graphical representation, we have slightly displaced the loops to highlight the fact that
there are two separate traces.) In contrast, links that connect the two loops contribute to the
“correlated” term:
⟨
tr
(
W[A;γxy]
)
tr
(
W[A;γyx]
)⟩
−
⟨
tr
(
W[A;γxy]
)⟩⟨
tr
(
W[A;γyx]
)⟩
=
γxy
γyx
+··· = 12
γxy
γyx
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
O(N)
− 12N
γxy
γyx
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
O(N)
+··· .
Therefore, we see that the correlated part of the double trace is only of order N, and in the
large-N limit we have
⟨
tr
(
W[A;γxy]
)
tr
(
W[A;γyx]
)⟩
=
N→+∞
⟨
tr
(
W[A;γxy]
)⟩⟨
tr
(
W[A;γyx]
)⟩
.
In this limit, the loop equation becomes
∂μx
δ
⟨
1
N tr
(
W[A;γ]
)⟩
δσμν(x) =N→+∞−ig2N2
∫
γ
dyν δ(x−y)
⟨
1
N tr
(
W[A;γxy]
)⟩⟨1
N tr
(
W[A;γyx]
)⟩
.
This equation, which is a closed equation for expectation values of traces of Wilson loops, is
known as the Makeenko–Migdal equation. In this ﬁnal form, we have normalized each trace
by a factor N−1 in order to have quantities of order one in the fundamental representation.
With this normalization, the prefactor of the second term contains the combinationg2N, called
the ’t Hooft coupling. The limit N → +∞ we have considered in this derivation in general
assumes that the limit is taken whileg2N is kept ﬁnite.
Source: Makeenko, Y . M. and Migdal, A. A. (1979),Phys Lett B 88: 135.
37. Classical Non-Abelian Particles and the Wong Equations The goal of this problem
is to extend to the non-Abelian case the concept of a classical particle that moves along
a trajectory xμ(t). This is useful in situations where the classical approximation provides
the leading answer, for instance in the calculation of hard thermal loops in QCD at ﬁnite
temperature (see Problem 74).


PDF PAGE 323 
 152 3 NON-ABELIAN FIELDS
37.a First, consider the Abelian case. Recall the deﬁnition of the momentumpμ of the particle
(assume it is massive, with a mass m), and the expression for dpμ/dt given by the
Lorentz force. Write the electromagnetic current created by this classical particle, and
check that it is conserved.
37.b Write down a non-Abelian generalization of the Lorentz force, introducing a “color
charge”Qa in place of the electrical chargee. Can Qa be gauge invariant? If not, what
is its transformation law?
37.c CanQa be constant when the particle moves through an external color ﬁeld?
37.d Write down the non-Abelian current generated by the moving particle. What should its
conservation equation be? Show that this conservation equation implies the following
equation of motion forQa:
dxμ
dt
[
Dμ,Q
]
= 0 (Q ≡ Qataf ).
37.a First, let us recall the conservation of the electromagnetic current in QED:
Jμ(x) ≡ eψγμψ, ∂ μJμ = 0,
which follows from the equation of motion of the ﬁeld operator ψ. In this equation, the
current is a quantum operator. However, in this case, it is well known how to obtain a classical
description of the electromagnetic current in terms of classical charged particles. Let us
illustrate this for a single point-like particle of chargee and massm. We denote byxμ(t) the
worldline of this particle, parameterized by its proper time. Its momentum is given by
pμ = mdxμ
dt ,
whose equation of motion is driven by the Lorentz force:
dpμ
dt = eFμν dxνdt . (3.34)
The electromagnetic current it produces can be written as
Jμ ≡ e
∫
dt dxμ
dt δ(x −x(t)).
(In this compact notation, keep in mind that the delta function is in fact a product of four delta
functions, one for each dimension of spacetime.) The veriﬁcation that this current is conserved
goes as follows:
∂μJμ = e
∫
dt dxμ
dt ∂μδ(x −x(t))/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
− ddtδ(x−x(t))
= 0.
Note an implicit assumption, crucial in obtaining this conservation law: the electrical charge
of the particle is time-independent (otherwise, an integration by parts would give a non-zero
integrand proportional to the time derivative ofe). This is of course very trivial: the electro-
magnetic current of the particle is conserved precisely because electrical charges are constants.


PDF PAGE 324 
 37 CLASSICAL NON-ABELIAN PARTICLES AND THE WONG EQUATIONS 153
37.b Now, we would like to generalize the concept of classical particle to particles that carry
a non-Abelian charge. The ﬁrst equation,
pμ = mdxμ
dt ,
is of course the same. Then, we would like to write an equation for the time derivative of the
momentum, involving the non-Abelian ﬁeld strength. Sincedpμ/dt is anSU(N) scalar, we
want a scalar on the right-hand side, not a matrix. Then comes the issue of gauge invariance:
dpμ/dt describes the trajectory of the particle, and therefore should be gauge invariant, while
Fμν is not. Taking the trace ofFμν gives a gauge invariant quantity, but this cannot be correct
since the trace is zero. These considerations suggest that we generalize (3.34) as follows in the
non-Abelian case:
dpμ
dt = 2 tr
(
QFμν) dxν
dt , (3.35)
where Q is a matrix-valued “charge” (in the same representation of the Lie algebra as Fμν).
For the right-hand side to be gauge invariant,Q should be gauge-dependent and transform in
the same way as the ﬁeld strength:
Fμν → Ω† Fμν Ω, Q → Ω† QΩ.
The prefactor2 on the right-hand side was chosen with the fundamental representation in mind,
so that we also have
dpμ
dt = QaFμνa dxνdt .
37.c Because of its transformation law and because a gauge transformationΩ can depend
on spacetime, Q should be regarded as a spacetime-dependent object. Moreover, since Q
describes the charge of a colored particle, and since the ﬁelds with which it may interact
during its propagation themselves carry color, we expect thatQ should evolve according to the
background gauge ﬁeld in which the particle propagates.
37.d In order to derive the equation of motion for Q, let us ﬁrst deﬁne the non-Abelian
current by mimicking the QED deﬁnition:
Jμ(x) ≡
∫
dt Q(x(t)) dxμ
dt δ(x −x(t)). (3.36)
The only notable modiﬁcation is that the charge Q is evaluated at the current point on the
trajectory of the particle, to account for its spacetime dependence inherited from gauge
transformations. Note also that this current is matrix-valued, and not gauge invariant. It


PDF PAGE 325 
 154 3 NON-ABELIAN FIELDS
transforms as
Jμ(x) → Ω†(x)Jμ(x)Ω(x).
For this classical current to be a good replacement for the quantum one, it should fulﬁll the
same covariant conservation equation,
[
Dμ,Jμ] = 0.
(The covariant derivative makes this conservation law gauge invariant.) Therefore, let us
evaluate the covariant derivative of the current deﬁned in (3.36):
[
Dμ,Jμ] = ∫ dt( −ig[Aμ,Q (x(t))] dxμdt δ(x −x(t))
+Q(x(t)) dxμ
dt ∂μδ(x −x(t))/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
− ddtδ(x−x(t))
)
=
∫
dt
(dQ(x(t))
dt −igdxμdt [Aμ,Q (x(t))])δ(x −x(t)).
Requesting that this covariant derivative vanish leads to the following equation of motion for
the non-Abelian chargeQ:
dQ(x(t))
dt −igdxμdt [Aμ,Q (x(t))]/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
dxμ
dt [Dμ,Q]
= 0.
This equation, known as the Wong equation forQ, describes the variation of the color charge
of the particle as it moves through a given background gauge ﬁeld. Note that even a very soft
ﬁeld (i.e., whose non-zero Fourier modes are much smaller than the momentum of the particle),
which does not alter the straight motion of the particle, will change its color. Finally, observe
that this equation may also be written as
dxμ
dt
(
Dadjμ )abQb = 0.
In other words, the covariant derivative ofQ projected along the trajectory of the particle is
vanishing (this equation of motion is reminiscent of the differential equation that deﬁnes a
Wilson line).
Source: Wong, S. K. (1970), Nuovo Cimento A 65: 689.
38. Wong Equations from the Worldline Formalism The goal of this problem is to obtain
the Wong equation derived in Problem 37 by using the worldline formalism. Consider a colored
complex scalar ﬁeld (which ultimately we would like to describe as a colored classical particle)
embedded in a non-Abelian gauge ﬁeldAμ.


PDF PAGE 364 
 48 INSTANTONS AND TUNNELING IN QUANTUM MECHANICS 193
47.c Consider now the speciﬁc case of QCD, for which the ﬁrst two coefﬁcients of the β
function are given in the statement of the problem. The condition β0 <0 is equivalent to
β0 <0 ⇐⇒ Nf < 11N2 (= 16.5 forN = 3).
The conditionβ1 >0 is equivalent to the following condition onNf:
β1 >0 ⇐⇒ Nf > 34N313N2 −3 (≈ 8 forN = 3).
Thus, the infrared ﬁxed point cannot be realized with the six families of quarks that are known
to exist in nature. Note that the value of the coupling g∗ at the infrared ﬁxed point is
g2∗ = 16π2(11N −2Nf)Nf(6Cf +10N)− 34N2.
This ratio decreases as Nf increases at ﬁxedN (it goes to zero at the upper end of the allowed
range of values ofNf, and to inﬁnity at the lower end of the range ofNf). The value of Nf at
which this critical coupling is equal to unity is given by
Nf = 88π2N +17N216π2 +3Cf +5N (≈ 15.6 forN = 3).
Therefore, the infrared ﬁxed point is perturbative only at the largest allowed value of the
number of ﬂavors, very close to the value where the theory ceases to be asymptotically free.
Source: Banks, T. and Zaks, A. (1982), Nucl Phys B 196: 189.
48. Instantons and Tunneling in Quantum Mechanics This is the ﬁrst of a series
of three problems devoted to the role of instantons in classifying the vacua of Yang–Mills
theory. In this ﬁrst instalment, we start with a warmup in non-relativistic mechanics, and
show that instanton-like solutions of the classical equations of motion provide a semi-classical
approximation of quantum tunneling amplitudes. Consider a one-dimensional double-well
potentialV(x) ≡ λ(x2 −x2∗)2, which has two degenerate minima located atx = ±x∗.
48.a Recall the path integral expression for a transition amplitude from −x∗ to +x∗, A ≡⟨
+x∗
⏐⏐e−iHt⏐⏐ −x∗⟩. Explain why there is no classical path making the action extremal
in this path integral.
48.b Perform a Wick rotation of the time variable by deﬁningτ = it , and write the resulting
expression for the transition amplitude.
48.c Show that a saddle point approximation is now possible, and that the leading behavior
of the amplitude is given by the quantum mechanical analogue of instantons. Solve
the imaginary time equation of motion to obtain this dominant classical path, and
calculate the corresponding action. Are there other minima of the action that would give
subleading contributions?


PDF PAGE 365 
 194 3 NON-ABELIAN FIELDS
48.d The preceding calculation does not give the prefactor inA(t). How can it be obtained?
Without doing an explicit calculation, explain why this prefactor is proportional to the
timet. What is the range of t where this semi-classical approximation is valid? What
contributions should one include to extend it to larger times?
48.e Let us denote by
⏐⏐ψ0,1,2,...⟩ the eigenstates of the Hamiltonian, with energies E0,1,2,....
Express the transition amplitude A(t) in terms of these eigenstates. Use this alternative
representation to show that the tunneling amplitudeA(t) is approximately proportional
to the splitting between the energies of the ﬁrst two levels,δE ≡ E1 −E0.
48.a The transition amplitude from the position −x∗ at time0 to the position +x∗ at timet
is given by
A(t) ≡
⟨
+x∗
⏐⏐e−iHt⏐⏐ −x∗⟩ = ∫
x(0)=−x∗
x(t)=+x∗
[
Dx(t)
]
eiS[x], (3.54)
where the action S[x] reads (for a massm ≡ 1)
S[x] ≡
∫t
0
dt′
( ˙x2(t′)
2 −V(x(t′))).
Classical trajectories are extrema of the action S[x] that satisfy ¨x +V′(x)= 0. Multiplying by
˙x leads to 12 ˙x2 +V(x)= const, i.e., energy conservation. Therefore, a classical particle thatstarts with no velocity from the bottom of one of the potential wells cannot reach the other
well. Because of the absence of a classical solution with the appropriate boundary conditions,
the path integral (3.54) is not dominated by any path in particular, and its value is the result of
interferences between many paths contributing comparably.
48.b However, we can simplify this problem by deﬁningτ ≡ it . The path integral (3.54)
becomes
A(t)=
∫[
Dx(τ)
]
e−SE [x],
with a Euclidean action equal to
SE [x] ≡
∫it
0
dτ′
( ˙x2(τ′)
2 +V(x(τ′))/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−U(x(τ′))
)
.
(Now the dot denotes a derivative with respect toτ.) This action has the same form as before,
if we interpret it as a ﬁctitious particle moving in the inverted potentialU(x) ≡ −V(x) (see
Figure 3.10).


PDF PAGE 366 
 48 INSTANTONS AND TUNNELING IN QUANTUM MECHANICS 195
x
V(x)
−x* +x*
x
U(x)
−x* +x*
Figure 3.10 Left: double-well potential. Right: classical solution of the Euclidean time
equation of motion, that connects the two extrema.
48.c Because the potentialU is ﬂipped upside down, the Euclidean action has extremal paths
connecting −x∗ to +x∗, which are the quantum mechanical analogue of instantons (recall that
instantons are gauge ﬁeld conﬁgurations that make the Euclidean action extremal). Solving the
Euclidean equation of motion is best done by starting from “energy conservation,”
˙x2
2 +U(x)= 0,
which can be rewritten as
dx
x2∗ −x2 =
√
2λdτ.
This can be solved by
x(τ)= x∗ tanh
(ω
2 (τ −τ0)
)
,
where ω ≡
√
8λx2∗ and where τ0 is an integration constant that deﬁnes when this solution
reaches the position x = 0. The value of the Euclidean action for this solution is SE [x]=
ω3/(12λ). Note that although this solution connects −x∗ to +x∗ in an inﬁnite Euclidean
time, the effective duration of the transition is ω−1 ∼ λ−1/2. Therefore, this path is a good
approximation of an extremal path (away from the transition region, this trajectory stays an
inﬁnite amount of time at −x∗ and at +x∗, but these parts of the trajectory do not contribute to
the action) for any transition durationt ≫ ω−1, and we ﬁnd
A(t) ∼
t≫ω−1
e−ω3/(12λ).
There are other extrema of the action. The classical trajectory that gives the next-to-lowest
minimum starts at −x∗ and goes to +x∗, then back to −x∗, and ﬁnally returns to +x∗. The
action of this “triple instanton” is three times the action we have previously obtained, and
therefore its contribution to the transition amplitude is considerably suppressed whenλ ≪ 1
since it enters in an exponential,
e−3ω3/(12λ) ≪ e−ω3/(12λ).


PDF PAGE 367 
 196 3 NON-ABELIAN FIELDS
48.d At this point, we have only obtained the leading dependence of the transition amplitude
on the coupling constant λ, but we know nothing about the prefactor. In particular, we
also do not control the dependence of A(t) on the duration t. This prefactor would be
obtained by integrating over the ﬂuctuations around the extremal trajectory, which in a ﬁrst
approximation is a Gaussian integral. Because the instanton solution has a free parameter τ0,
these Gaussian ﬂuctuations have a ﬂat direction (along which the action does not increase),
which corresponds to ﬂuctuations that merely amount to changing the value of τ0. The
integration of the ﬂuctuations along this direction therefore leads to a factor
∫t
0 dτ0 = t, andthe prefactor due to ﬂuctuations is proportional to the duration:
A(t) ∼
t≫ω−1
ωte −ω3/(12λ).
Obviously, the modulus of A(t) should not be larger than 1 (since its square is a transition
probability). Therefore, the validity of this expression is certainly limited by
1 ≪ ωt ≪ eω3/(12λ).
For times comparable to or larger than the upper bound, we need to take the multi-instanton
transitions into account, since they will provide corrections in powers ofωte−ω3/(12λ) and their
summation to all orders will tame the large time behavior of the single-instanton contribution.
48.e If the eigenstates of the Hamiltonian are
⏐⏐ψ0,1,2,...⟩, we can write the transition amplitude
as follows:
A(t)=
∑
m,n
⟨
+x∗
⏐⏐ψm⟩⟨ψm⏐⏐e−iHt⏐⏐ψn⟩/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
δmn e−iEmt
⟨
ψn
⏐⏐ −x∗⟩
=
∑
m
⟨
+x∗
⏐⏐ψm⟩⟨ψm⏐⏐ −x∗⟩e−iEmt
≈
⟨
+x∗
⏐⏐ψ0⟩⟨ψ0⏐⏐ −x∗⟩e−iE0t +⟨ +x∗⏐⏐ψ1⟩⟨ψ1⏐⏐ −x∗⟩e−iE1t,
where we keep only the lowest two eigenstates in the approximation. Recall now that in a
symmetric double-well potential (with well-separated wells), the ground state and the next-to-
lowest state are the symmetric and antisymmetric combinations of the Gaussian packetsψ±
that would give the ground state of each separate well:
ψ0(x)= 1√2(ψ+(x)+ ψ−(x)),ψ 1(x)= 1√2(ψ+(x)− ψ−(x)).
Moreover, when the wells are well separated, we have ψ+(−x∗) ≈ 0 and ψ−(+x∗) ≈ 0.
Therefore, the above transition amplitude becomes
A(t) ≈ i2ψ+(+x∗)ψ−(−x∗)e−iE0t (E1 −E0)t.
Thus, this formula establishes a direct connection between the tunneling amplitude and the ﬁrst
level splitting of the Hamiltonian. In particular, we see that the symmetric and antisymmetric
lowest-energy states are degenerate if the tunneling probability is zero. (This result is not
speciﬁc to instantons; another area where it is relevant is the discussion of spontaneous
symmetry breaking.)


exit_code=0
```

### 2026-11-16T17:43:59.835253+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in range(346,355)]'
```

```text

PDF PAGE 346 
 43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 175
χ = 2 χ = 1 χ = 0 χ = −1
Figure 3.6 Euler characteristics of polytopes with faces removed (indicated as hatched
triangles).
Figure 3.7 Deformation of a polytope with two holes into a torus. The Euler characteristic
does not change in the process.
remove two faces in order to create two holes, we haveδχ =− 2, etc. In Figure 3.6, we
have indicated the removed faces by hatched areas. Note that removing just the face, or
the face as well as the vertices and edges on the boundary, leads to the sameχ (indeed,
the boundary of a triangle has equal numbers of vertices and edges).
• If we create two holes and then bend the polytope to glue the boundaries of these holes,
we also haveδχ =− 2, as illustrated in Figure 3.7 (we show three stages of this process;
the Euler characteristic is equal to χ = 0 at all stages). However, this manipulation
creates a handle in the polytope: for instance, it transforms a sphere into a torus with
one handle, a torus with one handle into a torus with two handles, etc. Therefore, the
Euler characteristic of a closed surface withh handles isχ = 2 −2h.
Thus, the formula (3.49) provides a one-to-one correspondence between the order in N of
a vacuum graph (after we have absorbed a factor N in the deﬁnition of λ) and the genus of
the surface on which the graph may be embedded without line crossings. If we consider the
limit of largeN at ﬁxedλ, the leading graphs are those that can be embedded on a sphere (the
standard QFT terminology for these graphs is to call them planar graphs, because the sphere is
topologically equivalent to a plane if we remove its north pole; the large-N limit is also called
the planar approximation), the next-to-leading ones are those that can be embedded on a torus,
etc.
43. Soft Radiation and Antenna Effects in QCD The goal of this problem is to study soft
gluon radiation from a hard QCD process. The main result is that when a soft gluon is emitted
from a quark–antiquark pair in a color-singlet state, its emission at large angles is forbidden.


PDF PAGE 347 
 176 3 NON-ABELIAN FIELDS
43.a Generalize the equation (1.50) in the statement of Problem 10 for the emission of a soft
gluon off a massless quark or antiquark in the ﬁnal state.
43.b Consider now the case where the only colored particles in the hard process are a quark–
antiquark pair in a singlet state. Show that the squared amplitude for producing an extra
soft gluon is the square of theq ¯q production amplitude times the following factor:
I ≡ 2g2 Cf p·q(p·k)(q·k),
wherep,q are the momenta of the quark and antiquark, andk that of the gluon.
43.c Check that the above expression is singular when the gluon is aligned with the quark or
with the antiquark. Rewrite it as a sum of two terms, I ≡ Iq +I¯q, such thatIq (resp. I¯q)
is singular only in the direction of the quark (resp. antiquark). Note: these conditions do
not uniquely determine the splitting; try to ﬁnd the most symmetrical one.
43.d Choose the quark momentum as polar direction and integrate Iq over the azimuthal
angle. Show that this integral vanishes if the gluon polar angle is larger than the angular
separation between the quark and antiquark. Similarly, studyI¯q with respect to the polar
direction deﬁned by the direction of the antiquark.
43.e Does this result hold in the case where the quark–antiquark pair is produced from a
gluon, i.e., is in an octet state?
43.a Consider a QCD scattering amplitude with a massless quark and a massless antiquark
in the ﬁnal state,
Mri,sjq, ¯q (p,q,... ).
(We only explicitly indicate the quark and the antiquark in this notation. The indicesi andj
are the color indices of the quark and antiquark,r ands their spins, andp,q their momenta.)
In order to exhibit the corresponding spinors, we may write
Mri,sjq, ¯q (p,q,... )= ur(p)Aijq, ¯q(p,q,... )vs(q).
Let us now attach a gluon of momentumk, polarizationλ and color indexa to the outgoing
quark line. This gives the following amplitude:
Mri+λa,sjq+g, ¯q (p,q,k,... )
= ur(p)
(
−ig(taf )ii′γμϵλμ(k))i(/p +/k)(p +k)2Ai′jq, ¯q(p +k,q,... )vs(q)
≈
k≪p,q
g(taf )ii′ p·ϵλ(k)p·k ur(p)Ai′jq, ¯q(p,q,... )vs(q)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Mri′,sjq, ¯q (p,q,... )
.
In the last line, we have assumed the gluon to be soft compared to the quark, and we have
usedur(p)γμ/p = 2pμ ur(p) (thanks to the Dirac equation satisﬁed by the massless spinor).


PDF PAGE 348 
 43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 177
Likewise, we can attach the soft gluon to the outgoing antiquark:
Mri,sj+λaq, ¯q+g (p,q,k,... )
= ur(p)Aij′q, ¯q(p,q +k,... ) −i(/q +/k)(q +k)2 ( −ig(taf )j′jγμϵλμ(k))vs(q)
≈
k≪p,q
−g(taf )j′jq·ϵλ(k)q·k ur(p)Aij′q, ¯q(p,q,... )vs(q)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Mri,sj′q, ¯q (p,q,... )
.
43.b If we assume that the quark–antiquark pair is in a color-singlet state (this is always true
if they are the only colored particles in the process), we may write
Aijq, ¯q(p,q,... ) ≡ δij Aq, ¯q(p,q,... ).
Summing the two terms previously obtained, we obtain the following expression for a q ¯qg
ﬁnal state:
Mri,sj,λaq, ¯q,g (p,q,k,... )≈g(taf )ij
[p·ϵλ(k)
p·k −q·ϵλ(k)q·k/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Jμϵλμ
]
×ur(p)Aq, ¯q(p,q,... )vs(q).
(3.50)
Note that the currentJμ contracted into the gluon polarization vector satisﬁes an Abelian-like
Ward–Takahashi identity,
kμ
[ pμ
p·k − qμq·k] = 0,
which ensures the gauge invariance of the amplitude (since a gauge transformation modiﬁes
the polarization vector by a term proportional tokμ).
At this stage, squaring the above amplitude and summing over colors and the gluon
polarizations leads to
∑
ija,λ
⏐⏐⏐Mri,sj,λaq, ¯q,g (p,q,k,... )⏐⏐⏐2
≈ g2 (taf )ij(ta∗f )ij
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
tr (taf taf )=NCf
JμJν
( ∑
λ
ϵλμϵ∗λν
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−gμν+terms inkμ,ν
)⏐⏐⏐ur(p)Aq, ¯q(p,q,... )vs(q)⏐⏐⏐2
= 2g2Cf p·q(p·k)(q·k)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ I
×N
⏐⏐⏐ur(p)Aq, ¯q(p,q,... )vs(q)⏐⏐⏐2
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
∑
i,j
⏐⏐Mri,sjq, ¯q (p,q,... )⏐⏐2
.


PDF PAGE 349 
 178 3 NON-ABELIAN FIELDS
43.c Obviously, the factorI is singular ifp·k = 0 orq·k = 0. Consider the ﬁrst of these
conditions,
0 = EpEk(1 − cosθpk),
whereθpk is the angle between the3-momenta of the quark and of the gluon. Therefore, this
condition is realized when the gluon is emitted collinearly to the quark (note that there would
be no singularity if the quark were massive). Likewise, the conditionq·k = 0 is realized when
the gluon is emitted in the direction of the antiquark. These singularities are called collinear
singularities. The residues at the poles corresponding to the conditions p·k = 0 orq·k = 0
can be obtained easily:
p·q
(p·k)(q·k) = EpEk(p·k) + ﬁnite terms whenθpk → 0,
p·q
(p·k)(q·k) = EqEk(q·k) + ﬁnite terms whenθqk → 0.
This suggests that we writeI = Iq +I¯q, with
Iq ≡ g2Cf
[
p·q
(p·k)(q·k) − EqEk(q·k) + EpEk(p·k)
]
,
I¯q ≡ g2Cf
[
p·q
(p·k)(q·k) + EqEk(q·k) − EpEk(p·k)
]
.
(This decomposition is not unique, as we may subtract some ﬁnite terms along with the poles.)
By construction, Iq is ﬁnite when k ‖ q and I¯q is ﬁnite when k ‖ p, and their sum is trivially
equal to I. Note a caveat here: although it is tempting to interpret the factors Iq, ¯q as giving the
gluon emission off the quark and the antiquark, respectively, this interpretation is not robust
because these two quantities are not gauge invariant independently (only their sum is).
43.d Consider now the ﬁrst quantity, Iq. In this case, it is convenient to use spherical
coordinates with a polar axis alongp. The various vectors involved in the expression forIq
have the following Cartesian coordinates:
p =
⎛
⎜⎝ 00
Ep
⎞
⎟⎠, q =
⎛
⎜⎝sinθqp0
cosθqp
⎞
⎟⎠, k =
⎛
⎜⎝sinθpk cosφsinθpk sinφ
cosθpk
⎞
⎟⎠,
so that


PDF PAGE 350 
 43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 179
p
q
Figure 3.8 Allowed regions (illustrated by the two disks) for the emission of a soft gluon from
a quark–antiquark dipole in a singlet color state.
Iq = 1E2k(1 − cosθpk)
[
cosθpk − cosθqp
1 − cosθqp cosθpk − sinθqp sinθpk cosφ +1
]
.
Let us now perform the integration over the azimuthal angleφ. This integral is of the form
∫2π
0
dφ
a −b cosφ = 2πθ (|a| −|b|) sign (a)√a2 −b2.
This formula, after some trigonometric manipulations, leads to
∫2π
0
dφ Iq = 2πE2k(1 − cosθpk)
[
cosθpk − cosθqp
| cosθpk − cosθqp| +1
]
= θ(θqp −θpk) 4πE2k(1 − cosθpk).
Quite remarkably, the azimuthal integral ofIq vanishes if the emission angleθpk of the gluon
with respect to the quark is larger than the opening of the cone formed by theq ¯q pair. The same
conclusion holds for the integral of I¯q, but this time with a polar axis along the momentum
q of the antiquark. The pattern of allowed soft gluon emission is shown in Figure 3.8. Let
us rephrase more precisely the caveat mentioned earlier: Iq, ¯q cannot be interpreted as the
emission spectra off the quark and antiquark, respectively. Indeed, the emission of a gluon off
a quark does not suffer any angular restriction. The angular veto we are observing here is in
fact due to a destructive interference between the emissions by the quark and by the antiquark.
Let us mention a paradox: the soft radiation factor J is positive deﬁnite, and it is therefore
surprising to ﬁnd regions with seemingly no radiation. But the quantities Jq and J¯q into which
we decompose J are not positive deﬁnite, which allows their azimuthal integrals to be zero for
some polar angles. The paradox is resolved by noting that the polar axis is not the same for the
integrals ofJq andJ¯q (therefore, the sum of these integrals is not the integral ofJ).


PDF PAGE 351 
 180 3 NON-ABELIAN FIELDS
Semi-quantitative Interpretation: The same collimation effect exists in QED for photon
emission off an e+e− pair, where it is known as the Chudakov effect. This suppression of
gluon radiation at angles larger than the opening of the quark–antiquark pair can be understood
semi-quantitatively as follows. According to the uncertainty principle, the virtuality of the line
of momentump +k just before the gluon emission vertex deﬁnes the gluon “formation time,”
t−1f ≡ Ep +Ek −Ep+k ≈ (p +k)22Ep = Ek(1 − cosθpk) ≈θpk≪1 12Ekθ2pk.
During this time, the quark–antiquark pair grows to a transverse size
r⊥ = tfθpq.
Moreover, the gluon wavelength (E−1k ), projected on the plane orthogonal to the quark momen-tum, reads
λ⊥ = 1Ek sinθpk ≈θpk≪1 1Ekθpk.
For the gluon to be emitted without suppression, its transverse wavelength must be smaller than
the size of the quark–antiquark dipole. Otherwise, the gluon cannot resolve the quark–antiquark
pair, and sees only its total charge, which is zero in the present case since we have assumed the
pair to be in a singlet state. This condition reads
1
Ekθpk
≲ r⊥ ⇔ θpk ≲ θpq.
This property, known as angular ordering in the context of QCD, can be used to formulate
gluon emission in the form of “parton cascades” in which each quark, antiquark or gluon has a
certain probability of emitting a new gluon. The effect of quantum interference, which would
in principle preclude such a probabilistic description, is taken into account by vetoing emission
at large angles.
43.e Let us now consider the case where the quark–antiquark pair is produced in an octet
state, i.e., from a gluon. In this case, the above qualitative argument fails: even if the produced
gluon does not resolve the pair, it sees a non-zero total charge, and there should not be any
suppression of its emission (in fact, we expect that the emission at large angle should be
equivalent to the emission by the gluon that produced the quark–antiquark pair). First, let us
rewrite the analogue of (3.50) in the case where the quark–antiquark pair is not assumed to be
singlet:
Mri,sj,λaq, ¯q,g (p,q,k,... ) ≈ gur(p)[p·ϵλ(k)p·k (taf )ii′Ai′jq, ¯q(p,q,... )
−q·ϵλ(k)q·k Aij′q, ¯q(p,q,... )(taf )j′j
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ Jμijaϵλμ(k)
]
vs(q).
Let us check the Ward–Takahashi identity on the currentJμija:
kμJμija =[taf ,Aq, ¯q(p,q,... )]ij.
We can see a difﬁculty here: this current is conserved only when Aq, ¯q is singlet (indeed,
requesting that the commutator on the right-hand side vanish for all generatorstaf implies by
Schur’s lemma thatAq, ¯q must be proportional to the identity).


PDF PAGE 352 
 43 SOFT RADIATION AND ANTENNA EFFECTS IN QCD 181
The reason for this problem is that it is impossible for the quark–antiquark pair to be
non-singlet if the quark and antiquark are the only colored particles in the hard process.
Therefore, we must start from a hard process that has at least one gluon in addition to theq ¯q
pair:
Mri,sj,λaq, ¯q,g (p,q,k,... ) ≡ ϵμλ (k)ur(p)Aijaμ (p,q,k,... )vs(q).
Since this gluon is colored, it also contributes to the soft radiation. Therefore, the next step is
to calculate the soft radiation off an external gluon line. To be deﬁnite, we take this gluon line
to be in the ﬁnal state. The amplitude corrected by the emission of a soft gluon (of momentum
k′) off the gluon (of momentumk) line reads
Mri,sj,λa+λ′a′q, ¯q,g (p,q,k,k ′,... )= ϵλ′μ′ (k′) −i(k+k′)2 (−gfaba′ )Vμνμ′ (−k,k +k′, −k′)
×ϵλμ(k)ur(p)Aijbν (p,q,k +k′,... )vs(q),
whereVμνμ′ (−k,k +k′, −k′) is the momentum-dependent factor in the three-gluon vertex:
Vμνμ′ (−k,k +k′, −k′)= gμν(−2k −k′)μ′ +gνμ′ (k +2k′)μ +gμ′μ(−k′ +k)ν
≈
k′≪k gμν(−2kμ′ )+ gνμ′kμ +gμ′μkν.
The two underlined terms will give zero, sincekμϵλμ = 0 andkνAijbν (p,q,k,... )= 0. Using
also (k +k′)2 ≈ 2k·k′, we obtain
Mri,sj,λa+λ′a′q, ¯q,g+g (p,q,k,k ′ ... )
≈ (−igfaba′
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
g(Ta′adj )ab
)k·ϵλ′ (k′)k·k′ ϵμλ (k)ur(p)Aijbμ (p,q,k,... )vs(q).
(One may check that the soft emission off an incoming gluon is given by the same formula.)
Summing the soft emissions off the quark, the antiquark and the gluon, we have
Mri,sj,λa,λ′a′q, ¯q,g,g (p,q,k,k ′,... )
≈ gϵμλ (k)ur(p)[k·ϵλ′ (k′)k·k′ (Ta′adj)ab Aijbμ (p,q,k,... )
+ p·ϵλ′ (k′)p·k′ (ta′f )ii′ Ai′jaμ (p,q,k,... )
−q·ϵλ′ (k′)q·k′ Aij′aμ (p,q,k,... )(ta′f )j′j
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ ϵλ′μ′ (k)Jμ′ijaa′
]
vs(q). (3.51)
This time, we have
k′μ′Jμ′ijaa′ =(Ta′adj)ab Aijbμ +(ta′f )ii′ Ai′jaμ −Aij′aμ (ta′f )j′j = 0. (3.52)
(See Problem 44 for a discussion of this identity, which may be viewed as the statement of
color conservation in the hard process.) In order to be more speciﬁc, consider the case where


PDF PAGE 353 
 182 3 NON-ABELIAN FIELDS
the quark–antiquark pair is in the octet channel, i.e.,
Aijaμ ≡ Aabμ (tbf )ij.
(In this representation, b is the color of the gluon that produces the pair.) Plugging this
representation into Eq. (3.52) leads to
[
Ta′adj,Aμ]ac (tcf )ij = 0.
For this to be true for all assignments of the color indices, Schur’s lemma implies that the
object Aabμ must be proportional toδab,
Aabμ ≡ Bμ δab,
which is just saying that the gluon that produces the quark–antiquark pair must have the same
color as the external gluon in the hard process. We can now plug this speciﬁc form ofAijaμ into
(3.51) and square the amplitude. Because p2 = q2 = k2 = 0, the squares of the three terms
vanish after summing over the polarizationsλ′. Therefore, we need only consider the crossed
products,
∑
λ′
⏐⏐⏐Mri,sj,λa,λ′a′q, ¯q,g,g (p,q,k,k ′,... )⏐⏐⏐2
=
⏐⏐⏐Mhard⏐⏐⏐2( −Ikp(k′)(Ta′adj)ab(tbf )ij(taf )ji′(ta′f )i′i
+Ikq(k′)(Ta′adj)ab(tbf )ij(ta′f )jj′(taf )j′i
+Ipq(k′)(ta′f )ii′(taf )i′j(ta′f )jj′(taf )j′i + complex conjugate),
where we denote
Ipq(k′) ≡ g2 p·q(p·k′)(q·k′), Mhard ≡ ϵμλ (k)ur(p)Bμvs(q).
When we sum over the colors, the various color structures that appear in this formula can be
simpliﬁed easily in the case of su(N):
(
Ta′adj)ab(tbf )ij(taf )ji′(ta′f )i′i =− ifa′ab tr(tbf taf ta′f ) =− 14 N(N2 −1),(
Ta′adj)ab(tbf )ij(ta′f )jj′(taf )j′i =− ifa′ab tr(tbf ta′f taf ) =+ 14 N(N2 −1),(
ta′f )ii′(taf )i′j(ta′f )jj′(taf )j′i = tr(ta′f taf ta′f taf ) =− 12 Cf.
Therefore, we obtain
∑
ijaa′,λ′
⏐⏐⏐Mri,sj,λa,λ′a′q, ¯q,g,g (p,q,k,k ′,... )⏐⏐⏐2
= N2−12 ⏐⏐⏐Mhard⏐⏐⏐2(NIkp(k′)+ NIkq(k′)− 1NIpq(k′)).
Each term in this sum has a speciﬁc radiation pattern, as discussed earlier, and the total emission
pattern depends on the relative orientations ofp,q,k. For instance, if these three vectors are


PDF PAGE 354 
 44 AN IDENTITY OBEYED BY ON-SHELL QCD AMPLITUDES 183
all nearly in the same direction, then the soft gluon emission is also collimated in this direction
(this happens, for instance, if the gluon was itself radiated from the quark–antiquark pair; this
argument indicates that successive emissions of gluons from an initial color-singletq ¯q pair
remain collimated). In contrast, if k ∼ −(p +q), then the soft emission covers most of the
solid angle.
From the above formula, one can also see that, when N →∞ , the soft radiation is
dominated by the ﬁrst two terms, i.e., as if the gluon were emitted independently by a (pk)
quark–antiquark pair and by a (kq) quark–antiquark pair. This can easily be understood from
the fact that we can replace the gluon by a quark–antiquark double line in this limit, which
effectively amounts to replacing the qgq system by qqqq. This observation is the starting
point of the dipole model for successive soft gluon emissions in the large-N limit.
44. An Identity Obeyed by On-Shell QCD Amplitudes Consider an amplitude
Ma1···i1···¯ı1···, where the indices a1,a2,... are the color indices of external gluons, the indices
i1,i2,... are those of outgoing quarks or incoming antiquarks, and the indices ¯ı1, ¯ı2,... those
of outgoing antiquarks or incoming quarks. Show that
∑
α ∈ {out. q, in. ¯q}
(
tbf )iαi′α M···i′α··· − ∑
α ∈ {in. q, out. ¯q}
M···¯ı′α··· (tbf )¯ı′α¯ıα
+
∑
α ∈ {gluons}
(
Tbadj)aαa′α M···a′α··· = 0.
This identity may be proven in several ways. In the spirit of Problem 43, we can derive it
by adding a soft gluon to the amplitude under consideration, in all possible ways. In Problem
43, we worked out the eikonal factors corresponding to the emission of a soft gluon by an
outgoing quark or antiquark:
outgoing quark: M···i··· → gp·ϵλ(k)p·k (tbf )ii′ M···i′···,
outgoing antiquark: M···¯ı··· → −gp·ϵλ(k)p·k M···¯ı′··· (tbf )¯ı′¯ı.
(Of course, the momentum p should be that of the corresponding outgoing line.) Similar
considerations give the following corrective factors for gluon emission off an incoming quark


exit_code=0
```

### 2026-11-16T17:44:18.037187+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in list(range(92,95))+list(range(139,146))]'
```

```text

PDF PAGE 92 
 214 4 SCATTERING AMPLITUDES
Additional Note: The above results can be justiﬁed in a different way as follows. First, we
deﬁne a zero-dimensional “quantum ﬁeld theory” by its action:
S(X) ≡ X2
2 − X33! (φ3 theory),S (X) ≡ X22 − X33! − X44! (Yang–Mills theory).
Note that the propagators and vertices associated with this action are all equal to1. Then, we
deﬁne the generating function
Z(j) ≡ eW(j) ≡
∫
dX eS(X)−jX.
Because the Feynman rules are all equal to 1, the Taylor coefﬁcients ofW(j) merely count the
number of connected graphs (both tree-level graphs and graphs with loops). In order to isolate
the tree-level graphs, it is useful to introduce the quantum effective actionΓ (X) by
Γ (X) ≡ W(j)+ jX(j), with Γ′(X(j)) = j.
At tree level, we haveΓ (X)= S(X) and therefore
W(j)=
tree
S(X(j)) −jX(j), with S′(X(j)) = j.
Since in our earlier discussion one of the legs of the tree graphs was singled out, the corre-
sponding generating series is in fact the ﬁrst derivative ofW(j). At tree level, we have
∂jW(j)=tree ∂j(X(j))
(
S′(X(j)) −j/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 0
)
+X(j)= X(j).
51.c Let us now consider the case of tree-level color-ordered graphs in Yang–Mills theory.
The only difference from the non-ordered case is that we are not allowed to reshufﬂe the labels
on the external legs, since we must preserve their ordering, which has the effect of removing
the symmetry factors. Thus, by replacing Eq. (4.24) with
Y = j +Y2 +Y3,
we should have
Y(j)=
∞∑
n=1
( number of color-ordered
tree graphs with1 +n legs
)
jn.
Note that, unlike in (4.23), there is no factor1/n! here since the order of then factorsj matters
(one may viewj as a vector, andjn as the product of its ﬁrstn components: jn → j1j2 ··· jn).
As before, we solve this equation iteratively:
Y(n) = j +Y2(n−1) +Y3(n−1)
⏐⏐⏐
order ≤ n
,
which givesY(9) = j +j2 +3j3 +10j4 +38j5 +154j6 +654j7 +2871j8 +12,925j 9. The
coefﬁcients of this power series give directly the number of tree-level color-ordered graphs in
Yang–Mills theory.


PDF PAGE 93 
 52 SIX-POINT −−−+++ AMPLITUDE 215
3−^ 4+^
2−
5+
6+
1−
+−
3−^ 4+^
1−
2−
5+6+
+−
Figure 4.1 Contributions to the six-point color-ordered amplitude1−2−3−4+5+6+, with a
shift applied to the lines3 and4 (the lines carrying the shift are shown in boldface).
52. Six-Point −−−+++ Amplitude Using a BCFW shift on lines 3 and 4, derive an
expression for the color-ordered amplitude1−2−3−4+5+6+ that has only two terms:
A6(1−2−3−4+5+6+)=− 4ig4[2⏐⏐P3 +P4⏐⏐5⟩ { ⟨1⏐⏐P2 +P3⏐⏐4]3[23][34]⟨56⟩⟨61⟩(p2 +p3 +p4)2
+
⟨
3
⏐⏐P4 +P5⏐⏐6]3[
61
][
12
]⟨
34
⟩⟨
45
⟩
(p3 +p4 +p5)2
}
.
When the shift is applied to lines3 and4, there are only two ways to arrange the remaining
lines and to choose the internal helicities, as shown in Figure 4.1. Note that the graph on the
right contains an anti-MHV amplitude with two positive helicities and three negative ones. For
this sub-amplitude, we will accept without proof that the Parke–Taylor formula with square
brackets instead of angle brackets is valid. The shift that has good behavior when|z| →∞ is
the one with
⏐⏐ˆ4] =⏐⏐4] and⏐⏐ˆ3⟩ =⏐⏐3⟩ (and the direction of the shift is a complex momentum
kμ such that ⏐⏐k⟩ = ⏐⏐3⟩ and⏐⏐k] = ⏐⏐4]). Therefore, the sum of these two graphs gives the
following expression for the six-point amplitude:
A6(1−2−3−4+5+6+)=− 4ig4
{
1
s23
⟨
23
⟩3
⟨
3ˆKI
⟩⟨ˆKI2⟩
⟨
1ˆKI
⟩3
⟨ˆKIˆ4⟩⟨ˆ45⟩⟨56⟩⟨61⟩
+ 1s45
[
45
]3
[
5ˆLI
][ˆLI4]
[ˆLI6]3[
61
][
12
][
2ˆ3][ˆ3ˆLI]
}
,
where we denotes23 ≡ (p2 +p3)2,s45 ≡ (p4 +p5)2. We have deﬁnedKI ≡ −(p2 +p3) in the
ﬁrst term andLI =− (p4 +p5) in the second one. Consider the ﬁrst term, for which the value of
z at the pole is given by0 = ˆK2I = K2I +2z∗ KI ·k = s23 −z∗⟨kKI⟩[KIk] = s23 +z∗⟨32⟩[24],which leads to
z∗ =− s23⟨32⟩[24] =−
⟨
23
⟩[
23
]
⟨
32
⟩[
24
] =
[
23
]
[
24
], ⏐⏐ˆ4⟩ =⏐⏐4⟩ + [23][24]⏐⏐3⟩.
The angle brackets containingˆKI can be evaluated as follows. For a generic on-shell momentum


PDF PAGE 94 
 216 4 SCATTERING AMPLITUDES
𝓁μ,w eh a v e
⟨
𝓁ˆKI
⟩[ˆKI4] =−⟨𝓁2⟩[24] −⟨𝓁3⟩[34] +z∗⟨𝓁3⟩[44]/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
= 0
=−
⟨
𝓁
⏐⏐P2 +P3⏐⏐4].
Moreover,
[
24
]⟨ˆ45⟩ =[24]⟨45⟩ +z∗[24]⟨35⟩ =[24]⟨45⟩ +[23]⟨35⟩ =[2⏐⏐P3 +P4⏐⏐5⟩,⟨ˆ4⏐⏐P2 +P3⏐⏐4] =⟨4⏐⏐P2 +P3⏐⏐4] +z∗⟨3⏐⏐P2 +P3⏐⏐4]
=
⟨
42
⟩[
24
]
+
⟨
43
⟩[
34
]
−s23 =− 2
(
p2 ·p4 +p3 ·p4 +p2 ·p3
)
=− (p2 +p3 +p4)2.
Therefore, the ﬁrst term can be rewritten as
A(1)6 (1−2−3−4+5+6+)=− 4ig4(p2 +p3 +p4)2 ⟨1⏐⏐P2 +P3⏐⏐4]3[23][34]⟨56⟩⟨61⟩[2⏐⏐P3 +P4⏐⏐5⟩.
The same method can be used to simplify the second term, leading to the following ﬁnal result:
A6(1−2−3−4+5+6+)=− 4ig4[2⏐⏐P3 +P4⏐⏐5⟩ { ⟨1⏐⏐P2 +P3⏐⏐4]3[23][34]⟨56⟩⟨61⟩(p2 +p3 +p4)2
+
⟨
3
⏐⏐P4 +P5⏐⏐6]3[
61
][
12
]⟨
34
⟩⟨
45
⟩
(p3 +p4 +p5)2
}
.
This is a remarkably simple expression given the fact that it would be obtained as the sum of
38 color-ordered Feynman graphs in the traditional approach. Non-adjacent conﬁgurations of
the three negative helicities and the three positive ones lead to more complicated formulas, but
it is easy to see that BCFW recursion produces at most six terms in the worst case.
53. Two Spinor-Helicity Identities Deﬁne the following four4×4 matrices:
γμ ≡
(
0σ μ
σμ 0
)
, with σμ ≡ (1,σi), σμ ≡ (1, −σi).
53.a Check that theseγμ are a valid representation of the Dirac matrices in four dimensions.
53.b Show that
tr (σμσνσρσσ)= 2(gμνgρσ −gμρgνσ +gμσgνρ +iϵμνρσ),
tr (σμσνσρσσ)= 2(gμνgρσ −gμρgνσ +gμσgνρ −iϵμνρσ).
53.c Use this result to prove the following identities (withsij ≡ (pi +pj)2):
[
12
]⟨
23
⟩[
34
]⟨
41
⟩
−
⟨
12
⟩[
23
]⟨
34
⟩[
41
]
= 4ip 1μp2νp3ρp4σ ϵμνρσ,⟨
12
⟩[
23
]
⟨
14
⟩[
43
] = s12s34 −s13s24 +s14s23 −4ip 1μp2νp3ρp4σ ϵμνρσ
2s14s34
.


PDF PAGE 139 
 67 ONE-LOOP ++++ AMPLITUDE FROM GENERALIZED CUTS 261
proportional to each other:
⏐⏐1⟩ ∝⏐⏐a⟩ ∝⏐⏐d⟩.
Likewise, by considering the other three sub-amplitudes, we also have
⏐⏐2⟩ ∝⏐⏐b⟩ ∝⏐⏐a⟩, ⏐⏐3⟩ ∝⏐⏐c⟩ ∝⏐⏐b⟩, ⏐⏐4⟩ ∝⏐⏐d⟩ ∝⏐⏐c⟩.
Since proportionality is a transitive relationship, this implies that
⏐⏐1⟩ ∝⏐⏐2⟩ ∝⏐⏐3⟩ ∝⏐⏐4⟩.
This is a constraint on the external momenta, which implies that the three Mandelstam
invariants are zero,s = t = u = 0, which is not satisﬁed in general. Therefore, this cut
is also zero.
Thus, we have shown that all the possible cuts of the one-loop amplitudeA4(1+2+3+4+) are
zero in four dimensions, which implies that this amplitude is purely rational.
66.c Consider now the all-plusn-point amplitude at one loop,An(1+2+ ··· n+), withn ≥ 5.
With a four-dimensional loop momentum, the maximal number of cut lines is four. The proof
that all these cuts are zero follows the same reasoning as in the preceding case, and is even
simpler in the case of the four-particle cuts.
• Two-particle cuts split the amplitude into ap-point (3 ≤ p ≤ n) and an (n−p+4)-point
sub-amplitude. In total, these two sub-amplitudes require at least three negative helicities,
while the two cut propagators provide only two. These cuts are all zero.
• Three-particle cuts give ap-point, a q-point and an (n−p−q+6)-point sub-amplitude.
At least four negative helicities are necessary, while the cut propagators carry only three.
All these cuts are also zero.
• Four-particle cuts split the amplitude into a p-point, a q-point, an r-point and an
(n−p−q−r+8)-point sub-amplitude. At least ﬁve negative helicities are necessary
whenn ≥ 5, since at least one of the sub-amplitudes has four points or more. The cuts
provide only four negative helicities, implying that these cuts are zero.
Therefore, An(1+2+ ··· n+) is purely rational at one loop.
67. One-Loop Four-Point ++++ Amplitude from Generalized Unitarity The goal of
this problem is to calculate analytically the all-plus four-gluon color-ordered amplitude at one
loop, with a massless complex scalar running in the loop. Assume the loop momentum 𝓁μ to
be ind ≡ 4 −2ϵ dimensions, while the external gluons are kept strictly four-dimensional.
67.a Explain why the reduction of the corresponding loop integral is equivalent to that of the
same loop with a massive scalar in four dimensions. What set of scalar integrals can
appear in the result of this reduction?


PDF PAGE 140 
 262 4 SCATTERING AMPLITUDES
67.b Consider now the four-point all-plus amplitude with a scalar loop,Ascalar4 (1+2+3+4+).
Write its reduction to master integrals. Why are tadpoles and bubbles absent?
67.c Apply a four-particle cut to this amplitude to obtain the box coefﬁcient,
D0123 = 8g4𝓁4⊥
[
12
][
34
]
⟨
12
⟩⟨
34
⟩.
67.d By applying the three-particle cut (012), check that the triangle coefﬁcientC012 is zero.
67.e Perform explicitly the loop momentum integration in the master integrals, to obtain
Ascalar4 (1+2+3+4+)=− ig412π2 [12][34]⟨12⟩⟨34⟩.
67.a Recall the propagator for a massless complex scalar and its trilinear coupling to a gauge
ﬁeld:
p
= ip2 +i0+,
p
q
μ =− ig(p +q)μ.
(Since we are interested in color-ordered amplitudes, the vertex has been stripped of its color
factor. There is in addition aφ∗φAμAμ vertex that we shall not need in the discussion.) The
loop momentum 𝓁μ can be decomposed into a component 𝓁μ‖ that lives in the four physical
dimensions, and a component𝓁μ⊥ in thed −4 extra dimensions:
𝓁μ ≡ 𝓁μ‖/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
4 dim
+ 𝓁μ⊥
/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
d −4 dim
.
By construction, 𝓁⊥ is orthogonal to 𝓁‖, and also to all the external momenta and polariza-
tion vectors that are assumed to remain four-dimensional. Given this decomposition, the
denominators of the propagators in the loop are all of the form
(𝓁 +q)2 =( 𝓁‖ +q)2 +𝓁2⊥.
Interestingly,𝓁⊥ appears in the same way in all the denominators, via its square. Moreover,
if we view the extra dimensions as space-like, this contribution is identical to a mass term
μ2 ≡ −𝓁2⊥.
Consider now the numerator of the loop integral. Its momentum dependence comes from
theφ∗φAμ vertices, contracted with external trees made of gluons or with polarization vectors.


PDF PAGE 141 
 67 ONE-LOOP ++++ AMPLITUDE FROM GENERALIZED CUTS 263
Since these are four-dimensional, these contractions depend on𝓁‖ but not on𝓁⊥. Therefore, a
loop integral withm denominators has the following generic structure:
∫ dd𝓁
(2π)d
N(𝓁)∏m−1
i=0 (𝓁 +qi)2/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
d-dimensional massless
=
∫ dd−4𝓁⊥
(2π)d−4
∫ d4𝓁‖
(2π)4
N(𝓁‖)∏m−1
i=0
(
(𝓁‖ +qi)2 +𝓁2⊥)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
four-dimensional massive
.
Except for the additional integration over the extra dimensions of the loop momentum, the
right-hand side contains the same loop integral, for a four-dimensional but massive scalar. The
standard reduction techniques, applied to the latter integral, lead to a general decomposition in
boxes, triangles, bubbles and tadpoles.
67.b This observation is handy for calculating some amplitudes that are purely rational, such
as a one-loop amplitude with all external gluons having positive helicities. Since the result is
rational, it can be picked by unitarity methods only if the loop momentum is allowed to be
d-dimensional rather than four-dimensional. But this makes it difﬁcult to use the spinor-helicity
formalism to express the tree sub-amplitudes obtained after the cuts have been applied. With
the above observation, we need to cut a four-dimensional massive loop instead. When the
particle running in the loop is a scalar, simple expressions exist for the tree sub-amplitudes,
some of which have been derived in Problem 57, even when the scalar is massive.
Let us now apply this to the calculation of the one-loop amplitude Ascalar4 (1+2+3+4+).
From Problems 65 and 66, we know that this amplitude is ultraviolet ﬁnite and is a rational
function of the external momenta. Splitting the loop momentum into its four-dimensional part
𝓁‖ and the extra components𝓁⊥, we ﬁrst have
Ascalar4 (1+2+3+4+)= limd→4
∫ dd−4𝓁⊥
(2π)d−4 Ascalar4 (1+2+3+4+;−𝓁2⊥)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
massive4d scalar loop
,
where the integrand on the right-hand side is the same amplitude evaluated with a four-
dimensional loop momentum and a squared mass −𝓁2⊥. Since we expect an ultraviolet ﬁnite
result (see Problem 65), the reduction of the four-dimensional loop integral over 𝓁μ‖ cannot
contain bubbles or tadpoles, but only boxes and triangles. Therefore, the reduction applied to
this integrand leads to
Ascalar4 (1+2+3+4+;−𝓁2⊥)= D0123L(4)0123
+C012L(4)012 +C023L(4)023 +C013L(4)013 +C123L(4)123, (4.44)
where we have deﬁned
L(4)i1···ip ≡
∫ d4𝓁‖
(2π)4
ip
((𝓁‖ +qi1 )2 +𝓁2⊥)··· ((𝓁‖ +qip )2 +𝓁2⊥),
q0 ≡ 0, q 1 ≡ p1,q 2 ≡ p1 +p2,q 3 ≡ p1 +p2 +p3 =− p4
(p1,2,3,4 are the momenta of the four external gluons). It is interesting to note the dimensions


PDF PAGE 142 
 264 4 SCATTERING AMPLITUDES
of the various objects in the decomposition of the amplitude (in the limitϵ → 0):
dim (Ascalar4 )= 0,
dim (L(4)0123)=− 4, dim (D0123)= 4,
dim (L(4)ijk)=− 2, dim (Cijk)= 2.
Given the dimension of the coefﬁcientD0123, it may contain a factor𝓁4⊥, which would produce
an ultraviolet divergence in the integration over𝓁⊥, and therefore a pole inϵ−1. However, as
we shall see, because the factor𝓁4⊥ is restricted to the d −4 extra dimensions, it also brings
an explicit factorϵ into the numerator that compensates for the pole and thus leads to a ﬁnite
result in the end.
67.c In order to determine the coefﬁcientsD0123 andCijk, we apply cuts simultaneously to
the amplitude Ascalar4 (1+2+3+4+;−𝓁2⊥) and to the various integralsL(4)i1···ip . Let us denote by
Δi the operator that cuts the propagator of denominator (𝓁‖ +qi)2 +𝓁2⊥:
i
(𝓁‖ +qi)2 +𝓁2⊥ −→Δi δ
(
(𝓁‖ +qi)+ 𝓁2⊥)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ δi
.
Consider ﬁrst the four-line cut obtained by applyingΔ0Δ1Δ2Δ3 to Eq. (4.44). All the triangles
L(4)ijk give zero since they have only three denominators. Therefore, we must have
Δ0Δ1Δ2Δ3
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)] = D0123 Δ0Δ1Δ2Δ3[L(4)0123].
On the right-hand side, the application of the four cuts is immediate and gives
Δ0Δ1Δ2Δ3
[
L(4)0123] = ∫ d4𝓁‖(2π)4 δ0δ1δ2δ3. (4.45)
Applying the four cuts to the full amplitude is equally straightforward, since the four-point
amplitude has at most four denominators. We obtain
Δ0Δ1Δ2Δ3
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)] =
1+ 2+
3+4+
= 2
∫ d4𝓁‖
(2π)4 δ0δ1δ2δ3 A3(𝓁‖,1 +, −(𝓁‖ +q1)∗) A3(𝓁‖ +q1,2 +, −(𝓁‖ +q2)∗)
×A3(𝓁‖ +q2,3 +, −(𝓁‖ +q3)∗) A3(𝓁‖ +q3,4 +, −𝓁∗‖),
(4.46)
where A3(𝓁‖,i +, −𝓁′∗‖ ) denotes the on-shell three-point amplitude (with a mass −𝓁2⊥ for the
scalar particles), with a scalar, an antiscalar and a gluon. The prefactor 2 accounts for the fact
that the roles of the scalar and antiscalar may be interchanged. These three-point amplitudes


PDF PAGE 143 
 67 ONE-LOOP ++++ AMPLITUDE FROM GENERALIZED CUTS 265
have been calculated in Problem 57. In fact, we also evaluated there the product of two such
amplitudes, leading to the following compact results:
A3(𝓁‖,1 +, −(𝓁‖ +q1)∗)A3(𝓁‖ +q1,2 +, −(𝓁‖ +q2)∗)= 2g2𝓁2⊥
[
12
]
⟨
12
⟩,
A3(𝓁‖ +q2,3 +, −(𝓁‖ +q3)∗)A3(𝓁‖ +q3,4 +, −𝓁∗‖)= 2g2𝓁2⊥
[
34
]
⟨
34
⟩.
Comparing (4.45) and (4.46) therefore gives the following value for the box coefﬁcient:
D0123 = 8g4𝓁4⊥
[
12
][
34
]
⟨
12
⟩⟨
34
⟩.
(Such a direct identiﬁcation is permitted by the fact that the four delta functions freeze the
integral over the four components of𝓁‖.)
67.d Let us now turn to the triple cuts. We can limit the discussion to the cutΔ0Δ1Δ2, and
by symmetry we will be able to infer the other triple cuts without further calculation. When
applied to the right-hand side of (4.44), this triple cut receives contributions from the box
integralL(4)0123 and from the triangleL(4)012:
Δ0Δ1Δ2
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)] = D0123 Δ0Δ1Δ2[L(4)0123] +C012 Δ0Δ1Δ2[L(4)012].
The cuts on the right-hand side of this equation read
Δ0Δ1Δ2
[
L(4)0123] = ∫ d4𝓁‖(2π)4 i(𝓁‖ +q3)2 +𝓁2⊥ δ0δ1δ2,
Δ0Δ1Δ2
[
L(4)012] = ∫ d4𝓁‖(2π)4 δ0δ1δ2.
Applying this triple cut to the full amplitude gives
Δ0Δ1Δ2
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)] =
1+ 2+
3+4+
= 2
∫ d4𝓁‖
(2π)4 δ0δ1δ2 A3(𝓁‖,1 +, −(𝓁‖ +q1)∗) A3(𝓁‖ +q1,2 +, −(𝓁‖ +q2)∗)
×A4(𝓁‖ +q2,3 +4+, −𝓁∗‖).
The four-point amplitude that appears in the last line has also been calculated in Problem 57:


PDF PAGE 144 
 266 4 SCATTERING AMPLITUDES
A4(𝓁‖ +q2,3 +4+, −𝓁∗‖)= 2g2𝓁2⊥
[
34
]
⟨
34
⟩ i
(𝓁‖ +q3)2 +𝓁2⊥.
Therefore, we have
Δ0Δ1Δ2
[
Ascalar4 (1+2+3+4+;−𝓁2⊥)]
= 8g4𝓁4⊥
[
12
][
34
]
⟨
12
⟩⟨
34
⟩
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
D0123
∫ d4𝓁‖
(2π)4
i
(𝓁‖ +q3)2 +𝓁2⊥ δ0δ1δ2/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Δ0Δ1Δ2
[
L(4)0123
]
.
This triple cut is in fact saturated by the triple cut of the box integral. Therefore, the coefﬁcient
of the triangleL(4)012 vanishes,C012 = 0.
67.e Likewise, all the other triangle coefﬁcients are zero, and the amplitude is fully given by
Ascalar4 (1+2+3+4+)
= 8g4
[
12
][
34
]
⟨
12
⟩⟨
34
⟩ lim
d→4
∫ dd−4𝓁⊥
(2π)d−4
∫ d4𝓁‖
(2π)4
𝓁4⊥
((𝓁‖ +q0)2 +𝓁2⊥)··· ((𝓁‖ +q3)2 +𝓁2⊥)
= 8g4
[
12
][
34
]
⟨
12
⟩⟨
34
⟩ lim
d→4
gd−4μν gd−4ρσ
∫ dd𝓁
(2π)d
𝓁μ𝓁ν𝓁ρ𝓁σ
(𝓁 +q0)2 ··· (𝓁 +q3)2.
In the ﬁnal line, it is convenient to combine the integrations over 𝓁⊥ and 𝓁‖ into a unique
d-dimensional integral, by introducing the restriction gd−4μν of the metric tensor to the extra
dimensions. Its trace is equal tod −4, and it gives zero when contracted to a Lorentz index that
lives in the four physical dimensions. Therefore, after the Lorentz contractions are performed,
the factorgd−4μν gd−4ρσ will bring at least one power ofϵ. However, the integral is logarithmically
divergent in four dimensions, and therefore has a poleϵ−1. Since the divergence is logarithmic,
the coefﬁcient of the pole is simply given by
∫ dd𝓁
(2π)d
𝓁μ𝓁ν𝓁ρ𝓁σ
𝓁8 = 1d(d+2) (gμνgρσ +gμρgνσ +gμσgνρ)
∫ dd𝓁
(2π)d
1
𝓁4
= i24 (gμνgρσ +gμρgνσ +gμσgνρ) Γ (2 − d2 )(4π)2 Γ (2)
= i12(4π)2(4−d) (gμνgρσ +gμρgνσ +gμσgνρ).
(At every stage, we keep only the term that produces a pole ind = 4, and disregard the ﬁnite


PDF PAGE 145 
 68 ONE-LOOP +++++ AMPLITUDE FROM GENERALIZED CUTS 267
(1 graph) (4 graphs) (4 graphs)
(2 graphs) (2 graphs) (4 graphs)
(4 graphs) (4 graphs) (4 graphs)
(4 graphs) (4 graphs)
Figure 4.4 The37 color-ordered graphs contributing to the amplitudeAscalar4 (1+2+3+4+) in
the traditional approach (solid lines≡ gluons, dashed lines≡ scalars).
terms.) Contracting this with gd−4μν gd−4ρσ gives
gd−4μν gd−4ρσ
∫ dd𝓁
(2π)d
𝓁μ𝓁ν𝓁ρ𝓁σ
𝓁8 = i12(4π)2(4−d)gd−4μν gd−4ρσ (gμνgρσ +gμρgνσ +gμσgνρ)
= i12(4π)2 (2 −d),
so that we ﬁnally obtain the following remarkably simple result:
Ascalar4 (1+2+3+4+)=− ig412π2 [12][34]⟨12⟩⟨34⟩.
In the traditional approach based on Feynman diagrams, one would have to sum the contribu-
tions of37 color-ordered graphs (see Figure 4.4) in order to obtain this one-loop amplitude.
For reasons beyond the scope of this problem, this result also turns out to be the value of the
1+2+3+4+ amplitude in Yang–Mills theory (i.e., with a gluon and a ghost loop instead of a
scalar loop).
Source: Brandhuber, A., McNamara, S., Spence, B. and Travaglini, G. (2005), J High Energy
Phys 10: 011.
68. One-Loop Five-Point +++++ Amplitude from Generalized Unitarity This problem
continues along the lines of Problem 67. The goal is now to calculate the ﬁve-point all-plus
one-loop amplitudeAscalar5 (1+2+3+4+5+).
68.a Interpreting the contribution of thed −4 extra dimensions to the scalar propagator as a
mass, write the reduction of this amplitude on a basis of master integrals (denote by𝓁i
the momenta carried by the loop propagators, with 𝓁i = 𝓁i−1 +pi, and by Di ≡ 𝓁2i +𝓁2⊥
the corresponding denominators).


exit_code=0
```

### 2026-11-16T17:45:24.816731+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in list(range(161,164))+list(range(171,180))+list(range(183,191))+list(range(209,217))+list(range(225,229))]'
```

```text

PDF PAGE 161 
 69 BANKS–CASHER RELATION 283
69. Banks–Casher Relation Quantum chromodynamics, if restricted to the up and down
quarks, has a nearly exact chiral symmetry thanks to the very small masses of these quarks.
The three pions (π0,π±) are also much lighter than the other hadrons, a property which is
understood as a consequence of them being the Nambu–Goldstone bosons that result from the
spontaneous breaking of chiral symmetry (fromSU(2)×SU(2) toSU(2), hence three pions
corresponding to the three broken symmetries – note that their masses are not exactly zero,
because the symmetry was not exact to begin with). The goal of this problem is to establish a
relationship, known as the Banks–Casher relation, between the value of the chiral condensate⟨
ψψ
⟩
(which should be zero if chiral symmetry holds, and which may be viewed as the order
parameter for its spontaneous breaking) and the spectral density at zero energy of the Dirac
operator. Consider Euclidean QCD in the continuum.
69.a Show that the expectation value
⟨
ψ(x)ψ(x)
⟩
can be written as
⟨
ψ(x)ψ(x)
⟩
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM [A] det (i/D −m) trV
[ 1
i/D −m
]
,
whereV is a four-dimensional Euclidean volume to which the trace is restricted, andZ
is the same integral without the trace and the prefactor1/V.
69.b Recalling the properties of the Euclidean Dirac operator, write the trace as follows:
trV
[ 1
i/D −m
]
=
∑
n
1
iλn −m =−
∑
n
m
λ2n +m2,
where theλn are real numbers.
69.c Show that
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
69.d Show that, in the limits of inﬁnite volume and zero quark mass, we have⟨
ψ(x)ψ(x)
⟩
=− π limV→∞ ρV (0).


PDF PAGE 162 
 284 5 LATTICE, FINITE T , STRONG FIELDS
69.a Note ﬁrst that the equal-point correlation function
⟨
ψ(x)ψ(x)
⟩
is independent of the
pointx thanks to translation invariance. Therefore, we may write
⟨
ψ(x)ψ(x)
⟩
= lim
V→∞
1
V
∫
V
d4x⟨ψ(x)ψ(x)⟩,
where V is a ﬁnite volume in Euclidean R 4. Then, it admits the following path integral
representation:
⟨
ψ(x)ψ(x)
⟩
= 1ZV ∫ [DAμDψDψ] e−SYM −SD ∫V d4x ψ(x)ψ(x)
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM det (i/D −m)
∫
V
d4x⟨x⏐⏐ 1i/D −m⏐⏐x⟩
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM det (i/D −m) trV
[ 1
i/D −m
]
, (5.18)
where Z ≡
∫
[DAμDψDψ] e−SYM −SD.
In this formula, it is implicitly understood that the integrand is calculated for a ﬁnite volume
theory, in which the spectrum of the Dirac operator is discrete. The limit V →∞ ensures that
we recover the original theory in the end.
69.b The Euclidean Dirac matrices are anti-Hermitian,γμ† =− γμ, as is the derivative∂μ.
Therefore, the Euclidean Dirac operator is Hermitian, and it can therefore be diagonalized in
an orthonormal basis with real eigenvalues:
/Dψn(x)= λnψn(x),λ n ∈ R ,
∫
V
d4xψ∗m(x)ψn(x)= δmn.
(Note that the eigenvalues depend implicitly on the background gauge ﬁeldAμ.) The trace of
the inverse of the Dirac operator can be expressed in terms of these eigenvalues as follows:
trV
[ 1
i/D −m
]
=
∑
n
1
iλn −m.
On the other hand, sinceγ5γμγ5 = γμ† =− γμ, we can write
trV
[ 1
i/D −m
]
= trV
[
γ5γ5 1i/D −m] = trV [γ5 1i/D −mγ5]
= trV
[ 1
−i/D −m
]
=
∑
n
1
−iλn −m.
By taking the half-sum of the two representations of the trace, we arrive at
trV
[ 1
i/D −m
]
=−
∑
n
m
λ2n +m2 =−
∫
dλ
[ ∑
n
δ(λ −λn)
] m
λ2 +m2.


PDF PAGE 163 
 70 NIELSEN–NINOMIYA THEOREM 285
69.c Inserting this expression in (5.18), we immediately get
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
The integrand in the deﬁnition ofρV (λ) is a distribution that has a delta peak at each eigenvalue
of the ﬁnite volume Dirac operator, and its integral over some range [λ1,λ2] counts the number
of eigenvalues in that range, per unit of volume V. The average over all conﬁgurations of
the gauge ﬁeldAμ washes out the delta peaks and turnsρV (λ) into a smooth distribution that
provides the average density of eigenvalues of the Dirac operator:
∫λ2
λ1
dλ ρV (λ)=
⟨# of eigenvalues in [λ1,λ2]
V
⟩
A
.
Note that this distribution has a gap at the lower end of the spectrum because of the ﬁnite
volume.
69.d As the volume increases, the gap at the lower end decreases, andρV (λ) has support in
the entire range [0, +∞) in the inﬁnite-volume limit. Moreover, when the quark mass goes to
zero, we have
lim
m→0+
m
λ2 +m2 = πδ (λ).
Therefore, we have
lim
m→0+
⟨
ψ(x)ψ(x)
⟩
=− π lim
V→∞
ρV (0).
This relation is known as the Banks–Casher relation. The left hand side is a quantity known
as the chiral condensate. In the massless limit, the Dirac Lagrangian is invariant under chiral
transformations, since it does not contain an operator ψψ (which breaks chiral symmetry).
A non-zero expectation value of this operator therefore signals that the ground state of the
theory breaks chiral symmetry. The Banks–Casher formula relates the chiral condensate, which
quantiﬁes the spontaneous breaking of chiral symmetry, to the spectral density at the lower
end of the spectrum of the Dirac operator (the latter is controlled by how quickly eigenvalues
accumulate nearλ = 0 when the volume becomes inﬁnite).
Source: Banks, T. and Casher, A. (1980), Nucl Phys B 169: 103.
70. Nielsen–Ninomiya Theorem The goal of this problem is to prove theNielsen–Ninomiya
theorem, an obstruction to the construction of chiral gauge theories on the lattice. Consider
an inﬁnite square lattice of spacing a. The conjugate momenta pμ are continuous variables
with components in the range
[
− πa, +πa] and any function ofpμ is periodic with period 2π/a.In other words, we may view momentum space as a four-dimensional torusT4. The inverse
propagator of a massless left-handed fermion can be written as S−1(p)= ∑μ γμPLFμ(p),
whereFμ(p) is a real continuous vector ﬁeld onT4 andPL ≡ (1 −γ5)/2.


PDF PAGE 171 
 72 CENTER SYMMETRY AND DECONFINEMENT 293
controlled by the continuously varying parameter ¯h. Indeed, from the expression for the Moyal
product, the Moyal commutator reads
F ⋆G −G ⋆F = 2i¯h F sin {i ¯h2 [ ←∂X →∂p − →∂X ←∂p ]}G
= {F, G} + ¯h2
24 F
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]3 G +··· .
(We have reinstated Planck’s constant in this formula, using the fact that it has the dimensions
of an action.) From this expression, we also see that
F ⋆G −G ⋆F = {F, G}
if at least one of the functions F, Gis a polynomial of degree two in X,p . Thus, the Moyal–
Groenewold quantization of a theory with a quadratic Hamiltonian (e.g., a harmonic oscillator)
is particularly simple: its phase-space density obeys the classical Liouville evolution equation
even when ¯h ⁄= 0.
72. Center Symmetry and Deconfinement The goal of this problem is to study an
extension of gauge symmetry called center symmetry,i na SU(N) Yang–Mills theory at ﬁnite
temperature in the imaginary time formalism. In particular, we show that the deconﬁnement
transition may be viewed as a breaking of center symmetry.
72.a The center of a gauge group is the subgroup made of the elements that commute with the
entire group. In the case of SU(N), show that the center is Z N ≡ {e2iπk/N}0≤k<N, i.e.,
the set of theN-th roots of unity (multiplied by the identity matrix). Hint: ﬁrst, show
that the center of U(N) is the complex unit circle.
72.b At ﬁnite temperature, legitimate gauge transformations should be singled-valued in
imaginary time, i.e., beβ-periodic,Ω(β,x)= Ω(0,x). Consider now a more general
transformation, called a center transformation, deﬁned as a gauge transformation with a
non-periodicΩ. Instead, Ω(τ,x) is assumed to obeyΩ(β,x)= ξΩ(0,x) withξ ∈ Z N.
Show that center transformations also preserve the periodicity of the gauge ﬁeld.
72.c A Polyakov loop is the trace of a Wilson loop that wraps around the imaginary time
direction, at ﬁxed positionx:
L(x) ≡ N−1 tr⟨Pe x p∫β
0
dτA0(τ,x)⟩.
Show that L(x) is invariant under the usual (periodic) gauge transformations, but not
invariant under center transformations. What does this imply for the center transforma-
tions?
72.d Explain whyL(x) is related to the free energyFq of an inﬁnitely massive quark added
to the system at the pointx by
⏐⏐L(x)⏐⏐ = e−βFq (i.e., the energy necessary for bringing
the quark from inﬁnity, arbitrarily slowly). From this interpretation, conclude thatL(x)
should be zero in the conﬁning phase of Yang–Mills theory, and that one may view
deconﬁnement as a breaking of the center symmetry.


PDF PAGE 172 
 294 5 LATTICE, FINITE T , STRONG FIELDS
72.e Why is the center symmetry explicitly broken if dynamical quarks in the fundamental
representation are added to the theory? What about adding matter ﬁelds in the adjoint
representation?
72.a Consider ﬁrst the case of the group U(N) ofN×N unitary matrices. A matrix A is
in the center ofU(N) ifA = PAP−1 for all unitary matricesP. Since A is unitary, it can be
diagonalized by a unitary transformation, which implies that we can reduce the discussion to
diagonal matrices. Therefore, let us now assume that A is diagonal, but not proportional to the
identity. This means that there exists a pair of indicesi ⁄= j such thatAii ⁄= Ajj. Now, denote
byQ the matrix obtained by swapping the columnsi,j of the identity, and deﬁneB ≡ QAQ−1.
Note that Q = Q† = Qt and QQ = 1, hence Q is unitary. A simple calculation shows that
Bii = Ajj andBjj = Aii, which implies thatB ⁄= A, i.e.,
QAQ−1 ⁄= A,
in contradiction to the fact that A was assumed to be in the center of the group. Thus, our
hypothesis thatA is not proportional to the identity was inconsistent, and we conclude that
center
(
U(N)
)
=
{
c·1N×N,|c| = 1
}
.
(The constraint on the modulus ofc is necessary to have unitary matrices.)
Consider now the case of SU(N). It is useful to recall that any matrix of U(N) can be
written as the product of a phase by a matrix ofSU(N):
U = eiθV, U ∈ U(N),V ∈ SU(N),θ ∈ R .
IfA is in the center ofSU(N) andU is inU(N),w eh a v e
UAU−1 = VAV−1/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= A
= A.
Therefore A is also in the center of U(N) and must be of the form c · 1N×N . Since the
determinant of such a matrix is cN,c must be one of the N-th roots of unity in order to have a
matrix ofSU(N). This group is denoted Z N.
72.b Consider a transformationΩ(τ,x) that has the following boundary condition:
Ω(β,x)= ξΩ (0,x), withξ ∈ Z N.
Calculate the transformed gauge ﬁeld atτ = β (assuming that the gauge ﬁeld wasβ-periodic
before applying the transformation):


PDF PAGE 173 
 72 CENTER SYMMETRY AND DECONFINEMENT 295
Ω†(β,x)Aμ(β,x)Ω(β,x)+ igΩ†(β,x)∂μΩ(β,x)
= Ω†(0,x)ξ∗Aμ(0,x)ξΩ(0,x)+ igΩ†(0,x)ξ∗∂μξΩ(0,x)
= Ω†(0,x)Aμ(0,x)Ω(0,x)+ igΩ†(0,x)∂μΩ(0,x).
In the ﬁnal step, theξ andξ∗ cancel because we are allowed to move them throughAμ since
they belong to the center of SU(N). Despite the fact that this transformation is not β-periodic,
it nevertheless preserves the periodicity of the gauge ﬁelds. Therefore, these more general
transformations may be viewed as an extended symmetry of Yang–Mills theory (called center
symmetry) at ﬁnite temperature.
72.c Recall that a Wilson line Wγ(y,x ) along any path γ between the points x and y
transforms into Ω(y)Wγ(y,x )Ω†(x) under a gauge transformation. Therefore, the trace of
a Wilson loop is gauge invariant (and the Polyakov loop is just a special kind of Wilson
loop). But the cancellation of Ω(β,x) withΩ†(0,x) inside the trace works only whenΩ is
β-periodic, and therefore it fails with the generalized transformations considered above. In this
case, the Polyakov loop is not invariant, but is multiplied by an elementξ ∈ Z N of the center:
L(x) → ξL (x).
Since the Polyakov loop is gauge invariant, it should be considered as an observable of the
theory. Thus, the center transformations can alter the physical content of the system (i.e., they
are not just a reparameterization of redundant degrees of freedom). The only exception to this
statement occurs when L(x)= 0, since this value of the Polyakov loop is left invariant by
center transformations.
72.d The energy gainFq of the system due to bringing (inﬁnitely slowly, to avoid disturbing
the system) a heavy quark of massM at the pointx from inﬁnity may be written as follows:
e−β(Fq+M) =
∑
α
⟨
α +q(x)
⏐⏐e−βH⏐⏐α +q(x)⟩∑
α
⟨
α
⏐⏐e−βH⏐⏐α⟩
(the factore−βM, that contains the rest energy of the quark, has been explicitly added so that
Fq measures only the energy due to the interactions of the quark with its environment), where⏐⏐α +q(x)⟩ denotes the pure gluon state⏐⏐α⟩ to which a quark (of spin s and colori) is added
at the locationx:
⏐⏐α +q(x)⟩ ≡ ∫ d3p(2π)32Ep e−ip·x f(p)vs(p)b†sip/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ ψsi(x)
⏐⏐α⟩.
The functionf(p) is a wave-packet normalized according to


PDF PAGE 174 
 296 5 LATTICE, FINITE T , STRONG FIELDS
∫ d3p
(2π)3
⏐⏐f(p)⏐⏐2 = 1,
which ensures that
⟨
α +q(x)
⏐⏐α +q(x)⟩ =⟨α⏐⏐α⟩. Interpreting the canonical density operator
as an imaginary time evolution, we can write
ψ†si(τ,x)e−βH = e−βH ψ†si(τ +β,x),
and the quark free energy becomes
e−β(Fq+M) = tr (e−βH ψ†si(β,x)ψsi(0,x))tr (e−βH) .
(Note that there is no sum on the spins and the colori in this expression.) Loosely speaking,
the right-hand side is the thermal expectation value of the propagator of the heavy quark
between the times τ = 0 and τ = β (the problem is translation invariant, and we may thus
choose the ﬁrst time to be0). To promoteψsi(x) to a time-dependent object, we use Dirac’s
equation. In the limit of large mass, M →∞ , wherep0 ≈ M,|p| ≪ M, the Dirac equation
simpliﬁes to
((∂τ −gA0)γ0 −M)ψ = 0.
Moreover, in this kinematical limit, we also haveγ0vs(p)=− vs(p). Therefore, for a spinor
proportional tovs(p), the Dirac equation becomes
(∂τ −gA0 +M)ψ = 0,
whose solution reads
ψ(τ,x)= e−Mτ Te x p(g ∫τ
0
dτ′ A0(τ′,x))
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ U(τ,x)
ψ(0,x).
(The time ordering is necessary becauseA0 is a matrix in su(N).) Therefore, we can write
ψsi(τ,x) ≡ e−Mτ ∑
j
Uij(τ,x)
∫ d3p
(2π)32Ep e−ip·x f(p)vs(p)b†sjp,
which leads to
e−βFq = eβM ∑
j
tr (e−βH ψ†sj(0,x)Uji(β,x)e−βMψsi(0,x))
tr (e−βH)
= 1N ∑i,j tr (e−βH ψ†sj(0,x)Uji(β,x)ψsi(0,x))tr (e−βH) .
In the last equality, we have used the fact that the free energy is independent of the quark color
i in order to introduce an average overi. In the evaluation of this expectation value, the product


PDF PAGE 175 
 73 PHOTON HARD THERMAL LOOP FROM CLASSICAL PARTICLES 297
of the two free spinors simply yields
ψ†sj(0,x)ψsi(0,x)=
∫ d3pd3q
(2π)64EpEq ei(p−q)·x bsjpb†siq/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−b†siqbsjp+(2π)32Epδijδ(p−q)
f∗(p)f(q)v†s(p)vs(q).
The term in −b†siqbsjp gives zero when inserted in the trace, because it has a fermion
annihilation operator acting to the right on a pure gluonic state. Thus, only the term in
(2π)32Epδijδ(p −q) contributes:
ψ†sj(0,x)ψsi(0,x) → δij
∫ d3p
(2π)32Ep
⏐⏐f(p)⏐⏐2 v†s(p)vs(p)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 2Ep
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 1
= δij.
The factorδij then leads precisely to the trace of the Polyakov loop over its color indices.
In the conﬁning phase, isolated quarks cannot exist; in other words, it would cost an inﬁnite
amount of energy to bring one from inﬁnity (i.e., Fq =+ ∞). Therefore, the expectation value
of the Polyakov loop should be zero in this phase, and center symmetry is preserved (since
zero times any element of Z N is still zero). On the other hand, isolated quarks cost only a ﬁnite
energy in the deconﬁned phase, and the center symmetry is broken since the expectation value
of Polyakov loops is not zero. Therefore, one may view the expectation value of the Polyakov
loop as an order parameter for the deconﬁnement transition in pure Yang–Mills theory.
72.e Under the transformationΩ(τ,x), a fermion in the fundamental representation trans-
forms as
ψ(τ,x) → Ω†(τ,x)ψ(τ,x).
Therefore, the center transformations do not preserve the β-anti-periodicity of the spinors,
implying that the center symmetry is explicitly broken by the presence of dynamical quarks in
the fundamental representation. Therefore, in QCD with quarks, the expectation value of the
Polyakov loop is no longer a good order parameter for the deconﬁnement transition.
IfΦa is a ﬁeld in the adjoint representation, it transforms as
Φa → ΩabΦb, i.e., Φatar → Ω†rΦatar Ωr.
In the second form, it is clear that the ξ ∈ Z N of the center transformation cancels out, leaving
a transformed ﬁeld which is still β-periodic (or anti-periodic if it is a fermion). Therefore,
a theory with matter ﬁelds in the adjoint representation would be invariant under the center
symmetry.
Source: McLerran, L. D. and Svetitsky, B. (1981), Phys Rev D 24: 450.


PDF PAGE 176 
 298 5 LATTICE, FINITE T , STRONG FIELDS
73. Photon Hard Thermal Loop from Classical Particles In this problem, we use
the concept of a classical particle developed in Problem 31 in order to derive the effective
Lagrangian that generates hard thermal loops in QED. This derivation illustrates the classical
nature of hard thermal loops, and is also a good workout in preparation for the QCD case (see
Problem 74).
73.a Find a suitable generalization of the equations of motion discussed in Problem 37 to
describe the evolution of the position and momentum of a massless charged particle in
an external electromagnetic ﬁeld.
73.b Consider a collection of classical electrons and positrons, with a phase-space density
f(x,p ). Why do we have df/dτ = 0? Using the equations of motion of the classical
particles, turn this equation into a kinetic equation.
73.c Consider now an expansion off,f = f0 +f1 +··· , wheref0 is a distribution independent
of the external ﬁeld. Formally solve the kinetic equation in order to obtain the ﬁrst
correction in the external ﬁeld,f1.
73.d Determine the electromagnetic current Jμ induced by f1 (assume that f0 produces no
current). Then, determine an effective LagrangianLeff such thatJμ = ∂Leff/∂Aμ.
73.e Show that its second derivative, −δLeff/δAμδAν, is the photon polarization tensorΠμνHTL
in the hard thermal loop approximation.
73.a In the classical particle approximation of Problem 37, the charged particles feel the
effect of the background electromagnetic ﬁeld, but their own radiation is not considered.
Therefore, the particles do not feed the electromagnetic ﬁeld, and there are no interactions
between the charged particles. Since we are going to consider the ultra-relativistic limit, we
need to adapt the equations of motion to the case of massless particles. Formally, we can start
from the equations obtained in Problem 37, and deﬁneτ ≡ t/m before completely eliminating
m. This leads to
pμ = dxμ
dτ , dpμdτ = eFμνpν.
Note that since the particles are massless, τ is not really a time but simply some parameter that
maps the trajectory of a particle (in fact, this parameter has the dimensions of a squared time).
73.b Let us denote by f(x,p ) the phase-space density of these charged particles. By the
Liouville theorem,f is constant along the trajectories in phase-space (equivalently, the volume
in phase-space is preserved by a Hamiltonian ﬂow). Then, we can rewrite the time derivative
off more explicitly:
0 = dfdτ = dxμdτ ∂f∂xμ + dpμdτ ∂f∂pμ = pμ ∂f∂xμ +eFμνpν ∂f∂pμ
= pμ
( ∂
∂xμ −eFμν ∂∂pν)f.
This type of kinetic equation is known as a Vlasov equation. The ﬁrst term, p·∂xf, describes
the free streaming of particles, i.e., the motion at constant momentum of free particles. The


PDF PAGE 177 
 73 PHOTON HARD THERMAL LOOP FROM CLASSICAL PARTICLES 299
second term describes the deﬂection of their trajectories due to the force the particles feel from
the external ﬁeld in which they propagate.
73.c The Vlasov equation can be solved iteratively by writing
f = f0 +f1 +··· ,
where f0 is some distribution of free particles (it must obey p · ∂xf0 = 0), f1 is the ﬁrst
correction due to the external ﬁeld, etc. In the ﬁrst iteration, we have
p·∂xf1 = epμFμν ∂f0∂pν.
Indeed, iff1 is the correction of ﬁrst order in the external ﬁeld, we do not need to keep it on the
right-hand side, so that the left- and right-hand sides have the same order ine. This equation
can be solved formally to give
f1 = epμ
1
p·∂x
Fμν ∂f0
∂pν.
73.d The next step is to deﬁne the electromagnetic current associated with the distribution f:
Jμ(x) ≡ e
∫ d3p
(2π)3
pμ
p f(x,p ).
One may check that this current is conserved iff obeys the Vlasov equation:
∂μJμ = e
∫ d3p
(2π)3p (p·∂)f = e2
∫ d3p
(2π)3ppμFμν ∂f∂pν =− e2
∫ d3p
(2π)3p
∂pμ
∂pν
/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
gμν
Fμν
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 0
f = 0.
With the iterative solution obtained above, the current reads
Jμ = e
∫ d3p
(2π)3p pμ
(
f0 +epρ
1
p·∂x
Fρν ∂f0
∂pν +···
)
.
If we assume that the free distributionf0 does not produce any current, the ﬁrst term is zero
(physically, this is realized when the free distributionf0 has equal distributions of electrons
and positrons). Therefore, at order one in the external ﬁeld, the current reads
Jμ = e2
∫ d3p
(2π)3p
pμpρ
p·∂x
Fρν ∂f0
∂pν =− e2
∫ d3p
(2π)3p
∂
∂pν
(pμpρ
p·∂x
)
Fρν f0
=− e2
∫ d3p
(2π)3p
(δνμpρ
p·∂x
+ pμgνρ
p·∂x/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
→0
− pμpρ∂ν
(p·∂x)2
)
Fρν f0.
Note that the middle term gives zero after contraction with the antisymmetric tensor Fρν.N o w ,
we would like to determine an effective LagrangianLeff such that
Jμ = ∂Leff
∂Aμ
.
SinceJμ is linear in the external ﬁeld, this effective Lagrangian must have one more power of
A. Moreover, in order to be gauge invariant, this additionalA dependence should arise via a


PDF PAGE 178 
 300 5 LATTICE, FINITE T , STRONG FIELDS
power of the ﬁeld strength. In order to ﬁnd this Lagrangian, recall ﬁrst that
∂Fαβ
∂Aμ
= ∂(∂αAβ −∂βAα)∂Aμ = δβμ ∂α −δαμ ∂β.
Then, consider
∂
∂Aμ
(
Fνβ
pβpρ
(p·∂)2Fρν
)
=( δβμ∂ν −δνμ∂β) pβpρ(p·∂)2Fρν +Fνβ pβpρ(p·∂)2 (gμν∂ρ −gρμ∂ν)
= pμpρ
(p·∂)2
(
∂νFρν +Fρν∂ν) −2 pρp·∂Fρμ
=− pμpρ
(p·∂)2
(
∂νFρν/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
0
)
−2
(δνμpρ
p·∂ − pμpρ∂ν(p·∂)2)Fρν.
(Note that the derivatives act on everything located to their right, including the zeroth-order
phase-space distribution f0, not yet included in this formula. To obtain the ﬁnal line, we
usedFρν∂ν ··· = ∂νFρν ··· −(∂νFρν)··· . Finally, we have∂νFρν = 0 because the charged
particles are not feeding the external ﬁeld in this approximation (and we assume that the
sources producing this ﬁeld are far away). Up to a factor2, we recognize the structure of the
integrand in the currentJμ. Therefore, the effective Lagrangian whose derivative givesJμ reads
Leff = e22 ∫ d3p(2π)3p Fνβ pβpρ(p·∂)2Fρν f0.
73.e Let us now consider
Πμν =− ∂Jμ
∂Aν
= e2
∫ d3p
(2π)3p
(
gμν − pμ∂ν +pν∂μ
p·∂ + pμpν∂2(p·∂)2) f0.
To recover the HTL result, we replacef0 by the equilibrium fermion distribution,
f0(x,p )= 2×2× 1eβ|p0| +1
(the two prefactors2 account for electrons and anti-electrons, and for the fact they have two
spin states), and we Fourier transform the external coordinates (which simply amounts to the
replacement∂ → ik), so that
Πμν(k)= 4e2
∫ d3p
(2π)3p
(
gμν − pμkν +pνkμ
p·k + pμpνk2(p·k)2) 1eβp +1
(p0 = p in this equation). Note that the factor between the parentheses is homogeneous
of degree zero in p, and therefore depends only on the orientation ˆp of p. By writing


PDF PAGE 179 
 74 GLUON HARD THERMAL LOOP FROM COLORED CLASSICAL PARTICLES 301
d3p = p2dpd2ˆp, we can easily factorize the radial and angular integrals:
Πμν(k)= 2e2
∫ +∞
0
dp p
π2
1
eβp +1 ×
∫ d2ˆp
4π
(
gμν − ˆPμkν +ˆPνkμ
ˆP·k +
ˆPμˆPνk2
(ˆP·k)2
)
,
whereˆP ≡ (1,ˆp). The radial integral reads
2e2
∫ +∞
0
dp p
π2
1
eβp +1 = 2e2T2π2 ∫ +∞0 dx x(e−x −e−2x +e−3x −e−4x +··· )
= 2e2T2
π2
( 1
12 − 122 + 132 −··· ) = 2e2T2π2 ζ(2)2 = e2T26 .
In order to compare with the known results for the photon hard thermal loop, it is enough to
check the component Π00 and the trace Πμμ. The angular integration reduces to three basic
integrals,
∫ d2ˆp
4π = 1,
∫ d2ˆp
4π
1
ˆP·k = 12k ln⏐⏐⏐k0 +kk0 −k⏐⏐⏐,∫ d2ˆp
4π
1
(ˆP·k)2
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
− ∂∂k0 1ˆP·k
= 1
(k0)2 −k2,
and we obtain
Πμμ(k)= e2T26 ∫ d2ˆp4π (4 −2ˆP·kˆP·k +
0/bracehtipdownleft/bracehtipupright/bracehtipupleft/bracehtipdownright
ˆP2 k2
(ˆP·k)2
)
= e2T2
3 ,
Π00(k)= e2T2
6
∫ d2ˆp
4π
(
1 −2 k0
ˆP·k + k2(ˆP·k)2) = e2T23 (1 − k02k ln⏐⏐⏐k0 +kk0 −k⏐⏐⏐).
These results provide the two independent terms that enter into the photon hard thermal loop.
Although the gain provided by this approach to calculating the HTL contribution to the photon
polarization tensor is marginal, it becomes appreciable when applied to the case of QCD, and
does not require much more effort (as opposed to an approach in terms of Feynman diagrams).
Moreover, the present discussion highlights the fact that, in the HTL approximation, the particle
running in the loop is in fact classical.
74. Gluon Hard Thermal Loop from Colored Classical Particles This problem is a
continuation of Problem 73. Extend the method of that problem (with the help of the results
of Problem 37) in order to compute the gluon polarization tensor in the hard thermal loop


PDF PAGE 183 
 75 LANDAU–POMERANCHUK–MIGDAL EFFECT 305
vertex. The main reason why it is possible to capture the HTL results in such a simple setting
is that when the momentum circulating in the loop is much larger than the external momenta,
then all the couplings of the external lines to the loop become eikonal, and therefore universal
(in particular, independent of the spin). In this approximation, the only thing that distinguishes
the various ﬁelds that can circulate in the loop is their phase-space distribution, their color
representation and the corresponding number of degrees of freedom, while all the kinematical
dependence is universal.
Sources: Kelly, P. F., Liu, Q., Lucchesi, C. and Manuel, C. (1994),Phys Rev Lett 72: 3461;
Pisarski, R. D. (1998), Kinetic theory of hot gauge theories: Overview, details & extensions, in
S´anchez, N. and Zichichi, A. (eds.), Current Topics in Astrofundamental Physics: Primordial
Cosmology, NATO ASI Series, vol. 511 (Springer), p. 195.
75. Landau–Pomeranchuk–Migdal Effect The goal of this problem is to study the
emission of soft photons by a hot plasma of electrons and anti-electrons, and in particular
to discuss the Landau–Pomeranchuk–Migdal effect, an interference effect that reduces the
emission of soft photons in a hot medium.
75.a Recall the relationship between the photon emission rate and the imaginary part of the
retarded photon self-energy.
75.b Explain why this self-energy can be obtained as
−iΠijR (x,y )=− δJiind(x)δAj(y),
where Jiind is the electromagnetic current induced by the application of an external
potentialAj. Write this current in terms of the deviations from equilibriumδfe,δf ¯e of
the electron and anti-electron distributions.
75.c Show thatδfe obeys the following Boltzmann–Vlasov equation:
(v·∂x)δfe − eT (v·E)nF (p)(1 −nF (p)) = δCe,p[δf],
whereδCe,p is a collision term andnF is the Fermi–Dirac distribution.
75.d By explicitly writing the collision term with two-body collisions, show that
δCe,p =− e3nF (p)(1−nF (p))
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥+m2D )
[
F(x,p)− F(x,p −𝓁⊥)
]
,
wheremD is the photon Debye mass andδfe ≡ eT nF (1 −nF )F.
75.e Apply a Fourier transform to thex dependence, and discuss qualitatively the effect of
the integral on𝓁⊥ in the collision term.
75.f Extra: in the regime where m ≫ mD , transform the Boltzmann–Vlasov equation into a
diffusion equation that one may solve analytically.


PDF PAGE 184 
 306 5 LATTICE, FINITE T , STRONG FIELDS
75.a We consider a hot plasma of electrically charged electrons and anti-electrons of massm
(this could be their in-vacuum mass or, at very high temperature, the mass they acquire in the
plasma due to their interactions with their environment), interacting via photon exchanges (this
point is not crucial and one could easily generalize this discussion to interactions via gluon
exchanges). The photon emission rate from a sample of this plasma can be obtained from the
in-medium photon self-energy, as follows:
2k0(2π)3 dNγd4xd3k = ∑pol. λϵ(λ)μ (k)ϵ(λ)ν (k)2 Im( −iΠμνR (K))eβk0 −1 .
There are various variants of this formula, differing in which form of the self-energy is used.
Here, we choose the formula that involves the retarded self-energy, because we will want later
to obtain it from linear response theory. To be deﬁnite, let us choose the photon momentumk
to be aligned with thex3 direction. For on-shell photons, the sum over the polarizations simply
produces a projector on the planex1,x2 transverse to the photon momentum:
∑
pol. λ
ϵ(λ)μ (k)ϵ(λ)ν (k)Πμν(K)= ∑
i=1,2
Πii(K).
75.b The retarded photon self-energy can be viewed as a retarded correlation function
between a pair of electromagnetic currents (this is correct in linear gauges, where there is no
spurious triple or quartic photon coupling). Then, by the same reasoning as for the derivation
of Kubo’s formula (see, for instance, Mahan, G. D. (2000), Many-Particle Physics (Kluwer
Academic)), the retarded current–current correlator can be obtained by looking at the induced
current (the response) that appears in the system when we apply an external ﬁeld Aj (the
source):
−iΠijR (x,y )=− δJiind(x)δAj(y), with Jiind ≡ e⟨ψγiψ⟩.
Since we want the photon self-energy in equilibrium, we need only consider arbitrarily small
external ﬁelds (in other words, we calculate the induced current only at linear order in the
applied external ﬁeld).
In thermal equilibrium, there are no net currents in the system (since the fermions and
anti-fermions have opposite charges and the same momentum distribution). The induced
current can be obtained as
Jiind(x)= 2e
∫ d3p
(2π)3 vi(δfe(x,p)− δf¯e(x,p)),
where vi ≡ pi/Ep andδfe (resp. δf¯e) is the deviation from Fermi–Dirac of the electron (resp.
anti-electron) distribution induced by the external ﬁeld (think of an electric ﬁeld, which pulls
electrons and anti-electrons in opposite directions). The prefactor 2 is due to the two spin
states of an electron.
75.c The external ﬁeld acts on the fermions of the system via the Lorentz force. The other
effect that affects the fermion distribution is their collisions, which are responsible for the


PDF PAGE 185 
 75 LANDAU–POMERANCHUK–MIGDAL EFFECT 307
relaxation to equilibrium. Therefore, the equation that controls f and ¯f is a Boltzmann–Vlasov
equation:
(v·∂x)fe
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
free streaming
+e
(
E +v×B
)
· ∇pfe
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Vlasov term
= Ce,p[fe,f ¯e]/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
collisions
,
wherevμ ≡ (1,vi). The Vlasov term, proportional to the Lorentz force, is responsible for the
change of the momenta of the particles as they move in the external ﬁeld. The anti-electron
distribution obeys the same equation with the changee → −e to account for the fact that they
feel the opposite Lorentz force. In this problem, we need only consider small deviations of the
distribution about the equilibrium Fermi–Dirac distribution, fe ≡ nF +δfe, f¯e ≡ nF +δf¯e,
and we can linearize the above Boltzmann–Vlasov equation in δfe,δf ¯e. Recalling that the
deviationsδfe,δf ¯e are of the same order as the external electromagnetic ﬁeldE,B, and that
the collision term vanishes when evaluated with the equilibrium Fermi–Dirac distribution, we
obtain
(v·∂x)δfe +e
(
E +v×B
)
· ∇pnF/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1T nF (1−nF )v
= δCe,p[δf],
where we denote by δC the linearized collision term. Since the Fermi–Dirac distribution is
isotropic, its derivative with respect to momentum is proportional to the velocity v, imply-
ing that only the electric ﬁeld E contributes. In the following, it will prove convenient to
parameterize the deviationsδf2,δf ¯e as follows:
δfe(x,p) ≡ eT nF (p)(1 −nF (p))F(x,p),
δf¯e(x,p) ≡ −eT nF (p)(1 −nF (p))F(x,p),
where the functionF(x,p) is the same in both cases.
75.d Before linearization, the collision term with two-body collisionspq → p′q′ reads
Ce,p[f, ¯f]= ∑
α=e,¯e
∫
p′,q,q′
(2π)4δ(p +q −p′ −q′) 116EpEp′EqEq′
⏐⏐⏐Mpq→p′q′⏐⏐⏐2
×
{
(1−fe(x,p))fe(x,p′)(1−fα(x,q))fα(x,q′)
−fe(x,p)(1−fe(x,p′))fα(x,q)(1−fα(x,q′))},
where we have used the shorthand
∫
q ≡
∫ d3q
(2π)3 . Note that we sum over the two kinds of
scattering partners, electrons and anti-electrons. Next, we expand the distribution functions
about nF , keeping only terms linear in the deviations. Since δfe and δf¯e are opposite, the
deviations of the distributionfα of the scattering partner cancel when we sum over electrons
and anti-electrons. Therefore, we get
δCe,p =− 2eT ∫p′,q,q′ (2π)4δ(p +q −p′ −q′) 116EpEp′EqEq′ ⏐⏐⏐Mpq→p′q′⏐⏐⏐2
×nF (p)(1−nF (p′))nF (q)(1−nF (q′))[F(x,p)−F(x,p′)].
Note that the momentum transfer 𝓁 ≡ p −p′ = q′ −q is soft (of the order of the Debye mass,
i.e., ∼ eT) compared to the typical momentum of the electrons and anti-electrons (of the order


PDF PAGE 186 
 308 5 LATTICE, FINITE T , STRONG FIELDS
of the temperatureT). This implies that the scattering amplitude is dominated by the t-channel
diagram. Consequently, there is no difference between scattering off an electron and off an
anti-electron, hence the prefactor2. Then, in order to rewrite the integrals in the collision terms
in terms of𝓁, we can use
∫ d3p′
(2π)22Ep′
d3q
(2π)22Eq
d3q′
(2π)22Eq′ (2π)4δ(p +q −p′ −q′)
≈
∫ d4𝓁
(2π)4
d3q
(2π)32Eq
1
4EpEq
(2π)2δ(𝓁0 −𝓁·v)δ(𝓁0 −𝓁·vq),
where we have neglected terms quadratic in the soft momentum 𝓁 and where we denote
vq ≡ q/Eq. We can also use the approximation
nF (p)(1−nF (p′)) ≈ nF (p)(1−nF (p)),
nF (q)(1−nF (q′) ≈ nF (q)(1−nF (q),
and note that the integrated squared matrix element (at ﬁxed transfer 𝓁) can be expressed in
terms of the hard thermal loop spectral function (i.e., the imaginary part of the HTL photon
propagator):
2
∫ d3q
(2π)3 2πδ(𝓁0 −𝓁·vq)nF (q)(1−nF (q)
⏐⏐Mpq→p′q′⏐⏐2
16E2pE2q ≈ e2 T𝓁0vμvν ρμνHTL (𝓁),
with
ρμνHTL (𝓁) ≡ ∑
α=T,L
Pμνα (𝓁) 2 ImΠα(𝓁)(𝓁2 − ReΠα(𝓁))2 +( ImΠα(𝓁))2
(vμ ≡ (1,vi), and the projectors PμνT,L were deﬁned following Eq. (5.14)). Therefore, thelinearized collision term becomes
δCe,p =− e3T nF (p)(1−nF (p))
×
∫ d4𝓁
(2π)4 2πδ(𝓁0 −𝓁·v)T𝓁0vμvν ρμνHTL (𝓁)[F(x,p)− F(x,p −𝓁)].
Here, it is important to recognize thatF(x,p) is strongly peaked whenp is aligned with the
photon momentum, i.e., with the z axis. As a consequence, the variations of F are much faster


PDF PAGE 187 
 75 LANDAU–POMERANCHUK–MIGDAL EFFECT 309
when p varies in the transverse direction than in the longitudinal direction, implying that
F(x,p)− F(x,p −𝓁) ≈ F(x,p)− F(x,p −𝓁⊥).
For the same reason, we can approximateδ(𝓁0 −𝓁·v) ≈ δ(𝓁0 −𝓁z). Using the explicit form
of the projectorsPμνT,L(𝓁),w eh a v e
vμvνPμνL (𝓁)=− vμvνPμνT (𝓁)=𝓁0=𝓁z 𝓁2⊥𝓁20 +𝓁2⊥.
It is convenient to introduce the variablex ≡ 𝓁0/|𝓁|, since the HTL photon self-energies depend
only onx. The Jacobian of this change of variable is given by
d𝓁0d2𝓁⊥
𝓁0
𝓁2⊥
𝓁20 +𝓁2⊥ = dxd2𝓁⊥x .
Therefore, the collision term reads
δCe,p =− e3nF (p)(1−nF (p))
∫ d2𝓁⊥
(2π)2
[
F(x,p)− F(x,p −𝓁⊥)
]
× 2π ∫10 dxx { ImΠL (x)(𝓁2⊥+ReΠL (x))2+(ImΠL (x))2 − ImΠT (x)(𝓁2⊥+ReΠT (x))2+(ImΠT (x))2 }/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=
m2D
𝓁2⊥(𝓁2⊥+m2D )
.
The identity used in the second line, wheremD is the Debye screening mass, is an exact sum
rule satisﬁed by the photon HTL self-energies.
75.e Combining the above results, the Boltzmann–Vlasov equation can be written as follows
in terms ofF:
(v·∂x)F(x,p)+ e2T
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
[
F(x,p)− F(x,p −𝓁⊥)
]
= v·E.
Using E ≡ −∂tA and applying a Fourier transform to turn x into the photon momentum K,
this equation leads to
δF(K,p)
δAj(K) = k0vjK·v +i e2TK·v ∫ d2𝓁⊥(2π)2 m2D𝓁2⊥(𝓁2⊥ +m2D )[δF(K,p)δAj(K) −δF(K,p−𝓁⊥)δAj(K) ] (5.22)
(recall thatv ≡ p/Ep), whose solution must be inserted into
Im
(
−iΠijR (K)) =− 4e2T ∫ d3p(2π)3 nF (p)(1 −nF (p))vi Im(δF(K,p)δAj(K) ).
The integral term in (5.22) takes into account the collisions of the emitter with the other
particles in the plasma, while the ﬁrst term on the right-hand side of this equation would give
the contribution of the processe → eγ. Note that this collisionless contribution gives a purely


PDF PAGE 188 
 310 5 LATTICE, FINITE T , STRONG FIELDS
real δF/δAj and therefore does not contribute to the photon yield, as expected from trivial
kinematics.
The equation (5.22) could in principle be solved iteratively in powers ofe2, by inserting
inside the integral the solution obtained at the previous order. Assuming thatδF/δAj is of order
one as in the collisionless limit, then the integral in (5.22) is also of order one (the typical𝓁⊥ is
of the order of the Debye mass mD ). We therefore see that multiple collisions all contribute to
the same order ifv·K ≲ e2T. On the other hand, simple kinematics leads to
v·K ≈ k0
m2 +p2⊥
2p2z . (5.23)
Note that v · K can be interpreted as the inverse of the photon formation time , i.e., the
time necessary for the photon wave-packet to become separated from that of its emitter. In
more physical terms, multiple scatterings are important when the photon formation time is
comparable to or larger than the mean free path, i.e., the distance traveled by the emitter
between two successive collisions (in this process, the relevant collisions are small-angle
collisions, separated by (e2T )−1). This effect is known as the Landau–Pomeranchuk–Migdal
effect. In this regime, there is no point in solving (5.22) perturbatively as a series ine2 because
all orders are in fact comparable. From (5.23), we see thatv·K may be small when the electron
momentum is much larger than its mass,pz ≫ m, and its transverse momentump⊥ is small
(quasi-collinear emission of the photon). This is precisely what happens in a plasma at very
high temperature, where the relevant mass is a thermal mass of order m ∼ eT, the typical pz is
of orderT, and photon emission happens predominantly at small anglesθ ∼ e (i.e.,p⊥ ∼ eT).
The effect of these multiple scatterings on the photon spectrum can be estimated roughly
as follows. On the one hand, the photon formation length is 𝓁 ∼ 1/v·K. On the other hand, the
transverse momentum accumulated by the emitter over this distance isp2⊥ ∼ m2D𝓁/λ, whereλis the electron mean free path. This leads to
𝓁
λ ∼ pzmD√k0λ ≫k0→0 1.
This implies that it takes a large number (growing like 1/√k0) of collisions to produce a
single soft photon. In other words, the soft photon spectrum is reduced by a factor √k0
compared to what one would obtain by multiplying the one-collision spectrum by the number
of collisions (this is known as the Bethe–Heitler limit). This suppression is a quantum effect,
due to the destructive interference between photon emissions occurring at various points along
the trajectory of the emitting electron (the photon formation length controls how far apart two
emissions that still interfere can be); see Figure 5.4 for an illustration.
75.f This discussion can be made more quantitative analytically whenm ≫ mD (for this to
be true, the bare mass of the electron must dominate over its thermal mass). In this case, we
may write
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
[δF(K,p)
δAj(K) −δF(K,p−𝓁⊥)δAj(K) ]
≈
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
1
2
(
𝓁⊥ · ∇p
)2δF(K,p)
δAj(K) ≈ m2D8π ln( mmD )∇2pδF(K,p)δAj(K) .
Here, we have used the separation of scale between the typicalp⊥ ∼ m and the Debye mass
mD in order to make a leading logarithmic approximation of the integral over𝓁⊥ (the logarithm


PDF PAGE 189 
 75 LANDAU–POMERANCHUK–MIGDAL EFFECT 311
Figure 5.4 Left: illustration of the Landau–Pomeranchuk–Migdal effect. Right: the Feynman
graphs contributing to the photon self-energy in the LPM regime (the black dots on the
internal photons indicate the hard thermal loop re-summation).
must be large for this approximation to be justiﬁed). In this approximation, the equation (5.22)
that sums the multiple collisions of the emitter becomes a diffusion equation in the transverse
velocity space (v⊥ ≡ p⊥/p):
ik0
(
1
2
(
v2⊥ + m2p2 ) δFδAj −vj) +D∇2v⊥ δFδAj = 0,
where the diffusion constant is deﬁned as D ≡
e2Tm 2D
8πp2 ln(m/mD ). In order to solve this
diffusion equation, let us deﬁneδF/δAj ≡ vj(ϕ(s)+ 1)/s withs ≡ 12v2⊥ (note that we musthaveϕ(0)=− 1 for this to be deﬁned at v⊥ = 0). In terms of ϕ ands,w eh a v e
sϕ′′ +i(α +βs)ϕ +iα = 0, with α ≡ k0m24Dp2 ,β ≡ k02D.
This is a differential equation with polynomial coefﬁcients, which may be solved by taking a
Laplace transform,
v(λ) ≡
∫ ∞
0
dse −λsϕ(s).
First, we obtain a differential equation forv(λ):
v′ + 2λ −iαλ2 +iβ v + 1 −iαλλ2 +iβ = 0.
Since this is a ﬁrst-order equation, it can be solved analytically:
v(λ)=− 1λ21 −λ2(λ1 +λλ1 −λ)μ ∫λ1λ dξ(1 −iαξ)(λ1 −ξλ1 +ξ)μ,
withλ1 ≡ √βe−iπ/4 andμ ≡ (α/2√β)e−iπ/4. In terms of this function, we have


PDF PAGE 190 
 312 5 LATTICE, FINITE T , STRONG FIELDS
∑
i=1,2
Im
(
−iΠiiR (K)) =− 23e2T2 Imv(λ = 0)
= 23 e2T2β Re limλ→0
∫λ1
λ
dξ
(
1 −iαξ)(λ1 −ξλ1 +ξ)μ
= 23 e2T2β Re limλ→0
{
λ1
∫1
0
dx
(1−x
1+x
)μ
−iα
∫1
0
dx
x
[(1−x
1+x
)μ
−1
]
−iα ln
(λ1
λ
)}
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
∼√β whenk0 → 0
∝
k0→0
√
k0.
In the penultimate line, we have directly setλ = 0 in the terms that are regular in this limit, and
isolated a term that has a logarithmic singularity. But note that the singularity only contributes
to the imaginary part, so that the real part has a ﬁnite limit (λ should approach zero along the
positive real axis in order to obtain the correct result). When we combine this result with the
soft limit of the Bose–Einstein factor that multiplies Im (−iΠiiR (K)) in the photon emission
spectrum, we obtain a spectrum in 1/√k0, instead of 1/k0 for bremsstrahlung induced by
a single scattering. Thus, the effect of multiple scatterings is to reduce the emission of soft
photons by a factor√k0, as we had anticipated from our earlier qualitative discussion.
Let us ﬁnish with a general remark about the approach employed here to derive this effect.
Naively, it may seem paradoxical to be able to derive a quantum interference effect by means
of kinetic theory, which assumes that electrons behave completely classically. But in the LPM
effect, the only object whose coherence matters is the photon wavefunction, while the electron
can be totally classical.
Sources: Baym, G., Blaizot, J.-P., Gelis, F. and Matsui, T. (2007),Phys Lett B 644: 48; Migdal,
A. B. (1956), Phys Rev 103: 1811.
76. Microcanonical Equilibration in φ4 Scalar Theory Consider a massless scalar ﬁeld
theory withφ4 interaction in four spacetime dimensions. The goal of this problem is to study
some aspects of classical dynamics in this ﬁeld theory, in relation to thermal equilibration.
76.a What is the canonical energy–momentum tensor in this theory? What is its trace?
76.b What is the equation of state relating pressure to energy density for a scale invariant
system in statistical equilibrium?
76.c Consider a spatially homogeneous classical ﬁeld in this theory. Show that this ﬁeld is a
periodic function of time, and ﬁnd the relationship between the period and the amplitude
of the ﬁeld oscillations. Show that the trace of the energy–momentum tensor is non-zero
for this ﬁeld, but vanishes when averaged over one period.
76.d Consider now a statistical ensemble of such homogeneous classical ﬁelds, obtained by
choosing an ensemble of initial conditions and letting the ﬁelds evolve according to
the classical equation of motion. How does the expectation value of the trace of the
energy–momentum tensor evolve with time?


PDF PAGE 209 
 80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 331
79.f From the results of Problem 77, we know that P0 = exp(−Nclusters). It is only when
particles are produced without any correlations that the mean number of clusters is equal to
the mean number of produced particles N+ (since each particle is its own cluster in that case).
Therefore, we expect in general that P0 ⁄= exp(−N+) due to correlations. This discrepancy
can be made more explicit by using the formulas obtained above. By evaluating the generating
functional at z = z = 0, one obtains the following expression for the vacuum-to-vacuum
transition probability (i.e., the vacuum survival probability):
P0 = exp
(
−Nclusters
)
with Nclusters = V
∫ d3p
(2π)3 ln(1 +fp),
while the total particle multiplicity is
N+ = V
∫ d3p
(2π)3 fp.
Only when the occupation number is small in all modes can we expand the logarithm in P0
and obtain P0 ≈ exp(−N+), but this relationship is not exact in very strong ﬁelds. This is
a limitation of the methods that give only P0 (for instance by providing a way to calculate
the imaginary part of the effective action in a background ﬁeld): in general, knowledge ofP0
is not sufﬁcient to obtain the momentum dependence of the spectrum of produced particles
(proportional tofp).
Source: Fukushima, K., Gelis, F. and Lappi, T. (2009), Nucl Phys A 831: 184.
80. Schwinger Mechanism from Bogoliubov Transformations The goal of this problem
is to rederive some of the results of Problem 79 in the canonical formalism, and to introduce the
concept of Bogoliubov transformation (quite generally, this is a mapping between the creation
and annihilation operators on the Fock space of an observer and those of another observer).
80.a Write the Hamiltonian of the theory of a complex scalar ﬁeld coupled to an external
electromagnetic potential. Specialize it to the gauge A0 = 0. Derive the Hamilton–
Jacobi equations of motion.
80.b Decompose the ﬁeld operator φ in the in and out bases. Show that there is a linear
relationship between the in and out creation and annihilation operators,
ak,out = αk ak,in +βk b†−k,in,b †k,out = α∗−k b†k,in +β∗−k a−k,in,
with|αk|2 −|βk|2 = 1.
80.c Show that the in vacuum state can be expressed in terms of out objects as follows:
⏐⏐0in⟩ = e−V2 ∫ d3p(2π)3 ln(1+|βp|2) e∫ d3p(2π)3 βpα∗p a†p,outb†−p,out ⏐⏐0out⟩,
whereV is the volume of the system.
80.d Use this formula to calculate the inclusive one-particle and two-particle spectra, and
check that they agree with the results of Problem 79.


PDF PAGE 210 
 332 5 LATTICE, FINITE T , STRONG FIELDS
80.a Let us start from the Lagrangian density,
L =
(
Dμφ
)∗(Dμφ)− m2φ∗φ.
The conjugate momentum of the ﬁeldsφ,φ∗ are respectively
Π ≡ ∂L∂∂0φ =( D0φ)∗,Π ∗ ≡ ∂L∂∂0φ∗ = D0φ, (5.33)
from which we obtain the Hamiltonian
H =
∫
d3x(Π∗∂0φ∗ +Π∂0φ −L)
=
∫
d3x(Π∗Π +ieA0Πφ −ieA0Π∗φ∗ +m2φ∗φ +(Dφ)∗(Dφ)).
Here,φ andΠ are operators in the Heisenberg picture satisfying the equal-time commutation
relation,
[
φ(x),Π (y)
]
=
x0=y0
iδ (x −y).
It is convenient for the following discussion to choose a gauge where A0 = 0, because
in this gauge there is a non-ambiguous correspondence between the time dependence of a
wavefunction and the physical energy of the corresponding particle (in particular, the concepts
of positive and negative energies are invariant under the residual gauge freedom). In the
temporal gauge, we have the following Hamiltonian:
H =
∫
d3x(Π∗Π +m2φ∗φ +(Dφ)∗(Dφ)).
The dynamics of the scalar ﬁelds are determined by the Hamilton–Jacobi equations of motion,
∂0φ = i [H,φ ]= Π∗,
∂0Π = i [H,Π ]=( D2 −m2)φ∗.
Note that, since we are not considering self-interactions of the scalar ﬁelds, these equations
of motion are linear. Moreover, since the background electromagnetic ﬁeld is treated as a
classical ﬁeld given once and for all, there are no back-reaction effects (e.g., no photon loop
corrections on the propagator of the scalar). Thanks to the absence of loop corrections, solving
these equations of motion as if they were classical equations of motion is sufﬁcient in order to
obtain the relationship between the ﬁeld operators at x0 =− ∞ andx0 =+ ∞. In other words,
solving exactly the simpliﬁed QFT problem considered here can be reduced to solving a set of
linear partial differential equations.
80.b Let us now decompose the ﬁeld operator on the basis of creation or annihilation
operators. For this, we may choose either the in or the out basis. Let us mention here an
important subtlety. Even if we assume that the external electromagnetic ﬁeld vanishes when
x0 = ±∞, there may be a non-zero gauge potential Ai at asymptotic times, Ain,outi . (Thesegauge potentials are constants, since there is no physical electromagnetic ﬁeld at asymptotic


PDF PAGE 211 
 80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 333
times.) These asymptotic potentials modify the dispersion relation that relates the on-shell
energy and the wavenumberk, since the equation of motion of the ﬁeld contains a covariant
derivativeD rather than the ordinary derivative∂. For this reason, we must replace the usualEk
byEin,out,+k =√m2 +(k +eAin,out)2 for particles and byEin,out,−k =√m2 +(k −eAin,out)2
for anti-particles. Since we have Ein,out,−k = Ein,out,+−k , we can simplify the subsequent notationby systematically using only the energy of the anti-particles, which we denote more simply by
Ein,outk ≡ Ein,out,+k (with k changed into −k when necessary). (In a detector, one measures thekinetic momentum of a particle, p ≡ k±eA. If particles are measured in the ﬁnal state, it
is convenient to choose a residual gauge in whichAout = 0, so that the wavenumber and the
kinetic momentum are identical atx0 =+ ∞.)
With this in mind, the ﬁeld operator may be decomposed in two different ways:
φ(x)=
∫ d3k
(2π)3
[
ak,in√
2Eink φ+k,in(x)+ b†k,in√2Ein−k φ−−k,in(x)]
=
∫ d3k
(2π)3
[
ak,out√
2Eoutk φ+k,out(x)+ b†k,out√2Eout−kφ−−k,out(x)], (5.34)
where the functions φ±k,in andφ±k,out should be determined from the equations of motion (theycannot be simple plane waves because of the external ﬁeld). Note that we have adopted here a
slightly different normalization of the creation and annihilation operators than in the rest of
this book. Indeed, because we now haveEink ⁄= Eoutk , this choice of normalization turns out tobe a bit simpler.
As usual, we want the Heisenberg representation ﬁeld operator φ(x) to go to the in
interaction picture ﬁeld operator when x0 → −∞ and to the out interaction picture ﬁeld
operator atx0 → +∞. These boundary conditions are realized if the functionsφ±k,in andφ±k,out
have the following asymptotic behavior:
φ+k,in(x)= e−iEinkx0+ik·x forx0 → −∞,
φ−k,in(x)= eiEinkx0+ik·x forx0 → −∞,
φ+k,out(x)= e−iEoutk x0+ik·x forx0 → +∞,
φ−k,out(x)= eiEoutk x0+ik·x forx0 → +∞.
The corresponding annihilation operators ain,out,b in,out remove an in-state or out-state particle
and anti-particle, respectively. Note that, for further convenience, we have chosen the spatial
dependence in bothφ+k (x) andφ−k (x) to bee+ik·x, and thus the usual negative energy plane
wave e−ik·x corresponds to φ−−k(x). The canonical commutation relation for φ and Π issatisﬁed provided that we have
[
ak,in,a†p,in] =[bk,in,b†p,in] =[ak,out,a†p,out] =[bk,out,b†p,out] =( 2π)3δ(k −p).
(Note the absence of factors2Ek here, because of our choice of normalization in (5.34).)
Because the equation of motion satisﬁed by the ﬁeld is linear, there is a linear transformation
that relates the coefﬁcient functions in the in and out decompositions. Moreover, if the
background ﬁeld depends only on time, then this linear transformation does not mix values of


PDF PAGE 212 
 334 5 LATTICE, FINITE T , STRONG FIELDS
k. Let us introduce coefﬁcient αk andβk (known as Bogoliubov coefﬁcients) such that
lim
x0→+∞φ+k,in(x) ≡
√
Eink
Eoutk
(
αk e−iEoutk x0+ik·x +β∗k eiEoutk x0+ik·x).
In other words, αk and βk are deﬁned by decomposing the time dependence of φ+k,in on
the basis of the e±iEoutk x0 at large x0. In the absence of an external ﬁeld, one would simply
haveαk = 1 andβk = 0. Since (φ+k,in(x0, −x))∗ satisﬁes both the same initial condition as
φ−k,in(x) and the same equation of motion, they are therefore equal everywhere, and we havealso
lim
x0→+∞φ−k,in(x)=
√
Eink
Eoutk
(
α∗k eiEoutk x0+ik·x +βk e−iEoutk x0+ik·x).
Note now that the plane waves that appear in the integrands of the preceding two equations
are nothing but the asymptotic behavior of the waves φ±k,out. Since the waves φ±k,in and the
φ±k,out obey the same linear equation of motion (the Klein–Gordon equation), these linear
relationships are valid at all times (and not just atx0 =+ ∞):
φ+k,in(x)=
√
Eink
Eoutk
(
αk φ+k,out(x)+ β∗k φ−k,out(x)),
φ−k,in(x)=
√
Eink
Eoutk
(
α∗k φ−k,out(x)+ βk φ+k,out(x)).
By inserting these formulas in (5.34), we obtain similar relationships between the creation and
annihilation operators in the two bases:
ak,out = αk ak,in +βk b†−k,in,b †k,out = α∗−k b†k,in +β∗−k a−k,in.
This linear relationship is known as a Bogoliubov transformation . Consistency with the
commutation relations requires that
|αk|2 −|βk|2 = 1.
(One can also check that this condition implies that the charge operator is the same in the two
bases: Qin = Qout.) The above relations can be inverted as follows:
ak,in = α∗k ak,out −βk b†−k,out,b k,in = α∗−k bk,out −β−k a†−k,out.
80.c The vacuum is deﬁned as the state annihilated by all the annihilation operators:
ak
⏐⏐0⟩ = bk⏐⏐0⟩ = 0.
(We ignore the in and out labels for this generic discussion.) A properly normalized state with
one particle of momentumk can be constructed as
⏐⏐k⟩ = a†k√
V
⏐⏐0⟩,
where V is the spatial volume. (Note that here we are departing momentarily from the
convention used in the rest of the book, namely to have one-particle states normalized to2Ek


PDF PAGE 213 
 80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 335
particles per unit volume. The state deﬁned here contains exactly one particle in the volume
V.) Particles of momentum k can then be counted with the following particle number operator:
dˆN
d3k = a†kak(2π)3.
To check the consistency of these deﬁnitions, note that
⟨
p
⏐⏐dˆN
d3k
⏐⏐p⟩ =⟨0⏐⏐ ap√
V
a†kak
(2π)3
a†p√
V
⏐⏐0⟩ = δ(p −k).
(We use the commutation relations in order to obtain the last equality.) The integral overd3k
indeed gives1, i.e., the correct total number of particles in the state.
After having set these conventions, let us return to the problem of particle production. We
consider the situation where there are no particles at x0 → −∞, i.e., the system is prepared in
the in vacuum state deﬁned by
ap,in
⏐⏐0in⟩ = bp,in⏐⏐0in⟩ = 0.
In the Heisenberg picture, the states do not evolve (the operators do), and therefore the system
stays in this state forever. What changes with time is the number operator used to count
particles. For instance, at x0 =+ ∞, the operatorak,out in general no longer annihilates⏐⏐0in⟩
and an observer would see particles. In order to count the number of outgoing particles, we
must thus count the number of out particles contained in the state
⏐⏐0in⟩. For this, it is useful to
derive an expression for
⏐⏐0in⟩ in terms of the out quantities ap,out, bp,out and⏐⏐0out⟩. That is,
we should solve
ap,in
⏐⏐0in⟩ =(α∗p ap,out −βpb†−p,out)⏐⏐0in⟩ = 0,
bp,in
⏐⏐0in⟩ =(α∗−p bp,out −β−pa†−p,out)⏐⏐0in⟩ = 0.
Let us consider the following ansatz:
⏐⏐0in⟩ ≡ C exp(∫ d3k(2π)3 χk a†k,out b†−k,out)⏐⏐0out⟩,
whereC is a normalization constant. (This state is a coherent state in which each particle is
paired with an anti-particle of opposite momentum – a necessary condition for any representa-
tion of the vacuum state because of charge and momentum conservation.) Requesting that this
state be annihilated byak,in andb−k,in puts some constraints on the functionχk. In order to


PDF PAGE 214 
 336 5 LATTICE, FINITE T , STRONG FIELDS
see this, let us denote
A† ≡
∫ d3k
(2π3) χk a†k,out b†−k,out,
Bp ≡ α∗pap,out −βpb†−p,out,
Cp ≡
[
Bp,A†] = χpα∗pb†−p,out.
Note thatCp commutes withA†. Therefore, we have
BpA† = A†Bp +C,
Bp(A†)2 =( A†)2Bp +2CpA†,
···
Bp(A†)n =( A†)nBp +nCp(A†)n−1,
BpeA† = eA† (Bp +Cp).
Then, we have
(
α∗pap,out −βpb†−p,out)⏐⏐0in⟩ = eA† (Bp +Cp)⏐⏐0out⟩ = eA† (−βp +χpα∗p)b†−p,out⏐⏐0out⟩.
For this to be zero, we must have χp = βp/α∗p. (One may check that the second condition
leads to the same constraint.)
The next step is to determine the normalization constant so that
⟨
0in
⏐⏐0in⟩ = 1, i.e.,
⏐⏐C⏐⏐2 =⟨0out⏐⏐eAeA†⏐⏐0out⟩−1.
An easier way to handle this calculation is to discretize the integrals over the momentum inA
andA†. The consistent way of doing this is to write
A† = 1V ∑k χkA†k,A = 1V ∑k χ∗kAk,[
Ap,A†q] = Vδpq(a†p,outap,out +b−p,outb†−p,out/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ Np
)
,
[
Np,A†q] = 2VδpqA†p, [Np,Aq] =− 2VδpqAp,
whereδpq is now a discrete Kronecker symbol. We have
⟨
0out
⏐⏐eAeA†⏐⏐0out⟩ =⟨0out⏐⏐ ∏
p
eχ∗p ApV ∏
q
eχq
A†q
V
⏐⏐0out⟩
=
⟨
0out
⏐⏐ ∏
p
eχ∗p ApV eχp A†pV ⏐⏐0out⟩.
Noting that
⟨
0out
⏐⏐(Ap
V
)m(A†p
V
)n⏐⏐0out⟩ = δmn(n!)2
(the factorial factors come from the fact that
(A†p
V
)n⏐⏐0out⟩ is a state with n pairs of particles
and anti-particles with identical momenta, but this state is not normalized to account for the


PDF PAGE 215 
 80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 337
fact that then pairs are identical), we obtain
⟨
0out
⏐⏐eAeA†⏐⏐0out⟩ = ∏
p
(1 −|χp|2)−1 = ∏
p
(1 +|βp|2)
= e
∑
k ln(1+|βp|2) = exp(V ∫ d3p(2π)3 ln(1 +|βp|2)).
(We have restored the continuous notation in the last expression.) Therefore, the normalized in
vacuum state expressed in terms of out objects reads
⏐⏐0in⟩ = e−V2 ∫ d3p(2π)3 ln(1+|βp|2) e∫ d3p(2π)3 βpα∗p a†p,outb†−p,out ⏐⏐0out⟩. (5.35)
The physical meaning of this formula is that, for an observer measuring particles in the ﬁnal
state, the initially empty state has evolved into a coherent state ﬁlled with scalar–antiscalar
pairs of opposite momenta.
80.d Using (5.35), it is now straightforward to calculate the single and double inclusive
spectra by taking expectation values of the number operator. The spectrum of particles is
dN+1
d3p =
⟨
0in
⏐⏐a†p,outap,out
(2π)3
⏐⏐0in⟩.
The easiest way to evaluate this expression is to note that the expression (5.35) for the initial
vacuum state behaves as a coherent state. In particular, it is a kind of “generalized eigenstate”
of the out annihilation operators:
ap,out
⏐⏐0in⟩ = χpb†−p,out⏐⏐0in⟩, ⟨0in⏐⏐a†p,out = χ∗p⟨0in⏐⏐b−p,out.
(The proof is the same as in the case of the usual coherent states, since b†−p,out andb−p,out are
transparent to the action of ap,out anda†p,out.) Using these identities, we can relate the particle
spectrum at p to the anti-particle spectrum at −p:
dN+1
d3p = |χp|2 dN−1d3(−p) + V(2π)3|χp|2.
However, since the external ﬁeld is spatially homogeneous and the initial state is the empty
state, these two spectra must be equal. Therefore, we get
dN+1
d3p = V(2π)3 |χp|21 −|χp|2 = V(2π)3 ⏐⏐βp⏐⏐2.
This expression exactly coincides with the one obtained in Problem 79. The two-particle


PDF PAGE 216 
 338 5 LATTICE, FINITE T , STRONG FIELDS
spectrum (equal sign) is given by
dN++2
d3pd3q =
⟨
0in
⏐⏐
(
a†p,outap,out
(2π)3
a†q,outap,out
(2π)3 −δ(p −q)a†p,outap,out(2π)3 )⏐⏐0in⟩
= 1(2π)6 ⟨0in⏐⏐a†p,outa†q,outap,outaq,out⏐⏐0in⟩
= dN+1
d3p
dN+1
d3q +δ(p −p) V(2π)3|βp|4 .
Note that in the ﬁrst line, we are explicitly subtracting the delta function contribution in order
to agree with the deﬁnition used in Problem 79, where the bi-spectrum was deﬁned so that its
integral is the mean value ofN+(N+ −1).
Additional Note: In order to uncover the whole probability distribution, we can ﬁrst factorize
the Fock space into a direct product of the Fock spaces for different momentak. An arbitrary
state
⏐⏐Ψ⟩ can be written as a tensor product,
⏐⏐Ψ⟩ ≡⨂
k
⏐⏐Ψ⟩k.
Since particles and anti-particles are produced in pairs of opposite momenta, it is natural to
group together particles of momentum k and anti-particles of momentum −k under the same
labelk. Thus we deﬁne the vacuum states
⏐⏐0,0⟩k of the subspaces k as
ak,out
⏐⏐0,0⟩k = b−k,out⏐⏐0,0⟩k = 0,
and
⏐⏐0out⟩ is a tensor product of the vacuum states of the different modes,
⏐⏐0out⟩ =⨂
k
⏐⏐0,0⟩k .
An outgoing state withm particles of momentum k andn anti-particles of momentum −k at
x0 →∞ is then denoted by
⏐⏐m,n⟩k =( a†k,out√m!V)m(b†−k,out√n!V )n⏐⏐0,0⟩k.
(Arbitrary states can be constructed from tensor products of these states.)
Applying this decomposition, the in vacuum state leads to
⏐⏐0in⟩ =⨂
k
{
(1 +|βk|2)−1/2 exp[ βkVα∗ka†k,outb†out−k]⏐⏐0,0⟩k}.
By expanding the exponential we get
⏐⏐0in⟩ =⨂
k
{
(1 +|βk|2)−1/2
∞∑
mk=0
(βk
α∗k
)mk ⏐⏐mk,mk⟩k
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ |0in⟩k
}
.
In order to obtain the inclusive probabilityPk(m) of havingm pairs of momentum (k, −k),
we need to sum over all the possible numbers of pairs in the other momentum modes. This


PDF PAGE 225 
 82 ANDERSON LOCALIZATION 347
ρ → −∞. Therefore, the horizon of the black hole is located on the two semi-axes x+ = 0
andx− = 0. It turns out that, in the Kruskal coordinates, there is no singularity at the horizon,
and they can also be used below the horizon.
Note now that (5.40) are formally identical to the relationship between the light-cone
coordinates of the static and accelerated observers, as discussed for the Unruh effect, provided
we interpret (4M)−1 as the acceleration. Therefore, we can exactly reproduce the same steps
without any modiﬁcation: (1) decompose the ﬁelds in Fourier modes in the two systems of
coordinates, (2) ﬁnd the Bogoliubov transformation that relates the two sets of creation and
annihilation operators, (3) calculate the expectation value of the number operatorb†kbk of onesystem in the vacuum state of the other system. This leads to
⟨
0kruskal
⏐⏐(b†kbk)staticobs. ⏐⏐0kruskal⟩ = Ve8πMk −1,
i.e., a thermal equilibrium distribution with a temperature T =( 8πM)−1 (this is known as
the Hawking temperature). Let us end with a remark about why we use the Kruskal vacuum
in the last equation. Loosely speaking, in the presence of a black hole, other vacuum states,
deﬁned by non-freely falling observers, would have a very large energy density near the black
hole (because excitations that are not freely falling must have an energy that compensates
for the gravitational potential). This energy density would act as a source term in Einstein’s
equations and therefore have a strong back-reaction on the metric. Therefore, the physical
setup of quantum ﬁelds on top of an unperturbed Schwarzchild metric can only be achieved
with the Kruskal vacuum.
82. Anderson Localization In a periodic atomic lattice, the electronic eigenfunctions take
the form of Bloch states, whose energies span continuous bands. An electron whose energy
lies in such a band can propagate freely over macroscopic distances (whether the material is a
conductor or an insulator depends on whether the Fermi energy lies inside a band or between
two bands). The goal of this problem is to show that, in a disordered medium, electrons are
localized and cannot propagate.
82.a Check thatγ0 =(100 −1),γi =( 0σ i−σi 0 ) provide a valid representation of the Dirac ma-
trices. Using this representation, show that the two upper components are the dominant
ones in the non-relativistic limit, and show that the Dirac equation becomes
i∂tφ =
(
m −eA0 − (∇ −ieA)2
2m +eB·σ2m )φ.
82.b Show that the two-point functionG(x,y ) ≡
⟨
φ(x)φ†(y)⟩ obeys a Dyson equation of
the formG = G0 +ieG0A0G in the case of a purely electric external ﬁeld.
82.c Consider a medium in which the potential A0 has local Gaussian ﬂuctuations with
a variance
⟨
A0(x)A0(y)⟩ = σδ (x − y). Write the Dyson equation satisﬁed by G
at order e2. By calculating the self-energy that appears in this equation, show that
the denominator of the dressed propagator has an imaginary part, which leads to an
exponential damping of electronic waves.


PDF PAGE 226 
 348 5 LATTICE, FINITE T , STRONG FIELDS
82.a To check that the announced matrices are a valid representation of the Dirac matrices,
we must verify that {γμ,γν} = 2gμν. This is completely straightforward using the fact that
σiσj +σjσi = 2δij. With this representation in mind, we write the four-component Dirac
spinors as a combination of two two-component objects:
us(p) ≡
(
φ(p)
χ(p)
)
.
Consequently, the Dirac equation (/p −m)us(p)= 0 can be split into two separate equations
forφ andχ,
(Ep −m)φ −(p·σ)χ = 0, (Ep +m)χ −(p·σ)φ = 0,
from which we get
χ = 1Ep +m (p·σ)φ ≈p≪m p·σ2m φ.
Therefore, if we denoteφ(x) ≡ φ(p)e−ip·x, we obtain
i∂tφ(x)=
(
m + (p·σ)2
2m
)
φ(p)e−ip·x =(m − ∇2
2m
)
φ(x),
which is the non-relativistic Schr¨odinger equation (the term inm could be removed if we factor
out an explicit factore−imt from the wavefunction). Thus, we see that, in this representation,
the two upper components of a Dirac spinor obey the Schr¨odinger equation, while the two lower
components are suppressed by a power ofp/m (and in addition they are not independent).
This equation, valid for a free fermion, can be promoted to an equation for the evolution of
a non-relativistic fermion in an external electromagnetic ﬁeld by simply replacing the ordinary
derivatives by covariant ones: ∂μ → Dμ ≡ ∂μ − ieAμ. But in doing so, one should keep
in mind that ∇ and A do not commute, which imposes that we do this replacement before
eliminating the Pauli matrices:
i∂tφ =
(
m −eA0 −
(
∇ −ieA)·σ
)2
2m
)
φ
=
(
m −eA0 − (∇ −ieA)2 +e(Ai∇j +∇iAj)ϵijkσk
2m
)
φ
=
(
m −eA0 − (∇ −ieA)2
2m +eB·σ2m/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ H
)
φ,
where B is the external magnetic ﬁeld. From this Schr ¨odinger equation, we read the Hamilto-
nianH that drives the evolution of this fermion in the non-relativistic limit.


PDF PAGE 227 
 82 ANDERSON LOCALIZATION 349
82.b When the external ﬁeld is a pure electric ﬁeld, we may choose a gauge in whichA = 0,
so that the above Hamiltonian simpliﬁes to
H = m − ∇2
2m −eA0.
Consider the time-ordered two-point correlation function of the non-relativistic ﬁeldφ,
G(x,y ) ≡
⟨
Tφ(x)φ†(y)⟩ = θ(x0 −y0)⟨φ(x)φ†(y)⟩ −θ(y0 −x0)⟨φ†(y)φ(x)⟩.
Applying a time derivative to this deﬁnition, and recalling the equal-time anti-commutator{
φ(x),φ†(y)} = δ(x−y) (this is the restriction to the two upper components of the canonical
anti-commutation relation of Dirac spinors), we obtain
(
i ∂∂x0 −H)G(x,y )= iδ (x −y).
We can also deﬁne the free correlation functionG0, deﬁned as a Green’s function of the
free Hamiltonian, H0 ≡ m − ∇22m . Since H = H0 −eA0, the equation forG can be rewrittenas follows:
(
i∂x0 −H0
)
G = iδ(x −y)− eA0G.
This can be solved formally in the form of a Dyson equation,
G = G0 +ieG0A0G.
82.c Diagrammatically, the expansion of the solution of the Dyson equation for the propaga-
tor reads
= + + + + . . . GG 0 ieA0 .
If the external potential is ﬁxed, the next step is to perform the geometrical sum contained in
this solution (which may be a rather difﬁcult task if the potentialA0 has a non-trivial spatial
dependence).
Another interesting situation is when this potential ﬂuctuates, with a probability distribution
W[A0]. In this case, the above solution must be averaged over all the conﬁgurations of A0,
weighted by the distribution W[A0]. Diagrammatically, this amounts to connecting all the
crosses in the above representation by links and vertices as allowed byW[A0]. For instance, a
random time-independent external potential with only local Gaussian ﬂuctuations would have
the following distribution:
W[A0]= exp( − 12 ∫ d3x A0(x)A0(x)2σ ),
for which the only possible connection is a link
⟨
A0(x)A0(y)⟩ = σδ (x −y).
(This is independent of time, and the delta function is a spatial one.) With such Gaussian
ﬂuctuations of the external ﬁeld, the expectation value of the propagator takes the following


PDF PAGE 228 
 350 5 LATTICE, FINITE T , STRONG FIELDS
form:
= + + + + . . . 
1PI non 1PI
.
This has the form of a propagator dressed by self-energy corrections. This plain perturba-
tive expansion can be improved by calculating the self-energy at a certain order in e2 and
by re-summing its repeated insertions on the free propagator (this is a geometrical series).
When doing this, it is important to include only one-particle-irreducible contributions in
the self-energy in order to avoid double counting. If we restrict ourselves to the order- e2
self-energy, the equation for the dressed propagator is a Dyson equation that reads
= + .
This is simple algebraic equation in momentum space:
G(p)= G0(p)+ G0(p)
(
−iΣ(p)
)
G(p), i.e., G(p)= i
p0 −m − p22m −Σ(p),
and the self-energy is given by
Σ(p)=− ie2σ
∫ d4k
(2π)4 2πδ (k0) ip0 +k0 −m − (p+k)22m
= 2e2σm
∫ k2dkd cosθ
(2π)2
1
2m(p0 −m)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≈ p2 on-shell
−p2 −k2 −2pk cosθ
=− e2σmp ∫ kdk(2π)2 ln(k +2pk −2p)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
iπθ (2p−k)+real terms
=− ie2σmp2π + real terms.
Note that the real part of the self-energy, which we have not calculated here, is ultraviolet
divergent. This could be remedied on physical grounds by noting that the inverse inter-atomic
distance should certainly act as a cutoff in this integral since the external ﬁeld is not an
uncorrelated noise on atomic scales.
However, the main result here is the fact that the self-energy has an imaginary part
proportional to the strength of the ﬂuctuations of the external ﬁeld. The physical implication
is that fermions cannot propagate in such a disordered medium, since their propagator in
coordinate space is exponentially damped. The damping length is given by the inverse of the
imaginary part ofΣ and is thus inversely proportional to the strengthσ of the ﬂuctuations of
the external ﬁeld. Moreover, this imaginary part exists at all values of the momentump, which
means that there is no energy range where electrons can propagate freely in this material. This
phenomenon, known as Anderson localization, is a very important result of solid-state physics
that implies that disordered media are insulators (unlike periodic media, which may have a
conduction band, i.e., an energy range in which the electronic states – known as Bloch states –
are completely delocalized over macroscopic sizes).


exit_code=0
```

### 2026-11-16T17:48:57.488033+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in [176,177,178,179]]'
```

```text

PDF PAGE 176 
 298 5 LATTICE, FINITE T , STRONG FIELDS
73. Photon Hard Thermal Loop from Classical Particles In this problem, we use
the concept of a classical particle developed in Problem 31 in order to derive the effective
Lagrangian that generates hard thermal loops in QED. This derivation illustrates the classical
nature of hard thermal loops, and is also a good workout in preparation for the QCD case (see
Problem 74).
73.a Find a suitable generalization of the equations of motion discussed in Problem 37 to
describe the evolution of the position and momentum of a massless charged particle in
an external electromagnetic ﬁeld.
73.b Consider a collection of classical electrons and positrons, with a phase-space density
f(x,p ). Why do we have df/dτ = 0? Using the equations of motion of the classical
particles, turn this equation into a kinetic equation.
73.c Consider now an expansion off,f = f0 +f1 +··· , wheref0 is a distribution independent
of the external ﬁeld. Formally solve the kinetic equation in order to obtain the ﬁrst
correction in the external ﬁeld,f1.
73.d Determine the electromagnetic current Jμ induced by f1 (assume that f0 produces no
current). Then, determine an effective LagrangianLeff such thatJμ = ∂Leff/∂Aμ.
73.e Show that its second derivative, −δLeff/δAμδAν, is the photon polarization tensorΠμνHTL
in the hard thermal loop approximation.
73.a In the classical particle approximation of Problem 37, the charged particles feel the
effect of the background electromagnetic ﬁeld, but their own radiation is not considered.
Therefore, the particles do not feed the electromagnetic ﬁeld, and there are no interactions
between the charged particles. Since we are going to consider the ultra-relativistic limit, we
need to adapt the equations of motion to the case of massless particles. Formally, we can start
from the equations obtained in Problem 37, and deﬁneτ ≡ t/m before completely eliminating
m. This leads to
pμ = dxμ
dτ , dpμdτ = eFμνpν.
Note that since the particles are massless, τ is not really a time but simply some parameter that
maps the trajectory of a particle (in fact, this parameter has the dimensions of a squared time).
73.b Let us denote by f(x,p ) the phase-space density of these charged particles. By the
Liouville theorem,f is constant along the trajectories in phase-space (equivalently, the volume
in phase-space is preserved by a Hamiltonian ﬂow). Then, we can rewrite the time derivative
off more explicitly:
0 = dfdτ = dxμdτ ∂f∂xμ + dpμdτ ∂f∂pμ = pμ ∂f∂xμ +eFμνpν ∂f∂pμ
= pμ
( ∂
∂xμ −eFμν ∂∂pν)f.
This type of kinetic equation is known as a Vlasov equation. The ﬁrst term, p·∂xf, describes
the free streaming of particles, i.e., the motion at constant momentum of free particles. The


PDF PAGE 177 
 73 PHOTON HARD THERMAL LOOP FROM CLASSICAL PARTICLES 299
second term describes the deﬂection of their trajectories due to the force the particles feel from
the external ﬁeld in which they propagate.
73.c The Vlasov equation can be solved iteratively by writing
f = f0 +f1 +··· ,
where f0 is some distribution of free particles (it must obey p · ∂xf0 = 0), f1 is the ﬁrst
correction due to the external ﬁeld, etc. In the ﬁrst iteration, we have
p·∂xf1 = epμFμν ∂f0∂pν.
Indeed, iff1 is the correction of ﬁrst order in the external ﬁeld, we do not need to keep it on the
right-hand side, so that the left- and right-hand sides have the same order ine. This equation
can be solved formally to give
f1 = epμ
1
p·∂x
Fμν ∂f0
∂pν.
73.d The next step is to deﬁne the electromagnetic current associated with the distribution f:
Jμ(x) ≡ e
∫ d3p
(2π)3
pμ
p f(x,p ).
One may check that this current is conserved iff obeys the Vlasov equation:
∂μJμ = e
∫ d3p
(2π)3p (p·∂)f = e2
∫ d3p
(2π)3ppμFμν ∂f∂pν =− e2
∫ d3p
(2π)3p
∂pμ
∂pν
/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
gμν
Fμν
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 0
f = 0.
With the iterative solution obtained above, the current reads
Jμ = e
∫ d3p
(2π)3p pμ
(
f0 +epρ
1
p·∂x
Fρν ∂f0
∂pν +···
)
.
If we assume that the free distributionf0 does not produce any current, the ﬁrst term is zero
(physically, this is realized when the free distributionf0 has equal distributions of electrons
and positrons). Therefore, at order one in the external ﬁeld, the current reads
Jμ = e2
∫ d3p
(2π)3p
pμpρ
p·∂x
Fρν ∂f0
∂pν =− e2
∫ d3p
(2π)3p
∂
∂pν
(pμpρ
p·∂x
)
Fρν f0
=− e2
∫ d3p
(2π)3p
(δνμpρ
p·∂x
+ pμgνρ
p·∂x/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
→0
− pμpρ∂ν
(p·∂x)2
)
Fρν f0.
Note that the middle term gives zero after contraction with the antisymmetric tensor Fρν.N o w ,
we would like to determine an effective LagrangianLeff such that
Jμ = ∂Leff
∂Aμ
.
SinceJμ is linear in the external ﬁeld, this effective Lagrangian must have one more power of
A. Moreover, in order to be gauge invariant, this additionalA dependence should arise via a


PDF PAGE 178 
 300 5 LATTICE, FINITE T , STRONG FIELDS
power of the ﬁeld strength. In order to ﬁnd this Lagrangian, recall ﬁrst that
∂Fαβ
∂Aμ
= ∂(∂αAβ −∂βAα)∂Aμ = δβμ ∂α −δαμ ∂β.
Then, consider
∂
∂Aμ
(
Fνβ
pβpρ
(p·∂)2Fρν
)
=( δβμ∂ν −δνμ∂β) pβpρ(p·∂)2Fρν +Fνβ pβpρ(p·∂)2 (gμν∂ρ −gρμ∂ν)
= pμpρ
(p·∂)2
(
∂νFρν +Fρν∂ν) −2 pρp·∂Fρμ
=− pμpρ
(p·∂)2
(
∂νFρν/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
0
)
−2
(δνμpρ
p·∂ − pμpρ∂ν(p·∂)2)Fρν.
(Note that the derivatives act on everything located to their right, including the zeroth-order
phase-space distribution f0, not yet included in this formula. To obtain the ﬁnal line, we
usedFρν∂ν ··· = ∂νFρν ··· −(∂νFρν)··· . Finally, we have∂νFρν = 0 because the charged
particles are not feeding the external ﬁeld in this approximation (and we assume that the
sources producing this ﬁeld are far away). Up to a factor2, we recognize the structure of the
integrand in the currentJμ. Therefore, the effective Lagrangian whose derivative givesJμ reads
Leff = e22 ∫ d3p(2π)3p Fνβ pβpρ(p·∂)2Fρν f0.
73.e Let us now consider
Πμν =− ∂Jμ
∂Aν
= e2
∫ d3p
(2π)3p
(
gμν − pμ∂ν +pν∂μ
p·∂ + pμpν∂2(p·∂)2) f0.
To recover the HTL result, we replacef0 by the equilibrium fermion distribution,
f0(x,p )= 2×2× 1eβ|p0| +1
(the two prefactors2 account for electrons and anti-electrons, and for the fact they have two
spin states), and we Fourier transform the external coordinates (which simply amounts to the
replacement∂ → ik), so that
Πμν(k)= 4e2
∫ d3p
(2π)3p
(
gμν − pμkν +pνkμ
p·k + pμpνk2(p·k)2) 1eβp +1
(p0 = p in this equation). Note that the factor between the parentheses is homogeneous
of degree zero in p, and therefore depends only on the orientation ˆp of p. By writing


PDF PAGE 179 
 74 GLUON HARD THERMAL LOOP FROM COLORED CLASSICAL PARTICLES 301
d3p = p2dpd2ˆp, we can easily factorize the radial and angular integrals:
Πμν(k)= 2e2
∫ +∞
0
dp p
π2
1
eβp +1 ×
∫ d2ˆp
4π
(
gμν − ˆPμkν +ˆPνkμ
ˆP·k +
ˆPμˆPνk2
(ˆP·k)2
)
,
whereˆP ≡ (1,ˆp). The radial integral reads
2e2
∫ +∞
0
dp p
π2
1
eβp +1 = 2e2T2π2 ∫ +∞0 dx x(e−x −e−2x +e−3x −e−4x +··· )
= 2e2T2
π2
( 1
12 − 122 + 132 −··· ) = 2e2T2π2 ζ(2)2 = e2T26 .
In order to compare with the known results for the photon hard thermal loop, it is enough to
check the component Π00 and the trace Πμμ. The angular integration reduces to three basic
integrals,
∫ d2ˆp
4π = 1,
∫ d2ˆp
4π
1
ˆP·k = 12k ln⏐⏐⏐k0 +kk0 −k⏐⏐⏐,∫ d2ˆp
4π
1
(ˆP·k)2
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
− ∂∂k0 1ˆP·k
= 1
(k0)2 −k2,
and we obtain
Πμμ(k)= e2T26 ∫ d2ˆp4π (4 −2ˆP·kˆP·k +
0/bracehtipdownleft/bracehtipupright/bracehtipupleft/bracehtipdownright
ˆP2 k2
(ˆP·k)2
)
= e2T2
3 ,
Π00(k)= e2T2
6
∫ d2ˆp
4π
(
1 −2 k0
ˆP·k + k2(ˆP·k)2) = e2T23 (1 − k02k ln⏐⏐⏐k0 +kk0 −k⏐⏐⏐).
These results provide the two independent terms that enter into the photon hard thermal loop.
Although the gain provided by this approach to calculating the HTL contribution to the photon
polarization tensor is marginal, it becomes appreciable when applied to the case of QCD, and
does not require much more effort (as opposed to an approach in terms of Feynman diagrams).
Moreover, the present discussion highlights the fact that, in the HTL approximation, the particle
running in the loop is in fact classical.
74. Gluon Hard Thermal Loop from Colored Classical Particles This problem is a
continuation of Problem 73. Extend the method of that problem (with the help of the results
of Problem 37) in order to compute the gluon polarization tensor in the hard thermal loop


exit_code=0
```

### 2026-11-16T17:49:15.599743+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in range(183,191)]'
```

```text

PDF PAGE 183 
 75 LANDAU–POMERANCHUK–MIGDAL EFFECT 305
vertex. The main reason why it is possible to capture the HTL results in such a simple setting
is that when the momentum circulating in the loop is much larger than the external momenta,
then all the couplings of the external lines to the loop become eikonal, and therefore universal
(in particular, independent of the spin). In this approximation, the only thing that distinguishes
the various ﬁelds that can circulate in the loop is their phase-space distribution, their color
representation and the corresponding number of degrees of freedom, while all the kinematical
dependence is universal.
Sources: Kelly, P. F., Liu, Q., Lucchesi, C. and Manuel, C. (1994),Phys Rev Lett 72: 3461;
Pisarski, R. D. (1998), Kinetic theory of hot gauge theories: Overview, details & extensions, in
S´anchez, N. and Zichichi, A. (eds.), Current Topics in Astrofundamental Physics: Primordial
Cosmology, NATO ASI Series, vol. 511 (Springer), p. 195.
75. Landau–Pomeranchuk–Migdal Effect The goal of this problem is to study the
emission of soft photons by a hot plasma of electrons and anti-electrons, and in particular
to discuss the Landau–Pomeranchuk–Migdal effect, an interference effect that reduces the
emission of soft photons in a hot medium.
75.a Recall the relationship between the photon emission rate and the imaginary part of the
retarded photon self-energy.
75.b Explain why this self-energy can be obtained as
−iΠijR (x,y )=− δJiind(x)δAj(y),
where Jiind is the electromagnetic current induced by the application of an external
potentialAj. Write this current in terms of the deviations from equilibriumδfe,δf ¯e of
the electron and anti-electron distributions.
75.c Show thatδfe obeys the following Boltzmann–Vlasov equation:
(v·∂x)δfe − eT (v·E)nF (p)(1 −nF (p)) = δCe,p[δf],
whereδCe,p is a collision term andnF is the Fermi–Dirac distribution.
75.d By explicitly writing the collision term with two-body collisions, show that
δCe,p =− e3nF (p)(1−nF (p))
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥+m2D )
[
F(x,p)− F(x,p −𝓁⊥)
]
,
wheremD is the photon Debye mass andδfe ≡ eT nF (1 −nF )F.
75.e Apply a Fourier transform to thex dependence, and discuss qualitatively the effect of
the integral on𝓁⊥ in the collision term.
75.f Extra: in the regime where m ≫ mD , transform the Boltzmann–Vlasov equation into a
diffusion equation that one may solve analytically.


PDF PAGE 184 
 306 5 LATTICE, FINITE T , STRONG FIELDS
75.a We consider a hot plasma of electrically charged electrons and anti-electrons of massm
(this could be their in-vacuum mass or, at very high temperature, the mass they acquire in the
plasma due to their interactions with their environment), interacting via photon exchanges (this
point is not crucial and one could easily generalize this discussion to interactions via gluon
exchanges). The photon emission rate from a sample of this plasma can be obtained from the
in-medium photon self-energy, as follows:
2k0(2π)3 dNγd4xd3k = ∑pol. λϵ(λ)μ (k)ϵ(λ)ν (k)2 Im( −iΠμνR (K))eβk0 −1 .
There are various variants of this formula, differing in which form of the self-energy is used.
Here, we choose the formula that involves the retarded self-energy, because we will want later
to obtain it from linear response theory. To be deﬁnite, let us choose the photon momentumk
to be aligned with thex3 direction. For on-shell photons, the sum over the polarizations simply
produces a projector on the planex1,x2 transverse to the photon momentum:
∑
pol. λ
ϵ(λ)μ (k)ϵ(λ)ν (k)Πμν(K)= ∑
i=1,2
Πii(K).
75.b The retarded photon self-energy can be viewed as a retarded correlation function
between a pair of electromagnetic currents (this is correct in linear gauges, where there is no
spurious triple or quartic photon coupling). Then, by the same reasoning as for the derivation
of Kubo’s formula (see, for instance, Mahan, G. D. (2000), Many-Particle Physics (Kluwer
Academic)), the retarded current–current correlator can be obtained by looking at the induced
current (the response) that appears in the system when we apply an external ﬁeld Aj (the
source):
−iΠijR (x,y )=− δJiind(x)δAj(y), with Jiind ≡ e⟨ψγiψ⟩.
Since we want the photon self-energy in equilibrium, we need only consider arbitrarily small
external ﬁelds (in other words, we calculate the induced current only at linear order in the
applied external ﬁeld).
In thermal equilibrium, there are no net currents in the system (since the fermions and
anti-fermions have opposite charges and the same momentum distribution). The induced
current can be obtained as
Jiind(x)= 2e
∫ d3p
(2π)3 vi(δfe(x,p)− δf¯e(x,p)),
where vi ≡ pi/Ep andδfe (resp. δf¯e) is the deviation from Fermi–Dirac of the electron (resp.
anti-electron) distribution induced by the external ﬁeld (think of an electric ﬁeld, which pulls
electrons and anti-electrons in opposite directions). The prefactor 2 is due to the two spin
states of an electron.
75.c The external ﬁeld acts on the fermions of the system via the Lorentz force. The other
effect that affects the fermion distribution is their collisions, which are responsible for the


PDF PAGE 185 
 75 LANDAU–POMERANCHUK–MIGDAL EFFECT 307
relaxation to equilibrium. Therefore, the equation that controls f and ¯f is a Boltzmann–Vlasov
equation:
(v·∂x)fe
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
free streaming
+e
(
E +v×B
)
· ∇pfe
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Vlasov term
= Ce,p[fe,f ¯e]/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
collisions
,
wherevμ ≡ (1,vi). The Vlasov term, proportional to the Lorentz force, is responsible for the
change of the momenta of the particles as they move in the external ﬁeld. The anti-electron
distribution obeys the same equation with the changee → −e to account for the fact that they
feel the opposite Lorentz force. In this problem, we need only consider small deviations of the
distribution about the equilibrium Fermi–Dirac distribution, fe ≡ nF +δfe, f¯e ≡ nF +δf¯e,
and we can linearize the above Boltzmann–Vlasov equation in δfe,δf ¯e. Recalling that the
deviationsδfe,δf ¯e are of the same order as the external electromagnetic ﬁeldE,B, and that
the collision term vanishes when evaluated with the equilibrium Fermi–Dirac distribution, we
obtain
(v·∂x)δfe +e
(
E +v×B
)
· ∇pnF/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1T nF (1−nF )v
= δCe,p[δf],
where we denote by δC the linearized collision term. Since the Fermi–Dirac distribution is
isotropic, its derivative with respect to momentum is proportional to the velocity v, imply-
ing that only the electric ﬁeld E contributes. In the following, it will prove convenient to
parameterize the deviationsδf2,δf ¯e as follows:
δfe(x,p) ≡ eT nF (p)(1 −nF (p))F(x,p),
δf¯e(x,p) ≡ −eT nF (p)(1 −nF (p))F(x,p),
where the functionF(x,p) is the same in both cases.
75.d Before linearization, the collision term with two-body collisionspq → p′q′ reads
Ce,p[f, ¯f]= ∑
α=e,¯e
∫
p′,q,q′
(2π)4δ(p +q −p′ −q′) 116EpEp′EqEq′
⏐⏐⏐Mpq→p′q′⏐⏐⏐2
×
{
(1−fe(x,p))fe(x,p′)(1−fα(x,q))fα(x,q′)
−fe(x,p)(1−fe(x,p′))fα(x,q)(1−fα(x,q′))},
where we have used the shorthand
∫
q ≡
∫ d3q
(2π)3 . Note that we sum over the two kinds of
scattering partners, electrons and anti-electrons. Next, we expand the distribution functions
about nF , keeping only terms linear in the deviations. Since δfe and δf¯e are opposite, the
deviations of the distributionfα of the scattering partner cancel when we sum over electrons
and anti-electrons. Therefore, we get
δCe,p =− 2eT ∫p′,q,q′ (2π)4δ(p +q −p′ −q′) 116EpEp′EqEq′ ⏐⏐⏐Mpq→p′q′⏐⏐⏐2
×nF (p)(1−nF (p′))nF (q)(1−nF (q′))[F(x,p)−F(x,p′)].
Note that the momentum transfer 𝓁 ≡ p −p′ = q′ −q is soft (of the order of the Debye mass,
i.e., ∼ eT) compared to the typical momentum of the electrons and anti-electrons (of the order


PDF PAGE 186 
 308 5 LATTICE, FINITE T , STRONG FIELDS
of the temperatureT). This implies that the scattering amplitude is dominated by the t-channel
diagram. Consequently, there is no difference between scattering off an electron and off an
anti-electron, hence the prefactor2. Then, in order to rewrite the integrals in the collision terms
in terms of𝓁, we can use
∫ d3p′
(2π)22Ep′
d3q
(2π)22Eq
d3q′
(2π)22Eq′ (2π)4δ(p +q −p′ −q′)
≈
∫ d4𝓁
(2π)4
d3q
(2π)32Eq
1
4EpEq
(2π)2δ(𝓁0 −𝓁·v)δ(𝓁0 −𝓁·vq),
where we have neglected terms quadratic in the soft momentum 𝓁 and where we denote
vq ≡ q/Eq. We can also use the approximation
nF (p)(1−nF (p′)) ≈ nF (p)(1−nF (p)),
nF (q)(1−nF (q′) ≈ nF (q)(1−nF (q),
and note that the integrated squared matrix element (at ﬁxed transfer 𝓁) can be expressed in
terms of the hard thermal loop spectral function (i.e., the imaginary part of the HTL photon
propagator):
2
∫ d3q
(2π)3 2πδ(𝓁0 −𝓁·vq)nF (q)(1−nF (q)
⏐⏐Mpq→p′q′⏐⏐2
16E2pE2q ≈ e2 T𝓁0vμvν ρμνHTL (𝓁),
with
ρμνHTL (𝓁) ≡ ∑
α=T,L
Pμνα (𝓁) 2 ImΠα(𝓁)(𝓁2 − ReΠα(𝓁))2 +( ImΠα(𝓁))2
(vμ ≡ (1,vi), and the projectors PμνT,L were deﬁned following Eq. (5.14)). Therefore, thelinearized collision term becomes
δCe,p =− e3T nF (p)(1−nF (p))
×
∫ d4𝓁
(2π)4 2πδ(𝓁0 −𝓁·v)T𝓁0vμvν ρμνHTL (𝓁)[F(x,p)− F(x,p −𝓁)].
Here, it is important to recognize thatF(x,p) is strongly peaked whenp is aligned with the
photon momentum, i.e., with the z axis. As a consequence, the variations of F are much faster


PDF PAGE 187 
 75 LANDAU–POMERANCHUK–MIGDAL EFFECT 309
when p varies in the transverse direction than in the longitudinal direction, implying that
F(x,p)− F(x,p −𝓁) ≈ F(x,p)− F(x,p −𝓁⊥).
For the same reason, we can approximateδ(𝓁0 −𝓁·v) ≈ δ(𝓁0 −𝓁z). Using the explicit form
of the projectorsPμνT,L(𝓁),w eh a v e
vμvνPμνL (𝓁)=− vμvνPμνT (𝓁)=𝓁0=𝓁z 𝓁2⊥𝓁20 +𝓁2⊥.
It is convenient to introduce the variablex ≡ 𝓁0/|𝓁|, since the HTL photon self-energies depend
only onx. The Jacobian of this change of variable is given by
d𝓁0d2𝓁⊥
𝓁0
𝓁2⊥
𝓁20 +𝓁2⊥ = dxd2𝓁⊥x .
Therefore, the collision term reads
δCe,p =− e3nF (p)(1−nF (p))
∫ d2𝓁⊥
(2π)2
[
F(x,p)− F(x,p −𝓁⊥)
]
× 2π ∫10 dxx { ImΠL (x)(𝓁2⊥+ReΠL (x))2+(ImΠL (x))2 − ImΠT (x)(𝓁2⊥+ReΠT (x))2+(ImΠT (x))2 }/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=
m2D
𝓁2⊥(𝓁2⊥+m2D )
.
The identity used in the second line, wheremD is the Debye screening mass, is an exact sum
rule satisﬁed by the photon HTL self-energies.
75.e Combining the above results, the Boltzmann–Vlasov equation can be written as follows
in terms ofF:
(v·∂x)F(x,p)+ e2T
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
[
F(x,p)− F(x,p −𝓁⊥)
]
= v·E.
Using E ≡ −∂tA and applying a Fourier transform to turn x into the photon momentum K,
this equation leads to
δF(K,p)
δAj(K) = k0vjK·v +i e2TK·v ∫ d2𝓁⊥(2π)2 m2D𝓁2⊥(𝓁2⊥ +m2D )[δF(K,p)δAj(K) −δF(K,p−𝓁⊥)δAj(K) ] (5.22)
(recall thatv ≡ p/Ep), whose solution must be inserted into
Im
(
−iΠijR (K)) =− 4e2T ∫ d3p(2π)3 nF (p)(1 −nF (p))vi Im(δF(K,p)δAj(K) ).
The integral term in (5.22) takes into account the collisions of the emitter with the other
particles in the plasma, while the ﬁrst term on the right-hand side of this equation would give
the contribution of the processe → eγ. Note that this collisionless contribution gives a purely


PDF PAGE 188 
 310 5 LATTICE, FINITE T , STRONG FIELDS
real δF/δAj and therefore does not contribute to the photon yield, as expected from trivial
kinematics.
The equation (5.22) could in principle be solved iteratively in powers ofe2, by inserting
inside the integral the solution obtained at the previous order. Assuming thatδF/δAj is of order
one as in the collisionless limit, then the integral in (5.22) is also of order one (the typical𝓁⊥ is
of the order of the Debye mass mD ). We therefore see that multiple collisions all contribute to
the same order ifv·K ≲ e2T. On the other hand, simple kinematics leads to
v·K ≈ k0
m2 +p2⊥
2p2z . (5.23)
Note that v · K can be interpreted as the inverse of the photon formation time , i.e., the
time necessary for the photon wave-packet to become separated from that of its emitter. In
more physical terms, multiple scatterings are important when the photon formation time is
comparable to or larger than the mean free path, i.e., the distance traveled by the emitter
between two successive collisions (in this process, the relevant collisions are small-angle
collisions, separated by (e2T )−1). This effect is known as the Landau–Pomeranchuk–Migdal
effect. In this regime, there is no point in solving (5.22) perturbatively as a series ine2 because
all orders are in fact comparable. From (5.23), we see thatv·K may be small when the electron
momentum is much larger than its mass,pz ≫ m, and its transverse momentump⊥ is small
(quasi-collinear emission of the photon). This is precisely what happens in a plasma at very
high temperature, where the relevant mass is a thermal mass of order m ∼ eT, the typical pz is
of orderT, and photon emission happens predominantly at small anglesθ ∼ e (i.e.,p⊥ ∼ eT).
The effect of these multiple scatterings on the photon spectrum can be estimated roughly
as follows. On the one hand, the photon formation length is 𝓁 ∼ 1/v·K. On the other hand, the
transverse momentum accumulated by the emitter over this distance isp2⊥ ∼ m2D𝓁/λ, whereλis the electron mean free path. This leads to
𝓁
λ ∼ pzmD√k0λ ≫k0→0 1.
This implies that it takes a large number (growing like 1/√k0) of collisions to produce a
single soft photon. In other words, the soft photon spectrum is reduced by a factor √k0
compared to what one would obtain by multiplying the one-collision spectrum by the number
of collisions (this is known as the Bethe–Heitler limit). This suppression is a quantum effect,
due to the destructive interference between photon emissions occurring at various points along
the trajectory of the emitting electron (the photon formation length controls how far apart two
emissions that still interfere can be); see Figure 5.4 for an illustration.
75.f This discussion can be made more quantitative analytically whenm ≫ mD (for this to
be true, the bare mass of the electron must dominate over its thermal mass). In this case, we
may write
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
[δF(K,p)
δAj(K) −δF(K,p−𝓁⊥)δAj(K) ]
≈
∫ d2𝓁⊥
(2π)2
m2D
𝓁2⊥(𝓁2⊥ +m2D )
1
2
(
𝓁⊥ · ∇p
)2δF(K,p)
δAj(K) ≈ m2D8π ln( mmD )∇2pδF(K,p)δAj(K) .
Here, we have used the separation of scale between the typicalp⊥ ∼ m and the Debye mass
mD in order to make a leading logarithmic approximation of the integral over𝓁⊥ (the logarithm


PDF PAGE 189 
 75 LANDAU–POMERANCHUK–MIGDAL EFFECT 311
Figure 5.4 Left: illustration of the Landau–Pomeranchuk–Migdal effect. Right: the Feynman
graphs contributing to the photon self-energy in the LPM regime (the black dots on the
internal photons indicate the hard thermal loop re-summation).
must be large for this approximation to be justiﬁed). In this approximation, the equation (5.22)
that sums the multiple collisions of the emitter becomes a diffusion equation in the transverse
velocity space (v⊥ ≡ p⊥/p):
ik0
(
1
2
(
v2⊥ + m2p2 ) δFδAj −vj) +D∇2v⊥ δFδAj = 0,
where the diffusion constant is deﬁned as D ≡
e2Tm 2D
8πp2 ln(m/mD ). In order to solve this
diffusion equation, let us deﬁneδF/δAj ≡ vj(ϕ(s)+ 1)/s withs ≡ 12v2⊥ (note that we musthaveϕ(0)=− 1 for this to be deﬁned at v⊥ = 0). In terms of ϕ ands,w eh a v e
sϕ′′ +i(α +βs)ϕ +iα = 0, with α ≡ k0m24Dp2 ,β ≡ k02D.
This is a differential equation with polynomial coefﬁcients, which may be solved by taking a
Laplace transform,
v(λ) ≡
∫ ∞
0
dse −λsϕ(s).
First, we obtain a differential equation forv(λ):
v′ + 2λ −iαλ2 +iβ v + 1 −iαλλ2 +iβ = 0.
Since this is a ﬁrst-order equation, it can be solved analytically:
v(λ)=− 1λ21 −λ2(λ1 +λλ1 −λ)μ ∫λ1λ dξ(1 −iαξ)(λ1 −ξλ1 +ξ)μ,
withλ1 ≡ √βe−iπ/4 andμ ≡ (α/2√β)e−iπ/4. In terms of this function, we have


PDF PAGE 190 
 312 5 LATTICE, FINITE T , STRONG FIELDS
∑
i=1,2
Im
(
−iΠiiR (K)) =− 23e2T2 Imv(λ = 0)
= 23 e2T2β Re limλ→0
∫λ1
λ
dξ
(
1 −iαξ)(λ1 −ξλ1 +ξ)μ
= 23 e2T2β Re limλ→0
{
λ1
∫1
0
dx
(1−x
1+x
)μ
−iα
∫1
0
dx
x
[(1−x
1+x
)μ
−1
]
−iα ln
(λ1
λ
)}
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
∼√β whenk0 → 0
∝
k0→0
√
k0.
In the penultimate line, we have directly setλ = 0 in the terms that are regular in this limit, and
isolated a term that has a logarithmic singularity. But note that the singularity only contributes
to the imaginary part, so that the real part has a ﬁnite limit (λ should approach zero along the
positive real axis in order to obtain the correct result). When we combine this result with the
soft limit of the Bose–Einstein factor that multiplies Im (−iΠiiR (K)) in the photon emission
spectrum, we obtain a spectrum in 1/√k0, instead of 1/k0 for bremsstrahlung induced by
a single scattering. Thus, the effect of multiple scatterings is to reduce the emission of soft
photons by a factor√k0, as we had anticipated from our earlier qualitative discussion.
Let us ﬁnish with a general remark about the approach employed here to derive this effect.
Naively, it may seem paradoxical to be able to derive a quantum interference effect by means
of kinetic theory, which assumes that electrons behave completely classically. But in the LPM
effect, the only object whose coherence matters is the photon wavefunction, while the electron
can be totally classical.
Sources: Baym, G., Blaizot, J.-P., Gelis, F. and Matsui, T. (2007),Phys Lett B 644: 48; Migdal,
A. B. (1956), Phys Rev 103: 1811.
76. Microcanonical Equilibration in φ4 Scalar Theory Consider a massless scalar ﬁeld
theory withφ4 interaction in four spacetime dimensions. The goal of this problem is to study
some aspects of classical dynamics in this ﬁeld theory, in relation to thermal equilibration.
76.a What is the canonical energy–momentum tensor in this theory? What is its trace?
76.b What is the equation of state relating pressure to energy density for a scale invariant
system in statistical equilibrium?
76.c Consider a spatially homogeneous classical ﬁeld in this theory. Show that this ﬁeld is a
periodic function of time, and ﬁnd the relationship between the period and the amplitude
of the ﬁeld oscillations. Show that the trace of the energy–momentum tensor is non-zero
for this ﬁeld, but vanishes when averaged over one period.
76.d Consider now a statistical ensemble of such homogeneous classical ﬁelds, obtained by
choosing an ensemble of initial conditions and letting the ﬁelds evolve according to
the classical equation of motion. How does the expectation value of the trace of the
energy–momentum tensor evolve with time?


exit_code=0
```

### 2026-11-16T17:56:11.008369+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in list(range(368,372))+list(range(209,213))]'
```

```text

PDF PAGE 368 
 49 INSTANTONS AS TRANSITIONS BETWEEN PURE GAUGE FIELDS 197
49. Instantons as Transitions between Pure Gauges in Yang–Mills Theory In this
problem, we consider time-independent pure gauge ﬁelds such that Ai(x) → 0 when |x| →∞
(in the gaugeA0 = 0). We show that these ﬁelds can be classiﬁed in topological classes whose
index is a Cartan–Maurer invariant, and that instantons are ﬁeld conﬁgurations that interpolate
between two such pure gauges.
49.a Consider a pure gauge Ai(x) ≡ ig−1Ω†(x)∂iΩ(x), with Ω(x) → 1 at |x| →∞ .
Explain why the homotopy classes of these ﬁelds are the elements ofπ3(SU(N)), with
an indexn given by
n ≡
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ)).
49.b We denote by
⏐⏐nin,out⟩ the asymptotic states made of pure gauges in the homotopy
class of index n. A representative ﬁeld conﬁguration of the topological class n = 0
is Aia(x) ≡ 0. How does this ﬁeld evolve via the classical Yang–Mills equation in
the gauge A0 = 0? Conclude from this that the transitions ⟨nout⏐⏐0in⟩ are classically
forbidden ifn ⁄= 0 and necessarily happen by quantum tunneling.
49.c By analogy with Problem 48, write the path integral representation of this transition
amplitude after going to imaginary time, and argue that the amplitude is dominated by
Euclidean classical solutions.
49.d Recall that the topological index of the instanton is given by
N = g2
∫ d4x
64π2 ϵijklFaijFakl = limR→∞g2
∫
SR
d3Si
16π2 ϵijkl tr
(
AjFkl + 2ig3 AjAkAl),
where SR is a three-dimensional sphere of radius R. Deform the sphere S∞ at inﬁnity
into the surface of a hyper-cube, and show that in the gaugeA0 = 0 this integral is the
difference of two integrals on surfaces atx0 = ±∞, respectively, that are the topological
indices of two pure gauges. Conclude that the instanton of index N interpolates between
pure gauges of index0 andN.
49.a Since the pure gauge ﬁelds Ai(x) under consideration go to a constant when |x| →∞ ,
we may identify all the points at inﬁnity inR 3, which amounts to identifyingR 3 with a3-sphere
S3 (this mapping can be done explicitly by a stereographic projection). Thus, the group element
Ω(x) that deﬁnes the pure gauge can be viewed as a function from S3 to SU(N), and the
homotopy classes are the elements of the third homotopy group ofSU(N),π3(SU(N)). The
topological index of a givenΩ(x) is the appropriately normalized Cartan–Maurer invariant,
n ≡
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ)).


PDF PAGE 369 
 198 3 NON-ABELIAN FIELDS
49.b The topological sectorn = 0 admits as representative the group elementΩ(x) which
is constant and equal to the identity everywhere, i.e., the null gauge potentialAia = 0. In the
gauge A0 = 0, the classical Yang–Mills equations leave this ﬁeld conﬁguration unchanged
throughout all the time evolution. Therefore, the transition from a ﬁeld of index n = 0 to a
ﬁeld of indexn ⁄= 0 is classically forbidden, and can only be mediated by quantum tunneling.
49.c After a transformation to imaginary time, this transition amplitude may be written as
⟨
nout
⏐⏐0in⟩ = ∫ [n]
[0]
[DAi]e−SE [A],
whereSE is the Euclidean action, and where the notations[0] and [n] on the integral symbol are
a reminder of its boundary conditions, namely pure gauge ﬁeld conﬁgurations (which depend
only on x since they are at the boundaries in time) of topological indices 0 andn, respectively.
This path integral is dominated by the minimal action over the set of ﬁelds compatible with
these boundary conditions. On the other hand, we know that the ﬁelds that give the minima of
the Euclidean action are instantons, whose value at the boundary of R 4 is a pure gauge.
49.d The topological indexN of an instanton solution is given by the integral
N = g2
∫ d4x
64π2 ϵijklFaijFakl = g2
∫
∂(R 4)
d3Si
32π2 Ki, (3.55)
with
Ki = 2ϵijkl tr(AjFkl + 2ig3 AjAkAl) =|x|→∞ 4ig3 ϵijkl tr(AjAkAl).
(The ﬁrst term in Ki becomes negligible in the limit |x| →∞ for ﬁelds that go to a pure gauge
at inﬁnity.) The second equality in (3.55) comes from the fact thatϵijklFaijFakl is equal to the
total derivative2∂iKi. Therefore, by Stokes’s theorem, the integral can be rewritten as the
ﬂux ofKi through the boundary at inﬁnity. The result does not depend on the precise shape
of this boundary, and we can thus take a four-dimensional hyper-cube. Two “faces” of this
hyper-cube correspond to the boundaries at inﬁnite time, and all the others are boundaries at
inﬁnity in one of the spatial directions.
Let us consider the A0 = 0 gauge. If i is a spatial direction, then in ϵijklAjAkAl, one
of j,k,l must be 0 and therefore Ki vanishes at inﬁnity on the two faces of the hyper-cube
orthogonal to the spatial directioni. Thus, only the two boundaries atx0 = ±∞ may contribute,
and the topological index of the instanton can be rewritten as
N = 4ig3
3 ϵ0jkl
{ ∫
x0=+∞
d3x
32π2 tr
(
AjAkAl
)
−
∫
x0=−∞
d3x
32π2 tr
(
AjAkAl
)
}
.
In these integrals, the ﬁeld Ai is a pure gauge Ai =( i/g)Ω†∂iΩ, with Ω belonging to the
topological sector 0 (at x0 =− ∞)o r n (at x0 =+ ∞), respectively. The integrals are the


PDF PAGE 370 
 50 VACUA OF YANG–MILLS THEORY 199
corresponding Cartan–Maurer invariants, i.e., the topological indices of the initial and ﬁnal
pure gauges. For instance:
4ig3
3 ϵ0jkl
∫
x0=+∞
d3x
32π2 tr
(
AjAkAl
)
=
∫ d3x
24π2 ϵjkl tr
(
Ω†(∂jΩ)Ω†(∂kΩ)Ω†(∂lΩ))
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
topological indexn ofΩ(x) atx0 =+ ∞
.
Therefore, we have shown that
N = n −0 (more generally,N = n(+∞)− n(−∞)).
Therefore, the instanton of indexN is the Euclidean solution that interpolates between pure
gauges of topological indicesn andn +N.
50. Vacua of Yang–Mills Theory The goal of this problem is to show that classical
Yang–Mills theory has a countable inﬁnity of ground states. When quantum effects are taken
into account, this leads to a continuous set of ground states known as theθ-vacua. Consider
Yang–Mills theory in the temporal gaugeA0 = 0, with the coupling set tog = 1 for simplicity.
50.a What is the conjugate momentum of Ai? Derive the Hamiltonian, and check that
Hamilton’s equations are the usual Yang–Mills equations. Why do we need in addition
to impose Gauss’s law, i.e.,G[A] ≡
[
Di,∂0Ai] = 0, on the classical solutions? (Note
that the quantum analogue of Gauss’s law is that physical states should be annihilated
byG[A].)
50.b Yang–Mills theory in the temporal gauge has a residual invariance under purely spatial
gauge transformationsΩ(x). Explain why the gauge transformation Ω(x) ≡ eiϑa(x)ta
is generated by
Qϑ =−
∫
d3x(∂0Aia)(Diabϑb).
IfΩ(x) goes to the identity at spatial inﬁnity, show that this generator becomes propor-
tional to the Gauss’s law constraint, implying that physical states are in fact invariant
under the action ofeiQϑ .
50.c From the above considerations, show that a vacuum state is a superposition of pure
gauge ﬁeldsiU†∂iU, related to one another by spatial gauge transformations Ω(x) that
go to the identity at inﬁnity.
50.d Consider transition amplitudes between two vacua, the ﬁrst one corresponding toU1 ≡ 1
and the second one toU2(x). Show that U2(x) should go to a constant at inﬁnity for this
amplitude to be non-zero. Why can these U’s be seen as mappings from the3-sphere S3
to the gauge group?
50.e Use the preceding result to conclude that SU(N) Yang–Mills theory has a countable
inﬁnity of inequivalent energy minima, indexed by an integer given by the Cartan–
Maurer invariant. How do quantum ﬂuctuations alter this classical picture? Determine


PDF PAGE 371 
 200 3 NON-ABELIAN FIELDS
which linear combinations of these minima are eigenstates of the quantum Hamiltonian.
Hint: introduce T, the “translation operator” that transforms the ground state of index
n into the ground state of index n + 1, and use the fact that T commutes with the
Hamiltonian. Note: there is a close analogy between these superpositions and Bloch
states in solid-state physics.
50.a By using the temporal gauge A0 = 0, we circumvent the problem that A0a has a vanish-
ing conjugate momentum, because A0 is not a dynamical variable in this gauge. Regarding the
other components of the gauge potential, the conjugate momentumΠi ofAi is given by
Πia ≡ ∂LYM
∂∂0Aia = ∂0Aia.
It is convenient to introduce the chromo-electric and chromo-magnetic ﬁelds by
Eia ≡ F0ia = Πia (inA0 = 0 gauge),B ia ≡ 12ϵijk Fjka ,
in terms of which the Lagrangian density can be written as follows:
−14 Fμνa Faμν =− 14( −F0ia F0ia −Fi0a Fi0a +FijaFija) = 14(2EiaEia −ϵijkϵijlBkaBla)
= 14(2EiaEia −(δjjδkl −δjkδjl)BkaBla) = 12(EiaEia −BiaBia).
Then, the Hamiltonian is given by
H = Πia(∂0Aia)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
EiaEia
−L = 12(EiaEia +BiaBia) = 12ΠiaΠia + 14FijaFija.
(Note that this is also equivalent to the component T00 of the energy–momentum tensor in
Yang–Mills theory.) The Hamilton equations are
∂0Aia = ∂H∂Πia = Πia,∂ 0Πia =− ∂H∂Aia =− ∂jFjia −fabcAbj Fjic .
The ﬁrst equation is equivalent to the deﬁnition of the conjugate momentum, while the second
one reads
∂0F0ia +[Dj,Fji]a = 0,
which is indeed equivalent to the Yang–Mills equations in the vacuum.
Note, however, that the ﬁrst Yang–Mills equation,
[
Dμ,Fμ0] =− [Di,Ei]/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ G[A]
= 0,
does not appear among the Hamilton equations. In the Lagrangian formalism, it would appear
as the variation of the action with respect to A0. But when we set A0 = 0 as the gauge


PDF PAGE 209 
 80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 331
79.f From the results of Problem 77, we know that P0 = exp(−Nclusters). It is only when
particles are produced without any correlations that the mean number of clusters is equal to
the mean number of produced particles N+ (since each particle is its own cluster in that case).
Therefore, we expect in general that P0 ⁄= exp(−N+) due to correlations. This discrepancy
can be made more explicit by using the formulas obtained above. By evaluating the generating
functional at z = z = 0, one obtains the following expression for the vacuum-to-vacuum
transition probability (i.e., the vacuum survival probability):
P0 = exp
(
−Nclusters
)
with Nclusters = V
∫ d3p
(2π)3 ln(1 +fp),
while the total particle multiplicity is
N+ = V
∫ d3p
(2π)3 fp.
Only when the occupation number is small in all modes can we expand the logarithm in P0
and obtain P0 ≈ exp(−N+), but this relationship is not exact in very strong ﬁelds. This is
a limitation of the methods that give only P0 (for instance by providing a way to calculate
the imaginary part of the effective action in a background ﬁeld): in general, knowledge ofP0
is not sufﬁcient to obtain the momentum dependence of the spectrum of produced particles
(proportional tofp).
Source: Fukushima, K., Gelis, F. and Lappi, T. (2009), Nucl Phys A 831: 184.
80. Schwinger Mechanism from Bogoliubov Transformations The goal of this problem
is to rederive some of the results of Problem 79 in the canonical formalism, and to introduce the
concept of Bogoliubov transformation (quite generally, this is a mapping between the creation
and annihilation operators on the Fock space of an observer and those of another observer).
80.a Write the Hamiltonian of the theory of a complex scalar ﬁeld coupled to an external
electromagnetic potential. Specialize it to the gauge A0 = 0. Derive the Hamilton–
Jacobi equations of motion.
80.b Decompose the ﬁeld operator φ in the in and out bases. Show that there is a linear
relationship between the in and out creation and annihilation operators,
ak,out = αk ak,in +βk b†−k,in,b †k,out = α∗−k b†k,in +β∗−k a−k,in,
with|αk|2 −|βk|2 = 1.
80.c Show that the in vacuum state can be expressed in terms of out objects as follows:
⏐⏐0in⟩ = e−V2 ∫ d3p(2π)3 ln(1+|βp|2) e∫ d3p(2π)3 βpα∗p a†p,outb†−p,out ⏐⏐0out⟩,
whereV is the volume of the system.
80.d Use this formula to calculate the inclusive one-particle and two-particle spectra, and
check that they agree with the results of Problem 79.


PDF PAGE 210 
 332 5 LATTICE, FINITE T , STRONG FIELDS
80.a Let us start from the Lagrangian density,
L =
(
Dμφ
)∗(Dμφ)− m2φ∗φ.
The conjugate momentum of the ﬁeldsφ,φ∗ are respectively
Π ≡ ∂L∂∂0φ =( D0φ)∗,Π ∗ ≡ ∂L∂∂0φ∗ = D0φ, (5.33)
from which we obtain the Hamiltonian
H =
∫
d3x(Π∗∂0φ∗ +Π∂0φ −L)
=
∫
d3x(Π∗Π +ieA0Πφ −ieA0Π∗φ∗ +m2φ∗φ +(Dφ)∗(Dφ)).
Here,φ andΠ are operators in the Heisenberg picture satisfying the equal-time commutation
relation,
[
φ(x),Π (y)
]
=
x0=y0
iδ (x −y).
It is convenient for the following discussion to choose a gauge where A0 = 0, because
in this gauge there is a non-ambiguous correspondence between the time dependence of a
wavefunction and the physical energy of the corresponding particle (in particular, the concepts
of positive and negative energies are invariant under the residual gauge freedom). In the
temporal gauge, we have the following Hamiltonian:
H =
∫
d3x(Π∗Π +m2φ∗φ +(Dφ)∗(Dφ)).
The dynamics of the scalar ﬁelds are determined by the Hamilton–Jacobi equations of motion,
∂0φ = i [H,φ ]= Π∗,
∂0Π = i [H,Π ]=( D2 −m2)φ∗.
Note that, since we are not considering self-interactions of the scalar ﬁelds, these equations
of motion are linear. Moreover, since the background electromagnetic ﬁeld is treated as a
classical ﬁeld given once and for all, there are no back-reaction effects (e.g., no photon loop
corrections on the propagator of the scalar). Thanks to the absence of loop corrections, solving
these equations of motion as if they were classical equations of motion is sufﬁcient in order to
obtain the relationship between the ﬁeld operators at x0 =− ∞ andx0 =+ ∞. In other words,
solving exactly the simpliﬁed QFT problem considered here can be reduced to solving a set of
linear partial differential equations.
80.b Let us now decompose the ﬁeld operator on the basis of creation or annihilation
operators. For this, we may choose either the in or the out basis. Let us mention here an
important subtlety. Even if we assume that the external electromagnetic ﬁeld vanishes when
x0 = ±∞, there may be a non-zero gauge potential Ai at asymptotic times, Ain,outi . (Thesegauge potentials are constants, since there is no physical electromagnetic ﬁeld at asymptotic


PDF PAGE 211 
 80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 333
times.) These asymptotic potentials modify the dispersion relation that relates the on-shell
energy and the wavenumberk, since the equation of motion of the ﬁeld contains a covariant
derivativeD rather than the ordinary derivative∂. For this reason, we must replace the usualEk
byEin,out,+k =√m2 +(k +eAin,out)2 for particles and byEin,out,−k =√m2 +(k −eAin,out)2
for anti-particles. Since we have Ein,out,−k = Ein,out,+−k , we can simplify the subsequent notationby systematically using only the energy of the anti-particles, which we denote more simply by
Ein,outk ≡ Ein,out,+k (with k changed into −k when necessary). (In a detector, one measures thekinetic momentum of a particle, p ≡ k±eA. If particles are measured in the ﬁnal state, it
is convenient to choose a residual gauge in whichAout = 0, so that the wavenumber and the
kinetic momentum are identical atx0 =+ ∞.)
With this in mind, the ﬁeld operator may be decomposed in two different ways:
φ(x)=
∫ d3k
(2π)3
[
ak,in√
2Eink φ+k,in(x)+ b†k,in√2Ein−k φ−−k,in(x)]
=
∫ d3k
(2π)3
[
ak,out√
2Eoutk φ+k,out(x)+ b†k,out√2Eout−kφ−−k,out(x)], (5.34)
where the functions φ±k,in andφ±k,out should be determined from the equations of motion (theycannot be simple plane waves because of the external ﬁeld). Note that we have adopted here a
slightly different normalization of the creation and annihilation operators than in the rest of
this book. Indeed, because we now haveEink ⁄= Eoutk , this choice of normalization turns out tobe a bit simpler.
As usual, we want the Heisenberg representation ﬁeld operator φ(x) to go to the in
interaction picture ﬁeld operator when x0 → −∞ and to the out interaction picture ﬁeld
operator atx0 → +∞. These boundary conditions are realized if the functionsφ±k,in andφ±k,out
have the following asymptotic behavior:
φ+k,in(x)= e−iEinkx0+ik·x forx0 → −∞,
φ−k,in(x)= eiEinkx0+ik·x forx0 → −∞,
φ+k,out(x)= e−iEoutk x0+ik·x forx0 → +∞,
φ−k,out(x)= eiEoutk x0+ik·x forx0 → +∞.
The corresponding annihilation operators ain,out,b in,out remove an in-state or out-state particle
and anti-particle, respectively. Note that, for further convenience, we have chosen the spatial
dependence in bothφ+k (x) andφ−k (x) to bee+ik·x, and thus the usual negative energy plane
wave e−ik·x corresponds to φ−−k(x). The canonical commutation relation for φ and Π issatisﬁed provided that we have
[
ak,in,a†p,in] =[bk,in,b†p,in] =[ak,out,a†p,out] =[bk,out,b†p,out] =( 2π)3δ(k −p).
(Note the absence of factors2Ek here, because of our choice of normalization in (5.34).)
Because the equation of motion satisﬁed by the ﬁeld is linear, there is a linear transformation
that relates the coefﬁcient functions in the in and out decompositions. Moreover, if the
background ﬁeld depends only on time, then this linear transformation does not mix values of


PDF PAGE 212 
 334 5 LATTICE, FINITE T , STRONG FIELDS
k. Let us introduce coefﬁcient αk andβk (known as Bogoliubov coefﬁcients) such that
lim
x0→+∞φ+k,in(x) ≡
√
Eink
Eoutk
(
αk e−iEoutk x0+ik·x +β∗k eiEoutk x0+ik·x).
In other words, αk and βk are deﬁned by decomposing the time dependence of φ+k,in on
the basis of the e±iEoutk x0 at large x0. In the absence of an external ﬁeld, one would simply
haveαk = 1 andβk = 0. Since (φ+k,in(x0, −x))∗ satisﬁes both the same initial condition as
φ−k,in(x) and the same equation of motion, they are therefore equal everywhere, and we havealso
lim
x0→+∞φ−k,in(x)=
√
Eink
Eoutk
(
α∗k eiEoutk x0+ik·x +βk e−iEoutk x0+ik·x).
Note now that the plane waves that appear in the integrands of the preceding two equations
are nothing but the asymptotic behavior of the waves φ±k,out. Since the waves φ±k,in and the
φ±k,out obey the same linear equation of motion (the Klein–Gordon equation), these linear
relationships are valid at all times (and not just atx0 =+ ∞):
φ+k,in(x)=
√
Eink
Eoutk
(
αk φ+k,out(x)+ β∗k φ−k,out(x)),
φ−k,in(x)=
√
Eink
Eoutk
(
α∗k φ−k,out(x)+ βk φ+k,out(x)).
By inserting these formulas in (5.34), we obtain similar relationships between the creation and
annihilation operators in the two bases:
ak,out = αk ak,in +βk b†−k,in,b †k,out = α∗−k b†k,in +β∗−k a−k,in.
This linear relationship is known as a Bogoliubov transformation . Consistency with the
commutation relations requires that
|αk|2 −|βk|2 = 1.
(One can also check that this condition implies that the charge operator is the same in the two
bases: Qin = Qout.) The above relations can be inverted as follows:
ak,in = α∗k ak,out −βk b†−k,out,b k,in = α∗−k bk,out −β−k a†−k,out.
80.c The vacuum is deﬁned as the state annihilated by all the annihilation operators:
ak
⏐⏐0⟩ = bk⏐⏐0⟩ = 0.
(We ignore the in and out labels for this generic discussion.) A properly normalized state with
one particle of momentumk can be constructed as
⏐⏐k⟩ = a†k√
V
⏐⏐0⟩,
where V is the spatial volume. (Note that here we are departing momentarily from the
convention used in the rest of the book, namely to have one-particle states normalized to2Ek


exit_code=0
```

### 2026-11-16T18:25:00.017237+08:00

```bash
python3 -c 'from pathlib import Path; import re; root=Path("."); files=[root/"tasks"/f"qft-{i:02}"/"instruction.md" for i in range(1,6)]; [(print("\nFILE",p,"\n",p.read_text()[:6000] if p.exists() else "NOT CREATED")) for p in files]; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); pages={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",pages[i])) for i in [40,217]]'
```

```text

FILE tasks/qft-01/instruction.md 
 # QFT-01：真空极化的一圈解析延拓与阈值谱

## 研究问题

在四维 QED 一圈近似下，费曼参数化后的无量纲、在零动量减除的标量积分为

\[
F(z)=\int_0^1 x(1-x)\,\Log\!\left(1-zx(1-x)-i0\right)\,dx,
\qquad z=q^2/m^2.
\]

这里省略了耦合常数和横向张量因子；`z` 是有符号不变量，正时间样动量对应对数割线。主值对数取负实轴下沿，故阈值上方吸收部分的虚部为负。该参数积分与教材按维数正则化得到的真空极化张量同源；本任务关注其有限的动量依赖部分，常数减除已由 `F(0)=0` 固定。

请建立可稳定计算完整复函数的程序，不能只提交低能多项式。你要判断动量是否位于电子对产生阈值 (z=4) 的下方或上方，正确处理复对数分支；再量化低能展开可用到什么范围，并找出阈值以上实部零点。任务给出12个跨越空间样、低能、阈值及高能区间的独立查询点。

## 材料和工具

- `/app/data/model.json`：无量纲定义、12个 (z) 值、搜索区间和相对误差目标。
- `/app/data/physics.py`：严格输出格式和 48 节点的粗略开发探针。
- `/app/data/feedback.py answer.json`：检查格式并显示探针残差。普通固定节点求积在割线和阈值附近可能失准，反馈只是开发信息，不是最终分数。
- `/app/data/metric.json`：原始误差的登记基线、参考值和容差。

运行探针：`python3 /app/data/feedback.py /app/output/answer.json`。

## 输出

在 `/app/output/answer.json` 写一个 UTF-8 JSON 对象：

```json
{
  "cases": [
    {"id": "vp-01", "real": 0.0, "imag": 0.0}
  ],
  "diagnostics": {
    "real_zero_z": 0.0,
    "low_energy_limit_z": 0.0,
    "moment1": 0.0,
    "moment2": 0.0
  },
  "method": "brief method description"
}
```

`cases` 必须恰好包含 `model.json` 中每个工况一次；实部与虚部均用有限实数。`diagnostics` 中：

- `real_zero_z`：搜索区间内满足 \(\operatorname{Re}F(z)=0\) 的阈值以上实根；
- `low_energy_limit_z`：三级展开的相对误差首次达到 1% 的正向动量不变量边界，定义域为 \(0<z<4\)；
- `moment1`、`moment2`：在 \(F(z)=-c_1z-c_2z^2+O(z^3)\) 中报告 \(c_1,c_2\)，作为两个正谱矩。

不得输出 NaN、无穷、布尔值或重复/缺少的 ID。等价的解析式、稳定数值积分或谱表示均可。

## 评价

评分器重新读取产物，并与独立高精度色散积分真值比较。12点复响应误差占 65%，阈值以上实部零点和低能适用边界各占诊断误差 10%，前两个低能谱矩各占 7.5%。复响应实部、虚部误差底限分别是 0.05、0.02；诊断误差底限是 (10^{-12})，均登记在公开 `model.json`。各相对误差截断到 1；原始指标为 0 至 100 的加权百分点误差，越低越好。质量分使用题包 `metric.json` 中登记的实测基线与参考端点及课程统一函数计算。

此题不依赖 GPU。Agent 为 4 CPU、4 GiB 内存，时限 1200 秒；评分器 120 秒。所有计算可使用公开给定模型，不需要下载权重或访问网络。


FILE tasks/qft-02/instruction.md 
 # QFT-02：三体衰变相空间中的窄共振与干涉

研究一个质量为 `M` 的标量母粒子衰变为三个可区分标量粒子。采用教材相空间定义和 \(\hbar=c=1\)；把 \(s=(p_1+p_2)^2\) 作为 Dalitz 区域的一维投影，给定振幅
\[
\mathcal A(s)=g_0+\frac{g_1}{s-m_R^2+i m_R\Gamma_R}.
\]
对每个公开工况，计算完整三体相空间上的总宽度、相干干涉相对贡献，以及累计谱 \(d\Gamma/ds\) 的 10%、50%、90% 分位点。三体相空间投影的权函数为
\[
K(s)=\frac{\sqrt{\lambda(M^2,s,m_3^2)\lambda(s,m_1^2,m_2^2)}}s,
\quad s\in[(m_1+m_2)^2,(M-m_3)^2],
\]
并使用 \(d\Gamma/ds=K(s)|\mathcal A(s)|^2/(256\pi^3M^3)\)。

需要区分 \(|g_0+g_R|^2\) 与 \(|g_0|^2+|g_R|^2\)，不能把窄共振当作一个无宽度的 delta 函数；`decay-02`、`decay-03` 特意把窄峰放在相空间内部或靠近边界。所有输入在 `/app/data/model.json`，格式反馈在 `/app/data/feedback.py`。

其中 \(\lambda(a,b,c)=a^2+b^2+c^2-2ab-2ac-2bc\)。质量、宽度参数的单位为 GeV；\(s\) 和分位点的单位为 GeV²，\(g_0\) 无量纲，\(g_1\) 单位为 GeV²。复数由 `[实部, 虚部]` 表示。采用恒定宽度的标量有效振幅模型，不要求进一步计算自能重求和；有限宽度和非共振背景全部以公开参数为准。

## 干涉量和最终产物

令 \(\Gamma_{\rm inc}\) 是将 \(|\mathcal A|^2\) 替换为 \(|g_0|^2+|g_1/(s-m_R^2+im_R\Gamma_R)|^2\) 后的相空间积分。定义
\[
I=(\Gamma-\Gamma_{\rm inc})/\Gamma_{\rm inc}.
\]
`interference_fraction` 输出有符号的 \(I\)，破坏性干涉可为负。分位数 \(s_p\) 满足 \(\int_{s_-}^{s_p}(d\Gamma/ds)ds=p\Gamma\)。

输出 `/app/output/answer.json`：

```json
{"cases":[{"id":"decay-01","width":0.001,"interference_fraction":-0.2,"s10":2.0,"s50":5.0,"s90":10.0}]}
```

示例数字仅示范格式；须恰好覆盖全部公开工况。所有字段为有限实数，`width>0`，分位点按次序处于各自物理区间，不能重复或遗漏 ID。数组顺序不限，可附加 `method` 说明。

## 探索反馈和评价

`python3 /app/data/feedback.py /app/output/answer.json` 会检查格式、物理区间并返回129点粗网格宽度。窄共振可能被粗网格漏采；探针不提供最终分数。公开 `/app/data/physics.py` 给出区间、密度和格式接口，可用作起点；Python、NumPy、SciPy、mpmath 已固定版本安装。

最终评分与55位独立积分真值比较。定义 \(e_\Gamma=\min(1,|\Gamma-\hat\Gamma|/\hat\Gamma)\)、\(e_I=\min(1,|I-\hat I|/\max(0.05,|\hat I|))\)，以及 \(e_Q=\frac13\sum_{p=0.1,0.5,0.9}\min(1,|s_p-\hat s_p|/(s_+-s_-))\)。原始误差为四工况 \(100(0.45e_\Gamma+0.25e_I+0.30e_Q)\) 的算术平均，单位百分点，越低越好。`metric.json` 公开实测基线、参考端点及 \(10^{-6}\) 百分点容差；课程统一函数换算质量分。固定输入全部公开，最终验证以隔离的私有真值重算误差，不按文本或方法相似度评分。

Agent 使用 4 CPU、4 GiB、0 GPU，限时 1200 秒；verifier 120 秒。题包只需公开输入和数学工具，不需要网络、模型权重或 GPU。


FILE tasks/qft-03/instruction.md 
 # QFT-03：重整化群跨阈值演化与参数可辨识性

教材第 203--205 页给出一圈 QCD \(\beta\) 函数、活跃味数 \(n_f\) 和
\[
\frac{d\alpha_s}{d\ln\mu}=-\frac{\beta_0}{2\pi}\alpha_s^2,
\qquad \beta_0=11-\frac23n_f.
\]
本题采用一圈、阶跃阈值、连续匹配的固定约定。低于 \(m_c,m_b,m_t\) 时分别有 3、4、5、6 个活跃味；在阈值处 \(\alpha_s\) 连续。公开观测是若干能标上的 \(1/\alpha_s(\mu)\)，已四舍五入到 12 位小数。

请对每个工况：

1. 在公开参数边界内反演 \(\alpha_s(1\,\mathrm{GeV})\)、三个阈值和观测设计矩阵的秩；
2. 判断四个参数分别是否可由该工况唯一确定；
3. 在全部公开预测能标上给出 \(\alpha_s\)，并求 \(\alpha_s=0.15\) 的能标 `target_mu`。

`rg-01` 观测跨过三个阈值，`rg-02` 的所有观测均高于 charm 阈值，因此只能确定初始截距与 charm 阈值的组合，`rg-03` 只在 top 阈值以上观测，故会出现更大的不可辨识子空间。观测能标均被公开参数边界分隔，避免一道观测对应多个可能的活跃味数。不能在秩亏数据上武断报告唯一阈值；任何满足公开观测的等价参数化都可得同等预测分。

## 输入、输出和反馈

`/app/data/model.json` 给出观测、参数范围和预测能标；`physics.py` 给出一圈流的公开接口。运行 `python3 /app/data/feedback.py /app/output/answer.json` 可查看观测残差。输出对象的 `cases` 恰好覆盖三个 ID；每项含 `parameters`（`alpha0,mc,mb,mt`）、整数 `rank`、四个布尔 `identifiable`、七个 `predictions` 和正的 `target_mu`。所有阈值/耦合值必须为有限数并处于公开边界。

最终 verifier 重新按阈值区间积分，不使用候选的预测作为真值。原始指标为观测复现 40%、秩与可辨识性 25%、预测 25%、目标能标 10% 的百分点误差；各部分按公开尺度截断到 1，越低越好。课程统一质量函数使用 `tests/metric.json` 的实测 baseline/reference 端点。题目为 CPU 任务，Agent 4 CPU/4 GiB、verifier 120 秒、无网络无 GPU。


FILE tasks/qft-04/instruction.md 
 # QFT-04：康普顿散射的双图干涉与运动探测接受度

## 物理问题与约定

用户提供的《量子场论试题详解》PDF 第 83--85 页（书内 75--77 页）给出康普顿散射的两个树图及 QED 动量空间 Feynman 规则。请把这两个图相干相加，建立精确的电子反冲计算，再求运动电子实验中探测器角窗、能窗筛选后的光子能谱。只使用 Thomson 低能近似，或将两图的概率不相干相加，均不足以覆盖本题。

取 \(m_e=\hbar=c=1\)、\(g_{\mu\nu}=\operatorname{diag}(1,-1,-1,-1)\)，\(r_e^2=\alpha^2/m_e^2\)。所有截面均输出 \(\sigma/r_e^2\)，能量以电子质量为单位，角度为弧度。输入 `x` 是**初始电子静止系**的入射光子能量。该系中

\[
p=(1,0,0,0),\quad k=(x,0,0,x),\quad
k'=(r,r\sqrt{1-c^2},0,rc),\quad c=\cos\theta,
\quad p'=p+k-k',
\]

其中 \(r\) 由末态电子在壳条件 \(p'^2=1\) 确定。输入 `beta_fraction=[a,b]` 精确表示 \(\beta=a/b\)：从初始电子静止系到实验室系沿 \(+z\) 做速度 \(\beta\) 的 Lorentz boost，\(E_{\rm lab}=\gamma(E+\beta p_z)\)。因此负的 \(\beta\) 对应逆向运动电子。

采用实线偏振基

\[
\epsilon_1=(0,1,0,0),\quad\epsilon_2=(0,0,1,0),\qquad
\epsilon'_1=(0,c,0,-\sqrt{1-c^2}),\quad\epsilon'_2=(0,0,1,0).
\]

旋量归一化为 \(\bar u_s(p)u_s(p)=2\)，对初态电子自旋及入射光子偏振平均，对末态求和。省略对概率无影响的共同相位，定义两个无量纲振幅 \(a_s=\mathcal M_s/e^2\)、\(a_u=\mathcal M_u/e^2\)：

\[
a_s=\bar u(p')\slashed\epsilon'^{*}
\frac{\slashed p+\slashed k+1}{2p\cdot k}
\slashed\epsilon\,u(p),\qquad
a_u=\bar u(p')\slashed\epsilon
\frac{\slashed p-\slashed k'+1}{-2p\cdot k'}
\slashed\epsilon'^{*}u(p).
\]

\(\slashed v=\gamma^0v^0-\sum_{i=1}^3\gamma^iv^i\)。定义 \(S=\overline{|a_s|^2}\)、\(U=\overline{|a_u|^2}\)、\(I=2\operatorname{Re}\overline{a_sa_u^*}\) 及 \(T=S+U+I\)。它们均包含上述初态平均。单图贡献按固定偏振约定比较，不能将单图当作独立的规范不变可观测量。精确微分截面为

\[
\frac1{r_e^2}\frac{d\sigma}{d\Omega}
=\frac14\left(\frac r x\right)^2T.
\]

## 需要完成的工作

1. 对 `model.json` 中的每个 `probes` 项，计算 `s_squared=S`、`u_squared=U`、`interference=I`、`total=T`。再同时把每个入射偏振变为 \(\epsilon_i+\eta k/x\)，每个出射偏振变为 \(\epsilon'_j+\zeta k'/r\)，其中 \(\eta,\zeta\) 来自公开输入，计算总振幅平方 `gauge_shifted_total`。总结果应满足 Ward 一致性，单图一般会变化。
2. 对每个 `cases` 项，积分求完整静止系总截面 `sigma`。`lab_theta_window=[theta_min,theta_max]`、`lab_energy_window=[E_min,E_max]` 同时作用于 **boost 后的出射光子**；边界均包含在接受区内。求满足两个窗口的静止系 \(c\) 区间 `accepted_cos_interval=[c_min,c_max]`，无正测度接受区时填 `null`。
3. 在接受区内求截面 `accepted_sigma`、`acceptance=accepted_sigma/sigma`、条件实验室系光子能量均值 `mean_energy`，以及条件能谱的 10%、50%、90% 分位数 `energy_quantiles=[E10,E50,E90]`，按**能量升序**给出。分位数定义为下分位数 \(\inf\{E:F(E)\ge p\}\)；若能量在整个接受区恒定，三个分位数均等于该常量。空接受区时 `accepted_sigma=0`、`acceptance=0`，均值、分位数和区间均为 `null`；`sigma` 仍为全角域总截面。

这里 `accepted_sigma` 是电子静止系散射截面对**实验室探测窗口所选事件**的积分；不额外乘实验室束流的相对流因子。任务中电子静止系的方位角全接受，故对方位角积分为 \(2\pi\)。输入刻意包含低能、高能前向峰、逆向 boost、能量随 \(c\) 反向排序、恒能量以及无事件工况，须以精确运动学处理。

## 材料、产物和开发反馈

公开 `/app/data/model.json` 提供全部输入及评分权重，`physics.py` 提供实验室系运动学与格式检查接口。Python、NumPy、SciPy、mpmath 已固定版本安装；无需网络或 GPU。

在 `/app/output/answer.json` 写 UTF-8 JSON：

```json
{
  "cases":[{"id":"kn-01","sigma":1.0,"accepted_sigma":0.5,"acceptance":0.5,"accepted_cos_interval":[-0.5,0.5],"mean_energy":0.4,"energy_quantiles":[0.3,0.4,0.5]}],
  "probes":[{"id":"amp-01","s_squared":1.0,"u_squared":1.0,"interference":-0.5,"total":1.5,"gauge_shifted_total":1.5}],
  "method":"brief method description"
}
```

示例数字仅演示 schema；两数组分别恰好覆盖全部公开 ID 一次，顺序不限。除规定可为 `null` 的字段外，所有数值均须为有限实数，不能用布尔值、NaN 或 Infinity。截面不能为负，`sigma>0`，接受率位于 \([0,1]\)，非空接受区满足 \(-1\le c_{min}<c_{max}\le1\)。

`python3 /app/data/feedback.py /app/output/answer.json` 检查格式并显示接受率归一化残差，不能代替最终物理验证。评分器使用隔离的 70 位独立真值：截面部分由解析 Klein--Nishina 原函数和独立积分互查，探针由显式旋量逐态求和得到，与参考解的 Dirac 矩阵迹路线分开。

## 评分

对于非空条件量，标量误差为 \(\min(1,|y-\hat y|/\max(10^{-6},|\hat y|))\)。三个能量分位数取此误差平均；区间端点误差为 \(\tfrac12\sum_{j=1}^2\min(1,|c_j-\hat c_j|/2)\)。两个字段都为 `null` 时该部分误差 0，仅一个为 `null` 时误差 1。每个事件工况中，总截面、接受截面、接受率、条件均值、分位数、接受区误差的权重分别是 15%、25%、10%、15%、20%、15%。

每个振幅探针的五个字段分别计算 \(\min(1,|y-\hat y|/\max(1,|\hat y|))\) 并平均。事件工况误差平均占 80%，振幅探针误差平均占 20%；原始指标为其 100 倍，单位百分点，越低越好。`metric.json` 公开实测简单基线、参考端点与 \(10^{-6}\) 百分点容差，课程原版统一函数将原始指标换成质量分。

Agent 为 4 CPU、4 GiB、0 GPU，限时 1200 秒；verifier 120 秒、独立环境、无网络。只需提交上述 JSON，其他文件不参与评分。


FILE tasks/qft-05/instruction.md 
 NOT CREATED

PDF PAGE 40 
 28 1 QUANTUM FIELD THEORY BASICS
between the solutions of the Landau equations and the spacetime diagrams proposed by Cole-
man and Norton. For instance, in the case of the above example, we could use it as a way of
checking that there are no other solutions. Indeed, there could in principle be two additional
reduced diagrams:
k'
−k k
k'
𝓁
k
k'
However, neither of them is kinematically allowed; the left graph would have two non-collinear
particles propagating along the same spacetime interval, and the right graph would have a
physical free particle making a closed loop.
6. Multi-loop Integration in D Dimensions Start from equation (1.42) in Problem 5, in
the special case where the numerator is trivial, i.e.,N ≡ 1. Note that the denominator D is a
quadratic form in the components of the loop momenta, which we may arrange as follows:
D ≡ LtμALμ +LtμBμ +BtμLμ +C, L μ ≡ (𝓁μ1,𝓁μ2,...,𝓁 μL ).
6.a Perform explicitly the integration over theL loop momenta inD dimensions in order to
obtain
I({pi})= iLΓ (m − DL2 )
(−4π)
DL
2
∫
xr≥0
m∏
r=1
dxr
δ
(
1 − ∑r xr)( detA)m− (L+1)D2
(
C detA −Btμ CtA Bμ/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ Δ
+i0+)m−DL2 ,
whereCA is the matrix of co-factors ofA.
6.b Show thatΔ = det
⎛
⎜⎜⎜⎜⎜⎜⎝
A11 ... A 1L Bμ1
A21 ... A 2L Bμ2
... ... ...
AL1 ... A LL BμL
B1μ ... B Lμ C
⎞
⎟⎟⎟⎟⎟⎟⎠ and is of degree two in each variablexr.


PDF PAGE 217 
 81 UNRUH EFFECT, HAWKING RADIATION 339
corresponds to the following deﬁnition:
Pk(m)=
⏐⏐
k
⟨
0in
⏐⏐m,m⟩k⏐⏐2
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright⏐⏐⏐βkαk ⏐⏐⏐2m 11+|βk|2
×
∏
p⁄=k
∞∑
mp=0
⏐⏐
p
⟨
0in
⏐⏐mp,mp⟩p⏐⏐2
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
|αp|2
1+|βp|2 =1
= 11 +|βk|2
( |βk|2
1 +|βk|2
)m
.
This is the so called discrete Bose–Einstein (or geometrical) distribution, obtained in Problem
79. Since momenta are uncorrelated, the full distribution is just the product of the distributions
in each momentum mode.
Source: Fukushima, K., Gelis, F. and Lappi, T. (2009), Nucl Phys A 831: 184.
81. Unruh Effect, Hawking Radiation The goal of this problem is to study the relationship
between the notions of vacuum and particles for an observer at rest and for an accelerated
observer, the ﬁnal result being a derivation of theUnruh effect. A similar approach, sketched at
the end of the solution, can be used to derive the Hawking radiation of black holes (the analogy
is that a ﬁxed observer outside of a black hole feels an acceleration due to the gravitational
ﬁeld).
81.a Show that the coordinates (t,x ) in a frame at rest and (τ,u ) in a frame with a constant
accelerationa in the directionx are related by
t = 1 +aua sinh(aτ),x = 1 +aua cosh(aτ).
81.b Consider the alternative coordinatev ≡ a−1 ln(1 +au). Express (t,x ) in terms of (τ,v ).
Write the expression for the interval ds2 in terms of (τ,v ). Introduce the light-cone
coordinatesx± ≡ t±x,v± ≡ τ±v. How are x± andv± related?
81.c Consider a massless non-interacting scalar ﬁeldφ in (1+1) dimensions. Write its Fourier
decomposition in terms ofx± and in terms ofv±. Note that these two decompositions
require two distinct sets of creation and annihilation operators. Find the Bogoliubov
coefﬁcients that relate these two sets.
81.d Assume that the system is in the vacuum state of the frame at rest. Show that the
accelerated observer sees the following thermal spectrum of particles:
⟨
0rest
⏐⏐(b†kbk)accelerated⏐⏐0rest⟩ = Ve2πk/a −1.


exit_code=0
```

### 2026-11-16T18:25:58.088019+08:00

```bash
python3 -c 'from pathlib import Path; import re; t=Path("planning/source-notes/qft-gelis-all.txt").read_text(); p={int(n):s for n,s in re.findall(r"===== PDF PAGE (\d+) =====\n(.*?)(?=\n===== PDF PAGE |\Z)",t,re.S)}; [(print("\nPDF PAGE",i,"\n",p[i])) for i in range(163,169)]'
```

```text

PDF PAGE 163 
 70 NIELSEN–NINOMIYA THEOREM 285
69.c Inserting this expression in (5.18), we immediately get
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
The integrand in the deﬁnition ofρV (λ) is a distribution that has a delta peak at each eigenvalue
of the ﬁnite volume Dirac operator, and its integral over some range [λ1,λ2] counts the number
of eigenvalues in that range, per unit of volume V. The average over all conﬁgurations of
the gauge ﬁeldAμ washes out the delta peaks and turnsρV (λ) into a smooth distribution that
provides the average density of eigenvalues of the Dirac operator:
∫λ2
λ1
dλ ρV (λ)=
⟨# of eigenvalues in [λ1,λ2]
V
⟩
A
.
Note that this distribution has a gap at the lower end of the spectrum because of the ﬁnite
volume.
69.d As the volume increases, the gap at the lower end decreases, andρV (λ) has support in
the entire range [0, +∞) in the inﬁnite-volume limit. Moreover, when the quark mass goes to
zero, we have
lim
m→0+
m
λ2 +m2 = πδ (λ).
Therefore, we have
lim
m→0+
⟨
ψ(x)ψ(x)
⟩
=− π lim
V→∞
ρV (0).
This relation is known as the Banks–Casher relation. The left hand side is a quantity known
as the chiral condensate. In the massless limit, the Dirac Lagrangian is invariant under chiral
transformations, since it does not contain an operator ψψ (which breaks chiral symmetry).
A non-zero expectation value of this operator therefore signals that the ground state of the
theory breaks chiral symmetry. The Banks–Casher formula relates the chiral condensate, which
quantiﬁes the spontaneous breaking of chiral symmetry, to the spectral density at the lower
end of the spectrum of the Dirac operator (the latter is controlled by how quickly eigenvalues
accumulate nearλ = 0 when the volume becomes inﬁnite).
Source: Banks, T. and Casher, A. (1980), Nucl Phys B 169: 103.
70. Nielsen–Ninomiya Theorem The goal of this problem is to prove theNielsen–Ninomiya
theorem, an obstruction to the construction of chiral gauge theories on the lattice. Consider
an inﬁnite square lattice of spacing a. The conjugate momenta pμ are continuous variables
with components in the range
[
− πa, +πa] and any function ofpμ is periodic with period 2π/a.In other words, we may view momentum space as a four-dimensional torusT4. The inverse
propagator of a massless left-handed fermion can be written as S−1(p)= ∑μ γμPLFμ(p),
whereFμ(p) is a real continuous vector ﬁeld onT4 andPL ≡ (1 −γ5)/2.


PDF PAGE 164 
 286 5 LATTICE, FINITE T , STRONG FIELDS
70.a Explain why such a fermion exists if the vector ﬁeldFμ(p) has a zeropμ∗ in the vicinity
of which it behaves asFμ(p)=( p −p∗)μ +O((p −p∗)2). Note that the ﬁeld lines of
Fμ are all pointing away fromp∗.
70.b Consider now a zero ofFμ(p) at which the ﬁeld lines are incoming in one direction and
outgoing in the other three directions, such asFμ(p)=( − 1)δμ1 (p−p∗)μ +O((p−p∗)2).
Show that this zero in fact describes a right-handed particle. Hint: apply a similarity
transformation γ1γ5. Use this result to explain why, in one dimension, there must be
equal numbers of left-handed and right-handed fermions in the spectrum of the lattice
Dirac operator.
70.c More generally, explain the relationship between the handedness of a fermion and the
number of “ingoing directions” of the vector ﬁeldFμ at a zerop∗.
70.d The index of a zero of a vector ﬁeld is deﬁned as (−1)n, where n is the number of
dimensions along which the ﬁeld lines are ﬂowing away from the zero. The Poincar´e–
Hopf theorem states that the sum of the indices of the zeroes of a vector ﬁeld is equal to
the Euler characteristic of the manifold on which it is deﬁned, which is zero for a torus.
Use this result to conclude that this lattice setup in fact has equal numbers of left-handed
and right-handed fermions.
70.a The form S−1(p)= ∑μ γμPLFμ(p) for the inverse propagator assumes (discrete)
translation invariance on the lattice, and that the lattice is inﬁnite, so that the conjugate
momentum space is continuous rather than discrete. Because of the ﬁnite lattice spacing, the
momentumpμ is deﬁned on a four-dimensional torusT4 (each component of the momentum is
bounded, and the bounds in the positive and negative directions are identiﬁed) rather than R 4.
The functionFμ(p) is real if the Lagrangian is Hermitian, and is continuous provided the theory
is quasi-local (i.e., when the action is written as S ≡ ∑x,y ψ(x)h(x,y)ψ(y), the function
h(x,y) should decrease fast enough). Since Fμ(p) has as many components (μ = 1,2,3,4 )a s
its argumentp, it is a vector ﬁeld. Moreover, Fμ(p) may be viewed locally as the gradient of a
scalar function F(p),Fμ(p)= ∂pμF(p).
A massless fermion corresponds to a momentump∗ where the inverse Dirac propagator
vanishes linearly (think of the propagatori//p in the continuous theory). This means that all
the components ofFμ(p) vanish simultaneously atp∗,
Fμ(p) ∼ fμν(p −p∗)ν.
By an appropriate change of coordinates, the matrix of coefﬁcientsfμν can be made diagonal,
with only positive coefﬁcients. Up to a rescaling (by positive factors) of the components of pμ,
this implies the announced behavior nearp∗. These zeroes of the vector ﬁeldFμ(p) correspond
to minima of F(p). About such a zero, the ﬁeld lines of Fμ are all oriented outwards fromp∗.
Note that, because we have included an explicit projectorPL in the deﬁnition of the inverse
propagator, these zeroes describe left-handed fermions.


PDF PAGE 165 
 70 NIELSEN–NINOMIYA THEOREM 287
70.b Let us now ﬂip the orientation of the ﬁeld lines along one direction, i.e., consider a zero
for which the ﬁeld lines are ﬂowing away along three directions and into the zero along the
remaining direction (for instance the directionμ = 1):
Fμ(p)=( − 1)δμ1 (p −p∗)μ +O((p −p∗)2).
As suggested in the statement of the problem, we should study the following combination:
(γ1γ5)−1(−1)δμ1γμPL (γ1γ5)= γ5γ1(−1)δμ1γμPLγ1γ5
=
{
μ = 1 :− γ5γ1γ1PLγ1γ5 = γ1PR
μ ⁄= 1 :+ γ5γ1γμPLγ1γ5 = γμPR
}
= γμPR.
(Note that we also have (γ1γ5)−1(−1)δμ1γμPR (γ1γ5)= γμPL .) Therefore, this type of zero
describes (in disguise, i.e., up to a similarity) a massless fermion of right-handed chirality. This
observation is sufﬁcient to prove the Nielsen–Ninomiya theorem in one dimension: indeed, a
smooth vector ﬁeld on a circle must have an equal number of zeroes where the ﬁeld lines go
towards the zero (corresponding to left-handed fermions) and zeroes where the ﬁeld lines go
away from the zero (corresponding to right-handed fermions).
70.c Consider now a zero such that the vector ﬁeld is ﬂowing into the zero along two
directions and away from it along two directions. If the two dimensions along which the ﬁeld
is ﬂowing inwards areμ = 1,2 , we need now to considerFμ(p)=( − 1)δμ1 (−1)δμ2 (p −p∗)μ.
We have
(γ2γ5)−1(−1)δμ2
[
(γ1γ5)−1(−1)δμ1γμPL (γ1γ5)](γ2γ5)
=( γ2γ5)−1(−1)δμ2γμPR (γ2γ5)= γμPL.
Thus, this zero corresponds to a left-handed fermion. The pattern should be clear by now:
the chirality of the fermion ﬂips every time we add a direction along which the vector ﬁeld is
ﬂowing into the corresponding zero. In more mathematical terms, if a1,...,a p are distinct
integers in [1,4 ],w eh a v e
(γapγ5)−1 ··· (γa1γ5)−1
[
(−1)μa1 ··· (−1)μapγμPL
]
(γa1γ5)··· (γapγ5)
=
{γμPL ifp is even,
γμPR ifp is odd.
In words, the zero describes a left-handed fermion if the ﬁeld lines are ﬂowing into the
zero along an even number of directions, and a right-handed fermion for an odd number of
directions.
70.d The index of a zero of a vector ﬁeld is deﬁned as (−1)n, where n is the number
of dimensions along which the ﬁeld lines are ﬂowing away from the zero (see Figure 5.1).
Therefore, ind dimensions, we have the following correspondence between the index of a zero


PDF PAGE 166 
 288 5 LATTICE, FINITE T , STRONG FIELDS
Figure 5.1 Two-dimensional vector ﬁelds with zeroes of index +1 (Left: Fμ(p)= pμ) and −1
(Right: Fμ(p)=( − 1)δμ1pμ).
ofFμ and the chirality of the fermion it describes:
index= (−1)d ←→ left-handed,
index= (−1)d+1 ←→ right-handed.
The usefulness of this concept in the present discussion stems from thePoincar´e–Hopf theorem,
which relates the sum of the indices of the zeroes of a smooth vector ﬁeld deﬁned on a manifold
M without boundary to a topological invariant of this manifold, namely its Euler characteristic,
denoted byχ(M):
∑
zeroesz∗
index (z∗)= χ(M).
For two-dimensional manifolds, the Euler characteristic can be easily visualized and calculated
from any triangulation of the surface, since it is given by
χ(M)=( number of vertices)−( number of edges)+( number of faces).
(See Problem 42 for a discussion of the main properties of this quantity, in particular the fact
that it does not depend on the chosen triangulation.) From this deﬁnition, one may see that the
Euler characteristic of a2-sphere isχ = 2 and that it isχ = 0 for a two-dimensional torus with
one handle. This implies that any smooth vector ﬁeld on such a torus must have equal numbers
of zeroes of index +1 and −1, as illustrated in Figure 5.2. In the discussion of chiral fermions
on the lattice, this result implies that any such propagator would in fact describe equal numbers
of left-handed and right-handed fermions in two dimensions, despite the fact that we have put
an explicit projectorPL in it. This obstruction to the possibility of deﬁning chiral fermions on
the lattice is known as the Nielsen–Ninomiya theorem.
The Euler characteristic is in fact zero for one-holed tori in any dimension (but this is harder
to visualize in dimensions higher than two), in particular for the torusT4 on which the vector
Fμ(p) that enters in the inverse fermion propagator is deﬁned. Thus, the Nielsen–Ninomiya
theorem is also valid in four dimensions.


PDF PAGE 167 
 70 NIELSEN–NINOMIYA THEOREM 289
Figure 5.2 Illustration of the Poincar´e–Hopf theorem: smooth vector ﬁeld on a torus in two
dimensions with a zero of index +1 (open circle) and a zero of index −1 (ﬁlled circle).
Sketch of a Proof of the Poincar ´e–Hopf Theorem: The ﬁrst step in proving the Poincar´e–
Hopf theorem is to show that the sum of the indices of the zeroes is the same for all the
smooth vector ﬁelds. In fact, one can show (see, for instance, Milnor, J. W. (1997),Topology
from the Differentiable Viewpoint (Princeton University Press)) that the sum of the indices
of any smooth vector ﬁeld on a d-dimensional manifold M is equal to twice the degree of
the Gauss mapping fromM to the sphereSd (loosely speaking, this degree counts how many
times the Gauss mapping wraps around Sd), and is therefore a property of M itself. Then one
could invoke the Gauss–Bonnet theorem (see Problem 22) to relate this quantity to the Euler
characteristic.
A more elementary approach is to construct a special vector ﬁeld on M for which it is
easy to relate the sum of the indices to the Euler characteristic χ(M). For this, we start from a
triangulation of the manifoldM. For a two-dimensional manifold, this is a decomposition of
M into planar triangles, while in three dimensions it is a decomposition into tetrahedrons, and
more generally a decomposition ind-simplices ind dimensions. Note that, in a triangulation,
d-dimensional simplices meet at a (d −1)-dimensional simplex, etc. On such a triangulation,
consider the vector ﬁeld of Figure 5.3 (illustrated here in two dimensions). In this ﬁgure, the
triangle in boldface shows the conﬁguration of the ﬁeld lines in one cell of the triangulation,
and all the other triangles simply replicate the same pattern. This ﬁeld has zeroes at all the
vertices of the triangulation, at the midpoints of all the edges, and at the centers of all the
triangles. Moreover, if we count the number of dimensions along which the ﬁeld lines are
oriented away from these zeroes, we have
index (vertex)=+ 1,
index (edge midpoint)=− 1,
index (face center)=+ 1,
and the sum of the indices at all these zeroes reads
∑
zeroesz∗
index (z∗)=( number of vertices)−( number of edges)+( number of faces),
which is nothing but the deﬁnition of the Euler characteristic for a two-dimensional manifold.


PDF PAGE 168 
 290 5 LATTICE, FINITE T , STRONG FIELDS
Figure 5.3 Special vector ﬁeld used in the proof of the Poincar´e–Hopf theorem (here, in two
dimensions). Left: layout of the main ﬁeld lines on top of a triangulation of the surface. Right:
detail of the ﬁeld lines in one elementary triangle.
In higher dimensions, one may construct a similar vector ﬁeld, with zeroes at the centers of
all thek-simplices (k ≤ d) that make up the triangulation, and the above pattern generalizes to
index (center ofk-dim simplex)=( − 1)k.
Therefore, for such a ﬁeld conﬁguration ind dimensions, we have
∑
zeroesz∗
index (z∗)=
d∑
k=0
(−1)k × (number ofk-dim simplices),
which is again the deﬁnition of the Euler characteristic of a d-dimensional manifold. Al-
though explicit, the right-hand side of this equation is less practical for calculating the Euler
characteristic in dimensions greater than two because it is hard to visualize triangulations of
higher-dimensional manifolds.
Source: Karsten, L. H. (1981), Phys Lett B 104: 315.
71. Wigner Transform of a Convolution Product The Wigner transform of a two-point
functionF(x,y ) is a function F(X,p ) obtained by Fourier transformingF(x,y ) with respect to
the differencex −y while keeping the dependence on the midpoint coordinateX ≡ (x +y)/2:
F(X,p ) ≡
∫
ddse ip·s F(X + s2,X − s2 ).
Consider a pair of two-point functionsF(x,y ) andG(x,y ) and their convolutionH(x,y ) ≡∫
ddzF (x,z )G(z,y ). Show that their respective Wigner transforms are related by
H(X,p )= F(X,p ) exp
{i
2
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]}
G(X,p ). (5.19)
This result plays a role in the derivation of the Boltzmann equation from the Kadanoff–Baym
equations. It is also an important ingredient in the formulation of quantum mechanics in


exit_code=0
```

### 2026-11-16T18:26:22.288531+08:00

```bash
python3 -c 'from pathlib import Path; import subprocess; out=Path("planning/source-notes/gelis-review-images"); out.mkdir(exist_ok=True); pdf="/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf"; render="/Users/ai4s/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/pdftoppm"; [(subprocess.run([render,"-f",str(p),"-l",str(p),"-r","105","-singlefile","-png",pdf,str(out/f"p{p}")],check=True)) for p in [299,188]]'
```

```text

exit_code=0
```

### 2026-11-16T18:31:02.368519+08:00

```bash
python3 -c 'from pathlib import Path; import re; p=Path("planning/qft-expansion-gelis-review.md"); t=p.read_text(); h=re.findall(r"^### G\d+：.*$",t,re.M); print("file:",p.resolve()); print("bytes:",p.stat().st_size); print("reviewed_candidates:",len(h)); print("\n".join(h)); assert len(h)==16; assert "## 明确不建议直接采用的候选" in t; assert "## 选题进入封装前的统一门槛" in t'
```

```text
file: /Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/planning/qft-expansion-gelis-review.md
bytes: 29383
reviewed_candidates: 16
### G05：Landau 奇点分类与证书
### G11：简并态求和与红外安全（条件备选）
### G26：Gross–Neveu 的质量生成和大 N 有效势
### G29：复杂 Langevin 的正确性诊断
### G37：Wong 色荷输运与路径序
### G43：QCD 天线辐射、色守恒与角序
### G48：双阱 instanton 与零模（备选）
### G49：杨–米尔斯真空绕数与 instanton 拓扑荷
### G52：六胶子 NMHV 树振幅的递推与因子化
### G67：D 维幺正割与全正螺旋有理项
### G69：Dirac 谱与 Banks–Casher 极限
### G70：格点手征倍增的完整零点诊断
### G72：中心对称、边界条件与 Polyakov 环
### G73：Vlasov 推导的 HTL 因果响应
### G75：LPM 形成时间与碰撞积分重求和
### G80：强场 Schwinger 模式混合与成对关联

exit_code=0
```
