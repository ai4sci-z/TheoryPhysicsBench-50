# qft-07 开发验证

{
  "id": "qft-07",
  "checks": 19,
  "passed": true,
  "baseline": 0.1941668798006142,
  "reference": 3.7565563087237505e-07,
  "reference_seconds": 0.18845116700003928,
  "harbor_oracle_nop_passed": true,
  "harbor_sessions": [
    "runs/qft-07/harbor-macos-compat/session-20261116-222641.json",
    "runs/qft-07/harbor-macos-compat/session-20261116-223730.json"
  ]
}

平台：Linux-6.12.76-linuxkit-aarch64-with-glibc2.36，Python 3.12.13；Docker 4 CPU/4 GiB、无网络、0 GPU。依赖固定于题包。

独立真值细节见 `qft-07-truth-validation.json`；所有校准条目和端到端入口产物在 `qft-07-calibration.json`。原始失败与修复命令不删除，见 `qft-06-12-command-log.md`。参考程序、基线、真实错误解、空产物、非法JSON数值及等价记录重排用同一评分器验证。

Harbor原始运行归档在 `runs/qft-07/harbor-macos-compat`；macOS兼容试跑仅将verifier网络声明从no-network改为public，最终task.toml保持独立离线verifier。正式课程Codex三次测评尚未运行，oracle不冒充正式结果。
