# QFT-21：格点费米子倍增、完整零点与局部指数


来源：François Gelis, *Problems in Quantum Field Theory*, 第70题；用户PDF实际页163–168，书页285–290。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与约定

Gelis 第70题用动量环面上的局部指数讨论 Nielsen–Ninomiya 倍增约束。请对公开的四维有限 Fourier 核族找全零点，并给出局部拓扑信息。格距为1，Brillouin 区是 \(p_\mu\in[-\pi,\pi)\)。逆质量零 Weyl 核用实四矢量 \(F_\mu(p)\) 表示：
\[
q_0=p_0,\quad q_i=p_i+s_i\sin p_{i-1}\pmod{2\pi}\quad(i=1,2,3),
\qquad F_i=\sin q_i+a_i\sin(2q_i).
\]
`a` 和 `shear` 分别给出四个 \(a_i\) 与三个 \(s_i\)。该三角坐标变换是环面上的保定向微分同胚；不能把其耦合当作四维随机找根可以忽略的项。

每个孤立非退化零点的指数定义为 \(\operatorname{sgn}\det(\partial F/\partial p)\)。本题还含 \(|a_i|=1/2\) 的**孤立简并零点**：必须报告 Jacobian 行列式0，但局部 Brouwer 映射度由最低非零奇次项决定，不能把指数随手置0。临界前后零点的生成/湮灭可用来核对局部度。`near-critical` 是公开有限距离的近临界例子，仍应按严格输入参数找全简单根。

## 必须交付

每个 `cases` ID 一个 `results` 项，`values` 为零点行数组；每行严格依次为
`[p0,p1,p2,p3,det_J,local_degree,degenerate]`。

- `local_degree` 为数值 +1 或 −1，`degenerate` 为数值0或1。
- 坐标可用任意相差整倍 \(2\pi\) 的代表；评分使用周期最优匹配，行顺序不限。\(+\pi\) 和 \(-\pi\) 是同一点，只提交一次。
- 每个不同零点必须提交，额外零点和遗漏均扣分。`rows:512` 是安全容量上限，**不是正确零点数**。
- 需要计算完整 Jacobian；精确临界参数按解析条件判断简并，不用任意浮点阈值改变物理分类。

请在 `method` 简述根完备性依据，以及净指数怎样与周期核假设相容。本题的总指数约束限于给定连续、周期、局域 Fourier 型 Weyl 核；不宣称所有格点手征实现都不可能。评分基于数值零点、行列式和局部度，方法文字本身不自动获得分数。


## 验证路线

参考解在 q 坐标求 `sin q(1+2a cos q)=0` 的所有根，再用三角逆变换恢复 p。Jacobian 是对角标量导数乘三角坐标Jacobian，后者行列式1。临界a=+/-1/2时，一次项消失但三次项不消失，孤立根的局部度仍为三次系数符号乘其余简单方向的符号。

独立真值把 z=exp(iq) 代入，枚举 `(z²-1)(a z²+z+a)=0` 的全部单位圆根，独立构造完整4x4 Jacobian。它检查原Fourier核残差和各工况局部度之和0。代数根枚举保证完备性，不将随机多初值找根当作真值。

基线保留朴素最近邻动量核的16个角点，并在这些点使用正确参数计算局部信息；在高次谐波产生新doublers时漏点，因此不能获得完整性分。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。
