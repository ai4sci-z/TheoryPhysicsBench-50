# qm-02 本地 Linux 验收记录

## 已完成

题包目录 `tasks/qm-02/` 已包含中文题面、Harbor 配置、固定 Docker 环境、公开参数与反馈、基线、参考解及推导、评分器、课程原版质量换算函数、私有独立真值与指标。该任务对应一整道双有限矩形势垒研究题；四工况不重复计题。

实际环境：Mac 本地 Docker Desktop Linux，`Linux-6.12.76-linuxkit-aarch64-with-glibc2.36`，Python 3.12.13，4CPU、4GB、0GPU；没有连接远程服务器。镜像 `theory-physics-qm02:dev` 已成功构建，基础镜像 digest 与依赖版本沿用已有题包并固定。

## 实测结果

| 对象 | 原始误差（百分点，越低越好） | 质量分 | 时间 |
|---|---:|---:|---:|
| 2001 点等距扫描基线 | 45.92644529600235 | 0 | 0.133 秒 |
| 散射组合与按峰精化参考 | 0.000011118326344938853 | 1 | 0.427 秒 |

容差为 0.0001 百分点，参考解与独立真值的总误差低于该容差。时间是含 Python 启动的单次本地 Linux 实测，不是正式模型作答时间。

独立真值用 60 位 mpmath 状态传播矩阵生成，耗时 28.4 秒，不导入公开 `physics.py` 或参考 `solver_core.py`。四组峰数分别为 3、3、4、3；最窄半高全宽为 `6.60985065366113e-8`。最大驻点方程分子残差约 `5.52e-47`，最大半高根残差约 `1.15e-54`，最大矩阵行列式残差约 `1.13e-55`。积分采用两套分段，记录的最大差约 `3.42e-64`。这些是高精度计算的内部诊断；双精度参考与另一物理表示的一致性另由总误差检验。

## 14 项检查全部通过

1. 参考解与独立真值一致到原始指标容差。
2. 参考解实际改善基线。
3. 注册指标端点与实测一致。
4. 基线质量分 0、参考解质量分 1。
5. 峰和工况重排不改变分数。
6. 格式合法的实质错误解得低分。
7. 漏峰受到惩罚。
8. 重报峰受到惩罚。
9. 峰宽放大十倍受到惩罚。
10. 能窗积分设零受到惩罚。
11. 空对象、布尔值、非有限数、工况重复均被拒绝。
12. 真正执行 `tests/test.sh`，参考提交得 1、缺文件提交无效且得 0。
13. 公开反馈可运行，参考峰处概率流残差小于 `1e-7`。
14. `tests/quality_score.py` 与项目内课程原版文件逐字节相同。

重建最终镜像后，从不挂载项目的干净容器执行起步命令：`feedback.py --case barrier-01 --energy 1.0`，返回 `T=1.3611721791069294e-6`、`R=0.9999986388278208`、概率流残差 `-1.11e-16`。

## 复现入口

全部实际 shell 命令及输出保存在 `checks/qm-02-command-log.md`。运行：

```bash
docker build -t theory-physics-qm02:dev tasks/qm-02/environment
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-qm02:dev python tools/build_qm02_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-qm02:dev python tools/run_qm02_checks.py
```

首次校准使用 `--calibrate`；复核冻结端点时不用该参数。原始数值在 `checks/qm-02-calibration.json`、`checks/qm-02-truth-validation.json`；开发产物保存在 `checks/qm-02-development-answers/`。

## 尚未进行

Harbor oracle/nop 尚未运行，由主代理统一补跑。课程指定 Codex 的三次正式测评尚未进行；本记录不把参考代码运行视为正式模型评测结果。
