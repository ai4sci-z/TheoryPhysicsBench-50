# ed-02 Linux 开发验证

日期2026-11-16；本记录是本地开发验证，不是课程指定Codex的正式测评。

## 实际环境与结果

本地Docker Desktop Linux aarch64，Python3.12.13，NumPy2.1.3、SciPy1.14.1、mpmath1.3.0。4CPU、4GiB、断网、0GPU。没有连接远程服务器。

| 方案 | 原始误差（百分点） | 课程质量分 | 耗时 |
|---|---:|---:|---:|
| 单一半波起点拟合+中心匹配偶极方向图 | 57.43447796201397 | 0 | 0.134秒 |
| 全局投影反演+完整方向图参考解 | 9.806995042351381e-14 | 1 | 0.414秒 |
| 独立65位电流积分答案 | 0 | 1 | 包含于独立真值生成 |
| 错误功率归一化 | 20.0 | 0.6518 | 开发检查 |
| 全部沿用偶极方向性1.5 | 5.6891 | 0.9009 | 开发检查 |

独立真值生成约0.55秒，电流积分/闭式与θ/μ积分交叉核验最大差6.41e-65，极值方程残差3.61e-54以下；六工况半球瓣数为1、1、2、3、3、4。完整报告分别在 `checks/ed-02-truth-validation.json`、`checks/ed-02-calibration.json`。

## 通过的15项检查

参考优于基线、匹配独立真值、固定端点一致、基线0参考1、数组/瓣重排等价、独立合法替代解满分、合法错解处罚、漏瓣处罚、多瓣重复处罚、功率因子处罚、偶极方向性处罚、非法输出拒绝、实际test.sh参考1空提交0、公开反馈可运行且参考残差小、课程quality_score逐字节未改。

未执行本题Harbor oracle/nop与正式Codex三次独立测评，主代理会另行补跑并据实际结果更新。本记录不把本地数值执行冒充Harbor或被测模型结果。

## 复现

所有实际命令和输出在 `checks/ed-02-command-log.md`。在项目根目录运行：

```bash
docker build -t theory-physics-ed02:dev tasks/ed-02/environment
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-ed02:dev python tools/build_ed02_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-ed02:dev python tools/run_ed02_checks.py
```

不带--calibrate核对登记端点，不重新定义尺度。
