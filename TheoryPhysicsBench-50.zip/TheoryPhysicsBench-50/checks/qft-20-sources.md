# QFT-20：Dirac 低谱、Banks–Casher 凝聚与极限次序


来源：François Gelis, *Problems in Quantum Field Theory*, 第69题；用户PDF实际页161–163，书页283–285。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与材料

Gelis 第69题用 Euclidean Dirac 算子的正负配对谱证明 Banks–Casher 关系。现在请对三个**受控合成谱模型**完成凝聚重建和极限判断。它们不是实际格点 QCD 数据。取自然单位，输出正的凝聚幅度 \(S=-\langle\bar\psi\psi\rangle\)；完整有符号谱的单位四体积密度为 \(\rho_V(\lambda)\)。非零本征值为 \(\pm\lambda_j\)，另有 `zero_modes=N0` 个精确零模。

每个 `families` 项给出多体积谱、质量查询和已知 UV 尾。低谱的未知正支密度属于
\[
 \rho(\lambda)=r[1+b(\lambda-g)^2],\qquad g\le\lambda\le\Lambda,
\]
其中 \(r>0,b\ge0,g\ge0\) 在同一谱族内固定。公开谱通过确定性中点分位点产生：
\[
\int_g^{\lambda_j}\rho(\lambda)d\lambda=(j+1/2)/V,\quad j=0,\ldots,N-1,
\qquad \int_g^{\Lambda}\rho(\lambda)d\lambda=N/V.
\]
`edge` 就是该体积的 \(\Lambda\)；当体积增长时趋向固定截止。以上是生成约束，不是额外观测噪声；不得从直方图宽度推断严格零点密度。\(\lambda>\Lambda\) 的正支 UV 密度明确为 \(c/(1+\lambda^2)\)，其中 \(c\) 是公开 `uv_density_coefficient`，负支按偶对称延伸。UV 尾必须积分到无穷，不能遗忘或重复乘二。

有限体积凝聚为
\[
 S(V,m)=\frac{N_0}{mV}+\frac{2m}{V}\sum_j\frac1{\lambda_j^2+m^2}
 +2m\int_\Lambda^\infty\frac{c\,d\lambda}{(1+\lambda^2)(\lambda^2+m^2)}.
\]
定义 \(S_\infty^{(\Lambda)}(m)\) 为把上述非零低谱和替换成对应 \(\rho\) 的连续积分、保持同一个 `edge` 和 UV 尾的结果；零模不包括在内。定义有限体积修正 \(\delta=S_{\rm paired+UV}-S_\infty^{(\Lambda)}\)。先 \(V\to\infty\) 再 \(m\to0^+\) 的幅度记为 \(S_\chi\)。同时判断反向取极限是否有限，精确零模必须单独处理。各族的 `zero_modes` 序列都是次广延的。

## 必须交付

每族一个 `族名-inference` 行，`values` 依次为
`[r,b,g,S_chi,reverse_limit_finite,reverse_limit_diverges]`。两个标志取数值0或1；若无零模，反向极限值为0；若任意固定体积含零模，反向质量极限发散，用标志报告，不能写 Infinity。

每个公开体积/质量一个 `族名-V体积-m质量` 行，ID 已在 `output_specs` 穷举，`values` 依次为
`[S(V,m),N0/(mV),delta,S_infty_matched_cutoff,B,window_usable]`。
这里
\[
 B=|\delta|+N_0/(mV)+|S_\infty^{(\Lambda)}(m)-S_\chi|
\]
是从该点推断手征凝聚的公开保守误差上界。`window_usable=1` 当且仅当 \(B\le\)`window_target`，否则0。这样窗口判定有可核验的标准，不按自由文字或某个固定质量区间评分。所列全部点均要计算，包括不合格的窗口。

这道题同时考查谱归一化、UV尾、零模、有限体积偏差和极限次序。仅输出 \(\pi\rho(0)\) 不能完成任务。


## 验证路线

参考解先以确定性分位点反演 r,b,g，再对完整 +/- 谱直接求和。UV 尾作有理分式积分；低谱连续积分用独立数值求积。私有真值读取独立保留的生成参数，用45位 mpmath 求和、UV求积和低谱解析原函数，不导入参考解或拟合参数。

低谱连续积分原函数来自展开 `1+b(lambda-g)^2`：在端点 g,edge 之间，积分核可写成 arctan、线性项和 log 的组合。检查文件记录解析原函数与45位直接积分的最大差。零模贡献单独计算；次广延N0在固定m的体积极限消失，在固定V的质量极限仍可发散。

基线假设低谱无隙且局部平坦，用前40个低模估计密度，仍做完整有限谱与UV尾求和。它是有明确适用范围的密度近似，分差不是来自故意破坏格式。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。
