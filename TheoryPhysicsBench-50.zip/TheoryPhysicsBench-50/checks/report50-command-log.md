
### 2026-11-16T22:52:19.676794+08:00

```bash
python3 -
```

```text

===== planning/work-order-report50.md =====
# 完成50题报告和README

负责根README.md、报告.md、NOTICE.md、docs/design-and-provenance.md。不修改题包、benchmark.json、测评代码或其他代理工具。

以真实文件为准，读课程原件（../../00-老师原始材料/科研探索课程项目/课程大作业说明.md、附件二、template/报告.md），checks/benchmark-50-inventory.json及各题sources/fairness、provenance。写一份最多4页的中文报告正文（Markdown按4页<!-- pagebreak -->组织），我稍后渲染PDF。说明共同科研目标、六科分布（tm/ed/sp/qm/gr各5，qft25）与独立性、原创改造vs教材来源、公开起点/反馈/输出/统一quality_score、基线与独立真值方法、环境资源与42000秒预算、开发检查的具体证据和局限、人员分工（用户领域选题与目标，AI辅助封装/代码/校验；不可声称专家人工逐式验过全部）。

目前50题Linux数值校准全部通过，Harbor最终验收尚在集中完成，报告可以引用动态证据路径但不得提前冒称完成；不要把oracle/nop视为正式Codex150次。正式测评未做、CLI_VERSION尚待课程统一提供，明确状态并给出后续工具入口tools/run_formal_benchmark50.py（正在另一代理开发）、课程原版tools/course/汇总结果.py。

用户与助教沟通过单人/多题扩展，50题按用户要求做整套，保留课程10–20题及最多20计分的原规则说明，在README简短注明扩展入口不改原规则。不要反复劝用户删题。

README应可独立复现：Python>=3.11主机、Docker、Harbor0.24；任务镜像Python3.12.13 digest+NumPy/SciPy/mpmath固定版本；本地run_harbor_local_checks.py --macos-compat说明仅暂存verifier public（交付no-network），Linux正式不改；目录结构、题索引、参考和基线运行方法、检查/正式运行/汇总命令、无GPU且不连远程服务器、正式结果缺项状态。可新增requirements-dev.txt锁定Harbor0.24.0及开发数值依赖。

NOTICE不擅自给用户代码选择开源许可证。项目私有课程研究包；不附教材PDF/整本OCR/截图；教材/方法归原作者，标明Harbor及Python包第三方来源/许可证不被替代，课程原工具保留来源。不杜撰文献检索/运行结果。相近benchmark仅在现有sources里确实查到的可引用，未充分查证的留作具体范围限制。

所有shell命令先commentary展示，用 tools/run_logged.py --log checks/report50-command-log.md 包装。完成写planning/status-report50.md并汇报。


===== benchmark.json =====
{
  "name": "TheoryPhysicsBench-50",
  "research_goal": "在六门理论物理中检验智能体依据明确物理约定完成建模、推导构造、数值收敛、近似选择与可核验预测的能力。50题为统一Harbor运行的完整开发题集；固定实例通过隔离真值、独立重算和物理证书评分。",
  "version": "0.2.0-dev",
  "tasks": [
    {
      "id": "ed-01",
      "path": "tasks/ed-01",
      "title": "点电荷与介质核壳球的反作用：自力反号和径向平衡",
      "coverage": "电动力学：点电荷与介质核壳球的反作用：自力反号和径向平衡；独立任务材料、参考结果和评分依据见ed-01题包。"
    },
    {
      "id": "ed-02",
      "path": "tasks/ed-02",
      "title": "有限长直天线的角谱反演和多瓣辐射",
      "coverage": "电动力学：有限长直天线的角谱反演和多瓣辐射；独立任务材料、参考结果和评分依据见ed-02题包。"
    },
    {
      "id": "ed-03",
      "path": "tasks/ed-03",
      "title": "圆柱介质波导的全轴对称模、色散与能流约束",
      "coverage": "电动力学：圆柱介质波导的全轴对称模、色散与能流约束；独立任务材料、参考结果和评分依据见ed-03题包。"
    },
    {
      "id": "ed-04",
      "path": "tasks/ed-04",
      "title": "ed-04：相对论性加速电荷的源时间辐射束射",
      "coverage": "电动力学：ed-04：相对论性加速电荷的源时间辐射束射；独立任务材料、参考结果和评分依据见ed-04题包。"
    },
    {
      "id": "ed-05",
      "path": "tasks/ed-05",
      "title": "ed-05：理想导电球的多极电磁散射",
      "coverage": "电动力学：ed-05：理想导电球的多极电磁散射；独立任务材料、参考结果和评分依据见ed-05题包。"
    },
    {
      "id": "gr-01",
      "path": "tasks/gr-01",
      "title": "施瓦西强场光线的散射、捕获与反向冲量参数",
      "coverage": "广义相对论：施瓦西强场光线的散射、捕获与反向冲量参数；独立任务材料、参考结果和评分依据见gr-01题包。"
    },
    {
      "id": "gr-02",
      "path": "tasks/gr-02",
      "title": "非平直 FLRW 宇宙的联合反演、距离和视界",
      "coverage": "广义相对论：非平直 FLRW 宇宙的联合反演、距离和视界；独立任务材料、参考结果和评分依据见gr-02题包。"
    },
    {
      "id": "gr-03",
      "path": "tasks/gr-03",
      "title": "Schwarzschild 类时圆轨道的分支、稳定性与 ISCO",
      "coverage": "广义相对论：Schwarzschild 类时圆轨道的分支、稳定性与 ISCO；独立任务材料、参考结果和评分依据见gr-03题包。"
    },
    {
      "id": "gr-04",
      "path": "tasks/gr-04",
      "title": "Kerr 黑洞局域分裂：负能量是否意味着实际能量提取",
      "coverage": "广义相对论：Kerr 黑洞局域分裂：负能量是否意味着实际能量提取；独立任务材料、参考结果和评分依据见gr-04题包。"
    },
    {
      "id": "gr-05",
      "path": "tasks/gr-05",
      "title": "球对称 Einstein 初值约束：质量、物理密度与极小球分岔",
      "coverage": "广义相对论：球对称 Einstein 初值约束：质量、物理密度与极小球分岔；独立任务材料、参考结果和评分依据见gr-05题包。"
    },
    {
      "id": "qft-01",
      "path": "tasks/qft-01",
      "title": "真空极化的一圈解析延拓与阈值谱",
      "coverage": "量子场论：真空极化的一圈解析延拓与阈值谱；独立任务材料、参考结果和评分依据见qft-01题包。"
    },
    {
      "id": "qft-02",
      "path": "tasks/qft-02",
      "title": "三体衰变相空间中的窄共振与干涉",
      "coverage": "量子场论：三体衰变相空间中的窄共振与干涉；独立任务材料、参考结果和评分依据见qft-02题包。"
    },
    {
      "id": "qft-03",
      "path": "tasks/qft-03",
      "title": "重整化群跨阈值演化与参数可辨识性",
      "coverage": "量子场论：重整化群跨阈值演化与参数可辨识性；独立任务材料、参考结果和评分依据见qft-03题包。"
    },
    {
      "id": "qft-04",
      "path": "tasks/qft-04",
      "title": "康普顿散射的双图干涉与运动探测接受度",
      "coverage": "量子场论：康普顿散射的双图干涉与运动探测接受度；独立任务材料、参考结果和评分依据见qft-04题包。"
    },
    {
      "id": "qft-05",
      "path": "tasks/qft-05",
      "title": "有限红外调节下一圈Pauli形状因子及动量响应",
      "coverage": "量子场论：有限红外调节下一圈Pauli形状因子及动量响应；独立任务材料、参考结果和评分依据见qft-05题包。"
    },
    {
      "id": "qft-06",
      "path": "tasks/qft-06",
      "title": "Goldstone 模式的一圈质量保护与漏图诊断",
      "coverage": "量子场论：Goldstone 模式的一圈质量保护与漏图诊断；独立任务材料、参考结果和评分依据见qft-06题包。"
    },
    {
      "id": "qft-07",
      "path": "tasks/qft-07",
      "title": "赝标量 Yukawa 理论的反项闭合与有限振幅",
      "coverage": "量子场论：赝标量 Yukawa 理论的反项闭合与有限振幅；独立任务材料、参考结果和评分依据见qft-07题包。"
    },
    {
      "id": "qft-08",
      "path": "tasks/qft-08",
      "title": "二维 Schwinger 模型的质量生成与守恒源响应",
      "coverage": "量子场论：二维 Schwinger 模型的质量生成与守恒源响应；独立任务材料、参考结果和评分依据见qft-08题包。"
    },
    {
      "id": "qft-09",
      "path": "tasks/qft-09",
      "title": "Landau 方程的物理奇点分支与夹挤证书",
      "coverage": "量子场论：Landau 方程的物理奇点分支与夹挤证书；独立任务材料、参考结果和评分依据见qft-09题包。"
    },
    {
      "id": "qft-10",
      "path": "tasks/qft-10",
      "title": "简并态、探测分辨率与红外安全可观测量",
      "coverage": "量子场论：简并态、探测分辨率与红外安全可观测量；独立任务材料、参考结果和评分依据见qft-10题包。"
    },
    {
      "id": "qft-11",
      "path": "tasks/qft-11",
      "title": "Casimir 相互作用的双路线重构与有限壁强度",
      "coverage": "量子场论：Casimir 相互作用的双路线重构与有限壁强度；独立任务材料、参考结果和评分依据见qft-11题包。"
    },
    {
      "id": "qft-12",
      "path": "tasks/qft-12",
      "title": "Gross–Neveu 行列式、质量隙与真空选择",
      "coverage": "量子场论：Gross–Neveu 行列式、质量隙与真空选择；独立任务材料、参考结果和评分依据见qft-12题包。"
    },
    {
      "id": "qft-13",
      "path": "tasks/qft-13",
      "title": "复 Langevin 矩的物理解、截断收敛与相消",
      "coverage": "量子场论：复 Langevin 矩的物理解、截断收敛与相消；独立任务材料、参考结果和评分依据见qft-13题包。"
    },
    {
      "id": "qft-14",
      "path": "tasks/qft-14",
      "title": "Wong 色荷输运的路径顺序与规范协变",
      "coverage": "量子场论：Wong 色荷输运的路径顺序与规范协变；独立任务材料、参考结果和评分依据见qft-14题包。"
    },
    {
      "id": "qft-15",
      "path": "tasks/qft-15",
      "title": "大N规范图的完整颜色收缩与平面截断",
      "coverage": "量子场论：大N规范图的完整颜色收缩与平面截断；独立任务材料、参考结果和评分依据见qft-15题包。"
    },
    {
      "id": "qft-16",
      "path": "tasks/qft-16",
      "title": "QCD软天线的色守恒、干涉与角窗选择",
      "coverage": "量子场论：QCD软天线的色守恒、干涉与角窗选择；独立任务材料、参考结果和评分依据见qft-16题包。"
    },
    {
      "id": "qft-17",
      "path": "tasks/qft-17",
      "title": "一个SU(2)径向场族的拓扑荷、作用量与边界证书",
      "coverage": "量子场论：一个SU(2)径向场族的拓扑荷、作用量与边界证书；独立任务材料、参考结果和评分依据见qft-17题包。"
    },
    {
      "id": "qft-18",
      "path": "tasks/qft-18",
      "title": "六胶子NMHV振幅的BCFW通道与旋量协变性",
      "coverage": "量子场论：六胶子NMHV振幅的BCFW通道与旋量协变性；独立任务材料、参考结果和评分依据见qft-18题包。"
    },
    {
      "id": "qft-19",
      "path": "tasks/qft-19",
      "title": "D维切割的额外维信息与一圈有限有理项",
      "coverage": "量子场论：D维切割的额外维信息与一圈有限有理项；独立任务材料、参考结果和评分依据见qft-19题包。"
    },
    {
      "id": "qft-20",
      "path": "tasks/qft-20",
      "title": "Dirac 低谱、Banks–Casher 凝聚与极限次序",
      "coverage": "量子场论：Dirac 低谱、Banks–Casher 凝聚与极限次序；独立任务材料、参考结果和评分依据见qft-20题包。"
    },
    {
      "id": "qft-21",
      "path": "tasks/qft-21",
      "title": "格点费米子倍增、完整零点与局部指数",
      "coverage": "量子场论：格点费米子倍增、完整零点与局部指数；独立任务材料、参考结果和评分依据见qft-21题包。"
    },
    {
      "id": "qft-22",
      "path": "tasks/qft-22",
      "title": "中心对称、有限体积扇区混合与 Polyakov 环",
      "coverage": "量子场论：中心对称、有限体积扇区混合与 Polyakov 环；独立任务材料、参考结果和评分依据见qft-22题包。"
    },
    {
      "id": "qft-23",
      "path": "tasks/qft-23",
      "title": "热光子 HTL 的因果响应与集体模",
      "coverage": "量子场论：热光子 HTL 的因果响应与集体模；独立任务材料、参考结果和评分依据见qft-23题包。"
    },
    {
      "id": "qft-24",
      "path": "tasks/qft-24",
      "title": "完整差分碰撞核下的 LPM 响应与近似选择",
      "coverage": "量子场论：完整差分碰撞核下的 LPM 响应与近似选择；独立任务材料、参考结果和评分依据见qft-24题包。"
    },
    {
      "id": "qft-25",
      "path": "tasks/qft-25",
      "title": "标量强场产对、相干脉冲与玻色统计",
      "coverage": "量子场论：标量强场产对、相干脉冲与玻色统计；独立任务材料、参考结果和评分依据见qft-25题包。"
    },
    {
      "id": "qm-01",
      "path": "tasks/qm-01",
      "title": "非对称双 δ 势阱的束缚态与空间局域化",
      "coverage": "量子力学：非对称双 δ 势阱的束缚态与空间局域化；独立任务材料、参考结果和评分依据见qm-01题包。"
    },
    {
      "id": "qm-02",
      "path": "tasks/qm-02",
      "title": "双矩形势垒的窄共振与能量平均透射",
      "coverage": "量子力学：双矩形势垒的窄共振与能量平均透射；独立任务材料、参考结果和评分依据见qm-02题包。"
    },
    {
      "id": "qm-03",
      "path": "tasks/qm-03",
      "title": "双原子狄拉克晶格的 Bloch 能带与有限周期环",
      "coverage": "量子力学：双原子狄拉克晶格的 Bloch 能带与有限周期环；独立任务材料、参考结果和评分依据见qm-03题包。"
    },
    {
      "id": "qm-04",
      "path": "tasks/qm-04",
      "title": "多段旋转驱动下的自旋相干演化与失谐灵敏度",
      "coverage": "量子力学：多段旋转驱动下的自旋相干演化与失谐灵敏度；独立任务材料、参考结果和评分依据见qm-04题包。"
    },
    {
      "id": "qm-05",
      "path": "tasks/qm-05",
      "title": "非谐与双阱振子的能谱、局域宽度和偶极矩",
      "coverage": "量子力学：非谐与双阱振子的能谱、局域宽度和偶极矩；独立任务材料、参考结果和评分依据见qm-05题包。"
    },
    {
      "id": "sp-01",
      "path": "tasks/sp-01",
      "title": "平均场铁磁体的多分支平衡与亚稳态",
      "coverage": "统计物理：平均场铁磁体的多分支平衡与亚稳态；独立任务材料、参考结果和评分依据见sp-01题包。"
    },
    {
      "id": "sp-02",
      "path": "tasks/sp-02",
      "title": "sp-02：有限粒子储库中的双区域涨落与稀有事件",
      "coverage": "统计物理：sp-02：有限粒子储库中的双区域涨落与稀有事件；独立任务材料、参考结果和评分依据见sp-02题包。"
    },
    {
      "id": "sp-03",
      "path": "tasks/sp-03",
      "title": "sp-03：离散谐阱 Bose 气体的有限粒子数修正",
      "coverage": "统计物理：sp-03：离散谐阱 Bose 气体的有限粒子数修正；独立任务材料、参考结果和评分依据见sp-03题包。"
    },
    {
      "id": "sp-04",
      "path": "tasks/sp-04",
      "title": "sp-04：二维费米气体子带阈值与低温展开的适用边界",
      "coverage": "统计物理：sp-04：二维费米气体子带阈值与低温展开的适用边界；独立任务材料、参考结果和评分依据见sp-04题包。"
    },
    {
      "id": "sp-05",
      "path": "tasks/sp-05",
      "title": "sp-05：范德瓦耳斯流体的全局液气共存与临界边界",
      "coverage": "统计物理：sp-05：范德瓦耳斯流体的全局液气共存与临界边界；独立任务材料、参考结果和评分依据见sp-05题包。"
    },
    {
      "id": "tm-01",
      "path": "tasks/tm-01",
      "title": "局部振动观测下的弹簧链损伤辨识",
      "coverage": "理论力学：局部振动观测下的弹簧链损伤辨识；独立任务材料、参考结果和评分依据见tm-01题包。"
    },
    {
      "id": "tm-02",
      "path": "tasks/tm-02",
      "title": "非开普勒中心势中束缚轨道的拱点进动",
      "coverage": "理论力学：非开普勒中心势中束缚轨道的拱点进动；独立任务材料、参考结果和评分依据见tm-02题包。"
    },
    {
      "id": "tm-03",
      "path": "tasks/tm-03",
      "title": "重对称陀螺的非线性章动、相位与临界自转",
      "coverage": "理论力学：重对称陀螺的非线性章动、相位与临界自转；独立任务材料、参考结果和评分依据见tm-03题包。"
    },
    {
      "id": "tm-04",
      "path": "tasks/tm-04",
      "title": "非对称自由刚体的中间轴翻转与长期守恒",
      "coverage": "理论力学：非对称自由刚体的中间轴翻转与长期守恒；独立任务材料、参考结果和评分依据见tm-04题包。"
    },
    {
      "id": "tm-05",
      "path": "tasks/tm-05",
      "title": "库仑摩擦下圆环滑动—自转耦合及同步减速",
      "coverage": "理论力学：库仑摩擦下圆环滑动—自转耦合及同步减速；独立任务材料、参考结果和评分依据见tm-05题包。"
    }
  ]
}


===== checks/benchmark-50-inventory.json =====
{
  "name": "TheoryPhysicsBench-50",
  "task_count": 50,
  "total_registered_seconds": 42000.0,
  "round_limit_seconds": 43200,
  "tasks": [
    {
      "id": "ed-01",
      "title": "点电荷与介质核壳球的反作用：自力反号和径向平衡",
      "subject": "电动力学",
      "calibrated": true,
      "checks": 14,
      "baseline": 65.68074303839856,
      "reference": 8.157061168934074e-10,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "88ca3c7911e5ac9e43fbd81c36d8b17137f263fa962e2343df97acb99c4a4311"
    },
    {
      "id": "ed-02",
      "title": "有限长直天线的角谱反演和多瓣辐射",
      "subject": "电动力学",
      "calibrated": true,
      "checks": 15,
      "baseline": 57.43447796201397,
      "reference": 9.806995042351381e-14,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "11fb963ef232e31d56f2c545432285cd12d7be4c854fcf8aafbaff5ead5eae30"
    },
    {
      "id": "ed-03",
      "title": "圆柱介质波导的全轴对称模、色散与能流约束",
      "subject": "电动力学",
      "calibrated": true,
      "checks": 16,
      "baseline": 57.21562733781993,
      "reference": 4.005711247129106e-13,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "ecaab62c3cd4ecd808bc2d374de166bdc3a71ef6a5bf38151b9a30f10284e5bb"
    },
    {
      "id": "ed-04",
      "title": "ed-04：相对论性加速电荷的源时间辐射束射",
      "subject": "电动力学",
      "calibrated": true,
      "checks": 14,
      "baseline": 26.109281722028477,
      "reference": 3.913911249553121e-10,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "466faa017f3353909825cdf0eed13666116b3b983b66e30424873d3cea08cfcd"
    },
    {
      "id": "ed-05",
      "title": "ed-05：理想导电球的多极电磁散射",
      "subject": "电动力学",
      "calibrated": true,
      "checks": 17,
      "baseline": 41.58064676754055,
      "reference": 1.4459306547580368e-13,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "af5234f0b99fd38cd4795f5f7e0ffa3bae7320c2893ca480023c01764aa185e8"
    },
    {
      "id": "gr-01",
      "title": "施瓦西强场光线的散射、捕获与反向冲量参数",
      "subject": "广义相对论",
      "calibrated": true,
      "checks": 14,
      "baseline": 51.038343111983096,
      "reference": 7.510523845096038e-14,
      "tolerance": 1e-07,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "971f0e3b2a61abd7bc80e7d7acc8ad007fb23baaec76ce25428caca0b13706d3"
    },
    {
      "id": "gr-02",
      "title": "非平直 FLRW 宇宙的联合反演、距离和视界",
      "subject": "广义相对论",
      "calibrated": true,
      "checks": 15,
      "baseline": 37.45874163398382,
      "reference": 2.268796306996143e-12,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "5ae94b8137869cee8ae7f7e0169f807e8240ea5d1533ec7faa3cdbb28d368935"
    },
    {
      "id": "gr-03",
      "title": "Schwarzschild 类时圆轨道的分支、稳定性与 ISCO",
      "subject": "广义相对论",
      "calibrated": true,
      "checks": 14,
      "baseline": 73.77142297495756,
      "reference": 9.778272072498907e-12,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "ffb352cc397754b2bddafafe295d82fb420af0651e1f9fdfbd9a69779fba6b86"
    },
    {
      "id": "gr-04",
      "title": "Kerr 黑洞局域分裂：负能量是否意味着实际能量提取",
      "subject": "广义相对论",
      "calibrated": true,
      "checks": 14,
      "baseline": 7.234375000000131,
      "reference": 1.3070612842926155e-13,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "5c396144ebbca702a9c26f8f560ae823ec31e7ab989e7bfc826992aa42832125"
    },
    {
      "id": "gr-05",
      "title": "球对称 Einstein 初值约束：质量、物理密度与极小球分岔",
      "subject": "广义相对论",
      "calibrated": true,
      "checks": 15,
      "baseline": 40.60000000004074,
      "reference": 1.1146435795139768e-10,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "ccda853bcafc21be01073c2481734a887f1ebc290ea2b0c221453ccfdcfa9579"
    },
    {
      "id": "qft-01",
      "title": "真空极化的一圈解析延拓与阈值谱",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 15,
      "baseline": 3.6895280307201754,
      "reference": 3.9741570296244154e-12,
      "tolerance": 1e-07,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "994f1bcb8df8a994f9acc183e64178b6d3c188cf1113860efa0d0160f02f0776"
    },
    {
      "id": "qft-02",
      "title": "三体衰变相空间中的窄共振与干涉",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 13,
      "baseline": 3.0457292903105952,
      "reference": 6.877470144682901e-13,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "1acb5bdbacbf80ec1482598f9e75eb01ebec4167b3377aeb8ed4fa66a0b5e05f"
    },
    {
      "id": "qft-03",
      "title": "重整化群跨阈值演化与参数可辨识性",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 15,
      "baseline": 40.00000000000002,
      "reference": 8.788928516362442e-13,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "54d4ff7e650f606cfc9c96deb56022b3fb2e7d35a99b271d79603564e6fb9bab"
    },
    {
      "id": "qft-04",
      "title": "康普顿散射的双图干涉与运动探测接受度",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 20,
      "baseline": 55.40229668995407,
      "reference": 5.46829428869829e-13,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "7ac766440f3d01d417d147c0cf653d149558dff1b73811cfece10e39be9975a3"
    },
    {
      "id": "qft-05",
      "title": "有限红外调节下一圈Pauli形状因子及动量响应",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 22,
      "baseline": 71.04194670795617,
      "reference": 3.263271212152158e-14,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "ff623a42ea815acc4606bbb3dbea04b263c3e32c7a29e6e39e78c28b6352c7c0"
    },
    {
      "id": "qft-06",
      "title": "Goldstone 模式的一圈质量保护与漏图诊断",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 19,
      "baseline": 0.014735869029594778,
      "reference": 1.0222377899060933e-14,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "5ee0f3f09f539bf7606051c95dd0e985e05d31bdb6c557b6eaeadf04a0e5d8a1"
    },
    {
      "id": "qft-07",
      "title": "赝标量 Yukawa 理论的反项闭合与有限振幅",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 19,
      "baseline": 0.1941668798006142,
      "reference": 3.7565563087237505e-07,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "e6f5748a6fe9569028e870f64bc3aa2da7bfce01cc316a227a9ac2c296f2176d"
    },
    {
      "id": "qft-08",
      "title": "二维 Schwinger 模型的质量生成与守恒源响应",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 19,
      "baseline": 6.176256407956054,
      "reference": 3.7541804814140155e-14,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "d9a3516e112b2c4aeb35bcf00aecf4e233e010550db5ca1a04c1c575a3280d52"
    },
    {
      "id": "qft-09",
      "title": "Landau 方程的物理奇点分支与夹挤证书",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 19,
      "baseline": 0.032167402278406705,
      "reference": 2.6686109635508026e-15,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "5a59e1ab83d094bb6c783349f439cd4d69b463b175846058df9d869980240019"
    },
    {
      "id": "qft-10",
      "title": "简并态、探测分辨率与红外安全可观测量",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 20,
      "baseline": 0.47992867558681396,
      "reference": 2.7144065196341442e-08,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "06c0394a75cabee1dc6c9b7681e9885cea564588d3b9aef5fb1c75802a0713b5"
    },
    {
      "id": "qft-11",
      "title": "Casimir 相互作用的双路线重构与有限壁强度",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 19,
      "baseline": 0.13806808543184862,
      "reference": 5.59956619037007e-14,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "c859add108e7d25480be89b873da08939c405c6a1ef4a68e1f6feaf29d74d3a2"
    },
    {
      "id": "qft-12",
      "title": "Gross–Neveu 行列式、质量隙与真空选择",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 20,
      "baseline": 7.28094755939297,
      "reference": 1.1413301842607661e-14,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "ec1c7305bad24018ac2d4d6d89941e5103577f254ca8b80093ea28c9484e95d3"
    },
    {
      "id": "qft-13",
      "title": "复 Langevin 矩的物理解、截断收敛与相消",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 18,
      "baseline": 26.618052126734653,
      "reference": 1.2238316049032204e-09,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "d5fe7b736f5df21c2f89aa51490cff372a7df3ff2a35e4996a205a3698cbae47"
    },
    {
      "id": "qft-14",
      "title": "Wong 色荷输运的路径顺序与规范协变",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 15,
      "baseline": 2.619567285973766,
      "reference": 6.507387475499469e-10,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "6e80720305d399bc1e6681586eade26999b641e8ffba2ecd687741849bc04920"
    },
    {
      "id": "qft-15",
      "title": "大N规范图的完整颜色收缩与平面截断",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 17,
      "baseline": 21.652157738095237,
      "reference": 0.0,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "1cb0df999250a9c7e93c5bb9816f7fc87ea0bbdf8a9b39f8db7c4ee9936927fd"
    },
    {
      "id": "qft-16",
      "title": "QCD软天线的色守恒、干涉与角窗选择",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 17,
      "baseline": 22.95323347687499,
      "reference": 6.956032802867774e-13,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "06f3be54e4d5de8bf6075d48a05cfc906e5954201b7e93058c9d9b33d312dcb9"
    },
    {
      "id": "qft-17",
      "title": "一个SU(2)径向场族的拓扑荷、作用量与边界证书",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 18,
      "baseline": 1.9158529179807469,
      "reference": 9.599622440873136e-13,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "a80bff3cdbf2e98df89cb5882bf1eef596ed96d5d85bb016cc7a5981ff6c5a21"
    },
    {
      "id": "qft-18",
      "title": "六胶子NMHV振幅的BCFW通道与旋量协变性",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 18,
      "baseline": 79.03318228032632,
      "reference": 5.6407564150928496e-12,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "a7cefec6471df760b2005e60fead85664b1ae810b1a2ec79d9efc9a31ec7d2dc"
    },
    {
      "id": "qft-19",
      "title": "D维切割的额外维信息与一圈有限有理项",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 17,
      "baseline": 0.9854842971852217,
      "reference": 2.349922806575258e-14,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "8d24eaab5df810227794c46ab04e6ccf4e86b688cce731b6bba22798fd0b97c4"
    },
    {
      "id": "qft-20",
      "title": "Dirac 低谱、Banks–Casher 凝聚与极限次序",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 23,
      "baseline": 27.22528003601866,
      "reference": 0.0,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "1fb17410c34fc567aff7a29cfc68f3c8af8fb7a17517ef96bff62bb597325ab5"
    },
    {
      "id": "qft-21",
      "title": "格点费米子倍增、完整零点与局部指数",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 23,
      "baseline": 60.0,
      "reference": 0.0,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "e8a385f0d5944bd7d6d68127692cf1d791487ad96feeb953fd5ebe334503e46c"
    },
    {
      "id": "qft-22",
      "title": "中心对称、有限体积扇区混合与 Polyakov 环",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 23,
      "baseline": 5.115397663299489,
      "reference": 0.0,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "67f1db04b0000dc1297e8ca553d0ce8d68d933a459bde0b6e546449c4313e673"
    },
    {
      "id": "qft-23",
      "title": "热光子 HTL 的因果响应与集体模",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 23,
      "baseline": 8.105952610749412,
      "reference": 0.0,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "313f74908c88ffedc4d224036d5b2d52f00ecd5dfc85f260b197be9e3860324a"
    },
    {
      "id": "qft-24",
      "title": "完整差分碰撞核下的 LPM 响应与近似选择",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 23,
      "baseline": 39.43072557423114,
      "reference": 0.0,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "573947117a5e6b82f410d29c349a4bc32ca7bbab29dee22f7ebb1d3043ea86d3"
    },
    {
      "id": "qft-25",
      "title": "标量强场产对、相干脉冲与玻色统计",
      "subject": "量子场论",
      "calibrated": true,
      "checks": 24,
      "baseline": 1.1994053966841303,
      "reference": 0.0,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "35df62a3ec0b0e801ea821ab138a71ff0d1db30021ff220ad40153d5a0748bc3"
    },
    {
      "id": "qm-01",
      "title": "非对称双 δ 势阱的束缚态与空间局域化",
      "subject": "量子力学",
      "calibrated": true,
      "checks": 11,
      "baseline": 41.8244394323801,
      "reference": 9.995160479817116e-14,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "7391dfa0dd331ddc94a5cde298485a09d3a7ef35a9eaf67577b408e67b5f82e3"
    },
    {
      "id": "qm-02",
      "title": "双矩形势垒的窄共振与能量平均透射",
      "subject": "量子力学",
      "calibrated": true,
      "checks": 14,
      "baseline": 45.92644529600235,
      "reference": 1.1118326344938853e-05,
      "tolerance": 0.0001,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "324573c737d180080cd959094a3e929e0d7d6ddeda23855a3f5ab85b83d89ba4"
    },
    {
      "id": "qm-03",
      "title": "双原子狄拉克晶格的 Bloch 能带与有限周期环",
      "subject": "量子力学",
      "calibrated": true,
      "checks": 16,
      "baseline": 47.98481408329696,
      "reference": 6.392264439989367e-12,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "b9a7df6349514a975d24fe866b8d081973099eae9abeff48539caa5bd47da790"
    },
    {
      "id": "qm-04",
      "title": "多段旋转驱动下的自旋相干演化与失谐灵敏度",
      "subject": "量子力学",
      "calibrated": true,
      "checks": 22,
      "baseline": 50.227135869604524,
      "reference": 6.425912745490619e-12,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "4f923fe5afa4e1332978a4c60a0a24db6a034782d2833e8e2bafad584d40f55c"
    },
    {
      "id": "qm-05",
      "title": "非谐与双阱振子的能谱、局域宽度和偶极矩",
      "subject": "量子力学",
      "calibrated": true,
      "checks": 22,
      "baseline": 33.99772735727325,
      "reference": 1.7198117671000895e-09,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "36006cd1247b6f649a67ee003caabc6c7d4680ddf00bb547c7b1880b89853dee"
    },
    {
      "id": "sp-01",
      "title": "平均场铁磁体的多分支平衡与亚稳态",
      "subject": "统计物理",
      "calibrated": true,
      "checks": 13,
      "baseline": 3.108217863074369,
      "reference": 9.49440819944354e-14,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "f15afbc289ede799bcc918503939ba905c9659c4db30727ebbbfebcd22692c5c"
    },
    {
      "id": "sp-02",
      "title": "sp-02：有限粒子储库中的双区域涨落与稀有事件",
      "subject": "统计物理",
      "calibrated": true,
      "checks": 17,
      "baseline": 60.93912296620172,
      "reference": 0.0,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "bb6d92e88994d9ed4dc380c8d74052516ddc4d59db1ac272df262a0b14281cc4"
    },
    {
      "id": "sp-03",
      "title": "sp-03：离散谐阱 Bose 气体的有限粒子数修正",
      "subject": "统计物理",
      "calibrated": true,
      "checks": 17,
      "baseline": 29.786112806061837,
      "reference": 6.746971371232283e-13,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "ce6228df5cb043c6160396eb9501e991eb6d5bdc2e907e8bb0ca83c672b81782"
    },
    {
      "id": "sp-04",
      "title": "sp-04：二维费米气体子带阈值与低温展开的适用边界",
      "subject": "统计物理",
      "calibrated": true,
      "checks": 17,
      "baseline": 34.514341595926204,
      "reference": 2.887821512997446e-13,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "27a959f26f2780725d60d23c74548d7aa827b9aca408f1abef1eedf6f7d7a989"
    },
    {
      "id": "sp-05",
      "title": "sp-05：范德瓦耳斯流体的全局液气共存与临界边界",
      "subject": "统计物理",
      "calibrated": true,
      "checks": 19,
      "baseline": 4.913423935918016,
      "reference": 0.0,
      "tolerance": 1e-06,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "ffa23be02007cf9fecbadb6364770c73be15b5117166a01282770fda1dd4ccb0"
    },
    {
      "id": "tm-01",
      "title": "局部振动观测下的弹簧链损伤辨识",
      "subject": "理论力学",
      "calibrated": true,
      "checks": 11,
      "baseline": 17.91360687540514,
      "reference": 0.11871799377579552,
      "tolerance": 0.01,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "c90ee9acdd362fd01f7335f661001b1d2540544928c745058023c6a0fe560ece"
    },
    {
      "id": "tm-02",
      "title": "非开普勒中心势中束缚轨道的拱点进动",
      "subject": "理论力学",
      "calibrated": true,
      "checks": 11,
      "baseline": 10.420120704842862,
      "reference": 1.074843504126607e-11,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "3db43ac99ec72732c48ebab5f875cf7eb0b800d26fea1de7e2269575a782e696"
    },
    {
      "id": "tm-03",
      "title": "重对称陀螺的非线性章动、相位与临界自转",
      "subject": "理论力学",
      "calibrated": true,
      "checks": 19,
      "baseline": 12.01273063805162,
      "reference": 2.2464708776158673e-12,
      "tolerance": 1e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "03ebc5c0006700be546a51225ef20f088d3e4c46cf32bc3a37c26c4ba03b422e"
    },
    {
      "id": "tm-04",
      "title": "非对称自由刚体的中间轴翻转与长期守恒",
      "subject": "理论力学",
      "calibrated": true,
      "checks": 22,
      "baseline": 34.07714359344464,
      "reference": 1.7615553800201666e-11,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "ef47900826328d5af34acaa44d624d7cc65e11a289e7890cc977b581a794df0f"
    },
    {
      "id": "tm-05",
      "title": "库仑摩擦下圆环滑动—自转耦合及同步减速",
      "subject": "理论力学",
      "calibrated": true,
      "checks": 22,
      "baseline": 1.0409914156407214,
      "reference": 1.2280729415807244e-08,
      "tolerance": 2e-05,
      "agent_seconds": 720.0,
      "verifier_seconds": 120.0,
      "sha256": "20f27bdd271360a6af95c8d66067f81b42b8b84f7c577beb89b787a780757624"
    }
  ],
  "formal_codex_evaluation_complete": false,
  "status": "development verification; not a claim of formal course model results"
}


===== docs/formal-evaluation.md =====
# 50题正式测评入口

`tools/run_formal_benchmark50.py` 是用户与助教沟通过的50题扩展运行入口。课程原版材料的10–20题限制仍保留原文，本入口不声称已改变该限制。它沿用逐题 Harbor 0.24.0 合同、Codex + `gpt-6.1-sol` / `max`、每题3次独立尝试、并发1、不自动重试，以及每轮全部题43200秒预算。

课程原版 `tools/course/正式测评.sh`、`检查提交.py`、`汇总结果.py`、`quality_score.py` 保持不变。50题预检由 `tools/check_benchmark50.py --require-calibrated` 承担；结果表只由课程原版汇总器读取真实原始记录后生成。

## 助教统一配置

将助教给定的 CLI 版本写入一个无凭据的 `course.env`，例如项目内 `tools/course/course.env`。内容只能包含以下三个字面字段；引号和整行注释可用：

```text
MODEL='gpt-6.1-sol'
REASONING_EFFORT='max'
CLI_VERSION='助教提供的实际版本'
```

示例最后一行必须替换成助教给定的非空版本字符串。配置不存 API key、token、命令或环境变量引用；入口不执行 `source`，未知字段、重复字段、shell语法、错误模型与空版本会被拒绝。认证使用既有 Codex/Harbor 支持的课程环境，入口不会读取或输出凭据。

## 先预览

在项目根目录运行：

```bash
python3 tools/run_formal_benchmark50.py --config tools/course/course.env
```

不加运行模式时默认为 dry-run，只展示固定配置、将执行的命令、清单/逐题哈希和目标归档路径。它不会启动 Harbor、调用模型、创建正式结果目录或伪造 `results.csv`。没有助教CLI版本时先完成配置，入口不会猜测版本。

## 正式运行

```bash
python3 tools/run_formal_benchmark50.py --config tools/course/course.env --execute
```

仅这条显式 `--execute` 会运行正式模型。入口会依次检查 Harbor 恰为0.24.0、50题完整校准预检、清单和题包哈希、原版课程工具哈希以及正式结果目录不存在。`runs/codex` 已存在时拒绝覆盖或续写；不删除有效失败，不挑选最好的一次结果。

源路径可能含中文、空格和 `%`。入口将题包逐文件复制到 `/tmp/physics-formal50-*` 的 ASCII 安全路径，再核对清单与每题哈希。复制范围仅为 `benchmark.json` 和 `tasks`，不夹带项目根部 `checks`、开发工具或历史运行；逐题 Harbor 镜像仍只由 `environment/` 构建。参考解与隔离verifier按正常Harbor机制处理，不把它们复制进公开agent环境。

Harbor 使用如下固定关键参数：

```text
-a codex -m gpt-6.1-sol --ak version=<助教固定版本> --effort max
--n-attempts 3 --n-concurrent 1 --max-retries 0
```

所有原始job先写安全暂存路径，结束或中断后完整复制归档至 `runs/codex`，并逐文件核对归档哈希。源目录保留逐题冻结信息 `.formal50-frozen-input.json` 和入口运行记录 `.formal50-runner-record.json`。运行前后再次检查源题包、暂存副本和课程工具；发生变化时保留所有证据并停止自动汇总。暂存副本保留，便于审查和故障恢复，不自动删除原始记录。

实际Harbor命令失败时返回其非零退出码，仍保存已产生的原始记录。基础设施异常不能编造为模型零分；课程汇总器也会拒绝异常、不足三次或配置不一致的原始记录。

## 独立助教复测与汇总

助教全题独立复测使用单独目录：

```bash
python3 tools/run_formal_benchmark50.py --config tools/course/course.env --ta --execute
```

它写 `runs/ta-codex`，同样每题3次，不覆盖学生原始记录。

成功执行后会自动调用课程原版 `汇总结果.py`。也可对已有完整冻结记录单独汇总，不启动模型：

```bash
python3 tools/run_formal_benchmark50.py --summarize
python3 tools/run_formal_benchmark50.py --ta --summarize
```

汇总器分别生成 `results.csv` 和 `ta_results.csv`；每套50题应有150条真实可核实记录。开发用 `oracle=1/nop=0`、本地参考解校准和本入口离线自检均不是这150次正式Codex测评。

## 离线开发自检

```bash
python3 tools/test_formal_benchmark50.py
```

测试使用临时目录和模拟子进程，覆盖配置字面解析、拒绝shell语法、默认dry-run、固定三次/并发/重试参数、拒绝覆盖、ASCII暂存、逐题哈希一致、原始记录完整归档、失败退出及源题变化拦截。不会访问网络、调用正式模型或生成项目正式结果表。


exit_code=0
```

### 2026-11-16T22:52:46.408215+08:00

```bash
python3 -
```

```text

===== 课程大作业说明.md =====
# 课程大作业：科学探索任务设计与智能体评测

科学研究离不开专业判断：有限的实验机会应该用在哪里，数据中的异常意味着什么，一次方法改动是否值得继续尝试。智能体越来越擅长编程、调用工具和运行实验，“它们最终会取代科研人员吗？”这次大作业邀请同学们作为“人类科研阵营的守护者”，用自己的专业知识向大模型提出有分量的科研挑战。

期待大家把专家积累的知识、判断和创造力融入题目，尽可能提出难题，也为求解提供充分材料、公平条件和可靠的验证方法。我们希望通过实际测评，看清智能体已经能取得哪些进展，人类研究者的优势又体现在哪里。

每组选择一个熟悉的研究主题，设计一套10至20道题的原创benchmark，并提供专家参考解、评分程序和完整测评记录。人文、政治、生化环材、数学、AI等领域均可。

<a id="overview"></a>

## 这次要完成什么

**Benchmark是一套采用统一运行和评分规则的题集。** 本次由Codex阅读材料、调用工具、开展探索并提交结果，再由评分程序独立检验效果。你们同时承担出题者和实验研究者的工作：设计挑战、验证题目、测评模型，并解释结果。

| 项目 | 基本要求 |
|---|---|
| 分组与题数 | 2–3人一组；10至20道题，其中至少10道为有效独立题 |
| 被测智能体 | Codex + GPT6.1-sol-max；CLI版本和配置由课程统一指定 |
| 任务封装 | Harbor 0.24.0；材料包提供10题模板和运行工具 |
| 正式测评 | 学生每题独立运行3次；助教逐题独立复测3次 |
| 可用硬件 | 最多一块80GB A100，也接受纯CPU任务 |
| 运行上限 | 全部题各运行一次为一轮，每轮累计≤12小时；学生与助教各自3轮累计≤36小时 |
| 最终交付 | 一套可独立复现的任务包，以及正文最多4页的报告 |

可以先浏览[附件三：两个科研任务的完整示例](附件三_科研任务示例教程.md)，了解“科研问题如何变成可运行、可评分的任务”，再回到自己熟悉的领域组织题集。

<!-- pagebreak -->

<a id="questions"></a>

## 一、怎样设计一套有研究价值的题集

**先确定共同的科研能力，再设计有实质差异的题目。** 例如，“化学”可以进一步明确为“根据实验数据辨析反应机理并检验预测”；“政策研究”可以明确为“判断案例资料中的因果证据能否支持政策效果结论”。

研究过程可以包含实验选择、参数估计、竞争解释、材料互证、推导构造或算法改进。每道题都应有需要判断和探索的地方，并能交付可核查的结果。

| 每道题需要说明 | 学生出题时要回答的问题 |
|---|---|
| 研究目标 | 这个问题在本领域有什么用途？需要作出哪些研究选择？ |
| 公开起点 | Codex拿到什么材料和工具？第一次尝试后能获得什么反馈？ |
| 交付与验证 | 最后交程序、模型、推导还是分析？怎样判断它的质量？ |
| 基线与参考 | 一个简单起点能做到什么程度？专家方案如何做得更好？ |

**独立题目要有实质差异。** 各题应有自己的研究材料、参考结果和评分依据，材料或实例的变化应改变分析、证据处理或验证工作。题目可以共用工具、数据来源、环境和参考方法。同一实例只换名字、提示词、种子或近重复样本，按一道题计算；一道题中的多个小问或测试样本也按一道题计算。

**专家参考解要能复核。** 可以由本组完成，也可以使用公开专家方案，注明来源和工具使用。程序类任务提供代码、结果与运行方法；论证类任务提供分析、证据出处和评分要点。简单基线与专家参考使用同一套评分办法。

**根据研究目标选择验证方式。** 检验方法对新样本的适用性时，提供公开开发材料，保留未用于调参的最终案例。解决固定问答、构造、证明或优化实例时，可公开完整题设，通过独立执行、重算或核对证据检验结果。具体做法见[附件一第三节](附件一_Benchmark制作与提交指南.md#validation)。

**原创性与公平性贯穿整个出题过程。** 保留论文、数据、代码等来源，说明与相近benchmark的实质差异；参考解与Codex使用相同任务信息、执行资源和最终评分办法。助教会完整检查来源、题目质量和评测方式。经两位助教核实并听取小组说明，确认抄袭或故意操纵且实质影响结果的，整份大作业记0分。具体例子见[附件二第三节](附件二_评分与验收规则.md#integrity)。

<!-- pagebreak -->

<a id="submission"></a>

## 二、怎样完成与提交

可以按下面的顺序推进。第一次接触benchmark的同学，建议先完整跑通一道题，确认研究过程和验证办法合适，再扩展整套题集。

1. **确定主题与覆盖范围。** 列出各题研究什么、差异在哪里，检索相近任务，说明本组的设计贡献。
2. **制作题目与验证方法。** 准备公开材料、简单基线和专家参考解，用Harbor封装，检查参考解、空提交、实质错误解和合法替代解的评分。
3. **开发试跑并冻结。** 用公开开发材料调试，保留试跑与选题调整记录；完成检查后，固定整套题目、指标、参考解、运行条件和版本。
4. **正式测评与分析。** 每题从新会话、干净工作区独立运行3次，保留全部记录，分析典型成功与失败，完成报告和提交预检。

环境准备、具体文件、命令和填写示例见[附件一：Benchmark制作与提交指南](附件一_Benchmark制作与提交指南.md)。测评中的正常失败、运行故障和补跑办法见[附件二第五节](附件二_评分与验收规则.md#failures)。

### 提交一个小组压缩包

| 内容 | 应包含什么 |
|---|---|
| 题集登记 `benchmark.json` | 共同科研目标、题目ID、名称、路径和覆盖说明 |
| 10至20个任务目录 `tasks/` | 每题的题面、公开材料、参考解、评分程序及指标配置；简单基线附运行方法 |
| 检查材料 `checks/` | 来源与原创说明、材料划分、基线与参考结果、公平性和评分检查记录 |
| 正式结果 `results.csv`、`runs/codex/` | 每题3次的原始指标、评分记录、耗时、产物和完整日志 |
| 小组报告 `报告.md` | 正文最多4页，说明主题与原创设计、制作验证、结果分析与改进，以及成员分工 |

材料包中的`template/`可以直接复制后填写。报告引用详细材料的文件路径，让读者能沿着结论找到证据。

### 让助教能够独立复现

固定依赖、数据版本、种子和运行命令，写清CPU、内存、磁盘与GPU需求。助教应能在干净环境中，仅凭任务包、公开下载资源和课程统一配置完成复现。

每轮12小时累计包括所有题的探索、方案执行和最终评分，平行执行也按逐题耗时相加；首次环境构建与公共数据下载单独记录。基线和参考解各跑一轮也遵守这一上限。具体时间登记方法见附件一第五节。

<!-- pagebreak -->

<a id="grading"></a>

## 三、大作业怎样评分

本大作业满分100分，是课程总评的一部分。

| 项目 | 分值与主要依据 |
|---|---|
| 完整性 | **30分**：题集与实验设计、复现与交付、报告与结果分析，各10分 |
| 创新性 | **20分**：题集围绕真实科研需求形成的设计贡献，以及相对已有任务新增的检验价值 |
| 题目数量与难度 | **50分**：最多20题计分，每道有效题1至2.5分，逐题累加 |

每道通过质量验收的独立题先得1分，再按难度系数获得0至1.5分；单题得分＝1＋1.5×难度系数。专家参考越领先Codex，难度系数越高。助教对每题复测3次，取平均结果计分。无效题得0分。

题集须登记10至20道题，至少10道为有效独立题。冻结登记的题目全部计分，逐题相加，20道困难题即得满分50分；冻结后不能替换题目或挑选得分高的题。

完整公式、创新性参考档位和数值例子见[附件二：评分与验收规则](附件二_评分与验收规则.md)。

### 助教怎样验收

助教会完整复核整套benchmark的创新性，以及每一道题的质量、独立性、材料完整度、基线、参考解和评分方法；复跑基线、参考解与空提交，并对每题独立运行3次Codex。最终题目数量与难度得分采用助教复测结果，学生记录用于对照和分析。

两位助教分工检查、交叉复核，结合来源、产物和运行记录给出评分依据。默认组内同分，贡献明显失衡时核实调整并说明依据；同学可按具体条目提出复核请求。

<a id="reading"></a>

## 接下来读哪份材料

| 你现在想做什么 | 对应材料 |
|---|---|
| 动手制作、封装、运行和提交 | [附件一：Benchmark制作与提交指南](附件一_Benchmark制作与提交指南.md) |
| 了解怎样评分、怎样验收、故障怎样处理 | [附件二：评分与验收规则](附件二_评分与验收规则.md) |
| 跟着真实科研问题学一遍 | [附件三：两个科研任务的完整示例](附件三_科研任务示例教程.md)；包含磁性合金与NanoGPT |

四份说明均提供PDF和可编辑的Markdown。`template/`存放提交模板，`tools/`存放课程工具，`examples/`存放两个示例的代码、数据准备工具和原始来源。


===== template/报告.md =====
# 小组XX：benchmark名称

成员及分工：

正文最多4页。逐题题面、长命令、数据说明和日志保存在任务包中，报告给出路径。

## 一、主题与原创设计

共同科研目标与研究场景：
有效独立题数与覆盖范围，登记10至20题，至少10题有效（索引见benchmark.json）：
最近已有benchmark、本组实质差异与价值：
论文、数据、代码、方法和框架来源：

## 二、制作与验证

公开材料、探索反馈、基线、专家参考和评分程序：
逐题b/h、方向、单位、容差及案例汇总办法：
开发/最终材料划分，固定实例或定性论证的核验办法：
环境、数据版本、种子、资源、执行命令及每轮耗时：
参考解、空提交、错误解、合法替代解与本题特殊规则的检查记录：

## 三、结果、分析与改进

冻结题目ID、版本与哈希，统一Codex配置和运行日期：
学生每题3次原始结果（results.csv和runs/codex/），以及计分工具计算的难度系数与单题得分：
整套表现、通过质量验收的有效题数、各题得分，以及代表性的成功与失败：
结合实际产物或日志分析差异，区分事实与待验证解释：
局限、一项具体改进及预期作用：
开发试跑、选题调整、异常和额外尝试的处理及记录路径：

助教复测另存ta_results.csv和runs/ta-codex/。每道有效题按助教3次结果计算平均难度系数，单题得分为1＋1.5×平均难度系数；题目总分封顶50分。


===== tools/course/quality_score.py =====
"""课程统一质量分：简单基线0、专家参考1，逐次换算后取平均。"""
import math

VALID_FAILURES = {"invalid", "agent_error", "timeout"}


def finite_number(value, name):
    if type(value) not in (int, float):
        raise ValueError(f"{name}须为有限数值")
    try:
        result = float(value)
    except OverflowError as exc:
        raise ValueError(f"{name}须为有限数值") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name}须为有限数值")
    return result


def validate_metric(metric):
    if metric.get("kind") == "binary":
        baseline = finite_number(metric.get("baseline"), "baseline")
        reference = finite_number(metric.get("reference"), "reference")
        if baseline != 0 or reference != 1:
            raise ValueError("二元题须实测简单基线0、参考解1，否则不构成有效的参考提升")
        return
    if metric.get("kind") != "continuous":
        raise ValueError("kind须为binary或continuous")
    direction = metric.get("direction")
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction须为maximize或minimize")
    baseline = finite_number(metric.get("baseline"), "baseline")
    reference = finite_number(metric.get("reference"), "reference")
    tolerance = finite_number(metric.get("tolerance"), "tolerance")
    if tolerance < 0:
        raise ValueError("原始指标容差不能为负")
    improvement = reference - baseline if direction == "maximize" else baseline - reference
    if not math.isfinite(improvement) or improvement <= tolerance:
        raise ValueError("参考解相对基线的改善须超过原始指标容差；请先核查设置")


def quality_score(metric, raw_metric, status="completed"):
    validate_metric(metric)
    if status in VALID_FAILURES:
        return 0.0
    if status != "completed":
        raise ValueError("基础设施或评分器故障不能填0；请先处理并补跑")
    value = finite_number(raw_metric, "raw_metric")
    if metric["kind"] == "binary":
        if value not in {0.0, 1.0}:
            raise ValueError("二元任务的实测结果须为0或1")
        return value
    baseline = float(metric["baseline"])
    reference = float(metric["reference"])
    fraction = (value - baseline) / (reference - baseline)
    return max(0.0, min(1.0, fraction))


===== tasks/tm-01/solution/solve.py =====
#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
from pathlib import Path

from solver_core import solve


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, default=Path("/app/data"))
    parser.add_argument("--output", type=Path, default=Path("/app/output/answer.json"))
    args = parser.parse_args()
    stiffness, softened, history = solve(args.data_root)
    answer = {
        "stiffness_n_per_m": stiffness.tolist(),
        "softened_springs": softened,
        "method": "bounded finite-difference damped Gauss-Newton on all visible time histories",
        "iterations": len(history),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(answer, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(answer, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()


===== tasks/qft-20/solution/solve.py =====
import argparse

import itertools

import json

import math

from pathlib import Path

import numpy as np

from scipy.integrate import quad, solve_ivp

from scipy.linalg import expm

from scipy.optimize import brentq, least_squares, root

from scipy.special import gammaln, logsumexp

from scipy.sparse.linalg import LinearOperator, gmres

def q20_tail(edge,m,c):
    if abs(m-1)<1e-8:
        return 2*m*c*quad(lambda x:1/((1+x*x)*(x*x+m*m)),edge,np.inf,epsabs=1e-12)[0]
    return 2*m*c*((math.pi/2-math.atan(edge))-(math.pi/2-math.atan(edge/m))/m)/(m*m-1)

def q20_solve(model,baseline=False):
    out=[]
    for fam in model['families']:
        sample=fam['spectra'][-1];lam=np.array(sample['positive_eigenvalues']);target=(np.arange(len(lam))+.5)/sample['V']
        if baseline:
            g=0.;b=0.;r=min(40,len(lam))/(sample['V']*lam[min(39,len(lam)-1)])
        else:
            fit=least_squares(lambda p:p[0]*((lam-p[2])+p[1]*(lam-p[2])**3/3)-target,[.4,.3,max(0,lam[0]-.002)],bounds=([.01,0,0],[3,3,min(lam[0],.5)]),xtol=1e-14,ftol=1e-14,gtol=1e-14,max_nfev=2000)
            r,b,g=fit.x
            if g<1e-7:g=0.
        sigma=math.pi*r if g==0 else 0.
        divergent=any(s['zero_modes']>0 for s in fam['spectra'])
        out.append({'id':fam['id']+'-inference','values':[float(r),float(b),float(g),float(sigma),float(not divergent),float(divergent)]})
        for spec in fam['spectra']:
            lv=np.array(spec['positive_eigenvalues']);V=spec['V'];edge=spec['edge']
            for m in fam['masses']:
                paired=2*m*np.sum(1/(lv*lv+m*m))/V+q20_tail(edge,m,fam['uv_density_coefficient'])
                zero=spec['zero_modes']/(m*V)
                cont=2*m*quad(lambda x:r*(1+b*(x-g)**2)/(x*x+m*m),g,edge,epsabs=1e-12,epsrel=1e-12)[0]+q20_tail(edge,m,fam['uv_density_coefficient'])
                correction=paired-cont
                bound=abs(correction)+zero+abs(cont-sigma)
                out.append({'id':f"{fam['id']}-V{V}-m{m:g}",'values':[float(paired+zero),float(zero),float(correction),float(cont),float(bound),float(bound<=fam['window_target'])]})
    return {'results':out,'method':'quantile inversion, complete paired spectrum, analytic UV tail and explicit order of limits'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,default=Path('/app/data'));p.add_argument('--output',type=Path,default=Path('/app/output/answer.json'));p.add_argument('--baseline',action='store_true');a=p.parse_args()
    model=json.loads((a.data_root/'model.json').read_text());answer=globals()['q'+model['task_id'].split('-')[1]+'_solve'](model,a.baseline)
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n')

if __name__=="__main__":main()


===== tasks/tm-01/solution/solve.sh =====
#!/bin/bash
set -euo pipefail
python3 /solution/solve.py


===== tasks/qft-13/environment/requirements.txt =====
numpy==2.1.3
scipy==1.14.1
mpmath==1.3.0


===== checks/ed-01-sources.md =====
# ed-01 教材来源与改造

核对日期：2026-11-16。

## 已核对的原始材料

用户文件 `/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf`，第 4.4 节“带有电介质的边值问题”，已渲染并目视核对 PDF 第 168–173 页，对应书内第 163–168 页。

- PDF 168–170：两介质界面的点电荷问题、电势和法向位移连续条件。
- PDF 171–172：球内外勒让德展开、逐阶匹配与均匀介质球极化率，式 (4.48)–(4.58)。
- PDF 173：介质中球形空腔及相对介电对比的方向变化，式 (4.59)–(4.60)。

辅助资料 `/Users/ai4s/Downloads/JACKSON经典电动力学答案.pdf` 是 Rudolph J. Magyar 的 `A Companion to Classical Electrodynamics, 3rd Edition by J.D. Jackson`（2004），并非教师或 Jackson 本人所作答案。本轮查看了其既有 OCR 第 32–38 页的习题 4.8 文字，该题是圆柱壳界面匹配，不把它声称为本题球壳原题，也不直接采用其中解答代码或公式。正式题源按原教材 4.4 节登记。

## 本项目的改造

将均匀外场中的单介质球扩展为核壳球在非均匀点源场中的反作用，固定三种材料与六个源位置，联合检查极化能、自力、全区间平衡点及径向稳定性。近表面必须选择足够多极阶数；低介电壳/高介电核的竞争使远场近似可能给错自力方向，并遗漏平衡点。

基线为全核壳结构的 l=1 偶极近似，参考为完整多极展开。独立验证由 70 位四边界线性方程、绝对尾界及二分实现，不调用参考求解器。经典介质理论和高斯消元是已有方法；本项目贡献为研究目标、实例组合、反馈与评分协议，不将其宣称为新电磁理论。

本题并非从现有 benchmark 翻译或只加 Harbor 外壳。整套相关评测对照见已有 `checks/tm-01-sources.md`；本题用于检验多尺度边界响应、近似适用范围与平衡完整性，而非只核对一道教材的最终数字。


===== checks/ed-02-sources.md =====
# ed-02 教材来源与独立性

## 原始教材

用户提供 `/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf`，§9.4“中央馈电的平直天线”。原PDF第448页，书内443页，式(9.53)给出两臂对称的正弦规定电流；式(9.54)-(9.55)是远场电流积分与闭式矢势；式(9.56)是精确于该规定电流模型的角分布。第449页，书内444页，式(9.57)列出kd=π、2π的半波/全波极限，并解释全波由两个同相半波场相干叠加而形成更尖锐的角分布。

这两页已真实渲染并视觉查看，PNG在 `checks/ed-02-source-pages/antenna-448.png`、`antenna-449.png`。题包不附整本教材扫描内容。OCR读取过第446-450、498-500页，实际选题最终以448-449页为依据；早先考虑Mie散射的方向未被采用，不把未实现内容写成成果。

同一节下一段明确说明正弦电流只是假定，真实有限半径天线须作为复杂边值问题处理。本题因此明确约束为规定电流的理想细天线，不主张反演真实天线馈电阻抗或电流自洽性。

## 本组改造

将原书正向辐射题改成有未知电长度与幅度尺度的固定角谱逆问题，要求全局选择反演分支、积分功率、找全所有辐射瓣并计算最大方向性。六组不同电长度只作为一道任务的六工况，不拆成六题。全部十个角谱样本和搜索区间公开；最终参数、功率及瓣标签由独立高精度真值核对。

## 与本题集已有任务的区别

`ed-01` 研究静电介质核壳的边界匹配、自力与径向平衡；本题研究规定时谐电流的电磁辐射、有限长度干涉、角谱反演及多瓣能流结构。二者基本方程、观测材料、研究选择和评分对象均不同。本题的反演也不同于tm-01弹簧链时域刚度辨识，不能靠复用后者的运动模型完成。

未把外部benchmark相似性检索当作已完成事实；这里提供的是教材改造与题集内部独立性对照，整套冻结时仍可由主代理补齐外部同类基准检索。


===== checks/ed-03-sources-and-fairness.md =====
# ed-03 来源、改造与公平性

用户Jackson《经典电动力学》§8.10，原PDF406-412页OCR已读；关键原页409-411（书404-406）真实渲染并视觉核对。PNG保存于checks/ed-03-source-pages/guide-409.png至411.png。式8.117-8.120给TE₀ₙ径向场、界面条件及u²+w²关系；8.121给j₀₁截止；8.122给TM的ε₀/ε₁边界系数。原书图8.11说明求根分支，图8.12说明径向场约束。

本组将原书单一波导定性讨论改造成六工况的完整模谱与功率研究：覆盖低于截止、刚过第一截止、远离截止、多径向模以及低折射率对比，比较TE/TM并计算几何色散和芯层能流比例。全部输入工况公开，六工况只计一道题。严格限定轴对称，不把结论扩展到一般混合模。

与ed-01静电核壳边值、ed-02规定电流天线远场相干反演不同，本题求无源界面导波本征模、指数尾、截止和频率导数，研究对象与计算问题独立。

Agent只见environment/public中的材料、起点、反馈和登记指标。参考解和私有真值分别在solution与tests，Docker COPY仅public。独立真值求解器不导入参考模块。固定实例全部材料均可用于计算；私有数据仅保存独立验证标签，不假称是留出泛化样本。基线为有物理意义的强约束近似，同资源同公开材料。最终评分公开全部权重，允许等价方法和模式重排。

每题外部benchmark比对仍由主代理在题集冻结前统一补齐，这里只记录已核对的原教材出处和题集内部独立性。


===== checks/ed-04-sources.md =====
# ed-04 来源与公平性

用户 Jackson《经典电动力学》§14.3 原PDF765-768页（书235-238）已真实渲染，其中765、766、768页已视觉核对，PNG在 `checks/ed-04-source-pages/radiation-765.png`、`radiation-766.png`、`radiation-768.png`。式(14.35)-(14.38)说明观测通量与源时间的 Jacobian；式(14.39)-(14.41)给平行加速的前向束射和半功率角；式(14.44)-(14.46)给横向加速及总功率。题面固定源时间约定，不混淆两种功率定义。

本题把原书正向角分布改造成七工况的积分研究：恢复总功率、前向分位角、\(1/\gamma\)锥内能量和辐射动量。与ed-01静电球、ed-02细直天线、ed-03介质波导的边界/模式问题不同。本题所有工况属于一个统一的相对论辐射积分任务，不拆题。

公开材料包括全部 \(\beta,\chi\)、源时间公式、反馈和评分权重；参考与65位真值不进入Agent环境。基线是物理正确但未解析尖峰的固定角度求积，未人为改错物理。外部benchmark相似性检索由主代理统一补齐。


===== checks/ed-05-sources-and-fairness.md =====
# ed-05 来源与任务边界

## 实际教材证据

用户提供的 `/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf`，§16.9“球体对电磁波的散射”。本题关键原始扫描页为PDF第897-899页（书内第367-369页），三页均已用Poppler渲染并逐页视觉核对，图像保存在 `checks/ed-05-source-pages/jackson-897.png` 至 `jackson-899.png`。

- 书367页，式(16.151)定义两类散射相移；式(16.152)给理想导体球的球Bessel/Neumann函数比值。
- 书368页，式(16.155)-(16.158)从电、磁偶极展开推导低频角分布，明确线性干涉项引起前后不对称。
- 书369页，式(16.159)给长波总截面 `sigma = 10*pi*a^2*(ka)^4/3`，图16.6展示主要向后散射的长波方向图。

题目将原书部分波边界条件改造成从长波区到多极区的统一数值研究。原书的磁、电散射系数与本题Mie系数分别为 `alpha_l=-2*b_l`、`beta_l=-2*a_l`；题面明确时间因子、外向球波、效率归一化和无偏振微分截面，避免不同教材约定混用。

## 任务独立性与公平性

本题研究传播电磁波在理想导体球上的完整多极散射，输出相位敏感系数、积分截面、后向相干干涉与角分布。它与ed-01静电介质核壳球的界面反演、ed-02线天线、ed-03波导导模、ed-04运动电荷辐射的物理机制和验证量均不同。十个尺寸参数属于同一个多极研究任务，不拆作十题。

全部尺寸、阶数、角度、物理方程、输出格式和评分规则公开。公开基线是精确电/磁偶极截断，没有人为改坏物理；它在长波工况准确，尺寸较大时遗漏显著高阶散射。系数误差采用部分波能量权重，避免微小尾项与主导偶极同权。

完整参考程序和75位独立真值不复制进Agent镜像。公开反馈只从所交系数检查内部一致性；满足光学定理并不直接获得私有答案。独立真值不导入参考求解器，使用半整数阶普通Bessel函数与另一套高精度角积分核对。本地Linux开发验证与Harbor正式模型测评分别记录；本题未声称已进行三次Codex测评。

外部benchmark相似性检索由主代理统一汇总。


===== checks/gr-01-sources-and-fairness.md =====
# gr-01 来源、独立性与公平性

## 来源证据

原始文件：`/Users/ai4s/Downloads/微分几何入门与广义相对论 上 (梁灿彬) (z-lib.org).pdf`，457 页。

| 位置 | 核对内容 | 核对方式 |
|---|---|---|
| PDF 325–327，书内 310–312 | §9.1 施瓦西测地线，赤道面约化、守恒量与径向方程 | 指定页 OCR；尚不据此声称已目视 |
| PDF 333，书内 318 | §9.2.3 星光偏折的开头，类光条件 \(\kappa=0\) | OCR 及渲染原页目视核对 |
| PDF 334，书内 319 | 式 (9-2-24) 径向方程；(9-2-25) \(u=1/r\) 的一阶方程；(9-2-26) \(u''+u=3Mu^2\) | OCR 及渲染原页目视核对，截图位于 `checks/gr-01-source-pages/` |

只把教材用作物理定律、单位及推导来源。正式作答容器提供完成任务所需方程，不要求智能体取得用户本地教材。

## 新增研究任务与独立性

教材在此讨论弱场太阳星光偏折。本题针对强场黑洞光线：需要识别散射、捕获和临界三种轨道，选择从无穷远可达的外转折根，保留多周累计角，并由给定偏折反推极小冲量差。10 条射线与 4 个反向目标共同属于这一道研究任务，不分别计算题数。

与 `tm-02` 的区别：该题是非开普勒中心势下的经典束缚轨道拱点进动；本题是类光、无界入射散射与捕获，具有光子球分离界、无限绕行极限及反向冲量计算。物理材料、可达性判断、奇性处理、输出与评分均不同，不是更换参数或势函数后重复同一计算。

与现有 benchmark 的比对范围目前仅限教师材料包示例及本题集已有任务；尚未完成外部题集系统检索。这项记录必须在整套冻结前补足，不能据本文件宣称已证实全网首创。

## 公开与私有划分

- 公开：全部固定输入、物理模型、schema、评分公式、基线/参考指标端点、反馈工具、资源。
- 作答不可见：参考源代码、基线代码、独立真值、评分检查记录和开发产物。它们随出题者提交包供助教审查，Harbor 作答镜像仅复制 `environment/public/`。
- 最终固定实例核验：私有 `truth.json` 由独立高精度计算生成，不添加隐藏工况或秘密物理条件。
- 参考只读取与作答者相同的 `model.json`；无隐藏标签读取、逐 id 答案回填、私有服务或服务器算力。

## 评分依据

按数值、轨道分类和绕行计数评分，允许不同积分/求根方法及不同数组顺序。有效格式的物理错解按实际误差处理，只有 schema 错误或非有限数值等返回无效。反向冲量用对数误差避免近临界小量被绝对误差指标掩盖。评分函数逐字复制课程 `quality_score.py`，验证工具比较原始字节。

开发检查覆盖参考、空提交、实质错误解与合法替代顺序，另含偏折取模、漏绕行、临界误分类、错误转折点、重复 id、布尔值和非有限数。实际验证结果见校准 JSON，而非仅凭本清单认定通过。

## 资源

本地纯 CPU；每题 Agent 1200 秒、verifier 120 秒、4 CPU、4 GB、0 GPU。不会连接远程 GPU 服务器。开发期源码由 Codex 辅助编写，正式被测智能体的成绩需冻结后按课程统一配置运行三次后再填。


===== checks/gr-02-sources-and-fairness.md =====
# gr-02 来源、材料与公平性

## 教材依据

来源为用户提供的 `/Users/ai4s/Downloads/微分几何入门与广义相对论 上 (梁灿彬) (z-lib.org).pdf`。

| 原 PDF 位置 | 书内位置 | 依据与核对方式 |
|---|---|---|
| 388–389 页 | 373–374 页，§10.2.2 | 宇宙学红移和尺度因子关系，式 (10-2-8)–(10-2-10)；指定页 OCR 核对 |
| 390–392 页 | 375–377 页，§10.2.3 | Friedmann 方程、连续性方程、尘埃和辐射演化；指定页 OCR，其中 PDF 391 页已渲染并目视核对 |
| 415–417 页 | 400–402 页，§10.4.1 | 粒子视界概念、与事件视界的区别和径向固有距离；指定页 OCR，其中 PDF 417 页已渲染并目视核对 |
| 430–431 页 | 415–416 页，§10.5.2–10.5.3 | 正宇宙学常数、不同未来物态及宇宙命运的区别；指定页 OCR 核对 |

目视核对原页保存为 `checks/gr-02-source-pages/friedmann-391.png` 和 `horizon-417.png`。未声称 OCR 页均已目视。正式环境只包含完成题目所需的公开物理定义，不依赖用户本地教材。

横向距离、角径/光度距离和给定衰减模型由题面完整定义；衰减及瞬时转尘未来属于本题的理想化设计，不能冒称教材的观测结论或真实宇宙模型。参考解从已核对的膨胀、红移和类光传播关系推导具体计算。

## 模拟数据与研究贡献

公开观测由一个含辐射、尘埃、曲率和真空能的 FLRW 模型确定性生成，13 位有效数字舍入，无随机噪声。生成脚本、参数和舍入约定保存在 `tools/build_gr02_truth.py` 与 `checks/gr-02-observation-generation.json`。文件明确标注为模拟数据，不将其表述为来自望远镜的真实测量。

本题的贡献不是提出新的宇宙学定律，而是构造统一研究任务：由不同观测通道分离几何与衰减，重建未观测红移的距离，量化早期辐射对历史的作用，找出角径峰值和加速转变，并用两个相同过去、不同未来的完整反例检验事件视界可辨识性。不同红移和各项量共同属于一道题，不拆成多道独立计数。

与 `gr-01` 的区别：`gr-01` 研究局域施瓦西强场光线的散射、捕获及极小冲量差；本题研究均匀各向同性时空的观测反演、空间几何、宇宙历史和全局因果范围。输入、未知量、研究判断、积分困难和评价均有实质差异。

当前相近题目比对范围是教师材料示例及本题集已完成题。冻结整套前仍需补外部科学 benchmark 检索，不能把本记录当作已确认全网首创的证据。

## 最终答案的定义

评分目标是题面规定的顺序目标在**已舍入公开观测**上的极小点。独立真值重新拟合公开观测，不把生成参数当作精确标签。第一阶段不使用光度距离改变 H² 拟合目标；第二阶段不使用预测值或隐藏数据优化衰减。参数边界、物理约定、单位、输出、评分公式和尺度全部公开。

## 可见范围与标签隔离

- 正式作答可见：`environment/public/` 中模型、反馈、指标和辅助定义，加 `instruction.md`。
- 正式作答不可见：`solution/`、`tests/private/`、检查记录、生成参数和开发答案。它们供助教审查和重算，不复制到作答镜像。
- 全部输入固定公开；私有真值不添加隐藏观测、隐藏约束或额外未来模型。
- 参考只读相同公开数据，使用 4 CPU、4 GB、0 GPU。高精度真值属于验证器开发，不是给参考方案提供额外观测。

## 评分与基线

教师 `quality_score.py` 原样复制，校准脚本核对教师原版摘要。评分看物理数值与有无视界的布尔判断，允许等价数组顺序及任何满足公开模型的算法。格式合法的物理错解按指标评分，格式错误返回 `invalid`；不按文字或参考代码的字面相似度评判。

平直透明基线保留辐射和精确积分，只省去曲率与衰减参数。这是可复现的常用简化模型，不故意制造数值错误，也没有用近似参考的强方案压缩评分区间。参考与基线由同一指标评价。

实际检查包括参考、缺失产物、实质错解、数组重排，以及距离对偶、径向/横向视界混淆、未来视界、可辨识性、零衰减、重复红移、布尔值冒充实数及非有限值。结果见校准 JSON，不以本清单替代实际运行。

## 工具和资源使用

题面、求解器和验证代码由 Codex 辅助编写，原始教材由用户提供。实际验证只使用本地 Docker Linux，断网、4 CPU、4 GB、0 GPU；未连接远程服务器、未触碰推理项目、未向 GitHub 推送。正式课程指定智能体的三次独立测评需冻结后另行运行，不能用本题参考执行冒充。


===== checks/gr-03-sources-and-fairness.md =====
# gr-03 来源与公平性

来源：用户 `/Users/ai4s/Downloads/微分几何入门与广义相对论 上 (梁灿彬) (z-lib.org).pdf`。实际 OCR 读取 PDF326–327、331–333；实际渲染并目视核对 PDF327 和332，分别对应书内312和317页。式(9-1-5)–(9-1-6)给出角动量及径向方程，式(9-2-13)–(9-2-15)明确类时条件和相对论修正。原图保存在 `checks/gr-03-source-pages/`。

本题是有源可查的模型计算和仪器参数反演，不照搬教材弱场近日点近似。新增了未知质量/径向零点、完整圆轨道分支、ISCO 合并和双时间稳定性。全部角动量工况只算一道题。与 gr-01 的无界类光散射不同，本题是有静质量圆平衡、局部稳定性和分支分岔；没有复制其散射积分、捕获、绕行或反向冲量任务。与 tm-02 的经典束缚轨道周期/进动也不同，本题不评分周期积分，而评分平衡根完整性与扰动谱。

模拟观测为确定性生成，14位有效数字舍入，无随机噪声，未伪装成真实天文数据。生成常数记录在 `checks/gr-03-observation-generation.json`；真实评价目标是规定拟合在公开已舍入数据上的极小值。真值重新拟合，不回填生成参数。

作答可见题面和 `environment/public/`；参考、基线、私有真值和检查材料仅供助教审查，不复制进作答镜像。固定工况全部公开，评分不增加秘密条件。参考与智能体同样读公开模型、使用4 CPU/4GB/0GPU；独立高精度计算仅是验证标签。实现与文字由 Codex 辅助编写，注明工具使用。

基线是 Newton 模型与零仪器偏差的合理起点；其无ISCO事实如实说明，使用最内观测轨道作明确经验代理，未把完整参考参数泄露给基线。评分统一课程函数原样复制，不按文字相似度评判，支持数组重排、漏态/多态的一对一物理匹配。通过实际参考/空提交/实质错误/合法替代解检查，详见校准。

外部相近 benchmark 系统检索尚待整套冻结前补齐；当前只核对教师示例和本题集独立性，不宣称已证明全网首创。全部开发在Mac和本地断网Docker执行，不连接远程GPU、不推GitHub。正式三次Codex运行未用开发参考结果替代。


===== checks/gr-04-sources-and-fairness.md =====
# gr-04 来源与公平性

来源：用户提供梁灿彬、周彬《微分几何入门与广义相对论》中册。PDF145/书133式13-4-9至13-4-13为ZAMO标架；PDF147/书135为Penrose四动量守恒及13-5-3视界角速度；PDF148/书136式13-5-5是未来视界条件。三页已实际渲染并目视核对；PDF146也保留渲染文件。教材讨论的不可减质量和极端黑洞整体可提取比例不等于本题一次分裂效率，本题没有混用。

新增任务是固定母粒子局部速度、赤道面两光子分裂的有限方向网格，要求局域能量、全局径向拓扑、负能捕获和逃逸效率共同正确。不是把同一题换五个参数算作五题。与gr-01区别在旋转时空局部标架和Penrose守恒量，而非Schwarzschild散射角反演。

题面公开物理模型、号差、单位、boost轴定义、径向势、角度规则、两束顺序、汇总定义、固定评分尺度和资源。公开反馈只给守恒与未来性，不泄漏正确逃逸标签。冻结真值、参考解与开发答案位于非环境目录；Dockerfile仅复制public材料。

基线保留精确局部运动学，只省略全局转折，属于有意义的局部近似，不用随机输出制造分差。连续指标让只错一部分负能或标签的答案获得相应部分分。参考与独立真值采用不同线性代数表达及根算法，避免仅以同一个函数自证。

全部计算只用本地CPU。未使用远程GPU、未触碰推理项目、未推送GitHub；未读取或打包无关凭据。参考开发分数不冒充被测Codex表现。


===== checks/gr-05-sources-and-fairness.md =====
# gr-05 来源与公平性

用户提供梁灿彬、周彬《微分几何入门与广义相对论》中册，§14.5，PDF204/书192式14-5-9及14-5-10为真空3+1约束；PDF205/书193讨论约束保持。两页已用view_image实际目视；PDF203–207渲染文件存于本目录source-pages。教材讨论真空，此题通过Einstein方程的法向投影明确引入16πρ项，再指定共形源求解，未把新增的含源模型、临界数值或可计算任务伪称为教材原题答案。

来源页支持初值几何和约束结构；题面和参考推导独立给出共形标量曲率、Poisson边界条件、物质体元、球面平均曲率及根的完整性。C1紧支撑源不冒称无限光滑；本题只需经典径向约束和球面几何。K=0不等于整个时空静态，初始表观视界也不等于事件视界。

五个振幅是同一题的拓扑覆盖，不计作五道不同题；与gr01–04分别检验散射、宇宙学、圆轨道稳定性、Kerr分裂不同，本题检验Einstein初值约束与内禀几何。难点是物理密度/共形源、ADM/固有质量、极小曲面/面积极小、双根/无根等概念不能混同。

公开材料含全部物理定义、输入、端点、误差尺度及检查入口。基线正确处理Poisson场和密度，只作弱场物质质量与真空根近似；不是随机错解。独立真值采用直接高精度积分而非参考多项式原函数，采用区间二分而非Brent，避免一个实现自证。公开反馈只检查源质量与正性，不泄漏全部根。

Docker环境只复制public材料；参考、真值、开发答案不在agent环境目录。4CPU4GB0GPU，本地完成；无远程连接、无推理项目修改、无GitHub推送。开发参考满分不冒充正式被测智能体结果。


===== checks/qft-01-sources.md =====
# qft-01 来源与任务独立性

## 课程来源

用户提供的《量子场论试题详解（凡人看得懂的量子场论 非211高校适用）》PDF。原 PDF 第 115、116 页（书内页码 107、108）推导一圈光子自能/真空极化：费曼参数合并电子传播子分母、平移圈动量、用维数正则化隔离极点，并将有限的费曼参数对数积分化为阈值以上的复对数；页 108 明确指出 (K<2m) 时转为反正切、对数是复函数且只剩 (1/\epsilon) 项发散。

这道任务抽取其中有限的非局域动量依赖积分，以零动量减除定义
\[
F(z)=\int_0^1x(1-x)\Log(1-zx(1-x)-i0)\,dx.
\]
引入 (z=q^2/m^2) 后在时空样、阈值、割线上方和高能处查询，并增加展开适用范围及谱矩诊断。题目明确省略整体耦合和张量因子，固定主值对数与割线侧，避免不同记号约定导致符号不确定。

原书扫描页 OCR 索引为 `planning/source-notes/qft-all.txt`；视觉核对的源页 PNG 位于 `tmp/pdfs/qft01-source/page-115.png` 和 `page-116.png`。这里没有把 OCR 当作未核验页面的证据。

## 与现有题目区别

- 与 `sp-01` 的 Landau 平均场驻点分类不同，本题研究相对论性一圈费曼图的解析结构、复平面割线和色散谱。
- 与量子力学势散射的实透射共振不同，本题的虚部来自真空中的粒子产生阈值，且须服从 (i0) 处方和一次减除色散关系。
- 12 个动量点是同一固定研究任务的测试查询，并非作为 12 道独立题计数。

## 独立真值和公平性

参考解使用解析延拓闭式；私有真值由高精度谱密度色散积分计算，割线主值显式减极点；第三条直接费曼参数对数积分逐点核验。三条实现各自生成积分/闭式结果，没有从候选解的核心模块导入结果。全部动量点及物理约定公开，私有文件仅保存由独立计算得到的答案供 verifier 重算。朴素基线保留正确积分定义及 (i0) 符号，使用固定 24 节点求积但不解析分段，数值误差由真实测量确定，没有用错误物理构造低分。


===== checks/qft-02-sources.md =====
# qft-02 来源与公平性

来源是用户提供的《量子场论试题详解》PDF 第 128--129 页（PDF 页 128--129，书内页码 120--121）：给出末态相空间 \(d\Phi_n\)、单位时空跃迁率、流因子和衰变宽度 \(d\Gamma=|\mathcal M|^2d\Phi_n/(2M)\)。公开 OCR 索引在 `planning/source-notes/qft-all.txt` 的 4876--4956 行；原页 PNG 在 `tmp/pdfs/qft02-source-128.png`、`qft02-source-129.png`。

题目把教材的相空间和衰变宽度公式改成可复核的三体标量研究：公开四组质量、复耦合、共振质量和宽度，要求积分、识别相干干涉并报告分位数。不同工况是同一研究任务的固定测试案例，不单独计题。

参考解采用端点平滑的自适应积分；私有真值采用高精度独立实现，不导入参考模块。基线是真实但分辨率有限的均匀梯形积分。Verifier 只读取候选 JSON 和私有真值，题面不泄露正确结果。


===== checks/qft-03-sources.md =====
# qft-03 来源与公平性

来源：用户提供的《量子场论试题详解》PDF 第 203--205 页（书内 195--197 页），视觉核对了一圈 QED/QCD β 函数、\(\beta_0=11-2n_f/3\)、重整化群方程的积分解及渐近自由讨论。OCR 对应 `planning/source-notes/qft-all.txt` 第 7579--7805 行；原页图保存在 `tmp/pdfs/qft03-source-203.png` 至 `205.png`。

题目把教材的连续流公式改造成跨阈值参数反演：全部观测能标和边界公开，私有真值仅保存独立的高精度秩/投影核对。`rg-02` 和 `rg-03` 有意设置秩亏，评分接受等价的可行参数化，避免把参考文字或某个任意代表元当作唯一答案。基线是真实的固定味数近似，不是故意错误格式。


===== checks/qft-04-sources.md =====
# QFT-04 教材来源

来源是用户提供的《量子场论试题详解（凡人看得懂的量子场论 非211高校适用）》PDF 第 83--85 页，对应书内页码 75--77。已逐页渲染并目视核对：第 83 页有 Compton 散射的双图与关联函数；第 84 页给出坐标及动量空间传播子/顶点规则；第 85 页汇总光子、电子外线、电子传播子和顶点。原页图位于 `checks/qft-04-source-pages/compton-083.png`、`084.png`、`085.png`。

教材存在其自身的整体相位、图形记号与高亮注解。题面使用明确的标准 \(+---\) 度规、\(\bar uu=2\) 和两图振幅约定，避免把教材中间的相位/归一化讨论误作待猜条件。散射截面的 Lorentz 不变相空间和流因子另见 PDF 第 128--129 页；两页曾为 QFT-02 逐页渲染核对，图位于 `tmp/pdfs/qft02-source-128.png`、`129.png`。

教材给出的是 QED Feynman 规则和康普顿过程，不直接给本任务的七组 boost 窗口、分位数或振幅探针答案。本任务的窗口设计、恒能谱/空谱案例是基于同一理论的原创数值问题，不宣称扫描页含本任务完整答案。


===== checks/qft-05-sources.md =====
# 来源与原创改造

《量子场论试题详解》第1.3.2.2节Gordon分解和顶角修正，PDF131–135页／书页123–127。原书随后在高能极限省略F2；本题保留其有限质量分子并求有限调节及类时阈值下的动量响应，属于原创扩展，不归称原书已给结果。

所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。

QFT01为二点真空极化，本题三点壳上顶角Pauli张量结构与有限IR调节；不重复散射或RG。

参考解三角域变换为嵌套双积分；真值解析积掉一个参数后55位单积分和高精度微分。


===== checks/qft-06-sources.md =====
# 来源与本地改造

Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.8。

PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db

页码（PDF / 印刷）: [{"pdf": [65, 65], "printed": [63, 63], "role": "题面"}, {"pdf": [219, 220], "printed": [221, 222], "role": "解答"}]

原书工作：移位后的两标量模型中枚举五类一圈贡献，含真空tadpole，用同一正则化和真空条件证明Σπ(0)=0。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。


===== checks/qft-07-sources.md =====
# 来源与本地改造

Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.12。

PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db

页码（PDF / 印刷）: [{"pdf": [66, 66], "printed": [64, 64], "role": "题面"}, {"pdf": [225, 231], "printed": [227, 233], "role": "解答"}]

原书工作：由幂计数及一圈费米子/标量两点、Yukawa三点和标量四点图，构造闭合的局域反项，包括费米盒图排列和耦合混合。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。


===== checks/qft-08-sources.md =====
# 来源与本地改造

Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.13。

PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db

页码（PDF / 印刷）: [{"pdf": [66, 66], "printed": [64, 64], "role": "题面"}, {"pdf": [231, 232], "printed": [233, 234], "role": "解答"}]

原书工作：保留D=2−ε的张量结构计算横向极化，再Dyson求和，在守恒源响应中得到mγ²=e²/π。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。


===== checks/qft-09-sources.md =====
# 来源与本地改造

François Gelis，*Problems in Quantum Field Theory*，原题 5。

PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5

页码（PDF / 印刷）: [{"pdf": [34, 40], "printed": [22, 28], "role": "完整题面与解答"}]

原书工作：推导Feynman参数在壳条件和逐圈方程，找出无质量三角图两条共线支、一条软支，以Coleman–Norton图像排除伪分支。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。


===== checks/qft-10-sources.md =====
# 来源与本地改造

François Gelis，*Problems in Quantum Field Theory*，原题 11。

PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5

页码（PDF / 印刷）: [{"pdf": [55, 61], "printed": [43, 49], "role": "完整题面与解答"}]

原书工作：用散射算符端点简并子空间及幺正性，证明完整初末不可分辨态求和消除红外奇异；有明确连续谱及简并集合假设。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

补充过程：Ellis, Ross & Terrano, Nucl.Phys.B178 (1981) 421–456, DOI 10.1016/0550-3213(81)90165-6（e+e− three-jet 矩阵元及NLO）；此题使用单一O(αs)过程，未使用多维有限矩阵代替散射。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。


===== checks/qft-11-sources.md =====
# 来源与本地改造

François Gelis，*Problems in Quantum Field Theory*，原题 24,25。

PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5

页码（PDF / 印刷）: [{"pdf": [274, 277], "printed": [103, 106], "role": "24题完整题面与解答"}, {"pdf": [278, 281], "printed": [107, 110], "role": "25题完整题面与解答"}]

原书工作：零点模和减去体积项，用Euler–Maclaurin得到能量与应力；以δ壁的泛函行列式和ζ函数独立复现强壁极限。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。


===== checks/qft-12-sources.md =====
# 来源与本地改造

François Gelis，*Problems in Quantum Field Theory*，原题 26。

PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5

页码（PDF / 印刷）: [{"pdf": [282, 285], "printed": [111, 114], "role": "完整题面与解答"}]

原书工作：引入辅助场、积分费米子并重整化有效势，得到非解析质量尺度和leading large-N真空。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。


===== checks/qft-20-sources.md =====
# QFT-20：Dirac 低谱、Banks–Casher 凝聚与极限次序


来源：François Gelis, *Problems in Quantum Field Theory*, 第69题；用户PDF实际页161–163，书页283–285。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与材料

Gelis 第69题用 Euclidean Dirac 算子的正负配对谱证明 Banks–Casher 关系。现在请对三个**受控合成谱模型**完成凝聚重建和极限判断。它们不是实际格点 QCD 数据。取自然单位，输出正的凝聚幅度 \(S=-\langle\bar\psi\psi\rangle\)；完整有符号谱的单位四体积密度为 \(\rho_V(\lambda)\)。非零本征值为 \(\pm\lambda_j\)，另有 `zero_modes=N0` 个精确零模。

每个 `families` 项给出多体积谱、质量查询和已知 UV 尾。低谱的未知正支密度属于
\[
 \rho(\lambda)=r[1+b(\lambda-g)^2],\qquad g\le\lambda\le\Lambda,
\]
其中 \(r>0,b\ge0,g\ge0\) 在同一谱族内固定。公开谱通过确定性中点分位点产生：
\[
\int_g^{\lambda_j}\rho(\lambda)d\lambda=(j+1/2)/V,\quad j=0,\ldots,N-1,
\qquad \int_g^{\Lambda}\rho(\lambda)d\lambda=N/V.
\]
`edge` 就是该体积的 \(\Lambda\)；当体积增长时趋向固定截止。以上是生成约束，不是额外观测噪声；不得从直方图宽度推断严格零点密度。\(\lambda>\Lambda\) 的正支 UV 密度明确为 \(c/(1+\lambda^2)\)，其中 \(c\) 是公开 `uv_density_coefficient`，负支按偶对称延伸。UV 尾必须积分到无穷，不能遗忘或重复乘二。

有限体积凝聚为
\[
 S(V,m)=\frac{N_0}{mV}+\frac{2m}{V}\sum_j\frac1{\lambda_j^2+m^2}
 +2m\int_\Lambda^\infty\frac{c\,d\lambda}{(1+\lambda^2)(\lambda^2+m^2)}.
\]
定义 \(S_\infty^{(\Lambda)}(m)\) 为把上述非零低谱和替换成对应 \(\rho\) 的连续积分、保持同一个 `edge` 和 UV 尾的结果；零模不包括在内。定义有限体积修正 \(\delta=S_{\rm paired+UV}-S_\infty^{(\Lambda)}\)。先 \(V\to\infty\) 再 \(m\to0^+\) 的幅度记为 \(S_\chi\)。同时判断反向取极限是否有限，精确零模必须单独处理。各族的 `zero_modes` 序列都是次广延的。

## 必须交付

每族一个 `族名-inference` 行，`values` 依次为
`[r,b,g,S_chi,reverse_limit_finite,reverse_limit_diverges]`。两个标志取数值0或1；若无零模，反向极限值为0；若任意固定体积含零模，反向质量极限发散，用标志报告，不能写 Infinity。

每个公开体积/质量一个 `族名-V体积-m质量` 行，ID 已在 `output_specs` 穷举，`values` 依次为
`[S(V,m),N0/(mV),delta,S_infty_matched_cutoff,B,window_usable]`。
这里
\[
 B=|\delta|+N_0/(mV)+|S_\infty^{(\Lambda)}(m)-S_\chi|
\]
是从该点推断手征凝聚的公开保守误差上界。`window_usable=1` 当且仅当 \(B\le\)`window_target`，否则0。这样窗口判定有可核验的标准，不按自由文字或某个固定质量区间评分。所列全部点均要计算，包括不合格的窗口。

这道题同时考查谱归一化、UV尾、零模、有限体积偏差和极限次序。仅输出 \(\pi\rho(0)\) 不能完成任务。


## 验证路线

参考解先以确定性分位点反演 r,b,g，再对完整 +/- 谱直接求和。UV 尾作有理分式积分；低谱连续积分用独立数值求积。私有真值读取独立保留的生成参数，用45位 mpmath 求和、UV求积和低谱解析原函数，不导入参考解或拟合参数。

低谱连续积分原函数来自展开 `1+b(lambda-g)^2`：在端点 g,edge 之间，积分核可写成 arctan、线性项和 log 的组合。检查文件记录解析原函数与45位直接积分的最大差。零模贡献单独计算；次广延N0在固定m的体积极限消失，在固定V的质量极限仍可发散。

基线假设低谱无隙且局部平坦，用前40个低模估计密度，仍做完整有限谱与UV尾求和。它是有明确适用范围的密度近似，分差不是来自故意破坏格式。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。


===== checks/qft-21-sources.md =====
# QFT-21：格点费米子倍增、完整零点与局部指数


来源：François Gelis, *Problems in Quantum Field Theory*, 第70题；用户PDF实际页163–168，书页285–290。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与约定

Gelis 第70题用动量环面上的局部指数讨论 Nielsen–Ninomiya 倍增约束。请对公开的四维有限 Fourier 核族找全零点，并给出局部拓扑信息。格距为1，Brillouin 区是 \(p_\mu\in[-\pi,\pi)\)。逆质量零 Weyl 核用实四矢量 \(F_\mu(p)\) 表示：
\[
q_0=p_0,\quad q_i=p_i+s_i\sin p_{i-1}\pmod{2\pi}\quad(i=1,2,3),
\qquad F_i=\sin q_i+a_i\sin(2q_i).
\]
`a` 和 `shear` 分别给出四个 \(a_i\) 与三个 \(s_i\)。该三角坐标变换是环面上的保定向微分同胚；不能把其耦合当作四维随机找根可以忽略的项。

每个孤立非退化零点的指数定义为 \(\operatorname{sgn}\det(\partial F/\partial p)\)。本题还含 \(|a_i|=1/2\) 的**孤立简并零点**：必须报告 Jacobian 行列式0，但局部 Brouwer 映射度由最低非零奇次项决定，不能把指数随手置0。临界前后零点的生成/湮灭可用来核对局部度。`near-critical` 是公开有限距离的近临界例子，仍应按严格输入参数找全简单根。

## 必须交付

每个 `cases` ID 一个 `results` 项，`values` 为零点行数组；每行严格依次为
`[p0,p1,p2,p3,det_J,local_degree,degenerate]`。

- `local_degree` 为数值 +1 或 −1，`degenerate` 为数值0或1。
- 坐标可用任意相差整倍 \(2\pi\) 的代表；评分使用周期最优匹配，行顺序不限。\(+\pi\) 和 \(-\pi\) 是同一点，只提交一次。
- 每个不同零点必须提交，额外零点和遗漏均扣分。`rows:512` 是安全容量上限，**不是正确零点数**。
- 需要计算完整 Jacobian；精确临界参数按解析条件判断简并，不用任意浮点阈值改变物理分类。

请在 `method` 简述根完备性依据，以及净指数怎样与周期核假设相容。本题的总指数约束限于给定连续、周期、局域 Fourier 型 Weyl 核；不宣称所有格点手征实现都不可能。评分基于数值零点、行列式和局部度，方法文字本身不自动获得分数。


## 验证路线

参考解在 q 坐标求 `sin q(1+2a cos q)=0` 的所有根，再用三角逆变换恢复 p。Jacobian 是对角标量导数乘三角坐标Jacobian，后者行列式1。临界a=+/-1/2时，一次项消失但三次项不消失，孤立根的局部度仍为三次系数符号乘其余简单方向的符号。

独立真值把 z=exp(iq) 代入，枚举 `(z²-1)(a z²+z+a)=0` 的全部单位圆根，独立构造完整4x4 Jacobian。它检查原Fourier核残差和各工况局部度之和0。代数根枚举保证完备性，不将随机多初值找根当作真值。

基线保留朴素最近邻动量核的16个角点，并在这些点使用正确参数计算局部信息；在高次谐波产生新doublers时漏点，因此不能获得完整性分。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。


===== checks/qft-22-sources.md =====
# QFT-22：中心对称、有限体积扇区混合与 Polyakov 环


来源：François Gelis, *Problems in Quantum Field Theory*, 第72题；用户PDF实际页171–175，书页293–297。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与材料

Gelis 第72题说明纯规范理论的中心变换、Polyakov 环及基本表示物质的显式破缺。本题把它改造成**精确定义的中心有效模型**；这些数据不能用来声称真实 QCD 的临界温度。

首先，`chains` 给出四个不对易的 SU(3) 时间连接 \(U_0,\ldots,U_3\)，每个矩阵元素编码为 `[real,imag]`，最早时间的 \(U_0\) 作用在最右边。holonomy 为 \(W=U_3U_2U_1U_0\)，\(L=\operatorname{tr}W/3\)。中心扭曲 `twist=k` 令 \(W\to z^kW\)，\(z=e^{2\pi i/3}\)。`matter_nalities` 给出物质表示的 N-ality，只有对所有物质均满足 \(z^{kn}=1\) 的中心元素仍是对称性。

第二，`ensembles` 是完全图上的三态中心模型。体积 \(N\) 的每个格点 \(s_i\in\{0,1,2\}\)，\(L=N^{-1}\sum_i z^{s_i}\)。用占据数 \(n_0+n_1+n_2=N\) 表示，每个具体构型的无量纲 Boltzmann 权重为
\[
 w(s)=\exp\left[\frac{J}{2N}(n_0^2+n_1^2+n_2^2)+hN\operatorname{Re}L\right].
\]
同一占据数组合有 \(N!/(n_0!n_1!n_2!)\) 个具体构型。`h=0` 的有限体系包含全部中心扇区，禁止先挑一个扇区再报全系综均值。

对有限 \(N\)，定义
\(M_2=\langle|L|^2\rangle\)、\(U=1-\langle|L|^4\rangle/(2M_2^2)\)、
\(C_{\ne}=\langle z^{s_i-s_j}\rangle_{i\ne j}\)，以及每点对数配分函数 \(\log Z/N\)。其中 \(C_{\ne}\) 是不同点之间的平均相关，不能把自相关1混入。

热力学判据公开定义如下。令 \(x_j=n_j/N\)、\(\ell=\sum_jx_jz^j\)，全局极小化
\[
 f(x)=\sum_{j=0}^2x_j\log x_j-\frac J2\sum_jx_j^2-h\operatorname{Re}\ell,
\quad x_j\ge0,\ \sum_jx_j=1.
\]
`phase_code=0` 表示 \(h=0\) 且全局极小为均匀分布；`1` 表示 \(h=0\) 且有三个中心相关的非均匀全局极小（有限体积的扇区混合有序分布）；`2` 表示 \(h\ne0\) 的显式破缺。输入避开严格共存点。`thermodynamic_order_squared=|ell_min|^2`；三扇区在 \(h=0\) 时给相同模平方。**均值为零不是本题唯一的物相判据。**

## 必须交付

每个 `系综ID-V体积` 行的 `values` 依次为
`[Re<L>,Im<L>,M2,C_distinct,U,logZ/N,phase_code,thermodynamic_order_squared,f_min]`。

每个 `chains` ID 行的 `values` 依次为
`[Re L,Im L,Re(z^k L),Im(z^k L),keep_k0,keep_k1,keep_k2]`，三个 `keep` 是数值0或1。

任务要求同时完成精确有限系综统计、热力学全局极小判断、路径次序和残余中心。不得把这个显式给定有效模型的结论直接外推成完整 Yang–Mills 或含轻夸克 QCD 的结论。


## 验证路线

参考解按三态占据数枚举组合并使用log-sum-exp处理配分函数；精确矩关系给C_distinct=(N M2-1)/(N-1)。热力学最小化可利用一个中心扇区的对称参数x=((1+2r)/3,(1-r)/3,(1-r)/3)，搜全驻点后比自由能，而不是只取局部极小。输入J、h范围内该参数化覆盖物理解；原始自由能是公开定义的真值对象。

独立真值以Python整数二项式组合构造权重，不复用gammaln路线；N=12额外穷举全部3^12构型检查M2。热力学真值直接在二维概率单纯形从均匀及三个有序扇区搜索，独立于一维驻点方程。holonomy用四个显式群指标收缩核对矩阵连乘。

基线采用精确有限统计与群乘积，但直接把有限全系综|<L>|²当热力学序参量、用-logZ/N估计无限体积自由能，并以|<L>|是否超过0.1判断h=0的物相。这个统一的有限体积起点在扇区混合有序情形失败，尚未处理全局极小与极限次序；不掺入无关的路径次序错误。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。


===== checks/qft-23-sources.md =====
# QFT-23：热光子 HTL 的因果响应与集体模


来源：François Gelis, *Problems in Quantum Field Theory*, 第73题；用户PDF实际页176–179，书页298–301。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与约定

Gelis 第73题从带电硬粒子的无碰撞 Vlasov 响应推出 HTL 极化。请为**单个无质量 Dirac 物种**的各向同性平衡等离子体建立 retarded 响应。电子、正电子及两自旋的简并度共4，分布为 \(f_0(p)=4/(e^{p/T}+1)\)。自然单位；Debye 质量由硬动量积分确定，\(m_D^2=e^2 C_D T^2\)，\(C_D\) 要计算。下面所有频率和波数按 \(m_D\) 归一化，极化按 \(m_D^2\) 归一化。

波矢沿 \(+z\)，度规 \((+---)\)，时空 Fourier 为 \(e^{-i\omega t+i k z}\)，retarded 分母是 \(\omega-ku+i0\)。定义 \(x=\omega/k\) 和角平均响应
\[
 A(x)=\frac{\Pi^{00}_R}{m_D^2}=1-\frac{x}{2}\int_{-1}^1\frac{du}{x-u+i0},
\qquad B(x)=\frac{\Pi_T}{m_D^2}=\frac{x}{4}\int_{-1}^1\frac{1-u^2}{x-u+i0}\,du.
\]
它们是 Vlasov 张量的角积分起点，不把书中的实绝对值对数自动当作因果函数。空间样区域要保留主值和 \(\delta\) 项。由 Ward 关系，\(\Pi^{03}/m_D^2=xA\)、\(\Pi^{33}/m_D^2=x^2A\)。采用 Coulomb-gauge 纵向归一化响应 \(D_{00}=1/(k^2+A)\)，查询均离真实光锥奇点有限距离。

纵向正频集体模为 \(D_L(\omega,k)=k^2+A(\omega/k)=0\) 中 \(\omega>k\) 的物理解；横向为 \(D_T=\omega^2-k^2-B(\omega/k)=0\) 的物理解。留数定义为相应 **\(\omega\) 变量的一阶导数倒数**：\(R_L=(\partial_\omega D_L)^{-1}\)、\(R_T=(\partial_\omega D_T)^{-1}\)。不要与 \(\omega^2\) 留数混用，也不要额外取绝对值或乘 \(2\omega\)。

## 必须交付

每个 `queries` ID 行，`values` 依次为
`[Re A,Im A,Re B,Im B,Re(xA),Im(xA),Re(x²A),Im(x²A),Re D00,Im D00]`。

每个 `mode-k波数` 行，`values=[omega_L,omega_T,R_L,R_T]`。全部 `mode_k` 都要找到对应物理解。

`limits` 行依次为
`[lim_(k→0) lim_(omega→0) A,lim_(omega→0) lim_(k→0) A,Pi_T_static/mD²,Pi_T_uniform/mD²,C_D]`。
这里外侧极限写在前；`Pi_T_uniform` 指先在非零 \(\omega\) 下取 \(k\to0\)，再 \(\omega\to0\)。说明为什么两个 \(A\) 极限不交换。

HTL 仅适用于弱耦合、硬粒子动量约 \(T\)、软外动量约 \(eT\) 的各向同性平衡体系。本题没有碰撞项，不是所有温度/动量下的完整一圈真空加热修正。


## 验证路线

参考解对retarded角积分采用上半平面边界的复对数；|x|<1处为 log|(x+1)/(x-1)|-i*pi。由导数公式得到留数，再在omega>k域求两支物理解。静态与均匀极限由积分展开得到，C_D=4/pi² int_0^infty dp p/(e^p+1)=1/3。

独立真值对空间样点用Cauchy主值求积加精确delta项，对时间样点直接做速度积分。导数通过独立积分而非复用对数导数；Debye系数通过热分布径向求积。Ward分量按公开张量约定构造。

基线使用40点Gauss速度角网格和固定eta=.04，模式用小k等离子体近似；固定展宽和低阶色散不能覆盖光锥附近与有限k真实响应。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。


===== checks/qft-24-sources.md =====
# QFT-24：完整差分碰撞核下的 LPM 响应与近似选择


来源：François Gelis, *Problems in Quantum Field Theory*, 第75题；用户PDF实际页183–190，书页305–312。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与明确调节模型

Gelis 第75题的物理核心是形成时间内多次软散射同阶，必须保留碰撞算子的差分结构。本任务要求求解其**公开有限周期横动量调节模型**，比较完整核、一次碰撞和扩散近似。它是可独立复现的受控 LPM 响应题；不把有限方形网格伪称连续旋转对称模型，也不要求从此网格宣称普适软频率指数。

取 Debye 动量单位1。每个 `cases` 指定奇数网格边长 \(M\)、间距 \(h\)，点 \(p_{ij}=h(i-M//2,j-M//2)\)，\(0\le i,j<M\)。动量差采用最短周期代表 \(r_\mu\in\{-M//2,\ldots,M//2\}\)。定义全部非零转移的权重
\[
 K_r=\frac{h^2}{(2\pi)^2}\frac1{\ell_r^2(\ell_r^2+1)},\quad \ell_r=h r,\quad K_0=0,
\qquad (Cf)_p=\sum_rK_r(f_p-f_{p-r}).
\]
`p-r` 逐坐标模 \(M\)；该有限差分核就是本题精确模型，不再插值到无穷平面或另加核截断。零转移项的差分严格为0，不能把增益和损失分成两个 IR 发散积分后独立正则化。

令 \(D_p=a(m^2+p^2)\)、\(s_p=p_x\exp[-p^2/(2w^2)]\)，其中 `a,mass,source_width` 分别为 \(a,m,w\)。求唯一复响应
\[
 (C+iD)f=s.
\]
它采用正定耗散碰撞算子和 \(a>0\) 的因果相位约定。发射泛函 \(R=h^2\sum_ps_p\operatorname{Re}f_p\)。这里的源含 Gaussian 接受窗，以保证该有限基准不受紫外源尾污染；这是本项目明确的受控扩展，不归称原书已经给出的全部光子发射率。

定义一次碰撞 Bethe–Heitler 起点：\(g=s/D\)、\(f_{BH}=-ig+D^{-1}Cg\)，\(R_{BH}=h^2\sum_pg_p(Cg)_p\)。它在碰撞相对 \(D\) 较弱时适用，不能在全部输入上直接等同完整 \(R\)。

另一个比较是二阶矩扩散核：\(d=\tfrac14\sum_rK_r\ell_r^2\)，\(C_{diff}=d(-\Delta_h)\)，其中周期五点 \(-\Delta_h f=(4f-f_{+x}-f_{-x}-f_{+y}-f_{-y})/h^2\)。解 \((C_{diff}+iD)f_{diff}=s\) 得 \(R_{diff}\)。这是对同一有限核的扩散近似，不能把它的数值当完整核真值；正号来自 \(\langle f,Cf\rangle\ge0\)。

## 必须交付

每个 case 一行 `values`：
`[R,R_BH,R/R_BH,R_diff,relative_error_diff,BH_usable,diffusion_usable,Re f_probe1,Im f_probe1,...]`。

`relative_error_diff=|R_diff-R|/R`；`BH_usable=1` 当 \(|R_{BH}-R|/R\le\)`approximation_target`，否则0；`diffusion_usable` 同理。`probes` 中索引是明确的0基网格索引，不是动量坐标。每对探针实虚部按公开顺序输出。

需要使用完整核确定发射响应与近似适用区。所有核/源/边界均公开，直接稠密线性求解、FFT、Krylov 或其他收敛方法均可。参考解使用 FFT 使碰撞卷积对角化；独立真值由显式转移矩阵构造并求解，另核查实块线性系统和正性。


## 验证路线

由对称非负K，`<f,Cf>=1/2 sum_(p,r) K_r |f_p-f_(p-r)|²>=0`。因此碰撞核扩散展开应为正的-d Laplacian；不能直接复制书中Taylor行疑似反号。

参考解使用离散Fourier变换，使C的本征值为sum K - FFT(K)。势D在动量空间是对角的，使用预条件GMRES求完整复线性系统。BH项由Neumann展开 `(C+iD)^(-1)` 到一次碰撞得到，发射率为正二次型g.C.g。扩散比较用同一核二阶矩、周期五点负Laplacian，完整核真值从不替换成扩散核。

独立真值显式计算任意两动量点间的周期转移权重，构造稠密矩阵C，再用直接复求解与2n实块求解互查，并检查全部C本征值非负。公开网格就是规定模型；改成更细网格会改变题目，不用这种变化伪称连续收敛。有限调节的连续外推及原书软频率普适标度不是本题交付项。

基线是公式明确的一次碰撞BH解，仍计算扩散比较，但用BH作为完整响应；强相干工况有明显抑制。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。


===== checks/qft-25-sources.md =====
# QFT-25：标量强场产对、相干脉冲与玻色统计


来源：François Gelis, *Problems in Quantum Field Theory*, 第80题；用户PDF实际页209–217，书页331–339。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与约定

Gelis 第80题是**复标量 QED**的外场产对。自然单位，\(e=1\)、`mass=m`。外场空间均匀，temporal gauge \(A_0=0\)，仅 \(A_z(t)\ne0\)，电场 \(E_z=-\dot A_z\)。经典外场预先给定，不含反作用、自相互作用、光子环或费米子 Pauli 阻塞。

`backgrounds` 定义
\[
A_z(t)=A_{shift}+A_{offset}+\sum_j a_j\tanh[(t-t_j)/\tau_j],
\qquad -T\le t\le T.
\]
`pulses` 每项 `[a,center,tau]`；`offset` 是物理上对齐孤立脉冲与双脉冲相应阶段的常势，`shift` 是与canonical动量一起改变的规范平移，两者不能混用。使用输入给定有限 \(T\) 处的频率作为精确初末频率约定。对于每个 `modes`，规范未平移时 canonical \(k_z\) 就是公开 `kz`；背景含 `shift` 时必须同时取 \(k_z=\)`kz-shift`，这样 \(k_z+A_z\) 不变。`kperp` 是横动量模长。

模方程与初值为
\[
\ddot u+[m^2+k_\perp^2+(k_z+A_z(t))^2]u=0,
\qquad u(-T)=\frac1{\sqrt{2\omega_{in}}},\quad
\dot u(-T)=-i\sqrt{\omega_{in}/2}.
\]
在 \(+T\) 用正负频模分解，数目 \(n_k=|\beta_k|^2\)，满足玻色归一化 \(|\alpha_k|^2-|\beta_k|^2=1\)。评分只比较不变量，不把相位约定不同的裸 \(\alpha,\beta\) 判错。要求同时报告末态 kinetic 纵动量 \(p_{z,out}=k_z+A_z(T)\)。

每个离散输入 mode **恰好代表一个独立 canonical 模对**（正粒子 \(k\) 与负粒子 \(-k\)）；即使列表含 \(k_z\) 正负两种数值，它们是不同的模对，不额外乘二或再除二。每模产对数服从几何分布，而非 Poisson。对有限模集，计算总产对数均值 \(\mu\)、方差 \(v\)、\(\log P_0\) 及总粒子—反粒子数协方差 \(c_{+-}\)。不要混淆“总对数”与“粒子加反粒子总数”。

## 必须交付

每个 `背景ID-modeID` 行，`values=[n_k,abs_alpha_squared,pz_out]`。
每个 `背景ID-statistics` 行，`values=[mean_pairs,variance_pairs,log_vacuum_survival,cov_particle_antiparticle]`。

`first` 和 `second` 分别是孤立的正/负 Sauter 阶跃背景，`offset=1.2` 使其渐近常势分别为0→2.4、2.4→0，与 `double` 对应的两个阶段对齐；`double` 是两阶跃相干组合，`gauge-shifted` 是同一 double 的残余规范平移。对于每个 `interference-modeID` 行，报告
\[
 [n_{double}/\max(n_{first}+n_{second},\epsilon),\quad
 |n_{double}-n_{first}-n_{second}|/\max(n_{first}+n_{second},\epsilon)],
\]
其中 \(\epsilon=\)`occupation_floor`。两个孤立背景按同一 canonical 参考动量、已经对齐的渐近常势比较；分母是逐脉冲占据数的非相干相加预测，不包含相位干涉或玻色刺激项，不允许另行平移动量后重新定义分母。

任务包含频率变化、双脉冲相位干涉、规范平移和玻色统计。仅用常场率或把两次产对概率相加不能完成全部输出。公开容差对极小占据数采用绝对尺度，不按无意义的极小谱尾相对精度扣分。


## 验证路线

参考解积分二阶复KG方程，在末端按固定频率投影：beta=sqrt(omega_out/2)(u+udot/(i omega_out))，alpha采用相反号，比较模长。独立真值使用一阶绝热Bogoliubov系统：theta'=omega，alpha'=q exp(2i theta) beta，beta'=q exp(-2i theta) alpha，q=omega'/(2omega)。它不调用二阶参考函数；两个孤立Sauter背景另与解析谱核验。

对offset+a*tanh((t-center)/tau)，解析n=[cosh(2pi sqrt((a tau)²-1/4))+cosh(pi tau(omega_out-omega_in))]/[2 sinh(pi tau omega_in)sinh(pi tau omega_out)]，omega_in/out均使用已给offset和正确渐近kinetic动量。有限T尾误差已小于公开绝对容差。数值Wronskian残差独立核查。

每模两模压缩真空给几何对数分布：均值n，方差n(1+n)，P0=1/(1+n)。独立模相乘故log P0=-sum log(1+n)，总粒子与反粒子数相同，协方差等于对数方差。基线是一次绝热/Born混合并以Poisson作稀薄近似，具有明确适用层次；对双脉冲与增强占据数需改进。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。


===== checks/qm-01-sources.md =====
# qm-01 教材来源与题目改造

已目视核对用户提供的 Griffiths《量子力学概论》配套学习指导书 PDF 第 56–58 页（书内第 50–52 页），第 2 章习题 2.27。教材题给出等强度双 δ 吸引势，要求束缚态数目及指定强度下的能级；解答分段写波函数并使用 δ 点导数跃变形成匹配行列式。

本题改为可控的左右不等强度 `g_left,g_right`，设计八个浅/深和近/远阱工况，要求恢复完整负能谱及左半空间概率。独立数值验证和一对一匹配评分用于识别漏态、误计阈值态与态局域化错误。

来源 PDF：`/Users/ai4s/Downloads/量子力学概论-格里菲斯-学习指导书习题解答-中文版.pdf`。教材理论与题型有明确来源；非对称扩展、工况集、评分和 Harbor 封装由本项目编写，不把经典 δ 势结果宣称为新理论。


===== checks/qm-02-sources.md =====
# qm-02 来源与贡献

原始教材由用户提供：`/Users/ai4s/Downloads/量子力学概论-格里菲斯-学习指导书习题解答-中文版.pdf`。

- PDF 67-68，书内 61-62，习题 2.33：矩形势垒、波函数与导数连续性、低于势垒的透射公式。
- PDF 98-99，书内 92-93，习题 2.53：传递矩阵定义，两个分离势总矩阵为分矩阵乘积，图 2-22。

四页已由 pdftoppm 渲染并使用图像工具实际查看，页面保存在 `checks/qm-02-source-pages/`。OCR 仅用于定位，未拿 OCR 识别错误代替原公式。

本组贡献：将单势垒与多段势组合原则扩展成双有限矩形势垒完整共振研究；构造公开固定工况、引入半高全宽及能窗平均透射、实现稳定参考与独立 60 位矩阵真值、给出可重算指标。

独立性：qm-01 为负能闭系统的双 delta 束缚态与空间概率；qm-02 为正能开放系统双矩形势垒的共振透射和积分。势、边界条件、待研究物理量、数值困难及评分均不同。本题的四组工况共同组成一道任务，不算四题。


===== checks/qm-03-sources.md =====
# qm-03 来源与贡献

用户原件：`/Users/ai4s/Downloads/量子力学概论-格里菲斯-学习指导书习题解答-中文版.pdf`。

确切位置：PDF 228–231 页，书内 222–225 页，习题 5.18–5.21。

- 5.18：Bloch 波函数与带边特殊情形；周期 δ 势色散关系。
- 5.19：给定排斥强度的第一允带底端。
- 5.20：把排斥梳改为吸引梳，负能量双曲函数支与每带态数。
- 5.21：有限周期环的 Bloch 波数、成对简并与带边例外。

这四页均已实际渲染并逐页查看，图像为 `checks/qm-03-source-pages/bloch-228.png` 至 `bloch-231.png`。OCR 仅用于定位。

本组制作的题设采用每胞两个点势，并非逐字复刻教材数值。新增独立双原子晶格输入、三条带边、有限环前两带全扇区能级、负能窄带及闭隙/开隙研究。精确标量判别式参考与 60 位独立状态矩阵真值分别实现；使用课程原版质量分函数。

该题是一道周期量子谱任务，四组固定工况不算四题。与孤立束缚态 qm-01、开放系统散射 qm-02 的边界条件、待研究量及数值分支问题均不同。


===== checks/qm-04-sources.md =====
# 来源与原创改造

《量子力学概论—学习指导书习题解答》习题9.20，PDF387–390页／书页381–384。原书为单段圆偏振磁共振；多段相位跳变、非对易复合驱动与失谐响应为本题原创扩展。

所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。

不同于QM01束缚态、QM02散射、QM03空间周期谱；研究含时非对易传播与相干控制。

参考解旋转框架解析SU(2)及Fréchet导数；私有真值独立积分实验室系Schrodinger方程和参数灵敏度ODE。


===== checks/qm-05-sources.md =====
# 来源与原创改造

《量子力学概论—学习指导书习题解答》习题7.1(b)，PDF307–308页／书页301–302，四次势高斯变分。加入二次项、六次稳定项、前四能级、偶极跃迁和双阱谱为原创扩展。

所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。

无散射或Bloch结构，挑战非微扰谱、矩阵元和不同极限下的近似适用性。

参考解180维优化振子Rayleigh–Ritz；真值为独立实空间8阶差分，2200/3000网格收敛互查。


===== checks/sp-01-sources.md =====
# sp-01 来源与改造

核对日期：2026-11-16。

## 用户提供的教材依据

林宗涵，《热力学与统计物理学》配套习题解答，第九章，习题 9.2、9.3。源文件：`/Users/ai4s/Downloads/热力学与统计物理学 习题解答 by 林宗涵.pdf`。

已渲染并目视核对 PDF 第 174–177 页，对应书内第 168–171 页：

- 习题 9.2 给出铁磁 Ising 模型的平均场自洽方程。
- 习题 9.3 讨论零场有序分支、临界附近展开及磁化率。
- 第 170–171 页特别区分有限外场求导和零场极限的先后顺序。

本题使用热力学极限的 Curie–Weiss 平均场模型，不将其与一维短程 Ising 模型的精确有限温行为混同。固定磁化的熵自由能由二元自旋组合熵独立推导，用于在自洽解之外比较势形；参考解说明列出推导及重复计数项。

## 本题改造与贡献

从教材自洽方程与临界近似，改造成跨越单分支、三分支和共存工况的分支恢复任务。提交必须找全驻点、区分局部与全局稳定性，并计算有限场分支响应。工况含零场共存、正/负场、接近临界温度以及跨越亚稳分支消失区域。

Landau 近似作为可复现基线，完整平均场分支作为参考，70 位独立计算生成验证值。评分按磁化、自由能、响应和分类的一对一匹配计连续误差，对漏报和重复分支同样起作用。

经典平均场理论与通用求根算法均为已有知识。本项目编写固定工况、题面、公开反馈与评测代码；没有复制现有 benchmark 的题面、输入或解答代码。整套科学编程评测的相关工作说明见 [tm-01 来源记录](tm-01-sources.md)。


===== checks/sp-02-sources-and-fairness.md =====
# sp-02来源与公平性

用户林宗涵《热力学与统计物理学》习题解答原PDF165-166页，书159-160页，题8.13。两页均已Poppler渲染且真实view_image视觉核对，证据位于 `checks/sp-02-source-pages/lin-165.png`、`lin-166.png`。原题给定固定总粒子数N的理想气体，考查子体积v，并明确取热力学极限、将子粒子数求和上限从N延至无穷，导出泊松分布。书160页末明确说明在重力可忽略时平均密度均匀。

本题研究这一近似的有限储库修正：保留固定N、引入两个不相交观察窗，并用公开的线性外势定义非均匀单粒子位置分布。多项分布直接从经典正则位置配分函数导出。参考解的O(N)条件尾算法、稀有事件和条件协方差是在教材模型基础上的可复现研究改造，并非声称原书有完全相同八组数值答案。

与sp01平均场多项式分支无关：本题是理想气体正则计数、固定总数相关与大偏差，不含相互作用、相变或临界点。八工况属于一个完整任务，不拆成八题。

全部输入、模型、输出约定及评分公开。公开起点是物理合理的独立泊松热力学极限，具有稳定对数尾算法，没有人为制造数值下溢。参考与独立真值不进入Agent环境。独立75位真值反转条件化方向，并对小N工况按总占据数直接求多项分布交叉核验。固定质量评分使用课程原版函数，端点由本地Linux实际运行确定。外部benchmark相似性检索由主代理统一补齐。


===== checks/sp-03-sources-and-fairness.md =====
# sp-03来源与公平性

用户林宗涵《热力学与统计物理学》习题解答，题7.18–7.20。原PDF127、129、130页（书121、123、124页）已实际渲染且逐页view_image核对，文件位于 `checks/sp-03-source-pages/lin-127.png`、`lin-129.png`、`lin-130.png`；PDF128也已渲染，但不声称已视觉阅读。

7.18给三维各向同性谐阱单粒子能谱，并在能量远大于hbar*omega时连续化得到epsilon²态密度；7.19在大N、激发态饱和时取mu=0，给Tc0；7.20给热力学极限下的凝聚比例。本题保留同一个真实单粒子能谱的离散壳层与简并度，把这些近似改造为有限平均N的数值研究。

题目明确使用巨正则系综、平均粒子数N受约束，不冒充固定总N的正则凝聚涨落模型，也不将有限体系的激发态饱和点描述为非解析相变。输出化学势、基态比例、激发能、定平均N热容和饱和温度修正，共同描述一个完整的谐阱Bose气体任务；它独立于sp01平均场相互作用分支与sp02经典有限储库计数。

所有工况、能谱、系综、归一和评分公开。基线是教材连续态密度近似，正常区也求连续逸度而非故意沿用低温公式。公开反馈仅验证离散粒子数与能量一致性，不提供热容和饱和温度标签。60位独立真值由循环展开建立，不导入参考壳层求和代码，并与高精度壳层和及定平均N差分热容交叉核对。外部benchmark相似性检索由主代理统一补齐。


===== checks/sp-04-sources-and-fairness.md =====
# sp-04 来源与公平性

用户林宗涵《热力学与统计物理学》习题解答题7.25。原PDF138、140、141页（书132、134、135）已实际渲染且view_image核对，图像位于 `checks/sp-04-source-pages/lin-138.png`、`lin-140.png`、`lin-141.png`；PDF139也已渲染但未声称视觉阅读。

书132页给二维电子气的常数态密度及零温化学势；书134页在强简并条件下作Sommerfeld展开，给化学势的零阶结果及T²能量修正；书135页由自由能得到线性T熵。本题以这一真实二维色散为基础，公开加入第二个带底阈值，研究原低温展开在带边附近的适用边界。第二子带模型、参数与扩展问题均在题面公开，不声称原书已含同样双带数值答案。

该题是理想Fermi统计的阈值热激发与定密度响应，独立于sp01平均场分支、sp02经典有限储库计数和sp03谐阱Bose凝聚。八工况组成一个双子带热力学研究任务，不拆成多题。

全部参数、能量零点、态密度权重和评分公开。基线保留正确的零温带填充及Sommerfeld项，没有人为改坏公式；在深简并且化学势远离带边时有物理依据。反馈以完整有限温密度方程检查共享化学势，不提供响应标签。独立65位真值不导入参考核心，直接积分占据、二元熵和中心涨落核，并用高精度多对数能量及定密度差分热容交叉核验。参考与真值不复制进Agent环境。外部benchmark相似性检索由主代理统一补齐。


===== checks/sp-05-sources-and-fairness.md =====
# SP05 来源与公平性

- 题源：用户提供的林宗涵《热力学与统计物理学》及习题解答。直接依据为解答题3.8–3.9，PDF第61–62页、书页55–56；两页均已实际渲染并目视核验。题3.8为等温线极值/失稳线，题3.9为完整对比物态方程及临界展开。渲染文件在 `checks/sp-05-source-pages/`。
- 改编：从局部极值和临界截断扩展到完整状态方程的全局液气共存、临界分支分辨、自由能下凸包、气化潜热与克拉珀龙关系。温度和平均体积是公开制定的数值工况，不将扩展内容冒充教材原题原文或未知科研结论。
- 与其他题的独立性：SP01是磁性多项式平均场；SP05使用完整vdW流体、排除体积极点、正压全局公共切线和定平均体积混相。SP02–04分别为固定粒子涨落、离散Bose谱和Fermi子带，不共用此求解结构。
- 公开信息：全部8个温度、5个平均体积、单位、自由能温度规范、输出字段、误差权重和质量端点均公开。公开模型及反馈不导入私有真值。Dockerfile只复制public，不复制solution、tests/private或教材PDF。
- 合理基线：领先阶临界密度展开，具有正确临界指数与领先幅度；精确解失稳线，保留物质的量杠杆规则。更远离临界点时误差来自忽略高阶修正，没有故意制造下溢、噪声或错误单位。
- 独立真值：75位完整共存曲线参数化和三角失稳线，与45位直接分支/等面积参考不同；数值积分、公共切线、焓差、有限差分及凸包关系另作核验。私有标签仅给出公开工况的目标数值，不按预设代码形式评分。
- 等价答案：工况和平均体积顺序均不限；不限使用参数化、凸优化、公共切线或高精度分支求根。自由能固定规范已提前明确，不能用未声明的常数移位改变输出后再要求等价。
- 临界公平性：不只用端点体积的绝对误差，另评相对密度差；避免共存根合并时退化猜测获满分。全部工况仍为严格亚临界，未要求在临界点输出0/0形式的斜率。
- 资源：4CPU、4GiB、0GPU，agent1200秒、verifier120秒；本地Docker实测完成，不使用远程推理资源。
- 评分：课程原版quality_score逐字节复制；0/1端点来自实际运行，不将开发数值核验冒充正式被测智能体成绩。


===== checks/tm-01-sources.md =====
# tm-01 来源与改造

## 教材依据

- 鞠国兴，《理论力学学习指导与习题解析（理科用）（第二版）》，第 5 章“小振动”，习题 5.8。
- 用户提供的扫描件：`/Users/ai4s/Downloads/理论力学学习指导与习题解析(理科用)(第二版)-鞠国兴.pdf`。
- 准确位置：PDF 第 319–326 页，对应书内印刷第 310–317 页。2026-11-16 已渲染并目视核对 PDF 第 319、322、323、325、326 页。
- 题目从书内第 310 页开始；固定端 N 质点链、动能和势能见第 313 页；拉格朗日方程与本征值问题见第 314 页；固有频率与模态解见第 316–317 页。

教材的相关题目讨论固定端、等质量质点—弹簧链的正向小振动，给出动力学矩阵、简正模态和固有频率。此任务复用该经典理论力学模型，题面和求解目标由本组重新设计。

## 本组改造

1. 从给定参数求固有频率的正问题，改成由局部时域运动辨识九个非均匀弹簧刚度。
2. 给出三种已知初始状态下的含噪局部观测，要求模型利用小振动动力学解释全部时间历程。
3. 加入两个离散软化位置与连续刚度参数的联合反演。
4. 用未公开初始状态、采样网格和观测质点重新计算响应，核验识别出的力学模型能否外推。
5. 提供可执行的公开拟合反馈、粗网格基线、连续优化参考解和独立评分程序。

## 与已有科学评测的对照

已读取 SciCode 官方仓库的原始说明：

- Tian et al., *SciCode: A Research Coding Benchmark Curated by Scientists* (2024), [arXiv:2407.13168](https://arxiv.org/abs/2407.13168)。
- 官方仓库：[scicode-bench/SciCode](https://github.com/scicode-bench/SciCode)，核对日期 2026-11-16。

SciCode 将科学问题拆分为多个代码子问题，以专家解和测试用例评估研究编程能力。本题借鉴“科学知识落实为可执行计算并独立验证”的评测思路，但没有移植其题目、数据或代码。本题的最终产物是固定物理实例的九个刚度和两处软化位置；Agent 可以自行选择反演程序，verifier 依据物理参数和隐藏运动预测计连续分数。

弹簧链、简正振动、最小二乘反演和 Gauss–Newton 均为已有方法。本题的课程制作工作是将教材正问题改造成局部含噪观测下的离散位置与连续参数联合反演，并提供公开反馈、基线、参考解及 Harbor 独立验证。评价重点是能否恢复可预测额外初态和自由度运动的力学模型；不将经典物理模型或通用优化方法宣称为本项目的新理论。

任务包不包含教材扫描页或答案页。模拟器、观测数据、基线、参考解、反馈和评分代码均为本项目编写；教材仅作为物理模型和选题来源。


===== checks/tm-02-sources.md =====
# tm-02 来源与改造

核对日期：2026-11-16。

## 教材依据

鞠国兴，《理论力学学习指导与习题解析（理科用）（第二版）》，科学出版社，2018，第 4 章“有心力”。源文件由用户提供：`/Users/ai4s/Downloads/理论力学学习指导与习题解析(理科用)(第二版)-鞠国兴.pdf`。

已渲染并目视核对 PDF 第 237–239 页，对应书内第 228–230 页：

- 第 228 页：中心力的角动量守恒、平面运动、能量方程与轨迹积分。
- 第 229 页：拱点方程 (4.7)、完整径向周期的方位角增量 (4.8)、有界轨道与闭合轨道的区别、旋进图 4-2。
- 第 230 页：有效势定义 (4.9)、径向一维化能量方程 (4.10)。

本题依据这些中心力理论重新设计，不声称是教材某个编号习题的原样转录。教材扫描页和答案页不放进题包。

## 本题设计

选择 \(V=-1/r+\alpha/r^2+\beta r^2\) 为可控的非开普勒经典中心势。输入包含八组有限幅束缚轨道，统一要求恢复两拱点、径向周期、完整方位角与有符号进动。它考查有效势、转折点分支、奇性处理和可观测量计算，区别于 tm-01 的含噪局部观测参数反演。

完整解用正则化求积，验证值用独立运动方程积分；近圆小振动近似作为合理基线。八个工况共同覆盖同一个物理问题，不作为独立题数累加。

## 复用与新增工作

中心力理论、近圆近似、Gauss–Legendre 求积、DOP853 都是既有方法。项目编写题面、固定工况、反馈、参考/基线与评分代码，并将连续轨道可观测量封装为 Harbor 任务。NumPy/SciPy 为数值依赖，其名称与版本在环境中固定；未复制外部题库的题面或答案代码。

整套科学编程评测与 SciCode 的比较见 [tm-01 来源记录](tm-01-sources.md)。本题新增的检验对象是非线性中心势轨道的完整动力学量，提交的是固定实例结果，验证器按独立 ODE 计算结果计连续误差。


===== checks/tm-03-sources.md =====
# tm-03 来源与贡献

用户原件：`/Users/ai4s/Downloads/理论力学学习指导与习题解析(理科用)(第二版)-鞠国兴.pdf`。

- PDF375–377，书366–368，式6.46–6.55：重对称刚体的拉格朗日函数、角动量和能量积分、有效势、运动图像及规则进动。
- PDF438–440，书429–431，题6.32：竖直向上自转、规则进动二次方程、有效势二阶导数与高速稳定阈值。

六页已逐页渲染并实际查看，保存于 `checks/tm-03-source-pages/`。OCR用于检索定位，方程约定以原页核对为准。

本组扩展：从教材完整运动积分出发构造公开的六条非线性轨道及四个边界自转工况，要求转向角、完整周期、带符号累计相位、进动类型、分离轨道及线性稳定频率。实现参考三次根积分、独立65位角度势积分、起点反馈和量化评分。多个工况合为一道题，不重复计题。

独立性：tm-01是弹簧链参数辨识；tm-02是中心力平面轨道；tm-03是三维刚体姿态约化及极点临界分支，物理系统、边界约束、输入和输出均不同。


===== checks/tm-04-sources.md =====
# 来源与原创改造

《理论力学学习指导与习题解析》第二版，第6章6.1.4无力矩刚体及稳定性，PDF372–375页／书页363–366。非对称初值、近分离轨道和固定时刻预测为原创扩展。

所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。

TM03为有重力矩的轴对称陀螺，本题无力矩、三主惯量不同及中间轴非线性翻转。

参考解自适应DOP853；真值独立固定步RK4、步长加倍及Richardson外推，另验能量和角动量模长。


===== checks/tm-05-sources.md =====
# 来源与原创改造

《理论力学学习指导与习题解析》第二版，习题6.17，PDF409–413页／书页400–404；分布式摩擦、椭圆积分及滑动自转耦合。终止截面、耗散证书和不同惯量系数为原创扩展。

所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。

无保守势和周期轨道，研究分布摩擦导致的平移转动耦合及接触积分奇性。

参考解椭圆积分阻力+log(s)独立变量；真值直接接触角积分+时间域v/s ODE，并独立核对耗散与机械能差。


===== provenance/qft-13.md =====
# qft-13 来源与改造

François Gelis, Problems in Quantum Field Theory, PDF 294–300，书页123–129，题29。

原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。

题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH13；私有JSON由Linux检查工具生成，评分时不执行oracle。


===== provenance/qft-14.md =====
# qft-14 来源与改造

François Gelis, Problems in Quantum Field Theory, PDF322–325，书页151–154，题37。

原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。

题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH14；私有JSON由Linux检查工具生成，评分时不执行oracle。


===== provenance/qft-15.md =====
# qft-15 来源与改造

François Gelis, Problems in Quantum Field Theory, PDF342–346，书页171–175，题42。

原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。

题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH15；私有JSON由Linux检查工具生成，评分时不执行oracle。


===== provenance/qft-16.md =====
# qft-16 来源与改造

François Gelis, Problems in Quantum Field Theory, PDF346–354，书页175–183，题43。

原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。

题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH16；私有JSON由Linux检查工具生成，评分时不执行oracle。


===== provenance/qft-17.md =====
# qft-17 来源与改造

François Gelis, Problems in Quantum Field Theory, PDF368–370，书页197–199，题49；明确的径向ansatz为本题扩展。

原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。

题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH17；私有JSON由Linux检查工具生成，评分时不执行oracle。


===== provenance/qft-18.md =====
# qft-18 来源与改造

François Gelis, Problems in Quantum Field Theory, PDF93–94，书页215–216，题52。

原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。

题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH18；私有JSON由Linux检查工具生成，评分时不执行oracle。


===== provenance/qft-19.md =====
# qft-19 来源与改造

François Gelis, Problems in Quantum Field Theory, PDF139–145，书页261–267，题67。

原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。

题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH19；私有JSON由Linux检查工具生成，评分时不执行oracle。

checks_total 880
requirements ['numpy==2.1.3\n', 'numpy==2.1.3\nscipy==1.14.1\n', 'numpy==2.1.3\nscipy==1.14.1\nmpmath==1.3.0\n']

exit_code=0
```

### 2026-11-16T22:53:18.362232+08:00

```bash
python3 -
```

```text
task metrics: [('ed-01', 'continuous', 'minimize', '百分点', 14, {}), ('ed-02', 'continuous', 'minimize', '百分点', 15, {}), ('ed-03', 'continuous', 'minimize', '百分点', 16, {}), ('ed-04', 'continuous', 'minimize', '百分点', 14, {}), ('ed-05', 'continuous', 'minimize', '百分点', 17, {}), ('gr-01', 'continuous', 'minimize', '百分点', 14, {}), ('gr-02', 'continuous', 'minimize', '百分点', 15, {}), ('gr-03', 'continuous', 'minimize', '百分点', 14, {}), ('gr-04', 'continuous', 'minimize', '百分点', 14, {}), ('gr-05', 'continuous', 'minimize', '百分点', 15, {}), ('qft-01', 'continuous', 'minimize', '百分点', 15, {}), ('qft-02', 'continuous', 'minimize', '百分点', 13, {}), ('qft-03', 'continuous', 'minimize', '百分点', 15, {}), ('qft-04', 'continuous', 'minimize', '百分点', 20, {}), ('qft-05', 'continuous', 'minimize', '百分点', 22, {'baseline_seconds': 0.28784345799999755, 'reference_seconds': 0.3174480840000342}), ('qft-06', 'continuous', 'minimize', '百分点', 19, {}), ('qft-07', 'continuous', 'minimize', '百分点', 19, {}), ('qft-08', 'continuous', 'minimize', '百分点', 19, {}), ('qft-09', 'continuous', 'minimize', '百分点', 19, {}), ('qft-10', 'continuous', 'minimize', '百分点', 20, {}), ('qft-11', 'continuous', 'minimize', '百分点', 19, {}), ('qft-12', 'continuous', 'minimize', '百分点', 20, {}), ('qft-13', 'continuous', 'minimize', '百分点', 18, {}), ('qft-14', 'continuous', 'minimize', '百分点', 15, {}), ('qft-15', 'continuous', 'minimize', '百分点', 17, {}), ('qft-16', 'continuous', 'minimize', '百分点', 17, {}), ('qft-17', 'continuous', 'minimize', '百分点', 18, {}), ('qft-18', 'continuous', 'minimize', '百分点', 18, {}), ('qft-19', 'continuous', 'minimize', '百分点', 17, {}), ('qft-20', 'continuous', 'minimize', '百分点', 23, {}), ('qft-21', 'continuous', 'minimize', '百分点', 23, {}), ('qft-22', 'continuous', 'minimize', '百分点', 23, {}), ('qft-23', 'continuous', 'minimize', '百分点', 23, {}), ('qft-24', 'continuous', 'minimize', '百分点', 23, {}), ('qft-25', 'continuous', 'minimize', '百分点', 24, {}), ('qm-01', 'continuous', 'minimize', '百分点', 11, {}), ('qm-02', 'continuous', 'minimize', '百分点', 14, {}), ('qm-03', 'continuous', 'minimize', '百分点', 16, {}), ('qm-04', 'continuous', 'minimize', '百分点', 22, {'baseline_seconds': 0.31581408299985014, 'reference_seconds': 0.18836354199993366}), ('qm-05', 'continuous', 'minimize', '百分点', 22, {'baseline_seconds': 0.23797066700012692, 'reference_seconds': 1.5552961260000302}), ('sp-01', 'continuous', 'minimize', '百分点', 13, {}), ('sp-02', 'continuous', 'minimize', '百分点', 17, {}), ('sp-03', 'continuous', 'minimize', '百分点', 17, {}), ('sp-04', 'continuous', 'minimize', '百分点', 17, {}), ('sp-05', 'continuous', 'minimize', '百分点', 19, {}), ('tm-01', 'continuous', 'minimize', '百分点', 11, {}), ('tm-02', 'continuous', 'minimize', '百分点', 11, {}), ('tm-03', 'continuous', 'minimize', '百分点', 19, {}), ('tm-04', 'continuous', 'minimize', '百分点', 22, {'baseline_seconds': 0.26468975000011596, 'reference_seconds': 0.3069809169999189}), ('tm-05', 'continuous', 'minimize', '百分点', 22, {'baseline_seconds': 0.4012286249999306, 'reference_seconds': 0.2905974169998444})]

===== checks/qft-24-sources.md =====
# QFT-24：完整差分碰撞核下的 LPM 响应与近似选择


来源：François Gelis, *Problems in Quantum Field Theory*, 第75题；用户PDF实际页183–190，书页305–312。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与明确调节模型

Gelis 第75题的物理核心是形成时间内多次软散射同阶，必须保留碰撞算子的差分结构。本任务要求求解其**公开有限周期横动量调节模型**，比较完整核、一次碰撞和扩散近似。它是可独立复现的受控 LPM 响应题；不把有限方形网格伪称连续旋转对称模型，也不要求从此网格宣称普适软频率指数。

取 Debye 动量单位1。每个 `cases` 指定奇数网格边长 \(M\)、间距 \(h\)，点 \(p_{ij}=h(i-M//2,j-M//2)\)，\(0\le i,j<M\)。动量差采用最短周期代表 \(r_\mu\in\{-M//2,\ldots,M//2\}\)。定义全部非零转移的权重
\[
 K_r=\frac{h^2}{(2\pi)^2}\frac1{\ell_r^2(\ell_r^2+1)},\quad \ell_r=h r,\quad K_0=0,
\qquad (Cf)_p=\sum_rK_r(f_p-f_{p-r}).
\]
`p-r` 逐坐标模 \(M\)；该有限差分核就是本题精确模型，不再插值到无穷平面或另加核截断。零转移项的差分严格为0，不能把增益和损失分成两个 IR 发散积分后独立正则化。

令 \(D_p=a(m^2+p^2)\)、\(s_p=p_x\exp[-p^2/(2w^2)]\)，其中 `a,mass,source_width` 分别为 \(a,m,w\)。求唯一复响应
\[
 (C+iD)f=s.
\]
它采用正定耗散碰撞算子和 \(a>0\) 的因果相位约定。发射泛函 \(R=h^2\sum_ps_p\operatorname{Re}f_p\)。这里的源含 Gaussian 接受窗，以保证该有限基准不受紫外源尾污染；这是本项目明确的受控扩展，不归称原书已经给出的全部光子发射率。

定义一次碰撞 Bethe–Heitler 起点：\(g=s/D\)、\(f_{BH}=-ig+D^{-1}Cg\)，\(R_{BH}=h^2\sum_pg_p(Cg)_p\)。它在碰撞相对 \(D\) 较弱时适用，不能在全部输入上直接等同完整 \(R\)。

另一个比较是二阶矩扩散核：\(d=\tfrac14\sum_rK_r\ell_r^2\)，\(C_{diff}=d(-\Delta_h)\)，其中周期五点 \(-\Delta_h f=(4f-f_{+x}-f_{-x}-f_{+y}-f_{-y})/h^2\)。解 \((C_{diff}+iD)f_{diff}=s\) 得 \(R_{diff}\)。这是对同一有限核的扩散近似，不能把它的数值当完整核真值；正号来自 \(\langle f,Cf\rangle\ge0\)。

## 必须交付

每个 case 一行 `values`：
`[R,R_BH,R/R_BH,R_diff,relative_error_diff,BH_usable,diffusion_usable,Re f_probe1,Im f_probe1,...]`。

`relative_error_diff=|R_diff-R|/R`；`BH_usable=1` 当 \(|R_{BH}-R|/R\le\)`approximation_target`，否则0；`diffusion_usable` 同理。`probes` 中索引是明确的0基网格索引，不是动量坐标。每对探针实虚部按公开顺序输出。

需要使用完整核确定发射响应与近似适用区。所有核/源/边界均公开，直接稠密线性求解、FFT、Krylov 或其他收敛方法均可。参考解使用 FFT 使碰撞卷积对角化；独立真值由显式转移矩阵构造并求解，另核查实块线性系统和正性。


## 验证路线

由对称非负K，`<f,Cf>=1/2 sum_(p,r) K_r |f_p-f_(p-r)|²>=0`。因此碰撞核扩散展开应为正的-d Laplacian；不能直接复制书中Taylor行疑似反号。

参考解使用离散Fourier变换，使C的本征值为sum K - FFT(K)。势D在动量空间是对角的，使用预条件GMRES求完整复线性系统。BH项由Neumann展开 `(C+iD)^(-1)` 到一次碰撞得到，发射率为正二次型g.C.g。扩散比较用同一核二阶矩、周期五点负Laplacian，完整核真值从不替换成扩散核。

独立真值显式计算任意两动量点间的周期转移权重，构造稠密矩阵C，再用直接复求解与2n实块求解互查，并检查全部C本征值非负。公开网格就是规定模型；改成更细网格会改变题目，不用这种变化伪称连续收敛。有限调节的连续外推及原书软频率普适标度不是本题交付项。

基线是公式明确的一次碰撞BH解，仍计算扩散比较，但用BH作为完整响应；强相干工况有明显抑制。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。


===== checks/qft-25-sources.md =====
# QFT-25：标量强场产对、相干脉冲与玻色统计


来源：François Gelis, *Problems in Quantum Field Theory*, 第80题；用户PDF实际页209–217，书页331–339。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与约定

Gelis 第80题是**复标量 QED**的外场产对。自然单位，\(e=1\)、`mass=m`。外场空间均匀，temporal gauge \(A_0=0\)，仅 \(A_z(t)\ne0\)，电场 \(E_z=-\dot A_z\)。经典外场预先给定，不含反作用、自相互作用、光子环或费米子 Pauli 阻塞。

`backgrounds` 定义
\[
A_z(t)=A_{shift}+A_{offset}+\sum_j a_j\tanh[(t-t_j)/\tau_j],
\qquad -T\le t\le T.
\]
`pulses` 每项 `[a,center,tau]`；`offset` 是物理上对齐孤立脉冲与双脉冲相应阶段的常势，`shift` 是与canonical动量一起改变的规范平移，两者不能混用。使用输入给定有限 \(T\) 处的频率作为精确初末频率约定。对于每个 `modes`，规范未平移时 canonical \(k_z\) 就是公开 `kz`；背景含 `shift` 时必须同时取 \(k_z=\)`kz-shift`，这样 \(k_z+A_z\) 不变。`kperp` 是横动量模长。

模方程与初值为
\[
\ddot u+[m^2+k_\perp^2+(k_z+A_z(t))^2]u=0,
\qquad u(-T)=\frac1{\sqrt{2\omega_{in}}},\quad
\dot u(-T)=-i\sqrt{\omega_{in}/2}.
\]
在 \(+T\) 用正负频模分解，数目 \(n_k=|\beta_k|^2\)，满足玻色归一化 \(|\alpha_k|^2-|\beta_k|^2=1\)。评分只比较不变量，不把相位约定不同的裸 \(\alpha,\beta\) 判错。要求同时报告末态 kinetic 纵动量 \(p_{z,out}=k_z+A_z(T)\)。

每个离散输入 mode **恰好代表一个独立 canonical 模对**（正粒子 \(k\) 与负粒子 \(-k\)）；即使列表含 \(k_z\) 正负两种数值，它们是不同的模对，不额外乘二或再除二。每模产对数服从几何分布，而非 Poisson。对有限模集，计算总产对数均值 \(\mu\)、方差 \(v\)、\(\log P_0\) 及总粒子—反粒子数协方差 \(c_{+-}\)。不要混淆“总对数”与“粒子加反粒子总数”。

## 必须交付

每个 `背景ID-modeID` 行，`values=[n_k,abs_alpha_squared,pz_out]`。
每个 `背景ID-statistics` 行，`values=[mean_pairs,variance_pairs,log_vacuum_survival,cov_particle_antiparticle]`。

`first` 和 `second` 分别是孤立的正/负 Sauter 阶跃背景，`offset=1.2` 使其渐近常势分别为0→2.4、2.4→0，与 `double` 对应的两个阶段对齐；`double` 是两阶跃相干组合，`gauge-shifted` 是同一 double 的残余规范平移。对于每个 `interference-modeID` 行，报告
\[
 [n_{double}/\max(n_{first}+n_{second},\epsilon),\quad
 |n_{double}-n_{first}-n_{second}|/\max(n_{first}+n_{second},\epsilon)],
\]
其中 \(\epsilon=\)`occupation_floor`。两个孤立背景按同一 canonical 参考动量、已经对齐的渐近常势比较；分母是逐脉冲占据数的非相干相加预测，不包含相位干涉或玻色刺激项，不允许另行平移动量后重新定义分母。

任务包含频率变化、双脉冲相位干涉、规范平移和玻色统计。仅用常场率或把两次产对概率相加不能完成全部输出。公开容差对极小占据数采用绝对尺度，不按无意义的极小谱尾相对精度扣分。


## 验证路线

参考解积分二阶复KG方程，在末端按固定频率投影：beta=sqrt(omega_out/2)(u+udot/(i omega_out))，alpha采用相反号，比较模长。独立真值使用一阶绝热Bogoliubov系统：theta'=omega，alpha'=q exp(2i theta) beta，beta'=q exp(-2i theta) alpha，q=omega'/(2omega)。它不调用二阶参考函数；两个孤立Sauter背景另与解析谱核验。

对offset+a*tanh((t-center)/tau)，解析n=[cosh(2pi sqrt((a tau)²-1/4))+cosh(pi tau(omega_out-omega_in))]/[2 sinh(pi tau omega_in)sinh(pi tau omega_out)]，omega_in/out均使用已给offset和正确渐近kinetic动量。有限T尾误差已小于公开绝对容差。数值Wronskian残差独立核查。

每模两模压缩真空给几何对数分布：均值n，方差n(1+n)，P0=1/(1+n)。独立模相乘故log P0=-sum log(1+n)，总粒子与反粒子数相同，协方差等于对数方差。基线是一次绝热/Born混合并以Poisson作稀薄近似，具有明确适用层次；对双脉冲与增强占据数需改进。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。


===== checks/qft-06-sources.md =====
# 来源与本地改造

Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.8。

PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db

页码（PDF / 印刷）: [{"pdf": [65, 65], "printed": [63, 63], "role": "题面"}, {"pdf": [219, 220], "printed": [221, 222], "role": "解答"}]

原书工作：移位后的两标量模型中枚举五类一圈贡献，含真空tadpole，用同一正则化和真空条件证明Σπ(0)=0。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。


===== checks/ed-03-sources-and-fairness.md =====
# ed-03 来源、改造与公平性

用户Jackson《经典电动力学》§8.10，原PDF406-412页OCR已读；关键原页409-411（书404-406）真实渲染并视觉核对。PNG保存于checks/ed-03-source-pages/guide-409.png至411.png。式8.117-8.120给TE₀ₙ径向场、界面条件及u²+w²关系；8.121给j₀₁截止；8.122给TM的ε₀/ε₁边界系数。原书图8.11说明求根分支，图8.12说明径向场约束。

本组将原书单一波导定性讨论改造成六工况的完整模谱与功率研究：覆盖低于截止、刚过第一截止、远离截止、多径向模以及低折射率对比，比较TE/TM并计算几何色散和芯层能流比例。全部输入工况公开，六工况只计一道题。严格限定轴对称，不把结论扩展到一般混合模。

与ed-01静电核壳边值、ed-02规定电流天线远场相干反演不同，本题求无源界面导波本征模、指数尾、截止和频率导数，研究对象与计算问题独立。

Agent只见environment/public中的材料、起点、反馈和登记指标。参考解和私有真值分别在solution与tests，Docker COPY仅public。独立真值求解器不导入参考模块。固定实例全部材料均可用于计算；私有数据仅保存独立验证标签，不假称是留出泛化样本。基线为有物理意义的强约束近似，同资源同公开材料。最终评分公开全部权重，允许等价方法和模式重排。

每题外部benchmark比对仍由主代理在题集冻结前统一补齐，这里只记录已核对的原教材出处和题集内部独立性。


===== checks/gr-04-sources-and-fairness.md =====
# gr-04 来源与公平性

来源：用户提供梁灿彬、周彬《微分几何入门与广义相对论》中册。PDF145/书133式13-4-9至13-4-13为ZAMO标架；PDF147/书135为Penrose四动量守恒及13-5-3视界角速度；PDF148/书136式13-5-5是未来视界条件。三页已实际渲染并目视核对；PDF146也保留渲染文件。教材讨论的不可减质量和极端黑洞整体可提取比例不等于本题一次分裂效率，本题没有混用。

新增任务是固定母粒子局部速度、赤道面两光子分裂的有限方向网格，要求局域能量、全局径向拓扑、负能捕获和逃逸效率共同正确。不是把同一题换五个参数算作五题。与gr-01区别在旋转时空局部标架和Penrose守恒量，而非Schwarzschild散射角反演。

题面公开物理模型、号差、单位、boost轴定义、径向势、角度规则、两束顺序、汇总定义、固定评分尺度和资源。公开反馈只给守恒与未来性，不泄漏正确逃逸标签。冻结真值、参考解与开发答案位于非环境目录；Dockerfile仅复制public材料。

基线保留精确局部运动学，只省略全局转折，属于有意义的局部近似，不用随机输出制造分差。连续指标让只错一部分负能或标签的答案获得相应部分分。参考与独立真值采用不同线性代数表达及根算法，避免仅以同一个函数自证。

全部计算只用本地CPU。未使用远程GPU、未触碰推理项目、未推送GitHub；未读取或打包无关凭据。参考开发分数不冒充被测Codex表现。

baseline wrappers: [('ed-01', True), ('ed-02', True), ('ed-03', True), ('ed-04', True), ('ed-05', True), ('gr-01', True), ('gr-02', True), ('gr-03', True), ('gr-04', True), ('gr-05', True), ('qft-01', True), ('qft-02', True), ('qft-03', True), ('qft-04', True), ('qft-05', True), ('qft-06', True), ('qft-07', True), ('qft-08', True), ('qft-09', True), ('qft-10', True), ('qft-11', True), ('qft-12', True), ('qft-13', True), ('qft-14', True), ('qft-15', True), ('qft-16', True), ('qft-17', True), ('qft-18', True), ('qft-19', True), ('qft-20', True), ('qft-21', True), ('qft-22', True), ('qft-23', True), ('qft-24', True), ('qft-25', True), ('qm-01', True), ('qm-02', True), ('qm-03', True), ('qm-04', True), ('qm-05', True), ('sp-01', True), ('sp-02', True), ('sp-03', True), ('sp-04', True), ('sp-05', True), ('tm-01', True), ('tm-02', True), ('tm-03', True), ('tm-04', True), ('tm-05', True)]

exit_code=0
```

### 2026-11-16T22:53:42.919850+08:00

```bash
cat tasks/qft-06/environment/Dockerfile tasks/qft-20/environment/Dockerfile
```

```text

### 2026-11-16T22:53:42.919850+08:00

```bash
rg -n 'add_argument|baseline|solve.py' tasks/qft-06/solution/solve.py tasks/qft-06/solution/baseline.py tasks/qft-13/solution/solve.py tasks/tm-01/solution/baseline.py
```

```text
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2

COPY requirements.txt /tmp/requirements.txt
RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
 && useradd --uid 1000 --create-home student \
 && mkdir -p /app/data /app/output \
 && chown -R student:student /app

COPY public/ /app/data/
WORKDIR /app
USER student
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2

COPY requirements.txt /tmp/requirements.txt
RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
 && useradd --uid 1000 --create-home student \
 && mkdir -p /app/data /app/output \
 && chown -R student:student /app

COPY public/ /app/data/
WORKDIR /app
USER student

exit_code=0
```
tasks/qft-06/solution/baseline.py:3:sys.argv.append('--baseline')
tasks/qft-13/solution/solve.py:34:def solve(model,baseline=False):
tasks/qft-13/solution/solve.py:38:        m=moments(a,b,6 if baseline else 12000)[:4]
tasks/qft-13/solution/solve.py:52:    p=argparse.ArgumentParser();p.add_argument('--data-root',default='/app/data');p.add_argument('--output',default='/app/output/answer.json');p.add_argument('--baseline',action='store_true');a=p.parse_args();model=json.loads((Path(a.data_root)/'model.json').read_text());answer=solve(model,a.baseline);path=Path(a.output);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n')
tasks/tm-01/solution/baseline.py:16:    parser.add_argument("--data-root", type=Path, default=Path("/app/data"))
tasks/tm-01/solution/baseline.py:17:    parser.add_argument("--output", type=Path, default=Path("/app/output/answer.json"))
tasks/qft-06/solution/solve.py:4:def solve(model,baseline=False):
tasks/qft-06/solution/solve.py:5:    n=6 if baseline else 120;x,w=leggauss(n);x=(x+1)/2;w=w/2
tasks/qft-06/solution/solve.py:16:    p=argparse.ArgumentParser();p.add_argument('--data-root',default='/app/data');p.add_argument('--output',default='/app/output/answer.json');p.add_argument('--baseline',action='store_true');args=p.parse_args()
tasks/qft-06/solution/solve.py:17:    model=json.loads((Path(args.data_root)/'model.json').read_text());answer=solve(model,baseline=args.baseline)

exit_code=0
```

### 2026-11-16T22:54:02.761184+08:00

```bash
rg -n -C 3 'uv tool|pip install|Harbor|harbor==|Python' '../../00-老师原始材料/科研探索课程项目/附件一_Benchmark制作与提交指南.md'
```

```text
9-| 出题小组 | 选择研究问题，准备题面、材料、参考解和评分程序 |
10-| Codex（Agent） | 阅读公开材料，探索并提交解答 |
11-| 评分程序（verifier） | 作答结束后独立检查实际产物，计算本题指标 |
12:| Harbor | 为每次作答建立运行环境，作答结束后启动评分程序 |
13-| 助教 | 复核题目与评分，在独立环境中重新测评 |
14-
15-<a id="topic"></a>
--
112-
113-### 把评价办法写进评分程序
114-
115:在`tests/score.py`的`evaluate()`中读取或运行实际产物，重算主指标，并输出支持判分的明细。模板随后调用统一的`quality_score.py`，生成`metrics.json`和`reward.txt`。两者方向相反：Harbor的reward越高，表示解答越好；课程计分用`metrics.json`中的原始指标计算难度系数，Codex越难做好，单题得分越高。
116-
117-候选产物违反题意时，返回无效产物及具体原因；评分器本身出错时保留异常供排查。
118-
--
166-
167-### 先跑通参考解与空提交
168-
169:在Linux主机准备Python 3.12及以上、uv和Docker。确认`python3 --version`为所需版本，启动Docker后运行以下命令（将路径替换为实际绝对路径）：
170-
171-```bash
172-cd /absolute/path/group-XX
173:uv tool install 'harbor==0.24.0'
174-harbor run -p "$PWD/tasks" -a oracle \
175-  --n-attempts 1 --n-concurrent 1 --max-retries 0 \
176-  --jobs-dir "$PWD/runs/reference"
--
179-  --jobs-dir "$PWD/runs/empty"
180-```
181-
182:`oracle` 逐题执行 `solution/solve.sh`，`nop` 检查空提交。第一次运行建议只选一题（`-p`改为该题目录并换新运行目录），打开评分记录中的 `metrics.json` 与 `reward.txt`，对照一个具体产物追踪“输入材料 → 输出 → 原始指标 → Harbor评分”。
183-
184-### 检查评分是否反映真实质量
185-
--
239-| `config` | 学生为 `codex`；助教为 `ta_codex` |
240-| `run` | 每题恰好1、2、3 |
241-| `raw_metric` | 评分器计算的原始值，缺少时填null |
242:| `score` | 由原始指标换算的Harbor解答表现，越好越高 |
243-| `seconds` | Agent执行与verifier耗时之和 |
244-| `trial_dir` | 指向 `runs/` 下原始运行目录的相对路径 |
245:| `status` | `completed`、`invalid`（无效产物）、`agent_error`、`timeout`；后三种Harbor解答表现为0 |
246-
247-所有题run=1的耗时之和为第1轮累计，各轮≤43200秒。助教结果写入`ta_results.csv`和`runs/ta-codex/`。
248-
--
256-- [RE-Bench](https://arxiv.org/html/2411.15114)：公开起点、探索评估与最终测试。
257-- [MLE-bench](https://arxiv.org/html/2410.07095v1)：题目、数据、提交与最终评价。
258-- [PaperBench](https://arxiv.org/html/2504.01848v1)：提交后在新环境中独立复现。
259:- [Harbor评分器文档](https://docs.harborframework.com/tasks/verifier)：评分入口和reward，课程使用0.24.0。

exit_code=0
```

### 2026-11-16T22:59:11.649380+08:00

```bash
python3 -
```

```text
ed-01
checks/ed-01-sources.md 核对日期：2026-11-16。
用户文件 `/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf`，第 4.4 节“带有电介质的边值问题”，已渲染并目视核对 PDF 第 168–173 页，对应书内第 163–168 页。
- PDF 168–170：两介质界面的点电荷问题、电势和法向位移连续条件。
ed-02
checks/ed-02-sources.md 用户提供 `/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf`，§9.4“中央馈电的平直天线”。原PDF第448页，书内443页，式(9.53)给出两臂对称的正弦规定电流；式(9.54)-(9.55)是远场电流积分与闭式矢势；式(9.56)是精确于该规定电流模型的角分布。第449页，书内444页，式(9.57)列出kd=π、2π的半波/全波极限，并解释全波由两个同相半波场相干叠加而形成更尖锐的角分布。
这两页已真实渲染并视觉查看，PNG在 `checks/ed-02-source-pages/antenna-448.png`、`antenna-449.png`。题包不附整本教材扫描内容。OCR读取过第446-450、498-500页，实际选题最终以448-449页为依据；早先考虑Mie散射的方向未被采用，不把未实现内容写成成果。
同一节下一段明确说明正弦电流只是假定，真实有限半径天线须作为复杂边值问题处理。本题因此明确约束为规定电流的理想细天线，不主张反演真实天线馈电阻抗或电流自洽性。
ed-03
checks/ed-03-sources-and-fairness.md 用户Jackson《经典电动力学》§8.10，原PDF406-412页OCR已读；关键原页409-411（书404-406）真实渲染并视觉核对。PNG保存于checks/ed-03-source-pages/guide-409.png至411.png。式8.117-8.120给TE₀ₙ径向场、界面条件及u²+w²关系；8.121给j₀₁截止；8.122给TM的ε₀/ε₁边界系数。原书图8.11说明求根分支，图8.12说明径向场约束。
本组将原书单一波导定性讨论改造成六工况的完整模谱与功率研究：覆盖低于截止、刚过第一截止、远离截止、多径向模以及低折射率对比，比较TE/TM并计算几何色散和芯层能流比例。全部输入工况公开，六工况只计一道题。严格限定轴对称，不把结论扩展到一般混合模。
与ed-01静电核壳边值、ed-02规定电流天线远场相干反演不同，本题求无源界面导波本征模、指数尾、截止和频率导数，研究对象与计算问题独立。
ed-04
checks/ed-04-sources.md 用户 Jackson《经典电动力学》§14.3 原PDF765-768页（书235-238）已真实渲染，其中765、766、768页已视觉核对，PNG在 `checks/ed-04-source-pages/radiation-765.png`、`radiation-766.png`、`radiation-768.png`。式(14.35)-(14.38)说明观测通量与源时间的 Jacobian；式(14.39)-(14.41)给平行加速的前向束射和半功率角；式(14.44)-(14.46)给横向加速及总功率。题面固定源时间约定，不混淆两种功率定义。
本题把原书正向角分布改造成七工况的积分研究：恢复总功率、前向分位角、\(1/\gamma\)锥内能量和辐射动量。与ed-01静电球、ed-02细直天线、ed-03介质波导的边界/模式问题不同。本题所有工况属于一个统一的相对论辐射积分任务，不拆题。
公开材料包括全部 \(\beta,\chi\)、源时间公式、反馈和评分权重；参考与65位真值不进入Agent环境。基线是物理正确但未解析尖峰的固定角度求积，未人为改错物理。外部benchmark相似性检索由主代理统一补齐。
ed-05
checks/ed-05-sources-and-fairness.md 用户提供的 `/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf`，§16.9“球体对电磁波的散射”。本题关键原始扫描页为PDF第897-899页（书内第367-369页），三页均已用Poppler渲染并逐页视觉核对，图像保存在 `checks/ed-05-source-pages/jackson-897.png` 至 `jackson-899.png`。
- 书367页，式(16.151)定义两类散射相移；式(16.152)给理想导体球的球Bessel/Neumann函数比值。
- 书368页，式(16.155)-(16.158)从电、磁偶极展开推导低频角分布，明确线性干涉项引起前后不对称。
gr-01
checks/gr-01-sources-and-fairness.md 原始文件：`/Users/ai4s/Downloads/微分几何入门与广义相对论 上 (梁灿彬) (z-lib.org).pdf`，457 页。
| 位置 | 核对内容 | 核对方式 |
|---|---|---|
gr-02
checks/gr-02-sources-and-fairness.md 来源为用户提供的 `/Users/ai4s/Downloads/微分几何入门与广义相对论 上 (梁灿彬) (z-lib.org).pdf`。
| 原 PDF 位置 | 书内位置 | 依据与核对方式 |
|---|---|---|
gr-03
checks/gr-03-sources-and-fairness.md 来源：用户 `/Users/ai4s/Downloads/微分几何入门与广义相对论 上 (梁灿彬) (z-lib.org).pdf`。实际 OCR 读取 PDF326–327、331–333；实际渲染并目视核对 PDF327 和332，分别对应书内312和317页。式(9-1-5)–(9-1-6)给出角动量及径向方程，式(9-2-13)–(9-2-15)明确类时条件和相对论修正。原图保存在 `checks/gr-03-source-pages/`。
本题是有源可查的模型计算和仪器参数反演，不照搬教材弱场近日点近似。新增了未知质量/径向零点、完整圆轨道分支、ISCO 合并和双时间稳定性。全部角动量工况只算一道题。与 gr-01 的无界类光散射不同，本题是有静质量圆平衡、局部稳定性和分支分岔；没有复制其散射积分、捕获、绕行或反向冲量任务。与 tm-02 的经典束缚轨道周期/进动也不同，本题不评分周期积分，而评分平衡根完整性与扰动谱。
模拟观测为确定性生成，14位有效数字舍入，无随机噪声，未伪装成真实天文数据。生成常数记录在 `checks/gr-03-observation-generation.json`；真实评价目标是规定拟合在公开已舍入数据上的极小值。真值重新拟合，不回填生成参数。
gr-04
checks/gr-04-sources-and-fairness.md 来源：用户提供梁灿彬、周彬《微分几何入门与广义相对论》中册。PDF145/书133式13-4-9至13-4-13为ZAMO标架；PDF147/书135为Penrose四动量守恒及13-5-3视界角速度；PDF148/书136式13-5-5是未来视界条件。三页已实际渲染并目视核对；PDF146也保留渲染文件。教材讨论的不可减质量和极端黑洞整体可提取比例不等于本题一次分裂效率，本题没有混用。
新增任务是固定母粒子局部速度、赤道面两光子分裂的有限方向网格，要求局域能量、全局径向拓扑、负能捕获和逃逸效率共同正确。不是把同一题换五个参数算作五题。与gr-01区别在旋转时空局部标架和Penrose守恒量，而非Schwarzschild散射角反演。
题面公开物理模型、号差、单位、boost轴定义、径向势、角度规则、两束顺序、汇总定义、固定评分尺度和资源。公开反馈只给守恒与未来性，不泄漏正确逃逸标签。冻结真值、参考解与开发答案位于非环境目录；Dockerfile仅复制public材料。
gr-05
checks/gr-05-sources-and-fairness.md 用户提供梁灿彬、周彬《微分几何入门与广义相对论》中册，§14.5，PDF204/书192式14-5-9及14-5-10为真空3+1约束；PDF205/书193讨论约束保持。两页已用view_image实际目视；PDF203–207渲染文件存于本目录source-pages。教材讨论真空，此题通过Einstein方程的法向投影明确引入16πρ项，再指定共形源求解，未把新增的含源模型、临界数值或可计算任务伪称为教材原题答案。
来源页支持初值几何和约束结构；题面和参考推导独立给出共形标量曲率、Poisson边界条件、物质体元、球面平均曲率及根的完整性。C1紧支撑源不冒称无限光滑；本题只需经典径向约束和球面几何。K=0不等于整个时空静态，初始表观视界也不等于事件视界。
五个振幅是同一题的拓扑覆盖，不计作五道不同题；与gr01–04分别检验散射、宇宙学、圆轨道稳定性、Kerr分裂不同，本题检验Einstein初值约束与内禀几何。难点是物理密度/共形源、ADM/固有质量、极小曲面/面积极小、双根/无根等概念不能混同。
qft-01
checks/qft-01-sources.md 用户提供的《量子场论试题详解（凡人看得懂的量子场论 非211高校适用）》PDF。原 PDF 第 115、116 页（书内页码 107、108）推导一圈光子自能/真空极化：费曼参数合并电子传播子分母、平移圈动量、用维数正则化隔离极点，并将有限的费曼参数对数积分化为阈值以上的复对数；页 108 明确指出 (K<2m) 时转为反正切、对数是复函数且只剩 (1/\epsilon) 项发散。
这道任务抽取其中有限的非局域动量依赖积分，以零动量减除定义
\[
qft-02
checks/qft-02-sources.md 来源是用户提供的《量子场论试题详解》PDF 第 128--129 页（PDF 页 128--129，书内页码 120--121）：给出末态相空间 \(d\Phi_n\)、单位时空跃迁率、流因子和衰变宽度 \(d\Gamma=|\mathcal M|^2d\Phi_n/(2M)\)。公开 OCR 索引在 `planning/source-notes/qft-all.txt` 的 4876--4956 行；原页 PNG 在 `tmp/pdfs/qft02-source-128.png`、`qft02-source-129.png`。
题目把教材的相空间和衰变宽度公式改成可复核的三体标量研究：公开四组质量、复耦合、共振质量和宽度，要求积分、识别相干干涉并报告分位数。不同工况是同一研究任务的固定测试案例，不单独计题。
参考解采用端点平滑的自适应积分；私有真值采用高精度独立实现，不导入参考模块。基线是真实但分辨率有限的均匀梯形积分。Verifier 只读取候选 JSON 和私有真值，题面不泄露正确结果。
qft-03
checks/qft-03-sources.md 来源：用户提供的《量子场论试题详解》PDF 第 203--205 页（书内 195--197 页），视觉核对了一圈 QED/QCD β 函数、\(\beta_0=11-2n_f/3\)、重整化群方程的积分解及渐近自由讨论。OCR 对应 `planning/source-notes/qft-all.txt` 第 7579--7805 行；原页图保存在 `tmp/pdfs/qft03-source-203.png` 至 `205.png`。
题目把教材的连续流公式改造成跨阈值参数反演：全部观测能标和边界公开，私有真值仅保存独立的高精度秩/投影核对。`rg-02` 和 `rg-03` 有意设置秩亏，评分接受等价的可行参数化，避免把参考文字或某个任意代表元当作唯一答案。基线是真实的固定味数近似，不是故意错误格式。
qft-04
checks/qft-04-sources.md 来源是用户提供的《量子场论试题详解（凡人看得懂的量子场论 非211高校适用）》PDF 第 83--85 页，对应书内页码 75--77。已逐页渲染并目视核对：第 83 页有 Compton 散射的双图与关联函数；第 84 页给出坐标及动量空间传播子/顶点规则；第 85 页汇总光子、电子外线、电子传播子和顶点。原页图位于 `checks/qft-04-source-pages/compton-083.png`、`084.png`、`085.png`。
教材存在其自身的整体相位、图形记号与高亮注解。题面使用明确的标准 \(+---\) 度规、\(\bar uu=2\) 和两图振幅约定，避免把教材中间的相位/归一化讨论误作待猜条件。散射截面的 Lorentz 不变相空间和流因子另见 PDF 第 128--129 页；两页曾为 QFT-02 逐页渲染核对，图位于 `tmp/pdfs/qft02-source-128.png`、`129.png`。
教材给出的是 QED Feynman 规则和康普顿过程，不直接给本任务的七组 boost 窗口、分位数或振幅探针答案。本任务的窗口设计、恒能谱/空谱案例是基于同一理论的原创数值问题，不宣称扫描页含本任务完整答案。
qft-05
checks/qft-05-sources.md 《量子场论试题详解》第1.3.2.2节Gordon分解和顶角修正，PDF131–135页／书页123–127。原书随后在高能极限省略F2；本题保留其有限质量分子并求有限调节及类时阈值下的动量响应，属于原创扩展，不归称原书已给结果。
所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。
QFT01为二点真空极化，本题三点壳上顶角Pauli张量结构与有限IR调节；不重复散射或RG。
qft-06
checks/qft-06-sources.md Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.8。
PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db
页码（PDF / 印刷）: [{"pdf": [65, 65], "printed": [63, 63], "role": "题面"}, {"pdf": [219, 220], "printed": [221, 222], "role": "解答"}]
qft-07
checks/qft-07-sources.md Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.12。
PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db
页码（PDF / 印刷）: [{"pdf": [66, 66], "printed": [64, 64], "role": "题面"}, {"pdf": [225, 231], "printed": [227, 233], "role": "解答"}]
qft-08
checks/qft-08-sources.md Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.13。
PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db
页码（PDF / 印刷）: [{"pdf": [66, 66], "printed": [64, 64], "role": "题面"}, {"pdf": [231, 232], "printed": [233, 234], "role": "解答"}]
qft-09
checks/qft-09-sources.md François Gelis，*Problems in Quantum Field Theory*，原题 5。
PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5
页码（PDF / 印刷）: [{"pdf": [34, 40], "printed": [22, 28], "role": "完整题面与解答"}]
qft-10
checks/qft-10-sources.md François Gelis，*Problems in Quantum Field Theory*，原题 11。
PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5
页码（PDF / 印刷）: [{"pdf": [55, 61], "printed": [43, 49], "role": "完整题面与解答"}]
qft-11
checks/qft-11-sources.md François Gelis，*Problems in Quantum Field Theory*，原题 24,25。
PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5
页码（PDF / 印刷）: [{"pdf": [274, 277], "printed": [103, 106], "role": "24题完整题面与解答"}, {"pdf": [278, 281], "printed": [107, 110], "role": "25题完整题面与解答"}]
qft-12
checks/qft-12-sources.md François Gelis，*Problems in Quantum Field Theory*，原题 26。
PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5
页码（PDF / 印刷）: [{"pdf": [282, 285], "printed": [111, 114], "role": "完整题面与解答"}]
qft-13
provenance/qft-13.md François Gelis, Problems in Quantum Field Theory, PDF 294–300，书页123–129，题29。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。
题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH13；私有JSON由Linux检查工具生成，评分时不执行oracle。
qft-14
provenance/qft-14.md François Gelis, Problems in Quantum Field Theory, PDF322–325，书页151–154，题37。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。
题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH14；私有JSON由Linux检查工具生成，评分时不执行oracle。
qft-15
provenance/qft-15.md François Gelis, Problems in Quantum Field Theory, PDF342–346，书页171–175，题42。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。
题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH15；私有JSON由Linux检查工具生成，评分时不执行oracle。
qft-16
provenance/qft-16.md François Gelis, Problems in Quantum Field Theory, PDF346–354，书页175–183，题43。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。
题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH16；私有JSON由Linux检查工具生成，评分时不执行oracle。
qft-17
provenance/qft-17.md François Gelis, Problems in Quantum Field Theory, PDF368–370，书页197–199，题49；明确的径向ansatz为本题扩展。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。
题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH17；私有JSON由Linux检查工具生成，评分时不执行oracle。
qft-18
provenance/qft-18.md François Gelis, Problems in Quantum Field Theory, PDF93–94，书页215–216，题52。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。
题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH18；私有JSON由Linux检查工具生成，评分时不执行oracle。
qft-19
provenance/qft-19.md François Gelis, Problems in Quantum Field Theory, PDF139–145，书页261–267，题67。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。
题面已逐项说明原书物理内容与项目原创的参数、数值实验和交付要求。没有随包分发整本教材。独立真值实现位于tools/author_qft13_19.py的TRUTH19；私有JSON由Linux检查工具生成，评分时不执行oracle。
qft-20
checks/qft-20-sources.md 来源：François Gelis, *Problems in Quantum Field Theory*, 第69题；用户PDF实际页161–163，书页283–285。题包材料及数值工况是本项目原创改造，未复制整本教材。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。
Gelis 第69题用 Euclidean Dirac 算子的正负配对谱证明 Banks–Casher 关系。现在请对三个**受控合成谱模型**完成凝聚重建和极限判断。它们不是实际格点 QCD 数据。取自然单位，输出正的凝聚幅度 \(S=-\langle\bar\psi\psi\rangle\)；完整有符号谱的单位四体积密度为 \(\rho_V(\lambda)\)。非零本征值为 \(\pm\lambda_j\)，另有 `zero_modes=N0` 个精确零模。
qft-21
checks/qft-21-sources.md 来源：François Gelis, *Problems in Quantum Field Theory*, 第70题；用户PDF实际页163–168，书页285–290。题包材料及数值工况是本项目原创改造，未复制整本教材。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。
Gelis 第70题用动量环面上的局部指数讨论 Nielsen–Ninomiya 倍增约束。请对公开的四维有限 Fourier 核族找全零点，并给出局部拓扑信息。格距为1，Brillouin 区是 \(p_\mu\in[-\pi,\pi)\)。逆质量零 Weyl 核用实四矢量 \(F_\mu(p)\) 表示：
qft-22
checks/qft-22-sources.md 来源：François Gelis, *Problems in Quantum Field Theory*, 第72题；用户PDF实际页171–175，书页293–297。题包材料及数值工况是本项目原创改造，未复制整本教材。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。
Gelis 第72题说明纯规范理论的中心变换、Polyakov 环及基本表示物质的显式破缺。本题把它改造成**精确定义的中心有效模型**；这些数据不能用来声称真实 QCD 的临界温度。
qft-23
checks/qft-23-sources.md 来源：François Gelis, *Problems in Quantum Field Theory*, 第73题；用户PDF实际页176–179，书页298–301。题包材料及数值工况是本项目原创改造，未复制整本教材。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。
Gelis 第73题从带电硬粒子的无碰撞 Vlasov 响应推出 HTL 极化。请为**单个无质量 Dirac 物种**的各向同性平衡等离子体建立 retarded 响应。电子、正电子及两自旋的简并度共4，分布为 \(f_0(p)=4/(e^{p/T}+1)\)。自然单位；Debye 质量由硬动量积分确定，\(m_D^2=e^2 C_D T^2\)，\(C_D\) 要计算。下面所有频率和波数按 \(m_D\) 归一化，极化按 \(m_D^2\) 归一化。
qft-24
checks/qft-24-sources.md 来源：François Gelis, *Problems in Quantum Field Theory*, 第75题；用户PDF实际页183–190，书页305–312。题包材料及数值工况是本项目原创改造，未复制整本教材。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。
Gelis 第75题的物理核心是形成时间内多次软散射同阶，必须保留碰撞算子的差分结构。本任务要求求解其**公开有限周期横动量调节模型**，比较完整核、一次碰撞和扩散近似。它是可独立复现的受控 LPM 响应题；不把有限方形网格伪称连续旋转对称模型，也不要求从此网格宣称普适软频率指数。
qft-25
checks/qft-25-sources.md 来源：François Gelis, *Problems in Quantum Field Theory*, 第80题；用户PDF实际页209–217，书页331–339。题包材料及数值工况是本项目原创改造，未复制整本教材。
原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。
Gelis 第80题是**复标量 QED**的外场产对。自然单位，\(e=1\)、`mass=m`。外场空间均匀，temporal gauge \(A_0=0\)，仅 \(A_z(t)\ne0\)，电场 \(E_z=-\dot A_z\)。经典外场预先给定，不含反作用、自相互作用、光子环或费米子 Pauli 阻塞。
qm-01
checks/qm-01-sources.md 已目视核对用户提供的 Griffiths《量子力学概论》配套学习指导书 PDF 第 56–58 页（书内第 50–52 页），第 2 章习题 2.27。教材题给出等强度双 δ 吸引势，要求束缚态数目及指定强度下的能级；解答分段写波函数并使用 δ 点导数跃变形成匹配行列式。
本题改为可控的左右不等强度 `g_left,g_right`，设计八个浅/深和近/远阱工况，要求恢复完整负能谱及左半空间概率。独立数值验证和一对一匹配评分用于识别漏态、误计阈值态与态局域化错误。
来源 PDF：`/Users/ai4s/Downloads/量子力学概论-格里菲斯-学习指导书习题解答-中文版.pdf`。教材理论与题型有明确来源；非对称扩展、工况集、评分和 Harbor 封装由本项目编写，不把经典 δ 势结果宣称为新理论。
qm-02
checks/qm-02-sources.md 原始教材由用户提供：`/Users/ai4s/Downloads/量子力学概论-格里菲斯-学习指导书习题解答-中文版.pdf`。
- PDF 67-68，书内 61-62，习题 2.33：矩形势垒、波函数与导数连续性、低于势垒的透射公式。
- PDF 98-99，书内 92-93，习题 2.53：传递矩阵定义，两个分离势总矩阵为分矩阵乘积，图 2-22。
qm-03
checks/qm-03-sources.md 用户原件：`/Users/ai4s/Downloads/量子力学概论-格里菲斯-学习指导书习题解答-中文版.pdf`。
确切位置：PDF 228–231 页，书内 222–225 页，习题 5.18–5.21。
- 5.18：Bloch 波函数与带边特殊情形；周期 δ 势色散关系。
qm-04
checks/qm-04-sources.md 《量子力学概论—学习指导书习题解答》习题9.20，PDF387–390页／书页381–384。原书为单段圆偏振磁共振；多段相位跳变、非对易复合驱动与失谐响应为本题原创扩展。
所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。
不同于QM01束缚态、QM02散射、QM03空间周期谱；研究含时非对易传播与相干控制。
qm-05
checks/qm-05-sources.md 《量子力学概论—学习指导书习题解答》习题7.1(b)，PDF307–308页／书页301–302，四次势高斯变分。加入二次项、六次稳定项、前四能级、偶极跃迁和双阱谱为原创扩展。
所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。
无散射或Bloch结构，挑战非微扰谱、矩阵元和不同极限下的近似适用性。
sp-01
checks/sp-01-sources.md 核对日期：2026-11-16。
林宗涵，《热力学与统计物理学》配套习题解答，第九章，习题 9.2、9.3。源文件：`/Users/ai4s/Downloads/热力学与统计物理学 习题解答 by 林宗涵.pdf`。
已渲染并目视核对 PDF 第 174–177 页，对应书内第 168–171 页：
sp-02
checks/sp-02-sources-and-fairness.md 用户林宗涵《热力学与统计物理学》习题解答原PDF165-166页，书159-160页，题8.13。两页均已Poppler渲染且真实view_image视觉核对，证据位于 `checks/sp-02-source-pages/lin-165.png`、`lin-166.png`。原题给定固定总粒子数N的理想气体，考查子体积v，并明确取热力学极限、将子粒子数求和上限从N延至无穷，导出泊松分布。书160页末明确说明在重力可忽略时平均密度均匀。
本题研究这一近似的有限储库修正：保留固定N、引入两个不相交观察窗，并用公开的线性外势定义非均匀单粒子位置分布。多项分布直接从经典正则位置配分函数导出。参考解的O(N)条件尾算法、稀有事件和条件协方差是在教材模型基础上的可复现研究改造，并非声称原书有完全相同八组数值答案。
与sp01平均场多项式分支无关：本题是理想气体正则计数、固定总数相关与大偏差，不含相互作用、相变或临界点。八工况属于一个完整任务，不拆成八题。
sp-03
checks/sp-03-sources-and-fairness.md 用户林宗涵《热力学与统计物理学》习题解答，题7.18–7.20。原PDF127、129、130页（书121、123、124页）已实际渲染且逐页view_image核对，文件位于 `checks/sp-03-source-pages/lin-127.png`、`lin-129.png`、`lin-130.png`；PDF128也已渲染，但不声称已视觉阅读。
7.18给三维各向同性谐阱单粒子能谱，并在能量远大于hbar*omega时连续化得到epsilon²态密度；7.19在大N、激发态饱和时取mu=0，给Tc0；7.20给热力学极限下的凝聚比例。本题保留同一个真实单粒子能谱的离散壳层与简并度，把这些近似改造为有限平均N的数值研究。
题目明确使用巨正则系综、平均粒子数N受约束，不冒充固定总N的正则凝聚涨落模型，也不将有限体系的激发态饱和点描述为非解析相变。输出化学势、基态比例、激发能、定平均N热容和饱和温度修正，共同描述一个完整的谐阱Bose气体任务；它独立于sp01平均场相互作用分支与sp02经典有限储库计数。
sp-04
checks/sp-04-sources-and-fairness.md 用户林宗涵《热力学与统计物理学》习题解答题7.25。原PDF138、140、141页（书132、134、135）已实际渲染且view_image核对，图像位于 `checks/sp-04-source-pages/lin-138.png`、`lin-140.png`、`lin-141.png`；PDF139也已渲染但未声称视觉阅读。
书132页给二维电子气的常数态密度及零温化学势；书134页在强简并条件下作Sommerfeld展开，给化学势的零阶结果及T²能量修正；书135页由自由能得到线性T熵。本题以这一真实二维色散为基础，公开加入第二个带底阈值，研究原低温展开在带边附近的适用边界。第二子带模型、参数与扩展问题均在题面公开，不声称原书已含同样双带数值答案。
该题是理想Fermi统计的阈值热激发与定密度响应，独立于sp01平均场分支、sp02经典有限储库计数和sp03谐阱Bose凝聚。八工况组成一个双子带热力学研究任务，不拆成多题。
sp-05
checks/sp-05-sources-and-fairness.md - 题源：用户提供的林宗涵《热力学与统计物理学》及习题解答。直接依据为解答题3.8–3.9，PDF第61–62页、书页55–56；两页均已实际渲染并目视核验。题3.8为等温线极值/失稳线，题3.9为完整对比物态方程及临界展开。渲染文件在 `checks/sp-05-source-pages/`。
- 改编：从局部极值和临界截断扩展到完整状态方程的全局液气共存、临界分支分辨、自由能下凸包、气化潜热与克拉珀龙关系。温度和平均体积是公开制定的数值工况，不将扩展内容冒充教材原题原文或未知科研结论。
- 与其他题的独立性：SP01是磁性多项式平均场；SP05使用完整vdW流体、排除体积极点、正压全局公共切线和定平均体积混相。SP02–04分别为固定粒子涨落、离散Bose谱和Fermi子带，不共用此求解结构。
tm-01
checks/tm-01-sources.md - 鞠国兴，《理论力学学习指导与习题解析（理科用）（第二版）》，第 5 章“小振动”，习题 5.8。
- 用户提供的扫描件：`/Users/ai4s/Downloads/理论力学学习指导与习题解析(理科用)(第二版)-鞠国兴.pdf`。
- 准确位置：PDF 第 319–326 页，对应书内印刷第 310–317 页。2026-11-16 已渲染并目视核对 PDF 第 319、322、323、325、326 页。
tm-02
checks/tm-02-sources.md 核对日期：2026-11-16。
鞠国兴，《理论力学学习指导与习题解析（理科用）（第二版）》，科学出版社，2018，第 4 章“有心力”。源文件由用户提供：`/Users/ai4s/Downloads/理论力学学习指导与习题解析(理科用)(第二版)-鞠国兴.pdf`。
已渲染并目视核对 PDF 第 237–239 页，对应书内第 228–230 页：
tm-03
checks/tm-03-sources.md 用户原件：`/Users/ai4s/Downloads/理论力学学习指导与习题解析(理科用)(第二版)-鞠国兴.pdf`。
- PDF375–377，书366–368，式6.46–6.55：重对称刚体的拉格朗日函数、角动量和能量积分、有效势、运动图像及规则进动。
- PDF438–440，书429–431，题6.32：竖直向上自转、规则进动二次方程、有效势二阶导数与高速稳定阈值。
tm-04
checks/tm-04-sources.md 《理论力学学习指导与习题解析》第二版，第6章6.1.4无力矩刚体及稳定性，PDF372–375页／书页363–366。非对称初值、近分离轨道和固定时刻预测为原创扩展。
所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。
TM03为有重力矩的轴对称陀螺，本题无力矩、三主惯量不同及中间轴非线性翻转。
tm-05
checks/tm-05-sources.md 《理论力学学习指导与习题解析》第二版，习题6.17，PDF409–413页／书页400–404；分布式摩擦、椭圆积分及滑动自转耦合。终止截面、耗散证书和不同惯量系数为原创扩展。
所列PDF页码已根据本地逐页提取的完整段落核对；本轮未声明逐页视觉复核。题包不分发教材扫描页。
无保守势和周期轨道，研究分布摩擦导致的平移转动耦合及接触积分奇性。

exit_code=0
```

### 2026-11-16T23:02:34.344778+08:00

```bash
python3 -
```

```text
README.md characters 4785 broken_links []
报告.md characters 4183 broken_links []
NOTICE.md characters 1397 broken_links []
docs/design-and-provenance.md characters 7615 broken_links []
report_page_sections 4 section_characters [1064, 984, 1056, 1025]
registered_tasks 50 calibration_checks 880
all_cpu4_memory4096_gpu0 True

exit_code=0
```
