
### 2026-11-16T14:09:52.409602+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qm01:dev python tools/recheck_course_score.py
```

```text
tm-01 {"course_file_identical": true, "exit_code": 0, "output": "tm-01.txt"}
tm-02 {"course_file_identical": true, "exit_code": 0, "output": "tm-02.txt"}
sp-01 {"course_file_identical": true, "exit_code": 0, "output": "sp-01.txt"}
qm-01 {"course_file_identical": true, "exit_code": 0, "output": "qm-01.txt"}
ed-01 {"course_file_identical": true, "exit_code": 0, "output": "ed-01.txt"}

exit_code=0
```

### 2026-11-16T15:50:28.638911+08:00

```bash
python3 -c 'from pathlib import Path; p=Path("planning/source-notes/qft-all.txt"); lines=p.read_text().splitlines(); print("\n".join(lines[4820:5100]))'
```

```text
（1） 散射矩阵与不变振幅
（a）肘同演化算符
为简便，以下省略相互作用绘景角标1.设日=H。+ ，由
一4（）二日（）y（水），ひ（っt）y（t）=4（）
可得
음U(.S)=HU(%6)
初始条件び（ちoっt）＝1.改微分方程可化光根分方程（周邦融.量子場治）
U（36）=1-15ds,77（4）0て（3%）
设H（t）=ja'x ”（x），依次迭代，可得
ひ（6）=Texp-1id37/（2）
此处T为时序算符。
（b）散射矩阵
S=U（8，-8）=7CXP-1,0127/（）」
此处S为散射算符【S短阵相当于量子力学中的ax（t）】。各书中，此式基本一致，不再赘述。
（c）反应矩阵
对一阶微扰
5=1-i8d372（2）-1+iR
此处R 为反应算符（见周邦融：Fayyazuddin 《A Modern Introduction to Particle Physics》 3ed：
Quang H K 《Elementary Particles and Their Interactions》；Ryder、Peskin 用 T 表示 R），
Ra=ー（f768労反座短降（Falyazuddin；注意与刃慣的IT短降定文差
ー（27）*8（P，一p.）），【R矩陸相当子量子カ学中的 Hm1。
118

===== PDF PAGE 127 =====
细推物理须行乐
（d）不变振幅
定义
(PiP'...P'iR| P.P2)=(27)OÉLP'-PI-PA)iM
其中M为 Lorentz 不变振幅（Srednicki 用T，Fayyazuddin 用F表示M）。
（2）跃迁
（a）本征态展开
我们以标量场为例进行计算。场量可用动量本征态展开为（Ryder,Quang HK）
d'P
波浪线是为协变的要求（周邦融，Ryder 用P。或p表示E，王正行用0表示）。则入射态为
1）=好）名）=Jap,dps中（，）¢（p）|PP2）
而出射态为（Ryder）
f）=lpip•p.）
注意，根据量子力学的经验，出射态无需展开。于是，反应矩阵可写为
B=（ Rl）=Jipa如（P.）p（p.）（pip:pRlp.pz）
=(2т)dpdp$P)M(8(ÉP-PI-P2M
（b）跃迁概率
W，=BA=
据量子力学经验，跃迁概率应是反应矩阵模方（Ryder； 非S矩阵平方：周邦融用00g或32g）：
（c）时空体积
因为P+P=9+92，有
(2TT)* S*(0) = [d'xe""PtP291-42)x = VT
（d） Fourier 变换
根据 Fourier 逆变换（Ryder）
Jăpф(p)e* =y (x)
于是
₩,=lRд=(27)"dx((1?8([Pİ-P-DM1
119

===== PDF PAGE 128 =====
为往圣继绝学
（e）末态相空间
此式对于初末态为分立本征值时成立，然而我们选的平面波态有连续的动量本征值，所以还
必须乘以未态粒子相空间的态数（周邦融），于是
W=RATI
8pi
方（27）32E，
-=JOXy.（2）『WS（X）PIM.P d0.
郯次青中用P表示W.其中
d4，=I
9P（27）*8 Cpi-P-P2）
六（27）32E
为末态相空间积分（Quang HK粒子3始编号，郑汉青、Peskin 用dI，，肖振军少（2z）*）
（f）单位时空跃迁率
单位时空的跃迁率为
dw
P=-
dVdt
三=W（2）『WVっ（X）PMAdd，
（3）散射截面
（a）粒子数密度
设w（x）=e-m =e-i（E-px），类似量子力学的做法（了协变性，定义略有不同），可得
可得粒子数密度（Ryder, Quang HK）
p=1o=2EW（x）”
其“密度”概念可从归一化条件看出（周邦融）：
（0日）=（27）38（0-月）2日=2日0：=2EV
（b）微分散射截面
微分散射截面沩
P
P
da=-
jP2
V12P,P2
Md0n =.
MMP
-d0n
2E,2E,412
其中Y2为1相对2粒子的速度（周邦融：郑汉青；Quang HK ；Peskin: Fayyazuddin 用 p/E
表示速度）， =vp 可类比电流密度j=nev（n为电子数密度）。因归一化定义不同，粒子
数密度计算千差万别。王正行认为，数密度就是体积的倒数1/V.这样，从跃迁概率（郑汉青）
W=do.ViT
W12
1
一也可得微分截面do=-
ー=PI
-=P—
VILT
VTYz
11
1
-，注意此处
VI2PIP2
VT 相应于前面的 dvdt.
（c）流因子
120

===== PDF PAGE 129 =====
细推物理须行乐
为流因子（Quang H K: Ryder 用B 表示F），角标CM 表示质心系（Srednicki，或动量中心系）。
（d）归一化系数
另一方面，多数书将归一化系数的一部分吸收到不变振幅M 中（Greiner QED），也有的书将
归一化系数单独写出来（周邦融，Fayyazuddin.）：
in+m
M=計」
1
No=
Jea（四）
其中m 和n分别为初态和末态粒子数，s和r分别为玻色子和费米子数【根据平面波态归一
化（周邦融），应区分费米子质量，有质量费米子对相空间计数影响与玻色子不同，无质量
费米子则相同】，V=是取周期性边界条件和箱归一化的结果。
（e）全同粒子
考虑到全同粒子（a个），散射截面还需乘以对称因子S=工六，（QuangHK；周邦融、郑
la!
汉青用 m;Srednicki 用n；
Greiner QED 用g表示 ）
（4）衰变宽度（衰变率）
对于衰变问题，只需将流因子改一改即可 （Quang H K; Peskin）
d4，=I
片（2z）°2EY
此处没有2粒子，只剩p=p，而p2消失：取初态粒子静止系，V2也消失，E=E=m，
其中 m为初态粒子不变质量。
衰变宽度的倒数即为粒子寿命。
1.3.2
例题示范
前面几课，我们从 Lagrange 量计算生成泛函，对生成泛函求泛函导数得出关联函数，然后
将关联函数用 Feynman 图表示。这是在学习阶段走的路。实际工作时，路径有所不同：先
根据所讨论的物理过程画出拓扑不等价的Feynman 图，再根据Feynman 规则写出散射振幅，
最后将散射振幅平方、对相空间积分，算出散射截面。也就是说，只要 Feynman 规则己经
事先导出，那么以后就不必再重复“构造Lagrange 量”“计算Green 函数”这些中间过程了。
具体说来，因为 QED 的 Feynman 规则已经导出，以后再计算QED 过程（不论Compton 散射、
正负电子湮灭，抑或其他），只要画图，从图中读出矩阵元，然后将矩阵元平方即可。
当然，如果计算超出 QED 的过程，比如手征微扰论，其 Feynman 规则尚不清楚，那么应该
先构造手征 Lagrange 量，推导手征 Feynman 规则；拿到 Feynman 规则后，再将 Lagrange 量
和推导 Feynman 规则的中间过程都忘掉，直接从物理过程出发画图，读出S矩阵元，计算
振幅和截面。
121

===== PDF PAGE 130 =====
为往圣继绝学
现在，让我们忘掉 Lagrange 量，忘掉关联函数，忘掉S矩阵约化，只记得 Feynman 规则，
直接讨论 QED过程。
回到最初那道題：正負子湮天生経子対ルe*+e→4+4散射截面，到単圏水平。
其骨架图（树图）是最简单的，因为只有一个道，其他一般有S、t、u 三个道（即使
e* +e →e+e也有交叉道）。
1.3.2.1 过程图
我们只计算树图和末态粒子顶角修正，主要参考郑汉青《量子场论》上册。
树图（骨架图）光
et
p',s'
p+p
p,s
fk',r'
ker
相应于树图的矩阵元为
S2=(P+P)= >i e?
u(k,r)y'v(K',r)T(P,S)Y,u(P,s)
単圏福射修正（Kinoshita's QED）
（a）
(b)
相应于单圈图中末态顶角修正图（c）的矩阵元为
（c）
（d）
(e)
其中タ＝kーん。滋里与王正行差一負号。需要特別注意的是：
郑汉青的书这个地方将二者混为一谈，不适合初学者看。
122

===== PDF PAGE 131 =====
细推物理须行乐
外线粒子因在壳条件，其圈修正（此处轻子自能）可忽略（Greiner's QED）。虽然虚修正
可忽略，但可以考虑实修正（发射可见光子）：
又人人
1.3.2.2 矩阵元
M=Mnee + M -loop +..-Mo+（M-+.•）-loop +.
1.振幅表达式
树图已很清楚了，圈图的顶角函数尚未明了。为写出它的具体形式，先证明Gordon 恒等式：
+ ”2Ju（p）
2m
证明：由Dirac 方程（P-m）u（p）=0，可推出
=[22"-2io')P.M() (p"i 'o' . 4(D)
同理，u（p）（p' m）=0推出
i（p）my"'=i（p）Ip""+ic"p.］
第一式左乘，加上第二式右乘，得
2mu（p）y"u（p）=i（p）I（p'"+p"）+io"（p-p.）lu（p）
令动量转移为p'—P=q，两边除以2m 即为Gordon恒等式。证毕。
将 Gordon恒等式移项可见，p'+p等于树图顶点y“与p' p的叠加。单圈顶角也是p，P
的函数，所以顶角函数可写为树图顶点 ”与p' p的组合：
F"（p'，p）=y"F（g）+
组合系数中的F（q^），F（g'）可称为形状因子。树图顶角1个点，没有形状，不应该是q
123

===== PDF PAGE 132 =====
为往圣继绝学
的函数，所以第二项应该消失，第一项为常数。
利用Gordon恒等式导出的用形状因子表达的顶角函数，可将圈图振幅具体化力
u4ャニュー
2.顶角函数化简
由此式可见，关键在与顶角函数的计算。这个前面讨论过了，但用的是维数正规化方法。这
里既有紫外发散又有红外发散，我们可以用维数正规化，但为与其他人比较，我们采用
Pauli-Villars 正规化处理紫外发散，并通过给光子一个小质量来处理红外发散。顶角函数如图：
\kニん+9
DーR1
根据 Feynman 规则，可写出一圈顶角（Peskin's QFT）：
Й(Р)ОГ"(Р,р')и(р) =]
-18vp
(27)"(K-p)= " (P)(-ier") ilk' +m)
K'-m=zui(lt+M) (-iey")u(P)
Кº-m?
= -ie| 2k )*(E+m-*(k+mH(P)
（1）分母与分子的处理（引入xyz）
分母可用 Feynman 参数折叠火
（ルーアイんーカァ）ペール）＝「ardyidが（ょ+yナマーリ5
D=(K-p)'z+(k"-m')y +(k'-m')x
K-k+9 >K°z+p'z-2pkz+(k+9)'y +k'x-m'(x + y)
=k(x+y+z)+2k(gy-pz)+9y+p'z-m'(x+y)
xtyt2=l>(k+qy-pz)'-(gy-pz)'+g'y+p'z-m'(x+y)
IktQーBe >1+2p9y2+9：（0-¥3）+8（2-23）-m（5+3）
=P+[(p+9)-p-9]yz+9(y-y)+p(z-2)-m'(x+y)
パーカニパー（PtO* >P+9（ソージーy2）+m（2ー2ーメー1）
汁サミ →P+タソーンーン（1-8-2）］+m（2ー23+2-1）
=P+9'xy-m°(1-z)=P-A
##1=k+yq-zp, A=-xyq+(1-z}m?
分子看似简单，实则复杂。我们分两步算。
（a）Gamma 矩阵的处理
根据维数正规化一节证过的d维Gamma 矩阵公式
124

===== PDF PAGE 133 =====
细推物理须行乐
取d=4，得
N$=х(k+Mхü(k+mYv=хКрНy„+m[NK"X+Хy"ky„I+my"y"v
=-2Y°y"yPKpko+4m(g"k+8"k)-2m'y"=2[ky"K-2m(k+K)"+m?y"]
分子要遗传分母的特征，分母做了1=k+y9—zp变换，所以
Ne-A#-N+ -2111-19+201）11-19+20+91-2m12（-19+2p） +9j +myes
埼沢番製分10 >-24yN1+1-19+2p1y"19-19+201-2ml9-2y9+22pl +myis
=-2{-Lpy"+I-yq+zp]r"[9-y9+zp]-2m[9"-2yq"+2zp"I+m'y"}
其中利用アI1=1891=18080,89791=51189746=-
特别注意：
这里的度规张量不能任意选取，如果选择gpug”“将得出错误结果！
（b）旋量的処理
这一步的计算特别繁琐易错，所以先要明确目标：
I（P）N"UD）=Ay"+BP+PA）+Cg
根据 Dirac 方程有pu（p）=mu（p）， ii（p）p=ii（p）m，可代入g＝pーp化筒：
u（p）I-y（p-p）+2p】/"1（1-2）（p一p）+zpJu（p）
DiracTit >U (p')[-y(m-p)+zp]y"[(1-y)(p'-m)+zm]u(p)
xty+zel>u(p')I(1-x)p-my]r"I(1-y)p'-mx]u(p)
=Ù(p')[(1-X)(1-Y)PY"p'+m'xyy"-mx(1-X)py"-my(1-y)r"p'Iu(p)
(p){(1-x)(1-y)(28"-28"+28Hy-Yy"yPD
+m'xyp"-mx(1-X) (2p"-y"p)-my(1-Y) (2p'"-p'r"')}u(p)
Diractiht →U(p'){(1-x)(1-Y)[2m(p'"+p")+(9?-3m?)y"]
+m-xyy"-mx(1-x)(2p"-y"m)-my(1-y)(2p'"-my")ju(p)
=u(P') { (1-x) (1-y)92y"+m-y"[xy + x(1-x) +y(1-y)-3(1-x) (1-y)]
+2mp"[(1-x)(1-y)-x(1-x)]+2mp'"[(1-x)(1-y)-y(1-y)]}u(p)
3（1-x）（1-）株茂3ト期式分磐 >i（p）1（1-8）（1-2）9y-my"T（1-x）+（1-2）+112
+2mp"(1-x)z +2mp'"(1-y)z}u(p)
=T(p){(1-X)(1-y)9y"-my"z(z+2)+2mp"z(1-х)+2mp'"z(1-y)}u(p)
其中紅的部分是要特別小心的，推㝵它的辻程利用了py"=2pード"p及
125

===== PDF PAGE 134 =====
为往圣继绝学
й(p')pY"p'u(р)=й(p)(2g"º-2gßy"+2gP"yº-Yy"yPҐИ(P)
Diractiht >I(p')(2p'"m-2p. p'r"+2p"m-m'r")u(p)
=Ù(p){2m(p'"+p")+[(P'-p)-p-p']y"-m'y"şu(P)
p°=n=p>u(p)[2m(p'"'+p") + (Q-3m)y"Iu(p)
所以（別忘了我付的目杯T（P）N"U（D）=Ay"+B（P"+が）+Cg"）

exit_code=0
```

### 2026-11-16T15:50:55.174976+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(sorted(p.name for p in Path("tasks").iterdir() if p.is_dir())))'
```

```text
ed-01
gr-01
qft-01
qm-01
qm-02
sp-01
tm-01
tm-02

exit_code=0
```

### 2026-11-16T15:52:55.525333+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(sorted(p.name for p in Path("tasks").iterdir() if p.is_dir())))'
```

```text
ed-01
gr-01
qft-01
qm-01
qm-02
sp-01
tm-01
tm-02

exit_code=0
```

### 2026-11-16T15:52:55.622151+08:00

```bash
cat checks/qft-01-validation.md
```

```text
# qft-01 开发验证

日期：2026-11-16。本记录是本地开发验证，不是课程指定 Codex 的正式测评。

环境：本地 Docker Desktop Linux aarch64，Linux 6.12.76，Python 3.12.13，4 CPU、4 GiB、断网、0 GPU。课程原版统一质量评分函数经字节比较一致。

## 独立数值真值

70 位 mpmath 色散积分与直接费曼参数对数积分在全部12点最大绝对差约 (1.64\times10^{-70})。实部零点为 10.824815332412549；三级低能式相对误差首次达到 1% 的位置为 (z=1.4761335518527162)。两个正谱矩分别为 (1/30)、(1/280)。独立真值生成不导入参考求解器。

## 校准与检查

| 解答 | 原始误差（百分点） | 课程质量分 |
|---|---:|---:|
| 24 节点朴素固定求积 | 3.6895280307201754 | 0 |
| 解析延拓参考解 | 3.9741570296244154e-12 | 1 |
| 独立色散积分答案 | 0 | 1 |
| 复共轭分支错解 | 8.23136 | 0 |
| 漏掉吸收虚部 | 8.17818 | 0 |
| 低能边界错误 | 10.0 | 0 |

另检查了阈值虚部、重复/未知 ID、布尔数、非有限数、空产物、反馈入口和答案重排。全部 15 项通过；细节见 `checks/qft-01-calibration.json` 和 `checks/qft-01-truth-validation.json`。

Harbor oracle/nop 与正式 Codex 三次运行尚待执行。复现命令及输出在 `checks/qft-01-command-log.md`。

exit_code=0
```

### 2026-11-16T15:54:21.350697+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(sorted(str(p) for p in Path("tasks").glob("*/instruction.md"))))'
```

```text
tasks/ed-01/instruction.md
tasks/gr-01/instruction.md
tasks/qft-01/instruction.md
tasks/qm-01/instruction.md
tasks/qm-02/instruction.md
tasks/sp-01/instruction.md
tasks/tm-01/instruction.md
tasks/tm-02/instruction.md

exit_code=0
```

### 2026-11-16T15:54:21.401796+08:00

```bash
cat planning/work-order-gr02.md planning/work-order-qm03.md
```

```text
# gr-02 实际制作任务

只写 `tasks/gr-02/`、`tools/*gr02*`、`checks/gr-02*`。独立广义相对论任务，不能重复 gr-01 Schwarzschild 类光散射；优先 FLRW 宇宙模型距离/视界/宇宙年龄的反演和退化判断，或教材中另一有答案的独立场方程题。来源用户梁灿彬《微分几何入门与广义相对论》上/中/下册 OCR (`planning/source-notes/gr-*-all.txt`)；须定位原PDF页面并核对关键公式、约定。无需更改已完成gr-01。

交付完整中文 Harbor 包、合理基线、可复核参考解、原版课程评分器、独立真值、实际 Linux Docker 数值检查与来源公平性/命令日志。4 CPU 4 GiB 0 GPU。单题非多个近似参数变种。用户已给全权长程执行；不请求权限，不连服务器、不碰其推理项目、不推GitHub。命令写到 `checks/gr-02-command-log.md` 并显式展示。
# qm-03 实际制作任务

只写 `tasks/qm-03/`、`tools/*qm03*`、`checks/qm-03*`。完成量子力学第三个独立任务，优先选择一维周期势 Bloch 色散/带隙、有限周期数效应，避免与 qm-01 束缚态、qm-02 双矩形势垒散射重复。来源用户提供的 Griffiths 习题解答 PDF 及 OCR `planning/source-notes/qm-sol-all.txt`；需定位并检查确切教材页，不猜题号。用户已经授权长程执行，本任务内继续做完，不请求授权。

做完整 Harbor 题包：中文题面、固定版本环境、公开模型和反馈、合理简单基线、带推导的参考程序、课程原版质量评分函数、独立私有真值、分支/边界检查、Linux Docker 校准及来源/公平性/命令记录。按 qm-01/02 配置，4 CPU、4 GiB、0 GPU、agent1200秒/verifier120秒。任务有非平凡物理推理，不能将参数工况凑成多题。数学/数值结果经两条独立计算核对。只用本地，不碰远程推理服务器，不推送GitHub。

命令通过 `python3 tools/run_logged.py --log checks/qm-03-command-log.md -- ...` 保存，且在 commentary 向用户显式展示实际命令。Harbor可由主代理汇总跑。

exit_code=0
```

### 2026-11-16T15:58:05.917978+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(sorted(str(p) for p in Path("tasks").glob("*/instruction.md"))))'
```

```text
tasks/ed-01/instruction.md
tasks/gr-01/instruction.md
tasks/qft-01/instruction.md
tasks/qm-01/instruction.md
tasks/qm-02/instruction.md
tasks/sp-01/instruction.md
tasks/tm-01/instruction.md
tasks/tm-02/instruction.md

exit_code=0
```

### 2026-11-16T15:58:05.974335+08:00

```bash
cat checks/qft-01-validation.md
```

```text
# qft-01 开发验证

日期：2026-11-16。本记录是本地开发验证，不是课程指定 Codex 的正式测评。

环境：本地 Docker Desktop Linux aarch64，Linux 6.12.76，Python 3.12.13，4 CPU、4 GiB、断网、0 GPU。课程原版统一质量评分函数经字节比较一致。

## 独立数值真值

70 位 mpmath 色散积分与直接费曼参数对数积分在全部12点最大绝对差约 (1.64\times10^{-70})。实部零点为 10.824815332412549；三级低能式相对误差首次达到 1% 的位置为 (z=1.4761335518527162)。两个正谱矩分别为 (1/30)、(1/280)。独立真值生成不导入参考求解器。

## 校准与检查

| 解答 | 原始误差（百分点） | 课程质量分 |
|---|---:|---:|
| 24 节点朴素固定求积 | 3.6895280307201754 | 0 |
| 解析延拓参考解 | 3.9741570296244154e-12 | 1 |
| 独立色散积分答案 | 0 | 1 |
| 复共轭分支错解 | 8.23136 | 0 |
| 漏掉吸收虚部 | 8.17818 | 0 |
| 低能边界错误 | 10.0 | 0 |

另检查了阈值虚部、重复/未知 ID、布尔数、非有限数、空产物、反馈入口和答案重排。全部 15 项通过；细节见 `checks/qft-01-calibration.json` 和 `checks/qft-01-truth-validation.json`。

Harbor oracle/nop 与正式 Codex 三次运行尚待执行。复现命令及输出在 `checks/qft-01-command-log.md`。

exit_code=0
```

### 2026-11-16T15:58:41.613393+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(sorted(str(p) for p in Path("tasks").glob("*/instruction.md")))); print(Path("checks/qft-01-validation.md").read_text())'
```

```text
tasks/ed-01/instruction.md
tasks/gr-01/instruction.md
tasks/qft-01/instruction.md
tasks/qm-01/instruction.md
tasks/qm-02/instruction.md
tasks/sp-01/instruction.md
tasks/tm-01/instruction.md
tasks/tm-02/instruction.md
# qft-01 开发验证

日期：2026-11-16。本记录是本地开发验证，不是课程指定 Codex 的正式测评。

环境：本地 Docker Desktop Linux aarch64，Linux 6.12.76，Python 3.12.13，4 CPU、4 GiB、断网、0 GPU。课程原版统一质量评分函数经字节比较一致。

## 独立数值真值

70 位 mpmath 色散积分与直接费曼参数对数积分在全部12点最大绝对差约 (1.64\times10^{-70})。实部零点为 10.824815332412549；三级低能式相对误差首次达到 1% 的位置为 (z=1.4761335518527162)。两个正谱矩分别为 (1/30)、(1/280)。独立真值生成不导入参考求解器。

## 校准与检查

| 解答 | 原始误差（百分点） | 课程质量分 |
|---|---:|---:|
| 24 节点朴素固定求积 | 3.6895280307201754 | 0 |
| 解析延拓参考解 | 3.9741570296244154e-12 | 1 |
| 独立色散积分答案 | 0 | 1 |
| 复共轭分支错解 | 8.23136 | 0 |
| 漏掉吸收虚部 | 8.17818 | 0 |
| 低能边界错误 | 10.0 | 0 |

另检查了阈值虚部、重复/未知 ID、布尔数、非有限数、空产物、反馈入口和答案重排。全部 15 项通过；细节见 `checks/qft-01-calibration.json` 和 `checks/qft-01-truth-validation.json`。

Harbor oracle/nop 与正式 Codex 三次运行尚待执行。复现命令及输出在 `checks/qft-01-command-log.md`。


exit_code=0
```

### 2026-11-16T16:00:51.425552+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(sorted(str(p) for p in Path("tasks").glob("*/instruction.md")))); print("\n".join(sorted(str(p) for p in Path("tools").glob("*qft02*"))))'
```

```text
tasks/ed-01/instruction.md
tasks/gr-01/instruction.md
tasks/gr-02/instruction.md
tasks/qft-01/instruction.md
tasks/qm-01/instruction.md
tasks/qm-02/instruction.md
tasks/qm-03/instruction.md
tasks/sp-01/instruction.md
tasks/tm-01/instruction.md
tasks/tm-02/instruction.md


exit_code=0
```

### 2026-11-16T16:03:52.922776+08:00

```bash
cat tasks/qft-02/environment/public/model.json tasks/qm-03/instruction.md
```

```text
{
  "problem": "distinguishable-scalar three-body decay with a coherent s-channel pole",
  "units": "GeV, hbar=c=1; g0 dimensionless, g1 in GeV^2",
  "amplitude": "A(s)=g0+g1/(s-mr^2+i*mr*gamma)",
  "cases": [
    {"id":"decay-01","M":5.0,"m1":0.4,"m2":0.7,"m3":0.6,"mr":2.1,"gamma":0.15,"g0":[0.6,0.0],"g1":[0.8,0.5]},
    {"id":"decay-02","M":5.0,"m1":0.3,"m2":0.5,"m3":0.4,"mr":2.3,"gamma":0.0002,"g0":[1.0,0.0],"g1":[0.003,0.002]},
    {"id":"decay-03","M":2.51,"m1":0.8,"m2":0.7,"m3":1.0,"mr":1.505,"gamma":0.0004,"g0":[0.7,0.2],"g1":[0.001,-0.001]},
    {"id":"decay-04","M":4.0,"m1":0.9,"m2":0.6,"m3":0.8,"mr":1.35,"gamma":0.04,"g0":[0.3,-0.4],"g1":[-0.5,0.6]}
  ],
  "quantiles": [0.1,0.5,0.9],
  "scoring": {"weights":{"width":0.45,"interference_fraction":0.25,"quantiles":0.30},"interference_floor":0.05}
}
# 双原子狄拉克晶格的 Bloch 能带与有限周期环

## 研究问题

在一维周期势中考虑单粒子定态薛定谔方程
\[
-\psi''(x)+V(x)\psi(x)=E\psi(x),\qquad
V(x)=\sum_{j\in\mathbb Z}\left[g_A\delta(x-ja)+g_B\delta(x-ja-d)\right].
\]
采用 \(\hbar^2/(2m)=1\)，\(a>0\)、\(0<d<a\)。每个晶胞有位于 \(0,d\) 的两个点相互作用，强度可以为正（排斥）或负（吸引）。在势点处 \(\psi\) 连续，导数满足
\[
\psi'(x_i^+)-\psi'(x_i^-)=g_i\psi(x_i).
\]
四组固定工况在 `/app/data/model.json` 中公开。对每组完成两项研究：

1. 求最低三条 Bloch 能带各自的下、上带边。
2. 将同一个周期势放在含 \(N\) 个晶胞的周期环上，求前两条能带在**全部** Bloch 扇区 \(n=0,\ldots,N-1\) 的能量，周期条件为 \(\psi(x+Na)=\psi(x)\)。

这里按所给晶胞长度 \(a\) 定义第一布里渊区。能带编号是同一 Bloch 波数下按能量升序的第 1、2、3 条带，随后取其能量范围；即使两个相邻带接触，也仍然保留两个编号和同一个接触端点。当 \(g_A=g_B,d=a/2\) 时实际更小的原胞会使能带折叠，不能把接触的两条带合并为一个区间。吸引势还可能产生完全低于零的能带，不能仅在 \(E>0\) 搜索。

本题测量如何由点相互作用、Bloch 边界条件和状态传播判断允许谱，区分真正带隙与折叠接触，并由无限晶格色散确定有限环的量子化能级。四个工况共同组成一道题。

## 材料与工具

- `/app/data/model.json`：`a`（晶胞长度）、`d`（胞内两势点间距）、`g_a/g_b`（点势强度）、`cells`（环上晶胞数），以及全局要求的带数。
- `/app/data/physics.py`：公开的自由传播与点势跃变矩阵、单胞判别式和输出校验函数。`monodromy(E,case)` 返回半迹 `discriminant` 与行列式残差。
- `/app/data/feedback.py`：给定能量的允许性诊断，或提交带边/能级处的 Bloch 残差。
- `/app/data/metric.json`：公开实测基线、参考端点与原始指标容差。
- Python 3.12、NumPy、SciPy、mpmath 可用。可采用传播矩阵、精确色散关系、收敛的平面波展开或其他等价方法。

最小读取示例：

```python
import sys
sys.path.insert(0, '/app/data')
from physics import load_model, monodromy
c = load_model()['cases'][0]
print(c, monodromy(5.0,c))
```

## 探索与反馈

记 \(M(E)\) 为一个晶胞的 \((\psi,\psi')\) 状态传播矩阵。点势跃变与自由传播均保持 Wronskian，因此 \(\det M=1\)。Bloch 波满足
\[
\operatorname{spec}M=\{e^{iKa},e^{-iKa}\},\qquad
D(E)\equiv\tfrac12\operatorname{tr}M(E)=\cos(Ka).
\]
对实能量，\(|D(E)|\le1\) 为允许带，\(|D(E)|>1\) 为禁带。带边对应 \(D=\pm1\)，但**不能只检查符号变化**：闭合带隙的接触点可以是重复根。有限环允许 \(Ka=2\pi n/N\)，于是每个扇区需要求 \(D(E)=\cos(2\pi n/N)\)。\(n,N-n\) 通常给出相同能量，但它们是两个不同的扇区，仍须分别提交。

运行公开反馈：

```bash
python /app/data/feedback.py --case crystal-01 --energy 5.0
python /app/data/feedback.py /app/output/trial.json
```

第一条返回单个能量的判别式、行列式残差及是否处在允许谱；第二条检查提交格式，并逐项返回带边判别式及环能级的 Bloch 残差。命令不列出正确带边或完整能级表，不计算最终得分；次数不限。一个根的 Bloch 残差小并不自动说明找到了正确带号，应同时检查能量排序、允许区间、负能支和接触边界。

## 最终产物

写入 `/app/output/answer.json`，格式示意：

```json
{"cases":[{"id":"crystal-01","bands":[
  {"index":1,"lower":1.0,"upper":2.0},
  {"index":2,"lower":3.0,"upper":4.0},
  {"index":3,"lower":5.0,"upper":6.0}
],"ring_levels":[
  {"band":1,"sector":0,"energy":1.0}
]}]}
```

以上数值只演示字段，示意的 `ring_levels` 未列全。每个公开工况恰有一项；`bands` 恰有索引 1、2、3，各自 `lower<upper`。`ring_levels` 恰好覆盖前两条带的全部 \(2N\) 个 `(band,sector)`，不得重复或遗漏。工况、带、扇区的数组顺序不限。所有能量为有限实数，布尔值不算数值；允许负能量，允许相邻带的上下边相等。可附加不参与评分的 `method` 字符串。

## 评价办法

全部物理输入固定且公开。最终验证采用独立 60 位精度的自由传播/点势矩阵乘积，重算带边和环能级。对真值第 \(j\) 条带，取公开的统一误差尺度规则
\[
s_j=\max(0.1,\hat U_j-\hat L_j).
\]
带边误差和环能级误差为
\[
e_B=\frac16\sum_{j=1}^3\left[\min\left(1,\frac{|L_j-\hat L_j|}{s_j}\right)+\min\left(1,\frac{|U_j-\hat U_j|}{s_j}\right)\right],
\]
\[
e_R=\frac1{2N}\sum_{j=1}^2\sum_{n=0}^{N-1}
\min\left(1,\frac{|E_{jn}-\hat E_{jn}|}{s_j}\right).
\]
每工况误差为 \(100(0.6e_B+0.4e_R)\)，总指标为四工况算术平均，单位百分点，越低越好。指标要求正确带号和扇区，不按文本相似度或求解方法评分。合法但物理错误的数值按误差评分；格式无效得分 0。

简单基线是 Bloch 平面波 Galerkin 近似，保留 \(m=-3,\ldots,3\) 共七个平面波。参考解用精确判别式、单调区间分割和括根；二者读取同样的公开输入。`metric.json` 登记实际运行的基线/参考原始误差；课程统一函数把基线换成 0、参考换成 1。原始指标容差为 \(10^{-5}\) 百分点。

## 时间与资源

Agent 1200 秒，verifier 120 秒；4 CPU、4 GiB 内存、4 GiB 磁盘、0 GPU。Agent 只需输出固定问题的能量表；最终 verifier 独立读取 JSON 和冻结真值，不执行候选程序。

exit_code=0
```

### 2026-11-16T16:05:07.057975+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(str(p) for p in sorted(Path("tasks/qft-02").rglob("*")) if p.is_file())); print("\n".join(str(p) for p in Path("tools").glob("*qft02*")))'
```

```text
tasks/qft-02/environment/public/feedback.py
tasks/qft-02/environment/public/model.json
tasks/qft-02/environment/public/physics.py
tasks/qft-02/solution/baseline.py
tasks/qft-02/solution/solve.py
tasks/qft-02/solution/solver_core.py
tasks/qft-02/tests/score.py


exit_code=0
```

### 2026-11-16T16:15:45.766187+08:00

```bash
docker ps --format '{{.ID}} {{.Image}} {{.Status}} {{.Command}}'
```

```text
8e7f3d9c73f1 theory-physics-qft02:dev Up 2 minutes "python tools/build_…"

exit_code=0
```

### 2026-11-16T16:22:51.321667+08:00

```bash
python3 -c 'from pathlib import Path; import json; print("TASK STATUS"); [(print(p.name, (Path("checks")/(p.name+"-calibration.json")).exists())) for p in sorted(Path("tasks").iterdir()) if p.is_dir()]; print("QFT02 TRUTH"); print(Path("checks/qft-02-truth-validation.json").read_text()); print("MANIFEST TEMPLATE"); print((Path.cwd().parents[1]/"00-老师原始材料/科研探索课程项目/template/benchmark.json").read_text())'
```

```text
TASK STATUS
ed-01 True
ed-02 True
gr-01 True
gr-02 True
qft-01 True
qft-02 True
qm-01 True
qm-02 True
qm-03 True
sp-01 True
tm-01 True
tm-02 True
QFT02 TRUTH
{
  "method": "55-digit independent Breit-Wigner angle integration; 35-digit precision repeat; local safeguarded Newton with cached segment integrals",
  "cases": [
    {
      "id": "decay-01",
      "relative_35_vs_55_digit_difference": 0.0,
      "cdf_residuals": [
        "2.943902059028277472481003952667384675915478433815459361e-45",
        "6.600018815202243577397821892167023882425685959143793782e-55",
        "7.585096250307056051636302771594937894728027147075703301e-55"
      ]
    },
    {
      "id": "decay-02",
      "relative_35_vs_55_digit_difference": 0.0,
      "cdf_residuals": [
        "2.762609699558423753669383401219503284971668939616479125e-37",
        "7.162961200302384275171145896455747916380969716531040698e-54",
        "2.588751041585167557314275027428396465128205530029730259e-36"
      ]
    },
    {
      "id": "decay-03",
      "relative_35_vs_55_digit_difference": 0.0,
      "cdf_residuals": [
        "1.259384658742881995128574994042299460616459465539177091e-32",
        "1.837802904352926346943230265610534624030082519920723752e-56",
        "8.252168484181834493795812732321716841737664479930725161e-44"
      ]
    },
    {
      "id": "decay-04",
      "relative_35_vs_55_digit_difference": 0.0,
      "cdf_residuals": [
        "1.093506926804626249783573775900307288033706553808405216e-35",
        "5.681151310050916534930378651240575483014139265816030572e-56",
        "5.701136407818230163766932451114059037816060129134743238e-37"
      ]
    }
  ],
  "elapsed_seconds": 2.8393877930000144
}

MANIFEST TEMPLATE
{
  "name": "TODO：本组benchmark名称",
  "research_goal": "TODO：研究主题、能力目标与题目覆盖范围",
  "tasks": [
    {
      "id": "task-01",
      "title": "TODO：第1题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-01"
    },
    {
      "id": "task-02",
      "title": "TODO：第2题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-02"
    },
    {
      "id": "task-03",
      "title": "TODO：第3题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-03"
    },
    {
      "id": "task-04",
      "title": "TODO：第4题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-04"
    },
    {
      "id": "task-05",
      "title": "TODO：第5题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-05"
    },
    {
      "id": "task-06",
      "title": "TODO：第6题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-06"
    },
    {
      "id": "task-07",
      "title": "TODO：第7题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-07"
    },
    {
      "id": "task-08",
      "title": "TODO：第8题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-08"
    },
    {
      "id": "task-09",
      "title": "TODO：第9题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-09"
    },
    {
      "id": "task-10",
      "title": "TODO：第10题名称",
      "coverage": "TODO：本题研究对象、难点及与其他题的实质区别",
      "path": "tasks/task-10"
    }
  ]
}


exit_code=0
```

### 2026-11-16T16:22:51.367154+08:00

```bash
cat tools/run_harbor_local_checks.py
```

```text
#!/usr/bin/env python3
"""Run oracle/nop locally and archive raw jobs, including unsuccessful runs."""

import argparse
import datetime
import json
import platform
import re
import shlex
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("task_id")
    parser.add_argument("--macos-compat", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z]+-[0-9]{2}", args.task_id):
        parser.error("invalid task id")
    source = ROOT / "tasks" / args.task_id
    if not source.is_dir():
        parser.error("task directory does not exist")
    harbor = shutil.which("harbor")
    if not harbor:
        raise SystemExit("harbor executable not found")
    # Avoid '%' URL handling in Harbor/Compose, retaining the exact task contents.
    stage = Path(tempfile.mkdtemp(prefix=f"physics-{args.task_id}-harbor-", dir="/tmp"))
    task = stage / args.task_id
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"))
    if args.macos_compat:
        config = task / "task.toml"
        original = config.read_text(encoding="utf-8")
        needle = 'environment_mode = "separate"\nnetwork_mode = "no-network"'
        if needle not in original:
            raise SystemExit("expected verifier network declaration missing")
        config.write_text(original.replace(needle, 'environment_mode = "separate"\nnetwork_mode = "public"'), encoding="utf-8")
    mode = "harbor-macos-compat" if args.macos_compat else "harbor-linux"
    destination = ROOT / "runs" / args.task_id / mode
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for agent in ("oracle", "nop"):
        jobs = stage / "runs" / agent
        command = [harbor, "run", "-p", str(task), "-a", agent,
                   "--n-attempts", "1", "--n-concurrent", "1", "--max-retries", "0",
                   "--jobs-dir", str(jobs)]
        print("$ " + shlex.join(command), flush=True)
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(command, text=True)
        archive = destination / agent
        archive.mkdir(parents=True, exist_ok=True)
        if jobs.exists():
            shutil.copytree(jobs, archive, dirs_exist_ok=True)
        records.append({"agent": agent, "command": command, "returncode": result.returncode,
                        "started_utc": started, "archive": str(archive.relative_to(ROOT))})
    report = {"task_id": args.task_id, "host": platform.platform(), "temporary_task": str(task),
              "macos_verifier_network_override": args.macos_compat, "runs": records}
    output = destination / ("session-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    if any(record["returncode"] != 0 for record in records):
        raise SystemExit("Harbor exited unsuccessfully; original jobs have been archived")


if __name__ == "__main__":
    main()

exit_code=0
```

### 2026-11-16T16:23:38.569994+08:00

```bash
cat tasks/qft-02/instruction.md tools/build_qft02_truth.py
```

```text
# QFT-02：三体衰变相空间中的窄共振与干涉

研究一个质量为 `M` 的标量母粒子衰变为三个可区分标量粒子。采用教材相空间定义和 \(\hbar=c=1\)；把 \(s=(p_1+p_2)^2\) 作为 Dalitz 区域的一维投影，给定振幅
\[
\mathcal A(s)=g_0+\frac{g_1}{s-m_R^2+i m_R\Gamma_R}.
\]
对每个公开工况，计算完整三体相空间上的总宽度、相干干涉相对贡献，以及累计谱 \(d\Gamma/ds\) 的 10%、50%、90% 分位点。三体相空间投影的权函数为
\[
K(s)=\frac{\sqrt{\lambda(M^2,s,m_3^2)\lambda(s,m_1^2,m_2^2)}}s,
\quad s\in[(m_1+m_2)^2,(M-m_3)^2],
\]
并使用 \(d\Gamma/ds=K(s)|\mathcal A(s)|^2/(256\pi^3M^3)\)。

需要区分 \(|g_0+g_R|^2\) 与 \(|g_0|^2+|g_R|^2\)，不能把窄共振当作一个无宽度的 delta 函数；`decay-02`、`decay-03` 特意把窄峰放在相空间内部或靠近边界。所有输入在 `/app/data/model.json`，格式反馈在 `/app/data/feedback.py`。

输出 `/app/output/answer.json`，每个工况包含 `width`、`interference_fraction`、`s10`、`s50`、`s90`。分位点必须按次序位于物理区间。评分器与 60 位高精度独立积分真值比较：宽度占45%，干涉相对贡献占25%，三个分位点占30%。

Agent 使用 4 CPU、4 GiB、0 GPU，限时 1200 秒；verifier 120 秒。题包只需公开输入和数学工具，不需要网络、模型权重或 GPU。
"""Independent high-precision three-body phase-space integration."""
import json
from pathlib import Path
import time
import mpmath as mp

ROOT = Path(__file__).resolve().parents[1]
TASK = ROOT / 'tasks/qft-02'


def solve_case(case, precision=55):
    mp.mp.dps = precision
    M, m1, m2, m3 = [mp.mpf(str(case[key])) for key in ('M', 'm1', 'm2', 'm3')]
    mr, gamma = mp.mpf(str(case['mr'])), mp.mpf(str(case['gamma']))
    g0 = mp.mpc(str(case['g0'][0]), str(case['g0'][1]))
    g1 = mp.mpc(str(case['g1'][0]), str(case['g1'][1]))
    low, high = (m1 + m2) ** 2, (M - m3) ** 2
    span, center, scale = high - low, mr ** 2, mr * gamma

    # Unlike the reference's sine-squared endpoint map, this independent
    # integral uses the Breit-Wigner angle. Its Jacobian resolves the pole.
    def integrand(angle, coherent=True):
        s = center + scale * mp.tan(angle)
        first = (M ** 2 - (mp.sqrt(s) + m3) ** 2) * (M ** 2 - (mp.sqrt(s) - m3) ** 2)
        second = (s - (m1 + m2) ** 2) * (s - (m1 - m2) ** 2)
        pole = g1 / mp.mpc(s - center, scale)
        squared = abs(g0 + pole) ** 2 if coherent else abs(g0) ** 2 + abs(pole) ** 2
        return mp.sqrt(max(mp.mpf('0'), first * second)) / s * squared * scale / mp.cos(angle)**2

    lower = mp.atan((low-center)/scale)
    upper = mp.atan((high-center)/scale)
    knots = [lower, upper]
    for offset in (-100, -10, -1, 0, 1, 10, 100):
        s = center + offset * scale
        if low < s < high:
            knots.append(mp.atan((s-center)/scale))
    knots = sorted(set(knots))
    pieces = [mp.quad(integrand,[a,b]) for a,b in zip(knots[:-1],knots[1:])]
    cumulative = [mp.mpf(0)]
    for value in pieces:cumulative.append(cumulative[-1]+value)
    total = cumulative[-1]
    incoherent = sum(mp.quad(lambda t:integrand(t,False),[a,b]) for a,b in zip(knots[:-1],knots[1:]))
    quantiles = []
    residuals = []
    for probability in (mp.mpf('.1'), mp.mpf('.5'), mp.mpf('.9')):
        target = probability*total
        index = next(i for i in range(len(pieces)) if cumulative[i+1]>=target)
        start = knots[index]
        lo, hi = start, knots[index+1]
        angle = lo+(hi-lo)*(target-cumulative[index])/pieces[index]
        for _ in range(65):
            residual = cumulative[index]+mp.quad(integrand,[start,angle])-target
            if abs(residual/total)<mp.mpf('1e-30'):break
            if residual<0:lo=angle
            else:hi=angle
            candidate = angle-residual/integrand(angle)
            angle = candidate if lo<candidate<hi else (lo+hi)/2
        else:raise ArithmeticError('quantile convergence failed')
        quantiles.append(center+scale*mp.tan(angle))
        residuals.append(str(abs(residual/total)))
    return {
        'id': case['id'],
        'width': total / (256 * mp.pi ** 3 * M ** 3),
        'interference_fraction': (total - incoherent) / incoherent,
        's10': quantiles[0], 's50': quantiles[1], 's90': quantiles[2],
    }, residuals


def main():
    started=time.perf_counter()
    model = json.loads((TASK / 'environment/public/model.json').read_text(encoding='utf-8'))
    truth = {'cases': []};details=[]
    for case in model['cases']:
        value, residuals = solve_case(case)
        comparison,_ = solve_case(case,35)
        difference=max(abs(float(value[key])-float(comparison[key]))/max(abs(float(value[key])),1e-30) for key in value if key!='id')
        if difference>1e-25:raise ArithmeticError((case['id'],difference))
        truth['cases'].append({key: (float(value[key]) if key != 'id' else value[key]) for key in value})
        details.append({'id':case['id'],'relative_35_vs_55_digit_difference':difference,'cdf_residuals':residuals})
        print(case['id'], 'independent integration passed',flush=True)
    private = TASK / 'tests/private/truth.json'
    private.parent.mkdir(parents=True, exist_ok=True)
    private.write_text(json.dumps(truth, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    report={'method':'55-digit independent Breit-Wigner angle integration; 35-digit precision repeat; local safeguarded Newton with cached segment integrals',
            'cases':details,'elapsed_seconds':time.perf_counter()-started}
    (ROOT/'checks/qft-02-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(truth, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()

exit_code=0
```

### 2026-11-16T16:23:38.599671+08:00

```bash
cat runs/qft-01/harbor-macos-compat/oracle/2026-11-16__14-41-14/result.json
```

```text
{
    "id": "34b24853-01bc-4818-9d5f-51711a146f26",
    "started_at": "2026-11-16T14:41:14.856986",
    "updated_at": "2026-11-16T14:41:42.372776",
    "finished_at": "2026-11-16T14:41:42.372776",
    "n_total_trials": 1,
    "stats": {
        "n_completed_trials": 1,
        "n_errored_trials": 0,
        "n_running_trials": 0,
        "n_pending_trials": 0,
        "n_cancelled_trials": 0,
        "n_retries": 0,
        "evals": {
            "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                    {
                        "mean": 1.0
                    }
                ],
                "pass_at_k": {},
                "reward_stats": {
                    "reward": {
                        "1.0": [
                            "qft-01__jZAUwVc"
                        ]
                    }
                },
                "exception_stats": {}
            }
        },
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null
    }
}
exit_code=0
```

### 2026-11-16T16:27:12.860864+08:00

```bash
python3 -c 'from pathlib import Path; import json; print("\n".join(sorted(p.name for p in Path("tasks").iterdir() if p.is_dir()))); print("\n".join(str(p) for p in Path("checks").glob("*validation.md"))))'
```

```text
  File "<string>", line 1
    from pathlib import Path; import json; print("\n".join(sorted(p.name for p in Path("tasks").iterdir() if p.is_dir()))); print("\n".join(str(p) for p in Path("checks").glob("*validation.md"))))
                                                                                                                                                                                                   ^
SyntaxError: unmatched ')'

exit_code=1
```

### 2026-11-16T16:27:56.001190+08:00

```bash
rg -n '===== PDF PAGE|重整化群|标度|β函数|Landau|朗道|耦合常数|正则化|重正化' planning/source-notes/qft-all.txt
```

```text
2:===== PDF PAGE 1 =====
8:===== PDF PAGE 2 =====
17:===== PDF PAGE 3 =====
62:===== PDF PAGE 4 =====
106:===== PDF PAGE 5 =====
207:===== PDF PAGE 6 =====
255:2.3.5 重整化群
262:量纲标度变换群
264:重整化群方程的解.
316:===== PDF PAGE 7 =====
419:===== PDF PAGE 8 =====
422:===== PDF PAGE 9 =====
482:===== PDF PAGE 10 =====
521:===== PDF PAGE 11 =====
531:它们在空间中的距离可以有等号左边和右边两种表达（Landau 《场论》）
553:===== PDF PAGE 12 =====
586:===== PDF PAGE 13 =====
625:===== PDF PAGE 14 =====
658:平凡的）纤维丛，电荷在静电场中的运动就不再是抛物线，而变成悬链线（Landau《场论》）。
668:===== PDF PAGE 15 =====
720:===== PDF PAGE 16 =====
769:===== PDF PAGE 17 =====
805:===== PDF PAGE 18 =====
837:===== PDF PAGE 19 =====
853:可逆（Landau《量子力学（非相对论理论）》）。
869:===== PDF PAGE 20 =====
896:===== PDF PAGE 21 =====
923:===== PDF PAGE 22 =====
952:===== PDF PAGE 23 =====
990:===== PDF PAGE 24 =====
1026:===== PDF PAGE 25 =====
1056:===== PDF PAGE 26 =====
1094:===== PDF PAGE 27 =====
1131:===== PDF PAGE 28 =====
1193:===== PDF PAGE 29 =====
1225:===== PDF PAGE 30 =====
1253:===== PDF PAGE 31 =====
1290:===== PDF PAGE 32 =====
1326:===== PDF PAGE 33 =====
1363:===== PDF PAGE 34 =====
1390:===== PDF PAGE 35 =====
1427:===== PDF PAGE 36 =====
1451:===== PDF PAGE 37 =====
1482:===== PDF PAGE 38 =====
1506:===== PDF PAGE 39 =====
1550:===== PDF PAGE 40 =====
1577:===== PDF PAGE 41 =====
1611:===== PDF PAGE 42 =====
1646:===== PDF PAGE 43 =====
1676:===== PDF PAGE 44 =====
1706:===== PDF PAGE 45 =====
1736:===== PDF PAGE 46 =====
1758:===== PDF PAGE 47 =====
1793:===== PDF PAGE 48 =====
1820:===== PDF PAGE 49 =====
1851:===== PDF PAGE 50 =====
1887:===== PDF PAGE 51 =====
1905:===== PDF PAGE 52 =====
1927:===== PDF PAGE 53 =====
1965:===== PDF PAGE 54 =====
1991:===== PDF PAGE 55 =====
2032:===== PDF PAGE 56 =====
2065:===== PDF PAGE 57 =====
2094:===== PDF PAGE 58 =====
2130:===== PDF PAGE 59 =====
2182:，假定耦合常数入很小，则
2186:===== PDF PAGE 60 =====
2211:===== PDF PAGE 61 =====
2243:===== PDF PAGE 62 =====
2287:===== PDF PAGE 63 =====
2315:===== PDF PAGE 64 =====
2358:===== PDF PAGE 65 =====
2390:===== PDF PAGE 66 =====
2428:===== PDF PAGE 67 =====
2456:===== PDF PAGE 68 =====
2487:===== PDF PAGE 69 =====
2507:耦合常数很小时，可对生成泛函儆微扰展开
2512:===== PDF PAGE 70 =====
2543:===== PDF PAGE 71 =====
2575:===== PDF PAGE 72 =====
2603:===== PDF PAGE 73 =====
2633:===== PDF PAGE 74 =====
2667:===== PDF PAGE 75 =====
2705:===== PDF PAGE 76 =====
2735:===== PDF PAGE 77 =====
2774:===== PDF PAGE 78 =====
2802:===== PDF PAGE 79 =====
2841:===== PDF PAGE 80 =====
2915:其中入为耦合常数。注意这里定义的Green 函数、Feynman 传播子都与Srednicki 差一负号。
2921:===== PDF PAGE 81 =====
2957:===== PDF PAGE 82 =====
3002:===== PDF PAGE 83 =====
3041:===== PDF PAGE 84 =====
3084:===== PDF PAGE 85 =====
3124:===== PDF PAGE 86 =====
3177:===== PDF PAGE 87 =====
3219:===== PDF PAGE 88 =====
3291:===== PDF PAGE 89 =====
3328:===== PDF PAGE 90 =====
3394:===== PDF PAGE 91 =====
3444:===== PDF PAGE 92 =====
3489:===== PDF PAGE 93 =====
3530:===== PDF PAGE 94 =====
3561:===== PDF PAGE 95 =====
3596:===== PDF PAGE 96 =====
3612:故称重正化或重整化（renormalization）。如果把幸福从大众的定义“拥有的多”重新定义为
3635:理而言，点粒子图像是不合适的（远看是个点，近看可能是个球）。在P1 an ck标度，
3643:===== PDF PAGE 97 =====
3706:===== PDF PAGE 98 =====
3753:===== PDF PAGE 99 =====
3818:===== PDF PAGE 100 =====
3852:===== PDF PAGE 101 =====
3881:===== PDF PAGE 102 =====
3919:===== PDF PAGE 103 =====
3966:===== PDF PAGE 104 =====
4009:===== PDF PAGE 105 =====
4063:===== PDF PAGE 106 =====
4094:===== PDF PAGE 107 =====
4119:===== PDF PAGE 108 =====
4150:===== PDF PAGE 109 =====
4187:===== PDF PAGE 110 =====
4233:===== PDF PAGE 111 =====
4303:===== PDF PAGE 112 =====
4356:===== PDF PAGE 113 =====
4383:===== PDF PAGE 114 =====
4419:===== PDF PAGE 115 =====
4446:===== PDF PAGE 116 =====
4503:===== PDF PAGE 117 =====
4545:===== PDF PAGE 118 =====
4579:===== PDF PAGE 119 =====
4609:===== PDF PAGE 120 =====
4647:===== PDF PAGE 121 =====
4688:===== PDF PAGE 122 =====
4720:===== PDF PAGE 123 =====
4750:===== PDF PAGE 124 =====
4787:===== PDF PAGE 125 =====
4814:===== PDF PAGE 126 =====
4844:===== PDF PAGE 127 =====
4874:===== PDF PAGE 128 =====
4931:===== PDF PAGE 129 =====
4972:===== PDF PAGE 130 =====
5002:===== PDF PAGE 131 =====
5026:===== PDF PAGE 132 =====
5062:===== PDF PAGE 133 =====
5094:===== PDF PAGE 134 =====
5126:===== PDF PAGE 135 =====
5161:===== PDF PAGE 136 =====
5209:===== PDF PAGE 137 =====
5253:===== PDF PAGE 138 =====
5306:===== PDF PAGE 139 =====
5339:===== PDF PAGE 140 =====
5377:===== PDF PAGE 141 =====
5420:===== PDF PAGE 142 =====
5454:===== PDF PAGE 143 =====
5481:===== PDF PAGE 144 =====
5512:===== PDF PAGE 145 =====
5556:===== PDF PAGE 146 =====
5595:===== PDF PAGE 147 =====
5631:===== PDF PAGE 148 =====
5658:===== PDF PAGE 149 =====
5687:===== PDF PAGE 150 =====
5709:===== PDF PAGE 151 =====
5739:===== PDF PAGE 152 =====
5760:===== PDF PAGE 153 =====
5785:===== PDF PAGE 154 =====
5814:===== PDF PAGE 155 =====
5835:===== PDF PAGE 156 =====
5858:===== PDF PAGE 157 =====
5880:===== PDF PAGE 158 =====
5912:===== PDF PAGE 159 =====
5942:===== PDF PAGE 160 =====
5984:===== PDF PAGE 161 =====
6012:===== PDF PAGE 162 =====
6046:===== PDF PAGE 163 =====
6086:===== PDF PAGE 164 =====
6113:阶近似给出顶角，二阶近似给出树图过程，三阶近似给出单圈图。微扰展开可以按耦合常数
6120:===== PDF PAGE 165 =====
6159:===== PDF PAGE 166 =====
6196:===== PDF PAGE 167 =====
6222:===== PDF PAGE 168 =====
6244:===== PDF PAGE 169 =====
6279:===== PDF PAGE 170 =====
6307:===== PDF PAGE 171 =====
6344:===== PDF PAGE 172 =====
6372:===== PDF PAGE 173 =====
6392:===== PDF PAGE 174 =====
6432:===== PDF PAGE 175 =====
6467:===== PDF PAGE 176 =====
6528:===== PDF PAGE 177 =====
6581:===== PDF PAGE 178 =====
6632:===== PDF PAGE 179 =====
6677:===== PDF PAGE 180 =====
6805:===== PDF PAGE 181 =====
6866:===== PDF PAGE 182 =====
6920:===== PDF PAGE 183 =====
6949:===== PDF PAGE 184 =====
6974:===== PDF PAGE 185 =====
6993:===== PDF PAGE 186 =====
7022:===== PDF PAGE 187 =====
7077:===== PDF PAGE 188 =====
7111:===== PDF PAGE 189 =====
7153:===== PDF PAGE 190 =====
7189:===== PDF PAGE 191 =====
7248:===== PDF PAGE 192 =====
7294:===== PDF PAGE 193 =====
7310:===== PDF PAGE 194 =====
7347:===== PDF PAGE 195 =====
7399:===== PDF PAGE 196 =====
7426:===== PDF PAGE 197 =====
7462:===== PDF PAGE 198 =====
7494:===== PDF PAGE 199 =====
7529:===== PDF PAGE 200 =====
7571:===== PDF PAGE 201 =====
7579:2.3.5 重整化群
7586:看起来重整化常数似乎与重整化标度 无关。但是，若不采用最小减除方案，则重整化常
7606:===== PDF PAGE 202 =====
7609:虽然重整化常数z为重整化点 的函数，质量 m、耦合常数e和g乃至TY）都是山的函数，
7621:此即 Callan-Symanzik 重整化群方程。
7624:常数可取g=e，还可加入质量m，规范固定项A等等，重整化群方程就变成
7632:注意不同书符号约定差异。王正行、装忠平将H gm 定义成mpm，李灵峰将耦合常数定义
7638:===== PDF PAGE 203 =====
7640:（1）QED的β函数
7666:我们先将耦合常数用A表示，求导后再换回来（裘忠平）：
7683:B.>0，即耦合常数e随心增大而增大，看起来 QED 应该无渐近自由（渐近自由是随动量
7684:增大而减小，A是重整化标度，此处渐近自由尚不明确，更明确的分析见下节）。
7690:（2）QCD的β函数
7700:===== PDF PAGE 204 =====
7738:我们先将耦合常数用A表示，求导后再换回来（裘忠平）：
7759:（3）重整化群方程的解
7769:===== PDF PAGE 205 =====
7780:上节我们看到了渐近自由影子（g随重整化标度灿增大而减小），似乎冥冥之中注定要渐近
7803:===== PDF PAGE 206 =====
7812:2.3.6.2 量纲标度变换群
7814:样的变换也构成群，称为量纲标度变换群（胡瑶光《规范场论》）。在此变换下，无量纲量（如
7822:F（g）无量纲，这样定义的「”（P，M.g）量纲仍为d.记e=5，则在量纲标度变换群下，齐
7826:若只对动量p做量纲标度变换，而假定从不变，则
7831:===== PDF PAGE 207 =====
7844:与原始的重整化群方程（ ®
7848:此式不含重整化标度从，只有单纯的正则量纲效应。因相互作用，才使标度行为偏离正则
7850:2.3.6.3 重整化群方程的解
7862:===== PDF PAGE 208 =====
7905:===== PDF PAGE 209 =====
7938:===== PDF PAGE 210 =====
7980:===== PDF PAGE 211 =====
8008:===== PDF PAGE 212 =====
8045:===== PDF PAGE 213 =====
8066:===== PDF PAGE 214 =====
8103:===== PDF PAGE 215 =====
8132:===== PDF PAGE 216 =====
8164:===== PDF PAGE 217 =====
8190:===== PDF PAGE 218 =====
8215:===== PDF PAGE 219 =====
8244:===== PDF PAGE 220 =====
8265:===== PDF PAGE 221 =====
8289:===== PDF PAGE 222 =====
8327:===== PDF PAGE 223 =====
8357:===== PDF PAGE 224 =====
8389:===== PDF PAGE 225 =====
8421:===== PDF PAGE 226 =====
8445:===== PDF PAGE 227 =====
8449:介子换成 Higgs 粒子。耦合常数C。将在下一小节确定。
8475:===== PDF PAGE 228 =====
8493:===== PDF PAGE 229 =====
8516:===== PDF PAGE 230 =====
8536:===== PDF PAGE 231 =====
8569:===== PDF PAGE 232 =====
8595:===== PDF PAGE 233 =====
8627:===== PDF PAGE 234 =====
8655:===== PDF PAGE 235 =====
8714:===== PDF PAGE 236 =====
8749:===== PDF PAGE 237 =====
8760:2m（见3.2.3节），可得 Yukawa 耦合常数
8777:===== PDF PAGE 238 =====
8801:===== PDF PAGE 239 =====
8827:===== PDF PAGE 240 =====
8853:===== PDF PAGE 241 =====
8875:代入v Zmr，可得 Yukawa 耦合常数
8878:===== PDF PAGE 242 =====
8898:===== PDF PAGE 243 =====
8919:===== PDF PAGE 244 =====
8955:===== PDF PAGE 245 =====
8977:===== PDF PAGE 246 =====
9022:===== PDF PAGE 247 =====
9053:===== PDF PAGE 248 =====
9134:===== PDF PAGE 249 =====
9261:===== PDF PAGE 250 =====
9300:===== PDF PAGE 251 =====
9334:===== PDF PAGE 252 =====
9372:===== PDF PAGE 253 =====
9415:===== PDF PAGE 254 =====
9448:===== PDF PAGE 255 =====
9479:===== PDF PAGE 256 =====
9505:===== PDF PAGE 257 =====
9534:===== PDF PAGE 258 =====
9556:===== PDF PAGE 259 =====
9598:===== PDF PAGE 260 =====
9636:===== PDF PAGE 261 =====
9676:===== PDF PAGE 262 =====
9679:===== PDF PAGE 263 =====
9698:Landau
9773:===== PDF PAGE 264 =====
9851:===== PDF PAGE 265 =====
9980:===== PDF PAGE 266 =====

exit_code=0
```

### 2026-11-16T16:28:28.554832+08:00

```bash
python3 -c 'from pathlib import Path; print("\n".join(sorted(p.name for p in Path("tasks").iterdir() if p.is_dir())))'
```

```text
ed-01
ed-02
ed-03
gr-01
gr-02
gr-03
qft-01
qft-02
qm-01
qm-02
qm-03
sp-01
tm-01
tm-02
tm-03

exit_code=0
```

### 2026-11-16T16:28:28.608567+08:00

```bash
cat planning/work-order-tm03.md
```

```text
# tm-03 实际制作任务

只写 `tasks/tm-03/`、`tools/*tm03*`、`checks/tm-03*`。制作与 tm-01 弹簧链辨识、tm-02 中心势进动均不同的理论力学题；建议刚体对称陀螺完整重力矩进动/章动与分离根分类，或教材证据更扎实的非线性刚体方向。来源用户《理论力学学习指导与习题解析》PDF及 `planning/source-notes/tm-all.txt`，先定位原页并核对实际方程、符号和答案，不臆造页码。

按 tm-01/02 Harbor 结构交付完整任务、公开交互反馈、简单但正确基线、参考程序、教师原版质量评分函数、独立多精度真值、物理分支与退化情况、实际 Linux Docker 校准和公平性来源记录。单一综合任务含多工况不凑题。4CPU4GB0GPU，agent1200/verifier120秒。用户已授权长程执行，直接做完不索要权限；只使用 Mac 本地 Docker，不触碰远程推理项目，不推GitHub。实际命令显式展示并日志 `checks/tm-03-command-log.md`。

exit_code=0
```

### 2026-11-16T16:28:28.637722+08:00

```bash
sed -n 7570,7805p planning/source-notes/qft-all.txt
```

```text

===== PDF PAGE 201 =====
细推物理须行乐
Z=1+0Z=1-
8T'€
-IC,+Cl
对SU3）群：CP
3C=3=2=1-813
872E 3
2.3.5 重整化群
最小减除下2=1--82
8T'E
2C+CAJ，2=1-82
87'E
-Cr,Z=1+
872g
看起来重整化常数似乎与重整化标度 无关。但是，若不采用最小减除方案，则重整化常
数Z中将含有In（4元）， In Ac,YE等。一般Z是从的函数。QED 中，M。=2,Zim，
es =Z,Z 'Zs?e,2=Z5'2，所以m, e,A也是从的函数。
重整化方案或减除点的选择有一定的任意性，然而物理结果应该与重整化方案的选择无关
（李灵峰《量子场论》）。那么，不同的重整化方案之间什么关系？这就是本节要回答的问题。
足封闭性e‘eh =ehth =e”，结合律e"（e”e^）=（e'e”）e^，且有恒元e°，逆元e’，故e‘构
成群，称为重整化点变换群（胡瑶光《规范场论》）。
2.3.5.1 正规顶角的重整化
由于 Lagrangian 中每种场的自由部分都是二次型（王正行《简明量子场论》），所以为使
=公A；QCD中，除了YB，坐，还可定义裸鬼CB=2.C.
Green 函数是场量之积的真空期待值（胡瑶光《规范场论》），它与重整化的Green 函数之间
关系为
Gï(P„§8)=ZGФ(„„18)
而正规顶角之间关系为
T台（P.，8B）=Z 2TK（P.，4.g）
注意 Green 函数按Z2变换，而正规顶角按Z2变换。这让我们想起推导 QCD 的 Feynman
规则时遇到的问题：若场量按 Fourier 正变换，则顶角函数按 Fourier 逆变换；反之，若场量
按 Fourier 逆变换，则顶角函数按 Fourier 正变换。
193

===== PDF PAGE 202 =====
为往圣继绝学
2.3.5.2 Callan-Symanzik 方程
虽然重整化常数z为重整化点 的函数，质量 m、耦合常数e和g乃至TY）都是山的函数，
但Z2与「”相乘所得的TY却与 无关，即TY在重整化变换 =e' 下是不变的。
于是，方程T台（P.8日）=Z2T”（P.，4.g）对 的导数给出
0-4T - 2”
-18L.rw+22dF（）
所以
2 0
定义
O4
并在方程两边乘以A，得
（ND
-np）T=0
此即 Callan-Symanzik 重整化群方程。
以上只讨论了最简单的情况。实际上，还可以加入 Fermion场，则z’ ， 2，
2，耦合
常数可取g=e，还可加入质量m，规范固定项A等等，重整化群方程就变成
（M1
Tpe ae
•+fim m
其中
B.=4g
aınzy2
дн
注意不同书符号约定差异。王正行、装忠平将H gm 定义成mpm，李灵峰将耦合常数定义
为入.
2.3.5.3 beta 函数
注意与B（p.q）函数区分，那是积分函数。这里B函数带有偏导数，属于微分函数。
194

===== PDF PAGE 203 =====
细推物理须行乐
（1）QED的β函数
已知e=Z,Z：'Z:ie=Ze. 在d维g-4g=gB，有e=A'‘Z'Z.Zje =A'Z:ea
B.=4a7
-е - не
dInZe
дu
利用近似（1+x）®c1+ar,In（1+x） ～x
准确到单圈有2=22 =1-元
2лE
8,23=1-20
ЗлЕ
（Greiner 及胡瑶光），可得
Z。=ZZ223=23=11-
2a
－）2:1+
1 2a
3n8
2 3лЕ
1 2o
12a
In Ze~In（l+
一）2-
一＝
2 3m8
237E
127E
我们先将耦合常数用A表示，求导后再换回来（裘忠平）：
p.=-
Ее-не
2
12;2£
＝ーー
20-HO12T%69
1 a8Z2u9
дu
etegzu
ー=18
12m'E
12 ~
12г
8-20
→
12г
B.>0，即耦合常数e随心增大而增大，看起来 QED 应该无渐近自由（渐近自由是随动量
增大而减小，A是重整化标度，此处渐近自由尚不明确，更明确的分析见下节）。
思考：£为无穷小，其倒数为无穷大，（1+x）~1+ax成立条件是 x 为无穷小（而非无穷
大）、炒件ム（-30）321+520施成立？ 号外二光天労大、隅不二種薬労高肉天労大：
2 3m8
高阶无穷大竞被舍弃了！这种小把戏看起来有些耍流氓，不过，既然1+2+3+4+⋯=-
都能行，这样做似乎也无可厚非。
（2）QCD的β函数
将QED 中的e换成g，可得
8=4*ZZ22386=41 2288
Ba=Hop
照=-：
dInZg
28-48
дн
195

===== PDF PAGE 204 =====
为往圣继绝学
只不过此时
2=1~-8
8T'E
_(C,+C,). 7,=1-8
8T'€
Cp. 7, =1+-8
2z=Z7¡Z=7ş=11-8
8元g
- (G,+C,)|II- 8
87E
CTYI+8’
-(c,-
8T'E
8л'є
=+C)I[I+8
8元'g
_ CH1II-1 8º
287'E
=1-%
8П'E
(C,+C)+8?
-Cp-
8TT'E
18'
2 87'€
-1-8
8П'E
|C,+=
2
6
-CA-
=n,I1
3
InZz=In[1-8,1
8N 8
87'E
我们先将耦合常数用A表示，求导后再换回来（裘忠平）：
Bs=-
8-1g-
&=_!
8’
28-18 gu
=§8-н81- 83 ($C-3n,,„(Zн*
=-6
88
=8-H8|-÷
8Tỉ €
=-으
) 28-8188
-8-318
--< 870
-n,JF）］
1622（11-2
3n，）=~83 33-2n，
可見・見要1, 516、0日%＝ル93く0.欄合締数g脳よ物大面線小、可以鏡期、送祥的
理论将具有渐近自由。实际上，n，依赖于动量转移。9>m，，则n， =6（王正行《简明
量子场论》）。
（3）重整化群方程的解
定X8三11一会川、0，=88
，则及=4
-＝ーー
1672 （1-
）化为
1.0g3
分离变量，得
196

===== PDF PAGE 205 =====
细推物理须行乐
_ BoInu-Bomn1=
a, (٨)
其中A为具有动量量纲的参数。解出8。，得
a,=
a,(1)
47
A2
可见，Q。随必增大而藏小。
2.3.6 渐近自由
上节我们看到了渐近自由影子（g随重整化标度灿增大而减小），似乎冥冥之中注定要渐近
自由。现在，我们把这幅画描清晰些：如g随动量p增大而减小，那就是真正的渐近自由了！
2.3.6.1 正规顶角的量纲
QED中，我们曾讨论过：在d维，作用量量纲为［PJ® =1，Lagrangian 密度量纲［L］“=［P］”；
矢量场量纲［P），旋量场量纲［P：设0=
2e后，e为纯数，从具有动量量纲。
回到现在，正规顶角的生成泛函的树图近似为作用量，故正规顶角生成泛函量纲为［PJ=1
（有的书说成量纲为0，其实并非量纲等于0，而是等于动量的0次幂）。
6A（x）=8（x-X0=」
64（×）
（27）/e ）（裘忠平《现代量子场论导引》，e指数无量纲，
所以6函数具有动量（d次幂）量纲！做一次泛函微商，动量量纲幂次增加d：每个胶子场
aly（x）量纲
64（x）
бу(x)
2，于是正规顶角
T（X,L,M）=
S"T[4,4]
量纲为［P］
变换关系
2 =［P］%（x）（胡瑶光《规范场论》）．再由T（x）与T（P）的 Fourier
197

===== PDF PAGE 206 =====
为往圣继绝学
可知［乙］“［T”（p）］=［L］”“［T”（x）］，所以

exit_code=0
```

### 2026-11-16T16:29:48.173701+08:00

```bash
python3 -c 'from pathlib import Path; import json; print("\n".join(f"{p.name}: calibrated={(Path(\"checks\")/(p.name+\"-calibration.json\")).exists()}" for p in sorted(Path("tasks").iterdir()) if p.is_dir()))'
```

```text
  File "<string>", line 1
    from pathlib import Path; import json; print("\n".join(f"{p.name}: calibrated={(Path(\"checks\")/(p.name+\"-calibration.json\")).exists()}" for p in sorted(Path("tasks").iterdir()) if p.is_dir()))
                                                                                          ^
SyntaxError: unexpected character after line continuation character

exit_code=1
```

### 2026-11-16T16:31:16.459878+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=False checks=0 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=False nop=False

exit_code=0
```

### 2026-11-16T16:33:10.510376+08:00

```bash
pdftoppm -f 203 -l 205 -scale-to 1400 -png '/Users/ai4s/Downloads/量子场论试题详解（凡人看得懂的量子场论  非211高校适用）.pdf' tmp/pdfs/qft03-source
```

```text

### 2026-11-16T16:33:10.512168+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=False checks=0 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=False nop=False

exit_code=0
```
Fontconfig error: Cannot load default config file: File not found

### 2026-11-16T16:33:10.579047+08:00

```bash
sed -n 1,100p checks/tm-03-validation.md
```

```text
sed: checks/tm-03-validation.md: No such file or directory

exit_code=1
```

### 2026-11-16T16:33:10.611397+08:00

```bash
sed -n 1,100p checks/gr-03-validation.md
```

```text
# gr-03 数值与评分验证

2026-11-16，本地 Docker Linux aarch64、Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0，4CPU、4GB、断网、0GPU。数值复用镜像 `theory-physics-ed01:dev`，依赖与本题一致。

|产物|原始误差（百分点）|质量分|程序耗时|
|---|---:|---:|---:|
|Newton/零偏差基线|73.77142297495756|0|0.04879秒|
|完整参考|9.778272072498907e-12|1|0.04156秒|
|等价顺序|9.778272072498907e-12|1|检查内|
|实质错解|85|0|检查内|
|漏一条分支|3.7500000000097335|0.94917|检查内|
|重复一条分支|2.500000000009749|0.96611|检查内|
|丢弃不稳定模负号|4.90333391889086|0.93353|检查内|
|混淆时间参数|4.551162940339232|0.93831|检查内|

14项检查全部通过：课程函数摘要、独立真值匹配、参考改善、端点一致、基线0/参考1、顺序等价、实质错解、漏态、多态、频率符号、时间参数、非法格式、实际test.sh参考/空提交入口、公开反馈。完整记录 `checks/gr-03-calibration.json`。原始指标容差1e-5。

独立75位有效势验证：分支数量0/0/1/2/2/2/2/2；正规方程残差小于3.30e-74，驻点残差小于2.08e-75，四速度归一化残差小于1.11e-75。ISCO二阶导数在高精度阈值内为零。真值用多项式根和有效势自动高精度导数，不导入参考闭式频率核心。原始数据 `checks/gr-03-truth-validation.json`。

Harbor oracle/nop 尚未在此子任务执行，由主流程统一运行。课程正式三次Codex结果尚未运行；外部相近benchmark检索在冻结前补。上述参考数值不是正式智能体测评成绩。

复核时运行：

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-ed01:dev python tools/build_gr03_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-ed01:dev python tools/run_gr03_checks.py
```

exit_code=0
```

exit_code=0
```

### 2026-11-16T16:34:15.148063+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=False checks=0 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=False nop=False

exit_code=0
```

### 2026-11-16T16:36:22.513240+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=False checks=0 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=True nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=True nop=True

exit_code=0
```

### 2026-11-16T16:39:14.974653+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=True checks=16 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=True nop=True
gr-04 calibrated=False checks=0 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=True nop=True

exit_code=0
```

### 2026-11-16T16:39:15.039425+08:00

```bash
rg --files tasks/qft-03 tasks/ed-03 tasks/gr-04 tasks/qm-04
```

```text
rg: tasks/qft-03: No such file or directory (os error 2)
rg: tasks/qm-04: No such file or directory (os error 2)
tasks/ed-03/task.toml
tasks/gr-04/environment/public/physics.py
tasks/gr-04/environment/public/feedback.py
tasks/ed-03/environment/public/metric.json
tasks/ed-03/environment/public/physics.py
tasks/ed-03/environment/public/start.py
tasks/ed-03/environment/public/feedback.py
tasks/ed-03/environment/public/model.json
tasks/ed-03/environment/Dockerfile
tasks/ed-03/environment/requirements.txt
tasks/ed-03/instruction.md
tasks/gr-04/solution/solve.py
tasks/gr-04/solution/solver_core.py
tasks/gr-04/solution/baseline.py
tasks/ed-03/solution/solve.py
tasks/ed-03/solution/solver_core.py
tasks/ed-03/solution/README.md
tasks/ed-03/solution/solve.sh
tasks/ed-03/solution/baseline.py
tasks/gr-04/tests/score.py
tasks/gr-04/tests/development_cases.py
tasks/ed-03/tests/score.py
tasks/ed-03/tests/test.sh
tasks/ed-03/tests/metric.json
tasks/ed-03/tests/private/truth.json
tasks/ed-03/tests/quality_score.py
tasks/ed-03/tests/development_cases.py

exit_code=2
```

### 2026-11-16T16:41:54.600765+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=True checks=16 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=True nop=True
gr-04 calibrated=False checks=0 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=True nop=True

exit_code=0
```

### 2026-11-16T16:41:54.659735+08:00

```bash
cat checks/ed-03-validation.md
```

```text
# ed-03 Linux 开发验证

日期2026-11-16。本记录为开发验证，不是课程指定Codex正式测评。

本地Docker Desktop Linux aarch64，Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0。4CPU、4GiB、断网、0GPU，未连接远程推理服务器。

| 方案 | 原始误差（百分点） | 课程质量分 | Linux耗时 |
|---|---:|---:|---:|
| 强约束封闭边界近似 | 57.21562733781993 | 0 | 0.108秒 |
| 完整介质边界参考解 | 4.005711247129106e-13 | 1 | 0.114秒 |
| 独立高精度径向积分答案 | 0 | 1 | 独立计算 |
| 所有芯层功率比例误设为1 | 11.3692 | 0.8013 | 检查运行 |
| 群折射率误设为相折射率 | 6.3907 | 0.8883 | 检查运行 |
| TE/TM标签互换 | 10.1572 | 0.8225 | 检查运行 |

独立65位真值使用原始Bessel边界场行列式、频率对称微扰和芯内/外径向能流积分；未导入参考核心。六工况模式总数为0、2、2、4、6、4。直接径向积分与闭式范数最大差2.38e-66；群折射率差分与隐式导数最大差6.30e-35。真值生成总耗时256秒，属于离线出题制备，实际参考解与verifier远低于登记限时。

首次真值工具使用重复高精度二分求根，约3分钟未完成，已停止该单独本地容器，改用保括区间Illinois方法并加入逐模进度；最终实际成功运行才计入上述结果。原始停止命令及重新运行日志均保存。

16项检查全部通过：参考改善/独立真值/端点一致、基线0参考1、模式重排、独立替代解满分、合法错解/漏模/多模/TE-TM混淆/能流/群相折射率处罚、非法值拒绝、实际test.sh参考1空0、公开反馈有效、教师quality_score逐字节保持不变。详见ed-03-calibration.json及ed-03-truth-validation.json。

Harbor oracle/nop由主代理补跑；正式Codex三次运行未执行，不将开发参考结果冒充模型成绩。复现命令和实际输出见ed-03-command-log.md。

exit_code=0
```

### 2026-11-16T16:42:41.623003+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=True checks=16 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=True nop=True
gr-04 calibrated=False checks=0 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=True nop=True

exit_code=0
```

### 2026-11-16T16:42:41.687460+08:00

```bash
rg --files planning
```

```text
planning/source-notes/ed-sol-all.txt
planning/source-notes/gr-mid-front.txt
planning/source-notes/sp-front.txt
planning/source-notes/gr-down-front.txt
planning/source-notes/gr-up-front.txt
planning/source-notes/qm-sol-all.txt
planning/source-notes/qft-all.txt
planning/source-notes/qm-sol-front.txt
planning/source-notes/qft-front.txt
planning/source-notes/sp-sol-all.txt
planning/source-notes/ed-front.txt
planning/source-notes/gr-mid-all.txt
planning/source-notes/tm-front.txt
planning/source-notes/sp-sol-front.txt
planning/source-notes/ed-sol-front.txt
planning/source-notes/tm-all.txt
planning/source-notes/gr-down-all.txt
planning/implementation-qft.md
planning/work-order-gr02.md
planning/work-order-gr03.md
planning/gr-candidate-evidence.md
planning/work-order-ed03.md
planning/work-order-qm03.md
planning/work-order-ed02.md
planning/work-order-qm02.md
planning/implementation-gr.md
planning/work-order-qm04-tm04.md
planning/work-order-tm03.md

exit_code=0
```

### 2026-11-16T16:44:04.989956+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=True checks=16 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=True nop=True
gr-04 calibrated=False checks=0 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=True nop=True

exit_code=0
```

### 2026-11-16T16:44:05.054415+08:00

```bash
cat tools/init_task_shell.py
```

```text
"""Copy only the common, pinned Harbor shell for a newly authored task."""
import argparse
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('task_id');args=parser.parse_args()
destination=ROOT/'tasks'/args.task_id
destination.mkdir(parents=True,exist_ok=True)
for relative in ('environment/Dockerfile','environment/requirements.txt','environment/.dockerignore',
                 'solution/solve.sh','tests/test.sh','task.toml'):
    target=destination/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        raise SystemExit(f'refusing to overwrite {target}')
    shutil.copyfile(ROOT/'tasks/qm-01'/relative,target)
    if relative=='task.toml':
        target.write_text(target.read_text().replace('qm-01',args.task_id),encoding='utf-8')
(destination/'environment/public').mkdir(exist_ok=True)
(destination/'tests/private').mkdir(exist_ok=True)
shutil.copyfile(ROOT/'tools/course_quality_score.py',destination/'tests/quality_score.py')
print(f'Created common Harbor shell: {args.task_id}')

exit_code=0
```

### 2026-11-16T16:45:27.779030+08:00

```bash
python3 tools/task_status.py
```

```text
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=True checks=16 oracle=False nop=False
ed-04 calibrated=False checks=0 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=True nop=True
gr-04 calibrated=False checks=0 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qft-03 calibrated=False checks=0 oracle=False nop=False
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=True nop=True

exit_code=0
```

### 2026-11-16T16:45:27.867087+08:00

```bash
rg --files tasks/qft-03
```

```text
tasks/qft-03/task.toml
tasks/qft-03/environment/Dockerfile
tasks/qft-03/environment/requirements.txt
tasks/qft-03/solution/solve.sh
tasks/qft-03/tests/test.sh
tasks/qft-03/tests/quality_score.py

exit_code=0
```
