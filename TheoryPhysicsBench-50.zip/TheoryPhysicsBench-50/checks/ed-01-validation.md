# ed-01 开发验证记录

日期：2026-11-16。

## 已执行的本地数值验证

macOS 26.6.2 arm64，Python 3.12.10。独立真值使用标准库 Decimal，70 位精度，L=1702，最差测距的自力绝对尾界约 9.9061e-33，边界残差最大 2e-66。两组竞争材料各有一个径向稳定平衡点；普通介质球无根。详见 `ed-01-truth-validation.json`。

实际运行 `python3 tools/run_ed01_checks.py --calibrate`，14 项检查全部通过：

| 产物 | 原始误差/百分点 | 课程质量分 |
|---|---:|---:|
| 偶极基线 | 65.68074303839856 | 0 |
| 完整多极参考 | 8.157061168934074e-10 | 1 |
| 工况/测距合法换序 | 与参考相同 | 1 |
| 全部物理量填零且不报根 | 93.33333333333333 | 0 |
| 能量漏 1/2 因子 | 35.000000000725386 | 0.46711930497067455 |
| 自力符号错误 | 45.00000000008597 | 0.31486767782878106 |
| 漏一个平衡点 | 6.666666667467843 | 0.8984989152324687 |
| 一个稳定性分类错误 | 2.000000000815706 | 0.9695496745696742 |
| 缺工况、重复距离、布尔数值 | 无效 | 0 |

参考解耗时约 0.1516 秒，基线约 0.0569 秒。实际 `test.sh` 入口参考得 1，缺失答案文件得 0。公开反馈同时检查成功。详见 `ed-01-calibration.json`。

## Linux / Harbor 验证

主代理随后在 Docker Linux aarch64、Python 3.12.13、4 CPU、4 GB、断网条件下执行独立真值与评分检查，14 项全部通过，原始指标与上述本地数值一致。Linux 基线耗时 0.02767 秒，参考解 0.12192 秒；calibration.json 已更新为实际 Linux 记录。执行命令：

```bash
docker build -t theory-physics-ed01:dev tasks/ed-01/environment
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 \
  -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 \
  --mount "type=bind,source=$PWD,target=/work" -w /work \
  theory-physics-ed01:dev python tools/build_ed01_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 \
  -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 \
  --mount "type=bind,source=$PWD,target=/work" -w /work \
  theory-physics-ed01:dev python tools/run_ed01_checks.py
```

Harbor 0.24.0 单次、单并发、无重试的 oracle 得 1、nop 得 0，均无异常，各耗时约 27 秒。记录分别在 runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ 和 runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/。命令为 `python3 tools/run_harbor_local_checks.py ed-01 --macos-compat`。

临时 ASCII 副本避开课程路径的百分号解析问题；仅临时副本的 verifier 网络改为 public，以兼容 Docker Desktop。正式题包保留 no-network。LiteLLM 成本表下载超时后回退本地表，未影响两个 trial 的运行与评分。正式课程 Codex 三次运行在题集冻结后执行。
