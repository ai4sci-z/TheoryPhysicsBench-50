
### 2026-11-16T22:09:25.635397+08:00

```bash
docker run --rm --cpus 4 --memory 4g --network none --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/workspace' -w /workspace theory-physics-qft04:dev python3 tools/build_qft05_truth.py
```

```text
[
  {
    "id": "vertex-01",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": "1.0"
  },
  {
    "id": "vertex-02",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": "1.0"
  },
  {
    "id": "vertex-03",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": "1.0"
  },
  {
    "id": "vertex-04",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": "1.0"
  },
  {
    "id": "vertex-05",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": "1.0"
  },
  {
    "id": "vertex-06",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": "1.0"
  },
  {
    "id": "vertex-07",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": null
  },
  {
    "id": "vertex-08",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": null
  },
  {
    "id": "vertex-09",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": null
  },
  {
    "id": "vertex-10",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": null
  },
  {
    "id": "vertex-11",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": null
  },
  {
    "id": "vertex-12",
    "precision_digits": 55,
    "analytic_inner_integral": true,
    "normalized_F2_zero_regulator": null
  }
]

exit_code=0
```
