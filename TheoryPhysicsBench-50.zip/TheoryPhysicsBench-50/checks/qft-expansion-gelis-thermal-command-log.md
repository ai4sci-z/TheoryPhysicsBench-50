
### 2026-11-16T18:22:01.820913+08:00

```bash
rg -n '^===== PDF PAGE (16[0-9]|17[0-9]|18[0-9]|19[0-1]|20[8-9]|21[0-9]|22[0-9]|23[0-5])|^Problem (69|70|71|72|73|74|75|76|80|81|82)|Banks|Center|Photon|Langevin|Anderson|Schwinger' planning/source-notes/qft-gelis-all.txt
```

```text
54:29 Complex Langevin Equation 123
74:47 Banks–Zaks Fixed Points 191
88:56 Photon Decoupling Identity 221
103:69 Banks–Casher Relation 283
106:72 Center Symmetry and Deconfinement 293
107:73 Photon Hard Thermal Loop from Classical Particles 297
113:79 Correlations in the Schwinger Mechanism 324
114:80 Schwinger Mechanism from Bogoliubov Transformations 331
116:82 Anderson Localization 347
117:83 Scaling Theory of Anderson Localization 350
1223:Figure 1.3 Left: domains Ω1 andΩ2 with mutual space-like separations. Center and right:
2152:This is the celebrated result obtained by Schwinger in 1948. As of 2019, the QED calculation
2472:Ψ(0)β ⏐⏐V⏐⏐Ψ(0)α ⟩. This equation, known as the Lipmann–Schwinger equation, shows
2563:11.b The Lipmann–Schwinger equation (1.56) can be solved iteratively, leading to the
5146:56. Photon Decoupling Identity The goal of this problem is to prove a relationship between
9286:Kubo–Martin–Schwinger Symmetry
9291:a property known as Kubo–Martin–Schwinger (KMS) symmetry. One of its consequences is
9330:Schwinger--Keldysh Formalism
9331:The Schwinger–Keldysh formalism provides an alternative way of formulating perturbation
9387:When formulated in coordinate space, the Schwinger–Keldysh formalism can also cope with
9404:This formula shows that any graph in the Schwinger–Keldysh formalism may be obtained
9407:Schwinger–Keldysh formalism atT = 0 is identical to Cutkosky’s cutting rules.
9422:===== PDF PAGE 160 =====
9425:• Problem 69 derives the Banks–Casher relation, which relates the expectation value of
9437:Problem 73 using classical charged particles and a kinetic equation that describes the
9452:• The next two problems are devoted to the study of the Schwinger mechanism in scalar
9455:Problem 80 using Bogoliubov transformations.
9460:• Problem 82 proposes a ﬁeld theory approach to Anderson localization, namely the fact
9465:===== PDF PAGE 161 =====
9467:69. Banks–Casher Relation Quantum chromodynamics, if restricted to the up and down
9474:relationship, known as the Banks–Casher relation, between the value of the chiral condensate⟨
9529:===== PDF PAGE 162 =====
9631:===== PDF PAGE 163 =====
9673:This relation is known as the Banks–Casher relation. The left hand side is a quantity known
9677:theory breaks chiral symmetry. The Banks–Casher formula relates the chiral condensate, which
9681:Source: Banks, T. and Casher, A. (1980), Nucl Phys B 169: 103.
9691:===== PDF PAGE 164 =====
9731:===== PDF PAGE 165 =====
9778:===== PDF PAGE 166 =====
9809:===== PDF PAGE 167 =====
9843:===== PDF PAGE 168 =====
9887:===== PDF PAGE 169 =====
9969:===== PDF PAGE 170 =====
10029:===== PDF PAGE 171 =====
10052:72. Center Symmetry and Deconfinement The goal of this problem is to study an
10080:===== PDF PAGE 172 =====
10121:===== PDF PAGE 173 =====
10163:===== PDF PAGE 174 =====
10208:===== PDF PAGE 175 =====
10250:===== PDF PAGE 176 =====
10252:73. Photon Hard Thermal Loop from Classical Particles In this problem, we use
10256:Problem 74).
10292:===== PDF PAGE 177 =====
10381:===== PDF PAGE 178 =====
10439:===== PDF PAGE 179 =====
10511:===== PDF PAGE 180 =====
10552:===== PDF PAGE 181 =====
10607:===== PDF PAGE 182 =====
10667:===== PDF PAGE 183 =====
10710:===== PDF PAGE 184 =====
10753:===== PDF PAGE 185 =====
10818:===== PDF PAGE 186 =====
10862:===== PDF PAGE 187 =====
10912:===== PDF PAGE 188 =====
10971:===== PDF PAGE 189 =====
11002:===== PDF PAGE 190 =====
11074:===== PDF PAGE 191 =====
11497:The labels + and − on each side of the cut are the standard Schwinger–Keldysh notation for
11693:functions in the Schwinger–Keldysh formalism, with a modiﬁed off-diagonal propagator
11696:constructed with these modiﬁed Schwinger–Keldysh rules (and the logarithm ofF[z] is the sum
11697:of all these vacuum graphs that are connected). This modiﬁcation of the Schwinger–Keldysh
11703:Schwinger–Keldysh formalism, as a consequence of unitarity. However, this property applies
11715:As we have discussed above, this is the generating functional for the modiﬁed Schwinger–
11740:function in the modiﬁed Schwinger–Keldysh formalism. Note that this expression is valid to
11798:79. Correlations in the Schwinger Mechanism The Schwinger mechanism is a vacuum
11868:static external ﬁeld, this is the scalar QED analogue of the Schwinger mechanism (by which
11920:the vacuum graphs in a modiﬁed Schwinger–Keldysh formalism (in which the off-diagonal
11925:possible assignments for the + and − Schwinger–Keldysh vertices. This sum can be organized
11967:more explicit,T+ satisﬁes a Lipmann–Schwinger equation of the form
11980:following Lipmann–Schwinger equation:
11994:Moreover, the retarded propagator and its complex conjugate are related to the Schwinger–
12021:expression for the reverse situation). Using the Lipmann–Schwinger equations forTR andT∗R
12076:===== PDF PAGE 208 =====
12135:===== PDF PAGE 209 =====
12162:80. Schwinger Mechanism from Bogoliubov Transformations The goal of this problem
12179:===== PDF PAGE 210 =====
12227:===== PDF PAGE 211 =====
12272:===== PDF PAGE 212 =====
12329:===== PDF PAGE 213 =====
12374:===== PDF PAGE 214 =====
12440:===== PDF PAGE 215 =====
12484:===== PDF PAGE 216 =====
12549:===== PDF PAGE 217 =====
12603:===== PDF PAGE 218 =====
12652:===== PDF PAGE 219 =====
12705:===== PDF PAGE 220 =====
12733:===== PDF PAGE 221 =====
12810:===== PDF PAGE 222 =====
12935:===== PDF PAGE 223 =====
12944:Problem 80.)
13012:===== PDF PAGE 224 =====
13052:===== PDF PAGE 225 =====
13075:82. Anderson Localization In a periodic atomic lattice, the electronic eigenfunctions take
13100:===== PDF PAGE 226 =====
13161:===== PDF PAGE 227 =====
13203:===== PDF PAGE 228 =====
13248:phenomenon, known as Anderson localization, is a very important result of solid-state physics
13253:===== PDF PAGE 229 =====
13255:83. Scaling Theory of Anderson Localization Problem 82 corresponds to the limit of
13257:space. The situation regarding Anderson localization is in fact richer than what is suggested
13299:===== PDF PAGE 230 =====
13322:Source: Abrahams, E., Anderson, P. W., Licciardello, D. C. and Ramakrishnan, T. V . (1979),
13325:===== PDF PAGE 231 =====
13331:Anderson localization, 282, 347, 351
13341:Banks–Casher relation, 282, 283
13342:Banks–Zaks ﬁxed point, 136, 191
13382:===== PDF PAGE 232 =====
13471:===== PDF PAGE 233 =====
13510:Langevin equation, 76, 118
13528:Lipmann–Schwinger equation, 45, 327
13559:===== PDF PAGE 234 =====
13631:Schwinger mechanism, 282, 324, 331
13632:Schwinger–Keldysh
13646:===== PDF PAGE 235 =====
13720:he was awarded the Paul Langevin Prize of the French Physical Society in 2015. He
14066:that obey a Langevin equation with Gaussian white noise. These ideas are explored
14068:the concept (and problems) of complex Langevin equations.
16396:generalized ﬁelds obey the following Langevin equation:
16407:ﬁctitious time τ. Assuming each ﬁeld in this ensemble obeys the Langevin equation,
16420:the Langevin equation converge to the usual time-ordered correlation functions in the
16447:distribution P0[φ]. Evolving each ﬁeld in this ensemble with the Langevin equation (2.37)
16464:ϕ of the Langevin equation, and then average over all the realizations of the noise. Likewise,
16482:Using the Langevin equation, the second form of this derivative can be written as
16547:In order to obtain an evolution equation inτ for this quantity, we differentiate the Langevin
16597:between noise averages of products of solutions of the Langevin equation (in the limit of large
16601:28.e The solution of the Langevin equation with a null initial condition can be represented
16614:(This is the retarded solution, appropriate for solving the Langevin equation from some initial
16668:29. Complex Langevin Equation This problem is a continuation of Problem 28. Its goal
16670:a complex Langevin equation. We consider the “action” S(x) ≡ α2x2 + β4 x4, and write thefollowing Langevin equation:
16684:29.c Show that the momentsCn obtained from the complex Langevin equation coincide with
16688:29.e Show that the complex Langevin equation is equivalent to the following Fokker–Planck
16706:samples this distribution by solving the following Langevin equation:
16708:Moreover, the probability distribution Pτ(x) of an ensemble of x’s that obey this Langevin
16718:On the other hand, when we solve the Langevin equation (2.38) with a complex action,
16720:this reason, it is called a complex Langevin equation. Thus, the equilibrium distribution of an
16721:ensemble ofz ≡ x +iy’s obeying this Langevin equation is a positive deﬁnite distribution on
16724:29.b From the solution of the complex Langevin equation, let us deﬁneτ-dependent moments
16772:solutions of the complex Langevin equation is such that
16791:1. If the moments Cn(τ) deﬁned from the complex Langevin equation do converge to a
16817:3. In practice one has only a ﬁnite number of solutions of the complex Langevin equation,
17312:• Problem 47 studies some aspects of Banks–Zaks ﬁxed points, which are perturbative
20190:47. Banks–Zaks Fixed Points Consider a theory (e.g., QCD) in which theβ function has
20230:perturbative regime, the infrared ﬁxed point ii is known as a Banks–Zaks ﬁxed point.
20248:Source: Banks, T. and Zaks, A. (1982), Nucl Phys B 196: 189.

exit_code=0
```

### 2026-11-16T18:22:15.046020+08:00

```bash
sed -n 9465,10080p planning/source-notes/qft-gelis-all.txt
```

```text
===== PDF PAGE 161 =====
69 BANKS–CASHER RELATION 283
69. Banks–Casher Relation Quantum chromodynamics, if restricted to the up and down
quarks, has a nearly exact chiral symmetry thanks to the very small masses of these quarks.
The three pions (π0,π±) are also much lighter than the other hadrons, a property which is
understood as a consequence of them being the Nambu–Goldstone bosons that result from the
spontaneous breaking of chiral symmetry (fromSU(2)×SU(2) toSU(2), hence three pions
corresponding to the three broken symmetries – note that their masses are not exactly zero,
because the symmetry was not exact to begin with). The goal of this problem is to establish a
relationship, known as the Banks–Casher relation, between the value of the chiral condensate⟨
ψψ
⟩
(which should be zero if chiral symmetry holds, and which may be viewed as the order
parameter for its spontaneous breaking) and the spectral density at zero energy of the Dirac
operator. Consider Euclidean QCD in the continuum.
69.a Show that the expectation value
⟨
ψ(x)ψ(x)
⟩
can be written as
⟨
ψ(x)ψ(x)
⟩
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM [A] det (i/D −m) trV
[ 1
i/D −m
]
,
whereV is a four-dimensional Euclidean volume to which the trace is restricted, andZ
is the same integral without the trace and the prefactor1/V.
69.b Recalling the properties of the Euclidean Dirac operator, write the trace as follows:
trV
[ 1
i/D −m
]
=
∑
n
1
iλn −m =−
∑
n
m
λ2n +m2,
where theλn are real numbers.
69.c Show that
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
69.d Show that, in the limits of inﬁnite volume and zero quark mass, we have⟨
ψ(x)ψ(x)
⟩
=− π limV→∞ ρV (0).

===== PDF PAGE 162 =====
284 5 LATTICE, FINITE T , STRONG FIELDS
69.a Note ﬁrst that the equal-point correlation function
⟨
ψ(x)ψ(x)
⟩
is independent of the
pointx thanks to translation invariance. Therefore, we may write
⟨
ψ(x)ψ(x)
⟩
= lim
V→∞
1
V
∫
V
d4x⟨ψ(x)ψ(x)⟩,
where V is a ﬁnite volume in Euclidean R 4. Then, it admits the following path integral
representation:
⟨
ψ(x)ψ(x)
⟩
= 1ZV ∫ [DAμDψDψ] e−SYM −SD ∫V d4x ψ(x)ψ(x)
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM det (i/D −m)
∫
V
d4x⟨x⏐⏐ 1i/D −m⏐⏐x⟩
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM det (i/D −m) trV
[ 1
i/D −m
]
, (5.18)
where Z ≡
∫
[DAμDψDψ] e−SYM −SD.
In this formula, it is implicitly understood that the integrand is calculated for a ﬁnite volume
theory, in which the spectrum of the Dirac operator is discrete. The limit V →∞ ensures that
we recover the original theory in the end.
69.b The Euclidean Dirac matrices are anti-Hermitian,γμ† =− γμ, as is the derivative∂μ.
Therefore, the Euclidean Dirac operator is Hermitian, and it can therefore be diagonalized in
an orthonormal basis with real eigenvalues:
/Dψn(x)= λnψn(x),λ n ∈ R ,
∫
V
d4xψ∗m(x)ψn(x)= δmn.
(Note that the eigenvalues depend implicitly on the background gauge ﬁeldAμ.) The trace of
the inverse of the Dirac operator can be expressed in terms of these eigenvalues as follows:
trV
[ 1
i/D −m
]
=
∑
n
1
iλn −m.
On the other hand, sinceγ5γμγ5 = γμ† =− γμ, we can write
trV
[ 1
i/D −m
]
= trV
[
γ5γ5 1i/D −m] = trV [γ5 1i/D −mγ5]
= trV
[ 1
−i/D −m
]
=
∑
n
1
−iλn −m.
By taking the half-sum of the two representations of the trace, we arrive at
trV
[ 1
i/D −m
]
=−
∑
n
m
λ2n +m2 =−
∫
dλ
[ ∑
n
δ(λ −λn)
] m
λ2 +m2.

===== PDF PAGE 163 =====
70 NIELSEN–NINOMIYA THEOREM 285
69.c Inserting this expression in (5.18), we immediately get
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
The integrand in the deﬁnition ofρV (λ) is a distribution that has a delta peak at each eigenvalue
of the ﬁnite volume Dirac operator, and its integral over some range [λ1,λ2] counts the number
of eigenvalues in that range, per unit of volume V. The average over all conﬁgurations of
the gauge ﬁeldAμ washes out the delta peaks and turnsρV (λ) into a smooth distribution that
provides the average density of eigenvalues of the Dirac operator:
∫λ2
λ1
dλ ρV (λ)=
⟨# of eigenvalues in [λ1,λ2]
V
⟩
A
.
Note that this distribution has a gap at the lower end of the spectrum because of the ﬁnite
volume.
69.d As the volume increases, the gap at the lower end decreases, andρV (λ) has support in
the entire range [0, +∞) in the inﬁnite-volume limit. Moreover, when the quark mass goes to
zero, we have
lim
m→0+
m
λ2 +m2 = πδ (λ).
Therefore, we have
lim
m→0+
⟨
ψ(x)ψ(x)
⟩
=− π lim
V→∞
ρV (0).
This relation is known as the Banks–Casher relation. The left hand side is a quantity known
as the chiral condensate. In the massless limit, the Dirac Lagrangian is invariant under chiral
transformations, since it does not contain an operator ψψ (which breaks chiral symmetry).
A non-zero expectation value of this operator therefore signals that the ground state of the
theory breaks chiral symmetry. The Banks–Casher formula relates the chiral condensate, which
quantiﬁes the spontaneous breaking of chiral symmetry, to the spectral density at the lower
end of the spectrum of the Dirac operator (the latter is controlled by how quickly eigenvalues
accumulate nearλ = 0 when the volume becomes inﬁnite).
Source: Banks, T. and Casher, A. (1980), Nucl Phys B 169: 103.
70. Nielsen–Ninomiya Theorem The goal of this problem is to prove theNielsen–Ninomiya
theorem, an obstruction to the construction of chiral gauge theories on the lattice. Consider
an inﬁnite square lattice of spacing a. The conjugate momenta pμ are continuous variables
with components in the range
[
− πa, +πa] and any function ofpμ is periodic with period 2π/a.In other words, we may view momentum space as a four-dimensional torusT4. The inverse
propagator of a massless left-handed fermion can be written as S−1(p)= ∑μ γμPLFμ(p),
whereFμ(p) is a real continuous vector ﬁeld onT4 andPL ≡ (1 −γ5)/2.

===== PDF PAGE 164 =====
286 5 LATTICE, FINITE T , STRONG FIELDS
70.a Explain why such a fermion exists if the vector ﬁeldFμ(p) has a zeropμ∗ in the vicinity
of which it behaves asFμ(p)=( p −p∗)μ +O((p −p∗)2). Note that the ﬁeld lines of
Fμ are all pointing away fromp∗.
70.b Consider now a zero ofFμ(p) at which the ﬁeld lines are incoming in one direction and
outgoing in the other three directions, such asFμ(p)=( − 1)δμ1 (p−p∗)μ +O((p−p∗)2).
Show that this zero in fact describes a right-handed particle. Hint: apply a similarity
transformation γ1γ5. Use this result to explain why, in one dimension, there must be
equal numbers of left-handed and right-handed fermions in the spectrum of the lattice
Dirac operator.
70.c More generally, explain the relationship between the handedness of a fermion and the
number of “ingoing directions” of the vector ﬁeldFμ at a zerop∗.
70.d The index of a zero of a vector ﬁeld is deﬁned as (−1)n, where n is the number of
dimensions along which the ﬁeld lines are ﬂowing away from the zero. The Poincar´e–
Hopf theorem states that the sum of the indices of the zeroes of a vector ﬁeld is equal to
the Euler characteristic of the manifold on which it is deﬁned, which is zero for a torus.
Use this result to conclude that this lattice setup in fact has equal numbers of left-handed
and right-handed fermions.
70.a The form S−1(p)= ∑μ γμPLFμ(p) for the inverse propagator assumes (discrete)
translation invariance on the lattice, and that the lattice is inﬁnite, so that the conjugate
momentum space is continuous rather than discrete. Because of the ﬁnite lattice spacing, the
momentumpμ is deﬁned on a four-dimensional torusT4 (each component of the momentum is
bounded, and the bounds in the positive and negative directions are identiﬁed) rather than R 4.
The functionFμ(p) is real if the Lagrangian is Hermitian, and is continuous provided the theory
is quasi-local (i.e., when the action is written as S ≡ ∑x,y ψ(x)h(x,y)ψ(y), the function
h(x,y) should decrease fast enough). Since Fμ(p) has as many components (μ = 1,2,3,4 )a s
its argumentp, it is a vector ﬁeld. Moreover, Fμ(p) may be viewed locally as the gradient of a
scalar function F(p),Fμ(p)= ∂pμF(p).
A massless fermion corresponds to a momentump∗ where the inverse Dirac propagator
vanishes linearly (think of the propagatori//p in the continuous theory). This means that all
the components ofFμ(p) vanish simultaneously atp∗,
Fμ(p) ∼ fμν(p −p∗)ν.
By an appropriate change of coordinates, the matrix of coefﬁcientsfμν can be made diagonal,
with only positive coefﬁcients. Up to a rescaling (by positive factors) of the components of pμ,
this implies the announced behavior nearp∗. These zeroes of the vector ﬁeldFμ(p) correspond
to minima of F(p). About such a zero, the ﬁeld lines of Fμ are all oriented outwards fromp∗.
Note that, because we have included an explicit projectorPL in the deﬁnition of the inverse
propagator, these zeroes describe left-handed fermions.

===== PDF PAGE 165 =====
70 NIELSEN–NINOMIYA THEOREM 287
70.b Let us now ﬂip the orientation of the ﬁeld lines along one direction, i.e., consider a zero
for which the ﬁeld lines are ﬂowing away along three directions and into the zero along the
remaining direction (for instance the directionμ = 1):
Fμ(p)=( − 1)δμ1 (p −p∗)μ +O((p −p∗)2).
As suggested in the statement of the problem, we should study the following combination:
(γ1γ5)−1(−1)δμ1γμPL (γ1γ5)= γ5γ1(−1)δμ1γμPLγ1γ5
=
{
μ = 1 :− γ5γ1γ1PLγ1γ5 = γ1PR
μ ⁄= 1 :+ γ5γ1γμPLγ1γ5 = γμPR
}
= γμPR.
(Note that we also have (γ1γ5)−1(−1)δμ1γμPR (γ1γ5)= γμPL .) Therefore, this type of zero
describes (in disguise, i.e., up to a similarity) a massless fermion of right-handed chirality. This
observation is sufﬁcient to prove the Nielsen–Ninomiya theorem in one dimension: indeed, a
smooth vector ﬁeld on a circle must have an equal number of zeroes where the ﬁeld lines go
towards the zero (corresponding to left-handed fermions) and zeroes where the ﬁeld lines go
away from the zero (corresponding to right-handed fermions).
70.c Consider now a zero such that the vector ﬁeld is ﬂowing into the zero along two
directions and away from it along two directions. If the two dimensions along which the ﬁeld
is ﬂowing inwards areμ = 1,2 , we need now to considerFμ(p)=( − 1)δμ1 (−1)δμ2 (p −p∗)μ.
We have
(γ2γ5)−1(−1)δμ2
[
(γ1γ5)−1(−1)δμ1γμPL (γ1γ5)](γ2γ5)
=( γ2γ5)−1(−1)δμ2γμPR (γ2γ5)= γμPL.
Thus, this zero corresponds to a left-handed fermion. The pattern should be clear by now:
the chirality of the fermion ﬂips every time we add a direction along which the vector ﬁeld is
ﬂowing into the corresponding zero. In more mathematical terms, if a1,...,a p are distinct
integers in [1,4 ],w eh a v e
(γapγ5)−1 ··· (γa1γ5)−1
[
(−1)μa1 ··· (−1)μapγμPL
]
(γa1γ5)··· (γapγ5)
=
{γμPL ifp is even,
γμPR ifp is odd.
In words, the zero describes a left-handed fermion if the ﬁeld lines are ﬂowing into the
zero along an even number of directions, and a right-handed fermion for an odd number of
directions.
70.d The index of a zero of a vector ﬁeld is deﬁned as (−1)n, where n is the number
of dimensions along which the ﬁeld lines are ﬂowing away from the zero (see Figure 5.1).
Therefore, ind dimensions, we have the following correspondence between the index of a zero

===== PDF PAGE 166 =====
288 5 LATTICE, FINITE T , STRONG FIELDS
Figure 5.1 Two-dimensional vector ﬁelds with zeroes of index +1 (Left: Fμ(p)= pμ) and −1
(Right: Fμ(p)=( − 1)δμ1pμ).
ofFμ and the chirality of the fermion it describes:
index= (−1)d ←→ left-handed,
index= (−1)d+1 ←→ right-handed.
The usefulness of this concept in the present discussion stems from thePoincar´e–Hopf theorem,
which relates the sum of the indices of the zeroes of a smooth vector ﬁeld deﬁned on a manifold
M without boundary to a topological invariant of this manifold, namely its Euler characteristic,
denoted byχ(M):
∑
zeroesz∗
index (z∗)= χ(M).
For two-dimensional manifolds, the Euler characteristic can be easily visualized and calculated
from any triangulation of the surface, since it is given by
χ(M)=( number of vertices)−( number of edges)+( number of faces).
(See Problem 42 for a discussion of the main properties of this quantity, in particular the fact
that it does not depend on the chosen triangulation.) From this deﬁnition, one may see that the
Euler characteristic of a2-sphere isχ = 2 and that it isχ = 0 for a two-dimensional torus with
one handle. This implies that any smooth vector ﬁeld on such a torus must have equal numbers
of zeroes of index +1 and −1, as illustrated in Figure 5.2. In the discussion of chiral fermions
on the lattice, this result implies that any such propagator would in fact describe equal numbers
of left-handed and right-handed fermions in two dimensions, despite the fact that we have put
an explicit projectorPL in it. This obstruction to the possibility of deﬁning chiral fermions on
the lattice is known as the Nielsen–Ninomiya theorem.
The Euler characteristic is in fact zero for one-holed tori in any dimension (but this is harder
to visualize in dimensions higher than two), in particular for the torusT4 on which the vector
Fμ(p) that enters in the inverse fermion propagator is deﬁned. Thus, the Nielsen–Ninomiya
theorem is also valid in four dimensions.

===== PDF PAGE 167 =====
70 NIELSEN–NINOMIYA THEOREM 289
Figure 5.2 Illustration of the Poincar´e–Hopf theorem: smooth vector ﬁeld on a torus in two
dimensions with a zero of index +1 (open circle) and a zero of index −1 (ﬁlled circle).
Sketch of a Proof of the Poincar ´e–Hopf Theorem: The ﬁrst step in proving the Poincar´e–
Hopf theorem is to show that the sum of the indices of the zeroes is the same for all the
smooth vector ﬁelds. In fact, one can show (see, for instance, Milnor, J. W. (1997),Topology
from the Differentiable Viewpoint (Princeton University Press)) that the sum of the indices
of any smooth vector ﬁeld on a d-dimensional manifold M is equal to twice the degree of
the Gauss mapping fromM to the sphereSd (loosely speaking, this degree counts how many
times the Gauss mapping wraps around Sd), and is therefore a property of M itself. Then one
could invoke the Gauss–Bonnet theorem (see Problem 22) to relate this quantity to the Euler
characteristic.
A more elementary approach is to construct a special vector ﬁeld on M for which it is
easy to relate the sum of the indices to the Euler characteristic χ(M). For this, we start from a
triangulation of the manifoldM. For a two-dimensional manifold, this is a decomposition of
M into planar triangles, while in three dimensions it is a decomposition into tetrahedrons, and
more generally a decomposition ind-simplices ind dimensions. Note that, in a triangulation,
d-dimensional simplices meet at a (d −1)-dimensional simplex, etc. On such a triangulation,
consider the vector ﬁeld of Figure 5.3 (illustrated here in two dimensions). In this ﬁgure, the
triangle in boldface shows the conﬁguration of the ﬁeld lines in one cell of the triangulation,
and all the other triangles simply replicate the same pattern. This ﬁeld has zeroes at all the
vertices of the triangulation, at the midpoints of all the edges, and at the centers of all the
triangles. Moreover, if we count the number of dimensions along which the ﬁeld lines are
oriented away from these zeroes, we have
index (vertex)=+ 1,
index (edge midpoint)=− 1,
index (face center)=+ 1,
and the sum of the indices at all these zeroes reads
∑
zeroesz∗
index (z∗)=( number of vertices)−( number of edges)+( number of faces),
which is nothing but the deﬁnition of the Euler characteristic for a two-dimensional manifold.

===== PDF PAGE 168 =====
290 5 LATTICE, FINITE T , STRONG FIELDS
Figure 5.3 Special vector ﬁeld used in the proof of the Poincar´e–Hopf theorem (here, in two
dimensions). Left: layout of the main ﬁeld lines on top of a triangulation of the surface. Right:
detail of the ﬁeld lines in one elementary triangle.
In higher dimensions, one may construct a similar vector ﬁeld, with zeroes at the centers of
all thek-simplices (k ≤ d) that make up the triangulation, and the above pattern generalizes to
index (center ofk-dim simplex)=( − 1)k.
Therefore, for such a ﬁeld conﬁguration ind dimensions, we have
∑
zeroesz∗
index (z∗)=
d∑
k=0
(−1)k × (number ofk-dim simplices),
which is again the deﬁnition of the Euler characteristic of a d-dimensional manifold. Al-
though explicit, the right-hand side of this equation is less practical for calculating the Euler
characteristic in dimensions greater than two because it is hard to visualize triangulations of
higher-dimensional manifolds.
Source: Karsten, L. H. (1981), Phys Lett B 104: 315.
71. Wigner Transform of a Convolution Product The Wigner transform of a two-point
functionF(x,y ) is a function F(X,p ) obtained by Fourier transformingF(x,y ) with respect to
the differencex −y while keeping the dependence on the midpoint coordinateX ≡ (x +y)/2:
F(X,p ) ≡
∫
ddse ip·s F(X + s2,X − s2 ).
Consider a pair of two-point functionsF(x,y ) andG(x,y ) and their convolutionH(x,y ) ≡∫
ddzF (x,z )G(z,y ). Show that their respective Wigner transforms are related by
H(X,p )= F(X,p ) exp
{i
2
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]}
G(X,p ). (5.19)
This result plays a role in the derivation of the Boltzmann equation from the Kadanoff–Baym
equations. It is also an important ingredient in the formulation of quantum mechanics in

===== PDF PAGE 169 =====
71 WIGNER TRANSFORM OF A CONVOLUTION PRODUCT 291
phase-space, proposed by Moyal and Groenewold (Groenewold, H. J. (1946), Physica 12: 405;
Moyal, J. E. and Bartlett, M. S. (1949),Math Proc Cambridge Philos Soc 45: 99). Hint: one
may instead prove an equivalent relationship between the operators F,G,H obtained from
F, G, Hvia Weyl mapping (see Problem 18).
The formula announced in the statement of the problem is intimately related to Weyl
quantization prescription and to the fact that the Wigner transform is the inverse of Weyl
mapping (this result is shown in Problem 18). Note ﬁrst that a two-point function like F(x,y )
may always be viewed as the coordinate representation of an operatorF (in this problem, we
use boldface letters for quantum operators). In particular, we have
F(x,z )=
⟨
x
⏐⏐F⏐⏐z⟩,G (z,y )= ⟨z⏐⏐G⏐⏐y⟩,
H(x,y )=
∫
ddz⟨x⏐⏐F⏐⏐z⟩⟨z⏐⏐G⏐⏐y⟩ =⟨x⏐⏐FG⏐⏐y⟩.
The last equality uses the completeness of the position eigenstates, and shows that the function
H(x,y ), deﬁned as the convolution product ofF andG, is the coordinate space representation
of the product of operatorsFG.
In order to streamline the notation, let us collectively denote the phase-space coordinates
byu ≡ (X,p ), and do the same with the corresponding quantum operators, denoting them by
u ≡ (X,p). The commutators among these operators have the following generic form:
[um,un]= iθmn,
where the θmn are commuting numbers. Let us also denote ∂m ≡ ∂/∂um. Equipped with this
notation, the “product” on the right-hand side of (5.19) can be rewritten compactly as
F(X,p ) exp
{i
2
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]}
G(X,p )= F(u)e
i
2θmn
←
∂m
→
∂nG(u)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ (F⋆G)(u)
.
The ⋆ operation is known as the Moyal product. The identity we wish to prove is that the
Wigner transform of a product of operators is equal to the Moyal product of their respective
Wigner transforms:
(5.19) ⇐⇒ Wigner
(
FG
)
= Wigner
(
F
)
⋆ Wigner
(
G
)
.
Since the Wigner transform is the inverse of Weyl mapping (see Problem 18), this identity is
equivalent to
Weyl(F ⋆G)= Weyl(F)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
F
Weyl(G)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
G
,
where Weyl(·) denotes the Weyl mapping of a function deﬁned on the classical phase-space.
In terms of the compact notation we have introduced, the Weyl mapping of a functionA can
be written in two steps,
~A(τ) ≡
∫ d2du
(2π)2d e−iu·τ A(u), Weyl(A)(u) ≡
∫
d2dτe iu·τ ~A(τ).
The ﬁrst step is a Fourier transform whose result is an ordinary function of the variables τ
(Fourier conjugates of the classical phase-space variables). The second one looks like the

===== PDF PAGE 170 =====
292 5 LATTICE, FINITE T , STRONG FIELDS
inverse Fourier transform, but this time one uses the quantum operatorsu instead ofu, and the
result is an operator.
Then, we can rearrange the expression for the Moyal product as follows:
(F ⋆G)(u)= F(u)e
i
2θmn
←
∂m
→
∂n G(u)
=
∫
d2dτd2dσ~F(τ)~G(σ) eiu·τ ei2θmn←∂m→∂n eiu·σ
=
∫
d2dτd2dσ~F(τ)~G(σ) eiu·τ ei2θmn(iτm)(iσn) eiu·σ
=
∫
d2dτd2dσ~F(τ)~G(σ) eiu·(τ+σ) e−i2θmnτmσn.
Let us now calculate the Weyl mapping of this function. In fact, since it is already written as a
Fourier integral, this just amounts to replacing the phase-space coordinatesu by the quantum
operatorsu in the integrand:
Weyl(F ⋆G)(u)=
∫
d2dτd2dσ~F(τ)~G(σ) eiu·(τ+σ) e−i2θmnτmσn. (5.20)
To simplify this expression, we use the Baker–Campbell–Hausdorff formula to write
eiu·(τ+σ) = eiu·τ eiu·σ e12 [um,un]τmσn = eiu·τ eiu·σ ei2θmnτmσn.
We see that the last factor of this formula cancels the last factor of (5.20), so that the result in
fact factorizes:
Weyl(F ⋆G)(u)=
( ∫
d2dτe iu·τ~F(τ)
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Weyl(F)(u)
)
×
( ∫
d2dσe iu·σ ~G(σ)
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Weyl(G)(u)
)
,
which proves the announced result.
Quantum Mechanics in Phase-Space: The Moyal product in fact allows a complete refor-
mulation of quantum mechanics in terms of functions that depend on the classical phase-space
variables:
Phase-space function: Operator:
F(X,p )
Weyl mapping
−−−−−−−−−−−−−→ F←−−−−−−−−−−−−−Wigner transform
F(X,p ) ⋆G(X,p ) ←−−−−−−−−−−−→ FG
In this framework, known as the Moyal–Groenewold quantization, quantum operators are
replaced by classical phase-space functions obtained via the Wigner transform, the product of
operators is replaced by the Moyal product of phase-space functions, and their commutator
is replaced by a Moyal commutator, [F, G]⋆ ≡ F ⋆ G − G ⋆ F. Although this formalism is
technically challenging to work with, it offers a more intuitive picture of what “quantization”
means, since the Moyal commutator is a deformation of the classical Poisson bracket{F, G}

===== PDF PAGE 171 =====
72 CENTER SYMMETRY AND DECONFINEMENT 293
controlled by the continuously varying parameter ¯h. Indeed, from the expression for the Moyal
product, the Moyal commutator reads
F ⋆G −G ⋆F = 2i¯h F sin {i ¯h2 [ ←∂X →∂p − →∂X ←∂p ]}G
= {F, G} + ¯h2
24 F
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]3 G +··· .
(We have reinstated Planck’s constant in this formula, using the fact that it has the dimensions
of an action.) From this expression, we also see that
F ⋆G −G ⋆F = {F, G}
if at least one of the functions F, Gis a polynomial of degree two in X,p . Thus, the Moyal–
Groenewold quantization of a theory with a quadratic Hamiltonian (e.g., a harmonic oscillator)
is particularly simple: its phase-space density obeys the classical Liouville evolution equation
even when ¯h ⁄= 0.
72. Center Symmetry and Deconfinement The goal of this problem is to study an
extension of gauge symmetry called center symmetry,i na SU(N) Yang–Mills theory at ﬁnite
temperature in the imaginary time formalism. In particular, we show that the deconﬁnement
transition may be viewed as a breaking of center symmetry.
72.a The center of a gauge group is the subgroup made of the elements that commute with the
entire group. In the case of SU(N), show that the center is Z N ≡ {e2iπk/N}0≤k<N, i.e.,
the set of theN-th roots of unity (multiplied by the identity matrix). Hint: ﬁrst, show
that the center of U(N) is the complex unit circle.
72.b At ﬁnite temperature, legitimate gauge transformations should be singled-valued in
imaginary time, i.e., beβ-periodic,Ω(β,x)= Ω(0,x). Consider now a more general
transformation, called a center transformation, deﬁned as a gauge transformation with a
non-periodicΩ. Instead, Ω(τ,x) is assumed to obeyΩ(β,x)= ξΩ(0,x) withξ ∈ Z N.
Show that center transformations also preserve the periodicity of the gauge ﬁeld.
72.c A Polyakov loop is the trace of a Wilson loop that wraps around the imaginary time
direction, at ﬁxed positionx:
L(x) ≡ N−1 tr⟨Pe x p∫β
0
dτA0(τ,x)⟩.
Show that L(x) is invariant under the usual (periodic) gauge transformations, but not
invariant under center transformations. What does this imply for the center transforma-
tions?
72.d Explain whyL(x) is related to the free energyFq of an inﬁnitely massive quark added
to the system at the pointx by
⏐⏐L(x)⏐⏐ = e−βFq (i.e., the energy necessary for bringing
the quark from inﬁnity, arbitrarily slowly). From this interpretation, conclude thatL(x)
should be zero in the conﬁning phase of Yang–Mills theory, and that one may view
deconﬁnement as a breaking of the center symmetry.

===== PDF PAGE 172 =====

exit_code=0
```

### 2026-11-16T18:23:20.107754+08:00

```bash
sed -n 10050,10555p planning/source-notes/qft-gelis-all.txt
```

```text
is particularly simple: its phase-space density obeys the classical Liouville evolution equation
even when ¯h ⁄= 0.
72. Center Symmetry and Deconfinement The goal of this problem is to study an
extension of gauge symmetry called center symmetry,i na SU(N) Yang–Mills theory at ﬁnite
temperature in the imaginary time formalism. In particular, we show that the deconﬁnement
transition may be viewed as a breaking of center symmetry.
72.a The center of a gauge group is the subgroup made of the elements that commute with the
entire group. In the case of SU(N), show that the center is Z N ≡ {e2iπk/N}0≤k<N, i.e.,
the set of theN-th roots of unity (multiplied by the identity matrix). Hint: ﬁrst, show
that the center of U(N) is the complex unit circle.
72.b At ﬁnite temperature, legitimate gauge transformations should be singled-valued in
imaginary time, i.e., beβ-periodic,Ω(β,x)= Ω(0,x). Consider now a more general
transformation, called a center transformation, deﬁned as a gauge transformation with a
non-periodicΩ. Instead, Ω(τ,x) is assumed to obeyΩ(β,x)= ξΩ(0,x) withξ ∈ Z N.
Show that center transformations also preserve the periodicity of the gauge ﬁeld.
72.c A Polyakov loop is the trace of a Wilson loop that wraps around the imaginary time
direction, at ﬁxed positionx:
L(x) ≡ N−1 tr⟨Pe x p∫β
0
dτA0(τ,x)⟩.
Show that L(x) is invariant under the usual (periodic) gauge transformations, but not
invariant under center transformations. What does this imply for the center transforma-
tions?
72.d Explain whyL(x) is related to the free energyFq of an inﬁnitely massive quark added
to the system at the pointx by
⏐⏐L(x)⏐⏐ = e−βFq (i.e., the energy necessary for bringing
the quark from inﬁnity, arbitrarily slowly). From this interpretation, conclude thatL(x)
should be zero in the conﬁning phase of Yang–Mills theory, and that one may view
deconﬁnement as a breaking of the center symmetry.

===== PDF PAGE 172 =====
294 5 LATTICE, FINITE T , STRONG FIELDS
72.e Why is the center symmetry explicitly broken if dynamical quarks in the fundamental
representation are added to the theory? What about adding matter ﬁelds in the adjoint
representation?
72.a Consider ﬁrst the case of the group U(N) ofN×N unitary matrices. A matrix A is
in the center ofU(N) ifA = PAP−1 for all unitary matricesP. Since A is unitary, it can be
diagonalized by a unitary transformation, which implies that we can reduce the discussion to
diagonal matrices. Therefore, let us now assume that A is diagonal, but not proportional to the
identity. This means that there exists a pair of indicesi ⁄= j such thatAii ⁄= Ajj. Now, denote
byQ the matrix obtained by swapping the columnsi,j of the identity, and deﬁneB ≡ QAQ−1.
Note that Q = Q† = Qt and QQ = 1, hence Q is unitary. A simple calculation shows that
Bii = Ajj andBjj = Aii, which implies thatB ⁄= A, i.e.,
QAQ−1 ⁄= A,
in contradiction to the fact that A was assumed to be in the center of the group. Thus, our
hypothesis thatA is not proportional to the identity was inconsistent, and we conclude that
center
(
U(N)
)
=
{
c·1N×N,|c| = 1
}
.
(The constraint on the modulus ofc is necessary to have unitary matrices.)
Consider now the case of SU(N). It is useful to recall that any matrix of U(N) can be
written as the product of a phase by a matrix ofSU(N):
U = eiθV, U ∈ U(N),V ∈ SU(N),θ ∈ R .
IfA is in the center ofSU(N) andU is inU(N),w eh a v e
UAU−1 = VAV−1/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= A
= A.
Therefore A is also in the center of U(N) and must be of the form c · 1N×N . Since the
determinant of such a matrix is cN,c must be one of the N-th roots of unity in order to have a
matrix ofSU(N). This group is denoted Z N.
72.b Consider a transformationΩ(τ,x) that has the following boundary condition:
Ω(β,x)= ξΩ (0,x), withξ ∈ Z N.
Calculate the transformed gauge ﬁeld atτ = β (assuming that the gauge ﬁeld wasβ-periodic
before applying the transformation):

===== PDF PAGE 173 =====
72 CENTER SYMMETRY AND DECONFINEMENT 295
Ω†(β,x)Aμ(β,x)Ω(β,x)+ igΩ†(β,x)∂μΩ(β,x)
= Ω†(0,x)ξ∗Aμ(0,x)ξΩ(0,x)+ igΩ†(0,x)ξ∗∂μξΩ(0,x)
= Ω†(0,x)Aμ(0,x)Ω(0,x)+ igΩ†(0,x)∂μΩ(0,x).
In the ﬁnal step, theξ andξ∗ cancel because we are allowed to move them throughAμ since
they belong to the center of SU(N). Despite the fact that this transformation is not β-periodic,
it nevertheless preserves the periodicity of the gauge ﬁelds. Therefore, these more general
transformations may be viewed as an extended symmetry of Yang–Mills theory (called center
symmetry) at ﬁnite temperature.
72.c Recall that a Wilson line Wγ(y,x ) along any path γ between the points x and y
transforms into Ω(y)Wγ(y,x )Ω†(x) under a gauge transformation. Therefore, the trace of
a Wilson loop is gauge invariant (and the Polyakov loop is just a special kind of Wilson
loop). But the cancellation of Ω(β,x) withΩ†(0,x) inside the trace works only whenΩ is
β-periodic, and therefore it fails with the generalized transformations considered above. In this
case, the Polyakov loop is not invariant, but is multiplied by an elementξ ∈ Z N of the center:
L(x) → ξL (x).
Since the Polyakov loop is gauge invariant, it should be considered as an observable of the
theory. Thus, the center transformations can alter the physical content of the system (i.e., they
are not just a reparameterization of redundant degrees of freedom). The only exception to this
statement occurs when L(x)= 0, since this value of the Polyakov loop is left invariant by
center transformations.
72.d The energy gainFq of the system due to bringing (inﬁnitely slowly, to avoid disturbing
the system) a heavy quark of massM at the pointx from inﬁnity may be written as follows:
e−β(Fq+M) =
∑
α
⟨
α +q(x)
⏐⏐e−βH⏐⏐α +q(x)⟩∑
α
⟨
α
⏐⏐e−βH⏐⏐α⟩
(the factore−βM, that contains the rest energy of the quark, has been explicitly added so that
Fq measures only the energy due to the interactions of the quark with its environment), where⏐⏐α +q(x)⟩ denotes the pure gluon state⏐⏐α⟩ to which a quark (of spin s and colori) is added
at the locationx:
⏐⏐α +q(x)⟩ ≡ ∫ d3p(2π)32Ep e−ip·x f(p)vs(p)b†sip/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ ψsi(x)
⏐⏐α⟩.
The functionf(p) is a wave-packet normalized according to

===== PDF PAGE 174 =====
296 5 LATTICE, FINITE T , STRONG FIELDS
∫ d3p
(2π)3
⏐⏐f(p)⏐⏐2 = 1,
which ensures that
⟨
α +q(x)
⏐⏐α +q(x)⟩ =⟨α⏐⏐α⟩. Interpreting the canonical density operator
as an imaginary time evolution, we can write
ψ†si(τ,x)e−βH = e−βH ψ†si(τ +β,x),
and the quark free energy becomes
e−β(Fq+M) = tr (e−βH ψ†si(β,x)ψsi(0,x))tr (e−βH) .
(Note that there is no sum on the spins and the colori in this expression.) Loosely speaking,
the right-hand side is the thermal expectation value of the propagator of the heavy quark
between the times τ = 0 and τ = β (the problem is translation invariant, and we may thus
choose the ﬁrst time to be0). To promoteψsi(x) to a time-dependent object, we use Dirac’s
equation. In the limit of large mass, M →∞ , wherep0 ≈ M,|p| ≪ M, the Dirac equation
simpliﬁes to
((∂τ −gA0)γ0 −M)ψ = 0.
Moreover, in this kinematical limit, we also haveγ0vs(p)=− vs(p). Therefore, for a spinor
proportional tovs(p), the Dirac equation becomes
(∂τ −gA0 +M)ψ = 0,
whose solution reads
ψ(τ,x)= e−Mτ Te x p(g ∫τ
0
dτ′ A0(τ′,x))
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ U(τ,x)
ψ(0,x).
(The time ordering is necessary becauseA0 is a matrix in su(N).) Therefore, we can write
ψsi(τ,x) ≡ e−Mτ ∑
j
Uij(τ,x)
∫ d3p
(2π)32Ep e−ip·x f(p)vs(p)b†sjp,
which leads to
e−βFq = eβM ∑
j
tr (e−βH ψ†sj(0,x)Uji(β,x)e−βMψsi(0,x))
tr (e−βH)
= 1N ∑i,j tr (e−βH ψ†sj(0,x)Uji(β,x)ψsi(0,x))tr (e−βH) .
In the last equality, we have used the fact that the free energy is independent of the quark color
i in order to introduce an average overi. In the evaluation of this expectation value, the product

===== PDF PAGE 175 =====
73 PHOTON HARD THERMAL LOOP FROM CLASSICAL PARTICLES 297
of the two free spinors simply yields
ψ†sj(0,x)ψsi(0,x)=
∫ d3pd3q
(2π)64EpEq ei(p−q)·x bsjpb†siq/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−b†siqbsjp+(2π)32Epδijδ(p−q)
f∗(p)f(q)v†s(p)vs(q).
The term in −b†siqbsjp gives zero when inserted in the trace, because it has a fermion
annihilation operator acting to the right on a pure gluonic state. Thus, only the term in
(2π)32Epδijδ(p −q) contributes:
ψ†sj(0,x)ψsi(0,x) → δij
∫ d3p
(2π)32Ep
⏐⏐f(p)⏐⏐2 v†s(p)vs(p)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 2Ep
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 1
= δij.
The factorδij then leads precisely to the trace of the Polyakov loop over its color indices.
In the conﬁning phase, isolated quarks cannot exist; in other words, it would cost an inﬁnite
amount of energy to bring one from inﬁnity (i.e., Fq =+ ∞). Therefore, the expectation value
of the Polyakov loop should be zero in this phase, and center symmetry is preserved (since
zero times any element of Z N is still zero). On the other hand, isolated quarks cost only a ﬁnite
energy in the deconﬁned phase, and the center symmetry is broken since the expectation value
of Polyakov loops is not zero. Therefore, one may view the expectation value of the Polyakov
loop as an order parameter for the deconﬁnement transition in pure Yang–Mills theory.
72.e Under the transformationΩ(τ,x), a fermion in the fundamental representation trans-
forms as
ψ(τ,x) → Ω†(τ,x)ψ(τ,x).
Therefore, the center transformations do not preserve the β-anti-periodicity of the spinors,
implying that the center symmetry is explicitly broken by the presence of dynamical quarks in
the fundamental representation. Therefore, in QCD with quarks, the expectation value of the
Polyakov loop is no longer a good order parameter for the deconﬁnement transition.
IfΦa is a ﬁeld in the adjoint representation, it transforms as
Φa → ΩabΦb, i.e., Φatar → Ω†rΦatar Ωr.
In the second form, it is clear that the ξ ∈ Z N of the center transformation cancels out, leaving
a transformed ﬁeld which is still β-periodic (or anti-periodic if it is a fermion). Therefore,
a theory with matter ﬁelds in the adjoint representation would be invariant under the center
symmetry.
Source: McLerran, L. D. and Svetitsky, B. (1981), Phys Rev D 24: 450.

===== PDF PAGE 176 =====
298 5 LATTICE, FINITE T , STRONG FIELDS
73. Photon Hard Thermal Loop from Classical Particles In this problem, we use
the concept of a classical particle developed in Problem 31 in order to derive the effective
Lagrangian that generates hard thermal loops in QED. This derivation illustrates the classical
nature of hard thermal loops, and is also a good workout in preparation for the QCD case (see
Problem 74).
73.a Find a suitable generalization of the equations of motion discussed in Problem 37 to
describe the evolution of the position and momentum of a massless charged particle in
an external electromagnetic ﬁeld.
73.b Consider a collection of classical electrons and positrons, with a phase-space density
f(x,p ). Why do we have df/dτ = 0? Using the equations of motion of the classical
particles, turn this equation into a kinetic equation.
73.c Consider now an expansion off,f = f0 +f1 +··· , wheref0 is a distribution independent
of the external ﬁeld. Formally solve the kinetic equation in order to obtain the ﬁrst
correction in the external ﬁeld,f1.
73.d Determine the electromagnetic current Jμ induced by f1 (assume that f0 produces no
current). Then, determine an effective LagrangianLeff such thatJμ = ∂Leff/∂Aμ.
73.e Show that its second derivative, −δLeff/δAμδAν, is the photon polarization tensorΠμνHTL
in the hard thermal loop approximation.
73.a In the classical particle approximation of Problem 37, the charged particles feel the
effect of the background electromagnetic ﬁeld, but their own radiation is not considered.
Therefore, the particles do not feed the electromagnetic ﬁeld, and there are no interactions
between the charged particles. Since we are going to consider the ultra-relativistic limit, we
need to adapt the equations of motion to the case of massless particles. Formally, we can start
from the equations obtained in Problem 37, and deﬁneτ ≡ t/m before completely eliminating
m. This leads to
pμ = dxμ
dτ , dpμdτ = eFμνpν.
Note that since the particles are massless, τ is not really a time but simply some parameter that
maps the trajectory of a particle (in fact, this parameter has the dimensions of a squared time).
73.b Let us denote by f(x,p ) the phase-space density of these charged particles. By the
Liouville theorem,f is constant along the trajectories in phase-space (equivalently, the volume
in phase-space is preserved by a Hamiltonian ﬂow). Then, we can rewrite the time derivative
off more explicitly:
0 = dfdτ = dxμdτ ∂f∂xμ + dpμdτ ∂f∂pμ = pμ ∂f∂xμ +eFμνpν ∂f∂pμ
= pμ
( ∂
∂xμ −eFμν ∂∂pν)f.
This type of kinetic equation is known as a Vlasov equation. The ﬁrst term, p·∂xf, describes
the free streaming of particles, i.e., the motion at constant momentum of free particles. The

===== PDF PAGE 177 =====
73 PHOTON HARD THERMAL LOOP FROM CLASSICAL PARTICLES 299
second term describes the deﬂection of their trajectories due to the force the particles feel from
the external ﬁeld in which they propagate.
73.c The Vlasov equation can be solved iteratively by writing
f = f0 +f1 +··· ,
where f0 is some distribution of free particles (it must obey p · ∂xf0 = 0), f1 is the ﬁrst
correction due to the external ﬁeld, etc. In the ﬁrst iteration, we have
p·∂xf1 = epμFμν ∂f0∂pν.
Indeed, iff1 is the correction of ﬁrst order in the external ﬁeld, we do not need to keep it on the
right-hand side, so that the left- and right-hand sides have the same order ine. This equation
can be solved formally to give
f1 = epμ
1
p·∂x
Fμν ∂f0
∂pν.
73.d The next step is to deﬁne the electromagnetic current associated with the distribution f:
Jμ(x) ≡ e
∫ d3p
(2π)3
pμ
p f(x,p ).
One may check that this current is conserved iff obeys the Vlasov equation:
∂μJμ = e
∫ d3p
(2π)3p (p·∂)f = e2
∫ d3p
(2π)3ppμFμν ∂f∂pν =− e2
∫ d3p
(2π)3p
∂pμ
∂pν
/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
gμν
Fμν
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 0
f = 0.
With the iterative solution obtained above, the current reads
Jμ = e
∫ d3p
(2π)3p pμ
(
f0 +epρ
1
p·∂x
Fρν ∂f0
∂pν +···
)
.
If we assume that the free distributionf0 does not produce any current, the ﬁrst term is zero
(physically, this is realized when the free distributionf0 has equal distributions of electrons
and positrons). Therefore, at order one in the external ﬁeld, the current reads
Jμ = e2
∫ d3p
(2π)3p
pμpρ
p·∂x
Fρν ∂f0
∂pν =− e2
∫ d3p
(2π)3p
∂
∂pν
(pμpρ
p·∂x
)
Fρν f0
=− e2
∫ d3p
(2π)3p
(δνμpρ
p·∂x
+ pμgνρ
p·∂x/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
→0
− pμpρ∂ν
(p·∂x)2
)
Fρν f0.
Note that the middle term gives zero after contraction with the antisymmetric tensor Fρν.N o w ,
we would like to determine an effective LagrangianLeff such that
Jμ = ∂Leff
∂Aμ
.
SinceJμ is linear in the external ﬁeld, this effective Lagrangian must have one more power of
A. Moreover, in order to be gauge invariant, this additionalA dependence should arise via a

===== PDF PAGE 178 =====
300 5 LATTICE, FINITE T , STRONG FIELDS
power of the ﬁeld strength. In order to ﬁnd this Lagrangian, recall ﬁrst that
∂Fαβ
∂Aμ
= ∂(∂αAβ −∂βAα)∂Aμ = δβμ ∂α −δαμ ∂β.
Then, consider
∂
∂Aμ
(
Fνβ
pβpρ
(p·∂)2Fρν
)
=( δβμ∂ν −δνμ∂β) pβpρ(p·∂)2Fρν +Fνβ pβpρ(p·∂)2 (gμν∂ρ −gρμ∂ν)
= pμpρ
(p·∂)2
(
∂νFρν +Fρν∂ν) −2 pρp·∂Fρμ
=− pμpρ
(p·∂)2
(
∂νFρν/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
0
)
−2
(δνμpρ
p·∂ − pμpρ∂ν(p·∂)2)Fρν.
(Note that the derivatives act on everything located to their right, including the zeroth-order
phase-space distribution f0, not yet included in this formula. To obtain the ﬁnal line, we
usedFρν∂ν ··· = ∂νFρν ··· −(∂νFρν)··· . Finally, we have∂νFρν = 0 because the charged
particles are not feeding the external ﬁeld in this approximation (and we assume that the
sources producing this ﬁeld are far away). Up to a factor2, we recognize the structure of the
integrand in the currentJμ. Therefore, the effective Lagrangian whose derivative givesJμ reads
Leff = e22 ∫ d3p(2π)3p Fνβ pβpρ(p·∂)2Fρν f0.
73.e Let us now consider
Πμν =− ∂Jμ
∂Aν
= e2
∫ d3p
(2π)3p
(
gμν − pμ∂ν +pν∂μ
p·∂ + pμpν∂2(p·∂)2) f0.
To recover the HTL result, we replacef0 by the equilibrium fermion distribution,
f0(x,p )= 2×2× 1eβ|p0| +1
(the two prefactors2 account for electrons and anti-electrons, and for the fact they have two
spin states), and we Fourier transform the external coordinates (which simply amounts to the
replacement∂ → ik), so that
Πμν(k)= 4e2
∫ d3p
(2π)3p
(
gμν − pμkν +pνkμ
p·k + pμpνk2(p·k)2) 1eβp +1
(p0 = p in this equation). Note that the factor between the parentheses is homogeneous
of degree zero in p, and therefore depends only on the orientation ˆp of p. By writing

===== PDF PAGE 179 =====
74 GLUON HARD THERMAL LOOP FROM COLORED CLASSICAL PARTICLES 301
d3p = p2dpd2ˆp, we can easily factorize the radial and angular integrals:
Πμν(k)= 2e2
∫ +∞
0
dp p
π2
1
eβp +1 ×
∫ d2ˆp
4π
(
gμν − ˆPμkν +ˆPνkμ
ˆP·k +
ˆPμˆPνk2
(ˆP·k)2
)
,
whereˆP ≡ (1,ˆp). The radial integral reads
2e2
∫ +∞
0
dp p
π2
1
eβp +1 = 2e2T2π2 ∫ +∞0 dx x(e−x −e−2x +e−3x −e−4x +··· )
= 2e2T2
π2
( 1
12 − 122 + 132 −··· ) = 2e2T2π2 ζ(2)2 = e2T26 .
In order to compare with the known results for the photon hard thermal loop, it is enough to
check the component Π00 and the trace Πμμ. The angular integration reduces to three basic
integrals,
∫ d2ˆp
4π = 1,
∫ d2ˆp
4π
1
ˆP·k = 12k ln⏐⏐⏐k0 +kk0 −k⏐⏐⏐,∫ d2ˆp
4π
1
(ˆP·k)2
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
− ∂∂k0 1ˆP·k
= 1
(k0)2 −k2,
and we obtain
Πμμ(k)= e2T26 ∫ d2ˆp4π (4 −2ˆP·kˆP·k +
0/bracehtipdownleft/bracehtipupright/bracehtipupleft/bracehtipdownright
ˆP2 k2
(ˆP·k)2
)
= e2T2
3 ,
Π00(k)= e2T2
6
∫ d2ˆp
4π
(
1 −2 k0
ˆP·k + k2(ˆP·k)2) = e2T23 (1 − k02k ln⏐⏐⏐k0 +kk0 −k⏐⏐⏐).
These results provide the two independent terms that enter into the photon hard thermal loop.
Although the gain provided by this approach to calculating the HTL contribution to the photon
polarization tensor is marginal, it becomes appreciable when applied to the case of QCD, and
does not require much more effort (as opposed to an approach in terms of Feynman diagrams).
Moreover, the present discussion highlights the fact that, in the HTL approximation, the particle
running in the loop is in fact classical.
74. Gluon Hard Thermal Loop from Colored Classical Particles This problem is a
continuation of Problem 73. Extend the method of that problem (with the help of the results
of Problem 37) in order to compute the gluon polarization tensor in the hard thermal loop

===== PDF PAGE 180 =====
302 5 LATTICE, FINITE T , STRONG FIELDS
approximation. Hint: note that the current must now be deﬁned by
Jμ ≡
∫ d3p
(2π)3
∫
dQ Qpμ
p f(x,p,Q ),
whereQ is the “non-Abelian classical charge” introduced in Problem 37, and show that the
phase-space distribution obeys the following Vlasov equation:
pμ
( ∂
∂xμ −QaFaμν ∂∂pν +ig(Aadjμ )abQb ∂∂Qa)f = 0.
Since the method is the same as in Problem 73, our derivation will just go through the
main steps and will skip some details. The starting point is the equation of motion for classical
colored particles:
pμ = dxμ
dτ , dpμdτ = Qa Fμνa pν.
The classical chargesQa obey the Wong equations:
dQa
dτ = igpμ(Aadjμ )abQb.
An important difference compared to QED is that, since the charge Q is not constant, the
phase-space distribution may depend on Q as if it were a standard coordinate, f(x,p,Q ).
Again, the Liouville theorem implies that the distribution is constant along phase-space
trajectories, which can be rewritten as
0 = dfdτ =(dxμdτ ∂∂xμ + dpμdτ ∂∂pμ + dQadτ ∂∂Qa)f
= pμ
( ∂
∂xμ −QaFaμν ∂∂pν +ig(Aadjμ )abQb ∂∂Qa)f.
Compared to the QED case, the Vlasov equation contains an additional term because the
classical color charge is not constant in an external ﬁeld.
Then, we expand f ≡ f0 + f1 + ··· , assuming that f0 obeys the free Vlasov equation,
(p·∂)f0 = 0. The solution at order one in the external ﬁeld is then given by
f1 = pμp·∂(QaFaμν ∂∂pν −ig(Aadjμ )abQb ∂∂Qa)f0.
Anticipating the fact that at a later stage f0 will be replaced by an equilibrium distribution, we
can assume thatf0 does not depend onQa and therefore drop the last term, to obtain
f1 = pμp·∂ Qa[Faμν]abel. ∂∂pν f0.
Note that, to be consistent with the expansion in powers of the external ﬁeld, we must keep
only the Abelian part of the ﬁeld strength, since the commutator is of higher order in the gauge

===== PDF PAGE 181 =====
74 GLUON HARD THERMAL LOOP FROM COLORED CLASSICAL PARTICLES 303
ﬁeld. From f1, we get the following current:
Jμb =

exit_code=0
```

### 2026-11-16T18:24:36.703879+08:00

```bash
sed -n 10600,11080p planning/source-notes/qft-gelis-all.txt
```

```text

### 2026-11-16T18:24:36.703883+08:00

```bash
sed -n 12135,12590p planning/source-notes/qft-gelis-all.txt
```

```text
with gluons, we have
∑
r
Nrf0r = 2Neβ|p0| −1 + 2Nfeβ|p0| +1.
(For gluons, there are two polarization states andNadj = N. For quarks, there is a factor 2Nf
due toNf ﬂavors of quarks and antiquarks, a factor2 for their two spin states, and Nf = 12 .)

===== PDF PAGE 182 =====
304 5 LATTICE, FINITE T , STRONG FIELDS
After factorizing the radial and angular integrals, we obtain
Πμa,νb(k)= 2g2δab
∫ +∞
0
dp p
π2
( Nf/2
eβp +1 + N/2eβp −1)
×
∫ d2ˆp
4π
(
gμν − ˆPμkν +ˆPνkμ
ˆP·k +
ˆPμˆPνk2
===== PDF PAGE 209 =====
(ˆP·k)2
80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 331
)
79.f From the results of Problem 77, we know that P0 = exp(−Nclusters). It is only when
.
particles are produced without any correlations that the mean number of clusters is equal to
The angular integral is the same as in the Abelian case. In the radial integral, the term with the
the mean number of produced particles N+ (since each particle is its own cluster in that case).
Fermi–Dirac distribution is also the same, except for the changee2 → g2δabNf2 ,
Therefore, we expect in general that P0 ⁄= exp(−N+) due to correlations. This discrepancy
g2δabNf
can be made more explicit by using the formulas obtained above. By evaluating the generating
∫ +∞
functional at z = z = 0, one obtains the following expression for the vacuum-to-vacuum
0
transition probability (i.e., the vacuum survival probability):
dp p
P0 = exp
π2
(
1
−Nclusters
eβp +1 = g2T2Nf12 δab,
)
and we just need to calculate the second term in the radial integral:
with Nclusters = V
g2δabN
∫ d3p
∫ +∞
(2π)3 ln(1 +fp),
0
while the total particle multiplicity is
dp p
N+ = V
π2
∫ d3p
1
(2π)3 fp.
eβp −1 = g2T2Nπ2 δab ∫ +∞0 dx x 1ex −1
Only when the occupation number is small in all modes can we expand the logarithm in P0
= g2T2Nπ2 δab ∫ +∞0 dx x(e−x +e−2x +e−3x +··· )/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
and obtain P0 ≈ exp(−N+), but this relationship is not exact in very strong ﬁelds. This is
1
a limitation of the methods that give only P0 (for instance by providing a way to calculate
12 + 122 + 133 +···=ζ(2)=π26
the imaginary part of the effective action in a background ﬁeld): in general, knowledge ofP0
= g2T2N6 δab.
is not sufﬁcient to obtain the momentum dependence of the spectrum of produced particles
Therefore, the HTL gluon polarization tensor is identical to that of the photon, with only the
(proportional tofp).
following change of prefactor:
Source: Fukushima, K., Gelis, F. and Lappi, T. (2009), Nucl Phys A 831: 184.
e2T2
80. Schwinger Mechanism from Bogoliubov Transformations The goal of this problem
6 → g2T26 (N + Nf2 )δab.
is to rederive some of the results of Problem 79 in the canonical formalism, and to introduce the
In the non-Abelian case, the present approach based on classical transport has a very clear
concept of Bogoliubov transformation (quite generally, this is a mapping between the creation
advantage over the calculation of Feynman graphs (there are four of them). Moreover, from
and annihilation operators on the Fock space of an observer and those of another observer).
the current in Eq. (5.21), we can guess an effective Lagrangian whose derivative with respect
80.a Write the Hamiltonian of the theory of a complex scalar ﬁeld coupled to an external
to the ﬁeld gives the current:
electromagnetic potential. Specialize it to the gauge A0 = 0. Derive the Hamilton–
Leff = g22 ∫ d3p(2π)3p [Faνβ]abel. pβpρ(p·∂)2[Fρνa ]abel. ∑r Nrf0r.
Jacobi equations of motion.
This effective Lagrangian is sufﬁcient to recover the polarization tensor by taking two deriva-
80.b Decompose the ﬁeld operator φ in the in and out bases. Show that there is a linear
tives. But we can get a lot more out of it by noticing that it is not gauge invariant, but can be
relationship between the in and out creation and annihilation operators,
promoted into a gauge invariant one by very simple substitutions:
ak,out = αk ak,in +βk b†−k,in,b †k,out = α∗−k b†k,in +β∗−k a−k,in,
[
with|αk|2 −|βk|2 = 1.
Faνβ]abel. → Faνβ,p ·∂ → p·D,
80.c Show that the in vacuum state can be expressed in terms of out objects as follows:
which leads to
⏐⏐0in⟩ = e−V2 ∫ d3p(2π)3 ln(1+|βp|2) e∫ d3p(2π)3 βpα∗p a†p,outb†−p,out ⏐⏐0out⟩,
Leff = g22 ∫ d3p(2π)3p Faνβ[ pβpρ(p·D)2]ab Fρνb ∑r Nrf0r.
whereV is the volume of the system.
Note that this effective Lagrangian now contains terms of arbitrarily high order in the gauge
80.d Use this formula to calculate the inclusive one-particle and two-particle spectra, and
ﬁeld. In fact, by differentiating itn times with respect to the ﬁeld, it provides then-gluon HTL
check that they agree with the results of Problem 79.


===== PDF PAGE 183 =====
===== PDF PAGE 210 =====
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 305
332 5 LATTICE, FINITE T , STRONG FIELDS
vertex. The main reason why it is possible to capture the HTL results in such a simple setting
80.a Let us start from the Lagrangian density,
is that when the momentum circulating in the loop is much larger than the external momenta,
L =
then all the couplings of the external lines to the loop become eikonal, and therefore universal
(
(in particular, independent of the spin). In this approximation, the only thing that distinguishes
Dμφ
the various ﬁelds that can circulate in the loop is their phase-space distribution, their color
)∗(Dμφ)− m2φ∗φ.
representation and the corresponding number of degrees of freedom, while all the kinematical
The conjugate momentum of the ﬁeldsφ,φ∗ are respectively
dependence is universal.
Π ≡ ∂L∂∂0φ =( D0φ)∗,Π ∗ ≡ ∂L∂∂0φ∗ = D0φ, (5.33)
Sources: Kelly, P. F., Liu, Q., Lucchesi, C. and Manuel, C. (1994),Phys Rev Lett 72: 3461;
from which we obtain the Hamiltonian
Pisarski, R. D. (1998), Kinetic theory of hot gauge theories: Overview, details & extensions, in
H =
S´anchez, N. and Zichichi, A. (eds.), Current Topics in Astrofundamental Physics: Primordial
∫
Cosmology, NATO ASI Series, vol. 511 (Springer), p. 195.
d3x(Π∗∂0φ∗ +Π∂0φ −L)
75. Landau–Pomeranchuk–Migdal Effect The goal of this problem is to study the
=
emission of soft photons by a hot plasma of electrons and anti-electrons, and in particular
∫
to discuss the Landau–Pomeranchuk–Migdal effect, an interference effect that reduces the
d3x(Π∗Π +ieA0Πφ −ieA0Π∗φ∗ +m2φ∗φ +(Dφ)∗(Dφ)).
emission of soft photons in a hot medium.
Here,φ andΠ are operators in the Heisenberg picture satisfying the equal-time commutation
75.a Recall the relationship between the photon emission rate and the imaginary part of the
relation,
retarded photon self-energy.
[
75.b Explain why this self-energy can be obtained as
φ(x),Π (y)
−iΠijR (x,y )=− δJiind(x)δAj(y),
]
where Jiind is the electromagnetic current induced by the application of an external
=
potentialAj. Write this current in terms of the deviations from equilibriumδfe,δf ¯e of
x0=y0
the electron and anti-electron distributions.
iδ (x −y).
75.c Show thatδfe obeys the following Boltzmann–Vlasov equation:
It is convenient for the following discussion to choose a gauge where A0 = 0, because
(v·∂x)δfe − eT (v·E)nF (p)(1 −nF (p)) = δCe,p[δf],
in this gauge there is a non-ambiguous correspondence between the time dependence of a
whereδCe,p is a collision term andnF is the Fermi–Dirac distribution.
wavefunction and the physical energy of the corresponding particle (in particular, the concepts
75.d By explicitly writing the collision term with two-body collisions, show that
of positive and negative energies are invariant under the residual gauge freedom). In the
δCe,p =− e3nF (p)(1−nF (p))
temporal gauge, we have the following Hamiltonian:
∫ d2𝓁⊥
H =
(2π)2
∫
m2D
d3x(Π∗Π +m2φ∗φ +(Dφ)∗(Dφ)).
𝓁2⊥(𝓁2⊥+m2D )
The dynamics of the scalar ﬁelds are determined by the Hamilton–Jacobi equations of motion,
[
∂0φ = i [H,φ ]= Π∗,
F(x,p)− F(x,p −𝓁⊥)
∂0Π = i [H,Π ]=( D2 −m2)φ∗.
]
Note that, since we are not considering self-interactions of the scalar ﬁelds, these equations
,
of motion are linear. Moreover, since the background electromagnetic ﬁeld is treated as a
wheremD is the photon Debye mass andδfe ≡ eT nF (1 −nF )F.
classical ﬁeld given once and for all, there are no back-reaction effects (e.g., no photon loop
75.e Apply a Fourier transform to thex dependence, and discuss qualitatively the effect of
corrections on the propagator of the scalar). Thanks to the absence of loop corrections, solving
the integral on𝓁⊥ in the collision term.
these equations of motion as if they were classical equations of motion is sufﬁcient in order to
75.f Extra: in the regime where m ≫ mD , transform the Boltzmann–Vlasov equation into a
obtain the relationship between the ﬁeld operators at x0 =− ∞ andx0 =+ ∞. In other words,
diffusion equation that one may solve analytically.
solving exactly the simpliﬁed QFT problem considered here can be reduced to solving a set of

linear partial differential equations.
===== PDF PAGE 184 =====
80.b Let us now decompose the ﬁeld operator on the basis of creation or annihilation
306 5 LATTICE, FINITE T , STRONG FIELDS
operators. For this, we may choose either the in or the out basis. Let us mention here an
75.a We consider a hot plasma of electrically charged electrons and anti-electrons of massm
important subtlety. Even if we assume that the external electromagnetic ﬁeld vanishes when
(this could be their in-vacuum mass or, at very high temperature, the mass they acquire in the
plasma due to their interactions with their environment), interacting via photon exchanges (this
x0 = ±∞, there may be a non-zero gauge potential Ai at asymptotic times, Ain,outi . (Thesegauge potentials are constants, since there is no physical electromagnetic ﬁeld at asymptotic
point is not crucial and one could easily generalize this discussion to interactions via gluon

exchanges). The photon emission rate from a sample of this plasma can be obtained from the
===== PDF PAGE 211 =====
in-medium photon self-energy, as follows:
80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 333
2k0(2π)3 dNγd4xd3k = ∑pol. λϵ(λ)μ (k)ϵ(λ)ν (k)2 Im( −iΠμνR (K))eβk0 −1 .
times.) These asymptotic potentials modify the dispersion relation that relates the on-shell
There are various variants of this formula, differing in which form of the self-energy is used.
energy and the wavenumberk, since the equation of motion of the ﬁeld contains a covariant
Here, we choose the formula that involves the retarded self-energy, because we will want later
derivativeD rather than the ordinary derivative∂. For this reason, we must replace the usualEk
to obtain it from linear response theory. To be deﬁnite, let us choose the photon momentumk
byEin,out,+k =√m2 +(k +eAin,out)2 for particles and byEin,out,−k =√m2 +(k −eAin,out)2
to be aligned with thex3 direction. For on-shell photons, the sum over the polarizations simply
produces a projector on the planex1,x2 transverse to the photon momentum:
for anti-particles. Since we have Ein,out,−k = Ein,out,+−k , we can simplify the subsequent notationby systematically using only the energy of the anti-particles, which we denote more simply by
∑
Ein,outk ≡ Ein,out,+k (with k changed into −k when necessary). (In a detector, one measures thekinetic momentum of a particle, p ≡ k±eA. If particles are measured in the ﬁnal state, it
pol. λ
is convenient to choose a residual gauge in whichAout = 0, so that the wavenumber and the
ϵ(λ)μ (k)ϵ(λ)ν (k)Πμν(K)= ∑
kinetic momentum are identical atx0 =+ ∞.)
i=1,2
With this in mind, the ﬁeld operator may be decomposed in two different ways:
Πii(K).
φ(x)=
75.b The retarded photon self-energy can be viewed as a retarded correlation function
∫ d3k
between a pair of electromagnetic currents (this is correct in linear gauges, where there is no
(2π)3
spurious triple or quartic photon coupling). Then, by the same reasoning as for the derivation
[
of Kubo’s formula (see, for instance, Mahan, G. D. (2000), Many-Particle Physics (Kluwer
ak,in√
Academic)), the retarded current–current correlator can be obtained by looking at the induced
2Eink φ+k,in(x)+ b†k,in√2Ein−k φ−−k,in(x)]
current (the response) that appears in the system when we apply an external ﬁeld Aj (the
=
source):
∫ d3k
−iΠijR (x,y )=− δJiind(x)δAj(y), with Jiind ≡ e⟨ψγiψ⟩.
(2π)3
Since we want the photon self-energy in equilibrium, we need only consider arbitrarily small
[
external ﬁelds (in other words, we calculate the induced current only at linear order in the
ak,out√
applied external ﬁeld).
2Eoutk φ+k,out(x)+ b†k,out√2Eout−kφ−−k,out(x)], (5.34)
In thermal equilibrium, there are no net currents in the system (since the fermions and
where the functions φ±k,in andφ±k,out should be determined from the equations of motion (theycannot be simple plane waves because of the external ﬁeld). Note that we have adopted here a
anti-fermions have opposite charges and the same momentum distribution). The induced
slightly different normalization of the creation and annihilation operators than in the rest of
current can be obtained as
this book. Indeed, because we now haveEink ⁄= Eoutk , this choice of normalization turns out tobe a bit simpler.
Jiind(x)= 2e
As usual, we want the Heisenberg representation ﬁeld operator φ(x) to go to the in
∫ d3p
interaction picture ﬁeld operator when x0 → −∞ and to the out interaction picture ﬁeld
(2π)3 vi(δfe(x,p)− δf¯e(x,p)),
operator atx0 → +∞. These boundary conditions are realized if the functionsφ±k,in andφ±k,out
where vi ≡ pi/Ep andδfe (resp. δf¯e) is the deviation from Fermi–Dirac of the electron (resp.
have the following asymptotic behavior:
anti-electron) distribution induced by the external ﬁeld (think of an electric ﬁeld, which pulls
φ+k,in(x)= e−iEinkx0+ik·x forx0 → −∞,
electrons and anti-electrons in opposite directions). The prefactor 2 is due to the two spin
φ−k,in(x)= eiEinkx0+ik·x forx0 → −∞,
states of an electron.
φ+k,out(x)= e−iEoutk x0+ik·x forx0 → +∞,
75.c The external ﬁeld acts on the fermions of the system via the Lorentz force. The other
φ−k,out(x)= eiEoutk x0+ik·x forx0 → +∞.
effect that affects the fermion distribution is their collisions, which are responsible for the
The corresponding annihilation operators ain,out,b in,out remove an in-state or out-state particle

and anti-particle, respectively. Note that, for further convenience, we have chosen the spatial
===== PDF PAGE 185 =====
dependence in bothφ+k (x) andφ−k (x) to bee+ik·x, and thus the usual negative energy plane
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 307
wave e−ik·x corresponds to φ−−k(x). The canonical commutation relation for φ and Π issatisﬁed provided that we have
relaxation to equilibrium. Therefore, the equation that controls f and ¯f is a Boltzmann–Vlasov
[
equation:
ak,in,a†p,in] =[bk,in,b†p,in] =[ak,out,a†p,out] =[bk,out,b†p,out] =( 2π)3δ(k −p).
(v·∂x)fe
(Note the absence of factors2Ek here, because of our choice of normalization in (5.34).)
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Because the equation of motion satisﬁed by the ﬁeld is linear, there is a linear transformation
free streaming
that relates the coefﬁcient functions in the in and out decompositions. Moreover, if the
+e
background ﬁeld depends only on time, then this linear transformation does not mix values of
(

E +v×B
===== PDF PAGE 212 =====
)
334 5 LATTICE, FINITE T , STRONG FIELDS
· ∇pfe
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Vlasov term
= Ce,p[fe,f ¯e]/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
k. Let us introduce coefﬁcient αk andβk (known as Bogoliubov coefﬁcients) such that
collisions
lim
,
x0→+∞φ+k,in(x) ≡
wherevμ ≡ (1,vi). The Vlasov term, proportional to the Lorentz force, is responsible for the
√
Eink
Eoutk
(
αk e−iEoutk x0+ik·x +β∗k eiEoutk x0+ik·x).
change of the momenta of the particles as they move in the external ﬁeld. The anti-electron
In other words, αk and βk are deﬁned by decomposing the time dependence of φ+k,in on
distribution obeys the same equation with the changee → −e to account for the fact that they
the basis of the e±iEoutk x0 at large x0. In the absence of an external ﬁeld, one would simply
feel the opposite Lorentz force. In this problem, we need only consider small deviations of the
haveαk = 1 andβk = 0. Since (φ+k,in(x0, −x))∗ satisﬁes both the same initial condition as
distribution about the equilibrium Fermi–Dirac distribution, fe ≡ nF +δfe, f¯e ≡ nF +δf¯e,
φ−k,in(x) and the same equation of motion, they are therefore equal everywhere, and we havealso
and we can linearize the above Boltzmann–Vlasov equation in δfe,δf ¯e. Recalling that the
lim
deviationsδfe,δf ¯e are of the same order as the external electromagnetic ﬁeldE,B, and that
x0→+∞φ−k,in(x)=
the collision term vanishes when evaluated with the equilibrium Fermi–Dirac distribution, we
√
obtain
Eink
(v·∂x)δfe +e
Eoutk
(
(
E +v×B
α∗k eiEoutk x0+ik·x +βk e−iEoutk x0+ik·x).
)
Note now that the plane waves that appear in the integrands of the preceding two equations
· ∇pnF/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
are nothing but the asymptotic behavior of the waves φ±k,out. Since the waves φ±k,in and the
−1T nF (1−nF )v
φ±k,out obey the same linear equation of motion (the Klein–Gordon equation), these linear
= δCe,p[δf],
relationships are valid at all times (and not just atx0 =+ ∞):
where we denote by δC the linearized collision term. Since the Fermi–Dirac distribution is
isotropic, its derivative with respect to momentum is proportional to the velocity v, imply-
ing that only the electric ﬁeld E contributes. In the following, it will prove convenient to
parameterize the deviationsδf2,δf ¯e as follows:
δfe(x,p) ≡ eT nF (p)(1 −nF (p))F(x,p),
φ+k,in(x)=
δf¯e(x,p) ≡ −eT nF (p)(1 −nF (p))F(x,p),
where the functionF(x,p) is the same in both cases.
√
75.d Before linearization, the collision term with two-body collisionspq → p′q′ reads
Eink
Ce,p[f, ¯f]= ∑
Eoutk
α=e,¯e
(
∫
αk φ+k,out(x)+ β∗k φ−k,out(x)),
p′,q,q′
φ−k,in(x)=
(2π)4δ(p +q −p′ −q′) 116EpEp′EqEq′
√
⏐⏐⏐Mpq→p′q′⏐⏐⏐2
Eink
×
Eoutk
{
(
(1−fe(x,p))fe(x,p′)(1−fα(x,q))fα(x,q′)
α∗k φ−k,out(x)+ βk φ+k,out(x)).
−fe(x,p)(1−fe(x,p′))fα(x,q)(1−fα(x,q′))},
By inserting these formulas in (5.34), we obtain similar relationships between the creation and
where we have used the shorthand
annihilation operators in the two bases:
∫
ak,out = αk ak,in +βk b†−k,in,b †k,out = α∗−k b†k,in +β∗−k a−k,in.
q ≡
This linear relationship is known as a Bogoliubov transformation . Consistency with the
∫ d3q
commutation relations requires that
(2π)3 . Note that we sum over the two kinds of
|αk|2 −|βk|2 = 1.
scattering partners, electrons and anti-electrons. Next, we expand the distribution functions
(One can also check that this condition implies that the charge operator is the same in the two
about nF , keeping only terms linear in the deviations. Since δfe and δf¯e are opposite, the
bases: Qin = Qout.) The above relations can be inverted as follows:
deviations of the distributionfα of the scattering partner cancel when we sum over electrons
ak,in = α∗k ak,out −βk b†−k,out,b k,in = α∗−k bk,out −β−k a†−k,out.
and anti-electrons. Therefore, we get
80.c The vacuum is deﬁned as the state annihilated by all the annihilation operators:
δCe,p =− 2eT ∫p′,q,q′ (2π)4δ(p +q −p′ −q′) 116EpEp′EqEq′ ⏐⏐⏐Mpq→p′q′⏐⏐⏐2
ak
×nF (p)(1−nF (p′))nF (q)(1−nF (q′))[F(x,p)−F(x,p′)].
⏐⏐0⟩ = bk⏐⏐0⟩ = 0.
Note that the momentum transfer 𝓁 ≡ p −p′ = q′ −q is soft (of the order of the Debye mass,
(We ignore the in and out labels for this generic discussion.) A properly normalized state with
i.e., ∼ eT) compared to the typical momentum of the electrons and anti-electrons (of the order
one particle of momentumk can be constructed as

⏐⏐k⟩ = a†k√
===== PDF PAGE 186 =====
V
308 5 LATTICE, FINITE T , STRONG FIELDS
⏐⏐0⟩,
of the temperatureT). This implies that the scattering amplitude is dominated by the t-channel
where V is the spatial volume. (Note that here we are departing momentarily from the
diagram. Consequently, there is no difference between scattering off an electron and off an
convention used in the rest of the book, namely to have one-particle states normalized to2Ek
anti-electron, hence the prefactor2. Then, in order to rewrite the integrals in the collision terms

in terms of𝓁, we can use
===== PDF PAGE 213 =====
∫ d3p′
80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 335
(2π)22Ep′
particles per unit volume. The state deﬁned here contains exactly one particle in the volume
d3q
V.) Particles of momentum k can then be counted with the following particle number operator:
(2π)22Eq
dˆN
d3q′
d3k = a†kak(2π)3.
(2π)22Eq′ (2π)4δ(p +q −p′ −q′)
To check the consistency of these deﬁnitions, note that
≈
⟨
∫ d4𝓁
p
(2π)4
⏐⏐dˆN
d3q
d3k
(2π)32Eq
⏐⏐p⟩ =⟨0⏐⏐ ap√
1
V
4EpEq
a†kak
(2π)2δ(𝓁0 −𝓁·v)δ(𝓁0 −𝓁·vq),
(2π)3
where we have neglected terms quadratic in the soft momentum 𝓁 and where we denote
a†p√
vq ≡ q/Eq. We can also use the approximation
V
nF (p)(1−nF (p′)) ≈ nF (p)(1−nF (p)),
⏐⏐0⟩ = δ(p −k).
nF (q)(1−nF (q′) ≈ nF (q)(1−nF (q),
(We use the commutation relations in order to obtain the last equality.) The integral overd3k
and note that the integrated squared matrix element (at ﬁxed transfer 𝓁) can be expressed in
indeed gives1, i.e., the correct total number of particles in the state.
terms of the hard thermal loop spectral function (i.e., the imaginary part of the HTL photon
After having set these conventions, let us return to the problem of particle production. We
propagator):
consider the situation where there are no particles at x0 → −∞, i.e., the system is prepared in
2
the in vacuum state deﬁned by
∫ d3q
ap,in
(2π)3 2πδ(𝓁0 −𝓁·vq)nF (q)(1−nF (q)
⏐⏐0in⟩ = bp,in⏐⏐0in⟩ = 0.
⏐⏐Mpq→p′q′⏐⏐2
In the Heisenberg picture, the states do not evolve (the operators do), and therefore the system
16E2pE2q ≈ e2 T𝓁0vμvν ρμνHTL (𝓁),
stays in this state forever. What changes with time is the number operator used to count
with
particles. For instance, at x0 =+ ∞, the operatorak,out in general no longer annihilates⏐⏐0in⟩
ρμνHTL (𝓁) ≡ ∑
and an observer would see particles. In order to count the number of outgoing particles, we
α=T,L
must thus count the number of out particles contained in the state
Pμνα (𝓁) 2 ImΠα(𝓁)(𝓁2 − ReΠα(𝓁))2 +( ImΠα(𝓁))2
⏐⏐0in⟩. For this, it is useful to
(vμ ≡ (1,vi), and the projectors PμνT,L were deﬁned following Eq. (5.14)). Therefore, thelinearized collision term becomes
derive an expression for
δCe,p =− e3T nF (p)(1−nF (p))
⏐⏐0in⟩ in terms of the out quantities ap,out, bp,out and⏐⏐0out⟩. That is,
×
we should solve
∫ d4𝓁
ap,in
(2π)4 2πδ(𝓁0 −𝓁·v)T𝓁0vμvν ρμνHTL (𝓁)[F(x,p)− F(x,p −𝓁)].
⏐⏐0in⟩ =(α∗p ap,out −βpb†−p,out)⏐⏐0in⟩ = 0,
Here, it is important to recognize thatF(x,p) is strongly peaked whenp is aligned with the
bp,in
photon momentum, i.e., with the z axis. As a consequence, the variations of F are much faster
⏐⏐0in⟩ =(α∗−p bp,out −β−pa†−p,out)⏐⏐0in⟩ = 0.

Let us consider the following ansatz:
===== PDF PAGE 187 =====
⏐⏐0in⟩ ≡ C exp(∫ d3k(2π)3 χk a†k,out b†−k,out)⏐⏐0out⟩,
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 309
whereC is a normalization constant. (This state is a coherent state in which each particle is
when p varies in the transverse direction than in the longitudinal direction, implying that
paired with an anti-particle of opposite momentum – a necessary condition for any representa-
F(x,p)− F(x,p −𝓁) ≈ F(x,p)− F(x,p −𝓁⊥).
tion of the vacuum state because of charge and momentum conservation.) Requesting that this
For the same reason, we can approximateδ(𝓁0 −𝓁·v) ≈ δ(𝓁0 −𝓁z). Using the explicit form
state be annihilated byak,in andb−k,in puts some constraints on the functionχk. In order to
of the projectorsPμνT,L(𝓁),w eh a v e

vμvνPμνL (𝓁)=− vμvνPμνT (𝓁)=𝓁0=𝓁z 𝓁2⊥𝓁20 +𝓁2⊥.
===== PDF PAGE 214 =====
336 5 LATTICE, FINITE T , STRONG FIELDS
see this, let us denote
It is convenient to introduce the variablex ≡ 𝓁0/|𝓁|, since the HTL photon self-energies depend
A† ≡
only onx. The Jacobian of this change of variable is given by
∫ d3k
d𝓁0d2𝓁⊥
(2π3) χk a†k,out b†−k,out,
𝓁0
Bp ≡ α∗pap,out −βpb†−p,out,
𝓁2⊥
Cp ≡
𝓁20 +𝓁2⊥ = dxd2𝓁⊥x .
[
Therefore, the collision term reads
Bp,A†] = χpα∗pb†−p,out.
δCe,p =− e3nF (p)(1−nF (p))
Note thatCp commutes withA†. Therefore, we have
∫ d2𝓁⊥
BpA† = A†Bp +C,
(2π)2
Bp(A†)2 =( A†)2Bp +2CpA†,
[
···
F(x,p)− F(x,p −𝓁⊥)
Bp(A†)n =( A†)nBp +nCp(A†)n−1,
]
BpeA† = eA† (Bp +Cp).
× 2π ∫10 dxx { ImΠL (x)(𝓁2⊥+ReΠL (x))2+(ImΠL (x))2 − ImΠT (x)(𝓁2⊥+ReΠT (x))2+(ImΠT (x))2 }/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
Then, we have
=
(
m2D
α∗pap,out −βpb†−p,out)⏐⏐0in⟩ = eA† (Bp +Cp)⏐⏐0out⟩ = eA† (−βp +χpα∗p)b†−p,out⏐⏐0out⟩.
𝓁2⊥(𝓁2⊥+m2D )
.
The identity used in the second line, wheremD is the Debye screening mass, is an exact sum
For this to be zero, we must have χp = βp/α∗p. (One may check that the second condition
rule satisﬁed by the photon HTL self-energies.
leads to the same constraint.)
75.e Combining the above results, the Boltzmann–Vlasov equation can be written as follows
The next step is to determine the normalization constant so that
in terms ofF:
⟨
(v·∂x)F(x,p)+ e2T
0in
∫ d2𝓁⊥
⏐⏐0in⟩ = 1, i.e.,
(2π)2
⏐⏐C⏐⏐2 =⟨0out⏐⏐eAeA†⏐⏐0out⟩−1.
m2D
An easier way to handle this calculation is to discretize the integrals over the momentum inA
𝓁2⊥(𝓁2⊥ +m2D )
andA†. The consistent way of doing this is to write
[
A† = 1V ∑k χkA†k,A = 1V ∑k χ∗kAk,[
F(x,p)− F(x,p −𝓁⊥)
Ap,A†q] = Vδpq(a†p,outap,out +b−p,outb†−p,out/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
]
≡ Np
= v·E.
)
Using E ≡ −∂tA and applying a Fourier transform to turn x into the photon momentum K,
,
this equation leads to
[
δF(K,p)
Np,A†q] = 2VδpqA†p, [Np,Aq] =− 2VδpqAp,
δAj(K) = k0vjK·v +i e2TK·v ∫ d2𝓁⊥(2π)2 m2D𝓁2⊥(𝓁2⊥ +m2D )[δF(K,p)δAj(K) −δF(K,p−𝓁⊥)δAj(K) ] (5.22)
whereδpq is now a discrete Kronecker symbol. We have
(recall thatv ≡ p/Ep), whose solution must be inserted into
⟨
Im
0out
(
⏐⏐eAeA†⏐⏐0out⟩ =⟨0out⏐⏐ ∏
−iΠijR (K)) =− 4e2T ∫ d3p(2π)3 nF (p)(1 −nF (p))vi Im(δF(K,p)δAj(K) ).
p
The integral term in (5.22) takes into account the collisions of the emitter with the other
eχ∗p ApV ∏
particles in the plasma, while the ﬁrst term on the right-hand side of this equation would give
q
the contribution of the processe → eγ. Note that this collisionless contribution gives a purely
eχq

A†q
===== PDF PAGE 188 =====
V
310 5 LATTICE, FINITE T , STRONG FIELDS
⏐⏐0out⟩
real δF/δAj and therefore does not contribute to the photon yield, as expected from trivial
=
kinematics.
⟨
The equation (5.22) could in principle be solved iteratively in powers ofe2, by inserting
0out
inside the integral the solution obtained at the previous order. Assuming thatδF/δAj is of order
⏐⏐ ∏
one as in the collisionless limit, then the integral in (5.22) is also of order one (the typical𝓁⊥ is
p
of the order of the Debye mass mD ). We therefore see that multiple collisions all contribute to
eχ∗p ApV eχp A†pV ⏐⏐0out⟩.
the same order ifv·K ≲ e2T. On the other hand, simple kinematics leads to
Noting that
v·K ≈ k0
⟨
m2 +p2⊥
0out
2p2z . (5.23)
⏐⏐(Ap
Note that v · K can be interpreted as the inverse of the photon formation time , i.e., the
V
time necessary for the photon wave-packet to become separated from that of its emitter. In
)m(A†p
more physical terms, multiple scatterings are important when the photon formation time is
V
comparable to or larger than the mean free path, i.e., the distance traveled by the emitter
)n⏐⏐0out⟩ = δmn(n!)2
between two successive collisions (in this process, the relevant collisions are small-angle
(the factorial factors come from the fact that
collisions, separated by (e2T )−1). This effect is known as the Landau–Pomeranchuk–Migdal
(A†p
effect. In this regime, there is no point in solving (5.22) perturbatively as a series ine2 because
V
all orders are in fact comparable. From (5.23), we see thatv·K may be small when the electron
)n⏐⏐0out⟩ is a state with n pairs of particles
momentum is much larger than its mass,pz ≫ m, and its transverse momentump⊥ is small
and anti-particles with identical momenta, but this state is not normalized to account for the
(quasi-collinear emission of the photon). This is precisely what happens in a plasma at very

high temperature, where the relevant mass is a thermal mass of order m ∼ eT, the typical pz is
===== PDF PAGE 215 =====
80 SCHWINGER MECHANISM FROM BOGOLIUBOV TRANSFORMATIONS 337
fact that then pairs are identical), we obtain
⟨
of orderT, and photon emission happens predominantly at small anglesθ ∼ e (i.e.,p⊥ ∼ eT).
0out
⏐⏐eAeA†⏐⏐0out⟩ = ∏
The effect of these multiple scatterings on the photon spectrum can be estimated roughly
p
as follows. On the one hand, the photon formation length is 𝓁 ∼ 1/v·K. On the other hand, the
(1 −|χp|2)−1 = ∏
p
(1 +|βp|2)
= e
∑
k ln(1+|βp|2) = exp(V ∫ d3p(2π)3 ln(1 +|βp|2)).
(We have restored the continuous notation in the last expression.) Therefore, the normalized in
vacuum state expressed in terms of out objects reads
transverse momentum accumulated by the emitter over this distance isp2⊥ ∼ m2D𝓁/λ, whereλis the electron mean free path. This leads to
⏐⏐0in⟩ = e−V2 ∫ d3p(2π)3 ln(1+|βp|2) e∫ d3p(2π)3 βpα∗p a†p,outb†−p,out ⏐⏐0out⟩. (5.35)
𝓁
The physical meaning of this formula is that, for an observer measuring particles in the ﬁnal
λ ∼ pzmD√k0λ ≫k0→0 1.
state, the initially empty state has evolved into a coherent state ﬁlled with scalar–antiscalar
This implies that it takes a large number (growing like 1/√k0) of collisions to produce a
pairs of opposite momenta.
single soft photon. In other words, the soft photon spectrum is reduced by a factor √k0
80.d Using (5.35), it is now straightforward to calculate the single and double inclusive
compared to what one would obtain by multiplying the one-collision spectrum by the number
spectra by taking expectation values of the number operator. The spectrum of particles is
of collisions (this is known as the Bethe–Heitler limit). This suppression is a quantum effect,
dN+1
due to the destructive interference between photon emissions occurring at various points along
d3p =
the trajectory of the emitting electron (the photon formation length controls how far apart two
⟨
emissions that still interfere can be); see Figure 5.4 for an illustration.
0in
75.f This discussion can be made more quantitative analytically whenm ≫ mD (for this to
⏐⏐a†p,outap,out
be true, the bare mass of the electron must dominate over its thermal mass). In this case, we
(2π)3
may write
⏐⏐0in⟩.
∫ d2𝓁⊥
The easiest way to evaluate this expression is to note that the expression (5.35) for the initial
(2π)2
vacuum state behaves as a coherent state. In particular, it is a kind of “generalized eigenstate”
m2D
of the out annihilation operators:
𝓁2⊥(𝓁2⊥ +m2D )
ap,out
[δF(K,p)
⏐⏐0in⟩ = χpb†−p,out⏐⏐0in⟩, ⟨0in⏐⏐a†p,out = χ∗p⟨0in⏐⏐b−p,out.
δAj(K) −δF(K,p−𝓁⊥)δAj(K) ]
(The proof is the same as in the case of the usual coherent states, since b†−p,out andb−p,out are
≈
transparent to the action of ap,out anda†p,out.) Using these identities, we can relate the particle
∫ d2𝓁⊥
spectrum at p to the anti-particle spectrum at −p:
(2π)2
dN+1
m2D
d3p = |χp|2 dN−1d3(−p) + V(2π)3|χp|2.
𝓁2⊥(𝓁2⊥ +m2D )
However, since the external ﬁeld is spatially homogeneous and the initial state is the empty
1
state, these two spectra must be equal. Therefore, we get
2
dN+1
(
d3p = V(2π)3 |χp|21 −|χp|2 = V(2π)3 ⏐⏐βp⏐⏐2.
𝓁⊥ · ∇p
This expression exactly coincides with the one obtained in Problem 79. The two-particle
)2δF(K,p)

δAj(K) ≈ m2D8π ln( mmD )∇2pδF(K,p)δAj(K) .
===== PDF PAGE 216 =====
Here, we have used the separation of scale between the typicalp⊥ ∼ m and the Debye mass
338 5 LATTICE, FINITE T , STRONG FIELDS
mD in order to make a leading logarithmic approximation of the integral over𝓁⊥ (the logarithm
spectrum (equal sign) is given by

dN++2
===== PDF PAGE 189 =====
d3pd3q =
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 311
⟨
Figure 5.4 Left: illustration of the Landau–Pomeranchuk–Migdal effect. Right: the Feynman
0in
graphs contributing to the photon self-energy in the LPM regime (the black dots on the
⏐⏐
internal photons indicate the hard thermal loop re-summation).
(
must be large for this approximation to be justiﬁed). In this approximation, the equation (5.22)
a†p,outap,out
(2π)3
a†q,outap,out
that sums the multiple collisions of the emitter becomes a diffusion equation in the transverse
(2π)3 −δ(p −q)a†p,outap,out(2π)3 )⏐⏐0in⟩
velocity space (v⊥ ≡ p⊥/p):
= 1(2π)6 ⟨0in⏐⏐a†p,outa†q,outap,outaq,out⏐⏐0in⟩
ik0
= dN+1
(
d3p
1
dN+1
2
d3q +δ(p −p) V(2π)3|βp|4 .
(
Note that in the ﬁrst line, we are explicitly subtracting the delta function contribution in order
v2⊥ + m2p2 ) δFδAj −vj) +D∇2v⊥ δFδAj = 0,
to agree with the deﬁnition used in Problem 79, where the bi-spectrum was deﬁned so that its
where the diffusion constant is deﬁned as D ≡
integral is the mean value ofN+(N+ −1).
e2Tm 2D
Additional Note: In order to uncover the whole probability distribution, we can ﬁrst factorize
8πp2 ln(m/mD ). In order to solve this
the Fock space into a direct product of the Fock spaces for different momentak. An arbitrary
diffusion equation, let us deﬁneδF/δAj ≡ vj(ϕ(s)+ 1)/s withs ≡ 12v2⊥ (note that we musthaveϕ(0)=− 1 for this to be deﬁned at v⊥ = 0). In terms of ϕ ands,w eh a v e
state
sϕ′′ +i(α +βs)ϕ +iα = 0, with α ≡ k0m24Dp2 ,β ≡ k02D.
⏐⏐Ψ⟩ can be written as a tensor product,
This is a differential equation with polynomial coefﬁcients, which may be solved by taking a
⏐⏐Ψ⟩ ≡⨂
Laplace transform,
k
v(λ) ≡
⏐⏐Ψ⟩k.
∫ ∞
Since particles and anti-particles are produced in pairs of opposite momenta, it is natural to
0
group together particles of momentum k and anti-particles of momentum −k under the same
dse −λsϕ(s).
labelk. Thus we deﬁne the vacuum states
First, we obtain a differential equation forv(λ):
⏐⏐0,0⟩k of the subspaces k as
v′ + 2λ −iαλ2 +iβ v + 1 −iαλλ2 +iβ = 0.
ak,out
Since this is a ﬁrst-order equation, it can be solved analytically:
⏐⏐0,0⟩k = b−k,out⏐⏐0,0⟩k = 0,
v(λ)=− 1λ21 −λ2(λ1 +λλ1 −λ)μ ∫λ1λ dξ(1 −iαξ)(λ1 −ξλ1 +ξ)μ,
and
withλ1 ≡ √βe−iπ/4 andμ ≡ (α/2√β)e−iπ/4. In terms of this function, we have
⏐⏐0out⟩ is a tensor product of the vacuum states of the different modes,

⏐⏐0out⟩ =⨂
===== PDF PAGE 190 =====
k
312 5 LATTICE, FINITE T , STRONG FIELDS
⏐⏐0,0⟩k .
∑
An outgoing state withm particles of momentum k andn anti-particles of momentum −k at
i=1,2
x0 →∞ is then denoted by
Im
⏐⏐m,n⟩k =( a†k,out√m!V)m(b†−k,out√n!V )n⏐⏐0,0⟩k.
(
(Arbitrary states can be constructed from tensor products of these states.)
−iΠiiR (K)) =− 23e2T2 Imv(λ = 0)
Applying this decomposition, the in vacuum state leads to
= 23 e2T2β Re limλ→0
⏐⏐0in⟩ =⨂
∫λ1
k
λ
{
dξ
(1 +|βk|2)−1/2 exp[ βkVα∗ka†k,outb†out−k]⏐⏐0,0⟩k}.
(
By expanding the exponential we get
1 −iαξ)(λ1 −ξλ1 +ξ)μ
⏐⏐0in⟩ =⨂
= 23 e2T2β Re limλ→0
k
{
{
λ1
(1 +|βk|2)−1/2
∫1
∞∑
0
mk=0
dx
(βk
(1−x
α∗k
1+x
)mk ⏐⏐mk,mk⟩k
)μ
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−iα
≡ |0in⟩k
∫1
}
0
.
dx
In order to obtain the inclusive probabilityPk(m) of havingm pairs of momentum (k, −k),
x
we need to sum over all the possible numbers of pairs in the other momentum modes. This
[(1−x

1+x
===== PDF PAGE 217 =====
)μ
81 UNRUH EFFECT, HAWKING RADIATION 339
−1
corresponds to the following deﬁnition:
]
Pk(m)=
−iα ln
⏐⏐
(λ1
k
λ
⟨
)}
0in
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
⏐⏐m,m⟩k⏐⏐2
∼√β whenk0 → 0
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright⏐⏐⏐βkαk ⏐⏐⏐2m 11+|βk|2
∝
×
k0→0
∏
√
p⁄=k
k0.
∞∑
In the penultimate line, we have directly setλ = 0 in the terms that are regular in this limit, and
mp=0
isolated a term that has a logarithmic singularity. But note that the singularity only contributes
⏐⏐
to the imaginary part, so that the real part has a ﬁnite limit (λ should approach zero along the
p
positive real axis in order to obtain the correct result). When we combine this result with the
⟨
soft limit of the Bose–Einstein factor that multiplies Im (−iΠiiR (K)) in the photon emission
0in
spectrum, we obtain a spectrum in 1/√k0, instead of 1/k0 for bremsstrahlung induced by
⏐⏐mp,mp⟩p⏐⏐2
a single scattering. Thus, the effect of multiple scatterings is to reduce the emission of soft
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
photons by a factor√k0, as we had anticipated from our earlier qualitative discussion.
|αp|2
Let us ﬁnish with a general remark about the approach employed here to derive this effect.
1+|βp|2 =1
Naively, it may seem paradoxical to be able to derive a quantum interference effect by means
= 11 +|βk|2
of kinetic theory, which assumes that electrons behave completely classically. But in the LPM
( |βk|2
effect, the only object whose coherence matters is the photon wavefunction, while the electron
1 +|βk|2
can be totally classical.
)m
Sources: Baym, G., Blaizot, J.-P., Gelis, F. and Matsui, T. (2007),Phys Lett B 644: 48; Migdal,
.
A. B. (1956), Phys Rev 103: 1811.
This is the so called discrete Bose–Einstein (or geometrical) distribution, obtained in Problem
76. Microcanonical Equilibration in φ4 Scalar Theory Consider a massless scalar ﬁeld
79. Since momenta are uncorrelated, the full distribution is just the product of the distributions
theory withφ4 interaction in four spacetime dimensions. The goal of this problem is to study
in each momentum mode.
some aspects of classical dynamics in this ﬁeld theory, in relation to thermal equilibration.
Source: Fukushima, K., Gelis, F. and Lappi, T. (2009), Nucl Phys A 831: 184.
76.a What is the canonical energy–momentum tensor in this theory? What is its trace?
81. Unruh Effect, Hawking Radiation The goal of this problem is to study the relationship
76.b What is the equation of state relating pressure to energy density for a scale invariant
between the notions of vacuum and particles for an observer at rest and for an accelerated
system in statistical equilibrium?
observer, the ﬁnal result being a derivation of theUnruh effect. A similar approach, sketched at
76.c Consider a spatially homogeneous classical ﬁeld in this theory. Show that this ﬁeld is a
the end of the solution, can be used to derive the Hawking radiation of black holes (the analogy
periodic function of time, and ﬁnd the relationship between the period and the amplitude
is that a ﬁxed observer outside of a black hole feels an acceleration due to the gravitational
of the ﬁeld oscillations. Show that the trace of the energy–momentum tensor is non-zero
ﬁeld).
for this ﬁeld, but vanishes when averaged over one period.
81.a Show that the coordinates (t,x ) in a frame at rest and (τ,u ) in a frame with a constant
76.d Consider now a statistical ensemble of such homogeneous classical ﬁelds, obtained by
accelerationa in the directionx are related by
choosing an ensemble of initial conditions and letting the ﬁelds evolve according to
t = 1 +aua sinh(aτ),x = 1 +aua cosh(aτ).
the classical equation of motion. How does the expectation value of the trace of the
81.b Consider the alternative coordinatev ≡ a−1 ln(1 +au). Express (t,x ) in terms of (τ,v ).
energy–momentum tensor evolve with time?

===== PDF PAGE 191 =====
76 MICROCANONICAL EQUILIBRATION IN φ4 SCALAR THEORY 313
76.a The Lagrangian for this theory reads

exit_code=0
```
L = 12(∂μφ)(∂μφ) − g24!φ4.
Note that, in four spacetime dimensions, the coupling constant g is dimensionless. Therefore,
in the absence of a mass term, this theory is scale invariant. Its classical equation of motion is
a non-linear Klein–Gordon equation:

exit_code=0
```

### 2026-11-16T18:24:54.154919+08:00

```bash
sed -n 10970,11080p planning/source-notes/qft-gelis-all.txt
```

```text

### 2026-11-16T18:24:54.154927+08:00

```bash
sed -n 13052,13258p planning/source-notes/qft-gelis-all.txt
```

```text

===== PDF PAGE 189 =====
75 LANDAU–POMERANCHUK–MIGDAL EFFECT 311
Figure 5.4 Left: illustration of the Landau–Pomeranchuk–Migdal effect. Right: the Feynman
graphs contributing to the photon self-energy in the LPM regime (the black dots on the
===== PDF PAGE 225 =====
internal photons indicate the hard thermal loop re-summation).
82 ANDERSON LOCALIZATION 347
must be large for this approximation to be justiﬁed). In this approximation, the equation (5.22)
ρ → −∞. Therefore, the horizon of the black hole is located on the two semi-axes x+ = 0
that sums the multiple collisions of the emitter becomes a diffusion equation in the transverse
andx− = 0. It turns out that, in the Kruskal coordinates, there is no singularity at the horizon,
velocity space (v⊥ ≡ p⊥/p):
and they can also be used below the horizon.
ik0
Note now that (5.40) are formally identical to the relationship between the light-cone
(
coordinates of the static and accelerated observers, as discussed for the Unruh effect, provided
1
we interpret (4M)−1 as the acceleration. Therefore, we can exactly reproduce the same steps
2
without any modiﬁcation: (1) decompose the ﬁelds in Fourier modes in the two systems of
(
coordinates, (2) ﬁnd the Bogoliubov transformation that relates the two sets of creation and
v2⊥ + m2p2 ) δFδAj −vj) +D∇2v⊥ δFδAj = 0,
where the diffusion constant is deﬁned as D ≡
annihilation operators, (3) calculate the expectation value of the number operatorb†kbk of onesystem in the vacuum state of the other system. This leads to
e2Tm 2D
⟨
8πp2 ln(m/mD ). In order to solve this
0kruskal
diffusion equation, let us deﬁneδF/δAj ≡ vj(ϕ(s)+ 1)/s withs ≡ 12v2⊥ (note that we musthaveϕ(0)=− 1 for this to be deﬁned at v⊥ = 0). In terms of ϕ ands,w eh a v e
⏐⏐(b†kbk)staticobs. ⏐⏐0kruskal⟩ = Ve8πMk −1,
sϕ′′ +i(α +βs)ϕ +iα = 0, with α ≡ k0m24Dp2 ,β ≡ k02D.
i.e., a thermal equilibrium distribution with a temperature T =( 8πM)−1 (this is known as
This is a differential equation with polynomial coefﬁcients, which may be solved by taking a
the Hawking temperature). Let us end with a remark about why we use the Kruskal vacuum
Laplace transform,
in the last equation. Loosely speaking, in the presence of a black hole, other vacuum states,
v(λ) ≡
deﬁned by non-freely falling observers, would have a very large energy density near the black
∫ ∞
hole (because excitations that are not freely falling must have an energy that compensates
0
for the gravitational potential). This energy density would act as a source term in Einstein’s
dse −λsϕ(s).
equations and therefore have a strong back-reaction on the metric. Therefore, the physical
First, we obtain a differential equation forv(λ):
setup of quantum ﬁelds on top of an unperturbed Schwarzchild metric can only be achieved
v′ + 2λ −iαλ2 +iβ v + 1 −iαλλ2 +iβ = 0.
with the Kruskal vacuum.
Since this is a ﬁrst-order equation, it can be solved analytically:
82. Anderson Localization In a periodic atomic lattice, the electronic eigenfunctions take
v(λ)=− 1λ21 −λ2(λ1 +λλ1 −λ)μ ∫λ1λ dξ(1 −iαξ)(λ1 −ξλ1 +ξ)μ,
the form of Bloch states, whose energies span continuous bands. An electron whose energy
withλ1 ≡ √βe−iπ/4 andμ ≡ (α/2√β)e−iπ/4. In terms of this function, we have
lies in such a band can propagate freely over macroscopic distances (whether the material is a

conductor or an insulator depends on whether the Fermi energy lies inside a band or between
===== PDF PAGE 190 =====
two bands). The goal of this problem is to show that, in a disordered medium, electrons are
312 5 LATTICE, FINITE T , STRONG FIELDS
localized and cannot propagate.
∑
82.a Check thatγ0 =(100 −1),γi =( 0σ i−σi 0 ) provide a valid representation of the Dirac ma-
i=1,2
trices. Using this representation, show that the two upper components are the dominant
Im
ones in the non-relativistic limit, and show that the Dirac equation becomes
(
i∂tφ =
−iΠiiR (K)) =− 23e2T2 Imv(λ = 0)
(
= 23 e2T2β Re limλ→0
m −eA0 − (∇ −ieA)2
∫λ1
2m +eB·σ2m )φ.
λ
82.b Show that the two-point functionG(x,y ) ≡
dξ
⟨
(
φ(x)φ†(y)⟩ obeys a Dyson equation of
1 −iαξ)(λ1 −ξλ1 +ξ)μ
the formG = G0 +ieG0A0G in the case of a purely electric external ﬁeld.
= 23 e2T2β Re limλ→0
82.c Consider a medium in which the potential A0 has local Gaussian ﬂuctuations with
{
a variance
λ1
⟨
∫1
A0(x)A0(y)⟩ = σδ (x − y). Write the Dyson equation satisﬁed by G
0
at order e2. By calculating the self-energy that appears in this equation, show that
dx
the denominator of the dressed propagator has an imaginary part, which leads to an
(1−x
exponential damping of electronic waves.
1+x

)μ
===== PDF PAGE 226 =====
−iα
348 5 LATTICE, FINITE T , STRONG FIELDS
∫1
82.a To check that the announced matrices are a valid representation of the Dirac matrices,
0
we must verify that {γμ,γν} = 2gμν. This is completely straightforward using the fact that
dx
σiσj +σjσi = 2δij. With this representation in mind, we write the four-component Dirac
x
spinors as a combination of two two-component objects:
[(1−x
us(p) ≡
1+x
(
)μ
φ(p)
−1
χ(p)
]
)
−iα ln
.
(λ1
Consequently, the Dirac equation (/p −m)us(p)= 0 can be split into two separate equations
λ
forφ andχ,
)}
(Ep −m)φ −(p·σ)χ = 0, (Ep +m)χ −(p·σ)φ = 0,
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
from which we get
∼√β whenk0 → 0
χ = 1Ep +m (p·σ)φ ≈p≪m p·σ2m φ.
∝
Therefore, if we denoteφ(x) ≡ φ(p)e−ip·x, we obtain
k0→0
i∂tφ(x)=
√
(
k0.
m + (p·σ)2
In the penultimate line, we have directly setλ = 0 in the terms that are regular in this limit, and
2m
isolated a term that has a logarithmic singularity. But note that the singularity only contributes
)
to the imaginary part, so that the real part has a ﬁnite limit (λ should approach zero along the
φ(p)e−ip·x =(m − ∇2
positive real axis in order to obtain the correct result). When we combine this result with the
2m
soft limit of the Bose–Einstein factor that multiplies Im (−iΠiiR (K)) in the photon emission
)
spectrum, we obtain a spectrum in 1/√k0, instead of 1/k0 for bremsstrahlung induced by
φ(x),
a single scattering. Thus, the effect of multiple scatterings is to reduce the emission of soft
which is the non-relativistic Schr¨odinger equation (the term inm could be removed if we factor
photons by a factor√k0, as we had anticipated from our earlier qualitative discussion.
out an explicit factore−imt from the wavefunction). Thus, we see that, in this representation,
Let us ﬁnish with a general remark about the approach employed here to derive this effect.
Naively, it may seem paradoxical to be able to derive a quantum interference effect by means
of kinetic theory, which assumes that electrons behave completely classically. But in the LPM
the two upper components of a Dirac spinor obey the Schr¨odinger equation, while the two lower
effect, the only object whose coherence matters is the photon wavefunction, while the electron
can be totally classical.
components are suppressed by a power ofp/m (and in addition they are not independent).
Sources: Baym, G., Blaizot, J.-P., Gelis, F. and Matsui, T. (2007),Phys Lett B 644: 48; Migdal,
This equation, valid for a free fermion, can be promoted to an equation for the evolution of
A. B. (1956), Phys Rev 103: 1811.
a non-relativistic fermion in an external electromagnetic ﬁeld by simply replacing the ordinary
76. Microcanonical Equilibration in φ4 Scalar Theory Consider a massless scalar ﬁeld
derivatives by covariant ones: ∂μ → Dμ ≡ ∂μ − ieAμ. But in doing so, one should keep
theory withφ4 interaction in four spacetime dimensions. The goal of this problem is to study
in mind that ∇ and A do not commute, which imposes that we do this replacement before
some aspects of classical dynamics in this ﬁeld theory, in relation to thermal equilibration.
eliminating the Pauli matrices:
76.a What is the canonical energy–momentum tensor in this theory? What is its trace?
i∂tφ =
76.b What is the equation of state relating pressure to energy density for a scale invariant
(
system in statistical equilibrium?
m −eA0 −
76.c Consider a spatially homogeneous classical ﬁeld in this theory. Show that this ﬁeld is a
(
periodic function of time, and ﬁnd the relationship between the period and the amplitude
∇ −ieA)·σ
of the ﬁeld oscillations. Show that the trace of the energy–momentum tensor is non-zero
)2
for this ﬁeld, but vanishes when averaged over one period.
2m
76.d Consider now a statistical ensemble of such homogeneous classical ﬁelds, obtained by
)
choosing an ensemble of initial conditions and letting the ﬁelds evolve according to
φ
the classical equation of motion. How does the expectation value of the trace of the
=
energy–momentum tensor evolve with time?
(

m −eA0 − (∇ −ieA)2 +e(Ai∇j +∇iAj)ϵijkσk
===== PDF PAGE 191 =====
2m
76 MICROCANONICAL EQUILIBRATION IN φ4 SCALAR THEORY 313
)
76.a The Lagrangian for this theory reads
φ
L = 12(∂μφ)(∂μφ) − g24!φ4.
=
Note that, in four spacetime dimensions, the coupling constant g is dimensionless. Therefore,
(
in the absence of a mass term, this theory is scale invariant. Its classical equation of motion is
m −eA0 − (∇ −ieA)2
a non-linear Klein–Gordon equation:
2m +eB·σ2m/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ H
)
φ,
where B is the external magnetic ﬁeld. From this Schr ¨odinger equation, we read the Hamilto-

exit_code=0
```
nianH that drives the evolution of this fermion in the non-relativistic limit.

===== PDF PAGE 227 =====
82 ANDERSON LOCALIZATION 349
82.b When the external ﬁeld is a pure electric ﬁeld, we may choose a gauge in whichA = 0,
so that the above Hamiltonian simpliﬁes to
H = m − ∇2
2m −eA0.
Consider the time-ordered two-point correlation function of the non-relativistic ﬁeldφ,
G(x,y ) ≡
⟨
Tφ(x)φ†(y)⟩ = θ(x0 −y0)⟨φ(x)φ†(y)⟩ −θ(y0 −x0)⟨φ†(y)φ(x)⟩.
Applying a time derivative to this deﬁnition, and recalling the equal-time anti-commutator{
φ(x),φ†(y)} = δ(x−y) (this is the restriction to the two upper components of the canonical
anti-commutation relation of Dirac spinors), we obtain
(
i ∂∂x0 −H)G(x,y )= iδ (x −y).
We can also deﬁne the free correlation functionG0, deﬁned as a Green’s function of the
free Hamiltonian, H0 ≡ m − ∇22m . Since H = H0 −eA0, the equation forG can be rewrittenas follows:
(
i∂x0 −H0
)
G = iδ(x −y)− eA0G.
This can be solved formally in the form of a Dyson equation,
G = G0 +ieG0A0G.
82.c Diagrammatically, the expansion of the solution of the Dyson equation for the propaga-
tor reads
= + + + + . . . GG 0 ieA0 .
If the external potential is ﬁxed, the next step is to perform the geometrical sum contained in
this solution (which may be a rather difﬁcult task if the potentialA0 has a non-trivial spatial
dependence).
Another interesting situation is when this potential ﬂuctuates, with a probability distribution
W[A0]. In this case, the above solution must be averaged over all the conﬁgurations of A0,
weighted by the distribution W[A0]. Diagrammatically, this amounts to connecting all the
crosses in the above representation by links and vertices as allowed byW[A0]. For instance, a
random time-independent external potential with only local Gaussian ﬂuctuations would have
the following distribution:
W[A0]= exp( − 12 ∫ d3x A0(x)A0(x)2σ ),
for which the only possible connection is a link
⟨
A0(x)A0(y)⟩ = σδ (x −y).
(This is independent of time, and the delta function is a spatial one.) With such Gaussian
ﬂuctuations of the external ﬁeld, the expectation value of the propagator takes the following

===== PDF PAGE 228 =====
350 5 LATTICE, FINITE T , STRONG FIELDS
form:
= + + + + . . . 
1PI non 1PI
.
This has the form of a propagator dressed by self-energy corrections. This plain perturba-
tive expansion can be improved by calculating the self-energy at a certain order in e2 and
by re-summing its repeated insertions on the free propagator (this is a geometrical series).
When doing this, it is important to include only one-particle-irreducible contributions in
the self-energy in order to avoid double counting. If we restrict ourselves to the order- e2
self-energy, the equation for the dressed propagator is a Dyson equation that reads
= + .
This is simple algebraic equation in momentum space:
G(p)= G0(p)+ G0(p)
(
−iΣ(p)
)
G(p), i.e., G(p)= i
p0 −m − p22m −Σ(p),
and the self-energy is given by
Σ(p)=− ie2σ
∫ d4k
(2π)4 2πδ (k0) ip0 +k0 −m − (p+k)22m
= 2e2σm
∫ k2dkd cosθ
(2π)2
1
2m(p0 −m)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≈ p2 on-shell
−p2 −k2 −2pk cosθ
=− e2σmp ∫ kdk(2π)2 ln(k +2pk −2p)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
iπθ (2p−k)+real terms
=− ie2σmp2π + real terms.
Note that the real part of the self-energy, which we have not calculated here, is ultraviolet
divergent. This could be remedied on physical grounds by noting that the inverse inter-atomic
distance should certainly act as a cutoff in this integral since the external ﬁeld is not an
uncorrelated noise on atomic scales.
However, the main result here is the fact that the self-energy has an imaginary part
proportional to the strength of the ﬂuctuations of the external ﬁeld. The physical implication
is that fermions cannot propagate in such a disordered medium, since their propagator in
coordinate space is exponentially damped. The damping length is given by the inverse of the
imaginary part ofΣ and is thus inversely proportional to the strengthσ of the ﬂuctuations of
the external ﬁeld. Moreover, this imaginary part exists at all values of the momentump, which
means that there is no energy range where electrons can propagate freely in this material. This
phenomenon, known as Anderson localization, is a very important result of solid-state physics
that implies that disordered media are insulators (unlike periodic media, which may have a
conduction band, i.e., an energy range in which the electronic states – known as Bloch states –
are completely delocalized over macroscopic sizes).

===== PDF PAGE 229 =====
83 SCALING THEORY OF ANDERSON LOCALIZATION 351
83. Scaling Theory of Anderson Localization Problem 82 corresponds to the limit of
strong disorder, in which the motion of electrons is damped regardless of the dimension of
space. The situation regarding Anderson localization is in fact richer than what is suggested
by that simple study, and depends crucially on the dimension. As we shall see, it is possible

exit_code=0
```

### 2026-11-16T18:26:32.283221+08:00

```bash
sed -n 13253,13325p planning/source-notes/qft-gelis-all.txt
```

```text
===== PDF PAGE 229 =====
83 SCALING THEORY OF ANDERSON LOCALIZATION 351
83. Scaling Theory of Anderson Localization Problem 82 corresponds to the limit of
strong disorder, in which the motion of electrons is damped regardless of the dimension of
space. The situation regarding Anderson localization is in fact richer than what is suggested
by that simple study, and depends crucially on the dimension. As we shall see, it is possible
to gain a semi-quantitative understanding of this question without considering any speciﬁc
model, by using scaling arguments and ideas inspired from the renormalization group. For this,
we consider a cubic sample of sizeL ind dimensions. We denote byg its conductance (the
inverse of its resistance), and we deﬁneβ ≡ d(lng)/d(lnL).
83.a Explain why we have the following two limits:
lim
g→0
β = ln(g), lim
g→+∞
β = d −2.
83.b Use these limits to discuss the behavior of the conductance asL →∞ . Show that there
is a qualitative difference betweend = 1,2 andd = 3.
83.a Let us consider a cubic sample of material of length L.I n d spatial dimensions, its
volume is therefore Ld and its transverse section is Ld−1. We denote by g its electrical
conductance, i.e., the inverse of its resistanceR. This parameter depends on the size L (this
is quite obvious from the fact that a thick wire conducts better than a thin one), and it is
convenient to introduce aβ function that controls its variation withL:
β(g) ≡ Ld ln(g)dL .
(The implicit assumption here is that the β function depends on the conductance, but not
explicitly on the system size. In other words, it may depend on the system size only through
the value of the conductance.)
Consider ﬁrst the limit of strong disorder, studied in Problem 82. In this limit, the
conductance goes to zero exponentially with the system size (in any dimensiond):
g ∝ e−L/ξ,
where the lengthξ is given by the inverse of the imaginary part of the self-energy calculated
in that problem. This formula follows from the fact that electrons cannot propagate beyond a
distance ξ, so the conductance is non-zero only for systems whose length is smaller than ξ.
Therefore, in this limit, we have
β(g) ≈
g→0
−Lξ = ln(g)+ const.
The opposite limit, g → +∞, is the limit of good conductors. In this situation, the
resistance of a sample of lengthL and transverse sectionA is given by
R ∝ LA = g−1L2−d,
where the unwritten prefactor is the resistivity (i.e., the inverse of the conductivity). Since
R = g−1, we obtain the following behavior for theβ function in this limit:
β(g) ≈
g→+∞
d −2.

===== PDF PAGE 230 =====
352 5 LATTICE, FINITE T , STRONG FIELDS
g
β(g)
d = 3
d = 2
d = 1
g*
Figure 5.7 Behavior of theβ function for the conductance ind = 1,2,3 dimensions. The
arrows indicate the ﬂow towards larger sizes.
83.b Assuming a monotonous behavior of theβ function between the two limits we have
considered, we obtain the curves sketched in Figure 5.7. In this ﬁgure, we show theβ functions
ind = 1,2,3 spatial dimensions. We have also indicated by arrows on the curves the direction
of the ﬂow when the size L increases (this follows directly from the sign of the β function).
Interestingly, there are qualitative differences betweend = 1,2 andd = 3:
• d = 1,2 : theβ function is always negative, implying that the conductance goes to zero
as L →∞ . Therefore, one- and two-dimensional materials become insulators when
their size becomes inﬁnite, no matter how weak the disorder is.
• d = 3: the β function vanishes at some critical value g∗, is negative for g<g ∗
and positive for g>g ∗. Moreover, this critical point is repulsive. Therefore, a
three-dimensional material with a sufﬁciently small disorder (such that g>g ∗ at a
certain scale) may be a conductor when L →∞ , while for a stronger disorder (such that
g<g ∗ at a certain scale) it becomes an insulator whenL →∞ .
Source: Abrahams, E., Anderson, P. W., Licciardello, D. C. and Ramakrishnan, T. V . (1979),
Phys Rev Lett 42: 673.

===== PDF PAGE 231 =====

exit_code=0
```

### 2026-11-16T18:26:32.346989+08:00

```bash
python3 -c 'from pathlib import Path; import subprocess; out=Path("checks/qft-expansion-gelis-thermal-source-pages"); out.mkdir(parents=True,exist_ok=True); src="/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf"; [subprocess.run(["pdftoppm","-f",str(p),"-l",str(p),"-singlefile","-scale-to","1600","-png",src,str(out/("page-%03d"%p))],check=True) for p in (161,164,171,179,188,209,217,228)]'
```

```text

exit_code=0
```

### 2026-11-16T18:28:03.845507+08:00

```bash
rg -n '^## |范围与阅读状态|结论：' planning/qft-expansion-gelis-thermal-review.md
```

```text
9:## Problem 69：Banks–Casher Relation
11:- **范围与阅读状态：** 题面 PDF161 / 书283；完整相关解答 PDF162–163 / 书284–285（止于70题开始前）。已读全部相关文本；尚未逐页视觉核对。
18:- **结论：** 优先候选；原题定理本身不够编程难，必须落实上述谱族、误差和极限判断。
20:## Problem 70：Nielsen–Ninomiya Theorem
22:- **范围与阅读状态：** 题面 PDF163–164 / 书285–286；完整解答（含 Poincaré–Hopf 证明草图和图）PDF164–168 / 书286–290，止于71题开始前。已完整核读相关文本；尚未逐页视觉核对。
29:- **结论：** 强烈推荐优先入选；需要选择可证明根完备性的动量核族，避免只靠高维随机搜索。
31:## Problem 72：Center Symmetry and Deconfinement
33:- **范围与阅读状态：** 题面 PDF171–172 / 书293–294；完整相关解答 PDF172–175 / 书294–297，止于73题开始前。题面(a)–(e)、重夸克自由能推导和基本/伴随表示的讨论均已全文核读；尚未逐页视觉核对。
40:- **结论：** 有条件保留；要完成“扇区混合不等于禁闭”的研究判断和可控有效模型设计，原题纯证明直接封装不算高难数值任务。
42:## Problem 73：Photon Hard Thermal Loop from Classical Particles
44:- **范围与阅读状态：** 题面与解答 PDF176–179 / 书298–301，止于74题开始前；(a)–(e)全部核读，含有效作用量变分、径向积分和角积分。尚未逐页视觉核对。
51:- **结论：** 优先保留，尤其适合考查解析处方、守恒约束和尺度近似。
53:## Problem 75：Landau–Pomeranchuk–Migdal Effect
55:- **范围与阅读状态：** 题面 PDF183 / 书305；完整解答 PDF184–190 / 书306–312，止于76题开始前。已全文核读(a)–(f)，包括热光子率、线性碰撞项、HTL和规则、形成时间估计、扩散近似及 Laplace 解尾部的极限处方；尚未逐页视觉核对。
62:- **结论：** 高质量优先候选，工程量比单积分题大；先做精确核模型和双路线收敛，不应只抄一个 `√k0` 标度充当任务。
64:## Problem 80：Schwinger Mechanism from Bogoliubov Transformations
66:- **范围与阅读状态：** 题面 PDF209 / 书331；完整解答与附加离散模概率讨论 PDF210–217 / 书332–339，止于81题开始前。已完整核读(a)–(d)、归一化和 per-mode 几何分布；尚未逐页视觉核对。PDF209页上半是79题结尾，不属于80题。
73:- **结论：** 高质量优先候选；脉冲族和统计量应共同成一道完整题，不按单/双脉冲拆题。
75:## Problem 82：Anderson Localization（须纠正原解解释后才能采用）
77:- **范围与阅读状态：** 题面 PDF225 / 书347；完整解答 PDF226–228 / 书348–350，止于83题开始前。已全文核读(a)–(c)，并补读相邻83题及其解答 PDF229–230 / 书351–352，确认其讨论维数及无序强度的边界。已视觉查看 PDF228 的公式和结论，其余相关页为全文文本核读。
84:- **结论：** **不建议原样入选高难20题。** 若缺少独立主题，可采用上述纠错/输运改造并补充可靠定域来源；若已有20道更直接且物理闭合的候选，82应保留为后备。
86:## 七题取舍与相互独立性

exit_code=0
```

### 2026-11-16T18:29:51.403655+08:00

```bash
cat planning/work-order-radovanovic-next.md
```

```text
# Gelis 有限温、格点与强场候选核读

这是主代理分配的当前子任务。只做来源评审，不修改现有题包。

读取 `planning/source-notes/qft-gelis-all.txt` 中 Problem 69、70、72、73、75、80、82 的完整题面与解答。页码以 `===== PDF PAGE N =====` 为准，逐页确认印刷页。本书扫描件章节重排，不能使用全书统一偏移。

写入 `planning/qft-expansion-gelis-thermal-review.md`。每题列：原题号与准确 PDF/印刷页范围；已完整核读范围；核心物理工作及关键关系；容易误述的边界；有研究判断的原创 benchmark 改造；结构化交付与客观评分；两条独立真值路线；相互独立性。80 是标量 QED，不是费米子 QED。70 作为增强独立性的候选，与另一本六维 phi^3 比较。

起始页线索：69 PDF161；70 PDF163；72 PDF171；73 PDF176；75 PDF183；80 PDF209；82 PDF225。以实际题目开始结束为准。必要时视觉检查原页。

每完成两题先落盘，再继续。不要等全部结束才保存。不声称未实际做过的核读、渲染或测评。所有 shell 命令执行前在 commentary 展示，用 `python3 tools/run_logged.py --log checks/qft-expansion-gelis-thermal-command-log.md -- COMMAND ...` 记录。

exit_code=0
```

### 2026-11-16T18:33:09.195289+08:00

```bash
cat planning/work-order-radovanovic-next.md
```

```text
# Gelis 有限温、格点与强场候选核读

这是主代理分配的当前子任务。只做来源评审，不修改现有题包。

读取 `planning/source-notes/qft-gelis-all.txt` 中 Problem 69、70、72、73、75、80、82 的完整题面与解答。页码以 `===== PDF PAGE N =====` 为准，逐页确认印刷页。本书扫描件章节重排，不能使用全书统一偏移。

写入 `planning/qft-expansion-gelis-thermal-review.md`。每题列：原题号与准确 PDF/印刷页范围；已完整核读范围；核心物理工作及关键关系；容易误述的边界；有研究判断的原创 benchmark 改造；结构化交付与客观评分；两条独立真值路线；相互独立性。80 是标量 QED，不是费米子 QED。70 作为增强独立性的候选，与另一本六维 phi^3 比较。

起始页线索：69 PDF161；70 PDF163；72 PDF171；73 PDF176；75 PDF183；80 PDF209；82 PDF225。以实际题目开始结束为准。必要时视觉检查原页。

每完成两题先落盘，再继续。不要等全部结束才保存。不声称未实际做过的核读、渲染或测评。所有 shell 命令执行前在 commentary 展示，用 `python3 tools/run_logged.py --log checks/qft-expansion-gelis-thermal-command-log.md -- COMMAND ...` 记录。

exit_code=0
```
