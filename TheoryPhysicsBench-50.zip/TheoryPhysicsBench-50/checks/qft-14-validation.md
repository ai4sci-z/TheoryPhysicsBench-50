# qft-14 开发验收记录

日期：2026-11-16。本记录依据已保存的 Docker Linux 校准结果生成。

- 全部 15 项检查通过。
- 原始指标：Wong 色荷输运的路径顺序与规范协变：归一化误差，单位：百分点，越低越好。
- 简单基线：2.6195672859738；专家参考：6.5073874754995e-10；端点容差：2e-05。
- 参考求解实测：0.0151948 秒；基线：0.000825417 秒；离线独立真值生成：0.0238585 秒。
- 系统：Linux-6.12.76-linuxkit-aarch64-with-glibc2.36；Python：3.12.13；固定依赖见 environment/requirements.txt。
- 独立路线：50-digit ordered segment exponentials; spectral analytic force integral; endpoint gauge conjugation。
- 课程统一质量函数 SHA256：`797343b693d5676a4bd0dd13a8270038d2f879bcb41f863ec87563ead807def4`。

## 证据与可复现入口

- 完整逐项结果：[校准JSON](qft-14-calibration.json)。
- [题面](../tasks/qft-14/instruction.md)、[参考推导](../tasks/qft-14/solution/README.md)。
- [来源](../provenance/qft-14.md)、[材料和公平性](qft-14-materials-and-fairness.md)。
- 全部外层命令记录：[命令日志](qft-13-19-command-log.md)。
- 复核命令：`python3 tools/run_qft13_19_checks.py 14`（Linux、项目根目录；不带 --calibrate）。
- 实测产物：`runs/qft-14/development-answers/`。

## 检查范围

- linux_environment：通过。
- reference_matches_independent_truth：通过。
- reference_improves_baseline：通过。
- course_quality_unchanged：通过。
- baseline_zero_reference_one：通过。
- independent_truth_full_credit：通过。
- reordered_same_score：通过。
- invalid_rejected：通过。
- wrong_values_penalized：通过。
- feedback_accepts_reference：通过。
- verifier_entrypoint：通过。
- public_physical_explorer_runs：通过。
- solve.py_cli：通过。
- baseline.py_cli：通过。
- unitarity_hermiticity_casimirs_gauge_covariance：通过。

## 集成状态

本记录完成了真实 Linux 容器中的参考、基线、独立真值、评分入口、无效/错误产物、合法重排、公开反馈和本题物理约束检查。
Harbor 0.24.0 的 oracle/nop 集成记录由整套任务中央运行器另行保存；本记录本身不声称已完成 Harbor 集成或课程正式 Codex 三次测评。
参考数值计算使用公开模型，离线真值仅在 verifier 私有目录。具体任务为固定实例，不声称有隐藏泛化样本。
