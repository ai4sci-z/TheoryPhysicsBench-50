# 来源与本地改造

Voja Radovanović，*Problem Book in Quantum Field Theory*，原题 11.8。

PDF SHA256: 26fabda40b17a8cf937444f9b882900c4b4352568d67619924e5696c62a9a6db

页码（PDF / 印刷）: [{"pdf": [65, 65], "printed": [63, 63], "role": "题面"}, {"pdf": [219, 220], "printed": [221, 222], "role": "解答"}]

原书工作：移位后的两标量模型中枚举五类一圈贡献，含真空tadpole，用同一正则化和真空条件证明Σπ(0)=0。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。
