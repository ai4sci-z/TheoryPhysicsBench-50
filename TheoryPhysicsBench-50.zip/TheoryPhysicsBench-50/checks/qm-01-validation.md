# qm-01 校准与运行记录

日期：2026-11-16。

## Linux 数值验证

环境：Docker Linux aarch64，Python 3.12.13，NumPy 2.1.3、SciPy 1.14.1、mpmath 1.3.0；4 CPU、4 GB、断网、0 GPU。

独立真值通过 70 位行列式二分与分段全空间积分生成，不导入参考求解器。八组工况的束缚态数依次为 1、2、2、2、1、2、2、1；匹配方程最大残差小于 2e-71，对称势各态左半轴概率均为 1/2。

| 产物 | 原始匹配误差/百分点 | 质量分 |
|---|---:|---:|
| 孤立势阱弱耦合基线 | 41.8244394323801 | 0 |
| 完整双势阱参考解 | 9.995160479817116e-14 | 1 |
| 工况及态顺序改变 | 与参考相同 | 1 |
| 合法但错误的能量与概率 | 81.05518607255141 | 0 |
| 漏报 well-02 的一个态 | 6.250000000000099 | 0.8505658393795155 |
| 重复 well-02 的一个态 | 3.8049323699915556 | 0.9090261000116185 |
| 缺工况、重复 ID、布尔数值、零能态 | 无效 | 0 |

11 项自动检查通过。实际 test.sh 入口的参考解得 1、无答案文件得 0。基线耗时 0.2345 秒，参考解 0.2325 秒（不含容器启停）。完整数值见 qm-01-calibration.json 与 qm-01-truth-validation.json。

本轮修正了说明中 lambda_-(0) 与其导数的混淆；漏态、重复态检查改为真正有两个态的 well-02。物理解、独立验证值与评分协议保持一致。

## Harbor 0.24.0

单次、单并发、无重试：

| Agent | Reward | 异常数 | 耗时 | 原始记录 |
|---|---:|---:|---:|---|
| oracle | 1 | 0 | 33 秒 | runs/qm-01/harbor-macos-compat/oracle/2026-11-16__13-27-43/ |
| nop | 0 | 0 | 27 秒 | runs/qm-01/harbor-macos-compat/nop/2026-11-16__13-28-22/ |

使用 ASCII 临时路径避开课程目录百分号的 Compose 解析问题。macOS Docker Desktop 的 verifier egress-control 不兼容；仅临时副本将 verifier 网络改为 public。正式 task.toml 仍为 no-network；直接数值验证使用 --network none。课程 Linux 正式环境须保留正式配置。

上述 Harbor 记录在课程原版 quality_score.py 恢复前生成，原始分数对应的换算公式相同；恢复原版后的数值评分复核单独保存，不把旧记录当作新版本运行。正式 Codex 每题三次独立测评在题集冻结后统一进行。

## 复现命令

在项目根目录运行：

```bash
docker build -t theory-physics-qm01:dev tasks/qm-01/environment
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-qm01:dev python tools/build_qm01_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-qm01:dev python tools/run_qm01_checks.py
python3 tools/run_harbor_local_checks.py qm-01 --macos-compat
```

主动重新登记端点时给数值检查追加 --calibrate；通常只复核固定端点。
