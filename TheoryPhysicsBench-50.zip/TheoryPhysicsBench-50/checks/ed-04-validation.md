# ed-04 Linux 开发验证

本地Docker Desktop Linux aarch64、Python3.12.13、4CPU、4GiB、断网、0GPU；日期2026-11-16。本记录不代表正式Codex测评。

|方案|原始误差（百分点）|质量分|耗时|
|---|---:|---:|---:|
|64节点直接角度求积基线|26.109281722028477|0|0.086秒|
|源时间像差坐标多项式参考|3.913911249553121e-10|1|0.258秒|
|独立65位角积分答案|0|1|1.52秒生成真值|

独立真值的直接θ积分与有理原函数最大相对差 (6.2\times10^{-62})，与李纳总功率及 \(\langle\cos\theta\rangle=\beta\) 的核验均通过。14项校准检查通过：参考/基线端点、合法重排、错误功率/锥/动量、非法输出、反馈、test.sh入口和课程原版quality_score均已检查。详见 `ed-04-calibration.json`、`ed-04-truth-validation.json`。

Harbor oracle/nop和正式Codex三次测评未执行，主代理补跑。命令及输出保存于 `checks/ed-04-command-log.md`。
