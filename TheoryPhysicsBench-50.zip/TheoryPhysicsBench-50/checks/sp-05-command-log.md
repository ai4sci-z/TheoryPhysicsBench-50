
### 2026-11-16T18:25:02.564049+08:00

```bash
cat tools/run_sp04_checks.py tools/build_sp04_truth.py tasks/sp-04/tests/test.sh tasks/sp-04/tests/test_outputs.py
```

```text

### 2026-11-16T18:25:02.564054+08:00

```bash
rg -n -C 5 '3\.8|3\.9|Maxwell|麦克斯|范德瓦' planning/source-notes/sp-sol-all.txt
```

```text

### 2026-11-16T18:25:02.564026+08:00

```bash
cat planning/work-order-sp02.md tasks/sp-04/task.toml tasks/sp-04/environment/Dockerfile tasks/sp-04/environment/requirements.txt
```

```text
"""Actual verifier/public-entry calibration for the two-subband Fermi gas."""
import argparse
from copy import deepcopy
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-04';DATA=TASK/'environment/public';TESTS=TASK/'tests';sys.path.insert(0,str(TESTS))


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def main():
    p=argparse.ArgumentParser();p.add_argument('--calibrate',action='store_true');args=p.parse_args()
    scorer=module('sp04_score',TESTS/'score.py');quality=module('sp04_quality',TESTS/'quality_score.py');answers={};cases={};runtime={}
    model=json.loads((DATA/'model.json').read_text());specs={c['id']:c for c in model['cases']}
    with tempfile.TemporaryDirectory(prefix='sp04-check-') as directory:
        temp=Path(directory)
        for name,script in (('baseline','baseline.py'),('reference','solve.py')):
            out=temp/f'{name}.json';start=time.perf_counter();subprocess.run([sys.executable,str(TASK/'solution'/script),'--data-root',str(DATA),'--output',str(out)],check=True,capture_output=True,text=True)
            runtime[f'{name}_seconds']=time.perf_counter()-start;answers[name]=json.loads(out.read_text())
        independent=json.loads((TESTS/'private/truth.json').read_text());independent['method']='independent direct high-precision Fermi integrals';answers['independent']=independent
        answers['equivalent']=deepcopy(answers['reference']);answers['equivalent']['cases'].reverse()
        for name in ('wrong','no_offset_energy','wrong_cv','wrong_response','no_upper_band','duplicate','boolean','nonfinite','missing','negative','overflow'):
            answers[name]=deepcopy(answers['reference'])
        for case in answers['wrong']['cases']:
            case.update(mu=100.,upper_fraction=1.,energy_per_particle=1e-5,entropy_per_particle=1e-5,heat_capacity_per_particle=1e-5,susceptibility=100.)
        for case in answers['no_offset_energy']['cases']:
            case['energy_per_particle']-=specs[case['id']]['delta']*case['upper_fraction']
        for case in answers['wrong_cv']['cases']:case['heat_capacity_per_particle']*=2
        for case in answers['wrong_response']['cases']:case['susceptibility']*=2
        for case in answers['no_upper_band']['cases']:case['upper_fraction']=0.
        answers['duplicate']['cases'][1]['id']=answers['duplicate']['cases'][0]['id'];answers['boolean']['cases'][0]['mu']=False
        answers['nonfinite']['cases'][0]['mu']=float('nan');answers['missing']['cases'][0].pop('mu')
        answers['negative']['cases'][0]['upper_fraction']=-1;answers['overflow']['cases'][0]['mu']=10**1000
        for name,answer in answers.items():
            raw,detail=scorer.evaluate(answer,DATA,TESTS/'private');cases[name]={'raw_metric':raw,**detail,'status':'invalid' if raw is None else 'completed'}
        measured={'kind':'continuous','metric_name':'二维费米子带阈值与有限温热力学响应误差','unit':'百分点','direction':'minimize','baseline':cases['baseline']['raw_metric'],'reference':cases['reference']['raw_metric'],'tolerance':1e-6}
        metric=measured if args.calibrate else json.loads((TESTS/'metric.json').read_text());quality.validate_metric(metric)
        for case in cases.values():case['score']=quality.quality_score(metric,case['raw_metric'],case['status'])
        testroot=temp/'tests';testroot.mkdir();(testroot/'metric.json').write_text(json.dumps(metric));entries={}
        for name in ('reference','empty'):
            logs=temp/f'logs-{name}';env=dict(os.environ,TASK_DATA_ROOT=str(DATA),TASK_PRIVATE_ROOT=str(TESTS/'private'),TASK_TESTS_ROOT=str(testroot),TASK_ANSWER_PATH=str(temp/f'{name}.json'),VERIFIER_LOG_ROOT=str(logs))
            subprocess.run(['bash',str(TESTS/'test.sh')],check=True,env=env,capture_output=True,text=True);entries[name]=json.loads((logs/'metrics.json').read_text())
        feedback=json.loads(subprocess.run([sys.executable,str(DATA/'feedback.py'),str(temp/'reference.json')],check=True,capture_output=True,text=True).stdout)
        public=temp/'public.json';subprocess.run([sys.executable,str(DATA/'start.py'),'--data-root',str(DATA),'--output',str(public)],check=True,capture_output=True,text=True)
        public_raw,_=scorer.evaluate(json.loads(public.read_text()),DATA,TESTS/'private')
    checks={'reference_improves_baseline':measured['baseline']-measured['reference']>metric['tolerance'],
            'reference_matches_independent_truth':measured['reference']<metric['tolerance'],
            'fixed_endpoints_match':all(abs(measured[k]-metric[k])<metric['tolerance'] for k in ('baseline','reference')),
            'baseline_zero_reference_one':cases['baseline']['score']==0 and cases['reference']['score']==1,
            'independent_full_credit':cases['independent']['score']==1,'equivalent_same':cases['reference']['raw_metric']==cases['equivalent']['raw_metric'],
            'wrong_answer_zero':cases['wrong']['score']==0,'subband_offset_energy_matters':cases['no_offset_energy']['raw_metric']>1,
            'upper_population_matters':cases['no_upper_band']['raw_metric']>1,'fixed_density_heat_capacity_matters':cases['wrong_cv']['raw_metric']>19,
            'susceptibility_matters':cases['wrong_response']['raw_metric']>14,
            'invalid_rejected':all(cases[n]['status']=='invalid' and cases[n]['score']==0 for n in ('duplicate','boolean','nonfinite','missing','negative','overflow')),
            'verifier_reference_one_empty_zero':entries['reference']['score']==1 and entries['empty']['status']=='invalid' and entries['empty']['score']==0,
            'public_start_matches_baseline':abs(public_raw-measured['baseline'])<metric['tolerance'],
            'feedback_density_constraint':feedback['valid'] and max(abs(c['fixed_density_relative_residual']) for c in feedback['cases'])<1e-10,
            'high_temperature_negative_mu':answers['reference']['cases'][-1]['mu']<0,
            'course_quality_unmodified':(TESTS/'quality_score.py').read_bytes()==(ROOT/'tools/course_quality_score.py').read_bytes()}
    report={'cases':cases,'metric':metric,'runtime':{'platform':platform.platform(),'python':platform.python_version(),**runtime},'verifier_entries':entries,'public_feedback':feedback,'checks':checks}
    print(json.dumps({'scores':{n:{k:v[k] for k in ('raw_metric','score','status')} for n,v in cases.items()},'runtime':report['runtime'],'checks':checks},ensure_ascii=False,indent=2))
    if not all(checks.values()):raise SystemExit('sp04 checks failed')
    if args.calibrate:
        for path in (DATA/'metric.json',TESTS/'metric.json'):path.write_text(json.dumps(metric,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    elif json.loads((DATA/'metric.json').read_text())!=metric:raise SystemExit('metric copies differ')
    (ROOT/'checks/sp-04-calibration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');out=ROOT/'checks/sp-04-development-answers';out.mkdir(parents=True,exist_ok=True)
    for name in ('baseline','reference','equivalent','wrong','wrong_cv','wrong_response','no_upper_band','no_offset_energy'):(out/f'{name}.json').write_text(json.dumps(answers[name],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':main()
"""Independent high-precision direct Fermi integrals for a two-subband gas."""
import json
from pathlib import Path
import time
import mpmath as mp

ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/sp-04'


def solve_mu(rho,delta,g,t):
    def density(mu):return t*(mp.log1p(mp.exp(mu/t))+g*mp.log1p(mp.exp((mu-delta)/t)))
    lo=-100*t-delta;hi=max(rho,delta)+100*t
    for _ in range(210):
        mid=(lo+hi)/2
        if density(mid)<rho:lo=mid
        else:hi=mid
    return (lo+hi)/2


def integrals(eta):
    lower=-eta
    # Integrate in x=(epsilon-mu)/kT.  This independently centers the
    # fluctuation moments rather than subtracting large raw energies.
    upper=max(mp.mpf(0),lower)+mp.mpf(155)
    points=sorted(set([lower,upper]+[v for v in (mp.mpf(-30),mp.mpf(0),mp.mpf(30)) if lower<v<upper]))
    def f(x):return 1/(mp.exp(x)+1)
    def w(x):return mp.exp(-abs(x))/(1+mp.exp(-abs(x)))**2
    def entropy(x):
        a=abs(x);return mp.log1p(mp.exp(-a))+a/(mp.exp(a)+1)
    return tuple(mp.quad(fn,points) for fn in (
        f,lambda x:(x+eta)*f(x),entropy,w,lambda x:x*w(x),lambda x:x*x*w(x)))


def exact_energy(rho,delta,g,t):
    mu=solve_mu(rho,delta,g,t)
    total=mp.mpf(0)
    for d,weight in ((mp.mpf(0),mp.mpf(1)),(delta,g)):
        eta=(mu-d)/t;l1=mp.log1p(mp.exp(eta));l2=-mp.polylog(2,-mp.exp(eta))
        total+=weight*(d*t*l1+t*t*l2)
    return mp.re(total)


def main():
    started=time.perf_counter();mp.mp.dps=65
    model=json.loads((TASK/'environment/public/model.json').read_text());truth={'cases':[]};checks=[]
    for case in model['cases']:
        rho,delta,g,t=(mp.mpf(str(case[k])) for k in ('rho','delta','g','t'))
        mu=solve_mu(rho,delta,g,t);number=energy=entropy=a=b=h=upper=mp.mpf(0)
        for d,weight in ((mp.mpf(0),mp.mpf(1)),(delta,g)):
            fn,fe,fs,fa,fb,fh=integrals((mu-d)/t)
            count=weight*t*fn;number+=count;energy+=weight*(d*t*fn+t*t*fe);entropy+=weight*t*fs
            a+=weight*fa;b+=weight*fb;h+=weight*fh
            if d:upper=count/rho
        cv=t/rho*(h-b*b/a)
        dt=t*mp.mpf('1e-10');difference=(exact_energy(rho,delta,g,t+dt)-exact_energy(rho,delta,g,t-dt))/(2*dt*rho)
        poly_energy=exact_energy(rho,delta,g,t)
        truth['cases'].append({'id':case['id'],'mu':float(mu),'upper_fraction':float(upper),'energy_per_particle':float(energy/rho),'entropy_per_particle':float(entropy/rho),'heat_capacity_per_particle':float(cv),'susceptibility':float(a/rho)})
        checks.append({'id':case['id'],'number_relative_residual':str(abs(number/rho-1)),
                       'direct_polylog_energy_relative_difference':str(abs(energy-poly_energy)/max(energy,1)),
                       'fixed_density_cv_difference':str(abs(cv-difference)),
                       'entropy_heat_capacity_response_positive':entropy>0 and cv>0 and a>0})
        print(case['id'],checks[-1],flush=True)
    (TASK/'tests/private').mkdir(parents=True,exist_ok=True);(TASK/'tests/private/truth.json').write_text(json.dumps(truth,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    ok=all(mp.mpf(c['number_relative_residual'])<mp.mpf('1e-50') and mp.mpf(c['direct_polylog_energy_relative_difference'])<mp.mpf('1e-50') and mp.mpf(c['fixed_density_cv_difference'])<mp.mpf('1e-15') and c['entropy_heat_capacity_response_positive'] for c in checks)
    report={'precision_digits':65,'method':'direct Fermi occupation, binary entropy and centered fluctuation integrals; polylog energy and fixed-density finite differences','checks':checks,'checks_passed':ok,'elapsed_seconds':time.perf_counter()-started}
    (ROOT/'checks/sp-04-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
    if not ok:raise SystemExit('sp04 independent truth failed')


if __name__=='__main__':main()
#!/bin/bash
set -euo pipefail
python3 "$(dirname -- "$0")/score.py"
cat: tasks/sp-04/tests/test_outputs.py: No such file or directory

exit_code=1
```
# sp-02 至 sp-05 实际制作任务

完成 ED04/05 后，继续制作统计物理 sp-02、sp-03、sp-04、sp-05。已有sp-01平均场铁磁分支不改。只写各新题 tasks/sp-0[2345]、tools/*sp0[2345]*、checks/sp-0[2345]*。以用户林宗涵《热力学与统计物理学》及习题解答PDF原页为依据，OCR在 planning/source-notes/sp-sol-all.txt；先定位核对关键原页，不能猜页码。建议独立方向：有限粒子数正则系综与粒子涨落；理想Bose气体凝聚/有限体积修正；Fermi气体低温展开失效与化学势；van der Waals Maxwell构造与共存/临界边界。可依据来源调整，不能将同题换参数凑四题，也不要重复sp01的多项式平均场。

交付参照已完成ed03的完整Harbor包：中文题面六栏、固定环境、全部公开输入和有用反馈、合理基线、带推导参考解、课程原版quality_score.py、独立真值、实际Linux校准、必要错误/等价答案检查、来源/公平性/验证及命令日志。4CPU4GiB0GPU agent1200/verifier120秒。每题完成校准即继续下一题，不只规划不索要权限，只本地Docker不碰远程、不推GitHub。主代理补Harbor。
schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/sp-04"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 1200.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "no-network"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2

COPY requirements.txt /tmp/requirements.txt
RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
 && useradd --uid 1000 --create-home student \
 && mkdir -p /app/data /app/output \
 && chown -R student:student /app

COPY public/ /app/data/
WORKDIR /app
USER student
numpy==2.1.3
scipy==1.14.1
mpmath==1.3.0

exit_code=0
```
888--（） 证明：3多-33
889-1ー
890-aTaS=1
891-avap
892-（ii） 根据雅可比行列式的性质，由上式得
893:其中z，为任意两个独立变量.由此导出麦克斯韦关系.
894-解
895-a(T,S)=
896-a(T,S)
897-a（T,V）
898-a(p,V)
--
900-a（p,V）
901-as
902-/01
903-=av
904-（1）
905:以上第一步用到题1.2（i），第二步用到题1.2（ii）.由麦克斯韦关系
906-（說），-｛歌）
907-(2)
908-（2）代人（1），得
909-a(T,S)
910-=
--
971-解 此处提供一种证法，读者可尝试不同的证法.
972-（i） 待证公式为
973-（說）=-7（），
974-由热力学基本微分方程
975-dU = TdS- pdV，
976:得麦克斯韦关系
977-(1)
978-(2)
979-
980-===== PDF PAGE 27 =====
981-第二章 均匀系的平衡性质
--
991-（邻），=-n（）；
992-（ii）由热力学基本微分方程（1）对V求偏微商，得
993-（3）。=7（35）一0
994-又由
995-dH = TdS+Vdp,
996:得麦克斯韦关系
997-（3）。一（3）
998-颠倒一下，得
999-（歌）。-（（蒙）.
1000-将（10）代入（7），即得
1001-21
--
1012-（11）
1013-（ii）注意到待证公式是以（U,V）为独立变量，故最好将热力学
1014-基本微分方程改写为
1015-ds-会d十系心，
1016-(12)
1017:相应的麦克斯韦关系为
1018-
1019-===== PDF PAGE 28 =====
1020-22
1021-《热力学与统计物理学》习题解答
1022-「a（=）1
--
1035-基本微分方程的另一形式
1036-dH=Tas+Vdp
1037-(16)
1038-改写为
1039-(17)
1040:相应的麦克斯韦关系为
1041-【3（=）
1042-ap
1043-嘿：
1044-即有
1045--氣G）。一卡（說），+（）
--
1056-（21）
1057-
1058-===== PDF PAGE 29 =====
1059-第二章 均匀系的平衡性质
1060-（3），一-告
1061:又由麦克斯韦关系
1062-（带）.=（器），
1063-上式右方可进一步变化为
1064-（飛）-（翡），器），
1065--z（当）
1066-第二步再次用到（16）式.（24）代入（23），得
--
1114-证明其内能与体积无关.
1115-解对任何 V-T系统，热力学基本微分方程为
1116-dU = TdS-pdV，
1117-于是有
1118--工（歌），一p
1119:以上第二个等式用到麦克斯韦关系
1120-（4）
1121-（5）
1122-（6）
1123-（7）
1124-（1）
--
1146-G-G-水）.9
1147-其中C。与C。分别代表体积为V。时的定容热容与压强为加。时的
1148-定压热容，它们都只是温度的函数.
1149-（it） 根据以上Cw，C，两式证明，理想气体的Cv与C，只是温度
1150-的函数.
1151:（ii）证明范德瓦耳斯气体的Cv只是温度的函数，与体积无关.
1152-解（i）由
1153-（1）
1154-对V求偏微商，得
1155-（2）
1156:以上第三个等式用到麦克斯韦关系
1157-
1158-===== PDF PAGE 32 =====
1159-26
1160-《热力学与统计物理学》习题解答
1161-（說），-（說）
--
1191-方程.这将使实验测量的工作量减少.
1192-类似地，由
1193-c-T（歌）.
1194-（8）
1195-得
1196:以上第三个等式用到麦克斯韦关系
1197-（說），--（（恶），
1198-选T- 空间的等压过程（ =p。）与等温过程积分路径，最后可得
1199-（9）
1200-（10）
1201-（11）
--
1213-由（2）与（9）式，得
1214-（邻），=0
1215-(15)
1216-(16)
1217-亦即理想气体的C与C，都只是温度的函数.
1218:（ii）范德瓦耳斯气体的物态方程为
1219-
1220-===== PDF PAGE 34 =====
1221-28
1222-《热力学与统计物理学》习题解答
1223-(p+N'a) (V-ND) = NRT.
--
1226-(17)
1227-(18)
1228-由公式（2），即得
1229-(응두), -0..
1230-（19）
1231:表明范德瓦耳斯气体的Cu 只是温度的函数，与体积无关.顺便指
1232:出，当V-∞时，范德瓦耳斯气体趋于理想气体.既然范德瓦耳斯气
1233-体的Cv 与V无关，因而任意体积时的Cv与V-∞时的Cv相同.也
1234:就是说，范德瓦耳斯气体的Cv与理想气体的定容热容（记为C&）相
1235-等，即
1236-Cu=Ci.
1237-2.6 由测量一气体的膨胀系数与等温压缩系数得
1238-(20)
1239-其中 为摩尔体积，a 常数，f（ ）是压强的函数.又已知在低压下
--
1429-（說），一工說），+x
1430-为 （3）， 对（1）作勒让德变換，将 基由（S,L）奕为（T， ），
1431-d（U- TS） =- SdT+ XdL，
1432-（2）
1433-(3)
1434:相应的麦克斯韦关系为
1435-（說），--（詳）：
1436-（4）
1437-由橡皮带的物态方程
1438-X = A（L）T，
1439-（5）
--
1572-===== PDF PAGE 43 =====
1573-第二章 均勻系的平衡性质
1574-37
1575-d(U-TS) =-SdT + MaHdM,
1576-(8)
1577:其麦克斯韦关系为
1578-（含），=-m（票）：
1579-(9)
1580-代入（6），得
1581-G-C=-mT（說））
1582-（10）
--
1634-dU = TdS +AO Yd.M.
1635-作勒让德变换，将变量 S变沩T，
1636-d（U - TS） =- SdT+ MoYd.M，
1637-(3)
1638-(4)
1639:相应的麦克斯韦关系
1640-（含2），一- （祭）：
1641-(5)
1642-将（5）代入（2），得
1643-O.d/r
1644---pT（祭），
--
1697-(19)
1698-现在来求（含家），将热力学基本微分方程（3）由变址（S，4）变换到
1699-（T,30，即有
1700-dU-TS-4o26） =-SdT- podde，
1701-(20)
1702:相应的麦克斯韦关系
1703-（），==（）
1704-(21)
1705-利用（7），即得
1706-（），--4
1707-T2
--
1992-
1993-===== PDF PAGE 54 =====
1994-48
1995-《热力学与统计物理学》习题解答
1996-（2）
1997:其中已用到麦克斯韦关系
1998-(ap), =-(ai);
1999-同理将8展开，有
2000-30-（評）， +（品）. P.
2001-将（2）与（4）代人（1），得
2002-(3)
--
2051-解
2052-（i）由粒子数可变系统的热力学基本微分方程
2053-dU = TdS-pdV+udN，
2054-作勒让德变换，将变量由S变换到T，又由定义F= TS，得
2055-d（U- TS）= dF =- SdT- pdV+udN，
2056:即得麦克斯韦关系
2057-（1）
2058-(2)
2059-（）.
2060-V.N
2061-=-（器）.0
2062-(3)
2063-（ii）由（2），作 让德变换，将变量V变換到 ，又由G= TS
2064-+ V=F+ V，得
2065-d（F+pV）= dG =- SdT +Vdp+pdN，
2066-(4)
2067:即得麦克斯韦关系
2068-（）x-（架）.：
2069-（ii）由（1），在保持T,V 不变下对N 求偏微商，得
2070-（5）
2071-(6)
2072-以上第二步用到公式（3）.（6）式可改为
--
2117-a-8平養”
2118-上式中ら対T的偏微商是在保持α相与β相平衡的条件下完成的.
2119-由于在保持a-3两相平衡时， =P（T），故有s=S（T,p（T））.于是
2120-（1）可进一步写成
2121-s-T（），+說），將
2122:利用对a相的麦克斯韦关系
2123-（g），一（器）：
2124-(2)
2125-(3)
2126-及克拉珀龙方程
2127-LaB
--
2256-为另一相物质的增加），亦即系统的S与V可以改变.
2257-从（1）—（3）式可以看出，分子发生有限大小的改变，而分母不
2258-变.因而 Cp，a，KT 均趋于无穷大.
2259-以上是对一级相变而言的（对二级相变，在相变点S与V是连
2260-续的，上述诸量在相变点的行为将不同，详见原书e3.10）.
2261:3.8 证明范德瓦耳斯气体在 T<T。的p-~等温线上的极小点
2262-M与极大点N的轨迹为
2263-加 = a（w-26）.
2264:解 由范德瓦耳斯方程
2265-（ +品）（-b=RT，
2266-（1）
2267-或
2268-RT
2269-中=元
--
2283-(5)
2284-（6）
2285-经简单运算，得
2286-ps = a（w-26）.
2287-（7）
2288:*3.9从范德瓦耳斯对比物态方程（3.10.14）出发，在临界点的
2289-邻域引人无量纲变量
2290-=个-1=（T-T.）/T.，
2291-
2292-===== PDF PAGE 62 =====
2293-56
2294-《热力学与统计物理学》习题解答
2295-利用在临界点的邻域 ，和 都是小量，试由（3.10.14）导出
2296-（3.10.18）式，即由（万十号）（38-1）=8 导出
2297-二 6一多 。
2298-解 详细推导可参看原书§3.10，此处只列出要点.
2299:（a）由范德瓦耳斯方程出发，采用无量纲变量
2300-三 /P，a=w/ve，
2301-个= T/Te，
2302-（1）
2303-得到它的对比物态方程的普适形式
2304-（万+≥）（38-1）=8，
--
2315-（4）
2316-在临界点的邻域，T，$， 均为小量.
2317-（c）将（4）代入（3），在临界点的邻域作级数展开，略去O（c”），
2318-O（ ）以及更高阶的小量，最后可得
2319-（5）
2320:*3.10 由（3.10.18）式出发，证明范德瓦耳斯气体的临界指数
2321-B=，8 3,Y=1.
2322-解 详细计算可参看原书§3.10，此处只列出要点.
2323-（a）计算的出发点是方程
2324-（1）
2325-方程（1）是对比物态方程在临界点邻域的表达形式，它概括了临
--
3009-的幂律行为，其中a是V或p的函数，与T无关.于是有
3010-Cv=T
3011-aT） aT，
3012-(2)
3013-(3)
3014:又由麦克斯韦关系，并利用（1），得
3015-（詳），一-（3），一-部™
3016-（4）
3017-（），-（含），-部
3018-（5）
3019-由（2） （4）可见，当7 0时，C、C （） （歌）、均以与S相同
--
3665-（vi）
3666-C(T)
3667-dT
3668-0
3669-解（i）令e】=一e,2=0,es =e；这三个能级均为非简并的，即
3670:81=82=8=1.根据麦克斯韦-玻尔兹曼分布
3671-ax= ea Ba
3672--e тe,,
3673-（1）
3674-2=
3675-（2）
--
3753-aT，得
3754-.。CT票-$68）- $（0） - NEIn8-0-Naln3.
3755-（18）
3756-7.5 计算爱因斯坦固体模型的熵.
3757-解固体原子振动的爱因斯坦模型是典型的近独立定域子系
3758:（每一个振动自由度当作一个子系）组成的系统，按照麦克斯韦-玻
3759-尔兹曼分布，子系的配分函数
3760-e-Phv/2
3761-（1）
3762-1 - eshu•
3763-令N 代表总原子数，总振动自由度数 3N，应用原书公式（7.4.15）
--
4063-(8)
4064-由于n《N，故得
4065-n～ Ne-WAT
4066-.
4067-（9）
4068:7.10 试根据麦克斯韦速度分布律求两个分子的相对速度 ，=
4069-ひ2z一ひ」和相対速率ひ、＝｜1的分布、并求相対速率的平均値で，
4070:解 由麦克斯韦速度分布，一个分子速度处于速度间隔d =
4071-deraduydess内的几率
4072-(1)
4073-同样，另一个分子速度处于dw：内的几率为
4074-（2）
4075-令P2（ひ」っひ2）ひ、ぷひを代表一个分子的速度処手ぷひ、内同財男一↑
--
4187-分子的平均速率.
4188-7.11 设容器内的理想气体处于平衡态，并满足经典极限条件，
4189-试证明单位时间内碰到器壁单位面积上的平均分子数为
4190-立m，
4191-其中n为气体分子的数密度， 平均速率.
4192:解由麦克斯韦分布，单位体积内速度处于d d xdwyd ：内
4193-的平均分子数为
4194-S(0)d'o=M(2T)' e a du, du, du,.
4195-(1)
4196-此时间内碰到器壁dA 面积上、速度处
4197-于d 内的分子必定处于如图所示的
--
4391-由此求得与（i）相同的结果.
4392-（vi）当 ≤1时（即弱场、高温），证明
4393-9=x6.x=3，
4394-X为极化率.
4395-解（i）由于分子的转动能与平动自由度无关，而分子质心平
4396:动的速度分布只涉及平动自由度，故麦克斯韦速度分布的形式不变，
4397-即单位体积内、质心的平动速度处于d=dwadvydw。内的平均分子
4398-数为
4399-
4400-===== PDF PAGE 115 =====
4401-第七章 近独立子系组成的系统
--
4415-（3）
4416-（ii）设双原子分子的振动可以不考虑（相当于振动自由度冻结，
4417-这对许多双原子分子是很好的近似.不过，即使在需要考虑振动自由
4418-度的情况下，由于振动与转动及平动自由度相互独立，并不影响以下
4419-的计算结果），则在满足经典极限的条件下，双原子分子理想气体的
4420:麦克斯韦-玻尔兹曼分布可以表为
4421-eTa-Rda= er-Betedur'dwr，
4422-其中 ， 与dw’，dw' 分别代表分子平动与转动的能量和子相体元.
4423-e'=
4424-Gcos8，
4425-（4）
--
5109-子化的：
5110-En （2）=nhy, n =0,1,2，.
5111-(W1)
5112-一个频率为v、处于第n个激发
5113-态的谐振子
5114:谐振子按能量的分布遵从麦克斯
5115-韦-玻尔兹曼统计.
5116-对于频率为v的谐振子，其能量处
5117-チ en（>）＝nhy的几率労
5118-(W2)
5119-ZeA①
--
5883-c-（），=3NR，
5884-(13)
5885-C-（器），=ANR（H=E+AV =ANAT）.
5886-（14）
5887-8.4 对实际气体，分子之间的相互作用必须考虑.设气体满足
5888:经典极限条件.试问气体分子质心的速度分布是否仍然遵从麦克斯
5889-韦速度分布（用计算加以论证）？
5890-解为简单起见，设气体分子可看成质点（即忽略内部自由度；
5891-这一假设并不必要，放弃这一假设不影响结果），并设分子之间为两
5892-两相互作用，则气体的微观总能量可表为
5893-E=
--
5918-对任何一个分子均有相同的结果，故可省去（4）式中动量的下标，并
5919-用速度代替动量变量，最后得
5920-P（a）d0-（327）"ewrdo.
5921-（7）
5922-上述计算结果表明，即使对相互作用不能忽略的情形（如稠密气体或
5923:液体），只要满足经典极限条件，麦克斯韦速度分布仍然成立.尽管麦
5924:克斯韦分布在原书§7.12中是由相互作用可以忽略的麦克斯韦-玻
5925:尔兹曼分布导出的，但本题的证明告诉我们，麦克斯韦分布适用的条
5926-件更宽.
5927-8.5 一实际气体处于平衡态.设气体满足经典极限条件，分子
5928-之间的相互作用为带吸引力的刚球势（公式（8.6.21））.
5929-（i）计算正则系综的配分函数到最低阶修正（相对于理想气体
5930-而言）.
5931:（ii）证明在此近似下的物态方程为范德瓦耳斯方程，并定出参
5932-数a与6.
5933-（ii）计算内能E 和熵S，讨论a，6对E和S的影响.
5934-（i）系统微观总能量的经典形式为
5935-E=K+$=ZP/m+Zo（rs），
5936-（1）
--
6002-(14)
6003-(15)
6004-亦即
6005-（カ＋賞）（V-No）＝N&T.
6006-(16)
6007:上式正是范德瓦耳斯方程.
6008-（ii）将（11）式代入用正则系综计算内能的普遍公式
6009-Eニ-3n2zx・
6010-(17)
6011-注意到B=N6-NaB,B 的第二项与8有关，于是得
6012-B-品当+罪-wwT-始
--
6664-费米子，泡利不相容原理的排斥作用对涨落起抑制作用；而玻色子之
6665-间的有效吸引使涨落加强.
6666-
6667-===== PDF PAGE 171 =====
6668-第九章 相变和临界现象的统计理论简介
6669:*9.1 范德瓦耳斯方程的另一种推导方法是作平均场近似.设
6670-气体的哈密顿量沩
6671-H-名点+买8）。
6672-今假设第i个分子所受其他分子的相互作用可以用平均场中mt （r）来
6673-近似表达，即H近似用下列平均场哈密顿量代替：
6674-Hmt =
--
6694-
6695-===== PDF PAGE 172 =====
6696-166
6697-《热力学与统计物理学》习题解答
6698-注：在§3.10中我们曾经看到，范德耳斯方程所相应的临界
6699:指数与平均场理论的结果相同.这里以更直接的方式说明了范德瓦
6700-耳斯方程是一个平均场理论.
6701-解（i）在平均场近似下，气体的哈密顿量可近似表为
6702-H-名 +8c（n）。
6703-（1）
6704-从形式上看公式（1）与处于外场中的理想气体的哈密顿量相似.这里
--
6757-
6758-===== PDF PAGE 174 =====
6759-168
6760-《热力学与统计物理学》习题解答
6761-(12)
6762:这样就证明了范德瓦耳斯方程是平均场近似的结果.
6763-*9.2 伊辛模型的哈密顿量为
6764-在平均场近似下（即公式（9.1.10）与（9.1.11）），证明正则系综的配
6765-分函数为公式（9.1.14）
6766-20-［200h（（+当）.
6767-以及确定 的自治方程为公式（9.1.17）
--
7225-将（1）式 d2与d 积分，得
7226-@2= d@n2=|fododig:cosodn
7227-cosdsingde
7228-=тediz/ f2812d'tr.
7229-(i)On=Jorafido/Jrida==ferafid'o
7230:当气体处于平衡态时，fi，f，均为麦克斯韦分布，即
7231-3/2
7232-e-mtrekT，
7233-e m⅓/a8T ，
7234-(2)
7235-(3)
--
7533-(3)
7534-(4)
7535-或
7536-(5)
7537-由于题中所考虑的半导体传导电子数密度低，满足非简并条件，故
7538:f0为麦克斯韦分布，即
7539-e-m/2kT
7540-(6)
7541-得
7542-af0）
7543-=n

exit_code=0
```

### 2026-11-16T18:25:34.203533+08:00

```bash
mkdir -p checks/sp-05-source-pages
```

```text

exit_code=0
```

### 2026-11-16T18:25:34.265217+08:00

```bash
cat tasks/sp-04/tests/score.py tasks/sp-04/instruction.md tasks/sp-04/environment/public/feedback.py tasks/sp-04/README.md tools/course_quality_score.py
```

```text

### 2026-11-16T18:25:34.265370+08:00

```bash
/Users/ai4s/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/pdftoppm -f 61 -l 62 -scale-to 1800 -png '/Users/ai4s/Downloads/热力学与统计物理学 习题解答 by 林宗涵.pdf' checks/sp-05-source-pages/solutions
```

```text
import json
import os
from pathlib import Path
import sys
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get('TASK_DATA_ROOT','/app/data'));private=Path(private_root or os.environ.get('TASK_PRIVATE_ROOT','/tests/private'));sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    model=load_model(data);mapped,reason=validate_answer(answer,model)
    if reason:return None,{'reason':reason}
    truth=json.loads((private/'truth.json').read_text());cfg=model['scoring'];rows=[]
    for expected in truth['cases']:
        actual=mapped[expected['id']];errors={'mu':min(1.,abs(actual['mu']-expected['mu'])/max(1.,abs(expected['mu']))),'upper':abs(actual['upper_fraction']-expected['upper_fraction'])}
        for short,key in (('energy','energy_per_particle'),('entropy','entropy_per_particle'),('heat_capacity','heat_capacity_per_particle'),('susceptibility','susceptibility')):errors[short]=min(1.,abs(actual[key]-expected[key])/expected[key])
        raw=100*sum(cfg[k+'_weight']*v for k,v in errors.items());rows.append({'id':expected['id'],'errors':errors,'raw_metric':raw})
    return sum(r['raw_metric'] for r in rows)/len(rows),{'cases':rows}


def main():
    logs=Path(os.environ.get('VERIFIER_LOG_ROOT','/logs/verifier'));logs.mkdir(parents=True,exist_ok=True);tests=Path(os.environ.get('TASK_TESTS_ROOT','/tests'));out=Path(os.environ.get('TASK_ANSWER_PATH','/app/output/answer.json'));metric=json.loads((tests/'metric.json').read_text())
    try:answer=json.loads(out.read_text())
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{'reason':'没有有效JSON产物'}
    else:raw,details=evaluate(answer)
    status='invalid' if raw is None else 'completed';details.update(raw_metric=raw,score=quality_score(metric,raw,status),status=status)
    (logs/'metrics.json').write_text(json.dumps(details,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(logs/'reward.txt').write_text(f"{details['score']}\n")


if __name__=='__main__':main()
# sp-04：二维费米气体子带阈值与低温展开的适用边界

## 1. 科学问题

林宗涵习题7.25研究二维自由电子气，利用常数态密度和强简并展开得到近似不随温度变化的化学势。本题研究具有两条抛物色散子带的二维理想费米气体：温度能激活位于化学势附近的第二子带，低温展开在阈值附近会失准。求固定面密度下的化学势、带占据和热力学响应，覆盖深简并、阈值热激发及经典区。

## 2. 模型与单位

能量单位为 \(E_0\)，第一子带底为0，第二子带底为 \(\Delta=\delta E_0\)。单位面积态密度分别为 \(D_0\) 和 \(gD_0\)，已包含自旋简并。面密度 \(n=D_0E_0\rho\)，本题 \(\rho=1\)。令 \(t=k_BT/E_0\)、\(m=\mu/E_0\)，公开工况给定 \(\delta,g,t\)。没有子带间相互作用，热平衡共用一个化学势。

使用完整Fermi分布，而不是将热激活子带丢弃。令 \(d_j\in\{0,\delta\}\)、\(w_j\in\{1,g\}\)、\(\eta_j=(m-d_j)/t\)，有
\[
\rho=\sum_jw_jt\ln(1+e^{\eta_j}),\qquad
u\equiv\frac{U}{AD_0E_0^2}=\sum_jw_j[d_jt\ln(1+e^{\eta_j})-t^2\operatorname{Li}_2(-e^{\eta_j})].
\]
第二子带的内能必须包含带底偏移 \(d_j\)；不能只加平面内动能。熵、热容和响应也可以从连续Fermi积分直接求出。热容沿固定面密度求导。

## 3. 输出

写 `/app/output/answer.json`，恰好覆盖八个不同工况：

```json
{"cases":[{"id":"fermi-01","mu":1.0,"upper_fraction":0.0,"energy_per_particle":0.5,"entropy_per_particle":0.1,"heat_capacity_per_particle":0.1,"susceptibility":1.0}],"method":"说明密度约束、子带阈值和稳定热力学响应计算"}
```

`mu`为 \(m\)，`upper_fraction` 为上子带粒子占总数的比例，能量为 \(U/(NE_0)\)，熵和热容分别为 \(S/(Nk_B)\)、\(C_n/(Nk_B)\)。`susceptibility`为 \(\chi=(E_0/n)(\partial n/\partial\mu)_T\)，它与等温压缩率满足 \(\chi=nE_0\kappa_T\)。所有数值有限，化学势可正可负，其余正且占据比例在[0,1]。

## 4. 起点与反馈

```bash
python /app/data/start.py --data-root /app/data --output /app/output/answer.json
python /app/data/feedback.py /app/output/answer.json
```

公开起点是分段零温填充加Sommerfeld近似：在零温已占据的子带上保留 \(T^2\) 能量与线性T熵/热容，忽略带边附近热平滑。它在化学势远离各带底、温度充分小时合理。反馈用精确有限温粒子数方程检验所交化学势，不直接给热容和上子带响应标签。

## 5. 评分

八工况等权。每工况误差加权和乘100：化学势20%、上子带比例15%、能量15%、熵15%、热容20%、响应15%。化学势误差为 \(\min(1,|m-m_*|/\max(1,|m_*|))\)，比例用绝对误差，其余为截顶相对误差。固定基线和参考端点见 `metric.json`；课程原版质量分为 \(\operatorname{clip}((b-E)/(b-h),0,1)\)，非法产物0分。

## 6. 环境

4CPU、4GiB、0GPU；Agent1200秒、verifier120秒。已安装numpy、scipy、mpmath，无需权重或联网。独立真值和完整参考程序不复制到公开环境。
import argparse
import json
from pathlib import Path
from physics import density,load_model,validate_answer


def main():
    p=argparse.ArgumentParser();p.add_argument('answer',type=Path);a=p.parse_args()
    try:answer=json.loads(a.answer.read_text(encoding='utf-8'))
    except (OSError,UnicodeError,json.JSONDecodeError):print(json.dumps({'valid':False,'reason':'没有有效JSON'},ensure_ascii=False));return
    model=load_model(Path(__file__).parent);mapped,reason=validate_answer(answer,model)
    if reason:print(json.dumps({'valid':False,'reason':reason},ensure_ascii=False));return
    print(json.dumps({'valid':True,'cases':[{'id':c['id'],'fixed_density_relative_residual':density(c,mapped[c['id']]['mu'])/c['rho']-1} for c in model['cases']],'note':'粒子数方程残差不直接给出上子带热容和响应的私有标签'},ensure_ascii=False,indent=2))


if __name__=='__main__':main()
cat: tasks/sp-04/README.md: No such file or directory
"""课程统一质量分：简单基线0、专家参考1，逐次换算后取平均。"""
import math

VALID_FAILURES = {"invalid", "agent_error", "timeout"}


def finite_number(value, name):
    if type(value) not in (int, float):
        raise ValueError(f"{name}须为有限数值")
    try:
        result = float(value)
    except OverflowError as exc:
        raise ValueError(f"{name}须为有限数值") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name}须为有限数值")
    return result


def validate_metric(metric):
    if metric.get("kind") == "binary":
        baseline = finite_number(metric.get("baseline"), "baseline")
        reference = finite_number(metric.get("reference"), "reference")
        if baseline != 0 or reference != 1:
            raise ValueError("二元题须实测简单基线0、参考解1，否则不构成有效的参考提升")
        return
    if metric.get("kind") != "continuous":
        raise ValueError("kind须为binary或continuous")
    direction = metric.get("direction")
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction须为maximize或minimize")
    baseline = finite_number(metric.get("baseline"), "baseline")
    reference = finite_number(metric.get("reference"), "reference")
    tolerance = finite_number(metric.get("tolerance"), "tolerance")
    if tolerance < 0:
        raise ValueError("原始指标容差不能为负")
    improvement = reference - baseline if direction == "maximize" else baseline - reference
    if not math.isfinite(improvement) or improvement <= tolerance:
        raise ValueError("参考解相对基线的改善须超过原始指标容差；请先核查设置")


def quality_score(metric, raw_metric, status="completed"):
    validate_metric(metric)
    if status in VALID_FAILURES:
        return 0.0
    if status != "completed":
        raise ValueError("基础设施或评分器故障不能填0；请先处理并补跑")
    value = finite_number(raw_metric, "raw_metric")
    if metric["kind"] == "binary":
        if value not in {0.0, 1.0}:
            raise ValueError("二元任务的实测结果须为0或1")
        return value
    baseline = float(metric["baseline"])
    reference = float(metric["reference"])
    fraction = (value - baseline) / (reference - baseline)
    return max(0.0, min(1.0, fraction))

exit_code=1
```

exit_code=0
```

### 2026-11-16T18:27:22.087873+08:00

```bash
rg --files tasks/sp-04
```

```text
tasks/sp-04/task.toml
tasks/sp-04/environment/public/metric.json
tasks/sp-04/environment/public/physics.py
tasks/sp-04/environment/public/start.py
tasks/sp-04/environment/public/feedback.py
tasks/sp-04/environment/public/model.json
tasks/sp-04/environment/Dockerfile
tasks/sp-04/environment/requirements.txt
tasks/sp-04/instruction.md
tasks/sp-04/solution/solve.py
tasks/sp-04/solution/solver_core.py
tasks/sp-04/solution/README.md
tasks/sp-04/solution/solve.sh
tasks/sp-04/solution/baseline.py
tasks/sp-04/tests/score.py
tasks/sp-04/tests/test.sh
tasks/sp-04/tests/metric.json
tasks/sp-04/tests/private/truth.json
tasks/sp-04/tests/quality_score.py

exit_code=0
```

### 2026-11-16T18:31:49.715235+08:00

```bash
cp tools/course_quality_score.py tasks/sp-05/tests/quality_score.py
```

```text

exit_code=0
```

### 2026-11-16T18:31:49.779136+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-sp04:dev python tools/build_sp05_truth.py
```

```text
vdw-01 {"id": "vdw-01", "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76", "equal_pressure_residual": "1.65814436257813336807417955765767671765427206997176602592455106627236962621e-75", "direct_quadrature_equal_area_residual": "3.34398831730773636332494991754577150003249266438207598553534536090020144808e-76", "common_tangent_residual": "1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75", "latent_enthalpy_difference": "0.0", "clapeyron_finite_difference_relative_error": "7.40712864691118763498287284098906065716291655134479839026237879572956406875e-25", "convex_envelope_gap_min": "0.0", "physical_branch_order": true, "critical_density_amplitude_ratio": "0.946437521016043547568268528015847529174873421871765924429085650037407973856"}
vdw-02 {"id": "vdw-02", "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76", "equal_pressure_residual": "4.42171830020835564819781215375380458041139218659137606913213617672631900322e-75", "direct_quadrature_equal_area_residual": "2.72911775198383049282640156448836911219470208065021817332773876179666701129e-76", "common_tangent_residual": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76", "latent_enthalpy_difference": "1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75", "clapeyron_finite_difference_relative_error": "5.41004559967094806277974076080504023454558363359308579522099568895433053705e-25", "convex_envelope_gap_min": "-1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75", "physical_branch_order": true, "critical_density_amplitude_ratio": "0.960119260694783095361787099484671124692721722183380972128114661996281747237"}
vdw-03 {"id": "vdw-03", "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76", "equal_pressure_residual": "4.14536090644533342018544889414419179413568017492941506481137766568092406552e-75", "direct_quadrature_equal_area_residual": "7.73744132113967806269133720175877869343433979027904143089562530830922811657e-76", "common_tangent_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-75", "latent_enthalpy_difference": "2.21085915010417782409890607687690229020569609329568803456606808836315950161e-75", "clapeyron_finite_difference_relative_error": "4.02399736114133155218904982822001713572156936234920753610502677076895094137e-25", "convex_envelope_gap_min": "-1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75", "physical_branch_order": true, "critical_density_amplitude_ratio": "0.973608824571631513525562454193523307226053092070337141328001038846036180369"}
vdw-04 {"id": "vdw-04", "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76", "equal_pressure_residual": "2.48721654386720005211126933648651507648140810495764903888682659940855443931e-75", "direct_quadrature_equal_area_residual": "5.49798121684183833010573538505891301310218479595991329026008408110283349128e-76", "common_tangent_residual": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76", "latent_enthalpy_difference": "5.52714787526044456024726519219225572551424023323922008641517022090789875402e-76", "clapeyron_finite_difference_relative_error": "3.04135460257617827594392790958446713632395250342537884575904192359307821069e-25", "convex_envelope_gap_min": "0.0", "physical_branch_order": true, "critical_density_amplitude_ratio": "0.986902484425151448243518808393464971367021229001450856176648155596878900446"}
vdw-05 {"id": "vdw-05", "temperature_residual": "4.14536090644533342018544889414419179413568017492941506481137766568092406552e-76", "equal_pressure_residual": "1.24360827193360002605563466824325753824070405247882451944341329970427721966e-75", "direct_quadrature_equal_area_residual": "6.35306507938148860940340782937793676778768003095607958166352971813144305323e-77", "common_tangent_residual": "5.52714787526044456024726519219225572551424023323922008641517022090789875402e-76", "latent_enthalpy_difference": "0.0", "clapeyron_finite_difference_relative_error": "2.58886260876394260095585864579741053341029578825334903021409127193211497184e-25", "convex_envelope_gap_min": "0.0", "physical_branch_order": true, "critical_density_amplitude_ratio": "0.994784437367034068290893385517582376649282022058300865396725119421361930914"}
vdw-06 {"id": "vdw-06", "temperature_residual": "0.0", "equal_pressure_residual": "0.0", "direct_quadrature_equal_area_residual": "1.81850483715343839080057034217717710214673632753809006719076844081726557528e-76", "common_tangent_residual": "7.59982832848311127033998963926435162258208032070392761882085905374836078678e-76", "latent_enthalpy_difference": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76", "clapeyron_finite_difference_relative_error": "2.39282243762626574918724422853708433932142916556153042264293504848563475429e-25", "convex_envelope_gap_min": "0.0", "physical_branch_order": true, "critical_density_amplitude_ratio": "0.998699028778025354840971482313030428797395361548655234979294941760827686717"}
vdw-07 {"id": "vdw-07", "temperature_residual": "2.76357393763022228012363259609612786275712011661961004320758511045394937701e-76", "equal_pressure_residual": "1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75", "direct_quadrature_equal_area_residual": "2.02392294663087773304625103569252992172223679804612641081196291374695585566e-78", "common_tangent_residual": "4.40444596309816675894703945002820378126916018586250350636208876978598181961e-76", "latent_enthalpy_difference": "3.45446742203777785015454074512015982844640014577451255400948138806743672126e-76", "clapeyron_finite_difference_relative_error": "2.33263799496429321307575085595335937860236566909122611066347420617640600654e-25", "convex_envelope_gap_min": "0.0", "physical_branch_order": true, "critical_density_amplitude_ratio": "0.999973999611710173355545841286592212614563403925963364962314768498274821526"}
vdw-08 {"id": "vdw-08", "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76", "equal_pressure_residual": "1.51996566569662225406799792785287032451641606414078552376417181074967215736e-75", "direct_quadrature_equal_area_residual": "5.44796739895099496413687133475761369777013820672914011514675655319221275204e-80", "common_tangent_residual": "8.69959041792091945310403288429284000546638349211261032644497129252764239922e-76", "latent_enthalpy_difference": "6.73081386762673277991048798307006141573853278403252680445284889206264623659e-76", "clapeyron_finite_difference_relative_error": "2.3314286923337180058949759091873158817457530818939097929700905859583634157e-27", "convex_envelope_gap_min": "0.0", "physical_branch_order": true, "critical_density_amplitude_ratio": "0.999999997399999996117142853029469490639357941886303969804235330216247801684"}
{
  "precision_digits": 75,
  "method": "hyperbolic free-volume-ratio parameterization; trigonometric spinodals; direct quadrature, common tangents, enthalpy and coexistence-pressure finite differences",
  "checks": [
    {
      "id": "vdw-01",
      "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "equal_pressure_residual": "1.65814436257813336807417955765767671765427206997176602592455106627236962621e-75",
      "direct_quadrature_equal_area_residual": "3.34398831730773636332494991754577150003249266438207598553534536090020144808e-76",
      "common_tangent_residual": "1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75",
      "latent_enthalpy_difference": "0.0",
      "clapeyron_finite_difference_relative_error": "7.40712864691118763498287284098906065716291655134479839026237879572956406875e-25",
      "convex_envelope_gap_min": "0.0",
      "physical_branch_order": true,
      "critical_density_amplitude_ratio": "0.946437521016043547568268528015847529174873421871765924429085650037407973856"
    },
    {
      "id": "vdw-02",
      "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "equal_pressure_residual": "4.42171830020835564819781215375380458041139218659137606913213617672631900322e-75",
      "direct_quadrature_equal_area_residual": "2.72911775198383049282640156448836911219470208065021817332773876179666701129e-76",
      "common_tangent_residual": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76",
      "latent_enthalpy_difference": "1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75",
      "clapeyron_finite_difference_relative_error": "5.41004559967094806277974076080504023454558363359308579522099568895433053705e-25",
      "convex_envelope_gap_min": "-1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75",
      "physical_branch_order": true,
      "critical_density_amplitude_ratio": "0.960119260694783095361787099484671124692721722183380972128114661996281747237"
    },
    {
      "id": "vdw-03",
      "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "equal_pressure_residual": "4.14536090644533342018544889414419179413568017492941506481137766568092406552e-75",
      "direct_quadrature_equal_area_residual": "7.73744132113967806269133720175877869343433979027904143089562530830922811657e-76",
      "common_tangent_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-75",
      "latent_enthalpy_difference": "2.21085915010417782409890607687690229020569609329568803456606808836315950161e-75",
      "clapeyron_finite_difference_relative_error": "4.02399736114133155218904982822001713572156936234920753610502677076895094137e-25",
      "convex_envelope_gap_min": "-1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75",
      "physical_branch_order": true,
      "critical_density_amplitude_ratio": "0.973608824571631513525562454193523307226053092070337141328001038846036180369"
    },
    {
      "id": "vdw-04",
      "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "equal_pressure_residual": "2.48721654386720005211126933648651507648140810495764903888682659940855443931e-75",
      "direct_quadrature_equal_area_residual": "5.49798121684183833010573538505891301310218479595991329026008408110283349128e-76",
      "common_tangent_residual": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76",
      "latent_enthalpy_difference": "5.52714787526044456024726519219225572551424023323922008641517022090789875402e-76",
      "clapeyron_finite_difference_relative_error": "3.04135460257617827594392790958446713632395250342537884575904192359307821069e-25",
      "convex_envelope_gap_min": "0.0",
      "physical_branch_order": true,
      "critical_density_amplitude_ratio": "0.986902484425151448243518808393464971367021229001450856176648155596878900446"
    },
    {
      "id": "vdw-05",
      "temperature_residual": "4.14536090644533342018544889414419179413568017492941506481137766568092406552e-76",
      "equal_pressure_residual": "1.24360827193360002605563466824325753824070405247882451944341329970427721966e-75",
      "direct_quadrature_equal_area_residual": "6.35306507938148860940340782937793676778768003095607958166352971813144305323e-77",
      "common_tangent_residual": "5.52714787526044456024726519219225572551424023323922008641517022090789875402e-76",
      "latent_enthalpy_difference": "0.0",
      "clapeyron_finite_difference_relative_error": "2.58886260876394260095585864579741053341029578825334903021409127193211497184e-25",
      "convex_envelope_gap_min": "0.0",
      "physical_branch_order": true,
      "critical_density_amplitude_ratio": "0.994784437367034068290893385517582376649282022058300865396725119421361930914"
    },
    {
      "id": "vdw-06",
      "temperature_residual": "0.0",
      "equal_pressure_residual": "0.0",
      "direct_quadrature_equal_area_residual": "1.81850483715343839080057034217717710214673632753809006719076844081726557528e-76",
      "common_tangent_residual": "7.59982832848311127033998963926435162258208032070392761882085905374836078678e-76",
      "latent_enthalpy_difference": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76",
      "clapeyron_finite_difference_relative_error": "2.39282243762626574918724422853708433932142916556153042264293504848563475429e-25",
      "convex_envelope_gap_min": "0.0",
      "physical_branch_order": true,
      "critical_density_amplitude_ratio": "0.998699028778025354840971482313030428797395361548655234979294941760827686717"
    },
    {
      "id": "vdw-07",
      "temperature_residual": "2.76357393763022228012363259609612786275712011661961004320758511045394937701e-76",
      "equal_pressure_residual": "1.1054295750520889120494530384384511451028480466478440172830340441815797508e-75",
      "direct_quadrature_equal_area_residual": "2.02392294663087773304625103569252992172223679804612641081196291374695585566e-78",
      "common_tangent_residual": "4.40444596309816675894703945002820378126916018586250350636208876978598181961e-76",
      "latent_enthalpy_difference": "3.45446742203777785015454074512015982844640014577451255400948138806743672126e-76",
      "clapeyron_finite_difference_relative_error": "2.33263799496429321307575085595335937860236566909122611066347420617640600654e-25",
      "convex_envelope_gap_min": "0.0",
      "physical_branch_order": true,
      "critical_density_amplitude_ratio": "0.999973999611710173355545841286592212614563403925963364962314768498274821526"
    },
    {
      "id": "vdw-08",
      "temperature_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "equal_pressure_residual": "1.51996566569662225406799792785287032451641606414078552376417181074967215736e-75",
      "direct_quadrature_equal_area_residual": "5.44796739895099496413687133475761369777013820672914011514675655319221275204e-80",
      "common_tangent_residual": "8.69959041792091945310403288429284000546638349211261032644497129252764239922e-76",
      "latent_enthalpy_difference": "6.73081386762673277991048798307006141573853278403252680445284889206264623659e-76",
      "clapeyron_finite_difference_relative_error": "2.3314286923337180058949759091873158817457530818939097929700905859583634157e-27",
      "convex_envelope_gap_min": "0.0",
      "physical_branch_order": true,
      "critical_density_amplitude_ratio": "0.999999997399999996117142853029469490639357941886303969804235330216247801684"
    }
  ],
  "checks_passed": true,
  "elapsed_seconds": 0.2746570839999998
}

exit_code=0
```

### 2026-11-16T18:32:16.884475+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-sp04:dev python tools/run_sp05_checks.py --calibrate
```

```text
{
  "scores": {
    "baseline": {
      "raw_metric": 4.913423935918016,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    },
    "independent": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    },
    "wrong": {
      "raw_metric": 89.01265557901907,
      "score": 0.0,
      "status": "completed"
    },
    "spinodal_as_binodal": {
      "raw_metric": 16.745050384581123,
      "score": 0.0,
      "status": "completed"
    },
    "collapsed_gap": {
      "raw_metric": 14.999999995249638,
      "score": 0.0,
      "status": "completed"
    },
    "wrong_clapeyron": {
      "raw_metric": 10.0,
      "score": 0.0,
      "status": "completed"
    },
    "no_pressure_work": {
      "raw_metric": 2.3928042827816682,
      "score": 0.5130067517093656,
      "status": "completed"
    },
    "volume_fraction": {
      "raw_metric": 0.6339862635023651,
      "score": 0.8709685401115481,
      "status": "completed"
    },
    "homogeneous_loop": {
      "raw_metric": 1.9322216851206957,
      "score": 0.606746393081247,
      "status": "completed"
    },
    "duplicate": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "duplicate_probe": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "nonfinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "negative": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "overflow": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.2579579580000022,
    "reference_seconds": 1.4953060009999994
  },
  "checks": {
    "reference_improves_baseline": true,
    "reference_matches_independent_truth": true,
    "fixed_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "independent_full_credit": true,
    "equivalent_reordered_same": true,
    "wrong_answer_zero": true,
    "spinodal_is_not_binodal": true,
    "nearcritical_density_gap_matters": true,
    "clapeyron_slope_matters": true,
    "latent_pressure_work_matters": true,
    "mole_not_volume_fraction_matters": true,
    "global_convex_envelope_matters": true,
    "invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "public_start_matches_baseline": true,
    "feedback_physical_branches_and_constraints": true,
    "critical_interval_resolved": true,
    "course_quality_unmodified": true
  }
}

exit_code=0
```

### 2026-11-16T18:35:04.519812+08:00

```bash
docker build --tag theory-physics-sp05:dev tasks/sp-05/environment
```

```text
#0 building with "desktop-linux" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile: 460B done
#1 DONE 0.0s

#2 [internal] load metadata for mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#2 DONE 0.0s

#3 [internal] load .dockerignore
#3 transferring context: 2B done
#3 DONE 0.0s

#4 [1/5] FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#4 resolve mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2 done
#4 DONE 0.0s

#5 [internal] load build context
#5 transferring context: 8.10kB done
#5 DONE 0.0s

#6 [2/5] COPY requirements.txt /tmp/requirements.txt
#6 CACHED

#7 [3/5] RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt  && useradd --uid 1000 --create-home student  && mkdir -p /app/data /app/output  && chown -R student:student /app
#7 CACHED

#8 [4/5] COPY public/ /app/data/
#8 DONE 0.0s

#9 [5/5] WORKDIR /app
#9 DONE 0.0s

#10 exporting to image
#10 exporting layers 0.0s done
#10 exporting manifest sha256:da9a6a4a8ec1256c95668c80251d295b7740db512baf23ea56ea5cacfe3cb02e done
#10 exporting config sha256:440c853771e9c786d5b079b3b61b1202691f8a2f8de6954739838d61049308ba done
#10 exporting attestation manifest sha256:7f800fe493ec1ee864d884cce1070bdd3441f3426879d41c2eccec218636cd33 done
#10 exporting manifest list sha256:ce90d47d89fd0dac6a5eb77be519fe5c5ecc9ad2bd7562250e4faa3ed1c4566c done
#10 naming to docker.io/library/theory-physics-sp05:dev done
#10 unpacking to docker.io/library/theory-physics-sp05:dev 0.0s done
#10 DONE 0.1s

exit_code=0
```

### 2026-11-16T18:35:15.555185+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 theory-physics-sp05:dev sh -c 'python /app/data/start.py --data-root /app/data --output /app/output/answer.json && python /app/data/feedback.py /app/output/answer.json'
```

```text
{
  "valid": true,
  "cases": [
    {
      "id": "vdw-01",
      "relative_equal_pressure_residual": 0.11820574072320872,
      "scaled_equal_area_residual": -3.120665450730139e-16,
      "spinodal_derivative_residual": 3.552713678800501e-15,
      "density_gap_identity_residual": 0.0,
      "latent_enthalpy_relative_residual": 0.0,
      "clapeyron_identity_relative_residual": 0.0,
      "equilibrium_self_consistency_max_error": 0.0,
      "branch_order": true
    },
    {
      "id": "vdw-02",
      "relative_equal_pressure_residual": 0.0859158876234179,
      "scaled_equal_area_residual": 4.71947280805292e-16,
      "spinodal_derivative_residual": 7.105427357601002e-15,
      "density_gap_identity_residual": 0.0,
      "latent_enthalpy_relative_residual": 0.0,
      "clapeyron_identity_relative_residual": 0.0,
      "equilibrium_self_consistency_max_error": 0.0,
      "branch_order": true
    },
    {
      "id": "vdw-03",
      "relative_equal_pressure_residual": 0.042931527296130034,
      "scaled_equal_area_residual": -3.27639879475965e-16,
      "spinodal_derivative_residual": 1.7763568394002505e-14,
      "density_gap_identity_residual": 0.0,
      "latent_enthalpy_relative_residual": 1.7245674367938782e-16,
      "clapeyron_identity_relative_residual": 0.0,
      "equilibrium_self_consistency_max_error": 0.0,
      "branch_order": true
    },
    {
      "id": "vdw-04",
      "relative_equal_pressure_residual": 0.011486352109350673,
      "scaled_equal_area_residual": 0.0,
      "spinodal_derivative_residual": 1.7763568394002505e-15,
      "density_gap_identity_residual": 0.0,
      "latent_enthalpy_relative_residual": -1.2368275028124387e-16,
      "clapeyron_identity_relative_residual": 0.0,
      "equilibrium_self_consistency_max_error": 0.0,
      "branch_order": true
    },
    {
      "id": "vdw-05",
      "relative_equal_pressure_residual": 0.0018905929197656768,
      "scaled_equal_area_residual": -8.881784197001252e-16,
      "spinodal_derivative_residual": 8.881784197001252e-16,
      "density_gap_identity_residual": 0.0,
      "latent_enthalpy_relative_residual": -3.9232156022419624e-16,
      "clapeyron_identity_relative_residual": 0.0,
      "equilibrium_self_consistency_max_error": 0.0,
      "branch_order": true
    },
    {
      "id": "vdw-06",
      "relative_equal_pressure_residual": 0.00011956403708968111,
      "scaled_equal_area_residual": 0.0,
      "spinodal_derivative_residual": 1.7763568394002505e-15,
      "density_gap_identity_residual": 0.0,
      "latent_enthalpy_relative_residual": -1.962555713384283e-16,
      "clapeyron_identity_relative_residual": 0.0,
      "equilibrium_self_consistency_max_error": 0.0,
      "branch_order": true
    },
    {
      "id": "vdw-07",
      "relative_equal_pressure_residual": 4.799655139997583e-08,
      "scaled_equal_area_residual": 7.355227538141662e-16,
      "spinodal_derivative_residual": 5.3290705182007514e-14,
      "density_gap_identity_residual": 0.0,
      "latent_enthalpy_relative_residual": 4.718447854656915e-16,
      "clapeyron_identity_relative_residual": 0.0,
      "equilibrium_self_consistency_max_error": 0.0,
      "branch_order": true
    },
    {
      "id": "vdw-08",
      "relative_equal_pressure_residual": 1.0565992525357615e-12,
      "scaled_equal_area_residual": 4.2240516640035253e-16,
      "spinodal_derivative_residual": 0.0,
      "density_gap_identity_residual": 0.0,
      "latent_enthalpy_relative_residual": 1.431146867680866e-17,
      "clapeyron_identity_relative_residual": 0.0,
      "equilibrium_self_consistency_max_error": 0.0,
      "branch_order": true
    }
  ],
  "note": "反馈只检验公开方程和所交分支的一致性；不提供真实共存端点。临界附近仅看小残差不足以排除退化根。"
}

exit_code=0
```

### 2026-11-16T18:35:15.864409+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-sp05:dev python tools/run_sp05_checks.py
```

```text
{
  "scores": {
    "baseline": {
      "raw_metric": 4.913423935918016,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    },
    "independent": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    },
    "wrong": {
      "raw_metric": 89.01265557901907,
      "score": 0.0,
      "status": "completed"
    },
    "spinodal_as_binodal": {
      "raw_metric": 16.745050384581123,
      "score": 0.0,
      "status": "completed"
    },
    "collapsed_gap": {
      "raw_metric": 14.999999995249638,
      "score": 0.0,
      "status": "completed"
    },
    "wrong_clapeyron": {
      "raw_metric": 10.0,
      "score": 0.0,
      "status": "completed"
    },
    "no_pressure_work": {
      "raw_metric": 2.3928042827816682,
      "score": 0.5130067517093656,
      "status": "completed"
    },
    "volume_fraction": {
      "raw_metric": 0.6339862635023651,
      "score": 0.8709685401115481,
      "status": "completed"
    },
    "homogeneous_loop": {
      "raw_metric": 1.9322216851206957,
      "score": 0.606746393081247,
      "status": "completed"
    },
    "duplicate": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "duplicate_probe": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "nonfinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "negative": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "overflow": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.12179900000000998,
    "reference_seconds": 1.509094499999975
  },
  "checks": {
    "reference_improves_baseline": true,
    "reference_matches_independent_truth": true,
    "fixed_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "independent_full_credit": true,
    "equivalent_reordered_same": true,
    "wrong_answer_zero": true,
    "spinodal_is_not_binodal": true,
    "nearcritical_density_gap_matters": true,
    "clapeyron_slope_matters": true,
    "latent_pressure_work_matters": true,
    "mole_not_volume_fraction_matters": true,
    "global_convex_envelope_matters": true,
    "invalid_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "public_start_matches_baseline": true,
    "feedback_physical_branches_and_constraints": true,
    "critical_interval_resolved": true,
    "course_quality_unmodified": true
  }
}

exit_code=0
```

### 2026-11-16T22:17:57.773836+08:00

```bash
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' sp-05 --macos-compat
```

```text
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-sp-05-harbor-1ftlqfgh/sp-05 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-sp-05-harbor-1ftlqfgh/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:27 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 27s
Results written to 
/tmp/physics-sp-05-harbor-1ftlqfgh/runs/oracle/2026-11-16__22-17-58/result.json
Inspect results by running `harbor view 
/tmp/physics-sp-05-harbor-1ftlqfgh/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-sp-05-harbor-1ftlqfgh/runs/oracle/2026-11-16__22-17-58`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-sp-05-harbor-1ftlqfgh/sp-05 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-sp-05-harbor-1ftlqfgh/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-sp-05-harbor-1ftlqfgh/runs/nop/2026-11-16__22-18-31/result.json
Inspect results by running `harbor view 
/tmp/physics-sp-05-harbor-1ftlqfgh/runs/nop`
Share results by running `harbor upload 
/tmp/physics-sp-05-harbor-1ftlqfgh/runs/nop/2026-11-16__22-18-31`

{
  "task_id": "sp-05",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-sp-05-harbor-1ftlqfgh/sp-05",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-sp-05-harbor-1ftlqfgh/sp-05",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-sp-05-harbor-1ftlqfgh/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:17:57.809602+00:00",
      "archive": "runs/sp-05/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-17-58/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "sp-05__vrfajwJ"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-sp-05-harbor-1ftlqfgh/sp-05",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-sp-05-harbor-1ftlqfgh/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:18:30.612125+00:00",
      "archive": "runs/sp-05/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-18-31/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "sp-05__SY2wooJ"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}

exit_code=0
```
