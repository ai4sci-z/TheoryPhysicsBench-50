
### 2026-11-16T18:22:42.644773+08:00

```bash
rg --files planning -g '*expansion*review*'
```

```text
planning/qft-expansion-radovanovic-review.md

exit_code=0
```
