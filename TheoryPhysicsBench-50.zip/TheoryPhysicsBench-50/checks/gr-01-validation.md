# gr-01 开发验证

日期：2026-11-16。此文记录题包开发验证，不代表课程指定 Codex 的正式测评结果。

## 实际完成的数值验证

环境：本地 Docker Linux aarch64（Linux 6.12.76），Python 3.12.13、mpmath 1.3.0；4 CPU、4 GB 内存、断网、0 GPU。复用已存在的 `theory-physics-ed01:dev` 镜像，依赖版本与本题 `requirements.txt` 一致。没有连接远程服务器。

| 方案 | 原始指标，百分点，越低越好 | 课程统一质量分 | 程序耗时 |
|---|---:|---:|---:|
| 弱场简单基线 | 51.038343111983096 | 0 | 0.02636 秒 |
| 完整测地线参考解 | 7.510523845096038e-14 | 1 | 0.34210 秒 |
| 改变数组顺序的等价解 | 7.510523845096038e-14 | 1 | 包含于检查运行 |
| 全部报捕获并错误反向参数 | 85.0 | 0 | 包含于检查运行 |
| 将全部散射绕行周数改为 0 | 6.000000000000076 | 0.88244 | 包含于检查运行 |
| 将总偏折角对 2π 取模 | 10.500484364197064 | 0.79426 | 包含于检查运行 |
| 将临界光线误报为捕获 | 7.500000000000075 | 0.85305 | 包含于检查运行 |

完整分项、空提交入口和反馈检查在 `checks/gr-01-calibration.json`。`tests/metric.json` 和 `environment/public/metric.json` 使用同一次实测端点，容差为 1e-7 个百分点。

## 独立真值

`tools/build_gr01_truth.py` 使用 75 位 mpmath 三角三次根及 Legendre 椭圆积分，不导入参考程序。它另外进行 55 位重算及 Legendre 正规形式的直接积分，验证根、特殊函数与精度稳定性。

- 7 条散射光线的最大三次方程残差小于 3.5e-77。
- 最靠近临界的 `ray-04`（δ=1e-12）在 75 位和 55 位计算间的偏折差小于 5.5e-45。
- 椭圆积分与正规形式直接积分的最大偏折差小于 1.6e-73。
- 4 个反向目标的高精度偏折残差均小于 1.3e-56；最终对数参数区间宽度约 1.15e-56。
- 捕获/临界/散射完整性由外部有效势唯一极大值证明；散射根选择由从无穷远可达性证明；反向解唯一性由参考推导中的单调性证明。

原始精度记录位于 `checks/gr-01-truth-validation.json`，最终验证值位于 `tasks/gr-01/tests/private/truth.json`。输出中的小数是给定 JSON 输入的物理解，不由舍入后的冲量参数重建输入。

## 通过的 14 项检查

1. 本题统一质量评分函数的 SHA-256 与教师原版一致。
2. 参考结果在原始指标容差内匹配独立真值。
3. 参考相对基线的改善超过容差。
4. 登记的基线/参考端点与实际测量一致。
5. 基线质量分 0、参考质量分 1。
6. 合法数组重排不改变原始指标。
7. 格式合法的实质错解受到处罚，并保持 `completed` 状态。
8. 漏记绕行周数受到处罚。
9. 偏折角取模受到处罚。
10. 临界光线误分类受到处罚。
11. 错误转折半径受到数值处罚。
12. 缺字段、重复 id、布尔值冒充整数、非有限数被拒绝。
13. 实际 `test.sh` 入口对参考产物给 1、对缺失产物给 0，缺失产物状态为 `invalid`。
14. 公开反馈能检查 7 条散射轨道，参考转折残差小于 1e-12，均位于光子球外且周数自洽。

教师评分函数在宿主机将原件与副本分别执行 SHA-256，两者均为 `797343b693d5676a4bd0dd13a8270038d2f879bcb41f863ec87563ead807def4`。容器检查该固定摘要，避免把宿主项目外的教师目录依赖混入题包。

## 发现并修复的开发问题

- 宿主系统 Python 没有 NumPy；打包运行时也没有 SciPy/mpmath。参考程序使用标准库运行，高精度真值在现有本地 Linux 容器计算，没有临时安装依赖或访问服务器。
- 首次 Linux 校准将教师文件定位到容器挂载范围外，检查脚本报 `FileNotFoundError`；改为核对已在宿主机验证的原版 SHA-256。首次失败不算成功验证，重跑后 14 项才全部通过。

## 尚未执行的验收环节

本记录尚不包含本题专用环境的 Harbor oracle/nop 运行或课程统一配置的三次 Codex 正式测评。它们需在相应实际运行后登记。不得把开发参考执行、真值计算或空提交检查当作被测智能体结果。外部相近 benchmark 检索仍需在整套冻结前补齐。

## 复现命令

在项目根目录执行：

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-ed01:dev python tools/build_gr01_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-ed01:dev python tools/run_gr01_checks.py
```

第二条不带 `--calibrate`，核对已登记端点，不重新定义评价尺度。
