
### 2026-11-16T22:09:25.637060+08:00

```bash
docker run --rm --cpus 4 --memory 4g --network none --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/workspace' -w /workspace theory-physics-qft04:dev python3 tools/build_tm05_truth.py
```

```text
[
  {
    "id": "ring-01",
    "energy_balance_residual": 2.416955524608966e-13,
    "contact_quadrature": "adaptive 0..2pi with singular contact split"
  },
  {
    "id": "ring-02",
    "energy_balance_residual": 2.886579864025407e-14,
    "contact_quadrature": "adaptive 0..2pi with singular contact split"
  },
  {
    "id": "ring-03",
    "energy_balance_residual": 2.220446049250313e-16,
    "contact_quadrature": "adaptive 0..2pi with singular contact split"
  },
  {
    "id": "ring-04",
    "energy_balance_residual": 3.774758283725532e-14,
    "contact_quadrature": "adaptive 0..2pi with singular contact split"
  },
  {
    "id": "ring-05",
    "energy_balance_residual": 9.681144774731365e-14,
    "contact_quadrature": "adaptive 0..2pi with singular contact split"
  },
  {
    "id": "ring-06",
    "energy_balance_residual": 5.935252289646087e-13,
    "contact_quadrature": "adaptive 0..2pi with singular contact split"
  },
  {
    "id": "ring-07",
    "energy_balance_residual": 4.5075054799781356e-14,
    "contact_quadrature": "adaptive 0..2pi with singular contact split"
  }
]

exit_code=0
```
