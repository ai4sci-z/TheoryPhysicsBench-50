
### 2026-11-16T22:09:25.635406+08:00

```bash
docker run --rm --cpus 4 --memory 4g --network none --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/workspace' -w /workspace theory-physics-qft04:dev python3 tools/build_qm04_truth.py
```

```text
[
  {
    "id": "spin-01",
    "unitarity_residual": 6.217248937900877e-15
  },
  {
    "id": "spin-02",
    "unitarity_residual": 1.7763568394002505e-15
  },
  {
    "id": "spin-03",
    "unitarity_residual": 1.3922196728799463e-13
  },
  {
    "id": "spin-04",
    "unitarity_residual": 2.55351295663786e-15
  },
  {
    "id": "spin-05",
    "unitarity_residual": 6.772360450213455e-15
  },
  {
    "id": "spin-06",
    "unitarity_residual": 9.992007221626409e-16
  }
]

exit_code=0
```
