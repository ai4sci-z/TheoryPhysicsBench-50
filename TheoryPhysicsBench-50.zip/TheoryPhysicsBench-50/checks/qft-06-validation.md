# qft-06 开发验证

{
  "id": "qft-06",
  "checks": 19,
  "passed": true,
  "baseline": 0.014735869029594778,
  "reference": 1.0222377899060933e-14,
  "reference_seconds": 0.14707370800010722,
  "harbor_oracle_nop_passed": true,
  "harbor_sessions": [
    "runs/qft-06/harbor-macos-compat/session-20261116-222538.json",
    "runs/qft-06/harbor-macos-compat/session-20261116-223633.json"
  ]
}

平台：Linux-6.12.76-linuxkit-aarch64-with-glibc2.36，Python 3.12.13；Docker 4 CPU/4 GiB、无网络、0 GPU。依赖固定于题包。

独立真值细节见 `qft-06-truth-validation.json`；所有校准条目和端到端入口产物在 `qft-06-calibration.json`。原始失败与修复命令不删除，见 `qft-06-12-command-log.md`。参考程序、基线、真实错误解、空产物、非法JSON数值及等价记录重排用同一评分器验证。

Harbor原始运行归档在 `runs/qft-06/harbor-macos-compat`；macOS兼容试跑仅将verifier网络声明从no-network改为public，最终task.toml保持独立离线verifier。正式课程Codex三次测评尚未运行，oracle不冒充正式结果。
