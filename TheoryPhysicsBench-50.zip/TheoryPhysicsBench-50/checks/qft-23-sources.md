# QFT-23：热光子 HTL 的因果响应与集体模


来源：François Gelis, *Problems in Quantum Field Theory*, 第73题；用户PDF实际页176–179，书页298–301。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与约定

Gelis 第73题从带电硬粒子的无碰撞 Vlasov 响应推出 HTL 极化。请为**单个无质量 Dirac 物种**的各向同性平衡等离子体建立 retarded 响应。电子、正电子及两自旋的简并度共4，分布为 \(f_0(p)=4/(e^{p/T}+1)\)。自然单位；Debye 质量由硬动量积分确定，\(m_D^2=e^2 C_D T^2\)，\(C_D\) 要计算。下面所有频率和波数按 \(m_D\) 归一化，极化按 \(m_D^2\) 归一化。

波矢沿 \(+z\)，度规 \((+---)\)，时空 Fourier 为 \(e^{-i\omega t+i k z}\)，retarded 分母是 \(\omega-ku+i0\)。定义 \(x=\omega/k\) 和角平均响应
\[
 A(x)=\frac{\Pi^{00}_R}{m_D^2}=1-\frac{x}{2}\int_{-1}^1\frac{du}{x-u+i0},
\qquad B(x)=\frac{\Pi_T}{m_D^2}=\frac{x}{4}\int_{-1}^1\frac{1-u^2}{x-u+i0}\,du.
\]
它们是 Vlasov 张量的角积分起点，不把书中的实绝对值对数自动当作因果函数。空间样区域要保留主值和 \(\delta\) 项。由 Ward 关系，\(\Pi^{03}/m_D^2=xA\)、\(\Pi^{33}/m_D^2=x^2A\)。采用 Coulomb-gauge 纵向归一化响应 \(D_{00}=1/(k^2+A)\)，查询均离真实光锥奇点有限距离。

纵向正频集体模为 \(D_L(\omega,k)=k^2+A(\omega/k)=0\) 中 \(\omega>k\) 的物理解；横向为 \(D_T=\omega^2-k^2-B(\omega/k)=0\) 的物理解。留数定义为相应 **\(\omega\) 变量的一阶导数倒数**：\(R_L=(\partial_\omega D_L)^{-1}\)、\(R_T=(\partial_\omega D_T)^{-1}\)。不要与 \(\omega^2\) 留数混用，也不要额外取绝对值或乘 \(2\omega\)。

## 必须交付

每个 `queries` ID 行，`values` 依次为
`[Re A,Im A,Re B,Im B,Re(xA),Im(xA),Re(x²A),Im(x²A),Re D00,Im D00]`。

每个 `mode-k波数` 行，`values=[omega_L,omega_T,R_L,R_T]`。全部 `mode_k` 都要找到对应物理解。

`limits` 行依次为
`[lim_(k→0) lim_(omega→0) A,lim_(omega→0) lim_(k→0) A,Pi_T_static/mD²,Pi_T_uniform/mD²,C_D]`。
这里外侧极限写在前；`Pi_T_uniform` 指先在非零 \(\omega\) 下取 \(k\to0\)，再 \(\omega\to0\)。说明为什么两个 \(A\) 极限不交换。

HTL 仅适用于弱耦合、硬粒子动量约 \(T\)、软外动量约 \(eT\) 的各向同性平衡体系。本题没有碰撞项，不是所有温度/动量下的完整一圈真空加热修正。


## 验证路线

参考解对retarded角积分采用上半平面边界的复对数；|x|<1处为 log|(x+1)/(x-1)|-i*pi。由导数公式得到留数，再在omega>k域求两支物理解。静态与均匀极限由积分展开得到，C_D=4/pi² int_0^infty dp p/(e^p+1)=1/3。

独立真值对空间样点用Cauchy主值求积加精确delta项，对时间样点直接做速度积分。导数通过独立积分而非复用对数导数；Debye系数通过热分布径向求积。Ward分量按公开张量约定构造。

基线使用40点Gauss速度角网格和固定eta=.04，模式用小k等离子体近似；固定展宽和低阶色散不能覆盖光锥附近与有限k真实响应。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。
