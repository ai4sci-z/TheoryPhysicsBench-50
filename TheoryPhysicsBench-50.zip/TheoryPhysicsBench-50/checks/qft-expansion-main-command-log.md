
### 2026-11-16T18:22:42.644778+08:00

```bash
python3 tools/read_qft_source_pages.py gelis 161:168,225:231
```

```text

===== PDF PAGE 161 =====
69 BANKS–CASHER RELATION 283
69. Banks–Casher Relation Quantum chromodynamics, if restricted to the up and down
quarks, has a nearly exact chiral symmetry thanks to the very small masses of these quarks.
The three pions (π0,π±) are also much lighter than the other hadrons, a property which is
understood as a consequence of them being the Nambu–Goldstone bosons that result from the
spontaneous breaking of chiral symmetry (fromSU(2)×SU(2) toSU(2), hence three pions
corresponding to the three broken symmetries – note that their masses are not exactly zero,
because the symmetry was not exact to begin with). The goal of this problem is to establish a
relationship, known as the Banks–Casher relation, between the value of the chiral condensate⟨
ψψ
⟩
(which should be zero if chiral symmetry holds, and which may be viewed as the order
parameter for its spontaneous breaking) and the spectral density at zero energy of the Dirac
operator. Consider Euclidean QCD in the continuum.
69.a Show that the expectation value
⟨
ψ(x)ψ(x)
⟩
can be written as
⟨
ψ(x)ψ(x)
⟩
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM [A] det (i/D −m) trV
[ 1
i/D −m
]
,
whereV is a four-dimensional Euclidean volume to which the trace is restricted, andZ
is the same integral without the trace and the prefactor1/V.
69.b Recalling the properties of the Euclidean Dirac operator, write the trace as follows:
trV
[ 1
i/D −m
]
=
∑
n
1
iλn −m =−
∑
n
m
λ2n +m2,
where theλn are real numbers.
69.c Show that
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
69.d Show that, in the limits of inﬁnite volume and zero quark mass, we have⟨
ψ(x)ψ(x)
⟩
=− π limV→∞ ρV (0).


===== PDF PAGE 162 =====
284 5 LATTICE, FINITE T , STRONG FIELDS
69.a Note ﬁrst that the equal-point correlation function
⟨
ψ(x)ψ(x)
⟩
is independent of the
pointx thanks to translation invariance. Therefore, we may write
⟨
ψ(x)ψ(x)
⟩
= lim
V→∞
1
V
∫
V
d4x⟨ψ(x)ψ(x)⟩,
where V is a ﬁnite volume in Euclidean R 4. Then, it admits the following path integral
representation:
⟨
ψ(x)ψ(x)
⟩
= 1ZV ∫ [DAμDψDψ] e−SYM −SD ∫V d4x ψ(x)ψ(x)
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM det (i/D −m)
∫
V
d4x⟨x⏐⏐ 1i/D −m⏐⏐x⟩
= lim
V→∞
1
ZV
∫
[DAμ] e−SYM det (i/D −m) trV
[ 1
i/D −m
]
, (5.18)
where Z ≡
∫
[DAμDψDψ] e−SYM −SD.
In this formula, it is implicitly understood that the integrand is calculated for a ﬁnite volume
theory, in which the spectrum of the Dirac operator is discrete. The limit V →∞ ensures that
we recover the original theory in the end.
69.b The Euclidean Dirac matrices are anti-Hermitian,γμ† =− γμ, as is the derivative∂μ.
Therefore, the Euclidean Dirac operator is Hermitian, and it can therefore be diagonalized in
an orthonormal basis with real eigenvalues:
/Dψn(x)= λnψn(x),λ n ∈ R ,
∫
V
d4xψ∗m(x)ψn(x)= δmn.
(Note that the eigenvalues depend implicitly on the background gauge ﬁeldAμ.) The trace of
the inverse of the Dirac operator can be expressed in terms of these eigenvalues as follows:
trV
[ 1
i/D −m
]
=
∑
n
1
iλn −m.
On the other hand, sinceγ5γμγ5 = γμ† =− γμ, we can write
trV
[ 1
i/D −m
]
= trV
[
γ5γ5 1i/D −m] = trV [γ5 1i/D −mγ5]
= trV
[ 1
−i/D −m
]
=
∑
n
1
−iλn −m.
By taking the half-sum of the two representations of the trace, we arrive at
trV
[ 1
i/D −m
]
=−
∑
n
m
λ2n +m2 =−
∫
dλ
[ ∑
n
δ(λ −λn)
] m
λ2 +m2.


===== PDF PAGE 163 =====
70 NIELSEN–NINOMIYA THEOREM 285
69.c Inserting this expression in (5.18), we immediately get
⟨
ψ(x)ψ(x)
⟩
=− lim
V→∞
∫
dλ mρV (λ)λ2 +m2,
with ρV (λ) ≡ 1ZV ∫ [DAμ] e−SYM[A] det (i/D −m) ∑n δ(λ −λn).
The integrand in the deﬁnition ofρV (λ) is a distribution that has a delta peak at each eigenvalue
of the ﬁnite volume Dirac operator, and its integral over some range [λ1,λ2] counts the number
of eigenvalues in that range, per unit of volume V. The average over all conﬁgurations of
the gauge ﬁeldAμ washes out the delta peaks and turnsρV (λ) into a smooth distribution that
provides the average density of eigenvalues of the Dirac operator:
∫λ2
λ1
dλ ρV (λ)=
⟨# of eigenvalues in [λ1,λ2]
V
⟩
A
.
Note that this distribution has a gap at the lower end of the spectrum because of the ﬁnite
volume.
69.d As the volume increases, the gap at the lower end decreases, andρV (λ) has support in
the entire range [0, +∞) in the inﬁnite-volume limit. Moreover, when the quark mass goes to
zero, we have
lim
m→0+
m
λ2 +m2 = πδ (λ).
Therefore, we have
lim
m→0+
⟨
ψ(x)ψ(x)
⟩
=− π lim
V→∞
ρV (0).
This relation is known as the Banks–Casher relation. The left hand side is a quantity known
as the chiral condensate. In the massless limit, the Dirac Lagrangian is invariant under chiral
transformations, since it does not contain an operator ψψ (which breaks chiral symmetry).
A non-zero expectation value of this operator therefore signals that the ground state of the
theory breaks chiral symmetry. The Banks–Casher formula relates the chiral condensate, which
quantiﬁes the spontaneous breaking of chiral symmetry, to the spectral density at the lower
end of the spectrum of the Dirac operator (the latter is controlled by how quickly eigenvalues
accumulate nearλ = 0 when the volume becomes inﬁnite).
Source: Banks, T. and Casher, A. (1980), Nucl Phys B 169: 103.
70. Nielsen–Ninomiya Theorem The goal of this problem is to prove theNielsen–Ninomiya
theorem, an obstruction to the construction of chiral gauge theories on the lattice. Consider
an inﬁnite square lattice of spacing a. The conjugate momenta pμ are continuous variables
with components in the range
[
− πa, +πa] and any function ofpμ is periodic with period 2π/a.In other words, we may view momentum space as a four-dimensional torusT4. The inverse
propagator of a massless left-handed fermion can be written as S−1(p)= ∑μ γμPLFμ(p),
whereFμ(p) is a real continuous vector ﬁeld onT4 andPL ≡ (1 −γ5)/2.


===== PDF PAGE 164 =====
286 5 LATTICE, FINITE T , STRONG FIELDS
70.a Explain why such a fermion exists if the vector ﬁeldFμ(p) has a zeropμ∗ in the vicinity
of which it behaves asFμ(p)=( p −p∗)μ +O((p −p∗)2). Note that the ﬁeld lines of
Fμ are all pointing away fromp∗.
70.b Consider now a zero ofFμ(p) at which the ﬁeld lines are incoming in one direction and
outgoing in the other three directions, such asFμ(p)=( − 1)δμ1 (p−p∗)μ +O((p−p∗)2).
Show that this zero in fact describes a right-handed particle. Hint: apply a similarity
transformation γ1γ5. Use this result to explain why, in one dimension, there must be
equal numbers of left-handed and right-handed fermions in the spectrum of the lattice
Dirac operator.
70.c More generally, explain the relationship between the handedness of a fermion and the
number of “ingoing directions” of the vector ﬁeldFμ at a zerop∗.
70.d The index of a zero of a vector ﬁeld is deﬁned as (−1)n, where n is the number of
dimensions along which the ﬁeld lines are ﬂowing away from the zero. The Poincar´e–
Hopf theorem states that the sum of the indices of the zeroes of a vector ﬁeld is equal to
the Euler characteristic of the manifold on which it is deﬁned, which is zero for a torus.
Use this result to conclude that this lattice setup in fact has equal numbers of left-handed
and right-handed fermions.
70.a The form S−1(p)= ∑μ γμPLFμ(p) for the inverse propagator assumes (discrete)
translation invariance on the lattice, and that the lattice is inﬁnite, so that the conjugate
momentum space is continuous rather than discrete. Because of the ﬁnite lattice spacing, the
momentumpμ is deﬁned on a four-dimensional torusT4 (each component of the momentum is
bounded, and the bounds in the positive and negative directions are identiﬁed) rather than R 4.
The functionFμ(p) is real if the Lagrangian is Hermitian, and is continuous provided the theory
is quasi-local (i.e., when the action is written as S ≡ ∑x,y ψ(x)h(x,y)ψ(y), the function
h(x,y) should decrease fast enough). Since Fμ(p) has as many components (μ = 1,2,3,4 )a s
its argumentp, it is a vector ﬁeld. Moreover, Fμ(p) may be viewed locally as the gradient of a
scalar function F(p),Fμ(p)= ∂pμF(p).
A massless fermion corresponds to a momentump∗ where the inverse Dirac propagator
vanishes linearly (think of the propagatori//p in the continuous theory). This means that all
the components ofFμ(p) vanish simultaneously atp∗,
Fμ(p) ∼ fμν(p −p∗)ν.
By an appropriate change of coordinates, the matrix of coefﬁcientsfμν can be made diagonal,
with only positive coefﬁcients. Up to a rescaling (by positive factors) of the components of pμ,
this implies the announced behavior nearp∗. These zeroes of the vector ﬁeldFμ(p) correspond
to minima of F(p). About such a zero, the ﬁeld lines of Fμ are all oriented outwards fromp∗.
Note that, because we have included an explicit projectorPL in the deﬁnition of the inverse
propagator, these zeroes describe left-handed fermions.


===== PDF PAGE 165 =====
70 NIELSEN–NINOMIYA THEOREM 287
70.b Let us now ﬂip the orientation of the ﬁeld lines along one direction, i.e., consider a zero
for which the ﬁeld lines are ﬂowing away along three directions and into the zero along the
remaining direction (for instance the directionμ = 1):
Fμ(p)=( − 1)δμ1 (p −p∗)μ +O((p −p∗)2).
As suggested in the statement of the problem, we should study the following combination:
(γ1γ5)−1(−1)δμ1γμPL (γ1γ5)= γ5γ1(−1)δμ1γμPLγ1γ5
=
{
μ = 1 :− γ5γ1γ1PLγ1γ5 = γ1PR
μ ⁄= 1 :+ γ5γ1γμPLγ1γ5 = γμPR
}
= γμPR.
(Note that we also have (γ1γ5)−1(−1)δμ1γμPR (γ1γ5)= γμPL .) Therefore, this type of zero
describes (in disguise, i.e., up to a similarity) a massless fermion of right-handed chirality. This
observation is sufﬁcient to prove the Nielsen–Ninomiya theorem in one dimension: indeed, a
smooth vector ﬁeld on a circle must have an equal number of zeroes where the ﬁeld lines go
towards the zero (corresponding to left-handed fermions) and zeroes where the ﬁeld lines go
away from the zero (corresponding to right-handed fermions).
70.c Consider now a zero such that the vector ﬁeld is ﬂowing into the zero along two
directions and away from it along two directions. If the two dimensions along which the ﬁeld
is ﬂowing inwards areμ = 1,2 , we need now to considerFμ(p)=( − 1)δμ1 (−1)δμ2 (p −p∗)μ.
We have
(γ2γ5)−1(−1)δμ2
[
(γ1γ5)−1(−1)δμ1γμPL (γ1γ5)](γ2γ5)
=( γ2γ5)−1(−1)δμ2γμPR (γ2γ5)= γμPL.
Thus, this zero corresponds to a left-handed fermion. The pattern should be clear by now:
the chirality of the fermion ﬂips every time we add a direction along which the vector ﬁeld is
ﬂowing into the corresponding zero. In more mathematical terms, if a1,...,a p are distinct
integers in [1,4 ],w eh a v e
(γapγ5)−1 ··· (γa1γ5)−1
[
(−1)μa1 ··· (−1)μapγμPL
]
(γa1γ5)··· (γapγ5)
=
{γμPL ifp is even,
γμPR ifp is odd.
In words, the zero describes a left-handed fermion if the ﬁeld lines are ﬂowing into the
zero along an even number of directions, and a right-handed fermion for an odd number of
directions.
70.d The index of a zero of a vector ﬁeld is deﬁned as (−1)n, where n is the number
of dimensions along which the ﬁeld lines are ﬂowing away from the zero (see Figure 5.1).
Therefore, ind dimensions, we have the following correspondence between the index of a zero


===== PDF PAGE 166 =====
288 5 LATTICE, FINITE T , STRONG FIELDS
Figure 5.1 Two-dimensional vector ﬁelds with zeroes of index +1 (Left: Fμ(p)= pμ) and −1
(Right: Fμ(p)=( − 1)δμ1pμ).
ofFμ and the chirality of the fermion it describes:
index= (−1)d ←→ left-handed,
index= (−1)d+1 ←→ right-handed.
The usefulness of this concept in the present discussion stems from thePoincar´e–Hopf theorem,
which relates the sum of the indices of the zeroes of a smooth vector ﬁeld deﬁned on a manifold
M without boundary to a topological invariant of this manifold, namely its Euler characteristic,
denoted byχ(M):
∑
zeroesz∗
index (z∗)= χ(M).
For two-dimensional manifolds, the Euler characteristic can be easily visualized and calculated
from any triangulation of the surface, since it is given by
χ(M)=( number of vertices)−( number of edges)+( number of faces).
(See Problem 42 for a discussion of the main properties of this quantity, in particular the fact
that it does not depend on the chosen triangulation.) From this deﬁnition, one may see that the
Euler characteristic of a2-sphere isχ = 2 and that it isχ = 0 for a two-dimensional torus with
one handle. This implies that any smooth vector ﬁeld on such a torus must have equal numbers
of zeroes of index +1 and −1, as illustrated in Figure 5.2. In the discussion of chiral fermions
on the lattice, this result implies that any such propagator would in fact describe equal numbers
of left-handed and right-handed fermions in two dimensions, despite the fact that we have put
an explicit projectorPL in it. This obstruction to the possibility of deﬁning chiral fermions on
the lattice is known as the Nielsen–Ninomiya theorem.
The Euler characteristic is in fact zero for one-holed tori in any dimension (but this is harder
to visualize in dimensions higher than two), in particular for the torusT4 on which the vector
Fμ(p) that enters in the inverse fermion propagator is deﬁned. Thus, the Nielsen–Ninomiya
theorem is also valid in four dimensions.


===== PDF PAGE 167 =====
70 NIELSEN–NINOMIYA THEOREM 289
Figure 5.2 Illustration of the Poincar´e–Hopf theorem: smooth vector ﬁeld on a torus in two
dimensions with a zero of index +1 (open circle) and a zero of index −1 (ﬁlled circle).
Sketch of a Proof of the Poincar ´e–Hopf Theorem: The ﬁrst step in proving the Poincar´e–
Hopf theorem is to show that the sum of the indices of the zeroes is the same for all the
smooth vector ﬁelds. In fact, one can show (see, for instance, Milnor, J. W. (1997),Topology
from the Differentiable Viewpoint (Princeton University Press)) that the sum of the indices
of any smooth vector ﬁeld on a d-dimensional manifold M is equal to twice the degree of
the Gauss mapping fromM to the sphereSd (loosely speaking, this degree counts how many
times the Gauss mapping wraps around Sd), and is therefore a property of M itself. Then one
could invoke the Gauss–Bonnet theorem (see Problem 22) to relate this quantity to the Euler
characteristic.
A more elementary approach is to construct a special vector ﬁeld on M for which it is
easy to relate the sum of the indices to the Euler characteristic χ(M). For this, we start from a
triangulation of the manifoldM. For a two-dimensional manifold, this is a decomposition of
M into planar triangles, while in three dimensions it is a decomposition into tetrahedrons, and
more generally a decomposition ind-simplices ind dimensions. Note that, in a triangulation,
d-dimensional simplices meet at a (d −1)-dimensional simplex, etc. On such a triangulation,
consider the vector ﬁeld of Figure 5.3 (illustrated here in two dimensions). In this ﬁgure, the
triangle in boldface shows the conﬁguration of the ﬁeld lines in one cell of the triangulation,
and all the other triangles simply replicate the same pattern. This ﬁeld has zeroes at all the
vertices of the triangulation, at the midpoints of all the edges, and at the centers of all the
triangles. Moreover, if we count the number of dimensions along which the ﬁeld lines are
oriented away from these zeroes, we have
index (vertex)=+ 1,
index (edge midpoint)=− 1,
index (face center)=+ 1,
and the sum of the indices at all these zeroes reads
∑
zeroesz∗
index (z∗)=( number of vertices)−( number of edges)+( number of faces),
which is nothing but the deﬁnition of the Euler characteristic for a two-dimensional manifold.


===== PDF PAGE 168 =====
290 5 LATTICE, FINITE T , STRONG FIELDS
Figure 5.3 Special vector ﬁeld used in the proof of the Poincar´e–Hopf theorem (here, in two
dimensions). Left: layout of the main ﬁeld lines on top of a triangulation of the surface. Right:
detail of the ﬁeld lines in one elementary triangle.
In higher dimensions, one may construct a similar vector ﬁeld, with zeroes at the centers of
all thek-simplices (k ≤ d) that make up the triangulation, and the above pattern generalizes to
index (center ofk-dim simplex)=( − 1)k.
Therefore, for such a ﬁeld conﬁguration ind dimensions, we have
∑
zeroesz∗
index (z∗)=
d∑
k=0
(−1)k × (number ofk-dim simplices),
which is again the deﬁnition of the Euler characteristic of a d-dimensional manifold. Al-
though explicit, the right-hand side of this equation is less practical for calculating the Euler
characteristic in dimensions greater than two because it is hard to visualize triangulations of
higher-dimensional manifolds.
Source: Karsten, L. H. (1981), Phys Lett B 104: 315.
71. Wigner Transform of a Convolution Product The Wigner transform of a two-point
functionF(x,y ) is a function F(X,p ) obtained by Fourier transformingF(x,y ) with respect to
the differencex −y while keeping the dependence on the midpoint coordinateX ≡ (x +y)/2:
F(X,p ) ≡
∫
ddse ip·s F(X + s2,X − s2 ).
Consider a pair of two-point functionsF(x,y ) andG(x,y ) and their convolutionH(x,y ) ≡∫
ddzF (x,z )G(z,y ). Show that their respective Wigner transforms are related by
H(X,p )= F(X,p ) exp
{i
2
[ ←
∂X
→
∂p −
→
∂X
←
∂p
]}
G(X,p ). (5.19)
This result plays a role in the derivation of the Boltzmann equation from the Kadanoff–Baym
equations. It is also an important ingredient in the formulation of quantum mechanics in


===== PDF PAGE 225 =====
82 ANDERSON LOCALIZATION 347
ρ → −∞. Therefore, the horizon of the black hole is located on the two semi-axes x+ = 0
andx− = 0. It turns out that, in the Kruskal coordinates, there is no singularity at the horizon,
and they can also be used below the horizon.
Note now that (5.40) are formally identical to the relationship between the light-cone
coordinates of the static and accelerated observers, as discussed for the Unruh effect, provided
we interpret (4M)−1 as the acceleration. Therefore, we can exactly reproduce the same steps
without any modiﬁcation: (1) decompose the ﬁelds in Fourier modes in the two systems of
coordinates, (2) ﬁnd the Bogoliubov transformation that relates the two sets of creation and
annihilation operators, (3) calculate the expectation value of the number operatorb†kbk of onesystem in the vacuum state of the other system. This leads to
⟨
0kruskal
⏐⏐(b†kbk)staticobs. ⏐⏐0kruskal⟩ = Ve8πMk −1,
i.e., a thermal equilibrium distribution with a temperature T =( 8πM)−1 (this is known as
the Hawking temperature). Let us end with a remark about why we use the Kruskal vacuum
in the last equation. Loosely speaking, in the presence of a black hole, other vacuum states,
deﬁned by non-freely falling observers, would have a very large energy density near the black
hole (because excitations that are not freely falling must have an energy that compensates
for the gravitational potential). This energy density would act as a source term in Einstein’s
equations and therefore have a strong back-reaction on the metric. Therefore, the physical
setup of quantum ﬁelds on top of an unperturbed Schwarzchild metric can only be achieved
with the Kruskal vacuum.
82. Anderson Localization In a periodic atomic lattice, the electronic eigenfunctions take
the form of Bloch states, whose energies span continuous bands. An electron whose energy
lies in such a band can propagate freely over macroscopic distances (whether the material is a
conductor or an insulator depends on whether the Fermi energy lies inside a band or between
two bands). The goal of this problem is to show that, in a disordered medium, electrons are
localized and cannot propagate.
82.a Check thatγ0 =(100 −1),γi =( 0σ i−σi 0 ) provide a valid representation of the Dirac ma-
trices. Using this representation, show that the two upper components are the dominant
ones in the non-relativistic limit, and show that the Dirac equation becomes
i∂tφ =
(
m −eA0 − (∇ −ieA)2
2m +eB·σ2m )φ.
82.b Show that the two-point functionG(x,y ) ≡
⟨
φ(x)φ†(y)⟩ obeys a Dyson equation of
the formG = G0 +ieG0A0G in the case of a purely electric external ﬁeld.
82.c Consider a medium in which the potential A0 has local Gaussian ﬂuctuations with
a variance
⟨
A0(x)A0(y)⟩ = σδ (x − y). Write the Dyson equation satisﬁed by G
at order e2. By calculating the self-energy that appears in this equation, show that
the denominator of the dressed propagator has an imaginary part, which leads to an
exponential damping of electronic waves.


===== PDF PAGE 226 =====
348 5 LATTICE, FINITE T , STRONG FIELDS
82.a To check that the announced matrices are a valid representation of the Dirac matrices,
we must verify that {γμ,γν} = 2gμν. This is completely straightforward using the fact that
σiσj +σjσi = 2δij. With this representation in mind, we write the four-component Dirac
spinors as a combination of two two-component objects:
us(p) ≡
(
φ(p)
χ(p)
)
.
Consequently, the Dirac equation (/p −m)us(p)= 0 can be split into two separate equations
forφ andχ,
(Ep −m)φ −(p·σ)χ = 0, (Ep +m)χ −(p·σ)φ = 0,
from which we get
χ = 1Ep +m (p·σ)φ ≈p≪m p·σ2m φ.
Therefore, if we denoteφ(x) ≡ φ(p)e−ip·x, we obtain
i∂tφ(x)=
(
m + (p·σ)2
2m
)
φ(p)e−ip·x =(m − ∇2
2m
)
φ(x),
which is the non-relativistic Schr¨odinger equation (the term inm could be removed if we factor
out an explicit factore−imt from the wavefunction). Thus, we see that, in this representation,
the two upper components of a Dirac spinor obey the Schr¨odinger equation, while the two lower
components are suppressed by a power ofp/m (and in addition they are not independent).
This equation, valid for a free fermion, can be promoted to an equation for the evolution of
a non-relativistic fermion in an external electromagnetic ﬁeld by simply replacing the ordinary
derivatives by covariant ones: ∂μ → Dμ ≡ ∂μ − ieAμ. But in doing so, one should keep
in mind that ∇ and A do not commute, which imposes that we do this replacement before
eliminating the Pauli matrices:
i∂tφ =
(
m −eA0 −
(
∇ −ieA)·σ
)2
2m
)
φ
=
(
m −eA0 − (∇ −ieA)2 +e(Ai∇j +∇iAj)ϵijkσk
2m
)
φ
=
(
m −eA0 − (∇ −ieA)2
2m +eB·σ2m/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≡ H
)
φ,
where B is the external magnetic ﬁeld. From this Schr ¨odinger equation, we read the Hamilto-
nianH that drives the evolution of this fermion in the non-relativistic limit.


===== PDF PAGE 227 =====
82 ANDERSON LOCALIZATION 349
82.b When the external ﬁeld is a pure electric ﬁeld, we may choose a gauge in whichA = 0,
so that the above Hamiltonian simpliﬁes to
H = m − ∇2
2m −eA0.
Consider the time-ordered two-point correlation function of the non-relativistic ﬁeldφ,
G(x,y ) ≡
⟨
Tφ(x)φ†(y)⟩ = θ(x0 −y0)⟨φ(x)φ†(y)⟩ −θ(y0 −x0)⟨φ†(y)φ(x)⟩.
Applying a time derivative to this deﬁnition, and recalling the equal-time anti-commutator{
φ(x),φ†(y)} = δ(x−y) (this is the restriction to the two upper components of the canonical
anti-commutation relation of Dirac spinors), we obtain
(
i ∂∂x0 −H)G(x,y )= iδ (x −y).
We can also deﬁne the free correlation functionG0, deﬁned as a Green’s function of the
free Hamiltonian, H0 ≡ m − ∇22m . Since H = H0 −eA0, the equation forG can be rewrittenas follows:
(
i∂x0 −H0
)
G = iδ(x −y)− eA0G.
This can be solved formally in the form of a Dyson equation,
G = G0 +ieG0A0G.
82.c Diagrammatically, the expansion of the solution of the Dyson equation for the propaga-
tor reads
= + + + + . . . GG 0 ieA0 .
If the external potential is ﬁxed, the next step is to perform the geometrical sum contained in
this solution (which may be a rather difﬁcult task if the potentialA0 has a non-trivial spatial
dependence).
Another interesting situation is when this potential ﬂuctuates, with a probability distribution
W[A0]. In this case, the above solution must be averaged over all the conﬁgurations of A0,
weighted by the distribution W[A0]. Diagrammatically, this amounts to connecting all the
crosses in the above representation by links and vertices as allowed byW[A0]. For instance, a
random time-independent external potential with only local Gaussian ﬂuctuations would have
the following distribution:
W[A0]= exp( − 12 ∫ d3x A0(x)A0(x)2σ ),
for which the only possible connection is a link
⟨
A0(x)A0(y)⟩ = σδ (x −y).
(This is independent of time, and the delta function is a spatial one.) With such Gaussian
ﬂuctuations of the external ﬁeld, the expectation value of the propagator takes the following


===== PDF PAGE 228 =====
350 5 LATTICE, FINITE T , STRONG FIELDS
form:
= + + + + . . . 
1PI non 1PI
.
This has the form of a propagator dressed by self-energy corrections. This plain perturba-
tive expansion can be improved by calculating the self-energy at a certain order in e2 and
by re-summing its repeated insertions on the free propagator (this is a geometrical series).
When doing this, it is important to include only one-particle-irreducible contributions in
the self-energy in order to avoid double counting. If we restrict ourselves to the order- e2
self-energy, the equation for the dressed propagator is a Dyson equation that reads
= + .
This is simple algebraic equation in momentum space:
G(p)= G0(p)+ G0(p)
(
−iΣ(p)
)
G(p), i.e., G(p)= i
p0 −m − p22m −Σ(p),
and the self-energy is given by
Σ(p)=− ie2σ
∫ d4k
(2π)4 2πδ (k0) ip0 +k0 −m − (p+k)22m
= 2e2σm
∫ k2dkd cosθ
(2π)2
1
2m(p0 −m)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
≈ p2 on-shell
−p2 −k2 −2pk cosθ
=− e2σmp ∫ kdk(2π)2 ln(k +2pk −2p)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
iπθ (2p−k)+real terms
=− ie2σmp2π + real terms.
Note that the real part of the self-energy, which we have not calculated here, is ultraviolet
divergent. This could be remedied on physical grounds by noting that the inverse inter-atomic
distance should certainly act as a cutoff in this integral since the external ﬁeld is not an
uncorrelated noise on atomic scales.
However, the main result here is the fact that the self-energy has an imaginary part
proportional to the strength of the ﬂuctuations of the external ﬁeld. The physical implication
is that fermions cannot propagate in such a disordered medium, since their propagator in
coordinate space is exponentially damped. The damping length is given by the inverse of the
imaginary part ofΣ and is thus inversely proportional to the strengthσ of the ﬂuctuations of
the external ﬁeld. Moreover, this imaginary part exists at all values of the momentump, which
means that there is no energy range where electrons can propagate freely in this material. This
phenomenon, known as Anderson localization, is a very important result of solid-state physics
that implies that disordered media are insulators (unlike periodic media, which may have a
conduction band, i.e., an energy range in which the electronic states – known as Bloch states –
are completely delocalized over macroscopic sizes).


===== PDF PAGE 229 =====
83 SCALING THEORY OF ANDERSON LOCALIZATION 351
83. Scaling Theory of Anderson Localization Problem 82 corresponds to the limit of
strong disorder, in which the motion of electrons is damped regardless of the dimension of
space. The situation regarding Anderson localization is in fact richer than what is suggested
by that simple study, and depends crucially on the dimension. As we shall see, it is possible
to gain a semi-quantitative understanding of this question without considering any speciﬁc
model, by using scaling arguments and ideas inspired from the renormalization group. For this,
we consider a cubic sample of sizeL ind dimensions. We denote byg its conductance (the
inverse of its resistance), and we deﬁneβ ≡ d(lng)/d(lnL).
83.a Explain why we have the following two limits:
lim
g→0
β = ln(g), lim
g→+∞
β = d −2.
83.b Use these limits to discuss the behavior of the conductance asL →∞ . Show that there
is a qualitative difference betweend = 1,2 andd = 3.
83.a Let us consider a cubic sample of material of length L.I n d spatial dimensions, its
volume is therefore Ld and its transverse section is Ld−1. We denote by g its electrical
conductance, i.e., the inverse of its resistanceR. This parameter depends on the size L (this
is quite obvious from the fact that a thick wire conducts better than a thin one), and it is
convenient to introduce aβ function that controls its variation withL:
β(g) ≡ Ld ln(g)dL .
(The implicit assumption here is that the β function depends on the conductance, but not
explicitly on the system size. In other words, it may depend on the system size only through
the value of the conductance.)
Consider ﬁrst the limit of strong disorder, studied in Problem 82. In this limit, the
conductance goes to zero exponentially with the system size (in any dimensiond):
g ∝ e−L/ξ,
where the lengthξ is given by the inverse of the imaginary part of the self-energy calculated
in that problem. This formula follows from the fact that electrons cannot propagate beyond a
distance ξ, so the conductance is non-zero only for systems whose length is smaller than ξ.
Therefore, in this limit, we have
β(g) ≈
g→0
−Lξ = ln(g)+ const.
The opposite limit, g → +∞, is the limit of good conductors. In this situation, the
resistance of a sample of lengthL and transverse sectionA is given by
R ∝ LA = g−1L2−d,
where the unwritten prefactor is the resistivity (i.e., the inverse of the conductivity). Since
R = g−1, we obtain the following behavior for theβ function in this limit:
β(g) ≈
g→+∞
d −2.


===== PDF PAGE 230 =====
352 5 LATTICE, FINITE T , STRONG FIELDS
g
β(g)
d = 3
d = 2
d = 1
g*
Figure 5.7 Behavior of theβ function for the conductance ind = 1,2,3 dimensions. The
arrows indicate the ﬂow towards larger sizes.
83.b Assuming a monotonous behavior of theβ function between the two limits we have
considered, we obtain the curves sketched in Figure 5.7. In this ﬁgure, we show theβ functions
ind = 1,2,3 spatial dimensions. We have also indicated by arrows on the curves the direction
of the ﬂow when the size L increases (this follows directly from the sign of the β function).
Interestingly, there are qualitative differences betweend = 1,2 andd = 3:
• d = 1,2 : theβ function is always negative, implying that the conductance goes to zero
as L →∞ . Therefore, one- and two-dimensional materials become insulators when
their size becomes inﬁnite, no matter how weak the disorder is.
• d = 3: the β function vanishes at some critical value g∗, is negative for g<g ∗
and positive for g>g ∗. Moreover, this critical point is repulsive. Therefore, a
three-dimensional material with a sufﬁciently small disorder (such that g>g ∗ at a
certain scale) may be a conductor when L →∞ , while for a stronger disorder (such that
g<g ∗ at a certain scale) it becomes an insulator whenL →∞ .
Source: Abrahams, E., Anderson, P. W., Licciardello, D. C. and Ramakrishnan, T. V . (1979),
Phys Rev Lett 42: 673.


===== PDF PAGE 231 =====
Index
1PI effective action, see quantum effective
action
accelerated observer, 339
Altarelli–Parisi splitting function, 247
Anderson localization, 282, 347, 351
angular ordering, 180
anomalous dimension, 6
anomalous magnetic moment, 10, 34
antenna effect, 175
asymptotic freedom, 134, 192
axial gauge, see gauge ﬁxing
axion, 204
Baker–Campbell–Hausdorff formula, 13,
63, 77, 88, 143, 292
Banks–Casher relation, 282, 283
Banks–Zaks ﬁxed point, 136, 191
BCFW recursion, 208, 211, 215, 223, 233
Berends–Giele recursion, 210, 252
Berezin integral, see Grassmann, integral
Bernoulli numbers, 106
Berry
conjecture, 315
phase, 76, 91
β function, 6, 65, 69, 191, 351
Bethe–Heitler limit, 310
black hole radiation, see Hawking radiation
Bloch state, 200, 347
Bogoliubov transformation, 282, 331, 339
Boltzmann–Vlasov equation, 305
Bose–Einstein distribution, 278, 346
bosonization, 76, 111
BRST symmetry, 73, 134
Burnett–Kroll, see Low–Burnett–Kroll
Callan–Symanzik equation, 6
canonical ensemble, 277
Cartan–Maurer invariant, 135, 197, 199
Casimir
energy, 76, 103, 107
operator, 138, 150
causality, 18
center symmetry, 282, 293
chemical potential, 279
chiral condensate, 283
chiral symmetry, 76, 111, 277, 285
breaking, 76, 111, 283
Chudakov effect, 180
classical ﬁeld, 10, 49, 323
classical particle, 151, 282, 298, 301
coherent state, 10, 62, 63, 76, 83, 87, 335
overcompleteness, 86
spin, 76, 91, 136
Coleman–Norton, see Landau, equations
collinear divergence, 10, 22, 26, 47, 178,
211, 247


exit_code=0
```

### 2026-11-16T18:23:05.951017+08:00

```bash
rg --files planning -g '*expansion*' -g 'work-order*'
```

```text

### 2026-11-16T18:23:05.951017+08:00

```bash
cat planning/work-order-gelis-selection.md planning/work-order-radovanovic-next.md
```

```text
# Gelis 非阿贝尔场与振幅候选核读

当前任务只读评审 Problems 26、29、37、43、49、52、67。读取 `planning/source-notes/qft-gelis-all.txt` 中完整题面及解答，逐题核实 PDF 页与印刷页。需要时看用户 PDF 原页。

立即把已经完成的部分写 `planning/qft-expansion-gelis-review.md`，再逐项补齐。每项包括：准确页码、已核读范围、关键物理与公式、误读风险、原创研究任务设计、结构化产物/客观评分、独立真值路线、和其他题目的机制差异。不要把候选清单等同已经实现的题包。52 包含开始于前一页的内容，67 也须检查前后题边界。

其他题分工：主代理读5、11、24+25；另一代理读69、70、72、73、75、80、82。不要重复这些。

每条 shell 执行前展示，`tools/run_logged.py` 写 `checks/qft-expansion-gelis-command-log.md`。不要改现有 tasks，也不要跑测评。
# Gelis 有限温、格点与强场候选核读

这是主代理分配的当前子任务。只做来源评审，不修改现有题包。

读取 `planning/source-notes/qft-gelis-all.txt` 中 Problem 69、70、72、73、75、80、82 的完整题面与解答。页码以 `===== PDF PAGE N =====` 为准，逐页确认印刷页。本书扫描件章节重排，不能使用全书统一偏移。

写入 `planning/qft-expansion-gelis-thermal-review.md`。每题列：原题号与准确 PDF/印刷页范围；已完整核读范围；核心物理工作及关键关系；容易误述的边界；有研究判断的原创 benchmark 改造；结构化交付与客观评分；两条独立真值路线；相互独立性。80 是标量 QED，不是费米子 QED。70 作为增强独立性的候选，与另一本六维 phi^3 比较。

起始页线索：69 PDF161；70 PDF163；72 PDF171；73 PDF176；75 PDF183；80 PDF209；82 PDF225。以实际题目开始结束为准。必要时视觉检查原页。

每完成两题先落盘，再继续。不要等全部结束才保存。不声称未实际做过的核读、渲染或测评。所有 shell 命令执行前在 commentary 展示，用 `python3 tools/run_logged.py --log checks/qft-expansion-gelis-thermal-command-log.md -- COMMAND ...` 记录。

exit_code=0
```
planning/source-notes/qft-expansion-inventory.json
planning/work-order-sp02.md
planning/work-order-gr02.md
planning/work-order-radovanovic-next.md
planning/work-order-gr03.md
planning/qft-expansion-radovanovic-review.md
planning/work-order-ed03.md
planning/work-order-qm03.md
planning/work-order-ed02.md
planning/work-order-qm02.md
planning/work-order-qm04-tm04.md
planning/work-order-gelis-selection.md
planning/work-order-tm03.md

exit_code=0
```

### 2026-11-16T18:23:46.723670+08:00

```bash
rg --files planning -g '*expansion*review*'
```

```text
planning/qft-expansion-gelis-thermal-review.md
planning/qft-expansion-radovanovic-review.md

exit_code=0
```

### 2026-11-16T18:24:15.059143+08:00

```bash
cat planning/qft-expansion-gelis-thermal-review.md
```

```text
# Gelis：格点、有限温与强场候选核读评审

日期：2026-11-16。来源核读和原创改造设计，未封装成 Harbor 任务，未进行正式模型测评。

来源：François Gelis, *Problems in Quantum Field Theory*，用户文件 `/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256 `7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。本 PDF 有章节重排，以下页码逐页依据页标登记，不使用全书统一偏移。文本索引 `planning/source-notes/qft-gelis-all.txt`。

## Problem 69：Banks–Casher Relation

- **范围与阅读状态：** 题面 PDF161 / 书283；完整相关解答 PDF162–163 / 书284–285（止于70题开始前）。已读全部相关文本；尚未逐页视觉核对。
- **原题主要工作：** 把手征凝聚写成有限体积 Euclidean Dirac 算子逆的迹，利用 γ5 对称性配对 ±λ 本征值，得到 `⟨ψ̄ψ⟩=−lim(V→∞)∫dλ mρV(λ)/(λ²+m²)`。随后先取热力学极限，再取 `m→0+`，以 Poisson 核的分布极限得到 `Σ=−πρ(0)`。谱密度按单位四维体积、完整正负谱定义。
- **容易误述的边界：** 有限体积的离散谱不能直接在零点做平滑密度估计后声称严格自发破缺；极限顺序不能互换。精确拓扑零模会贡献 `N0/(mV)`，不能笼统假定每个有限体积背景必有严格谱隙，也不能把它与广延近零模凝聚混为一谈。原题证明在形式化连续理论层面；输入有限维谱不等于已经模拟完整 QCD。UV 发散/减除必须在改造模型中明定。
- **原创 benchmark 设计：** 给定数个体积、质量和成对本征值的可复现谱族（含非零近原点密度、伪谱隙、次广延拓扑零模三类），要求计算凝聚、识别能支持稳定手征极限的缩放窗口、区分先取 m 极限和先取 V 极限的结果，并从有明确误差模型的低谱观测反演 `ρ(0)`。可使用源自谱密度的固定生成模型，必须称“受控谱模型”，不可伪称格点 QCD 数据。要有离散低模和已知 UV 尾两部分，不能仅做直方图读值。
- **产物与客观评分：** 每个谱族输出各 `(V,m)` 的 condensate、zero_mode_contribution、finite_volume_correction、所选 scaling_window、热力学手征极限及可辨识性。数值按固定绝对/相对尺度评分，窗口由明确误差上界及覆盖性判定，不按文字偏好评分。任何满足相同精度的外推方法应等价得分。
- **两条独立真值：** ① 直接高精度成对本征值求和加解析 UV 尾；② 从设计的连续 `ρ(λ)` 独立积分并用 Euler–Maclaurin/已知谱求和式获得有限体积修正。零模项另算、极限分别取，交叉验证而不共用拟合算法。
- **独立性：** 核心是低谱密度、极限非交换与序参量，不是11.8的逐图 Goldstone 抵消，也不是一般矩阵对角化。与70同属格点相关，但任务对象及物理问题不同。
- **结论：** 优先候选；原题定理本身不够编程难，必须落实上述谱族、误差和极限判断。

## Problem 70：Nielsen–Ninomiya Theorem

- **范围与阅读状态：** 题面 PDF163–164 / 书285–286；完整解答（含 Poincaré–Hopf 证明草图和图）PDF164–168 / 书286–290，止于71题开始前。已完整核读相关文本；尚未逐页视觉核对。
- **原题主要工作：** 无限平移不变格点的动量空间是 `T⁴`，逆 Weyl 传播子由实连续周期矢量 `Fμ(p)` 构成。非退化线性零点给质量为零的费米子；每反转一个局部方向，γ 矩阵相似变换使手征翻转。非退化零点的指数与局部 Jacobian 行列式符号相联系，在四维与左/右手性相对应；Poincaré–Hopf 给总指数 `χ(T⁴)=0`，所以在这些假设下净手征数零。
- **容易误述的边界：** 结论依赖周期动量空间、局域性/足够连续性、Hermiticity、合适的 Dirac 结构和孤立非退化零点；不能写成任何格点理论都绝不可能含手征费米子。Wilson 破坏朴素手征对称性，Ginsparg–Wilson 等更改手征实现，均不能被简单“找一个零点”否定。对一般耦合 `F`，应直接用 `sign det J` 和映射度，不假定它总是全局某个势函数的梯度；简并零点要单独检测，不能硬判符号。
- **原创 benchmark 设计：** 给出有有限 Fourier 表示的周期、局域格点动量核族，含可严格枚举的基准、各向异性高次谐波、可解的三角耦合变形以及零点生成/湮灭的临界参数。要求完整找出 Brillouin 区内的零点（周期边界去重）、线性化矩阵、手征/指数和总指数，并判断哪些“单手征”候选实际有未发现的 doublers，哪些通过放弃明确假设避开了原定理。高难度来自完整性和拓扑边界，不是一次随机找根。
- **产物与客观评分：** 零点数组（坐标模2π规范化）、残差、`det J`、chirality、degenerate 标记、各参数区间物种数和净指数。评分使用周期距离的最优匹配，完整性和误判简并单独计分；不因等价坐标/排序扣分。输入族必须允许给出根完备性的证书，不能用不可保证找到所有根的私有随机算法充当真值。
- **两条独立真值：** ① 对设计的 Fourier 家族用 `t=tan(p/2)` 化为有理多项式，隔离全部实根并单独查 `p=π` 边界，以区间法验证 Jacobian 非零；② 独立解耦/同伦坐标变换解析枚举，并在各零点邻域计算映射度或数值积分包围面验证指数，检查全局和为零。临界面用结果式/解析判别条件而非把很小行列式当严格零。
- **独立性与比较：** 明显区别于 Radovanović 11.14 的六维 φ³ 局域 UV 减除，也区别于已有 QFT-01–04 的积分、相空间、RG和树图散射。若题库同含11.12和11.14导致重整化主题偏密，70更值得入选。与69共同使用“谱”概念，但70考核动量核零点的拓扑/手征障碍，69考核随机背景低谱的热力学极限。
- **结论：** 强烈推荐优先入选；需要选择可证明根完备性的动量核族，避免只靠高维随机搜索。

exit_code=0
```

### 2026-11-16T18:25:10.727317+08:00

```bash
cat planning/qft-expansion-gelis-review.md
```

```text
cat: planning/qft-expansion-gelis-review.md: No such file or directory

exit_code=1
```

### 2026-11-16T18:25:32.212260+08:00

```bash
cat planning/qft-expansion-gelis-review.md
```

```text
cat: planning/qft-expansion-gelis-review.md: No such file or directory

exit_code=1
```
