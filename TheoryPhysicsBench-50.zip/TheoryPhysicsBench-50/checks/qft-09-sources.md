# 来源与本地改造

François Gelis，*Problems in Quantum Field Theory*，原题 5。

PDF SHA256: 7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5

页码（PDF / 印刷）: [{"pdf": [34, 40], "printed": [22, 28], "role": "完整题面与解答"}]

原书工作：推导Feynman参数在壳条件和逐圈方程，找出无质量三角图两条共线支、一条软支，以Coleman–Norton图像排除伪分支。

本题具体参数、诊断与评分为本地原创改造，不归于原作者。题包不分发扫描教材。

## 材料划分与公平性

本题解决完整公开的固定实例。镜像只COPY environment/public，参考程序在solution，最终真值在tests/private。开发锚点只公开一个记录；提交物以实际数值证书独立核验，允许不同求解路线。专家参考与基线仅使用同一公开模型。
