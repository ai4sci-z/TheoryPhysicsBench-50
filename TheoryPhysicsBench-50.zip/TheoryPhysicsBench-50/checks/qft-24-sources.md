# QFT-24：完整差分碰撞核下的 LPM 响应与近似选择


来源：François Gelis, *Problems in Quantum Field Theory*, 第75题；用户PDF实际页183–190，书页305–312。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与明确调节模型

Gelis 第75题的物理核心是形成时间内多次软散射同阶，必须保留碰撞算子的差分结构。本任务要求求解其**公开有限周期横动量调节模型**，比较完整核、一次碰撞和扩散近似。它是可独立复现的受控 LPM 响应题；不把有限方形网格伪称连续旋转对称模型，也不要求从此网格宣称普适软频率指数。

取 Debye 动量单位1。每个 `cases` 指定奇数网格边长 \(M\)、间距 \(h\)，点 \(p_{ij}=h(i-M//2,j-M//2)\)，\(0\le i,j<M\)。动量差采用最短周期代表 \(r_\mu\in\{-M//2,\ldots,M//2\}\)。定义全部非零转移的权重
\[
 K_r=\frac{h^2}{(2\pi)^2}\frac1{\ell_r^2(\ell_r^2+1)},\quad \ell_r=h r,\quad K_0=0,
\qquad (Cf)_p=\sum_rK_r(f_p-f_{p-r}).
\]
`p-r` 逐坐标模 \(M\)；该有限差分核就是本题精确模型，不再插值到无穷平面或另加核截断。零转移项的差分严格为0，不能把增益和损失分成两个 IR 发散积分后独立正则化。

令 \(D_p=a(m^2+p^2)\)、\(s_p=p_x\exp[-p^2/(2w^2)]\)，其中 `a,mass,source_width` 分别为 \(a,m,w\)。求唯一复响应
\[
 (C+iD)f=s.
\]
它采用正定耗散碰撞算子和 \(a>0\) 的因果相位约定。发射泛函 \(R=h^2\sum_ps_p\operatorname{Re}f_p\)。这里的源含 Gaussian 接受窗，以保证该有限基准不受紫外源尾污染；这是本项目明确的受控扩展，不归称原书已经给出的全部光子发射率。

定义一次碰撞 Bethe–Heitler 起点：\(g=s/D\)、\(f_{BH}=-ig+D^{-1}Cg\)，\(R_{BH}=h^2\sum_pg_p(Cg)_p\)。它在碰撞相对 \(D\) 较弱时适用，不能在全部输入上直接等同完整 \(R\)。

另一个比较是二阶矩扩散核：\(d=\tfrac14\sum_rK_r\ell_r^2\)，\(C_{diff}=d(-\Delta_h)\)，其中周期五点 \(-\Delta_h f=(4f-f_{+x}-f_{-x}-f_{+y}-f_{-y})/h^2\)。解 \((C_{diff}+iD)f_{diff}=s\) 得 \(R_{diff}\)。这是对同一有限核的扩散近似，不能把它的数值当完整核真值；正号来自 \(\langle f,Cf\rangle\ge0\)。

## 必须交付

每个 case 一行 `values`：
`[R,R_BH,R/R_BH,R_diff,relative_error_diff,BH_usable,diffusion_usable,Re f_probe1,Im f_probe1,...]`。

`relative_error_diff=|R_diff-R|/R`；`BH_usable=1` 当 \(|R_{BH}-R|/R\le\)`approximation_target`，否则0；`diffusion_usable` 同理。`probes` 中索引是明确的0基网格索引，不是动量坐标。每对探针实虚部按公开顺序输出。

需要使用完整核确定发射响应与近似适用区。所有核/源/边界均公开，直接稠密线性求解、FFT、Krylov 或其他收敛方法均可。参考解使用 FFT 使碰撞卷积对角化；独立真值由显式转移矩阵构造并求解，另核查实块线性系统和正性。


## 验证路线

由对称非负K，`<f,Cf>=1/2 sum_(p,r) K_r |f_p-f_(p-r)|²>=0`。因此碰撞核扩散展开应为正的-d Laplacian；不能直接复制书中Taylor行疑似反号。

参考解使用离散Fourier变换，使C的本征值为sum K - FFT(K)。势D在动量空间是对角的，使用预条件GMRES求完整复线性系统。BH项由Neumann展开 `(C+iD)^(-1)` 到一次碰撞得到，发射率为正二次型g.C.g。扩散比较用同一核二阶矩、周期五点负Laplacian，完整核真值从不替换成扩散核。

独立真值显式计算任意两动量点间的周期转移权重，构造稠密矩阵C，再用直接复求解与2n实块求解互查，并检查全部C本征值非负。公开网格就是规定模型；改成更细网格会改变题目，不用这种变化伪称连续收敛。有限调节的连续外推及原书软频率普适标度不是本题交付项。

基线是公式明确的一次碰撞BH解，仍计算扩散比较，但用BH作为完整响应；强相干工况有明显抑制。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。
