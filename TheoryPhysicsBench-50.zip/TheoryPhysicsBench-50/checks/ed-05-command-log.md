
### 2026-11-16T16:47:12.661656+08:00

```bash
swift tools/ocr_pdf_pages.swift '/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf' 889-896
```

```text

===== PDF PAGE 889 =====
X-
（a）kd=霄
（b） kd=27
图 16.4
半波（kd= ）和全波（kd=2x）中央馈电天线的精确辐射
图梯（实曲线）跟二项多极展开（虚曲线）的比较、在半波
图样中，还画出了偶极近似（点曲线）。二项多极的结果和
精确的结果很符合，kd= 时犹为符合.
对于半波天线来说，第357页表中的系数表明：辐射功率等于简
单偶极结果（1272/ 2c）的1.00245倍、对于全波天线来说，辐射功
率等于偶极形式（3I2/c）的1.114倍.
16.8 矢量平面波的球面波展开
在讨论球形物体或一般的定域系统对电磁波的散射或吸收问
题时，将平面电磁波展开为球面波是有用的.
对于满足波动方程的标量场4（x）来说，利用基本球面解
•359•

===== PDF PAGE 890 =====
j：（ker）Yim（0，¢）的正交性可得所需的展开式.另一种推导法，是
利用格临函数（e R/4 R）的球面波展开式（16.22）、令（16.22）两
以用 （kr' 的渐近式（16.13）．于是，得到
（16.126）
消去两边的因子ehr'/r'，并取复共轭，便得到平面波的展开式：
∞
（16.127）
式中k是波矢，其球坐标是K，8'， '•我们可以运用加法定理（3.
62） 将上式写成更简洁的形式：
8
e'k:x=Z："（2+1）j （kr）P.（cosy）
（16.128）
式中 是k和x的夹角•取P：（cosy）为（3.57）的形式，可将上
式写成
eik:z=
ZiVAr(21+1)ji(lr)Yı,o(V)
（16.129）
我们现在要对沿2轴人射的圆偏振平面波作相仿的展开。这
波是
E（x） =（E1土iEz）eihs
(16.130)
由于平面波处处有限值，因而它的多极展开式（16.46）只含正规
的径向函数j：（kr），可写为
•360•

===== PDF PAGE 891 =====
E(x) = E a= (1,mm) (t).m
1,m
+20=（5,m）7x3. （kr） Xim
(16.131)
B（X）-317
ーぇ
-a=(l,m)TXj,(kr)Xim
1,m
+6+（l,m） ）.（hr）X.m］
我付可以利用矢量球浩数Xim的正交性来确定系数4土（U,m）和
b+（U,m）.我们将基本关系（16.44）和其它一些有用的关系总结
于下，以供参考：
[[S.(r)Xim]*•[g. (r)Xim]880=f79,8,10mm'
|[f.(r)Xime]*•[TX9,(r)Xim]d9=0
EEJ[VXf(7)*im]*-[PX91(7)Ximld2
(16.132)
这些关系式中f：（r）和g：（r）是满足（16.5）的球贝塞耳函数的线
性組合。利用算符恒等式（16.49）、梯度算符表式
1=ー
以及径向微分方程（16.5），可以证明上述第二个和第三个关系式.
㐧了确定系数α+（U,m）和ひょ（ん，m），我付取（16.131）的两辺
与X伽的标积，然后对角度积分：于是，利用（16.132）中第一个和
第二个正交关系，我们得到
Gx（（，m）3： （6x）= Xm・E（X）63
（16.133）
・361：

===== PDF PAGE 892 =====
和
(16.134)
用电场表式（16.130）后，（16.133）变成
e'hid2
(16.135)
式中算符L由（16.26）定义，它们的运算结果由（16.28）所确定.
于是，我们得到
a （1、m） eaas
vi（+1）
(16.136)
如果把 e*hn 的展开式（16.129）代入，则由Y.m 的正交性显然可得
下列结果：
(16.137)
由（16.134）和（16.130）可知
B（l,m）=干iC （l,m）
于是，平面波（16.130）的多极展开是
(16.138)
xj.（er）Xt
(16.139)
干i（kr）X，坦］
对于这样的圆偏振波，显然可将m的值（m=士1）解释为每个光子
在平行于传播方向上具有士1单位角动量.习题7.20和习題7.21
中已经证明了这一点•
•362•

===== PDF PAGE 893 =====
16.9 球体对电磁波的散射
如果平面电磁波入射在一个球形障碍物上，如图16.5所示，
电磁波即被散射，于是在远离散射体的地方，场是平面波和出射球
面波的叠加•障碍物除了可以引起散射外，还可以有吸收．这时，
流出障碍物的总能量要比流向障碍物的总能量少，两者之差就是
被吸收的能量.
散射波
入射波
图16.5 定城物体对辐射的散射
我们最终将讨论一个简单的例子：半径为a、电导 率为无穷
大的球的散射，但是我们暂时将问题考虑得更普遍些.
球外的场可写成入射波和散射波之和：
(16.140)
B（x）=B人射十B数射
式中E人 和B人料由（16.139）给出•因为在无穷远处的散射场是出
射波，所以它们的展开式必具有如下的形式：
（16.141）
×Hú"'(cr)Xı,+ıFiB+(1)K['(r)Xı,+1)
• 363

===== PDF PAGE 894 =====
系数αょ（い）和β土（い）由散射体表面上的辺界条件确定・从演経上：
说，（16.141）中必须对所有的m和【求和，但是这里所考虑的仅限
于球对称类问题，所以只出现 m=士1.
正如（9.184）和（9.185）所表示的那样，我们可以根据一个包
围散射体的半径a的球面上的散射场和总场，导出用系数a（l）
和B（L）表示的总散射功率和总吸收功率的正规表式。这些表式
可以写成
PxN=Ca'Re /ERN• (Mx Bin) 2S
（16.142）
PAを=SRRe （E・（日xB*）a8
(16.143)
这里n另沿径向朝外的单位法线矢量，Ew时和B收特由（16.141）給
出，而E和B 是平面波场（16.139）和散射场（16.141）之和.这些
方程只含场的横向分量．我们已经知道Xim是横向的．（16.139）
和（16.141）中另一类项是
（16.144）
式中f：是满足（16.5）的任一阶球贝塞耳函数.当将场的多极
展平式代人（16.142）和（16.143）肘、就声生X前・Ximi,Xim・
（nxX1m）和（nxXmm）・（nxXiml）的各种形式的析穂対し和じ
的双重求和.对角度积分，利用正交关系（16.132），双重求和就化
为单一求和、和中的每一项，都包含球贝塞耳函数和球贝塞耳函
数的导数之积.利用朗斯基行列式（16.15），可以消去所有贝塞耳
函数，得到下列总散射截面和总吸收截面（散射功率或吸收功率除
以入射通量c/4 ）表式：
数=2k22
5：（21+1） ［1a（1）12+18（0）127
(16.144)
•364•

===== PDF PAGE 895 =====
can=272(21+1)[2-la(1)+113-1B(1)+11] (16.115)
总截面或消光截面是 G款时和吸 之和：
（21+1） Re［a（l）+B（l）］
（16.146）
并不奇怪，这些截面表式与量子力学散射的部分波展开式极其相
像①.
计算进入一给定立体角元d92 中的辐射功率，或是等效地，取
归一化散射振幅f（9.188）的绝对值平方，都可以求得微分散射截
面．利用习题16.11（a）的结果，我们求得人射偏振为（E1土iE2）的
散射截面是
dO数射二六
dS
（16.147）
散射波通常是椭圆偏振的．只当对所有的 来说a土（U）=B土（ ）
时，它才是圆偏振的.这意味着，如果入射波是线偏振的，则散射
波是椭圆偏振的；如果入射波是非偏振的，则散射波随观测角的不
同而呈现不同程度的部分偏振.我们在第九章里已叙述了在长波
长极限下上述情况的一些例子（参看图9.6 和图 9.7）•
（16.141）中的系数8（U）和B （U）由 =a处的场的边界条件
决定．通常这要牵涉到球内的麦克斯韦方程组的解和〝=“处适
当搭配的解•但是，如果散射体是半径为。 的球，其电磁性质可以
① 我们的结果不是完全普适的.如果在（16 141）中包含对m的录和，那未散射
截面含有a（l,m）和B（L,m）的绝对值平方，并对【和m求和.总截面表式依然有效，
只要作以下替换：a（t） a（lm二士专）和B（2）一日（1.加=士专）.正质号取决于
人射波（16.130）的偏振态.取g总和G散 之差，可以导出吸收截面.
•365•

===== PDF PAGE 896 =====
用表面阻抗2.描写（就这种情况来说，球的紧内侧场的径向变化
必定比半径快得多），那末边界条件就取比较简单的形式，
Eon=2n×B
(16.148)
式中E和B是在球的紧外侧计算的．由（16.139）、（16.141）和
（16.144），我们得
Em =
和
nXB=Ei NAr(21+17(4 2a[o(j, +44(1) AM)] x.ar
式中x=kc，所有球贝塞耳函数的宗量为心、按照
（16.149）
对每一个1值、每一项Xim和每一项n×X;m来说，E四的系数与
nxB 的系数成正比，这是边界条件（16.148） 要求的•利用关系式
土（ ）+1=
cZa1
4 /2
d
-（ah23）！
(16.150)
-（ahg y）
43/2
43/
•366•

exit_code=0
```

### 2026-11-16T17:01:00.506551+08:00

```bash
swift tools/ocr_pdf_pages.swift '/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf' 896-900
```

```text

===== PDF PAGE 896 =====
用表面阻抗2.描写（就这种情况来说，球的紧内侧场的径向变化
必定比半径快得多），那末边界条件就取比较简单的形式，
Eon=2n×B
(16.148)
式中E和B是在球的紧外侧计算的．由（16.139）、（16.141）和
（16.144），我们得
Em =
和
nXB=Ei NAr(21+17(4 2a[o(j, +44(1) AM)] x.ar
式中x=kc，所有球贝塞耳函数的宗量为心、按照
（16.149）
对每一个1值、每一项Xim和每一项n×X;m来说，E四的系数与
nxB 的系数成正比，这是边界条件（16.148） 要求的•利用关系式
土（ ）+1=
cZa1
4 /2
d
-（ah23）！
(16.150)
-（ahg y）
43/2
43/
•366•

===== PDF PAGE 897 =====
意到，若用表面阻抗边界条件，则对两个圆偏振态来说，系数是相
同的.
从原则上说，当Z。给定后，所有多极系数就可以确定，因而可
以知道散射.剩下的只不过是代以数字罢了.在讨论特殊的极限
情形以前，我们先说明几点，首先，如果2。是纯虚数（无耗散），或
者如果2。＝0和2g→∞0，列［0土（い）十1］和［日土（い）＋1］是模数光1
的数・送意味着，＆土（い）和8土（り）可以写労
&：（）=（82181-1）， B2（l）=（e216-1）
（16.151）
式中相角8、和8叫做散射相移.特别是，如果Z。=0（理想导电
球），则
tgd. =j.（kc）/n：（ka）
[d
(16.152)
6882=
d
ae（am， （2））
しょニzの
而当Z。~∞时，8，<20
第二点要说明的是，在低频极限和高频极限下，（16.150）可以
简化•当ha《时，我们可以按（16.12）取球贝塞耳函数的近似
式。于是，我们求得长波长近似：
-2i (k0) 21+1
e： （0）=（21+5）1（26-1）1171
2-8（2+1）228
4Jt
(16.153)
而日（い的形式与α土（い）相同，但（CZg/47）用其倒数代替・当 kca
≥1时，我们利用（16.13）而得
cLe-1
＆上（りニ
(16.154)
cZs+1
4T
• 367°

===== PDF PAGE 898 =====
同时通过代换“2
cZs
与2。的实际值无关，当1增加时，散射系数 （L）、B土（L）很快地
变小•通常，对每一多极级数来说，只需保留最低阶项（L=1）.
在相反的Ra》1的极限下，（16.154）表明：当《ka时，逐项系数
的大小大抵相当，但在很宽范围内有位相涨落．当1~max= a时，
有一个过渡区域，而当》Unax时，（16.153）成立•对于这样大的
项数来说，用部分波或多极展开是一件棘手的事情，必须使用电子
数字计算机，或用9.13 节里讨论的那种类型的一些近似方法•
我们现在专门来讨论理想导电球（Z.=0）的长波长极限（ka《
1），并将一些稍复杂的实例留作习题．在（16.147）中只有1=1的
项才是重要的•由（16.153），我们求得
a：（1）=号2 0（1）≥-警（ka）
在这种极限下，散射截面是
(16.155)
根据第343页上的表，我们得到绝对值平方项为
|mxX1=1X11=1Ổ(1+003-0)
(16.156)
我们可以容易地算出交叉项：
[ti(x X.1)*•X,+1]=330030
(16.157)
于是，微分散射截面的长波长极限是
「a（ +〇08°0） 〇00］
(16.158)
与入射波的偏振态无关.散射波的角分布如图16.6所示，这是与
图9.7等效的极坐标图。散射主要是向后散射，对90°的明显不
对称性是由电偶极-磁偶极干涉项所引起的.
•368．

===== PDF PAGE 899 =====
长波长极限下的总截面是
10л c (ka)$
（16.159）
这个著名结果是米（Mie）氏和德
拜最先得到的（1908—1909年），
并在9.6节（c）段里，已经用不同
的观点讨论过.
当ka 不是很小时，具有任意
电磁性质的球体对电磁波的散射
的一般问题是复杂的.在1908至
1909年间，米氏和德拜最先系统
图16.6 在长波长极限情况（ka《
地研究了这个问题．现在已经发
1）下，理想导电球对电磁
表了数百篇论文讨论这一课题.
波散射的角分布.
有关这个重要问题的许多方面的详细论述可以在下列三本书中找
Il: Kerker; King and Wu; Bowman, Senior, and Uslenghi.
也可以在本章末援引的其它书籍中找到.Bowman, Senior,and
Uslenghi这本书除了球体以外还讨论了其它规则形状物体的散
射.
对于球、圆柱等以外的散射体来说，正统的理论很少．最近已
经取得了一些令人感兴趣的进展，即普塞耳（Purcell）和潘尼派克
（Pennypacker）所发展的近似方法，在此近似方法中，用一个由基
本偶极散射体组成的粗粒点阵列，来代替一个具有任意电磁性质、
任意形状的散射体，这些基本偶极散射体的性质能使任意形状散
射体的诸性质重现.使用高速电子数字计算机，采用数值计算方
法，求得了“散射体”内外场的自治解.第九章末的推荐读物中援
引了这项工作.
• 369

===== PDF PAGE 900 =====
16.10 多极场的边值问题
导电球对电磁波的散射是多极场边值问题的一个例子，其它
的例子是，导电球的自由振荡、球形谐振腔以及电介质球的散射.
导体中可能出现的电阻损失，加上诸如谐振腔的Q值和吸收截面
（已经提到过）等问题，有待进一步讨论•处理这些问题的一般方
法与16.9节和第八章里用过的相同.本章里已经阐明了必要的
数学工具.我们将把这些例子的讨论留作本章末的习题.
参考书和推荐读物
透彻讨论了关量球谐函数和多极矢量场理论的书有：
Blatt and Weisskopf， 附录 B；
Morse and Feshbach, 13.3节.
在下列著作中论述了在原子核多极辐射方面的应用：
Blatt and Weisskopf，第十二章；
Siegbahn，第十三章（S.A.Moszkowski 撰写）和第十六章（I）（M.
Goldhaber 和 A. W. Sunyar 撰写）.
第九章末援引了若于论述天线和散射的书精.但是，其中没有一本书用
严密的方法讨论多极展开的问题.
简要地论述了理想导电球对电磁波的散射的书有：
Morse and Feshbach， 第1882 页至第1886页；
Panofsky and phillips, 12.9节.
下列两书作了更精辟的讨论，所讨论的球体具有任意的介电性质和导电
性质：
Born and Wolf, 13.5 节s
Stratton, 9.25 节.
关于球贝塞耳函数等的数学知识，可参看
Morse and Feshbach，第1573页至第1576 页.
16.9节末已经援引了有关散射的其它参考书。
•370.

exit_code=0
```

### 2026-11-16T17:11:04.439352+08:00

```bash
sh -lc 'mkdir -p checks/ed-05-source-pages && pdfinfo "/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf" | head -20 && pdftotext -f 893 -l 900 -layout "/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf" -'
```

```text
Title:           
Author:          Hongru Ma
Creator:         Acrobat 10.0
Producer:        Acrobat 10.0
CreationDate:    Fri Mar  2 20:58:01 2018 CST
ModDate:         Fri Mar  2 20:58:01 2018 CST
Custom Metadata: no
Metadata Stream: yes
Tagged:          no
UserProperties:  no
Suspects:        no
Form:            none
JavaScript:      no
Pages:           967
Encrypted:       no
Page size:       596 x 842 pts (A4)
Page rot:        0
File size:       29971328 bytes
Optimized:       yes
PDF version:     1.6
sh: pdftotext: command not found

exit_code=127
```

### 2026-11-16T17:11:18.748959+08:00

```bash
sh -lc 'command -v pdftoppm || true; python3 -c "import pypdf; print(pypdf.__version__)"; python3 -c "from pypdf import PdfReader; p=\"/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf\"; r=PdfReader(p); print(\"pages\",len(r.pages)); [(print(\"\\nPAGE\",n),print((r.pages[n-1].extract_text() or \"\")[:9000])) for n in range(893,901)]"'
```

```text
/Users/ai4s/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/pdftoppm
6.21.2
pages 967

PAGE 893


PAGE 894


PAGE 895


PAGE 896


PAGE 897


PAGE 898


PAGE 899


PAGE 900


exit_code=0
```

### 2026-11-16T17:11:30.424937+08:00

```bash
sh -lc 'pdftoppm -f 897 -l 899 -png -r 150 "/Users/ai4s/Downloads/经典电动力学（杰克逊）.pdf" checks/ed-05-source-pages/jackson >/dev/null 2>&1 && ls -lh checks/ed-05-source-pages'
```

```text
total 608
-rw-r--r--@ 1 ai4s  staff    88K Nov 16 17:11 jackson-897.png
-rw-r--r--@ 1 ai4s  staff   105K Nov 16 17:11 jackson-898.png
-rw-r--r--@ 1 ai4s  staff   106K Nov 16 17:11 jackson-899.png

exit_code=0
```

### 2026-11-16T17:12:01.711825+08:00

```bash
python3 -c 'from pathlib import Path; import json; fs=["tasks/ed-02/task.toml","tasks/ed-02/environment/public/start.py","tasks/ed-02/environment/public/physics.py","tasks/ed-02/environment/public/feedback.py","tasks/ed-02/solution/solve.py","tasks/ed-02/solution/README.md","tasks/ed-02/tests/score.py","tasks/ed-02/tests/metric.json","tasks/ed-02/tests/test.sh","tasks/ed-05"]; [(print("\nPATH:",f),print(Path(f).read_text() if Path(f).is_file() else sorted(str(p) for p in Path(f).rglob("*")))) for f in fs]; print("\nDOCKERFILES", [str(x) for x in Path("tasks").glob("ed-*/environment/Dockerfile")])'
```

```text

PATH: tasks/ed-02/task.toml
schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/ed-02"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 1200.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "no-network"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0


PATH: tasks/ed-02/environment/public/start.py
"""Public simple starting point for the finite-wire inverse problem."""
import json
import math
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares


def pattern(u, mu):
    mu=np.asarray(mu,dtype=float)
    numerator=(np.cos(u*mu)-math.cos(u))**2
    return np.divide(numerator,1-mu*mu,out=np.zeros_like(mu),where=abs(mu)<1)


def main():
    root=Path('/app/data');model=json.loads((root/'model.json').read_text(encoding='utf-8'));cases=[]
    for case in model['cases']:
        mu=np.array(case['mu']);observed=np.array(case['intensity'])
        def values(u):return pattern(u,mu)
        start=math.pi/2
        initial=float(np.dot(values(start),observed)/np.dot(values(start),values(start)))
        fit=least_squares(lambda x:x[1]*values(x[0])-observed,[start,initial],bounds=([model['u_range'][0],1e-6],[model['u_range'][1],1e6]),max_nfev=300)
        u,scale=map(float,fit.x);central=float(values(u)[len(values(u))//2])
        cases.append({'id':case['id'],'u':u,'scale':scale,'power_integral':4*central/3,'directivity':1.5,'lobes':[{'mu':0.0,'height':central}]})
    answer={'cases':cases,'method':'public half-wave local fit and dipole angular starting point'}
    out=Path('/app/output/answer.json');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(answer,ensure_ascii=False))


if __name__=='__main__':main()


PATH: tasks/ed-02/environment/public/physics.py
"""Public forward antenna model and schema; no private inverse labels."""
import json
import math
from pathlib import Path
import numpy as np


def load_model(root="/app/data"):
    return json.loads((Path(root)/"model.json").read_text(encoding="utf-8"))


def pattern(u, mu):
    mu=np.asarray(mu,dtype=float)
    # Product identity avoids subtracting two nearly equal cosines.
    amplitude=2*np.sin(u*(1+mu)/2)*np.sin(u*(1-mu)/2)
    result=np.divide(amplitude*amplitude,1-mu*mu,out=np.zeros_like(mu),where=abs(mu)<1)
    return float(result) if result.ndim==0 else result


def fitting_residual(case,u,scale):
    values=scale*pattern(u,np.array(case["mu"]))
    observed=np.array(case["intensity"])
    return float(np.linalg.norm(values-observed)/np.linalg.norm(observed))


def finite(value):
    try:return type(value) in (int,float) and math.isfinite(value)
    except OverflowError:return False


def validate_answer(answer,model):
    if not isinstance(answer,dict) or not isinstance(answer.get("cases"),list):return None,"须提交 cases 数组"
    ids={case["id"] for case in model["cases"]}
    if len(answer["cases"])!=len(ids):return None,"每个公开工况须恰好一项"
    mapped={}
    for case in answer["cases"]:
        if not isinstance(case,dict) or type(case.get("id")) is not str or case["id"] not in ids or case["id"] in mapped:return None,"未知或重复工况 id"
        for key in ("u","scale","power_integral","directivity"):
            if not finite(case.get(key)) or case[key]<=0:return None,f"{key} 必须为有限正数"
        if not model["u_range"][0]<=case["u"]<=model["u_range"][1]:return None,"u 超出公开搜索区间"
        lobes=case.get("lobes")
        if not isinstance(lobes,list) or not 1<=len(lobes)<=12:return None,"lobes 须为1至12项数组"
        for lobe in lobes:
            if not isinstance(lobe,dict) or not finite(lobe.get("mu")) or not 0<=lobe["mu"]<1:return None,"lobe.mu 须位于[0,1)"
            if not finite(lobe.get("height")) or lobe["height"]<=0:return None,"lobe.height 须为有限正数"
        mapped[case["id"]]=case
    return mapped,None


PATH: tasks/ed-02/environment/public/feedback.py
import argparse
import json
from pathlib import Path
from physics import fitting_residual,load_model,validate_answer


def main():
    parser=argparse.ArgumentParser();parser.add_argument("answer",type=Path);args=parser.parse_args()
    try:answer=json.loads(args.answer.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):print(json.dumps({"valid":False,"reason":"没有有效JSON"},ensure_ascii=False));return
    model=load_model(Path(__file__).parent);mapped,reason=validate_answer(answer,model)
    if reason:print(json.dumps({"valid":False,"reason":reason},ensure_ascii=False));return
    print(json.dumps({"valid":True,"cases":[{"id":case["id"],"relative_angular_sample_residual":fitting_residual(case,mapped[case["id"]]["u"],mapped[case["id"]]["scale"])} for case in model["cases"]]},ensure_ascii=False,indent=2))


if __name__=="__main__":main()


PATH: tasks/ed-02/solution/solve.py
import argparse
import json
from pathlib import Path
from solver_core import solve_case


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--data-root",type=Path,default=Path("/app/data"));parser.add_argument("--output",type=Path,default=Path("/app/output/answer.json"));args=parser.parse_args()
    model=json.loads((args.data_root/"model.json").read_text(encoding="utf-8"))
    answer={"cases":[solve_case(case,model["u_range"]) for case in model["cases"]],"method":"global variable projection; full sinusoidal-current pattern and node-separated lobe search"}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print(json.dumps(answer,ensure_ascii=False))


if __name__=="__main__":main()


PATH: tasks/ed-02/solution/README.md
# 参考解：有限长直天线角谱的全局反演与完整瓣枚举

## 原书模型与无量纲约定

Jackson 用户提供中文版 §9.4，原PDF第448-449页（书内443-444页）式(9.53)-(9.57)规定
\[
J_z(z')=I\sin(kd/2-k|z'|),\quad |z'|<d/2,
\]
以及远区角分布
\[
\frac{dP}{d\Omega}=\frac{I^2}{2\pi c}
\left[\frac{\cos((kd/2)\cos\theta)-\cos(kd/2)}{\sin\theta}\right]^2.
\]
这是**规定电流近似**，不把它当作任意真实天线的自洽电流解；原书在下一段也明确指出电流假定的局限性。令 u=kd/2、μ=cosθ，得到公开方向图 G。总功率为
\(P=(I^2/c)\int_{-1}^1G_u(\mu)d\mu\)，因此 H 的定义不含2π或电流尺度。方向性是最大单位立体角功率除以平均单位立体角功率，即 D=2Gmax/H。

## 角谱反演

公开观测 (y_j=Sg_j(u))，其中 (g_j(u)=G_u(\mu_j)\)。对每个给定u，正尺度有解析最小二乘解
\[
S_*(u)=\frac{\sum_jg_j(u)y_j}{\sum_jg_j(u)^2}.
\]
于是二参数逆问题化为闭区间内一维投影目标
\(R(u)=\|S_*(u)g(u)-y\|_2^2/\|y\|_2^2\)。角谱的相干振荡使R有多个局部极小值，单一半波起点未必找到正确分支。参考程序在整个公开区间的6001点网格上定位所有离散局部极小区域，在各小区间作有界极小化，并比较两端点；选全局最优候选后，做联合最小二乘数值精化。所有材料来自公开角谱，没有读取私有参数。

数值稳定计算用
\[
\cos(u\mu)-\cos u
=2\sin\frac{u(1+\mu)}2\sin\frac{u(1-\mu)}2,
\]
避免接近轴向时减去两个近等余弦。μ=±1处方向图的连续极限为0。

## 所有辐射瓣的完整性

零点满足 \(u\mu=\pm u+2\pi n\)。列出(0,1)内所有这类根，并加0、1分割半球。每个不含零点的区间内设
\[
f(\mu)=\tfrac12\log G_u(\mu)
=\log\left|2\sin\frac{u(1+\mu)}2\sin\frac{u(1-\mu)}2\right|
-\tfrac12\log(1-\mu^2).
\]
导数为
\[
f'(\mu)=\frac u2\cot\frac{u(1+\mu)}2
-\frac u2\cot\frac{u(1-\mu)}2
+\frac{\mu}{1-\mu^2}.
\]
进一步
\[
f''=-\frac{u^2}4\left[\csc^2\frac{u(1+\mu)}2+\csc^2\frac{u(1-\mu)}2\right]
+\frac{1+\mu^2}{(1-\mu^2)^2}<0.
\]
最后一个不等号可由 \(|\sin t|\le|t|\) 得到：方括号项乘u²/4不小于
\(1/(1+\mu)^2+1/(1-\mu)^2=2(1+\mu^2)/(1-\mu^2)^2\)。所以f'在每个零点之间严格递减。中心区间的f'(0)=0，μ=0为唯一中心瓣极大；每个正μ的零点间隔内f'由正无穷到负无穷，末区间在μ→1时也趋负无穷，故恰有一个极大值。参考程序因此对每个正区间只解一个 f'=0 方程，既不漏瓣，也不把零点计作瓣。

对全部节点分段积分H，再从所有瓣峰高取Gmax。六工况的半球瓣数为1、1、2、3、3、4。

## 简单基线

基线从熟悉的半波电长度u=π/2开始做一次有边界的局部拟合，再用保持中心强度的偶极近似 \(G\approx G_u(0)(1-\mu^2)\)，得到H≈4G(0)/3、D≈3/2及单中心瓣。该方法保留正确前向方程，并在小u时一致，但不能正确处理高电长度的多分支逆问题和旁瓣。

## 独立真值

65位mpmath实现不导入参考核心。它直接算原书远场电流积分
\[
A(u,\mu)=2\int_0^u\sin(u-s)\cos(\mu s)\,ds,
\quad G=(1-\mu^2)A^2/4,
\]
独立核对公开数据与每个峰高。极值使用原始余弦分子方程
\[-u\sin(u\mu)(1-\mu^2)+\mu[\cos(u\mu)-\cos u]=0,\]
按解析零点分段高精度二分。总功率分别在μ和θ变量积分核对雅可比。最大交叉差约6.4e-65，最大极值残差约3.6e-54。Linux参考原始误差约9.81e-14百分点，朴素基线57.4345百分点。

运行：`/solution/solve.sh`。公开起点可通过 `/app/data/start.py` 运行，正式题包只向Agent公开起点而非本完整参考程序。


PATH: tasks/ed-02/tests/score.py
import json
import os
from pathlib import Path
import sys
import numpy as np
from scipy.optimize import linear_sum_assignment
from quality_score import quality_score


def evaluate(answer,data_root=None,private_root=None):
    data=Path(data_root or os.environ.get("TASK_DATA_ROOT","/app/data"));private=Path(private_root or os.environ.get("TASK_PRIVATE_ROOT","/tests/private"))
    sys.path.insert(0,str(data))
    from physics import load_model,validate_answer
    model=load_model(data);mapped,reason=validate_answer(answer,model)
    if reason:return None,{"reason":reason}
    truth=json.loads((private/"truth.json").read_text(encoding="utf-8"));details=[]
    config=model["scoring"]
    for expected in truth["cases"]:
        actual=mapped[expected["id"]]
        errors={key:min(1.,abs(actual[key]-expected[key])/abs(expected[key])) for key in ("u","scale","power_integral","directivity")}
        n=max(len(actual["lobes"]),len(expected["lobes"]));cost=np.ones((n,n))
        for i,p in enumerate(actual["lobes"]):
            for j,q in enumerate(expected["lobes"]):
                pos=min(1.,abs(p["mu"]-q["mu"])/config["lobe_mu_scale"])
                height=min(1.,abs(p["height"]-q["height"])/max(abs(q["height"]),config["lobe_height_floor"]))
                cost[i,j]=0.6*pos+0.4*height
        rows,cols=linear_sum_assignment(cost)
        errors["lobes"]=float(cost[rows,cols].sum()/n)
        raw=100*(config["u_weight"]*errors["u"]+config["scale_weight"]*errors["scale"]+config["power_weight"]*errors["power_integral"]+config["directivity_weight"]*errors["directivity"]+config["lobes_weight"]*errors["lobes"])
        details.append({"id":expected["id"],"errors":errors,"submitted_lobes":len(actual["lobes"]),"expected_lobes":len(expected["lobes"]),"raw_metric":raw})
    return sum(case["raw_metric"] for case in details)/len(details),{"cases":details}


def main():
    logs=Path(os.environ.get("VERIFIER_LOG_ROOT","/logs/verifier"));logs.mkdir(parents=True,exist_ok=True)
    tests=Path(os.environ.get("TASK_TESTS_ROOT","/tests"));output=Path(os.environ.get("TASK_ANSWER_PATH","/app/output/answer.json"))
    metric=json.loads((tests/"metric.json").read_text(encoding="utf-8"))
    try:answer=json.loads(output.read_text(encoding="utf-8"))
    except (OSError,UnicodeError,json.JSONDecodeError):raw,details=None,{"reason":"没有有效JSON产物"}
    else:raw,details=evaluate(answer)
    status="invalid" if raw is None else "completed";score=quality_score(metric,raw,status)
    details.update(raw_metric=raw,score=score,status=status)
    (logs/"metrics.json").write_text(json.dumps(details,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");(logs/"reward.txt").write_text(f"{score}\n",encoding="utf-8")


if __name__=="__main__":main()


PATH: tasks/ed-02/tests/metric.json
{
  "kind": "continuous",
  "metric_name": "角谱反演与有限长天线多瓣辐射误差",
  "unit": "百分点",
  "direction": "minimize",
  "baseline": 57.43447796201397,
  "reference": 9.806995042351381e-14,
  "tolerance": 1e-06
}


PATH: tasks/ed-02/tests/test.sh
#!/bin/bash
set -euo pipefail
python3 "$(dirname -- "$0")/score.py"


PATH: tasks/ed-05
[]

DOCKERFILES ['tasks/ed-01/environment/Dockerfile', 'tasks/ed-03/environment/Dockerfile', 'tasks/ed-04/environment/Dockerfile', 'tasks/ed-02/environment/Dockerfile']

exit_code=0
```

### 2026-11-16T17:12:47.624058+08:00

```bash
python3 -c 'from pathlib import Path; fs=["tasks/ed-04/environment/Dockerfile","tasks/ed-04/tests/quality_score.py","tasks/ed-04/tests/metric.json","tasks/ed-04/solution/baseline.py","tasks/ed-04/solution/solver_core.py","tasks/ed-04/tests/private/truth.json","tools/build_ed04_truth.py"]; [(print("\nFILE:",f),print(Path(f).read_text())) for f in fs]'
```

```text

FILE: tasks/ed-04/environment/Dockerfile
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2

COPY requirements.txt /tmp/requirements.txt
RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
 && useradd --uid 1000 --create-home student \
 && mkdir -p /app/data /app/output \
 && chown -R student:student /app

COPY public/ /app/data/
WORKDIR /app
USER student


FILE: tasks/ed-04/tests/quality_score.py
"""课程统一质量分：简单基线0、专家参考1，逐次换算后取平均。"""
import math

VALID_FAILURES = {"invalid", "agent_error", "timeout"}


def finite_number(value, name):
    if type(value) not in (int, float):
        raise ValueError(f"{name}须为有限数值")
    try:
        result = float(value)
    except OverflowError as exc:
        raise ValueError(f"{name}须为有限数值") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name}须为有限数值")
    return result


def validate_metric(metric):
    if metric.get("kind") == "binary":
        baseline = finite_number(metric.get("baseline"), "baseline")
        reference = finite_number(metric.get("reference"), "reference")
        if baseline != 0 or reference != 1:
            raise ValueError("二元题须实测简单基线0、参考解1，否则不构成有效的参考提升")
        return
    if metric.get("kind") != "continuous":
        raise ValueError("kind须为binary或continuous")
    direction = metric.get("direction")
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction须为maximize或minimize")
    baseline = finite_number(metric.get("baseline"), "baseline")
    reference = finite_number(metric.get("reference"), "reference")
    tolerance = finite_number(metric.get("tolerance"), "tolerance")
    if tolerance < 0:
        raise ValueError("原始指标容差不能为负")
    improvement = reference - baseline if direction == "maximize" else baseline - reference
    if not math.isfinite(improvement) or improvement <= tolerance:
        raise ValueError("参考解相对基线的改善须超过原始指标容差；请先核查设置")


def quality_score(metric, raw_metric, status="completed"):
    validate_metric(metric)
    if status in VALID_FAILURES:
        return 0.0
    if status != "completed":
        raise ValueError("基础设施或评分器故障不能填0；请先处理并补跑")
    value = finite_number(raw_metric, "raw_metric")
    if metric["kind"] == "binary":
        if value not in {0.0, 1.0}:
            raise ValueError("二元任务的实测结果须为0或1")
        return value
    baseline = float(metric["baseline"])
    reference = float(metric["reference"])
    fraction = (value - baseline) / (reference - baseline)
    return max(0.0, min(1.0, fraction))


FILE: tasks/ed-04/tests/metric.json
{
  "kind": "continuous",
  "metric_name": "相对论辐射总功率与前向能量锥误差",
  "unit": "百分点",
  "direction": "minimize",
  "baseline": 26.109281722028477,
  "reference": 3.913911249553121e-10,
  "tolerance": 1e-06
}


FILE: tasks/ed-04/solution/baseline.py
"""Fixed 64-node angular quadrature, using physically correct source-time density."""
import argparse
import json
import math
from pathlib import Path
import numpy as np


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',type=Path,default=Path('/app/data'));parser.add_argument('--output',type=Path,default=Path('/app/output/answer.json'));args=parser.parse_args()
    model=json.loads((args.data_root/'model.json').read_text(encoding='utf-8'));mu,weights=np.polynomial.legendre.leggauss(64);cases=[]
    for case in model['cases']:
        b=case['beta'];c,s=math.cos(case['chi']),math.sin(case['chi']);d=1-b*mu
        numerator=c*c*(1-mu*mu)+s*s*(d*d-(1-b*b)*(1-mu*mu)/2)
        mass=weights*numerator/d**5;total=mass.sum()
        cumulative=np.cumsum(mass[::-1])/total;reverse=mu[::-1]
        angles={f'theta{int(100*f)}':math.acos(float(np.interp(f,cumulative,reverse))) for f in (.5,.9)}
        gamma=1/math.sqrt((1-b)*(1+b))
        cases.append({'id':case['id'],'power':float(total/2),**angles,'cone_fraction':float(mass[mu>=math.cos(1/gamma)].sum()/total),'mean_cosine':float(np.dot(mass,mu)/total)})
    answer={'cases':cases,'method':'fixed 64-node Gauss-Legendre quadrature and discrete angular CDF'}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(answer,ensure_ascii=False))


if __name__=='__main__':main()


FILE: tasks/ed-04/solution/solver_core.py
"""Smooth aberration coordinate eliminates the ultra-relativistic endpoint peak."""
import math
from scipy.optimize import brentq


def solve_case(case):
    b=case['beta'];delta=(1-b)*(1+b);c=math.cos(case['chi']);s=math.sin(case['chi'])
    a=c*c/delta;d=s*s/2
    def primitive(t):return a*(t-t**3/3+b*(t*t/2-t**4/4))+d*(t+t**3/3+b*(t*t/2+t**4/4))
    total=primitive(1)-primitive(-1)
    def cdf(t):return (primitive(1)-primitive(t))/total
    def angle(t):
        return 2*math.atan(math.sqrt((1-b)*(1-t)/((1+b)*(1+t))))
    angles={f'theta{int(100*fraction)}':angle(brentq(lambda t:cdf(t)-fraction,-1,1,xtol=1e-14)) for fraction in (.5,.9)}
    gamma=1/math.sqrt(delta);ratio=math.tan(1/(2*gamma))**2;aberration=(1-b)/(1+b)
    t=(aberration-ratio)/(aberration+ratio)
    return {'id':case['id'],'power':total/(2*delta**2),**angles,'cone_fraction':max(0.,min(1.,cdf(t))),'mean_cosine':b}


FILE: tasks/ed-04/tests/private/truth.json
{
  "cases": [
    {
      "id": "radiation-01",
      "power": 0.6666666666666666,
      "theta50": 1.5707963267948966,
      "theta90": 2.327577069862817,
      "cone_fraction": 0.17007170634450103,
      "mean_cosine": 0.0
    },
    {
      "id": "radiation-02",
      "power": 2.5431315104166665,
      "theta50": 0.8158383671982572,
      "theta90": 1.4046292226144341,
      "cone_fraction": 0.4828928893538159,
      "mean_cosine": 0.6
    },
    {
      "id": "radiation-03",
      "power": 18.467220683287167,
      "theta50": 0.26208001977909967,
      "theta90": 0.7268209904183024,
      "cone_fraction": 0.7396841971772705,
      "mean_cosine": 0.9
    },
    {
      "id": "radiation-04",
      "power": 84595.93828675544,
      "theta50": 0.1124580417262406,
      "theta90": 0.20652362020220882,
      "cone_fraction": 0.6831066363040901,
      "mean_cosine": 0.99
    },
    {
      "id": "radiation-05",
      "power": 22411.578950618696,
      "theta50": 0.11103582797163236,
      "theta90": 0.20670819918003616,
      "cone_fraction": 0.6884063238030728,
      "mean_cosine": 0.99
    },
    {
      "id": "radiation-06",
      "power": 16668333.458341667,
      "theta50": 0.007782196558278863,
      "theta90": 0.020955839761792935,
      "cone_fraction": 0.7812093740833087,
      "mean_cosine": 0.9999
    },
    {
      "id": "radiation-07",
      "power": 4.166681250014583e+16,
      "theta50": 0.001120662354754499,
      "theta90": 0.0020593736360306108,
      "cone_fraction": 0.6874997499994104,
      "mean_cosine": 0.999999
    }
  ]
}


FILE: tools/build_ed04_truth.py
"""65-digit source-time radiation truth; rational and direct angle integrals."""
import json
from pathlib import Path
import time
import mpmath as mp

ROOT=Path(__file__).resolve().parents[1];TASK=ROOT/'tasks/ed-04'


def main():
    started=time.perf_counter();mp.mp.dps=65
    model=json.loads((TASK/'environment/public/model.json').read_text(encoding='utf-8'))
    truth={'cases':[]};cross=[]
    for case in model['cases']:
        b=mp.mpf(str(case['beta']));chi=mp.mpf(str(case['chi']));c,s=mp.cos(chi),mp.sin(chi);delta=1-b*b
        def density(mu):
            d=1-b*mu
            return (c*c*(1-mu*mu)+s*s*(d*d-delta*(1-mu*mu)/2))/d**5
        if b:
            factor=(c*c-s*s*delta/2)/(b*b)
            coefficients=[-factor*delta,2*factor,s*s-factor]
            def primitive(y):return sum(coefficients[n]*y**(n-4)/(n-4) for n in range(3))
            def cone(theta):return (primitive(1-b*mp.cos(theta))-primitive(1-b))/b
            def momentum_primitive(y):
                return sum(coefficients[n]*(y**(n-4)/(n-4)-y**(n-3)/(n-3)) for n in range(3))/(b*b)
            momentum=momentum_primitive(1+b)-momentum_primitive(1-b)
        else:
            def cone(theta):return mp.quad(density,[mp.cos(theta),1])
            momentum=mp.quad(lambda mu:mu*density(mu),[-1,0,1])
        total=cone(mp.pi)
        # Direct theta integral has a different measure and no rational primitive.
        gamma=1/mp.sqrt(delta);angle_cuts=sorted(set([mp.mpf(0),1/gamma,min(4/gamma,mp.pi),mp.pi]))
        integrated=mp.quad(lambda theta:density(mp.cos(theta))*mp.sin(theta),angle_cuts)
        expected=mp.mpf(4)/3*(c*c/delta**3+s*s/delta**2)
        def angle_for(fraction):
            a=mp.mpf(0);z=mp.pi
            for _ in range(205):
                mid=(a+z)/2
                if cone(mid)/total<fraction:a=mid
                else:z=mid
            return (a+z)/2
        angles={f'theta{int(100*fraction)}':angle_for(fraction) for fraction in (mp.mpf('.5'),mp.mpf('.9'))}
        truth['cases'].append({'id':case['id'],'power':float(total/2),**{k:float(v) for k,v in angles.items()},'cone_fraction':float(cone(1/gamma)/total),'mean_cosine':float(momentum/total)})
        cross.append({'id':case['id'],'direct_theta_relative_difference':str(abs(integrated-total)/total),'lienard_relative_difference':str(abs(expected-total)/total),'momentum_difference':str(abs(momentum/total-b))})
        print(case['id'],cross[-1],flush=True)
    (TASK/'tests/private/truth.json').write_text(json.dumps(truth,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    checks={'direct_theta_matches_rational_integral':all(mp.mpf(c['direct_theta_relative_difference'])<mp.mpf('1e-45') for c in cross),'lienard_identity_matches':all(mp.mpf(c['lienard_relative_difference'])<mp.mpf('1e-45') for c in cross),'radiation_momentum_matches':all(mp.mpf(c['momentum_difference'])<mp.mpf('1e-45') for c in cross)}
    report={'precision_digits':65,'method':'independent original source-time angular density; rational primitive in 1-beta*mu; direct theta quadrature and Lienard checks','cross_checks':cross,'checks':checks,'elapsed_seconds':time.perf_counter()-started}
    (ROOT/'checks/ed-04-truth-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
    if not all(checks.values()):raise SystemExit('ed-04 truth checks failed')


if __name__=='__main__':main()


exit_code=0
```

### 2026-11-16T17:20:47.391042+08:00

```bash
python3 -c 'from pathlib import Path; import shutil; t=Path("tasks/ed-05"); shutil.copyfile("tools/course_quality_score.py",t/"tests/quality_score.py"); shutil.copyfile(t/"environment/public/start.py",t/"solution/baseline.py"); [(p.chmod(0o755)) for p in [t/"solution/solve.sh",t/"tests/test.sh"]]'
```

```text

exit_code=0
```

### 2026-11-16T17:20:47.481087+08:00

```bash
docker build -t theory-physics-ed05:dev tasks/ed-05/environment
```

```text
#0 building with "desktop-linux" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile: 460B done
#1 DONE 0.0s

#2 [internal] load metadata for mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#2 DONE 0.0s

#3 [internal] load .dockerignore
#3 transferring context: 2B done
#3 DONE 0.0s

#4 [1/5] FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#4 resolve mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2 done
#4 DONE 0.0s

#5 [internal] load build context
#5 transferring context: 9.43kB done
#5 DONE 0.0s

#6 [2/5] COPY requirements.txt /tmp/requirements.txt
#6 CACHED

#7 [3/5] RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt  && useradd --uid 1000 --create-home student  && mkdir -p /app/data /app/output  && chown -R student:student /app
#7 CACHED

#8 [4/5] COPY public/ /app/data/
#8 DONE 0.0s

#9 [5/5] WORKDIR /app
#9 DONE 0.0s

#10 exporting to image
#10 exporting layers 0.0s done
#10 exporting manifest sha256:32de5e07a769841eb8acc615e6465f215560e6c3976130fcc4ccfb14a334a0ab done
#10 exporting config sha256:b9800841cae52ba4cfe807aac3f99590222c268b664bcae79c6ec213c331beb6 done
#10 exporting attestation manifest sha256:833bde5d7993639799b38d48093c1b982c9e5e6a2c3df64ea1a1df205d66399c done
#10 exporting manifest list sha256:871297b867f2db44d6eb9e76126326b7ee38fec8682dba231937f4e3653573b5 done
#10 naming to docker.io/library/theory-physics-ed05:dev done
#10 unpacking to docker.io/library/theory-physics-ed05:dev done
#10 DONE 0.1s

exit_code=0
```

### 2026-11-16T17:22:28.314693+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-ed05:dev python tools/build_ed05_truth.py
```

```text
pec-01 {'id': 'pec-01', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.01144429473697297645903616679999860683756690427394571438393958624474063873e-75', 'angular_g_absolute_residual': '6.90893484407555570030908149024031965689280029154902510801896277613487344253e-76', 'lmax_plus_12_max_observable_relative_change': '6.415388864573428e-17'}
pec-02 {'id': 'pec-02', 'optical_theorem_relative_residual': '1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '9.5444215086634120006982914924400248355750718328028268084549663458340664116e-76', 'angular_g_absolute_residual': '4.83625439085288899021635704316822375982496020408431757561327394329441140977e-76', 'lmax_plus_12_max_observable_relative_change': '7.710289742181398e-17'}
pec-03 {'id': 'pec-03', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '1.27266969554342566995133828004793828138053097001830267192801896905331752493e-75', 'angular_g_absolute_residual': '8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76', 'lmax_plus_12_max_observable_relative_change': '1.9313269123976714e-14'}
pec-04 {'id': 'pec-04', 'optical_theorem_relative_residual': '2.71489017731814593435836987467235206243112783318005146224658949899841019303e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.90042312412270215405085891227064644370178948322603602357261264929888713512e-75', 'angular_g_absolute_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-75', 'lmax_plus_12_max_observable_relative_change': '4.702346208039442e-13'}
pec-05 {'id': 'pec-05', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '3.07891160053305600845764213384798745457746197817754053047158516976912714894e-75', 'angular_g_absolute_residual': '2.22813148721436671334967878060250308934792809402456059733611549530349668522e-75', 'lmax_plus_12_max_observable_relative_change': '4.1880841872197046e-12'}
pec-06 {'id': 'pec-06', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '6.13083296659044901781766237768993833077785735079079649045768079834119051871e-75', 'angular_g_absolute_residual': '5.66532657214195567425344682199706211865209623907020058857554947643059622287e-75', 'lmax_plus_12_max_observable_relative_change': '1.3393743018217157e-12'}
pec-07 {'id': 'pec-07', 'optical_theorem_relative_residual': '2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.03329733409873101479784373714219225081398978734535145230745318284111504451e-74', 'angular_g_absolute_residual': '9.60341943326502242342962327143404432308099240525314490014635825882747408512e-75', 'lmax_plus_12_max_observable_relative_change': '3.159115479002677e-13'}
pec-08 {'id': 'pec-08', 'optical_theorem_relative_residual': '2.66171077712157945235389802534124085003067949790794409992442619388537619941e-76', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '3.27390425585954272639529457116972624553773578242677124290704421847901272527e-74', 'angular_g_absolute_residual': '3.19883683280698228924310472998126800114136653498719862501277976535044640389e-74', 'lmax_plus_12_max_observable_relative_change': '9.744499252076039e-12'}
pec-09 {'id': 'pec-09', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '8.7386841442309932796368361957835601391818863873708976886792349092955783573e-74', 'angular_g_absolute_residual': '8.6914400338470490709888245147223221283711427667686735858878551723776707907e-74', 'lmax_plus_12_max_observable_relative_change': '1.1514327074030843e-10'}
pec-10 {'id': 'pec-10', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '2.61762779379272863331897961983912934215312892038914324179405354021051637114e-73', 'angular_g_absolute_residual': '2.6088137971229298324367091707147447024427213900889118807879603442685282119e-73', 'lmax_plus_12_max_observable_relative_change': '8.866387237177389e-10'}
Traceback (most recent call last):
  File "/work/tools/build_ed05_truth.py", line 141, in <module>
    main()
  File "/work/tools/build_ed05_truth.py", line 118, in main
    (TASK / "tests/private/truth.json").write_text(json.dumps(truth, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
  File "/usr/local/lib/python3.12/pathlib.py", line 1047, in write_text
    with self.open(mode='w', encoding=encoding, errors=errors, newline=newline) as f:
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/local/lib/python3.12/pathlib.py", line 1013, in open
    return io.open(self, mode, buffering, encoding, errors, newline)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
FileNotFoundError: [Errno 2] No such file or directory: '/work/tasks/ed-05/tests/private/truth.json'

exit_code=1
```

### 2026-11-16T17:23:45.899648+08:00

```bash
python3 -c 'import shutil; shutil.copyfile("tasks/ed-05/environment/public/start.py","tasks/ed-05/solution/baseline.py")'
```

```text

exit_code=0
```

### 2026-11-16T17:23:46.003921+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-ed05:dev python tools/build_ed05_truth.py
```

```text
pec-01 {'id': 'pec-01', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.01144429473697297645903616679999860683756690427394571438393958624474063873e-75', 'angular_g_absolute_residual': '6.90893484407555570030908149024031965689280029154902510801896277613487344253e-76', 'lmax_plus_12_max_observable_relative_change': '6.415388864573428e-17'}
pec-02 {'id': 'pec-02', 'optical_theorem_relative_residual': '1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '9.5444215086634120006982914924400248355750718328028268084549663458340664116e-76', 'angular_g_absolute_residual': '4.83625439085288899021635704316822375982496020408431757561327394329441140977e-76', 'lmax_plus_12_max_observable_relative_change': '7.710289742181398e-17'}
pec-03 {'id': 'pec-03', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '1.27266969554342566995133828004793828138053097001830267192801896905331752493e-75', 'angular_g_absolute_residual': '8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76', 'lmax_plus_12_max_observable_relative_change': '1.9313269123976714e-14'}
pec-04 {'id': 'pec-04', 'optical_theorem_relative_residual': '2.71489017731814593435836987467235206243112783318005146224658949899841019303e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.90042312412270215405085891227064644370178948322603602357261264929888713512e-75', 'angular_g_absolute_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-75', 'lmax_plus_12_max_observable_relative_change': '4.702346208039442e-13'}
pec-05 {'id': 'pec-05', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '3.07891160053305600845764213384798745457746197817754053047158516976912714894e-75', 'angular_g_absolute_residual': '2.22813148721436671334967878060250308934792809402456059733611549530349668522e-75', 'lmax_plus_12_max_observable_relative_change': '4.1880841872197046e-12'}
pec-06 {'id': 'pec-06', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '6.13083296659044901781766237768993833077785735079079649045768079834119051871e-75', 'angular_g_absolute_residual': '5.66532657214195567425344682199706211865209623907020058857554947643059622287e-75', 'lmax_plus_12_max_observable_relative_change': '1.3393743018217157e-12'}
pec-07 {'id': 'pec-07', 'optical_theorem_relative_residual': '2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.03329733409873101479784373714219225081398978734535145230745318284111504451e-74', 'angular_g_absolute_residual': '9.60341943326502242342962327143404432308099240525314490014635825882747408512e-75', 'lmax_plus_12_max_observable_relative_change': '3.159115479002677e-13'}
pec-08 {'id': 'pec-08', 'optical_theorem_relative_residual': '2.66171077712157945235389802534124085003067949790794409992442619388537619941e-76', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '3.27390425585954272639529457116972624553773578242677124290704421847901272527e-74', 'angular_g_absolute_residual': '3.19883683280698228924310472998126800114136653498719862501277976535044640389e-74', 'lmax_plus_12_max_observable_relative_change': '9.744499252076039e-12'}
pec-09 {'id': 'pec-09', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '8.7386841442309932796368361957835601391818863873708976886792349092955783573e-74', 'angular_g_absolute_residual': '8.6914400338470490709888245147223221283711427667686735858878551723776707907e-74', 'lmax_plus_12_max_observable_relative_change': '1.1514327074030843e-10'}
pec-10 {'id': 'pec-10', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '2.61762779379272863331897961983912934215312892038914324179405354021051637114e-73', 'angular_g_absolute_residual': '2.6088137971229298324367091707147447024427213900889118807879603442685282119e-73', 'lmax_plus_12_max_observable_relative_change': '8.866387237177389e-10'}
{
  "precision_digits": 75,
  "independent_method": "mpmath half-integer Bessel functions, Riccati derivative identity, multipole sums, and 64-node high-precision Gauss-Legendre angular integration (exact for this truncated polynomial degree)",
  "cross_checks": [
    {
      "id": "pec-01",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.01144429473697297645903616679999860683756690427394571438393958624474063873e-75",
      "angular_g_absolute_residual": "6.90893484407555570030908149024031965689280029154902510801896277613487344253e-76",
      "lmax_plus_12_max_observable_relative_change": "6.415388864573428e-17"
    },
    {
      "id": "pec-02",
      "optical_theorem_relative_residual": "1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "9.5444215086634120006982914924400248355750718328028268084549663458340664116e-76",
      "angular_g_absolute_residual": "4.83625439085288899021635704316822375982496020408431757561327394329441140977e-76",
      "lmax_plus_12_max_observable_relative_change": "7.710289742181398e-17"
    },
    {
      "id": "pec-03",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "1.27266969554342566995133828004793828138053097001830267192801896905331752493e-75",
      "angular_g_absolute_residual": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76",
      "lmax_plus_12_max_observable_relative_change": "1.9313269123976714e-14"
    },
    {
      "id": "pec-04",
      "optical_theorem_relative_residual": "2.71489017731814593435836987467235206243112783318005146224658949899841019303e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.90042312412270215405085891227064644370178948322603602357261264929888713512e-75",
      "angular_g_absolute_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-75",
      "lmax_plus_12_max_observable_relative_change": "4.702346208039442e-13"
    },
    {
      "id": "pec-05",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "3.07891160053305600845764213384798745457746197817754053047158516976912714894e-75",
      "angular_g_absolute_residual": "2.22813148721436671334967878060250308934792809402456059733611549530349668522e-75",
      "lmax_plus_12_max_observable_relative_change": "4.1880841872197046e-12"
    },
    {
      "id": "pec-06",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "6.13083296659044901781766237768993833077785735079079649045768079834119051871e-75",
      "angular_g_absolute_residual": "5.66532657214195567425344682199706211865209623907020058857554947643059622287e-75",
      "lmax_plus_12_max_observable_relative_change": "1.3393743018217157e-12"
    },
    {
      "id": "pec-07",
      "optical_theorem_relative_residual": "2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.03329733409873101479784373714219225081398978734535145230745318284111504451e-74",
      "angular_g_absolute_residual": "9.60341943326502242342962327143404432308099240525314490014635825882747408512e-75",
      "lmax_plus_12_max_observable_relative_change": "3.159115479002677e-13"
    },
    {
      "id": "pec-08",
      "optical_theorem_relative_residual": "2.66171077712157945235389802534124085003067949790794409992442619388537619941e-76",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "3.27390425585954272639529457116972624553773578242677124290704421847901272527e-74",
      "angular_g_absolute_residual": "3.19883683280698228924310472998126800114136653498719862501277976535044640389e-74",
      "lmax_plus_12_max_observable_relative_change": "9.744499252076039e-12"
    },
    {
      "id": "pec-09",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "8.7386841442309932796368361957835601391818863873708976886792349092955783573e-74",
      "angular_g_absolute_residual": "8.6914400338470490709888245147223221283711427667686735858878551723776707907e-74",
      "lmax_plus_12_max_observable_relative_change": "1.1514327074030843e-10"
    },
    {
      "id": "pec-10",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "2.61762779379272863331897961983912934215312892038914324179405354021051637114e-73",
      "angular_g_absolute_residual": "2.6088137971229298324367091707147447024427213900889118807879603442685282119e-73",
      "lmax_plus_12_max_observable_relative_change": "8.866387237177389e-10"
    }
  ],
  "low_frequency_checks": [
    {
      "id": "pec-01",
      "qsca_rayleigh_relative_error": 0.0005998430326947801,
      "g_dipole_absolute_error": 0.0006727583052494879
    },
    {
      "id": "pec-02",
      "qsca_rayleigh_relative_error": 0.005377102245938348,
      "g_dipole_absolute_error": 0.006013719499134873
    }
  ],
  "checks_passed": true,
  "elapsed_seconds": 0.6277523329999894
}

exit_code=0
```

### 2026-11-16T17:27:14.926574+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-ed05:dev python tools/run_ed05_checks.py --calibrate
```

```text
{
  "scores": {
    "baseline": {
      "raw_metric": 54.7865767076393,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 1.7490612732554056e-13,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 1.7490612732554056e-13,
      "score": 1.0,
      "status": "completed"
    },
    "zero": {
      "raw_metric": 83.3244189031516,
      "score": 0.0,
      "status": "completed"
    },
    "wrong_hankel_sign": {
      "raw_metric": 37.06833410324246,
      "score": 0.32340481317071074,
      "status": "completed"
    },
    "missing_magnetic": {
      "raw_metric": 19.1151700114172,
      "score": 0.6510975651312831,
      "status": "completed"
    },
    "backscatter_factor_four": {
      "raw_metric": 5.625000000000107,
      "score": 0.8973288652434528,
      "status": "completed"
    },
    "phase_factor_two": {
      "raw_metric": 20.000000000000092,
      "score": 0.6349470764211623,
      "status": "completed"
    },
    "zero_asymmetry": {
      "raw_metric": 1.5783241296435535,
      "score": 0.971191408105933,
      "status": "completed"
    },
    "duplicate": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "nonfinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_order": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_angle": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing_order": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "wrong_angle": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "malformed": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "overflow_integer": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "negative_efficiency": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing_method": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "independent": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.11581362499998704,
    "reference_seconds": 0.10532599999999093
  },
  "checks": {
    "reference_improves_baseline": true,
    "reference_matches_independent_truth": true,
    "fixed_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "equivalent_order_same": true,
    "independent_solution_full_credit": true,
    "all_zero_answer_zero": true,
    "outgoing_hankel_sign_penalized": true,
    "missing_magnetic_multipoles_penalized": true,
    "backscatter_normalization_penalized": true,
    "phase_normalization_penalized": true,
    "angular_asymmetry_penalized": true,
    "invalid_answers_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "actual_public_start_matches_baseline": true,
    "public_feedback_works": true,
    "course_quality_unmodified": true
  }
}

exit_code=0
```

### 2026-11-16T17:28:22.944283+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-ed05:dev python tools/build_ed05_truth.py
```

```text
pec-01 {'id': 'pec-01', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.01144429473697297645903616679999860683756690427394571438393958624474063873e-75', 'angular_g_absolute_residual': '6.90893484407555570030908149024031965689280029154902510801896277613487344253e-76', 'forward_optical_theorem_relative_residual': '0.0', 'backscatter_differential_identity_relative_residual': '0.0', 'lmax_plus_12_max_observable_relative_change': '6.415388864573428e-17', 'lmax_plus_12_max_phase_relative_change': '0.0000000000000000641538886457342735240737195954501041985195649540880746231530258538917697869'}
pec-02 {'id': 'pec-02', 'optical_theorem_relative_residual': '1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '9.5444215086634120006982914924400248355750718328028268084549663458340664116e-76', 'angular_g_absolute_residual': '4.83625439085288899021635704316822375982496020408431757561327394329441140977e-76', 'forward_optical_theorem_relative_residual': '1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76', 'backscatter_differential_identity_relative_residual': '0.0', 'lmax_plus_12_max_observable_relative_change': '7.710289742181398e-17', 'lmax_plus_12_max_phase_relative_change': '0.0000000000000000771028974218139824844669824661085286445067363678800354885066737787450853284'}
pec-03 {'id': 'pec-03', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '1.27266969554342566995133828004793828138053097001830267192801896905331752493e-75', 'angular_g_absolute_residual': '8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76', 'forward_optical_theorem_relative_residual': '0.0', 'backscatter_differential_identity_relative_residual': '0.0', 'lmax_plus_12_max_observable_relative_change': '1.9313269123976714e-14', 'lmax_plus_12_max_phase_relative_change': '0.0000000000000193132691239767137510974780035420247711069852583964982848569951575280129543'}
pec-04 {'id': 'pec-04', 'optical_theorem_relative_residual': '2.71489017731814593435836987467235206243112783318005146224658949899841019303e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.90042312412270215405085891227064644370178948322603602357261264929888713512e-75', 'angular_g_absolute_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-75', 'forward_optical_theorem_relative_residual': '0.0', 'backscatter_differential_identity_relative_residual': '0.0', 'lmax_plus_12_max_observable_relative_change': '4.702346208039442e-13', 'lmax_plus_12_max_phase_relative_change': '0.000000000000470234620803944248446801782564700591391578720829669876439814477092510942942'}
pec-05 {'id': 'pec-05', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '3.07891160053305600845764213384798745457746197817754053047158516976912714894e-75', 'angular_g_absolute_residual': '2.22813148721436671334967878060250308934792809402456059733611549530349668522e-75', 'forward_optical_theorem_relative_residual': '2.56575966711088000704803511153998954548121831514795044205965430814093929078e-76', 'backscatter_differential_identity_relative_residual': '0.0', 'lmax_plus_12_max_observable_relative_change': '4.1880841872197046e-12', 'lmax_plus_12_max_phase_relative_change': '0.00000000000418808418721970452859431149381377817512292546140614937216544601449441992296'}
pec-06 {'id': 'pec-06', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '6.13083296659044901781766237768993833077785735079079649045768079834119051871e-75', 'angular_g_absolute_residual': '5.66532657214195567425344682199706211865209623907020058857554947643059622287e-75', 'forward_optical_theorem_relative_residual': '5.10902747215870751484805198140828194231488112565899707538140066528432543226e-76', 'backscatter_differential_identity_relative_residual': '9.69547900070940581760145612441646043395793329400767712047084478977653393714e-76', 'lmax_plus_12_max_observable_relative_change': '1.3393743018217157e-12', 'lmax_plus_12_max_phase_relative_change': '0.00000000000133937430182171570769619024067074675734766032224203670288762837613035713177'}
pec-07 {'id': 'pec-07', 'optical_theorem_relative_residual': '2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76', 'partial_wave_unitarity_max_residual': '0.0', 'angular_qsca_relative_residual': '1.03329733409873101479784373714219225081398978734535145230745318284111504451e-74', 'angular_g_absolute_residual': '9.60341943326502242342962327143404432308099240525314490014635825882747408512e-75', 'forward_optical_theorem_relative_residual': '2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76', 'backscatter_differential_identity_relative_residual': '5.27850471645001512033101442725729832222062597620730755760377081316168063831e-76', 'lmax_plus_12_max_observable_relative_change': '3.159115479002677e-13', 'lmax_plus_12_max_phase_relative_change': '0.000000000000572385334931256185970324972785317143343452896918833268007249129081471320522'}
pec-08 {'id': 'pec-08', 'optical_theorem_relative_residual': '2.66171077712157945235389802534124085003067949790794409992442619388537619941e-76', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '3.27390425585954272639529457116972624553773578242677124290704421847901272527e-74', 'angular_g_absolute_residual': '3.19883683280698228924310472998126800114136653498719862501277976535044640389e-74', 'forward_optical_theorem_relative_residual': '0.0', 'backscatter_differential_identity_relative_residual': '8.87957531201745224665622676172770203604092467067742752162092717563727871739e-76', 'lmax_plus_12_max_observable_relative_change': '9.744499252076039e-12', 'lmax_plus_12_max_phase_relative_change': '0.00000000000974449925207603844663101296221071078497712934529594238951534572453367731358'}
pec-09 {'id': 'pec-09', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '8.7386841442309932796368361957835601391818863873708976886792349092955783573e-74', 'angular_g_absolute_residual': '8.6914400338470490709888245147223221283711427667686735858878551723776707907e-74', 'forward_optical_theorem_relative_residual': '5.41094993450835497191135368159972764036030116865071064314503709553905780638e-76', 'backscatter_differential_identity_relative_residual': '1.79207691044852579569254607013497208992761292673162000843178021952490986878e-75', 'lmax_plus_12_max_observable_relative_change': '1.1514327074030843e-10', 'lmax_plus_12_max_phase_relative_change': '0.000000000115143270740308424775545539795393448385092432151259171251459413170635525056'}
pec-10 {'id': 'pec-10', 'optical_theorem_relative_residual': '0.0', 'partial_wave_unitarity_max_residual': '1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76', 'angular_qsca_relative_residual': '2.61762779379272863331897961983912934215312892038914324179405354021051637114e-73', 'angular_g_absolute_residual': '2.6088137971229298324367091707147447024427213900889118807879603442685282119e-73', 'forward_optical_theorem_relative_residual': '2.45914928435642564716814369295951608344239668930086525847040520479067300003e-75', 'backscatter_differential_identity_relative_residual': '2.61099353632484331490757759828081578451133585548255780905962079861773058364e-74', 'lmax_plus_12_max_observable_relative_change': '8.866387237177389e-10', 'lmax_plus_12_max_phase_relative_change': '0.000000000886638723717738905445208160098781322487103600077818277754557297581475401322'}
{
  "precision_digits": 75,
  "independent_method": "mpmath half-integer Bessel functions, Riccati derivative identity, multipole sums, and 64-node high-precision Gauss-Legendre angular integration (exact for this truncated polynomial degree)",
  "cross_checks": [
    {
      "id": "pec-01",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.01144429473697297645903616679999860683756690427394571438393958624474063873e-75",
      "angular_g_absolute_residual": "6.90893484407555570030908149024031965689280029154902510801896277613487344253e-76",
      "forward_optical_theorem_relative_residual": "0.0",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "6.415388864573428e-17",
      "lmax_plus_12_max_phase_relative_change": "0.0000000000000000641538886457342735240737195954501041985195649540880746231530258538917697869"
    },
    {
      "id": "pec-02",
      "optical_theorem_relative_residual": "1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "9.5444215086634120006982914924400248355750718328028268084549663458340664116e-76",
      "angular_g_absolute_residual": "4.83625439085288899021635704316822375982496020408431757561327394329441140977e-76",
      "forward_optical_theorem_relative_residual": "1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "7.710289742181398e-17",
      "lmax_plus_12_max_phase_relative_change": "0.0000000000000000771028974218139824844669824661085286445067363678800354885066737787450853284"
    },
    {
      "id": "pec-03",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "1.27266969554342566995133828004793828138053097001830267192801896905331752493e-75",
      "angular_g_absolute_residual": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76",
      "forward_optical_theorem_relative_residual": "0.0",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "1.9313269123976714e-14",
      "lmax_plus_12_max_phase_relative_change": "0.0000000000000193132691239767137510974780035420247711069852583964982848569951575280129543"
    },
    {
      "id": "pec-04",
      "optical_theorem_relative_residual": "2.71489017731814593435836987467235206243112783318005146224658949899841019303e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.90042312412270215405085891227064644370178948322603602357261264929888713512e-75",
      "angular_g_absolute_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-75",
      "forward_optical_theorem_relative_residual": "0.0",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "4.702346208039442e-13",
      "lmax_plus_12_max_phase_relative_change": "0.000000000000470234620803944248446801782564700591391578720829669876439814477092510942942"
    },
    {
      "id": "pec-05",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "3.07891160053305600845764213384798745457746197817754053047158516976912714894e-75",
      "angular_g_absolute_residual": "2.22813148721436671334967878060250308934792809402456059733611549530349668522e-75",
      "forward_optical_theorem_relative_residual": "2.56575966711088000704803511153998954548121831514795044205965430814093929078e-76",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "4.1880841872197046e-12",
      "lmax_plus_12_max_phase_relative_change": "0.00000000000418808418721970452859431149381377817512292546140614937216544601449441992296"
    },
    {
      "id": "pec-06",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "6.13083296659044901781766237768993833077785735079079649045768079834119051871e-75",
      "angular_g_absolute_residual": "5.66532657214195567425344682199706211865209623907020058857554947643059622287e-75",
      "forward_optical_theorem_relative_residual": "5.10902747215870751484805198140828194231488112565899707538140066528432543226e-76",
      "backscatter_differential_identity_relative_residual": "9.69547900070940581760145612441646043395793329400767712047084478977653393714e-76",
      "lmax_plus_12_max_observable_relative_change": "1.3393743018217157e-12",
      "lmax_plus_12_max_phase_relative_change": "0.00000000000133937430182171570769619024067074675734766032224203670288762837613035713177"
    },
    {
      "id": "pec-07",
      "optical_theorem_relative_residual": "2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.03329733409873101479784373714219225081398978734535145230745318284111504451e-74",
      "angular_g_absolute_residual": "9.60341943326502242342962327143404432308099240525314490014635825882747408512e-75",
      "forward_optical_theorem_relative_residual": "2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76",
      "backscatter_differential_identity_relative_residual": "5.27850471645001512033101442725729832222062597620730755760377081316168063831e-76",
      "lmax_plus_12_max_observable_relative_change": "3.159115479002677e-13",
      "lmax_plus_12_max_phase_relative_change": "0.000000000000572385334931256185970324972785317143343452896918833268007249129081471320522"
    },
    {
      "id": "pec-08",
      "optical_theorem_relative_residual": "2.66171077712157945235389802534124085003067949790794409992442619388537619941e-76",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "3.27390425585954272639529457116972624553773578242677124290704421847901272527e-74",
      "angular_g_absolute_residual": "3.19883683280698228924310472998126800114136653498719862501277976535044640389e-74",
      "forward_optical_theorem_relative_residual": "0.0",
      "backscatter_differential_identity_relative_residual": "8.87957531201745224665622676172770203604092467067742752162092717563727871739e-76",
      "lmax_plus_12_max_observable_relative_change": "9.744499252076039e-12",
      "lmax_plus_12_max_phase_relative_change": "0.00000000000974449925207603844663101296221071078497712934529594238951534572453367731358"
    },
    {
      "id": "pec-09",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "8.7386841442309932796368361957835601391818863873708976886792349092955783573e-74",
      "angular_g_absolute_residual": "8.6914400338470490709888245147223221283711427667686735858878551723776707907e-74",
      "forward_optical_theorem_relative_residual": "5.41094993450835497191135368159972764036030116865071064314503709553905780638e-76",
      "backscatter_differential_identity_relative_residual": "1.79207691044852579569254607013497208992761292673162000843178021952490986878e-75",
      "lmax_plus_12_max_observable_relative_change": "1.1514327074030843e-10",
      "lmax_plus_12_max_phase_relative_change": "0.000000000115143270740308424775545539795393448385092432151259171251459413170635525056"
    },
    {
      "id": "pec-10",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "2.61762779379272863331897961983912934215312892038914324179405354021051637114e-73",
      "angular_g_absolute_residual": "2.6088137971229298324367091707147447024427213900889118807879603442685282119e-73",
      "forward_optical_theorem_relative_residual": "2.45914928435642564716814369295951608344239668930086525847040520479067300003e-75",
      "backscatter_differential_identity_relative_residual": "2.61099353632484331490757759828081578451133585548255780905962079861773058364e-74",
      "lmax_plus_12_max_observable_relative_change": "8.866387237177389e-10",
      "lmax_plus_12_max_phase_relative_change": "0.000000000886638723717738905445208160098781322487103600077818277754557297581475401322"
    }
  ],
  "low_frequency_checks": [
    {
      "id": "pec-01",
      "qsca_rayleigh_relative_error": 0.0005998430326947801,
      "g_dipole_absolute_error": 0.0006727583052494879
    },
    {
      "id": "pec-02",
      "qsca_rayleigh_relative_error": 0.005377102245938348,
      "g_dipole_absolute_error": 0.006013719499134873
    }
  ],
  "checks_passed": true,
  "elapsed_seconds": 0.5893098340000051
}

exit_code=0
```

### 2026-11-16T17:28:23.765637+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-ed05:dev python tools/run_ed05_checks.py
```

```text
{
  "scores": {
    "baseline": {
      "raw_metric": 54.7865767076393,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 1.7490612732554056e-13,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 1.7490612732554056e-13,
      "score": 1.0,
      "status": "completed"
    },
    "zero": {
      "raw_metric": 83.3244189031516,
      "score": 0.0,
      "status": "completed"
    },
    "wrong_hankel_sign": {
      "raw_metric": 37.06833410324246,
      "score": 0.32340481317071074,
      "status": "completed"
    },
    "missing_magnetic": {
      "raw_metric": 19.1151700114172,
      "score": 0.6510975651312831,
      "status": "completed"
    },
    "backscatter_factor_four": {
      "raw_metric": 5.625000000000107,
      "score": 0.8973288652434528,
      "status": "completed"
    },
    "phase_factor_two": {
      "raw_metric": 20.000000000000092,
      "score": 0.6349470764211623,
      "status": "completed"
    },
    "zero_asymmetry": {
      "raw_metric": 1.5783241296435535,
      "score": 0.971191408105933,
      "status": "completed"
    },
    "duplicate": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "nonfinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_order": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_angle": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing_order": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "wrong_angle": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "malformed": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "overflow_integer": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "negative_efficiency": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing_method": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "independent": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.11069837499996993,
    "reference_seconds": 0.1014714579999918
  },
  "checks": {
    "reference_improves_baseline": true,
    "reference_matches_independent_truth": true,
    "fixed_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "equivalent_order_same": true,
    "independent_solution_full_credit": true,
    "all_zero_answer_zero": true,
    "outgoing_hankel_sign_penalized": true,
    "missing_magnetic_multipoles_penalized": true,
    "backscatter_normalization_penalized": true,
    "phase_normalization_penalized": true,
    "angular_asymmetry_penalized": true,
    "invalid_answers_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "actual_public_start_matches_baseline": true,
    "public_feedback_works": true,
    "course_quality_unmodified": true
  }
}

exit_code=0
```

### 2026-11-16T17:29:05.233971+08:00

```bash
python3 -c 'from pathlib import Path; fs=["planning/work-order-ed03.md","tasks/ed-05/instruction.md","tasks/ed-05/solution/README.md","tasks/ed-05/environment/public/model.json","checks/ed-05-truth-validation.json","checks/ed-05-calibration.json"]; [(print("\nFILE:",f),print(Path(f).read_text()[:12000])) for f in fs]'
```

```text

FILE: planning/work-order-ed03.md
# ed-03 至 ed-05 制作

ed-01 介质核壳球、ed-02 细直天线已完成，请不要改它们。按 planning/work-order-ed02.md 的封装规范继续 ed-03、ed-04、ed-05，每题独立。可选：ed-03 波导截止/色散/模式辨识，ed-04 运动电荷辐射角分布与谱，ed-05 导体涡流/趋肤或Mie散射。最终以用户Jackson及答案的实际原页证据为准，可调整。每题完整题面、环境、公开反馈、合理baseline、带推导参考解、独立真值、课程原版质量评分、实际Linux校准、来源和命令日志。只写对应新题、工具和checks。4CPU4GiB0GPU，agent1200/verifier120秒。每题完成就汇报并继续下一题，不等用户。只用本地Docker、不碰远程/推GitHub；Harbor由主代理补跑。


FILE: tasks/ed-05/instruction.md
# ed-05：理想导电球的多极电磁散射

## 任务

半径为 \(a\) 的理想导体球受沿 \(+z\) 方向传播的平面电磁波照射。对 `model.json` 给出的尺寸参数 \(x=ka\)，求所有指定多极阶数 \(1\leq l\leq l_{\max}\) 的电系数 \(a_l\)、磁系数 \(b_l\)，以及散射效率 \(Q_{sca}\)、消光效率 \(Q_{ext}\)、后向散射效率 \(Q_{back}\)、非对称参数 \(g=\langle\cos\theta\rangle\) 和指定角度处的无偏振相函数 \(\Phi(\theta)=k^2d\sigma/d\Omega\)。半径固定为1，效率以几何截面 \(\pi a^2\) 归一。

本题研究的是理想导体球的完整多极解，不是只保留Rayleigh偶极项。需呈现小球长波极限、偶极干涉和尺寸进入多极区后的变化。角度 \(\theta\) 从前向 \(+z\) 量起，后向为 \(180^\circ\)。

## 约定和公式

采用时间因子 \(e^{-i\omega t}\)，外向球波为 \(h_l^{(1)}\)，并定义 Riccati-Bessel 函数
\[
\psi_l(x)=xj_l(x),\qquad \xi_l(x)=xh_l^{(1)}(x).
\]
理想导体边界给出
\[
a_l=\frac{\psi_l'(x)}{\xi_l'(x)},\qquad b_l=\frac{\psi_l(x)}{\xi_l(x)}.
\]
撇号表示对自变量求导。这等价于 Jackson 式(16.152)的散射相移表示；本题将系数明确换成以上外向波约定下的复 Mie 系数，以免相移正负号造成歧义。对无耗散球，每个阶数满足 \(|1-2a_l|=|1-2b_l|=1\)，并有光学定理 \(Q_{ext}=Q_{sca}\)。

对 \(\pi_l(\mu)=P_l^1(\mu)/\sqrt{1-\mu^2}\) 的此处无 Condon-Shortley 号约定，即 \(\pi_1=1\)，令
\[
\tau_l(\mu)=l\mu\pi_l-(l+1)\pi_{l-1},\quad
\pi_{l+1}=\frac{2l+1}{l}\mu\pi_l-\frac{l+1}{l}\pi_{l-1}.
\]
角振幅为
\[
S_1=\sum_l\frac{2l+1}{l(l+1)}(a_l\pi_l+b_l\tau_l),\quad
S_2=\sum_l\frac{2l+1}{l(l+1)}(a_l\tau_l+b_l\pi_l),
\]
\[
\Phi(\theta)=\frac{|S_1|^2+|S_2|^2}{2},\quad
Q_{sca}=\frac2{x^2}\sum_l(2l+1)(|a_l|^2+|b_l|^2),
\]
\[
Q_{ext}=\frac2{x^2}\Re\sum_l(2l+1)(a_l+b_l),\quad
Q_{back}=\frac1{x^2}\left|\sum_l(2l+1)(-1)^l(a_l-b_l)\right|^2.
\]
非对称参数为
\[
g=\frac{4}{x^2Q_{sca}}\left[\sum_{l=1}^{L-1}\frac{l(l+2)}{l+1}\Re(a_la_{l+1}^*+b_lb_{l+1}^*)
+\sum_{l=1}^L\frac{2l+1}{l(l+1)}\Re(a_lb_l^*)\right].
\]

## 输入输出

公开工况给定 \(x\)、截断阶数和角度。提交 `/app/output/answer.json`，格式如下；复系数以 `[实部, 虚部]` 表示：

```json
{"cases":[{"id":"pec-01","coefficients":[{"l":1,"a":[0.0,0.0],"b":[0.0,0.0]}],"qsca":0.0,"qext":0.0,"qback":0.0,"g":0.0,"phase":[{"theta_deg":0,"value":0.0}]}],"method":"说明多极计算和角分布方法"}
```

示例只表示字段结构；正式结果应恰好提交公开 `lmax` 个系数及全部公开角度，并且按阶数和角度升序。所有数值必须有限，不接受布尔值代替数字。相函数量纲约定、效率归一和入射波约定均以本题定义为准。

## 起点与反馈

运行公开的电、磁偶极起点：

```bash
python /app/data/start.py --data-root /app/data --output /app/output/answer.json
python /app/data/feedback.py /app/output/answer.json
```

起点只保留 \(l=1\)，但精确计算该阶的电、磁系数；它是低频物理基线，不代表多极全解。公开反馈检查每阶无耗散性，并从提交的系数重算光学定理、角分布与积分观测量的一致性。自洽的错误系数仍可能通过这些恒等式，最终准确度由私有真值评分。

## 评分

十个尺寸参数工况等权平均，误差越低越好。每工况的原始误差为以下四项的加权和（再乘100）：40%系数复数相对误差，30%积分量误差，20%角分布误差，10%低频精度误差。系数项对所有阶数的 \(a_l,b_l\) 取平均，误差按各自真值模长归一并截于1；当参考系数极小，分母下限为该工况最大参考系数的 \(10^{-12}\) 且不小于 \(10^{-15}\)。积分量对 \(Q_{sca},Q_{ext},Q_{back}\) 取截顶相对误差，对 \(g\) 使用 \(\min(1,|g-g_*|/2)\)。角分布在12个公开角度逐点比较，按该工况最大真值的 \(10^{-10}\) 且不小于 \(10^{-14}\) 作小值保护。只对 \(x\leq0.15\) 的两个长波工况计入低频精度项：\(\frac12\min(1,|Q-Q_*|/(10x^4/3))+\frac12\min(1,|g-g_*|/2)\)。这里用 Jackson 长波式作为归一尺度，真值仍用有限尺寸的完整解，故不会奖励把渐近式当作精确答案。基线、参考端点和质量分数线性换算由 `metric.json` 和课程原版评分函数给出。

资源限制：4 CPU、4 GiB内存、0 GPU；无需模型权重或联网数据。参考程序、独立真值和评分答案不在公开环境中。


FILE: tasks/ed-05/solution/README.md
# 参考解与物理核验

## 边界条件到多极系数

Jackson《经典电动力学》§16.9讨论电磁球散射。理想导体的边界使表面切向电场为零；书内式(16.152)以球面 Bessel/Neumann 函数给出两类散射相移。采用本题的 \(e^{-i\omega t}\) 和出射 \(h_l^{(1)}\) 约定，可将相移转换成
\[
a_l=\frac{[xj_l(x)]'}{[xh_l^{(1)}(x)]'},\qquad
b_l=\frac{xj_l(x)}{xh_l^{(1)}(x)}.
\]
该比值保持每一阶的相位信息。只比较总散射截面会丢失多极相干干涉，故提交完整的电、磁系数序列。

程序用 SciPy 球 Bessel/Neumann 函数及导数构造 Riccati 函数，再代入边界比值。阶数由输入给定，最大尺寸工况 \(x=30\) 取 \(l_{max}=45\)，不在任务运行时偷偷截断。对系数 \(z_l\)，PEC无吸收要求 \(|1-2z_l|=1\)，总截面满足光学定理 \(Q_{ext}=Q_{sca}\)。

## 截面、角分布与偶极干涉

用角递推而非直接求高阶伴随 Legendre 函数。由 \(\pi_0=0,\pi_1=1\) 和
\[
\pi_{l+1}=\frac{2l+1}{l}\mu\pi_l-\frac{l+1}{l}\pi_{l-1},\qquad
\tau_l=l\mu\pi_l-(l+1)\pi_{l-1}
\]
形成两种偏振振幅 \(S_1,S_2\)。它们给出无偏振微分截面 \(d\sigma/d\Omega=(|S_1|^2+|S_2|^2)/(2k^2)\)。总散射、消光、后向效率及 \(g\) 再由多极和解析求出。后向散射振幅是所有阶的交替相干和；逐阶功率相加不能得到它。

Jackson式(16.158)展示长波下电偶极与磁偶极的交叉干涉，角分布不是纯电偶极的 \(1+\cos^2\theta\)。式(16.159)给
\[
\sigma\sim\frac{10\pi}{3}a^2(ka)^4,
\]
因此 \(Q_{sca}\sim10x^4/3\)，并由电、磁偶极比值得 \(g\to-2/5\)。当 \(x\) 增大，更多部分波进入散射，后向干涉和前向相函数出现细致结构；题目从长波跨到 \(x=30\)，逐阶系数和角分布会揭示仅拟合一个总截面无法说明的结构。

## 简单基线与独立真值

公开基线精确保留 \(l=1\) 电、磁偶极，不以人为错误的公式制造分数差。其长波极限有物理依据，但随 \(x\) 增大遗漏更高阶部分波。参考解按输入保留所有阶数，并以递推生成角振幅。

独立真值脚本用 75 位 mpmath 半整数阶普通 Bessel 函数直接构造系数；它不导入参考解核心。每个工况另以高阶 Gauss-Legendre 对相函数角积分，检验 \(Q_{sca}\) 与 \(g\)；检查后向振幅恒等式、光学定理和逐阶幺正性，并将截断阶数增加12验证尾项。长波系数与解析偶极阶标度比较。校准脚本用真实 verifier 入口测出公开偶极基线和参考端点，采用课程原版连续质量评分。

运行参考解：`/solution/solve.sh`。环境中供 Agent 使用的起点为 `/app/data/start.py`；完整参考核心仅留在课程材料/solution目录。


FILE: tasks/ed-05/environment/public/model.json
{
  "problem": "multipole scattering of a plane electromagnetic wave by a perfectly conducting sphere",
  "conventions": {
    "time_dependence": "exp(-i*omega*t)",
    "outgoing_wave": "spherical_hankel_first_kind",
    "radius": 1.0,
    "size_parameter": "x=k*a",
    "incident_direction": "+z",
    "polarization": "unpolarized",
    "efficiencies": "cross_section/(pi*a^2)",
    "backscatter_efficiency": "4*pi*differential_cross_section(theta=pi)/(pi*a^2)",
    "phase_quantity": "k^2*differential_cross_section_per_steradian",
    "multipole_cutoff": "fixed lmax is given separately for each case; use every order 1..lmax"
  },
  "angles_deg": [0, 5, 10, 20, 30, 45, 60, 90, 120, 150, 170, 180],
  "cases": [
    {"id": "pec-01", "x": 0.05, "lmax": 4},
    {"id": "pec-02", "x": 0.15, "lmax": 5},
    {"id": "pec-03", "x": 0.5, "lmax": 6},
    {"id": "pec-04", "x": 1.0, "lmax": 7},
    {"id": "pec-05", "x": 1.5, "lmax": 8},
    {"id": "pec-06", "x": 2.8, "lmax": 11},
    {"id": "pec-07", "x": 4.0, "lmax": 13},
    {"id": "pec-08", "x": 8.0, "lmax": 19},
    {"id": "pec-09", "x": 15.0, "lmax": 27},
    {"id": "pec-10", "x": 30.0, "lmax": 45}
  ],
  "scoring": {
    "coefficient_weight": 0.40,
    "integrated_weight": 0.30,
    "angular_weight": 0.20,
    "low_frequency_weight": 0.10
  }
}


FILE: checks/ed-05-truth-validation.json
{
  "precision_digits": 75,
  "independent_method": "mpmath half-integer Bessel functions, Riccati derivative identity, multipole sums, and 64-node high-precision Gauss-Legendre angular integration (exact for this truncated polynomial degree)",
  "cross_checks": [
    {
      "id": "pec-01",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.01144429473697297645903616679999860683756690427394571438393958624474063873e-75",
      "angular_g_absolute_residual": "6.90893484407555570030908149024031965689280029154902510801896277613487344253e-76",
      "forward_optical_theorem_relative_residual": "0.0",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "6.415388864573428e-17",
      "lmax_plus_12_max_phase_relative_change": "0.0000000000000000641538886457342735240737195954501041985195649540880746231530258538917697869"
    },
    {
      "id": "pec-02",
      "optical_theorem_relative_residual": "1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "9.5444215086634120006982914924400248355750718328028268084549663458340664116e-76",
      "angular_g_absolute_residual": "4.83625439085288899021635704316822375982496020408431757561327394329441140977e-76",
      "forward_optical_theorem_relative_residual": "1.5907369181105686667830485820733374725958453054671378014091610576390110686e-76",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "7.710289742181398e-17",
      "lmax_plus_12_max_phase_relative_change": "0.0000000000000000771028974218139824844669824661085286445067363678800354885066737787450853284"
    },
    {
      "id": "pec-03",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "1.27266969554342566995133828004793828138053097001830267192801896905331752493e-75",
      "angular_g_absolute_residual": "8.29072181289066684037089778828838358827136034985883012962275533136184813104e-76",
      "forward_optical_theorem_relative_residual": "0.0",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "1.9313269123976714e-14",
      "lmax_plus_12_max_phase_relative_change": "0.0000000000000193132691239767137510974780035420247711069852583964982848569951575280129543"
    },
    {
      "id": "pec-04",
      "optical_theorem_relative_residual": "2.71489017731814593435836987467235206243112783318005146224658949899841019303e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.90042312412270215405085891227064644370178948322603602357261264929888713512e-75",
      "angular_g_absolute_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-75",
      "forward_optical_theorem_relative_residual": "0.0",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "4.702346208039442e-13",
      "lmax_plus_12_max_phase_relative_change": "0.000000000000470234620803944248446801782564700591391578720829669876439814477092510942942"
    },
    {
      "id": "pec-05",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "3.07891160053305600845764213384798745457746197817754053047158516976912714894e-75",
      "angular_g_absolute_residual": "2.22813148721436671334967878060250308934792809402456059733611549530349668522e-75",
      "forward_optical_theorem_relative_residual": "2.56575966711088000704803511153998954548121831514795044205965430814093929078e-76",
      "backscatter_differential_identity_relative_residual": "0.0",
      "lmax_plus_12_max_observable_relative_change": "4.1880841872197046e-12",
      "lmax_plus_12_max_phase_relative_change": "0.00000000000418808418721970452859431149381377817512292546140614937216544601449441992296"
    },
    {
      "id": "pec-06",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "6.13083296659044901781766237768993833077785735079079649045768079834119051871e-75",
      "angular_g_absolute_residual": "5.66532657214195567425344682199706211865209623907020058857554947643059622287e-75",
      "forward_optical_theorem_relative_residual": "5.10902747215870751484805198140828194231488112565899707538140066528432543226e-76",
      "backscatter_differential_identity_relative_residual": "9.69547900070940581760145612441646043395793329400767712047084478977653393714e-76",
      "lmax_plus_12_max_observable_relative_change": "1.3393743018217157e-12",
      "lmax_plus_12_max_phase_relative_change": "0.00000000000133937430182171570769619024067074675734766032224203670288762837613035713177"
    },
    {
      "id": "pec-07",
      "optical_theorem_relative_residual": "2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76",
      "partial_wave_unitarity_max_residual": "0.0",
      "angular_qsca_relative_residual": "1.03329733409873101479784373714219225081398978734535145230745318284111504451e-74",
      "angular_g_absolute_residual": "9.60341943326502242342962327143404432308099240525314490014635825882747408512e-75",
      "forward_optical_theorem_relative_residual": "2.58324333524682753699460934285548062703497446836337863076863295710278761128e-76",
      "backscatter_differential_identity_relative_residual": "5.27850471645001512033101442725729832222062597620730755760377081316168063831e-76",
      "lmax_plus_12_max_observable_relative_change": "3.159115479002677e-13",
      "lmax_plus_12_max_phase_relative_change": "0.000000000000572385334931256185970324972785317143343452896918833268007249129081471320522"
    },
    {
      "id": "pec-08",
      "optical_theorem_relative_residual": "2.66171077712157945235389802534124085003067949790794409992442619388537619941e-76",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "3.27390425585954272639529457116972624553773578242677124290704421847901272527e-74",
      "angular_g_absolute_residual": "3.19883683280698228924310472998126800114136653498719862501277976535044640389e-74",
      "forward_optical_theorem_relative_residual": "0.0",
      "backscatter_differential_identity_relative_residual": "8.87957531201745224665622676172770203604092467067742752162092717563727871739e-76",
      "lmax_plus_12_max_observable_relative_change": "9.744499252076039e-12",
      "lmax_plus_12_max_phase_relative_change": "0.00000000000974449925207603844663101296221071078497712934529594238951534572453367731358"
    },
    {
      "id": "pec-09",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "8.7386841442309932796368361957835601391818863873708976886792349092955783573e-74",
      "angular_g_absolute_residual": "8.6914400338470490709888245147223221283711427667686735858878551723776707907e-74",
      "forward_optical_theorem_relative_residual": "5.41094993450835497191135368159972764036030116865071064314503709553905780638e-76",
      "backscatter_differential_identity_relative_residual": "1.79207691044852579569254607013497208992761292673162000843178021952490986878e-75",
      "lmax_plus_12_max_observable_relative_change": "1.1514327074030843e-10",
      "lmax_plus_12_max_phase_relative_change": "0.000000000115143270740308424775545539795393448385092432151259171251459413170635525056"
    },
    {
      "id": "pec-10",
      "optical_theorem_relative_residual": "0.0",
      "partial_wave_unitarity_max_residual": "1.38178696881511114006181629804806393137856005830980502160379255522697468851e-76",
      "angular_qsca_relative_residual": "2.61762779379272863331897961983912934215312892038914324179405354021051637114e-73",
      "angular_g_absolute_residual": "2.6088137971229298324367091707147447024427213900889118807879603442685282119e-73",
      "forward_optical_theorem_relative_residual": "2.45914928435642564716814369295951608344239668930086525847040520479067300003e-75",
      "backscatter_differential_identity_relative_residual": "2.61099353632484331490757759828081578451133585548255780905962079861773058364e-74",
      "lmax_plus_12_max_observable_relative_change": "8.866387237177389e-10",
      "lmax_plus_12_max_phase_relative_change": "0.000000000886638723717738905445208160098781322487103600077818277754557297581475401322"
    }
  ],
  "low_frequency_checks": [
    {
      "id": "pec-01",
      "qsca_rayleigh_relative_error": 0.0005998430326947801,
      "g_dipole_absolute_error": 0.0006727583052494879
    },
    {
      "id": "pec-02",
      "qsca_rayleigh_relative_error": 0.005377102245938348,
      "g_dipole_absolute_error": 0.006013719499134873
    }
  ],
  "checks_passed": true,
  "elapsed_seconds": 0.5893098340000051
}


FILE: checks/ed-05-calibration.json
{
  "cases": {
    "baseline": {
      "raw_metric": 54.7865767076393,
      "cases": [
        {
          "id": "pec-01",
          "raw_metric": 20.23194590332596,
          "coefficient_error": 0.5055345859039351,
          "integrated_errors": {
            "qsca": 3.0051160256884566e-08,
            "qext": 3.0051159769286066e-08,
            "qback": 0.0004628875886586522,
            "g": 6.661809397595642e-05
          },
          "maximum_phase_error": 0.0004628875886588782,
          "low_frequency_error": 3.33240815810962e-05
        },
        {
          "id": "pec-02",
          "raw_metric": 24.43556887880104,
          "coefficient_error": 0.6085358395876775,
          "integrated_errors": {
            "qsca": 2.4075915238190117e-06,
            "qext": 2.4075915238190117e-06,
            "qback": 0.004160570837998185,
            "g": 0.0005960844079876126
          },
          "maximum_phase_error": 0.004160570837998143,
          "low_frequency_error": 0.0002992524726886108
        },
        {
          "id": "pec-03",
          "raw_metric": 34.164830730204294,
          "coefficient_error": 0.8307866012187715,
          "integrated_errors": {
            "qsca": 0.00026780188787765114,
            "qext": 0.0002678018878773955,
            "qback": 0.045828856250131465,
            "g": 0.006242111952737273
          },
          "maximum_phase_error": 0.045828856250131465,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-04",
          "raw_metric": 38.47603162305189,
          "coefficient_error": 0.8571428571428571,
          "integrated_errors": {
            "qsca": 0.00599109083737112,
            "qext": 0.00599109083737112,
            "qback": 0.23709077125777256,
            "g": 0.026409547051798654
          },
          "maximum_phase_error": 0.23709077125777256,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-05",
          "raw_metric": 53.69582740191129,
          "coefficient_error": 0.875,
          "integrated_errors": {
            "qsca": 0.10298926002737503,
            "qext": 0.10298926002737524,
            "qback": 1.0,
            "g": 0.10347369714023172
          },
          "maximum_phase_error": 1.0,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-06",
          "raw_metric": 64.81378535186485,
          "coefficient_error": 0.9090909090909093,
          "integrated_errors": {
            "qsca": 0.6455155639232671,
            "qext": 0.6455155639232671,
            "qback": 0.6076234133597734,
            "g": 0.18715779902203913
          },
          "maximum_phase_error": 0.8766970665792708,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-07",
          "raw_metric": 67.78994840598038,
          "coefficient_error": 0.9230769230769231,
          "integrated_errors": {
            "qsca": 0.8225577071008134,
            "qext": 0.8225577071008134,
            "qback": 0.28391417427373267,
            "g": 0.21399837875070862
          },
          "maximum_phase_error": 0.9687170105536236,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-08",
          "raw_metric": 79.06424655495631,
          "coefficient_error": 0.9473684210526315,
          "integrated_errors": {
            "qsca": 0.9548983151233421,
            "qext": 0.9548983151233421,
            "qback": 0.8493875994061529,
            "g": 0.24113326506896474
          },
          "maximum_phase_error": 0.9979668906132854,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-09",
          "raw_metric": 81.94017331559677,
          "coefficient_error": 0.9629629629629629,
          "integrated_errors": {
            "qsca": 0.9869506829888618,
            "qext": 0.9869506829888618,
            "qback": 0.9567691018088906,
            "g": 0.2477569556254142
          },
          "maximum_phase_error": 0.9998297177827628,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-10",
          "raw_metric": 83.25340891070029,
          "coefficient_error": 0.9777777777777777,
          "integrated_errors": {
            "qsca": 0.9967043268906771,
            "qext": 0.9967043268906771,
            "qback": 0.9901584506464369,
            "g": 0.2499433511817447
          },
          "maximum_phase_error": 0.9999891386234255,
          "low_frequency_error": 0.0
        }
      ],
      "status": "completed",
      "score": 0.0
    },
    "reference": {
      "raw_metric": 1.7490612732554056e-13,
      "cases": [
        {
          "id": "pec-01",
          "raw_metric": 5.1016169690942903e-14,
          "coefficient_error": 8.755440615874095e-16,
          "integrated_errors": {
            "qsca": 0.0,
            "qext": 3.2506566337230904e-16,
            "qback": 4.820906902947754e-16,
            "g": 1.1102230246251565e-16
          },
          "maximum_phase_error": 8.417492862109507e-16,
          "low_frequency_error": 5.551115123125783e-17
        },
        {
          "id": "pec-02",
          "raw_metric": 3.730278740300992e-14,
          "coefficient_error": 4.993552399118015e-16,
          "integrated_errors": {
            "qsca": 1.2781078360595854e-16,
            "qext": 1.2781078360595854e-16,
            "qback": 1.9116167436803204e-16,
            "g": 1.1102230246251565e-16
          },
          "maximum_phase_error": 1.4078089114851668e-15,
          "low_frequency_error": 1.1976016886002846e-16
        },
        {
          "id": "pec-03",
          "raw_metric": 7.802734451051022e-14,
          "coefficient_error": 5.395426414057392e-16,
          "integrated_errors": {
            "qsca": 8.947318413006038e-16,
            "qext": 6.390941723575741e-16,
            "qback": 4.192872941206045e-16,
            "g": 1.942890293094024e-16
          },
          "maximum_phase_error": 3.3942997553573883e-15,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-04",
          "raw_metric": 6.079969574247523e-14,
          "coefficient_error": 9.00098679813071e-16,
          "integrated_errors": {
            "qsca": 4.362660311917565e-16,
            "qext": 4.362660311917565e-16,
            "qback": 6.104207368007432e-16,
            "g": 6.938893903907228e-17
          },
          "maximum_phase_error": 1.1842525189147919e-15,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-05",
          "raw_metric": 4.7060260224487834e-14,
          "coefficient_error": 9.810084359586185e-16,
          "integrated_errors": {
            "qsca": 4.1230168215057555e-16,
            "qext": 0.0,
            "qback": 0.0,
            "g": 1.3877787807814457e-17
          },
          "maximum_phase_error": 5.348209807809306e-16,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-06",
          "raw_metric": 8.30593911201324e-14,
          "coefficient_error": 1.4307995266162194e-15,
          "integrated_errors": {
            "qsca": 0.0,
            "qext": 2.0524726535440417e-16,
            "qback": 1.4022030657198674e-15,
            "g": 5.551115123125783e-17
          },
          "maximum_phase_error": 1.634383257408712e-15,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-07",
          "raw_metric": 6.993285589722402e-14,
          "coefficient_error": 1.442440065735278e-15,
          "integrated_errors": {
            "qsca": 0.0,
            "qext": 0.0,
            "qback": 4.2411150228320217e-16,
            "g": 0.0
          },
          "maximum_phase_error": 1.3106113908869492e-15,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-08",
          "raw_metric": 2.0212237845227732e-13,
          "coefficient_error": 3.390241511432019e-15,
          "integrated_errors": {
            "qsca": 4.2772043105708283e-16,
            "qext": 4.2772043105708283e-16,
            "qback": 2.378154564290623e-15,
            "g": 1.942890293094024e-16
          },
          "maximum_phase_error": 6.2207726507648865e-15,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-09",
          "raw_metric": 9.48625067575679e-13,
          "coefficient_error": 6.230240923571171e-15,
          "integrated_errors": {
            "qsca": 6.521295979006625e-16,
            "qext": 4.3475306526710836e-16,
            "qback": 6.599442129586734e-14,
            "g": 1.1102230246251565e-16
          },
          "maximum_phase_error": 6.457480796665846e-14,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-10",
          "raw_metric": 1.711153226386667e-13,
          "coefficient_error": 1.607357696441875e-15,
          "integrated_errors": {
            "qsca": 0.0,
            "qext": 2.1953891897470056e-16,
            "qback": 1.3111577646358466e-15,
            "g": 5.551115123125783e-17
          },
          "maximum_phase_error": 1.4047841413105838e-14,
          "low_frequency_error": 0.0
        }
      ],
      "status": "completed",
      "score": 1.0
    },
    "equivalent": {
      "raw_metric": 1.7490612732554056e-13,
      "cases": [
        {
          "id": "pec-01",
          "raw_metric": 5.1016169690942903e-14,
          "coefficient_error": 8.755440615874095e-16,
          "integrated_errors": {
            "qsca": 0.0,
            "qext": 3.2506566337230904e-16,
            "qback": 4.820906902947754e-16,
            "g": 1.1102230246251565e-16
          },
          "maximum_phase_error": 8.417492862109507e-16,
          "low_frequency_error": 5.551115123125783e-17
        },
        {
          "id": "pec-02",
          "raw_metric": 3.730278740300992e-14,
          "coefficient_error": 4.993552399118015e-16,
          "integrated_errors": {
            "qsca": 1.2781078360595854e-16,
            "qext": 1.2781078360595854e-16,
            "qback": 1.9116167436803204e-16,
            "g": 1.1102230246251565e-16
          },
          "maximum_phase_error": 1.4078089114851668e-15,
          "low_frequency_error": 1.1976016886002846e-16
        },
        {
          "id": "pec-03",
          "raw_metric": 7.802734451051022e-14,
          "coefficient_error": 5.395426414057392e-16,
          "integrated_errors": {
            "qsca": 8.947318413006038e-16,
            "qext": 6.390941723575741e-16,
            "qback": 4.192872941206045e-16,
            "g": 1.942890293094024e-16
          },
          "maximum_phase_error": 3.3942997553573883e-15,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-04",
          "raw_metric": 6.079969574247523e-14,
          "coefficient_error": 9.00098679813071e-16,
          "integrated_errors": {
            "qsca": 4.362660311917565e-16,
            "qext": 4.362660311917565e-16,
            "qback": 6.104207368007432e-16,
            "g": 6.938893903907228e-17
          },
          "maximum_phase_error": 1.1842525189147919e-15,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-05",
          "raw_metric": 4.7060260224487834e-14,
          "coefficient_error": 9.810084359586185e-16,
          "integrated_errors": {
            "qsca": 4.1230168215057555e-16,
            "qext": 0.0,
            "qback": 0.0,
            "g": 1.3877787807814457e-17
          },
          "maximum_phase_error": 5.348209807809306e-16,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-06",
          "raw_metric": 8.30593911201324e-14,
          "coefficient_error": 1.4307995266162194e-15,
          "integrated_errors": {
            "qsca": 0.0,
            "qext": 2.0524726535440417e-16,
            "qback": 1.4022030657198674e-15,
            "g": 5.551115123125783e-17
          },
          "maximum_phase_error": 1.634383257408712e-15,
          "low_frequency_error": 0.0
        },
        {
          "id": "pec-07",
      

exit_code=0
```

### 2026-11-16T17:30:57.109148+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-ed05:dev python tools/run_ed05_checks.py --calibrate
```

```text
{
  "scores": {
    "baseline": {
      "raw_metric": 41.58064676754055,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 1.4459306547580368e-13,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 1.4459306547580368e-13,
      "score": 1.0,
      "status": "completed"
    },
    "zero": {
      "raw_metric": 85.07832412964339,
      "score": 0.0,
      "status": "completed"
    },
    "wrong_hankel_sign": {
      "raw_metric": 40.00000000000011,
      "score": 0.03801400147470439,
      "status": "completed"
    },
    "missing_magnetic": {
      "raw_metric": 24.085059368089226,
      "score": 0.4207627528561944,
      "status": "completed"
    },
    "backscatter_factor_four": {
      "raw_metric": 5.625000000000076,
      "score": 0.8647207189573817,
      "status": "completed"
    },
    "phase_factor_two": {
      "raw_metric": 20.000000000000064,
      "score": 0.5190070007373536,
      "status": "completed"
    },
    "zero_asymmetry": {
      "raw_metric": 1.5783241296435233,
      "score": 0.9620418571537109,
      "status": "completed"
    },
    "duplicate": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "nonfinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_order": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_angle": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing_order": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "wrong_angle": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "malformed": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "overflow_integer": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "negative_efficiency": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing_method": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "independent": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.12304849999998169,
    "reference_seconds": 0.1620065419999719
  },
  "checks": {
    "reference_improves_baseline": true,
    "reference_matches_independent_truth": true,
    "fixed_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "equivalent_order_same": true,
    "independent_solution_full_credit": true,
    "all_zero_answer_zero": true,
    "outgoing_hankel_sign_penalized": true,
    "missing_magnetic_multipoles_penalized": true,
    "backscatter_normalization_penalized": true,
    "phase_normalization_penalized": true,
    "angular_asymmetry_penalized": true,
    "invalid_answers_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "actual_public_start_matches_baseline": true,
    "public_feedback_works": true,
    "course_quality_unmodified": true
  }
}

exit_code=0
```

### 2026-11-16T17:32:13.577408+08:00

```bash
docker build -t theory-physics-ed05:dev tasks/ed-05/environment
```

```text
#0 building with "desktop-linux" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile: 460B done
#1 DONE 0.0s

#2 [internal] load metadata for mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#2 DONE 0.0s

#3 [internal] load .dockerignore
#3 transferring context: 2B done
#3 DONE 0.0s

#4 [1/5] FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#4 resolve mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2 done
#4 DONE 0.0s

#5 [internal] load build context
#5 transferring context: 10.09kB done
#5 DONE 0.0s

#6 [2/5] COPY requirements.txt /tmp/requirements.txt
#6 CACHED

#7 [3/5] RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt  && useradd --uid 1000 --create-home student  && mkdir -p /app/data /app/output  && chown -R student:student /app
#7 CACHED

#8 [4/5] COPY public/ /app/data/
#8 DONE 0.0s

#9 [5/5] WORKDIR /app
#9 DONE 0.0s

#10 exporting to image
#10 exporting layers 0.0s done
#10 exporting manifest sha256:8e5f0aece80281e6e5c985f4baeab86e3ba165d8ab72ec963dd2e663e6ace6b5 done
#10 exporting config sha256:8d19bed12135e91cd2f0c2714f2dfee724754473e119a56a50a429610898f8a8 done
#10 exporting attestation manifest sha256:4acc2021a357c3509bf2af14d3fda5e9882a9bbb57be1db314b893e95e70a3c5 done
#10 exporting manifest list sha256:edb123754e708a0307fa99bbda61702c44d2f1f1bae4a13d07bc4522020000a4 done
#10 naming to docker.io/library/theory-physics-ed05:dev done
#10 unpacking to docker.io/library/theory-physics-ed05:dev 0.0s done
#10 DONE 0.1s

exit_code=0
```

### 2026-11-16T17:32:14.107063+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 theory-physics-ed05:dev python -c 'import subprocess; subprocess.run(["python","/app/data/start.py"],check=True); subprocess.run(["python","/app/data/feedback.py","/app/output/answer.json"],check=True)'
```

```text
{"cases": 10, "method": "exact PEC electric and magnetic dipole (l=1) truncation"}
{
  "valid": true,
  "cases": [
    {
      "id": "pec-01",
      "partial_wave_unitarity_residual": 1.1102230246251565e-16,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-02",
      "partial_wave_unitarity_residual": 1.1102230246251565e-16,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-03",
      "partial_wave_unitarity_residual": 0.0,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-04",
      "partial_wave_unitarity_residual": 1.1102230246251565e-16,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-05",
      "partial_wave_unitarity_residual": 1.1102230246251565e-16,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-06",
      "partial_wave_unitarity_residual": 1.1102230246251565e-16,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-07",
      "partial_wave_unitarity_residual": 2.220446049250313e-16,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-08",
      "partial_wave_unitarity_residual": 0.0,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-09",
      "partial_wave_unitarity_residual": 0.0,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    },
    {
      "id": "pec-10",
      "partial_wave_unitarity_residual": 1.1102230246251565e-16,
      "observable_residuals_from_submitted_coefficients": {
        "qsca": 0.0,
        "qext": 0.0,
        "qback": 0.0,
        "g": 0.0
      },
      "maximum_phase_residual_from_coefficients": 0.0
    }
  ],
  "note": "这些恒等式检查内部一致性，不替代私有多极系数和角分布核验"
}

exit_code=0
```

### 2026-11-16T17:32:14.542578+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-ed05:dev python tools/run_ed05_checks.py
```

```text
{
  "scores": {
    "baseline": {
      "raw_metric": 41.58064676754055,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 1.4459306547580368e-13,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 1.4459306547580368e-13,
      "score": 1.0,
      "status": "completed"
    },
    "zero": {
      "raw_metric": 85.07832412964339,
      "score": 0.0,
      "status": "completed"
    },
    "wrong_hankel_sign": {
      "raw_metric": 40.00000000000011,
      "score": 0.03801400147470439,
      "status": "completed"
    },
    "missing_magnetic": {
      "raw_metric": 24.085059368089226,
      "score": 0.4207627528561944,
      "status": "completed"
    },
    "backscatter_factor_four": {
      "raw_metric": 5.625000000000076,
      "score": 0.8647207189573817,
      "status": "completed"
    },
    "phase_factor_two": {
      "raw_metric": 20.000000000000064,
      "score": 0.5190070007373536,
      "status": "completed"
    },
    "zero_asymmetry": {
      "raw_metric": 1.5783241296435233,
      "score": 0.9620418571537109,
      "status": "completed"
    },
    "duplicate": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "nonfinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_order": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_angle": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing_order": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "wrong_angle": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "malformed": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "overflow_integer": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "negative_efficiency": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "missing_method": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "independent": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.17006500000002234,
    "reference_seconds": 0.1331577500000094
  },
  "checks": {
    "reference_improves_baseline": true,
    "reference_matches_independent_truth": true,
    "fixed_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "equivalent_order_same": true,
    "independent_solution_full_credit": true,
    "all_zero_answer_zero": true,
    "outgoing_hankel_sign_penalized": true,
    "missing_magnetic_multipoles_penalized": true,
    "backscatter_normalization_penalized": true,
    "phase_normalization_penalized": true,
    "angular_asymmetry_penalized": true,
    "invalid_answers_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "actual_public_start_matches_baseline": true,
    "public_feedback_works": true,
    "course_quality_unmodified": true
  }
}

exit_code=0
```

### 2026-11-16T17:32:55.141471+08:00

```bash
rg --files planning
```

```text
planning/source-notes/ed-sol-all.txt
planning/source-notes/gr-mid-front.txt
planning/source-notes/sp-front.txt
planning/source-notes/qft-expansion-inventory.json
planning/source-notes/gr-down-front.txt
planning/source-notes/gr-up-front.txt
planning/source-notes/qm-sol-all.txt
planning/source-notes/qft-problem-book-all.txt
planning/source-notes/qft-all.txt
planning/source-notes/qm-sol-front.txt
planning/source-notes/qft-front.txt
planning/source-notes/sp-sol-all.txt
planning/source-notes/ed-front.txt
planning/source-notes/gr-mid-all.txt
planning/source-notes/qft-gelis-all.txt
planning/source-notes/tm-front.txt
planning/source-notes/sp-sol-front.txt
planning/source-notes/ed-sol-front.txt
planning/source-notes/tm-all.txt
planning/source-notes/gr-down-all.txt
planning/work-order-sp02.md
planning/implementation-qft.md
planning/work-order-gr02.md
planning/work-order-gr03.md
planning/gr-candidate-evidence.md
planning/work-order-ed03.md
planning/work-order-qm03.md
planning/work-order-ed02.md
planning/work-order-qm02.md
planning/implementation-gr.md
planning/work-order-qm04-tm04.md
planning/work-order-tm03.md

exit_code=0
```

### 2026-11-16T17:33:06.502049+08:00

```bash
cat planning/work-order-sp02.md
```

```text
# sp-02 至 sp-05 实际制作任务

完成 ED04/05 后，继续制作统计物理 sp-02、sp-03、sp-04、sp-05。已有sp-01平均场铁磁分支不改。只写各新题 tasks/sp-0[2345]、tools/*sp0[2345]*、checks/sp-0[2345]*。以用户林宗涵《热力学与统计物理学》及习题解答PDF原页为依据，OCR在 planning/source-notes/sp-sol-all.txt；先定位核对关键原页，不能猜页码。建议独立方向：有限粒子数正则系综与粒子涨落；理想Bose气体凝聚/有限体积修正；Fermi气体低温展开失效与化学势；van der Waals Maxwell构造与共存/临界边界。可依据来源调整，不能将同题换参数凑四题，也不要重复sp01的多项式平均场。

交付参照已完成ed03的完整Harbor包：中文题面六栏、固定环境、全部公开输入和有用反馈、合理基线、带推导参考解、课程原版quality_score.py、独立真值、实际Linux校准、必要错误/等价答案检查、来源/公平性/验证及命令日志。4CPU4GiB0GPU agent1200/verifier120秒。每题完成校准即继续下一题，不只规划不索要权限，只本地Docker不碰远程、不推GitHub。主代理补Harbor。

exit_code=0
```

### 2026-11-16T22:11:52.882472+08:00

```bash
/usr/local/bin/python3 '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/run_harbor_local_checks.py' ed-05 --macos-compat
```

```text
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-ed-05-harbor-v42ahise/ed-05 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-ed-05-harbor-v42ahise/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-ed-05-harbor-v42ahise/runs/oracle/2026-11-16__22-11-53/result.json
Inspect results by running `harbor view 
/tmp/physics-ed-05-harbor-v42ahise/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-ed-05-harbor-v42ahise/runs/oracle/2026-11-16__22-11-53`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-ed-05-harbor-v42ahise/ed-05 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-ed-05-harbor-v42ahise/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-ed-05-harbor-v42ahise/runs/nop/2026-11-16__22-12-25/result.json
Inspect results by running `harbor view 
/tmp/physics-ed-05-harbor-v42ahise/runs/nop`
Share results by running `harbor upload 
/tmp/physics-ed-05-harbor-v42ahise/runs/nop/2026-11-16__22-12-25`

{
  "task_id": "ed-05",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-ed-05-harbor-v42ahise/ed-05",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-ed-05-harbor-v42ahise/ed-05",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-ed-05-harbor-v42ahise/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:11:53.004451+00:00",
      "archive": "runs/ed-05/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-11-53/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "ed-05__bmgm5h9"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-ed-05-harbor-v42ahise/ed-05",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-ed-05-harbor-v42ahise/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:12:25.439534+00:00",
      "archive": "runs/ed-05/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-12-25/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "ed-05__gmFkazG"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}

exit_code=0
```
