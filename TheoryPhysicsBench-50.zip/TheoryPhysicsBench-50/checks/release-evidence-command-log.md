
### 2026-11-16T22:51:49.974494+08:00

```bash
cat planning/work-order-release-evidence.md
```

```text
# 整套开发证据版本核对

实现 tools/collect_release_evidence.py，生成 checks/benchmark-50-harbor-evidence.json。不要修改task内容、run原始记录、全局README或check_benchmark50.py。

逐题核对runs/ID的原始Harbor oracle/nop，不只相信session的passed标记。解析实际job/result.json及trial/result.json、verifier/reward.txt/metrics.json；要求无异常、完成、oracle reward1/nop reward0。某些早期session无passed或不存在，请定位实际归档并如实列出，不得伪造旧session。

尽可能利用仍存在的/tmp/physics-*-harbor-*题目暂存副本校验最终版本。输出每题最终全文件hash、运行核心文件hash、来源证据路径、原始文件SHA256，逐文件差异与适用范围。无原快照证据或关键文件变化应明确needs_rerun，不得猜测通过。允许的差异只有：task.toml verifier public（Mac兼容）、agent时限1200改720（算子/评分未变）、instruction中同一时限文本同步、solution/README纯文档。feedback.py变化或代码/数据/metric变化必须重跑。超出允许的题面差异列出让主代理处理。

新记录若已有绑定hash也核对。发布证据应自足：将必要快照文件hash保存到证据JSON，而非发布包依赖/tmp。不要复制整本教材或OCR。每条shell命令先commentary展示并用 tools/run_logged.py --log checks/release-evidence-command-log.md 包装。完成后写planning/status-release-evidence.md及需补跑ID。主代理正在run_pending_harbor qft13–19，不要重复；其他题未经协调不要重跑。

exit_code=0
```

### 2026-11-16T22:52:07.974105+08:00

```bash
python3 -
```

```text

TASK tm-01
results: ['runs/tm-01/harbor-macos-compat/nop/2026-11-16__11-39-53/result.json', 'runs/tm-01/harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/result.json', 'runs/tm-01/harbor-macos-compat/oracle/2026-11-16__11-39-32/result.json', 'runs/tm-01/harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/result.json', 'runs/tm-01/harbor-path-failure/oracle/2026-11-16__11-38-25/result.json', 'runs/tm-01/harbor-path-failure/oracle/2026-11-16__11-38-25/tm-01__CJ5UToB/result.json']
sessions: []

FILE runs/tm-01/harbor-macos-compat/nop/2026-11-16__11-39-53/result.json 
 {
    "id": "e128b4f4-dd76-407b-ad66-3ffe32b0da6b",
    "started_at": "2026-11-16T11:39:53.792320",
    "updated_at": "2026-11-16T11:40:21.441477",
    "finished_at": "2026-11-16T11:40:21.441477",
    "n_total_trials": 1,
    "stats": {
        "n_completed_trials": 1,
        "n_errored_trials": 0,
        "n_running_trials": 0,
        "n_pending_trials": 0,
        "n_cancelled_trials": 0,
        "n_retries": 0,
        "evals": {
            "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                    {
                        "mean": 0.0
                    }
                ],
                "pass_at_k": {},
                "reward_stats": {
                    "reward": {
                        "0.0": [
                            "tm-01__dei9EjP"
                        ]
                    }
                },
                "exception_stats": {}
            }
        },
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null
    }
}

FILE runs/tm-01/harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/result.json 
 {
    "id": "9402201f-baa3-40d1-8ea3-b95f0036eaa3",
    "task_name": "theory-physics-bench/tm-01",
    "trial_name": "tm-01__dei9EjP",
    "trial_uri": "file:///private/tmp/theory-physics-tm01-harbor/runs/nop/2026-11-16__11-39-53/tm-01__dei9EjP",
    "task_id": {
        "path": "/private/tmp/theory-physics-tm01-harbor/task/tm-01"
    },
    "source": null,
    "task_checksum": "f833d65fb1077a358f9ba8617b5177399fa2f44c54bb5a62f7a159d718bb505f",
    "config": {
        "task": {
            "path": "/private/tmp/theory-physics-tm01-harbor/task/tm-01",
            "git_url": null,
            "git_commit_id": null,
            "name": null,
            "ref": null,
            "overwrite": false,
            "download_dir": null,
            "source": null
        },
        "trial_name": "tm-01__dei9EjP",
        "trials_dir": "/private/tmp/theory-physics-tm01-harbor/runs/nop/2026-11-16__11-39-53",
        "install_only": false,
        "timeout_multiplier": 1.0,
        "agent_timeout_multiplier": null,
        "verifier_timeout_multiplier": null,
        "agent_setup_timeout_multiplier": null,
        "environment_build_timeout_multiplier": null,
        "agent": {
            "name": "nop",
            "import_path": null,
            "model_name": null,
            "n_concurrent": null,
            "concurrency_group": null,
            "skills": [],
            "override_timeout_sec": null,
            "override_setup_timeout_sec": null,
            "max_timeout_sec": null,
            "resume_trajectory": false,
            "load_trajectory": null,
            "extra_allowed_hosts": [],
            "kwargs": {},
            "mcp_servers": []
        },
        "user_agent": null,
        "environment": {
            "type": "docker",
            "import_path": null,
            "force_build": false,
            "delete": true,
            "stream": false,
            "cpu_enforcement_policy": "auto",
            "memory_enforcement_policy": "auto",
            "override_cpus": null,
            "override_memory_mb": null,
            "override_storage_mb": null,
            "override_gpus": null,
            "override_tpu": null,
            "mounts": null,
            "extra_docker_compose": [],
            "kwargs": {},
            "extra_allowed_hosts": []
        },
        "verifier": {
            "override_timeout_sec": null,
            "max_timeout_sec": null,
            "disable": false
        },
        "artifacts": [],
        "extra_instruction_paths": [],
        "extra_instructions": [],
        "job_id": "e128b4f4-dd76-407b-ad66-3ffe32b0da6b",
        "source_trial": null
    },
    "agent_info": {
        "name": "nop",
        "version": "1.0.0",
        "model_info": null
    },
    "agent_result": {
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null,
        "model_usage": null,
        "rollout_details": null,
        "metadata": null
    },
    "verifier_result": {
        "rewards": {
            "reward": 0.0
        }
    },
    "verifier_environment_mode": "separate",
    "exception_info": null,
    "started_at": "2026-11-16T03:39:53.853459Z",
    "finished_at": "2026-11-16T03:40:21.438120Z",
    "environment_setup": {
        "started_at": "2026-11-16T03:39:53.902401Z",
        "finished_at": "2026-11-16T03:39:55.985175Z"
    },
    "agent_setup": {
        "started_at": "2026-11-16T03:39:55.985325Z",
        "finished_at": "2026-11-16T03:39:55.985435Z"
    },
    "agent_execution": {
        "started_at": "2026-11-16T03:39:55.985612Z",
        "finished_at": "2026-11-16T03:39:55.986670Z"
    },
    "verifier": {
        "started_at": "2026-11-16T03:40:07.674997Z",
        "finished_at": "2026-11-16T03:40:21.438086Z"
    },
    "step_results": null
}

TASK sp-01
results: ['runs/sp-01/harbor-macos-compat/nop/2026-11-16__12-39-48/result.json', 'runs/sp-01/harbor-macos-compat/nop/2026-11-16__12-39-48/sp-01__7o4J8Sz/result.json', 'runs/sp-01/harbor-macos-compat/oracle/2026-11-16__12-39-48/result.json', 'runs/sp-01/harbor-macos-compat/oracle/2026-11-16__12-39-48/sp-01__ADfJMaH/result.json']
sessions: []

FILE runs/sp-01/harbor-macos-compat/nop/2026-11-16__12-39-48/result.json 
 {
    "id": "4d058162-a4fa-4f19-bd24-4b72ba8842fc",
    "started_at": "2026-11-16T12:39:48.753184",
    "updated_at": "2026-11-16T12:40:16.696649",
    "finished_at": "2026-11-16T12:40:16.696649",
    "n_total_trials": 1,
    "stats": {
        "n_completed_trials": 1,
        "n_errored_trials": 0,
        "n_running_trials": 0,
        "n_pending_trials": 0,
        "n_cancelled_trials": 0,
        "n_retries": 0,
        "evals": {
            "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                    {
                        "mean": 0.0
                    }
                ],
                "pass_at_k": {},
                "reward_stats": {
                    "reward": {
                        "0.0": [
                            "sp-01__7o4J8Sz"
                        ]
                    }
                },
                "exception_stats": {}
            }
        },
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null
    }
}

FILE runs/sp-01/harbor-macos-compat/nop/2026-11-16__12-39-48/sp-01__7o4J8Sz/result.json 
 {
    "id": "3d90731e-f896-4ccc-a071-bb78854770f1",
    "task_name": "theory-physics-bench/sp-01",
    "trial_name": "sp-01__7o4J8Sz",
    "trial_uri": "file:///private/tmp/theory-physics-sp01-harbor.xd66Zv/runs/nop/2026-11-16__12-39-48/sp-01__7o4J8Sz",
    "task_id": {
        "path": "/tmp/theory-physics-sp01-harbor.xd66Zv/sp-01"
    },
    "source": null,
    "task_checksum": "0b230e9cfcba444849eb39463d71afd03d188741546426d3a28f9c5c2cbf6770",
    "config": {
        "task": {
            "path": "/tmp/theory-physics-sp01-harbor.xd66Zv/sp-01",
            "git_url": null,
            "git_commit_id": null,
            "name": null,
            "ref": null,
            "overwrite": false,
            "download_dir": null,
            "source": null
        },
        "trial_name": "sp-01__7o4J8Sz",
        "trials_dir": "/tmp/theory-physics-sp01-harbor.xd66Zv/runs/nop/2026-11-16__12-39-48",
        "install_only": false,
        "timeout_multiplier": 1.0,
        "agent_timeout_multiplier": null,
        "verifier_timeout_multiplier": null,
        "agent_setup_timeout_multiplier": null,
        "environment_build_timeout_multiplier": null,
        "agent": {
            "name": "nop",
            "import_path": null,
            "model_name": null,
            "n_concurrent": null,
            "concurrency_group": null,
            "skills": [],
            "override_timeout_sec": null,
            "override_setup_timeout_sec": null,
            "max_timeout_sec": null,
            "resume_trajectory": false,
            "load_trajectory": null,
            "extra_allowed_hosts": [],
            "kwargs": {},
            "mcp_servers": []
        },
        "user_agent": null,
        "environment": {
            "type": "docker",
            "import_path": null,
            "force_build": false,
            "delete": true,
            "stream": false,
            "cpu_enforcement_policy": "auto",
            "memory_enforcement_policy": "auto",
            "override_cpus": null,
            "override_memory_mb": null,
            "override_storage_mb": null,
            "override_gpus": null,
            "override_tpu": null,
            "mounts": null,
            "extra_docker_compose": [],
            "kwargs": {},
            "extra_allowed_hosts": []
        },
        "verifier": {
            "override_timeout_sec": null,
            "max_timeout_sec": null,
            "disable": false
        },
        "artifacts": [],
        "extra_instruction_paths": [],
        "extra_instructions": [],
        "job_id": "4d058162-a4fa-4f19-bd24-4b72ba8842fc",
        "source_trial": null
    },
    "agent_info": {
        "name": "nop",
        "version": "1.0.0",
        "model_info": null
    },
    "agent_result": {
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null,
        "model_usage": null,
        "rollout_details": null,
        "metadata": null
    },
    "verifier_result": {
        "rewards": {
            "reward": 0.0
        }
    },
    "verifier_environment_mode": "separate",
    "exception_info": null,
    "started_at": "2026-11-16T04:39:48.818135Z",
    "finished_at": "2026-11-16T04:40:16.693116Z",
    "environment_setup": {
        "started_at": "2026-11-16T04:39:48.868698Z",
        "finished_at": "2026-11-16T04:39:51.122721Z"
    },
    "agent_setup": {
        "started_at": "2026-11-16T04:39:51.122827Z",
        "finished_at": "2026-11-16T04:39:51.122907Z"
    },
    "agent_execution": {
        "started_at": "2026-11-16T04:39:51.123050Z",
        "finished_at": "2026-11-16T04:39:51.124079Z"
    },
    "verifier": {
        "started_at": "2026-11-16T04:40:02.809832Z",
        "finished_at": "2026-11-16T04:40:16.693086Z"
    },
    "step_results": null
}

TASK ed-01
results: ['runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/result.json', 'runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/result.json', 'runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs/result.json', 'runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/result.json']
sessions: ['runs/ed-01/harbor-macos-compat/session-20261116-134245.json']
{
  "task_id": "ed-01",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-ed-01-harbor-2hua6kf9/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T05:41:36.634595+00:00",
      "archive": "runs/ed-01/harbor-macos-compat/oracle"
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-ed-01-harbor-2hua6kf9/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T05:42:09.441049+00:00",
      "archive": "runs/ed-01/harbor-macos-compat/nop"
    }
  ]
}


FILE runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/result.json 
 {
    "id": "a606ae29-0400-4fd5-9f9f-f9ca7f43bfa0",
    "task_name": "theory-physics-bench/ed-01",
    "trial_name": "ed-01__x8GVk78",
    "trial_uri": "file:///private/tmp/physics-ed-01-harbor-2hua6kf9/runs/nop/2026-11-16__13-42-10/ed-01__x8GVk78",
    "task_id": {
        "path": "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01"
    },
    "source": null,
    "task_checksum": "d25af280a904992fe5637f6c64e85f081e9cacfc0d9e73c0cf91d2dbf455919a",
    "config": {
        "task": {
            "path": "/tmp/physics-ed-01-harbor-2hua6kf9/ed-01",
            "git_url": null,
            "git_commit_id": null,
            "name": null,
            "ref": null,
            "overwrite": false,
            "download_dir": null,
            "source": null
        },
        "trial_name": "ed-01__x8GVk78",
        "trials_dir": "/tmp/physics-ed-01-harbor-2hua6kf9/runs/nop/2026-11-16__13-42-10",
        "install_only": false,
        "timeout_multiplier": 1.0,
        "agent_timeout_multiplier": null,
        "verifier_timeout_multiplier": null,
        "agent_setup_timeout_multiplier": null,
        "environment_build_timeout_multiplier": null,
        "agent": {
            "name": "nop",
            "import_path": null,
            "model_name": null,
            "n_concurrent": null,
            "concurrency_group": null,
            "skills": [],
            "override_timeout_sec": null,
            "override_setup_timeout_sec": null,
            "max_timeout_sec": null,
            "resume_trajectory": false,
            "load_trajectory": null,
            "extra_allowed_hosts": [],
            "kwargs": {},
            "mcp_servers": []
        },
        "user_agent": null,
        "environment": {
            "type": "docker",
            "import_path": null,
            "force_build": false,
            "delete": true,
            "stream": false,
            "cpu_enforcement_policy": "auto",
            "memory_enforcement_policy": "auto",
            "override_cpus": null,
            "override_memory_mb": null,
            "override_storage_mb": null,
            "override_gpus": null,
            "override_tpu": null,
            "mounts": null,
            "extra_docker_compose": [],
            "kwargs": {},
            "extra_allowed_hosts": []
        },
        "verifier": {
            "override_timeout_sec": null,
            "max_timeout_sec": null,
            "disable": false
        },
        "artifacts": [],
        "extra_instruction_paths": [],
        "extra_instructions": [],
        "job_id": "4fb6476f-8c94-44f5-a416-064f63787172",
        "source_trial": null
    },
    "agent_info": {
        "name": "nop",
        "version": "1.0.0",
        "model_info": null
    },
    "agent_result": {
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null,
        "model_usage": null,
        "rollout_details": null,
        "metadata": null
    },
    "verifier_result": {
        "rewards": {
            "reward": 0.0
        }
    },
    "verifier_environment_mode": "separate",
    "exception_info": null,
    "started_at": "2026-11-16T05:42:10.657456Z",
    "finished_at": "2026-11-16T05:42:37.738756Z",
    "environment_setup": {
        "started_at": "2026-11-16T05:42:10.706124Z",
        "finished_at": "2026-11-16T05:42:12.743013Z"
    },
    "agent_setup": {
        "started_at": "2026-11-16T05:42:12.743117Z",
        "finished_at": "2026-11-16T05:42:12.743191Z"
    },
    "agent_execution": {
        "started_at": "2026-11-16T05:42:12.743327Z",
        "finished_at": "2026-11-16T05:42:12.744315Z"
    },
    "verifier": {
        "started_at": "2026-11-16T05:42:24.380083Z",
        "finished_at": "2026-11-16T05:42:37.738725Z"
    },
    "step_results": null
}

FILE runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/result.json 
 {
    "id": "4fb6476f-8c94-44f5-a416-064f63787172",
    "started_at": "2026-11-16T13:42:10.595571",
    "updated_at": "2026-11-16T13:42:37.742080",
    "finished_at": "2026-11-16T13:42:37.742080",
    "n_total_trials": 1,
    "stats": {
        "n_completed_trials": 1,
        "n_errored_trials": 0,
        "n_running_trials": 0,
        "n_pending_trials": 0,
        "n_cancelled_trials": 0,
        "n_retries": 0,
        "evals": {
            "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                    {
                        "mean": 0.0
                    }
                ],
                "pass_at_k": {},
                "reward_stats": {
                    "reward": {
                        "0.0": [
                            "ed-01__x8GVk78"
                        ]
                    }
                },
                "exception_stats": {}
            }
        },
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null
    }
}

TASK qm-04
results: ['runs/qm-04/harbor-macos-compat/nop/2026-11-16__22-19-31/qm-04__FTmKEyb/result.json', 'runs/qm-04/harbor-macos-compat/nop/2026-11-16__22-19-31/result.json', 'runs/qm-04/harbor-macos-compat/oracle/2026-11-16__22-19-00/qm-04__HUbKwCL/result.json', 'runs/qm-04/harbor-macos-compat/oracle/2026-11-16__22-19-00/result.json']
sessions: ['runs/qm-04/harbor-macos-compat/session-20261116-222001.json']
{
  "task_id": "qm-04",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qm-04-harbor-5tu6nro8/qm-04",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qm-04-harbor-5tu6nro8/qm-04",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qm-04-harbor-5tu6nro8/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:19:00.248994+00:00",
      "archive": "runs/qm-04/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-19-00/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qm-04__HUbKwCL"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qm-04-harbor-5tu6nro8/qm-04",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qm-04-harbor-5tu6nro8/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:19:31.481555+00:00",
      "archive": "runs/qm-04/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-19-31/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qm-04__FTmKEyb"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}


FILE runs/qm-04/harbor-macos-compat/nop/2026-11-16__22-19-31/qm-04__FTmKEyb/result.json 
 {
    "id": "6c141071-2095-4e13-9d0e-e3ab540f90c1",
    "task_name": "theory-physics-bench/qm-04",
    "trial_name": "qm-04__FTmKEyb",
    "trial_uri": "file:///private/tmp/physics-qm-04-harbor-5tu6nro8/runs/nop/2026-11-16__22-19-31/qm-04__FTmKEyb",
    "task_id": {
        "path": "/tmp/physics-qm-04-harbor-5tu6nro8/qm-04"
    },
    "source": null,
    "task_checksum": "96aed117d372c93880906247bdad5a9fc4de50e061e724c5d379d23de4e9eeb2",
    "config": {
        "task": {
            "path": "/tmp/physics-qm-04-harbor-5tu6nro8/qm-04",
            "git_url": null,
            "git_commit_id": null,
            "name": null,
            "ref": null,
            "overwrite": false,
            "download_dir": null,
            "source": null
        },
        "trial_name": "qm-04__FTmKEyb",
        "trials_dir": "/tmp/physics-qm-04-harbor-5tu6nro8/runs/nop/2026-11-16__22-19-31",
        "install_only": false,
        "timeout_multiplier": 1.0,
        "agent_timeout_multiplier": null,
        "verifier_timeout_multiplier": null,
        "agent_setup_timeout_multiplier": null,
        "environment_build_timeout_multiplier": null,
        "agent": {
            "name": "nop",
            "import_path": null,
            "model_name": null,
            "n_concurrent": null,
            "concurrency_group": null,
            "skills": [],
            "override_timeout_sec": null,
            "override_setup_timeout_sec": null,
            "max_timeout_sec": null,
            "resume_trajectory": false,
            "load_trajectory": null,
            "extra_allowed_hosts": [],
            "kwargs": {},
            "mcp_servers": []
        },
        "user_agent": null,
        "environment": {
            "type": "docker",
            "import_path": null,
            "force_build": false,
            "delete": true,
            "stream": false,
            "cpu_enforcement_policy": "auto",
            "memory_enforcement_policy": "auto",
            "override_cpus": null,
            "override_memory_mb": null,
            "override_storage_mb": null,
            "override_gpus": null,
            "override_tpu": null,
            "mounts": null,
            "extra_docker_compose": [],
            "kwargs": {},
            "extra_allowed_hosts": []
        },
        "verifier": {
            "override_timeout_sec": null,
            "max_timeout_sec": null,
            "disable": false
        },
        "artifacts": [],
        "extra_instruction_paths": [],
        "extra_instructions": [],
        "job_id": "303a4d7d-38a4-4e4c-81aa-b3a169cb47fe",
        "source_trial": null
    },
    "agent_info": {
        "name": "nop",
        "version": "1.0.0",
        "model_info": null
    },
    "agent_result": {
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null,
        "model_usage": null,
        "rollout_details": null,
        "metadata": null
    },
    "verifier_result": {
        "rewards": {
            "reward": 0.0
        }
    },
    "verifier_environment_mode": "separate",
    "exception_info": null,
    "started_at": "2026-11-16T14:19:31.996801Z",
    "finished_at": "2026-11-16T14:19:57.794004Z",
    "environment_setup": {
        "started_at": "2026-11-16T14:19:32.026054Z",
        "finished_at": "2026-11-16T14:19:33.785502Z"
    },
    "agent_setup": {
        "started_at": "2026-11-16T14:19:33.785574Z",
        "finished_at": "2026-11-16T14:19:33.785630Z"
    },
    "agent_execution": {
        "started_at": "2026-11-16T14:19:33.785757Z",
        "finished_at": "2026-11-16T14:19:33.786406Z"
    },
    "verifier": {
        "started_at": "2026-11-16T14:19:45.112965Z",
        "finished_at": "2026-11-16T14:19:57.793973Z"
    },
    "step_results": null
}

FILE runs/qm-04/harbor-macos-compat/nop/2026-11-16__22-19-31/result.json 
 {
    "id": "303a4d7d-38a4-4e4c-81aa-b3a169cb47fe",
    "started_at": "2026-11-16T22:19:31.962125",
    "updated_at": "2026-11-16T22:19:57.797426",
    "finished_at": "2026-11-16T22:19:57.797426",
    "n_total_trials": 1,
    "stats": {
        "n_completed_trials": 1,
        "n_errored_trials": 0,
        "n_running_trials": 0,
        "n_pending_trials": 0,
        "n_cancelled_trials": 0,
        "n_retries": 0,
        "evals": {
            "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                    {
                        "mean": 0.0
                    }
                ],
                "pass_at_k": {},
                "reward_stats": {
                    "reward": {
                        "0.0": [
                            "qm-04__FTmKEyb"
                        ]
                    }
                },
                "exception_stats": {}
            }
        },
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null
    }
}

TASK qft-19
results: ['runs/qft-19/harbor-macos-compat/nop/2026-11-16__22-48-29/qft-19__jGLaHvm/result.json', 'runs/qft-19/harbor-macos-compat/nop/2026-11-16__22-48-29/result.json', 'runs/qft-19/harbor-macos-compat/oracle/2026-11-16__22-47-57/qft-19__2DvJRqj/result.json', 'runs/qft-19/harbor-macos-compat/oracle/2026-11-16__22-47-57/result.json']
sessions: ['runs/qft-19/harbor-macos-compat/session-20261116-224859.json']
{
  "task_id": "qft-19",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-19-harbor-4tujm_y7/qft-19",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-19-harbor-4tujm_y7/qft-19",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-19-harbor-4tujm_y7/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:47:57.484625+00:00",
      "archive": "runs/qft-19/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__22-47-57/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-19__2DvJRqj"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-19-harbor-4tujm_y7/qft-19",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-19-harbor-4tujm_y7/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T14:48:29.307194+00:00",
      "archive": "runs/qft-19/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__22-48-29/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-19__jGLaHvm"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}


FILE runs/qft-19/harbor-macos-compat/nop/2026-11-16__22-48-29/qft-19__jGLaHvm/result.json 
 {
    "id": "2a3563b8-5e1f-42f6-9f43-ef71f75d6e4c",
    "task_name": "theory-physics-bench/qft-19",
    "trial_name": "qft-19__jGLaHvm",
    "trial_uri": "file:///private/tmp/physics-qft-19-harbor-4tujm_y7/runs/nop/2026-11-16__22-48-29/qft-19__jGLaHvm",
    "task_id": {
        "path": "/tmp/physics-qft-19-harbor-4tujm_y7/qft-19"
    },
    "source": null,
    "task_checksum": "2080814cc0e054826217a282301ff9d28fd58ebfcbc601c447176d3b2e5a4b4e",
    "config": {
        "task": {
            "path": "/tmp/physics-qft-19-harbor-4tujm_y7/qft-19",
            "git_url": null,
            "git_commit_id": null,
            "name": null,
            "ref": null,
            "overwrite": false,
            "download_dir": null,
            "source": null
        },
        "trial_name": "qft-19__jGLaHvm",
        "trials_dir": "/tmp/physics-qft-19-harbor-4tujm_y7/runs/nop/2026-11-16__22-48-29",
        "install_only": false,
        "timeout_multiplier": 1.0,
        "agent_timeout_multiplier": null,
        "verifier_timeout_multiplier": null,
        "agent_setup_timeout_multiplier": null,
        "environment_build_timeout_multiplier": null,
        "agent": {
            "name": "nop",
            "import_path": null,
            "model_name": null,
            "n_concurrent": null,
            "concurrency_group": null,
            "skills": [],
            "override_timeout_sec": null,
            "override_setup_timeout_sec": null,
            "max_timeout_sec": null,
            "resume_trajectory": false,
            "load_trajectory": null,
            "extra_allowed_hosts": [],
            "kwargs": {},
            "mcp_servers": []
        },
        "user_agent": null,
        "environment": {
            "type": "docker",
            "import_path": null,
            "force_build": false,
            "delete": true,
            "stream": false,
            "cpu_enforcement_policy": "auto",
            "memory_enforcement_policy": "auto",
            "override_cpus": null,
            "override_memory_mb": null,
            "override_storage_mb": null,
            "override_gpus": null,
            "override_tpu": null,
            "mounts": null,
            "extra_docker_compose": [],
            "kwargs": {},
            "extra_allowed_hosts": []
        },
        "verifier": {
            "override_timeout_sec": null,
            "max_timeout_sec": null,
            "disable": false
        },
        "artifacts": [],
        "extra_instruction_paths": [],
        "extra_instructions": [],
        "job_id": "69ec0421-fce0-478e-9889-e55f1f79c52b",
        "source_trial": null
    },
    "agent_info": {
        "name": "nop",
        "version": "1.0.0",
        "model_info": null
    },
    "agent_result": {
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null,
        "model_usage": null,
        "rollout_details": null,
        "metadata": null
    },
    "verifier_result": {
        "rewards": {
            "reward": 0.0
        }
    },
    "verifier_environment_mode": "separate",
    "exception_info": null,
    "started_at": "2026-11-16T14:48:30.148361Z",
    "finished_at": "2026-11-16T14:48:55.832841Z",
    "environment_setup": {
        "started_at": "2026-11-16T14:48:30.180877Z",
        "finished_at": "2026-11-16T14:48:31.775394Z"
    },
    "agent_setup": {
        "started_at": "2026-11-16T14:48:31.775468Z",
        "finished_at": "2026-11-16T14:48:31.775520Z"
    },
    "agent_execution": {
        "started_at": "2026-11-16T14:48:31.775610Z",
        "finished_at": "2026-11-16T14:48:31.776359Z"
    },
    "verifier": {
        "started_at": "2026-11-16T14:48:43.049054Z",
        "finished_at": "2026-11-16T14:48:55.832811Z"
    },
    "step_results": null
}

FILE runs/qft-19/harbor-macos-compat/nop/2026-11-16__22-48-29/result.json 
 {
    "id": "69ec0421-fce0-478e-9889-e55f1f79c52b",
    "started_at": "2026-11-16T22:48:30.104320",
    "updated_at": "2026-11-16T22:48:55.835080",
    "finished_at": "2026-11-16T22:48:55.835080",
    "n_total_trials": 1,
    "stats": {
        "n_completed_trials": 1,
        "n_errored_trials": 0,
        "n_running_trials": 0,
        "n_pending_trials": 0,
        "n_cancelled_trials": 0,
        "n_retries": 0,
        "evals": {
            "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                    {
                        "mean": 0.0
                    }
                ],
                "pass_at_k": {},
                "reward_stats": {
                    "reward": {
                        "0.0": [
                            "qft-19__jGLaHvm"
                        ]
                    }
                },
                "exception_stats": {}
            }
        },
        "n_input_tokens": null,
        "n_cache_tokens": null,
        "n_output_tokens": null,
        "cost_usd": null
    }
}

TOOLS
#!/usr/bin/env python3
"""Run oracle/nop locally and archive raw jobs, including unsuccessful runs."""

import argparse
import datetime
import json
import platform
import re
import shlex
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("task_id")
    parser.add_argument("--macos-compat", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z]+-[0-9]{2}", args.task_id):
        parser.error("invalid task id")
    source = ROOT / "tasks" / args.task_id
    if not source.is_dir():
        parser.error("task directory does not exist")
    harbor = shutil.which("harbor")
    if not harbor:
        raise SystemExit("harbor executable not found")
    # Avoid '%' URL handling in Harbor/Compose, retaining the exact task contents.
    stage = Path(tempfile.mkdtemp(prefix=f"physics-{args.task_id}-harbor-", dir="/tmp"))
    task = stage / args.task_id
    shutil.copytree(source, task, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"))
    if args.macos_compat:
        config = task / "task.toml"
        original = config.read_text(encoding="utf-8")
        needle = 'environment_mode = "separate"\nnetwork_mode = "no-network"'
        if needle not in original:
            raise SystemExit("expected verifier network declaration missing")
        config.write_text(original.replace(needle, 'environment_mode = "separate"\nnetwork_mode = "public"'), encoding="utf-8")
    mode = "harbor-macos-compat" if args.macos_compat else "harbor-linux"
    destination = ROOT / "runs" / args.task_id / mode
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for agent in ("oracle", "nop"):
        jobs = stage / "runs" / agent
        command = [harbor, "run", "-p", str(task), "-a", agent,
                   "--n-attempts", "1", "--n-concurrent", "1", "--max-retries", "0",
                   "--jobs-dir", str(jobs)]
        print("$ " + shlex.join(command), flush=True)
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(command, text=True)
        job_results=sorted(jobs.glob('*/result.json'))
        summaries=[]
        for result_path in job_results:
            payload=json.loads(result_path.read_text(encoding='utf-8'))
            stats=payload.get('stats',{})
            expected=1.0 if agent=='oracle' else 0.0
            evaluations=stats.get('evals',{})
            passed=(stats.get('n_errored_trials')==0 and stats.get('n_completed_trials')==1
                    and len(evaluations)==1)
            for evaluation in evaluations.values():
                passed=passed and evaluation.get('n_trials')==1 and evaluation.get('n_errors')==0
                metrics=evaluation.get('metrics',[])
                passed=passed and len(metrics)==1 and metrics[0].get('mean')==expected
            summaries.append({'result':str(result_path.relative_to(jobs)), 'passed':passed,
                              'expected_reward':expected, 'stats':stats})
        archive = destination / agent
        archive.mkdir(parents=True, exist_ok=True)
        if jobs.exists():
            shutil.copytree(jobs, archive, dirs_exist_ok=True)
        records.append({"agent": agent, "command": command, "returncode": result.returncode,
                        "started_utc": started, "archive": str(archive.relative_to(ROOT)),
                        "verified_results":summaries,
                        "passed":result.returncode==0 and len(summaries)==1 and all(s['passed'] for s in summaries)})
    report = {"task_id": args.task_id, "host": platform.platform(), "temporary_task": str(task),
              "macos_verifier_network_override": args.macos_compat, "runs": records}
    output = destination / ("session-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + ".json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    if any(not record['passed'] for record in records):
        raise SystemExit("Harbor trial/reward verification failed; original jobs have been archived")


if __name__ == "__main__":
    main()


exit_code=0
```

### 2026-11-16T22:52:39.506562+08:00

```bash
python3 -
```

```text
runs/tm-01/harbor-macos-compat/nop/2026-11-16__11-39-53/tm-01__dei9EjP/verifier/metrics.json {
  "reason": "没有有效的 JSON 产物",
  "raw_metric": null,
  "score": 0.0,
  "status": "invalid"
}

runs/tm-01/harbor-macos-compat/oracle/2026-11-16__11-39-32/tm-01__wDBNYhw/verifier/metrics.json {
  "parameter_mape_percent": 0.049706878520401676,
  "hidden_response_nrmse_percent": 0.22223466665888628,
  "location_f1": 1.0,
  "location_penalty_points": 0.0,
  "raw_metric": 0.11871799377579552,
  "score": 1.0,
  "status": "completed"
}

runs/tm-01/harbor-macos-compat/oracle/2026-11-16__11-39-32/config.json keys ['job_name', 'jobs_dir', 'n_concurrent_trials', 'tasks'] agents None
snapshot tm-01 /private/tmp/theory-physics-tm01-harbor/task/tm-01 True
schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/tm-01"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 1200.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "public"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0

runs/ed-01/harbor-macos-compat/nop/2026-11-16__13-42-10/ed-01__x8GVk78/verifier/metrics.json {
  "reason": "没有有效 JSON 产物",
  "raw_metric": null,
  "score": 0.0,
  "status": "invalid"
}

runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/ed-01__chchGjs/verifier/metrics.json {
  "cases": [
    {
      "id": "sphere-01",
      "energy_error": 8.340219451116991e-13,
      "force_error": 6.173561496029185e-12,
      "equilibrium_error": 0.0,
      "raw_metric": 3.070010354002228e-10
    },
    {
      "id": "sphere-02",
      "energy_error": 4.277896436181119e-12,
      "force_error": 3.4446640496609494e-11,
      "equilibrium_error": 2.179580781124902e-12,
      "raw_metric": 1.7434168132362648e-09
    },
    {
      "id": "sphere-03",
      "energy_error": 9.495458267492777e-13,
      "force_error": 8.02929496050864e-12,
      "equilibrium_error": 1.0740624423105235e-13,
      "raw_metric": 3.967005020437346e-10
    }
  ],
  "raw_metric": 8.157061168934074e-10,
  "score": 1.0,
  "status": "completed"
}

runs/ed-01/harbor-macos-compat/oracle/2026-11-16__13-41-37/config.json keys ['jobs_dir', 'n_concurrent_trials', 'tasks'] agents None
snapshot ed-01 /tmp/physics-ed-01-harbor-2hua6kf9/ed-01 True
schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/ed-01"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 1200.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "public"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0

runs/qft-19/harbor-macos-compat/nop/2026-11-16__22-48-29/qft-19__jGLaHvm/verifier/metrics.json {
  "reason": "invalid JSON artifact",
  "raw_metric": null,
  "status": "invalid",
  "score": 0.0
}

runs/qft-19/harbor-macos-compat/oracle/2026-11-16__22-47-57/qft-19__2DvJRqj/verifier/metrics.json {
  "records": [
    {
      "id": "rational-01",
      "error": 2.2932524836781783e-16,
      "parts": [
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.9358361541306403e-16,
        0.0,
        0.0,
        1.4237259750294035e-15,
        1.2052177482419985e-15,
        8.466766352006194e-16,
        0.0,
        0.0
      ]
    },
    {
      "id": "rational-02",
      "error": 2.2431313053116107e-16,
      "parts": [
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        1.139983650557554e-16,
        1.5674775195166372e-16,
        1.2602660094033709e-15,
        1.0390410310090937e-15,
        1.018956931078693e-15,
        0.0,
        0.0
      ]
    },
    {
      "id": "rational-03",
      "error": 2.513384630735985e-16,
      "parts": [
        0.0,
        1.784694934132518e-16,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        2.0953452688588002e-16,
        0.0,
        1.651334341548392e-16,
        0.0,
        1.4190558728880848e-15,
        1.2032402147737134e-15,
        8.459818670618069e-16,
        0.0,
        0.0
      ]
    }
  ],
  "raw_metric": 2.349922806575258e-14,
  "status": "completed",
  "score": 1.0
}

runs/qft-19/harbor-macos-compat/oracle/2026-11-16__22-47-57/config.json keys ['jobs_dir', 'n_concurrent_trials', 'tasks'] agents None
snapshot qft-19 /tmp/physics-qft-19-harbor-4tujm_y7/qft-19 True
schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/qft-19"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 720.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "public"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0

harbor None

exit_code=0
```

### 2026-11-16T22:53:16.962031+08:00

```bash
python3 -
```

```text
/Users/ai4s/.local/share/uv/tools/harbor/bin/harbor
#!/Users/ai4s/.local/share/uv/tools/harbor/bin/python
# -*- coding: utf-8 -*-
import sys
from harbor.cli.main import app
if __name__ == "__main__":
    if sys.argv[0].endswith("-script.pyw"):
        sys.argv[0] = sys.argv[0][:-11]
    elif sys.argv[0].endswith(".exe"):
        sys.argv[0] = sys.argv[0][:-4]
    sys.exit(app())


DIFF tm-01
--- 
+++ 
@@ -26,6 +26,7 @@
 - `/app/data/observations.csv`：列为 `experiment_id,time_s,node_1_m,node_4_m,node_8_m`，包含三次实验在质点 1、4、8 上的含噪位移。
 - `/app/data/mechanics.py`：构造刚度矩阵、计算无阻尼精确响应、读取数据的 NumPy 实现，可以直接导入或修改副本。
 - `/app/data/feedback.py`：公开开发反馈，只计算候选参数对可见含噪观测的拟合误差，不接触隐藏真值。
+- `/app/data/metric.json`：公开主指标配置，包含基线值、专家参考值、指标方向和数值容差。
 
 镜像提供 Python 3.12 和 NumPy 2.1.3。名义刚度只表示未损伤前的工程先验，不等于当前真值。每个当前刚度必须位于其名义值的 `[0.4, 1.1]` 倍范围内；恰有两根弹簧的当前/名义刚度比小于 0.8。
 
@@ -60,7 +61,7 @@
 
 ## 最后交什么
 
-把结果写入 `/app/output/answer.json`。JSON 对象必须包含 `stiffness_n_per_m`（长度为 9 的有限数值数组）和 `softened_springs`（长度为 2 的弹簧编号数组）；可以附上可选字符串字段 `method`。软化位置必须由你对观测数据的辨识结果决定，不能从示例推断。
+把结果写入 `/app/output/answer.json`。JSON 对象必须包含 `stiffness_n_per_m`（长度为 9 的有限数值数组）和 `softened_springs`（长度为 2 的弹簧编号数组）；可以附上可选字符串字段 `method`。
 
 `stiffness_n_per_m` 必须恰有 9 个有限实数并满足公开上下界，其中必须且只能有两项低于相应名义刚度的 0.8 倍。`softened_springs` 必须恰有两个互不相同的整数，范围为 1 到 9，并与刚度数组中低于 0.8 倍名义值的位置一致；顺序不影响评分。`method` 为可选字符串，不参与数值评分。
 
@@ -78,8 +79,8 @@
 综合识别误差 = 0.6 * 参数MAPE + 0.4 * 隐藏响应NRMSE + 10 * (1 - 位置F1)
 ```
 
-单位为百分点，越低越好。简单基线枚举全部损伤位置对，只测试固定软化比例 0.5、0.6、0.7，并按公开观测误差选最优组合；专家参考在相同粗搜索基础上继续做有界连续优化。二者使用相同公开数据、边界和纯 CPU 资源，实测值写在 `/tests/metric.json`，课程统一线性换算使简单基线为 0、专家参考为 1。刚度数组越界、字段缺失、不是恰有两根低于 0.8 倍名义值，或位置标签与刚度矛盾，均为无效产物，得分 0。最终验证解决的是这个固定反演实例，不会在提交后增加新约束。
+单位为百分点，越低越好。简单基线枚举全部损伤位置对，只测试固定软化比例 0.5、0.6、0.7，并按公开观测误差选最优组合；专家参考在相同粗搜索基础上继续做有界连续优化。二者使用相同公开数据、边界和纯 CPU 资源，实测值写在 `/app/data/metric.json`，课程统一线性换算使简单基线为 0、专家参考为 1。刚度数组越界、字段缺失、不是恰有两根低于 0.8 倍名义值，或位置标签与刚度矛盾，均为无效产物，得分 0。最终验证解决的是这个固定反演实例，不会在提交后增加新约束。
 
 ## 时间与资源
 
-Agent 探索与作答上限 1200 秒，评分上限 120 秒。环境提供 4 个 CPU、4 GB 内存和 4 GB 磁盘，无需 GPU。参考解在普通 CPU 上只处理 8 自由度矩阵；首次构建镜像不计入求解时间。
+Agent 探索与作答上限 720 秒，评分上限 120 秒。环境提供 4 个 CPU、4 GB 内存和 4 GB 磁盘，无需 GPU。参考解在普通 CPU 上只处理 8 自由度矩阵；首次构建镜像不计入求解时间。


DIFF ed-02
--- 
+++ 
@@ -89,4 +89,4 @@
 
 ## 时间与资源
 
-4 CPU、4 GiB内存、4 GiB磁盘、0 GPU。Agent时限1200秒，独立 verifier时限120秒。全部角谱数据已公开，求解不需要联网、模型权重或额外实验设备。
+4 CPU、4 GiB内存、4 GiB磁盘、0 GPU。Agent时限720秒，独立 verifier时限120秒。全部角谱数据已公开，求解不需要联网、模型权重或额外实验设备。


DIFF qm-04
--- 
+++ 
@@ -10,7 +10,7 @@
 
 ## 探索反馈
 
-可从物理近似及收敛检查开始，运行`python3 /app/data/feedback.py /app/output/answer.json`检查完整ID、有限数值及向量长度。该反馈不含标准答案；归一化、守恒量、参数极限可提供进一步物理自检。`model.json`的fields明确向量顺序。
+可从物理近似及收敛检查开始，运行`python3 /app/data/feedback.py /app/output/answer.json`检查完整ID、有限数值及向量长度，并报告本题可公开推得的物理必要条件（详见反馈中的meaning）。该反馈不含标准答案，必要条件通过不代表数值正确。`model.json`的fields明确向量顺序。
 
 ## 最终产物
 


DIFF qft-20
--- 
+++ 
@@ -55,4 +55,4 @@
 
 `metric.json` 保存实测基线与专家参考端点，课程原版 `quality_score.py` 用 `(raw-baseline)/(reference-baseline)` 截断到[0,1]，失败或非法产物为0。这里参考验证是题包开发检查，不是课程统一Codex三次正式测评。
 
-Agent资源：4CPU、4GiB、0GPU、1200秒；verifier为隔离环境、无网络、120秒。可运行 `python3 /app/data/feedback.py /app/output/answer.json` 检查格式。
+Agent资源：4CPU、4GiB、0GPU、720秒；verifier为隔离环境、无网络、120秒。可运行 `python3 /app/data/feedback.py /app/output/answer.json` 检查格式。


exit_code=0
```

### 2026-11-16T22:53:44.548854+08:00

```bash
rg -n 'def.*checksum|task_checksum|def.*hash' /Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/harbor/models/task
```

```text
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/harbor/models/task/task.py:217:    def checksum(self) -> str:

exit_code=0
```

### 2026-11-16T22:54:02.787275+08:00

```bash
python3 -
```

```text
        return extra_instructions

    def _append_extra_instructions(self, instruction: str) -> str:
        return "\n\n".join([instruction, *self._extra_instructions])

    @property
    def has_steps(self) -> bool:
        return bool(self.config.steps)

    def step_instruction(self, step_name: str) -> str:
        path = self.paths.step_instruction_path(step_name)
        return self._append_extra_instructions(
            strip_canary(path.read_text()),
        )

    @property
    def checksum(self) -> str:
        """Generate a deterministic hash for the task based on its entire directory content.

        This property will be deprecated soon. Use ``TrialLock.task.digest`` from
        the trial lock when you need the durable content hash for a task.
        """
        warnings.warn(
            "Task.checksum will be deprecated soon. Use TrialLock.task.digest "
            "from the trial lock when you need the task content hash.",
            DeprecationWarning,
            stacklevel=2,
        )
        from dirhash import dirhash

        return dirhash(self._task_dir, "sha256")

    @property
    def task_dir(self) -> Path:
        """Public accessor for the task directory."""
        return self._task_dir
runs/tm-01/harbor-macos-compat/oracle/2026-11-16__11-39-32/config.json {
    "job_name": "2026-11-16__11-39-32",
    "jobs_dir": "/private/tmp/theory-physics-tm01-harbor/runs/oracle",
    "n_concurrent_trials": 1,
    "tasks": [
        {
            "path": "/private/tmp/theory-physics-tm01-harbor/task/tm-01"
        }
    ]
}
runs/qft-19/harbor-macos-compat/oracle/2026-11-16__22-47-57/config.json {
    "jobs_dir": "/tmp/physics-qft-19-harbor-4tujm_y7/runs/oracle",
    "n_concurrent_trials": 1,
    "tasks": [
        {
            "path": "/tmp/physics-qft-19-harbor-4tujm_y7/qft-19"
        }
    ]
}

exit_code=0
```

### 2026-11-16T22:54:25.162207+08:00

```bash
/Users/ai4s/.local/share/uv/tools/harbor/bin/python -
```

```text
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py
def dirhash(
    directory,
    algorithm,
    match=("*",),
    ignore=None,
    linked_dirs=True,
    linked_files=True,
    empty_dirs=False,
    entry_properties=("name", "data"),
    allow_cyclic_links=False,
    chunk_size=2**20,
    jobs=1,
):
    """Computes the hash of a directory based on its structure and content.

    # Arguments
        directory: Union[str, pathlib.Path] - Path to the directory to hash.
        algorithm: str - The name of the hashing algorithm to use. See
            `dirhash.algorithms_available` for the available options.
        match: Iterable[str] - An iterable of glob/wildcard match-patterns for paths
            to include when computing the hash. Default is ["*"] which means that all
            files and directories are matched.  To e.g. only include python source
            files, use: `match=["*.py"]`. See "Path Selection and Filtering" section
            below for further details.
        ignore: Optional[Iterable[str]] - An iterable of glob/wildcard match-patterns
            for paths to ignore when computing the hash. Default `None` (no ignore
            patterns). To e.g. exclude hidden files and directories use:
            `ignore=[".*/", ".*"]`. See "Path Selection and Filtering" section below
            for further details.
        linked_dirs: bool - If `True` (default), follow symbolic links to other
            *directories* and include these and their content in the hash
            computation.
        linked_files: bool - If `True` (default), include symbolic linked files in
            the hash computation.
        empty_dirs: bool - If `True`, include empty directories when computing the
            hash. A directory is considered empty if it does not contain any files
            that *matches provided matching criteria*. Default `False`, i.e. empty
            directories are ignored (as is done in git version control).
        entry_properties: Iterable[str] - A set (i.e. order does not matter) of the
            file/directory properties to consider when computing the hash. Supported
            properties are {"name", "data", "is_link"} where at least one of
            "name" and "data" must be included. Default is ["name", "data"] which
            means that the content (actual data) as well as the path relative to the
            root `directory` of files will affect the hash value. See "Entry
            Properties Interpretation" section below for further details.
        allow_cyclic_links: bool - If `False` (default) a `SymlinkRecursionError` is
            raised on presence of cyclic symbolic links. If set to `True` the the
            dirhash value for directory causing the cyclic link is replaced with the
            hash function hexdigest of the relative path from the link to the target.
        chunk_size: int - The number of bytes to read in one go from files while
            being hashed. A too small size will slow down the processing and a larger
            size consumes more working memory. Default 2**20 byte = 1 MiB.
        jobs: int - The number of processes to use when computing the hash.
            Default `1`, which means that a single (the main) process is used. NOTE
            that using multiprocessing can significantly speed-up execution, see
            `https://github.com/andhus/dirhash-python/benchmark` for further
            details.

    # Returns
        str - The hash/checksum as a string of the hexadecimal digits (the result of
        `hexdigest` method of the hashlib._hashlib.HASH object corresponding to the
        provided `algorithm`).

    # Raises
        TypeError/ValueError: For incorrectly provided arguments.
        SymlinkRecursionError: In case the `directory` contains symbolic links that
            lead to (infinite) recursion and `allow_cyclic_links=False` (default).

    # Path Selection and Filtering
        Provided glob/wildcard (".gitignore style") match-patterns determine what
        paths within the `directory` to include when computing the hash value. Paths
        *relative to the root `directory`* (i.e. excluding the name of the root
        directory itself) are matched against the patterns.
            The `match` argument represent what should be *included* - as opposed
        to the `ignore` argument for which matches are *excluded*. Using `ignore` is
        just short for adding the same patterns to the `match` argument with the
        prefix "!", i.e. the calls bellow are equivalent:
            `dirhash(..., match=["*", "!<pattern>"])`
            `dirhash(..., ignore=["<pattern>"])`
        To validate which paths are included, call `dirhash.included_paths` with
        the same values for the arguments: `match`, `ignore`, `linked_dirs`,
        `linked_files` and `empty_dirs` to get a list of all paths that will be
        included when computing the hash by this function.

    # Entry Properties Interpretation
        - ["name", "data"] (Default) - The name as well as data is included. Due to
            the recursive nature of the dirhash computation, "name" implies that the
            path relative to the root `directory` of each file/directory affects the
            computed hash value.
        - ["data"] - Compute the hash only based on the data of files -
            *not* their names or the names of their parent directories. NOTE that
            the tree structure in which files are organized under the `directory`
            root still influences the computed hash. As longs as all files have
            the same content and are organised the same way in relation to all
            other files in the Directed Acyclic Graph representing the file-tree,
            the hash will remain the same (but the "name of nodes" does not
            matter). This option can e.g. be used to verify that that data is
            unchanged after renaming files (change extensions etc.).
        - ["name"] - Compute the hash only based on the name and location of
            files in the file tree under the `directory` root. This option can
            e.g. be used to check if any files have been added/moved/removed,
            ignoring the content of each file.
        - "is_link" - if this options is added to any of the cases above the
            hash value is also affected by whether a file or directory is a
            symbolic link or not. NOTE: with this property added, the hash
            will be different than without it even if there are no symbolic links
            in the directory.

    # References
        See https://github.com/andhus/dirhash/README.md for a formal
        description of how the returned hash value is computed.
    """
    filter_ = Filter(
        match_patterns=get_match_patterns(match=match, ignore=ignore),
        linked_dirs=linked_dirs,
        linked_files=linked_files,
        empty_dirs=empty_dirs,
    )
    protocol = Protocol(
        entry_properties=entry_properties, allow_cyclic_links=allow_cyclic_links
    )
    return dirhash_impl(
        directory=directory,
        algorithm=algorithm,
        filter_=filter_,
        protocol=protocol,
        chunk_size=chunk_size,
        jobs=jobs,
    )

Traceback (most recent call last):
  File "<stdin>", line 5, in <module>
AttributeError: module 'dirhash' has no attribute '_dirhash'. Did you mean: 'dirhash'?

exit_code=1
```

### 2026-11-16T22:54:41.496991+08:00

```bash
rg -n 'class Protocol|def.*hash|def.*digest|file_hash|directory_hash|property' /Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash
```

```text
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:32:def dirhash(
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:136:            symbolic link or not. NOTE: with this property added, the hash
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:163:def dirhash_impl(
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:267:        file_hashes = _parmap(
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:275:        real_path_to_hash = dict(zip(real_paths, file_hashes))
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:410:class Protocol:
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:437:                symbolic link or not. NOTE: which this property added, the hash
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:453:    _entry_property_separator = "\000"
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:495:        return cls._entry_property_separator.join(sorted(entry_strings))
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:497:    def _get_entry_properties(self, path, entry_hash):
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:524:def _get_hasher_factory(algorithm):
/Users/ai4s/.local/share/uv/tools/harbor/lib/python3.12/site-packages/dirhash/__init__.py:560:def _get_filehash(filepath, hasher_factory, chunk_size, cache=None):

exit_code=0
```

### 2026-11-16T22:54:55.276438+08:00

```bash
python3 -
```

```text
            directories to consider when computing the hash value.
        chunk_size: int - The number of bytes to read in one go from files while
            being hashed. A too small size will slow down the processing and a larger
            size consumes more working memory. Default 2**20 byte = 1 MiB.
        jobs: int - The number of processes to use when computing the hash.
            Default `1`, which means that a single (the main) process is used. NOTE
            that using multiprocessing can significantly speed-up execution, see
            `https://github.com/andhus/dirhash/tree/master/benchmark` for further
            details.

    # Returns
        str - The hash/checksum as a string of the hexadecimal digits (the result of
        `hexdigest` method of the hashlib._hashlib.HASH object corresponding to the
        provided `algorithm`).

    # Raises
        TypeError/ValueError: For incorrectly provided arguments.
        SymlinkRecursionError: In case the `directory` contains symbolic links that
            lead to (infinite) recursion and the protocol option `allow_cyclic_links`
            is `False`.

    # References
        See https://github.com/andhus/dirhash/README.md for a formal
        description of how the returned hash value is computed.
    """

    def get_instance(value, cls_, argname):
        if isinstance(value, cls_):
            return value
        if value is None:
        _DIRHASH = "dirhash"

    _entry_property_separator = "\000"
    _entry_descriptor_separator = "\000\000"

    def __init__(self, entry_properties=("name", "data"), allow_cyclic_links=False):
        entry_properties = set(entry_properties)
        if not entry_properties.issubset(self.EntryProperties.options):
            raise ValueError(
                f"entry properties {entry_properties - self.EntryProperties.options} "
                "not supported"
            )
        if not (
            self.EntryProperties.NAME in entry_properties
            or self.EntryProperties.DATA in entry_properties
        ):
            raise ValueError(
                "at least one of entry properties `name` and `data` must be used"
            )
        self.entry_properties = entry_properties
        self._include_name = self.EntryProperties.NAME in entry_properties
        self._include_data = self.EntryProperties.DATA in entry_properties
        self._include_is_link = self.EntryProperties.IS_LINK in entry_properties

        if not isinstance(allow_cyclic_links, bool):
            raise ValueError(
                f"allow_cyclic_link must be a boolean, got {allow_cyclic_links}"
            )
        self.allow_cyclic_links = allow_cyclic_links

    def get_descriptor(self, dir_node):
        if isinstance(dir_node, CyclicLinkedDir):
            return self._get_cyclic_linked_dir_descriptor(dir_node)

        entries = dir_node.directories + dir_node.files
        entry_descriptors = [
            self._get_entry_descriptor(self._get_entry_properties(path, entry_hash))
            for path, entry_hash in entries
        ]
        return self._entry_descriptor_separator.join(sorted(entry_descriptors))

    @classmethod
    def _get_entry_descriptor(cls, entry_properties):
        entry_strings = [f"{name}:{value}" for name, value in entry_properties]
        return cls._entry_property_separator.join(sorted(entry_strings))

    def _get_entry_properties(self, path, entry_hash):
        properties = []
        if path.is_dir():
            properties.append((self.EntryProperties._DIRHASH, entry_hash))
        elif self._include_data:  # path is file
            properties.append((self.EntryProperties.DATA, entry_hash))

        if self._include_name:
            properties.append((self.EntryProperties.NAME, path.name))
        if self._include_is_link:
            properties.append((self.EntryProperties.IS_LINK, path.is_symlink))

        return properties

    def _get_cyclic_linked_dir_descriptor(self, dir_node):
        relpath = dir_node.path.relative
        target_relpath = dir_node.target_path.relative
        path_to_target = os.path.relpath(
            # the extra '.' is needed if link back to root, because
            # an empty path ('') is not supported by os.path.relpath
            os.path.join(".", target_relpath),
            os.path.join(".", relpath),
        )
        # TODO normalize posix!
        return path_to_target


def _get_hasher_factory(algorithm):

exit_code=0
```

### 2026-11-16T22:57:19.810485+08:00

```bash
/Users/ai4s/.local/share/uv/tools/harbor/bin/python -
```

```text

### 2026-11-16T22:57:19.810485+08:00

```bash
python3 tools/collect_release_evidence.py
```

```text
tm-01 {'portable_matches_dirhash': True, 'matches_trial': True}
ed-01 {'portable_matches_dirhash': True, 'matches_trial': True}
qft-19 {'portable_matches_dirhash': True, 'matches_trial': True}

exit_code=0
```
{
  "task_count": 50,
  "verified_count": 46,
  "needs_rerun": [
    "ed-04",
    "qft-05",
    "qm-01",
    "tm-01"
  ],
  "all_verified": false
}

exit_code=0
```

### 2026-11-16T22:58:05.173563+08:00

```bash
python3 -
```

```text
ed-04 no compatible successful oracle/nop snapshot pair
errors: ['final package has unapproved changes since run']
differences: [{'path': 'instruction.md', 'snapshot_sha256': '609ec8e5d9ee94aa764ce3cf162a909c3d4c9ab073b39cfb5718d29991878422', 'final_sha256': '2ac4b61086d4379b8cf6fd28d89d089b11391feb4234313e343dc9d2b3c64110', 'permitted': False, 'reasons': ['material/code/data/metric/feedback or unapproved instruction change; rerun required']}, {'path': 'task.toml', 'snapshot_sha256': 'a84bb876383261c3533c2af77dbfd0e8e0d28d9723fc458e3bfa24af9f571b7b', 'final_sha256': 'e24e5fd1a9ce7954100456d1581fa94d44e3085165bf7b11417971097e0e45c1', 'permitted': True, 'reasons': ['macOS verifier public override; final package no-network', 'agent deadline reduced 1200 to 720 seconds; no formal-model timing claim']}]
qft-05 no compatible successful oracle/nop snapshot pair
errors: ['final package has unapproved changes since run']
differences: [{'path': 'environment/public/feedback.py', 'snapshot_sha256': '9ede4c66b603b488968f3d93fcd33c01a3dca47d0597e0c18beddd22f82c3957', 'final_sha256': 'f402e35d75708d7a23a8e6e010caa45752439e04b092338f464afb13cf4b357e', 'permitted': False, 'reasons': ['material/code/data/metric/feedback or unapproved instruction change; rerun required']}, {'path': 'instruction.md', 'snapshot_sha256': '9ad875cfcab67df96b35cc94ad3b53c9ec9aef7186081b97410fac30a2c0c9a2', 'final_sha256': '5cc3fc75dbca7e80c00b31389173ae482fe6086d0dc0441144040c7c1d30df37', 'permitted': False, 'reasons': ['material/code/data/metric/feedback or unapproved instruction change; rerun required']}, {'path': 'solution/README.md', 'snapshot_sha256': 'c5f295ca21c685f5244bfcc3f0025556448e53e2e5d4c03a70bb0b268b959096', 'final_sha256': '26016fb9692879385d6e1be775b1cc64b039e8d95c0176c36f39c421e756315d', 'permitted': True, 'reasons': ['reference derivation documentation only']}, {'path': 'task.toml', 'snapshot_sha256': '7c7722004eeeacaca1bafcd675b028bab62acc22f0eb1d6970d3684ed466498b', 'final_sha256': '8de7545538f37c6f7a25842e05eebbe7fb012dac05dc1ff07904bda27dbbe7c4', 'permitted': True, 'reasons': ['macOS verifier public override; final package no-network']}]
qm-01 no compatible successful oracle/nop snapshot pair
errors: ['final package has unapproved changes since run']
differences: [{'path': 'instruction.md', 'snapshot_sha256': '7ad166b6f06728c97103f466572cbe30ede43a207333115b7ab0d2b12ac103cf', 'final_sha256': 'a0bbf3e9e29b2c3a93387af98efc192020be348ca68a334ddbc00504b2a27aaa', 'permitted': True, 'reasons': ['instruction deadline synchronized 1200 to 720 seconds only']}, {'path': 'task.toml', 'snapshot_sha256': 'c39a8724f58e0d53fa8611898caccd46a6c1cbc136e1d69b4dc18bfc9e9fb2e0', 'final_sha256': '0359c7cb0a0437efa0474ea4f8a0025976d9abf47f0dc6cf5c2d9a4f04cb73d0', 'permitted': True, 'reasons': ['macOS verifier public override; final package no-network', 'agent deadline reduced 1200 to 720 seconds; no formal-model timing claim']}, {'path': 'tests/quality_score.py', 'snapshot_sha256': 'f34bd88e72b98fae68d34a1a00498b1e4f1fec07f4fe24c8fcbe1c9880964298', 'final_sha256': '797343b693d5676a4bd0dd13a8270038d2f879bcb41f863ec87563ead807def4', 'permitted': False, 'reasons': ['material/code/data/metric/feedback or unapproved instruction change; rerun required']}]
tm-01 no compatible successful oracle/nop snapshot pair
errors: ['final package has unapproved changes since run']
differences: [{'path': 'environment/public/metric.json', 'snapshot_sha256': None, 'final_sha256': 'ee8bbf52c55a1b39bc32f8d97304288d5b92605ab85ec4e49d71882a1edcbf0a', 'permitted': False, 'reasons': ['material/code/data/metric/feedback or unapproved instruction change; rerun required']}, {'path': 'instruction.md', 'snapshot_sha256': 'bc95fc2799dab2cc33f5c3308ee78d60b485e133005903af495dfd784bb077ce', 'final_sha256': '37551552d56e68fab9c131d52fcb14b2d9ab43eaff531ddd4e772f7d46fd1461', 'permitted': False, 'reasons': ['material/code/data/metric/feedback or unapproved instruction change; rerun required']}, {'path': 'solution/README.md', 'snapshot_sha256': None, 'final_sha256': '2db82297b47ba75b5141ea72a3032eee6df61126188d6636e494c2ec079f7679', 'permitted': False, 'reasons': ['material/code/data/metric/feedback or unapproved instruction change; rerun required']}, {'path': 'task.toml', 'snapshot_sha256': 'f0c5757c04d222814b2a3ac514694ff21a674cbde380f433e31a71a9af3238e5', 'final_sha256': 'dde1b517f3f7ceb4beddbcf0de3681836217557e8294f4eba7faa5a7bcabc1a9', 'permitted': True, 'reasons': ['macOS verifier public override; final package no-network', 'agent deadline reduced 1200 to 720 seconds; no formal-model timing claim']}, {'path': 'tests/metric.json', 'snapshot_sha256': '5b4195e76bbb6037909c297cc652ed7287b43e2963f515fb6a40502224c1cf7d', 'final_sha256': 'ee8bbf52c55a1b39bc32f8d97304288d5b92605ab85ec4e49d71882a1edcbf0a', 'permitted': False, 'reasons': ['material/code/data/metric/feedback or unapproved instruction change; rerun required']}]

exit_code=0
```

### 2026-11-16T22:59:33.008064+08:00

```bash
python3 tools/collect_release_evidence.py
```

```text
{
  "task_count": 50,
  "verified_count": 47,
  "needs_rerun": [
    "ed-04",
    "qm-01",
    "tm-01"
  ],
  "all_verified": false
}

exit_code=0
```

### 2026-11-16T22:59:33.639310+08:00

```bash
python3 -
```

```text
{"portable_without_tmp": true, "current_errors_match_rerun_list": true, "final_hash_tamper_detected": true, "raw_evidence_hash_tamper_detected": true, "needs_rerun": ["ed-04", "qm-01", "tm-01"]}

exit_code=0
```
