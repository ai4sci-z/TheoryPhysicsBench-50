# sp-01 校准与运行记录

日期：2026-11-16。

## Linux 数值与评分校准

环境：Docker Linux aarch64，Python 3.12.13，NumPy 2.1.3，SciPy 1.14.1，mpmath 1.3.0；4 CPU、4 GB、断网。

| 提交 | 原始匹配误差/百分点 | 课程质量分 |
|---|---:|---:|
| 四阶 Landau 基线 | 3.108217863074369 | 0 |
| 完整平均场参考解 | 9.49440819944354e-14 | 1 |
| 改变工况和驻点顺序 | 与参考相同 | 1 |
| 漏报一个分支 | 4.166666666666761 | 0 |
| 重复一个分支 | 2.510078186522987 | 0.192438143946504 |
| 全部分类错误 | 25.000000000000096 | 0 |
| 缺项、重复工况、布尔数值、磁化越界 | 无效 | 0 |

13 项检查全部通过，实际 verifier 入口的参考解得 1、无答案文件得 0。基线耗时 0.2358 秒，参考解 0.2233 秒。详细记录见 [校准 JSON](sp-01-calibration.json)。

独立验证值使用 70 位 mpmath 二分求根；八个工况根数依次为 3、3、3、3、1、1、1、3，最大驻点残差小于 1e-70。见 [高精度记录](sp-01-truth-validation.json)。

## Harbor 0.24.0

单次、单并发、无重试，两次运行均无异常：

| Agent | Reward | 总耗时 | 原始记录 |
|---|---:|---:|---|
| oracle | 1 | 29 秒 | `runs/sp-01/harbor-macos-compat/oracle/2026-11-16__12-39-48/` |
| nop | 0 | 27 秒 | `runs/sp-01/harbor-macos-compat/nop/2026-11-16__12-39-48/` |

临时目录 `/tmp/theory-physics-sp01-harbor.xd66Zv/sp-01` 避开课程路径中的百分号；仅临时副本的 verifier 网络改为 `public` 兼容 Docker Desktop，正式配置仍为 `no-network`。直接数值校准使用 Docker `--network none`。

## 复现命令

在项目根目录运行：

```bash
docker build -t theory-physics-sp01:dev tasks/sp-01/environment
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 \
  --env PYTHONDONTWRITEBYTECODE=1 --env OPENBLAS_NUM_THREADS=1 \
  --mount "type=bind,source=$PWD,target=/work" --workdir /work \
  theory-physics-sp01:dev python tools/build_sp01_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 \
  --env PYTHONDONTWRITEBYTECODE=1 --env OPENBLAS_NUM_THREADS=1 \
  --mount "type=bind,source=$PWD,target=/work" --workdir /work \
  theory-physics-sp01:dev python tools/run_sp01_checks.py
```

主动重新登记端点时追加 `--calibrate`。课程指定 Codex 的三次正式运行在题集冻结后统一执行。
