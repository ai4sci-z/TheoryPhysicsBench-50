# qm-03 本地 Linux 验收记录

## 题包与环境

已完成 `tasks/qm-03/` 中的中文题面、Harbor 配置、固定依赖环境、公开模型与反馈、七平面波简单基线、精确判别式参考解与推导、评分器、课程原版质量换算函数、私有独立真值、校准指标。

本题为双原子 δ 周期晶格，要求最低三条 Bloch 能带的带边，以及有限周期环前两条带的全部 Bloch 扇区能级。四工况共同构成一道题，覆盖排斥势、吸引负能窄带、对称晶胞折叠闭隙和轻微不对称开隙。与 qm-01 孤立束缚态和 qm-02 开放系统散射有不同的周期边界条件及物理目标。

实际平台：Mac 本地 Docker Desktop Linux，`Linux-6.12.76-linuxkit-aarch64-with-glibc2.36`，Python 3.12.13，4CPU、4GB、0GPU。镜像 `theory-physics-qm03:dev` 已构建，基础镜像 digest 与依赖版本固定。未连接远程服务器。

## 实测结果

| 对象 | 原始误差（百分点，越低越好） | 质量分 | 单次时间 |
|---|---:|---:|---:|
| 七平面波 Galerkin 基线 | 47.98481408329696 | 0 | 0.051 秒 |
| 精确判别式与括根参考 | 6.392264439989367e-12 | 1 | 0.164 秒 |

原始指标容差为 `1e-5` 百分点。参考误差低于该容差。时间为含 Python 启动的本地 Linux 实测，不是被测模型正式作答时间。

独立真值采用 60 位 mpmath 精度，直接构造自由传播与 δ 跃变矩阵，逐项相乘并解析求导；不导入参考核心、不读取参考输出。生成耗时 4.69 秒。最大带边残差约 `7.34e-58`，最大有限环 Bloch 残差约 `8.92e-58`，最大矩阵行列式残差约 `1.60e-56`。这些残差是高精度计算内部诊断，参考解与独立物理表示的一致性另由实际主指标核对。

关键分支实际结果：

- `crystal-02` 的前两条带均严格低于零；第一带范围约 `[-20.259665234162124, -20.249778722131452]`。
- `crystal-03` 的第一、二带在 `6.8390226269161` 接触，闭合带隙为零；两个带号均保留。
- `crystal-04` 的第一带隙约 `0.6140466178826278`，对称性破缺后重新打开。

## 检查结果

16 项检查全部通过：参考与独立真值一致、参考改善基线、端点注册一致、基线0/参考1、合法重排不改分、合法错误解失分、负能带保留、漏负能带失分、折叠闭隙、破缺开隙、伪造折叠带隙失分、有限环错误失分、无效产物拒绝、真实 verifier 入口参考1/缺文件0、公开反馈可用、课程质量函数逐字节相同。

其中合法错误解实测原始误差分别为：整体能量错误100，漏负能带15.0，伪造折叠带隙约1.0723，有限环能量错误约19.1204。工况、带、扇区重排与参考解得到完全相同的主指标。重复扇区、布尔能量、无穷值和空对象均判无效。

最终镜像重建后，无项目挂载的干净容器成功运行起步反馈命令。`crystal-01` 在 `E=5` 的判别式为 `-2.380280293448318`、矩阵行列式残差0，返回禁带诊断。

## 复现

完整实际命令与输出见 `checks/qm-03-command-log.md`。核心入口：

```bash
docker build -t theory-physics-qm03:dev tasks/qm-03/environment
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-qm03:dev python tools/build_qm03_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-qm03:dev python tools/run_qm03_checks.py
```

首次校准加 `--calibrate`；冻结后的端点复核不加。原始结果位于 `checks/qm-03-calibration.json`、`checks/qm-03-truth-validation.json`；开发输出位于 `checks/qm-03-development-answers/`。

## 尚未进行

Harbor oracle/nop 由主代理统一补跑；课程指定 Codex 的三次正式测评尚未运行。本记录没有把参考代码运行当作正式模型结果。
