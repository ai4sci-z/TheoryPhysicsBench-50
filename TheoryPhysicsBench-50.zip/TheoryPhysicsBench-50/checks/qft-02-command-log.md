
### 2026-11-16T15:55:04.479009+08:00

```bash
pdftoppm -f 128 -l 129 -scale-to 1400 -png '/Users/ai4s/Downloads/量子场论试题详解（凡人看得懂的量子场论  非211高校适用）.pdf' tmp/pdfs/qft02-source
```

```text
Fontconfig error: Cannot load default config file: File not found

exit_code=0
```

### 2026-11-16T16:12:22.968451+08:00

```bash
docker build -t theory-physics-qft02:dev tasks/qft-02/environment
```

```text
#0 building with "desktop-linux" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile: 458B done
#1 DONE 0.0s

#2 [internal] load metadata for mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#2 DONE 0.0s

#3 [internal] load .dockerignore
#3 transferring context: 69B done
#3 DONE 0.0s

#4 [1/5] FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#4 resolve mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2 done
#4 DONE 0.0s

#5 [internal] load build context
#5 transferring context: 4.36kB done
#5 DONE 0.0s

#6 [2/5] COPY requirements.txt /tmp/requirements.txt
#6 CACHED

#7 [3/5] RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt  && useradd --uid 1000 --create-home student  && mkdir -p /app/data /app/output  && chown -R student:student /app
#7 CACHED

#8 [4/5] COPY public/ /app/data/
#8 DONE 0.0s

#9 [5/5] WORKDIR /app
#9 DONE 0.0s

#10 exporting to image
#10 exporting layers 0.0s done
#10 exporting manifest sha256:52d9f68ef122293c55fa31bbd9dcef1a99ee5542dbcc026c93eee9b14e4cf4db done
#10 exporting config sha256:c62e184f0e545d5f0b52b37be51383519f166a211c742e9df8c0135088249d7b done
#10 exporting attestation manifest sha256:dd945495131f364b48e91b7f9c0dd37774d9497880e670e0eab977135219386a done
#10 exporting manifest list sha256:797b173358d9f697c59214747cdc542becb4a5ed445fba8dae896482b2a835ff done
#10 naming to docker.io/library/theory-physics-qft02:dev done
#10 unpacking to docker.io/library/theory-physics-qft02:dev 0.0s done
#10 DONE 0.1s

exit_code=0
```

### 2026-11-16T16:12:56.710198+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qft02:dev python tools/build_qft02_truth.py
```

```text

### 2026-11-16T16:15:45.736620+08:00

```bash
cat tools/build_qft02_truth.py
```

```text
"""Independent high-precision three-body phase-space integration."""
import json
from pathlib import Path
import mpmath as mp

ROOT = Path(__file__).resolve().parents[1]
TASK = ROOT / 'tasks/qft-02'


def solve_case(case):
    mp.mp.dps = 70
    M, m1, m2, m3 = [mp.mpf(str(case[key])) for key in ('M', 'm1', 'm2', 'm3')]
    mr, gamma = mp.mpf(str(case['mr'])), mp.mpf(str(case['gamma']))
    g0 = mp.mpc(str(case['g0'][0]), str(case['g0'][1]))
    g1 = mp.mpc(str(case['g1'][0]), str(case['g1'][1]))
    low, high = (m1 + m2) ** 2, (M - m3) ** 2
    span, center, scale = high - low, mr ** 2, mr * gamma

    def integrand(theta, coherent=True):
        s = low + span * mp.sin(theta) ** 2
        first = (M ** 2 - (mp.sqrt(s) + m3) ** 2) * (M ** 2 - (mp.sqrt(s) - m3) ** 2)
        second = (s - (m1 + m2) ** 2) * (s - (m1 - m2) ** 2)
        pole = g1 / mp.mpc(s - center, scale)
        squared = abs(g0 + pole) ** 2 if coherent else abs(g0) ** 2 + abs(pole) ** 2
        return mp.sqrt(max(mp.mpf('0'), first * second)) / s * squared * 2 * span * mp.sin(theta) * mp.cos(theta)

    knots = [mp.mpf('0'), mp.pi / 2]
    for offset in (-100, -10, -1, 0, 1, 10, 100):
        s = center + offset * scale
        if low < s < high:
            knots.append(mp.asin(mp.sqrt((s - low) / span)))
    knots = sorted(set(knots))

    def integral(top, coherent=True):
        cuts = [t for t in knots if t < top] + [top]
        return sum(mp.quad(lambda t: integrand(t, coherent), [a, b]) for a, b in zip(cuts[:-1], cuts[1:]))

    total, incoherent = integral(mp.pi / 2), integral(mp.pi / 2, False)
    quantiles = []
    for probability in (mp.mpf('.1'), mp.mpf('.5'), mp.mpf('.9')):
        lo, hi = mp.mpf('0'), mp.pi / 2
        for _ in range(220):
            middle = (lo + hi) / 2
            if integral(middle) / total < probability:
                lo = middle
            else:
                hi = middle
        angle = (lo + hi) / 2
        quantiles.append(low + span * mp.sin(angle) ** 2)
    return {
        'id': case['id'],
        'width': total / (256 * mp.pi ** 3 * M ** 3),
        'interference_fraction': (total - incoherent) / incoherent,
        's10': quantiles[0], 's50': quantiles[1], 's90': quantiles[2],
    }


def main():
    model = json.loads((TASK / 'environment/public/model.json').read_text(encoding='utf-8'))
    truth = {'cases': []}
    for case in model['cases']:
        value = solve_case(case)
        truth['cases'].append({key: (float(value[key]) if key != 'id' else value[key]) for key in value})
    private = TASK / 'tests/private/truth.json'
    private.parent.mkdir(parents=True, exist_ok=True)
    private.write_text(json.dumps(truth, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(truth, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()

exit_code=0
```

### 2026-11-16T16:16:43.403896+08:00

```bash
docker stop 8e7f3d9c73f1
```

```text
{
  "cases": [
    {
      "id": "decay-01",
      "width": 0.00026704890681306294,
      "interference_fraction": 0.22015577644280482,
      "s10": 4.125512128716601,
      "s50": 4.851264629181131,
      "s90": 11.564636433187957
    },
    {
      "id": "decay-02",
      "width": 0.00025560998585788265,
      "interference_fraction": 0.0010725635740509451,
      "s10": 2.248417691875967,
      "s50": 7.739682429422242,
      "s90": 16.01646091175395
    },
    {
      "id": "decay-03",
      "width": 4.316295490308466e-09,
      "interference_fraction": -0.24089848222354457,
      "s10": 2.2565855732959075,
      "s50": 2.2661109100771606,
      "s90": 2.2748495746100335
    },
    {
      "id": "decay-04",
      "width": 8.478638806490778e-06,
      "interference_fraction": -0.7432210055514523,
      "s10": 2.4480338959036554,
      "s50": 6.506884253901149,
      "s90": 9.066223632073955
    }
  ]
}
8e7f3d9c73f1

exit_code=0
```

exit_code=0
```

### 2026-11-16T16:19:42.822250+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qft02:dev python tools/build_qft02_truth.py
```

```text
decay-01 independent integration passed
decay-02 independent integration passed
decay-03 independent integration passed
decay-04 independent integration passed
{
  "cases": [
    {
      "id": "decay-01",
      "width": 0.00026704890681306294,
      "interference_fraction": 0.22015577644280482,
      "s10": 4.125512128716601,
      "s50": 4.851264629181131,
      "s90": 11.564636433187957
    },
    {
      "id": "decay-02",
      "width": 0.00025560998585788265,
      "interference_fraction": 0.0010725635740509451,
      "s10": 2.248417691875967,
      "s50": 7.739682429422242,
      "s90": 16.01646091175395
    },
    {
      "id": "decay-03",
      "width": 4.316295490308466e-09,
      "interference_fraction": -0.24089848222354457,
      "s10": 2.2565855732959075,
      "s50": 2.2661109100771606,
      "s90": 2.2748495746100335
    },
    {
      "id": "decay-04",
      "width": 8.478638806490778e-06,
      "interference_fraction": -0.7432210055514523,
      "s10": 2.4480338959036554,
      "s50": 6.506884253901149,
      "s90": 9.066223632073955
    }
  ]
}

exit_code=0
```

### 2026-11-16T16:20:38.070938+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qft02:dev python tools/run_qft02_checks.py --calibrate
```

```text
{
  "metric": {
    "kind": "continuous",
    "metric_name": "三体衰变相空间、共振干涉与分位数误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 3.0457292903105952,
    "reference": 6.877470144682901e-13,
    "tolerance": 1e-06
  },
  "scores": {
    "baseline": {
      "raw_metric": 3.0457292903105952,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 6.877470144682901e-13,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 6.877470144682901e-13,
      "score": 1.0,
      "status": "completed"
    },
    "wrong": {
      "raw_metric": 45.849314273964154,
      "score": 0.0,
      "status": "completed"
    },
    "missing_resonance": {
      "raw_metric": 45.88407044675661,
      "score": 0.0,
      "status": "completed"
    },
    "incoherent": {
      "raw_metric": 18.884070446756848,
      "score": 0.0,
      "status": "completed"
    },
    "duplicate": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "nonfinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "malformed": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "independent_truth": {
      "raw_metric": 0.0,
      "score": 1.0,
      "status": "completed"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.03813062500000797,
    "reference_seconds": 0.24977670900000248
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_improves_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "equivalent_order_same": true,
    "independent_truth_full_credit": true,
    "wrong_solution_penalized": true,
    "missing_resonance_penalized": true,
    "incoherent_interference_penalized": true,
    "invalid_answers_rejected": true,
    "verifier_reference_one_empty_zero": true,
    "public_feedback_works": true,
    "course_quality_score_unchanged": true
  }
}

exit_code=0
```

### 2026-11-16T16:25:01.651821+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qft02:dev python tools/build_qft02_truth.py
```

```text
decay-01 independent integration passed
decay-02 independent integration passed
decay-03 independent integration passed
decay-04 independent integration passed
{
  "cases": [
    {
      "id": "decay-01",
      "width": 0.00026704890681306294,
      "interference_fraction": 0.22015577644280482,
      "s10": 4.125512128716601,
      "s50": 4.851264629181131,
      "s90": 11.564636433187957
    },
    {
      "id": "decay-02",
      "width": 0.00025560998585788265,
      "interference_fraction": 0.0010725635740509451,
      "s10": 2.248417691875967,
      "s50": 7.739682429422242,
      "s90": 16.01646091175395
    },
    {
      "id": "decay-03",
      "width": 4.316295490308466e-09,
      "interference_fraction": -0.24089848222354457,
      "s10": 2.2565855732959075,
      "s50": 2.2661109100771606,
      "s90": 2.2748495746100335
    },
    {
      "id": "decay-04",
      "width": 8.478638806490778e-06,
      "interference_fraction": -0.7432210055514523,
      "s10": 2.4480338959036554,
      "s50": 6.506884253901149,
      "s90": 9.066223632073955
    }
  ]
}

exit_code=0
```

### 2026-11-16T16:26:20.827300+08:00

```bash
python3 tools/run_harbor_local_checks.py qft-02 --macos-compat
```

```text
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-02-harbor-2lh6f48o/qft-02 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-02-harbor-2lh6f48o/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-02-harbor-2lh6f48o/runs/oracle/2026-11-16__16-26-21/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-02-harbor-2lh6f48o/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qft-02-harbor-2lh6f48o/runs/oracle/2026-11-16__16-26-21`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qft-02-harbor-2lh6f48o/qft-02 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qft-02-harbor-2lh6f48o/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qft-02-harbor-2lh6f48o/runs/nop/2026-11-16__16-26-50/result.json
Inspect results by running `harbor view 
/tmp/physics-qft-02-harbor-2lh6f48o/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qft-02-harbor-2lh6f48o/runs/nop/2026-11-16__16-26-50`

{
  "task_id": "qft-02",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qft-02-harbor-2lh6f48o/qft-02",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-02-harbor-2lh6f48o/qft-02",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-02-harbor-2lh6f48o/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T08:26:20.863689+00:00",
      "archive": "runs/qft-02/harbor-macos-compat/oracle",
      "verified_results": [
        {
          "result": "2026-11-16__16-26-21/result.json",
          "passed": true,
          "expected_reward": 1.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "oracle__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 1.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "1.0": [
                      "qft-02__QVbm8Gm"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qft-02-harbor-2lh6f48o/qft-02",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qft-02-harbor-2lh6f48o/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T08:26:50.366900+00:00",
      "archive": "runs/qft-02/harbor-macos-compat/nop",
      "verified_results": [
        {
          "result": "2026-11-16__16-26-50/result.json",
          "passed": true,
          "expected_reward": 0.0,
          "stats": {
            "n_completed_trials": 1,
            "n_errored_trials": 0,
            "n_running_trials": 0,
            "n_pending_trials": 0,
            "n_cancelled_trials": 0,
            "n_retries": 0,
            "evals": {
              "nop__adhoc": {
                "n_trials": 1,
                "n_errors": 0,
                "metrics": [
                  {
                    "mean": 0.0
                  }
                ],
                "pass_at_k": {},
                "reward_stats": {
                  "reward": {
                    "0.0": [
                      "qft-02__dWaXhcK"
                    ]
                  }
                },
                "exception_stats": {}
              }
            },
            "n_input_tokens": null,
            "n_cache_tokens": null,
            "n_output_tokens": null,
            "cost_usd": null
          }
        }
      ],
      "passed": true
    }
  ]
}

exit_code=0
```
