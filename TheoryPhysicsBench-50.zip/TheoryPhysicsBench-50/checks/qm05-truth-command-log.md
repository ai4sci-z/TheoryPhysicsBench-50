
### 2026-11-16T22:09:25.635398+08:00

```bash
docker run --rm --cpus 4 --memory 4g --network none --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/workspace' -w /workspace theory-physics-qft04:dev python3 tools/build_qm05_truth.py
```

```text
[
  {
    "id": "well-01",
    "mesh_difference": 1.9466650513777495e-12,
    "grid_sizes": [
      2200,
      3000
    ],
    "stencil_order": 8
  },
  {
    "id": "well-02",
    "mesh_difference": 1.5694112676101213e-12,
    "grid_sizes": [
      2200,
      3000
    ],
    "stencil_order": 8
  },
  {
    "id": "well-03",
    "mesh_difference": 1.7843504451775516e-12,
    "grid_sizes": [
      2200,
      3000
    ],
    "stencil_order": 8
  },
  {
    "id": "well-04",
    "mesh_difference": 8.433254095052689e-13,
    "grid_sizes": [
      2200,
      3000
    ],
    "stencil_order": 8
  },
  {
    "id": "well-05",
    "mesh_difference": 7.8026474170656e-13,
    "grid_sizes": [
      2200,
      3000
    ],
    "stencil_order": 8
  },
  {
    "id": "well-06",
    "mesh_difference": 6.188383139260623e-13,
    "grid_sizes": [
      2200,
      3000
    ],
    "stencil_order": 8
  },
  {
    "id": "well-07",
    "mesh_difference": 1.035171948160496e-12,
    "grid_sizes": [
      2200,
      3000
    ],
    "stencil_order": 8
  }
]

exit_code=0
```
