# gr-03 数值与评分验证

2026-11-16，本地 Docker Linux aarch64、Python3.12.13、NumPy2.1.3、SciPy1.14.1、mpmath1.3.0，4CPU、4GB、断网、0GPU。数值复用镜像 `theory-physics-ed01:dev`，依赖与本题一致。

|产物|原始误差（百分点）|质量分|程序耗时|
|---|---:|---:|---:|
|Newton/零偏差基线|73.77142297495756|0|0.04879秒|
|完整参考|9.778272072498907e-12|1|0.04156秒|
|等价顺序|9.778272072498907e-12|1|检查内|
|实质错解|85|0|检查内|
|漏一条分支|3.7500000000097335|0.94917|检查内|
|重复一条分支|2.500000000009749|0.96611|检查内|
|丢弃不稳定模负号|4.90333391889086|0.93353|检查内|
|混淆时间参数|4.551162940339232|0.93831|检查内|

14项检查全部通过：课程函数摘要、独立真值匹配、参考改善、端点一致、基线0/参考1、顺序等价、实质错解、漏态、多态、频率符号、时间参数、非法格式、实际test.sh参考/空提交入口、公开反馈。完整记录 `checks/gr-03-calibration.json`。原始指标容差1e-5。

独立75位有效势验证：分支数量0/0/1/2/2/2/2/2；正规方程残差小于3.30e-74，驻点残差小于2.08e-75，四速度归一化残差小于1.11e-75。ISCO二阶导数在高精度阈值内为零。真值用多项式根和有效势自动高精度导数，不导入参考闭式频率核心。原始数据 `checks/gr-03-truth-validation.json`。

Harbor oracle/nop 尚未在此子任务执行，由主流程统一运行。课程正式三次Codex结果尚未运行；外部相近benchmark检索在冻结前补。上述参考数值不是正式智能体测评成绩。

复核时运行：

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-ed01:dev python tools/build_gr03_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount "type=bind,source=$PWD,target=/work" -w /work theory-physics-ed01:dev python tools/run_gr03_checks.py
```
