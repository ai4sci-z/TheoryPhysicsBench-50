
### 2026-11-16T18:24:15.059143+08:00

```bash
rg --files planning -g '*expansion*review*'
```

```text
planning/qft-expansion-gelis-thermal-review.md
planning/qft-expansion-radovanovic-review.md

exit_code=0
```
