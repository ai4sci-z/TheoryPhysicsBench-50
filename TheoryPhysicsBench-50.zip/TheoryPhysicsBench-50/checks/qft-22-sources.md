# QFT-22：中心对称、有限体积扇区混合与 Polyakov 环


来源：François Gelis, *Problems in Quantum Field Theory*, 第72题；用户PDF实际页171–175，书页293–297。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与材料

Gelis 第72题说明纯规范理论的中心变换、Polyakov 环及基本表示物质的显式破缺。本题把它改造成**精确定义的中心有效模型**；这些数据不能用来声称真实 QCD 的临界温度。

首先，`chains` 给出四个不对易的 SU(3) 时间连接 \(U_0,\ldots,U_3\)，每个矩阵元素编码为 `[real,imag]`，最早时间的 \(U_0\) 作用在最右边。holonomy 为 \(W=U_3U_2U_1U_0\)，\(L=\operatorname{tr}W/3\)。中心扭曲 `twist=k` 令 \(W\to z^kW\)，\(z=e^{2\pi i/3}\)。`matter_nalities` 给出物质表示的 N-ality，只有对所有物质均满足 \(z^{kn}=1\) 的中心元素仍是对称性。

第二，`ensembles` 是完全图上的三态中心模型。体积 \(N\) 的每个格点 \(s_i\in\{0,1,2\}\)，\(L=N^{-1}\sum_i z^{s_i}\)。用占据数 \(n_0+n_1+n_2=N\) 表示，每个具体构型的无量纲 Boltzmann 权重为
\[
 w(s)=\exp\left[\frac{J}{2N}(n_0^2+n_1^2+n_2^2)+hN\operatorname{Re}L\right].
\]
同一占据数组合有 \(N!/(n_0!n_1!n_2!)\) 个具体构型。`h=0` 的有限体系包含全部中心扇区，禁止先挑一个扇区再报全系综均值。

对有限 \(N\)，定义
\(M_2=\langle|L|^2\rangle\)、\(U=1-\langle|L|^4\rangle/(2M_2^2)\)、
\(C_{\ne}=\langle z^{s_i-s_j}\rangle_{i\ne j}\)，以及每点对数配分函数 \(\log Z/N\)。其中 \(C_{\ne}\) 是不同点之间的平均相关，不能把自相关1混入。

热力学判据公开定义如下。令 \(x_j=n_j/N\)、\(\ell=\sum_jx_jz^j\)，全局极小化
\[
 f(x)=\sum_{j=0}^2x_j\log x_j-\frac J2\sum_jx_j^2-h\operatorname{Re}\ell,
\quad x_j\ge0,\ \sum_jx_j=1.
\]
`phase_code=0` 表示 \(h=0\) 且全局极小为均匀分布；`1` 表示 \(h=0\) 且有三个中心相关的非均匀全局极小（有限体积的扇区混合有序分布）；`2` 表示 \(h\ne0\) 的显式破缺。输入避开严格共存点。`thermodynamic_order_squared=|ell_min|^2`；三扇区在 \(h=0\) 时给相同模平方。**均值为零不是本题唯一的物相判据。**

## 必须交付

每个 `系综ID-V体积` 行的 `values` 依次为
`[Re<L>,Im<L>,M2,C_distinct,U,logZ/N,phase_code,thermodynamic_order_squared,f_min]`。

每个 `chains` ID 行的 `values` 依次为
`[Re L,Im L,Re(z^k L),Im(z^k L),keep_k0,keep_k1,keep_k2]`，三个 `keep` 是数值0或1。

任务要求同时完成精确有限系综统计、热力学全局极小判断、路径次序和残余中心。不得把这个显式给定有效模型的结论直接外推成完整 Yang–Mills 或含轻夸克 QCD 的结论。


## 验证路线

参考解按三态占据数枚举组合并使用log-sum-exp处理配分函数；精确矩关系给C_distinct=(N M2-1)/(N-1)。热力学最小化可利用一个中心扇区的对称参数x=((1+2r)/3,(1-r)/3,(1-r)/3)，搜全驻点后比自由能，而不是只取局部极小。输入J、h范围内该参数化覆盖物理解；原始自由能是公开定义的真值对象。

独立真值以Python整数二项式组合构造权重，不复用gammaln路线；N=12额外穷举全部3^12构型检查M2。热力学真值直接在二维概率单纯形从均匀及三个有序扇区搜索，独立于一维驻点方程。holonomy用四个显式群指标收缩核对矩阵连乘。

基线采用精确有限统计与群乘积，但直接把有限全系综|<L>|²当热力学序参量、用-logZ/N估计无限体积自由能，并以|<L>|是否超过0.1判断h=0的物相。这个统一的有限体积起点在扇区混合有序情形失败，尚未处理全局极小与极限次序；不掺入无关的路径次序错误。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。
