## 记录器启用前的只读命令

以下命令已在当时的 commentary 显式展示，现补记到统一日志；前两次交接检索未匹配，第三次找到交接文件。

```bash
rg --files planning | rg 'qm02|qm-02|work-order'
rg --files planning | rg 'qm02|qm-02|work-order'
rg --files planning | rg 'qm02|qm-02|work-order|implementation-qm'
cat planning/work-order-qm02.md
rg -n '势垒|透射|穿透|隧穿|传输' planning/source-notes/qm-sol-all.txt | head -60
cat '/Users/ai4s/.codex/plugins/cache/openai-primary-runtime/pdf/26.1112.11217/skills/pdf/SKILL.md'
```

### 2026-11-16T14:16:37.355192+08:00

```bash
python3 -c 'from pathlib import Path; print(Path('"'"'tools/run_logged.py'"'"').read_text()); print(Path('"'"'tasks/qm-01/instruction.md'"'"').read_text()); print(Path('"'"'tasks/qm-01/tests/score.py'"'"').read_text())'
```

```text
"""Print and save the exact local command, its output and exit code."""
import argparse
from datetime import datetime
from pathlib import Path
import shlex
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--log', default='checks/session-command-log.md')
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command:
    parser.error('a command is required after --')
path = Path(args.log)
path.parent.mkdir(parents=True, exist_ok=True)
heading = f"\n### {datetime.now().astimezone().isoformat()}\n\n```bash\n{shlex.join(command)}\n```\n\n```text\n"
with path.open('a', encoding='utf-8') as log:
    log.write(heading)
    log.flush()
    print(shlex.join(command), flush=True)
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    for line in process.stdout:
        print(line, end='', flush=True)
        log.write(line)
        log.flush()
    code = process.wait()
    log.write(f'\nexit_code={code}\n```\n')
sys.exit(code)

# 非对称双 δ 势阱的束缚态与空间局域化

## 研究问题

考虑一维非对称吸引势

\[
V(x)=-g_L\delta(x+a)-g_R\delta(x-a),\qquad a,g_L,g_R>0,
\]

单位取 \(\hbar=m=1\)。题目给出八组阱间距和左右阱强度。对每组参数，找出所有可归一化束缚态，报告能量及归一化态落在左半轴的概率 \(P_L=\int_{-\infty}^0|\psi(x)|^2dx\)。束缚态必须满足 \(E<0\)；零能量阈值解不属于束缚态。

该问题测试如何由 δ 势的波函数连续性、导数跃变和无穷远衰减条件确定束缚谱。不同强度和间距会改变弱束缚支是否存在；对称阱可用于检查左右概率，对非对称阱则需量化态的局域化。

## 公开材料与单位

- `/app/data/model.json`：每个工况唯一字符串 `id`，以及 `a`、`g_left`、`g_right`。长度单位与能量单位按 \(\hbar=m=1\) 的无量纲约定。
- `/app/data/physics.py`：读入模型、定义去除零能伪根因子的匹配残差、校验输出格式。
- `/app/data/feedback.py`：计算提交能量处的公开匹配残差；对称势还返回 \(P_L-1/2\)。
- `/app/data/metric.json`：公开指标及实测基线、参考端点。

最小读取示例：

```python
import sys
sys.path.insert(0, "/app/data")
from physics import load_model, matching_residual
case = load_model()["cases"][0]
print(case, matching_residual(-0.2, case))
```

## 探索和物理反馈

令束缚能量 \(E=-\kappa^2/2\)，\(\kappa>0\)。在两个 δ 点外，波函数是指数函数的线性组合。积分薛定谔方程得到

\[
\psi'(x_i^+)-\psi'(x_i^-)=-2g_i\psi(x_i).
\]

匹配条件可写成二乘二的 Birman–Schwinger 本征值方程

\[
\kappa\mathbf v=
\begin{pmatrix}
g_L&\sqrt{g_Lg_R}e^{-2a\kappa}\\
\sqrt{g_Lg_R}e^{-2a\kappa}&g_R
\end{pmatrix}\mathbf v.
\]

两条特征值支都要检查，且只接受严格正的 \(\kappa\)。矩阵的行列式会在 \(\kappa=0\) 带有阈值因子；不能把它产生的零能根当作束缚态。

把尝试写入最终输出格式后运行：

```bash
python /app/data/feedback.py /app/output/trial.json
```

该命令返回格式检查、匹配残差和可用的对称性诊断，不列出完整正确谱，不计最终得分。可以使用矩阵本征值支、波函数分段匹配、根区间分析或独立数值积分探索。公开反馈次数不限。

## 最终产物

提交 `/app/output/answer.json`，根对象包含 `cases` 数组，每个工况恰好一项：

```json
{"cases":[{"id":"well-01","states":[
  {"energy":-0.5,"left_probability":0.5}
]}]}
```

每项 `states` 是全部不同束缚态的列表，字段 `energy` 是严格负的有限数，`left_probability` 是 \([0,1]\) 内有限数。工况顺序及同一工况内态顺序不限；每工况可提交 1 至 4 个态。不得遗漏或重复工况。可附加字符串 `method`，不参与评分。

## 评分指标

验证器按能量和左半轴概率，将提交态与独立验证态作最小代价一对一匹配。每对的代价为

\[
c=0.65\min\!\left(1,\frac{|E-\hat E|}{\max(|\hat E|,10^{-6})}\right)
+0.35|P_L-\hat P_L|.
\]

未配对态的代价为 1。单工况误差为 \(100\sum c/\max(n_{提交},n_{真值})\)，总指标为八组工况误差的算术平均，单位百分点，越低越好。该计分同时惩罚漏态、多报和态量不准；仅能级接近不足以通过局域化检查。

简单基线把两阱视为互不耦合的孤立 δ 阱，使用 \(E_i=-g_i^2/2\) 和孤立阱归一态的左概率。参考解包含两阱耦合并精确积分其态密度。两者使用同一公开数据与资源。无效 JSON、工况缺失/重复、非有限值、非负能量或概率越界均无效并得分 0；物理数值错误但格式合法按实际误差评分。

## 时间与资源

Agent 1200 秒，verifier 120 秒，4 CPU、4 GB 内存、4 GB 磁盘、0 GPU。所有工况固定且公开；评分不增加隐藏物理约束。

import json
import os
import sys
from pathlib import Path
import numpy as np
from scipy.optimize import linear_sum_assignment
from quality_score import quality_score


def evaluate(answer, data_root=None, private_root=None):
    data = Path(data_root or os.environ.get("TASK_DATA_ROOT", "/app/data"))
    private = Path(private_root or os.environ.get("TASK_PRIVATE_ROOT", "/tests/private"))
    sys.path.insert(0, str(data))
    from physics import load_model, validate_answer
    states, reason = validate_answer(answer, load_model(data))
    if reason:
        return None, {"reason": reason}
    truth = json.loads((private/"truth.json").read_text(encoding="utf-8"))
    details = []
    for case in truth["cases"]:
        predicted, expected = states[case["id"]], case["states"]
        size = max(len(predicted), len(expected))
        costs = np.ones((size, size))
        for i, p in enumerate(predicted):
            for j, q in enumerate(expected):
                energy_error = min(1.0, abs(p["energy"]-q["energy"])/max(abs(q["energy"]), 1e-6))
                probability_error = abs(p["left_probability"]-q["left_probability"])
                costs[i, j] = 0.65*energy_error+0.35*probability_error
        rows, cols = linear_sum_assignment(costs)
        raw = 100*float(np.sum(costs[rows, cols]))/size
        details.append({"id": case["id"], "submitted_count": len(predicted), "expected_count": len(expected), "raw_metric": raw})
    return sum(item["raw_metric"] for item in details)/len(details), {"cases": details}


def main():
    logs = Path(os.environ.get("VERIFIER_LOG_ROOT", "/logs/verifier"))
    tests = Path(os.environ.get("TASK_TESTS_ROOT", "/tests"))
    output = Path(os.environ.get("TASK_ANSWER_PATH", "/app/output/answer.json"))
    logs.mkdir(parents=True, exist_ok=True)
    metric = json.loads((tests/"metric.json").read_text(encoding="utf-8"))
    try:
        answer = json.loads(output.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        raw, details = None, {"reason": "没有有效的 JSON 产物"}
    else:
        raw, details = evaluate(answer)
    status = "invalid" if raw is None else "completed"
    score = quality_score(metric, raw, status)
    details.update(raw_metric=raw, score=score, status=status)
    (logs/"metrics.json").write_text(json.dumps(details, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    (logs/"reward.txt").write_text(f"{score}\n", encoding="utf-8")


if __name__ == "__main__":
    main()


exit_code=0
```

### 2026-11-16T14:18:11.698038+08:00

```bash
python3 -c 'from pathlib import Path; s=Path('"'"'planning/source-notes/qm-sol-all.txt'"'"').read_text().splitlines(); print('"'"'\n'"'"'.join(s[3250:3500])); print('"'"'\n'"'"'.join(s[4990:5190]))'
```

```text
(PDFÑ'ËõÆ÷ - Î'x[2áºæ)
题解
mao
ка=20 =
或者
K=¥2mlEl
mo
-=
左
在这个表达式中势阱宽度a不出现，a-0并不影响这个式子。这样
E＝ー
2左
这同教材2.5节中8势阱情况一样。
习题 2.32
推导出式 2.167:B=i
sin(2la)
2kl
（P-R）F和式 2.168:P=
e
-Zika A
(k+K)
。提示：用式2.165:Csin（la）+ Deos（la） = Fe* 和式 2.166：
cos(2la) - і
-sin (2la)
2kl
I［ Ccos（la） -Dsin（la）］=ikFe™求出用『表示的C和D：
C= sin(la) +i
-cos (la) eitaF,
k
D= cos(la) - i
, sin(la) eiha F
然后代人到式2.163: Ae M +Beta = - Csin（la） +Dcos（la）和式2.164: ih（Ae-lha - Bewd） =
I［ Ccos（la）+ Dsin（la）］中。求出透射系数、验证式2.169。
解：当E＞0时，一维有限深势阱散射态的解是
Ae"* + Be -iks
¢（×）=
Csin (lx) + Dcos(lx)
Feikt
(x<-a)
(-a<x <a)
(a <x)
其中
V2mE
k=
v2m(E+V)
有，
方
由波函数及其导数在x=士a处的连续性，有
Ae-le + Be™a = - Csin（la） + Dcos（la）（教材中式 2.163）
L
Ae-ika - Beika
［Ccos（la）+Dsin（la）］（教材中式2.164）
Csin （la） + Dcos（la） = Fele（教材中式2.165）
1 Ccos（la） - Dsin（la）］=ikFe™（教材中式2.166）
由前两个式子相加相减可以得到
B=% | - ((¼C0(a) +an(a) -미(m(a) -c0(a)]
用 sin（la）乘以式2.165，cos（la）乘以式2.166后，两式相加得到
59

===== PDF PAGE 66 =====
(PDFÑ'ËõÆ÷ - Îx[2áºæ)
第2章 定态薛定谔方程
C= re*/[ sin(la) + *, cos( la)]
用 cos（la）乘以式2.165，sin（la）乘以式2.166后，两式相减得到
D=Petl coe（1a）-丝sin（la）
把C，D的表达式代人A，B的表达式
A=
*, cos(la) + sin(la) ( Ecos(la) - sin(la)) +
cos(la) -
-sin(la)-
P2(2( co (la) → sin (1a) +2 ( L *)cos(1a) sin(a)])
= Fe*ka/ cos(2/a) - L (E + k° )sin (2la)]
Ae-ika
所以
cos (2la) - →
- (P +k) sin(2la)
- ika
b=
- Fie'( kcos(la) + sin(la) ( i cos( la) + sin(la)) -
re**/ co(la) - ",sin(la) ( isin(la) - cos( la))]
=！sin（210）（ピー8）P
透射系数（的倒数）为
T-'=
代人
cos (2la) - ; sin(2la)
2kl
- (K +P)"
sin (2la)
= cos (2la) +
-(k +1)2
(2kl)2
= 1 - sin (2la) +
sin (2la) (12 +P)=
(2kl)2
=1 + sin (2la)
[ (1+l) -1 =1 +sin (2la) (12 -B)?
(2kl)2
(2kl)2
k=
2mE
[=V2m(E+ Vo)
有
60

===== PDF PAGE 67 =====
(PDFÑ'ËõÆ÷ - Î'x[2áºæ)
题解
2a2m(E+V,)
2la =—
h
Kº -P = -
2mVo
邡
（-2ml/な）”
4(2mE/R7)[2m(E+V)/#]
4E(E +Vo)
4E(E +Vo)
sin (n(2m(E+VoJ)
(k -[)2
（2kl）2
所以
T-=1 +
这与教材中的式2.169一致。
＊＊刃題2.33求出矩形勢全的透射系数（与式2.145 相似，只不辻在ーαくさくa区域
V（x）= +V>0）。按E<Y，E=Y。和E>V。三种情况来分开处理（注意：在三种情况下，
势垒区中的波函数是不同的）。部分答案：对于E<V，
T- =1 +
4E(Vo -E)
sinli（分v2m（%一回）
解：定态薛定方程为
t du
=By
（x< a）
2m dx?
tr d'u
-+Vy=B（-a<xca）
2m de?
(x>a)
2m dx?
1.EくV。的情況
薛定湂方程的解㐧
Aei+ Be-iks (x<-a)
* (x) =Ce** + De**
(-a<x<a)
Feit*
(x>a)
其中
V2mE
v2m（Vo-E）
k=
hi
ー，KE
左
并且已经假设在x＞a时只有透射波。
由波函数及其导数在x=土a处的连续性，有
Ae-la + Bele = Ce-xe + Dema
Ae-W-Bele =B（Ce-ma_ Dema）
Ce*ª + De-Kº = Fela
B( Ce*a -De-**) = Feika
其中
61

===== PDF PAGE 68 =====
(PDFÑ'ËõÆ÷ - Î'x[<áºæ)
第2章 定态薛定方程
B=-
ik
由前两式解出
2Ae-ka = （1 +B） Ce-m + （1-B） Dem
由后两式解出
2Ce** = (1 +1/B) Feka,2De-** = (1 - 1/B) Feika
由此得到入射波振幅A与透射波振幅F的关系，
2Ae-ika =
2 (1+B) (1 +1/B)e-=*• Fel* + = (1 -B) (1 - 1/B) e* Fea
=Fe
(2+B +1/B) e-2ка
2
2
-（2-B-1/B）820
= Feika [2cosh(2ка) - (B +1/B) sinh (2ка) ]
=Ko/2coh(2ka) +i 2 - 1 sinh (2ka)|
kк
所以
T-'=
= cosh (2кa) + (k° - 2
sinh' (2кa)
2kK
=1+ 1+
(2x )Jinti (20a)
(к + k°)2
=1+
-sinh (2ка)
4k° к°
=1+
4E(VD - B) sinhi (3a V2m(Vo -E))
2.E=V。的情况
薛定谔方程的解为
-Ael +Be-w（x<-a）
（x）= C+Dx
（ a<x<a）
Fels
(x>a)
由波函数及其导数在*=土a处的连续性，有
Ae-ila + Bel =C-Da
ik(Ae-ika - Beika) = D
C + Da = Feik*
D=ikFew
由上面的四个方程可以得到入射波振幅与透射波振幅的关系
2Ae~iha =2F（1-iha）
所以
=1 +（ha）’=1+=
62

===== PDF PAGE 69 =====
(PDFÑ'ËõÆ÷ - Î'x[2áºæ)
题解
3.E>V。的情况
薛定方程的解为
4（×）=
Aei* + Be -iks
Csin(lx) + Dcos(lx)
Feikx
(x<-a)
(-a <x <a)
(x>a)
其中
2m(E-Vo)
1=
方
由波函数及其导数在x=土a的连续性，有
Ae-il + Bel = - Csin（la） + Dcos（la）
(Ae-ika - Beika) =a[ Ccos(la) + Dsin(la) ]
Csin(la) + Dcos(la) = Feka
a[ Ccos(la) - Dsin(la) ] = Feika
其中
Q=
ik
前两式相加得到
2Ae=ika = C[ acos(la) - sin(la) ] + D[ asin (la) + cos (la) ]
后两式消去D，或者C得到
C = sin(la) +-cos(la) Feta
D= (cos(la) - -Bin(la) Felo
把C，D代入前一个式子，得到
2Ae-ika = Feik | [ sin(la) + (1/a) cos(la) ][ acos(la) - sin(la)] +
[cos(la) - (1/a) sin(la) ] [ asin(la) + cos(la) ] }
= Feika [2cos (la) - 2sin? (la) +2(a - 1/a) cos ( la) sin (la) ]
所以
T-1=
= I (cos (la) - sin° (la) + (a- 1/a) cos (la) sin (la) 12
(ở -1)
析问题的对称性，无需重新计算。
解：（a） 对6势阱，E>0 散射态的解为
在x=0处波函数连续及波函数导数跃变给出
（Ae +Be-i
¢（×）=
Feik + Ge-ik
F+G=A+B
（x<0）
(x>0)
2ma
ik（F-G-A+B）=-
-（A+B）
於
或者令B=ma/於k
F-G=A(1+2iß) - B(1-2iB)
消去 得到
1
В =
- (iBA +G)
1-$8
消去B得到
1
F=
-(A + iBG)
1 - iß
用矩阵表示上述关系
（A）-
1- 1
显然，散射矩阵为
1
(іB
S=
1-i61
if
（b）有限深方势阱的势能满足V（x）=V（-*），对这种偶函数势，从右边人射同从左边
入射结果是一样的，即作变换* *，A G，B+F，S矩阵不变，所以同时有
S12
Szi
（）-｛
S21
所以
Su =Sa2s Siz.= Sz1
注意：（a）中的。也是偶函数势，所以也有这种性质。
对有限深方势阱E>0散射态，从左边入射的解（G=0）为
4（x）=Ae™+Be-
（ < a）
4（*） = Csin（Lx） + Dcos（kx）
(-a<x <a)
4 (x) = Fei*
（×≥a）
其中，
91

===== PDF PAGE 98 =====
(PDFÑ'ËõÆ÷ - Îx[2áºæ)
第2章 定态薛定谓方程
k=
2mE
方
2m(E+Vo)
7=
左
由*=士a波函数及其导数连续，有
Ae-ika + Beika = - Csin(la) + Dcos(la)
ik［Ae-ila - Bele］ =/［Ccos（la） +Dsin（la）］
Csin(la) + Dcos(la) = Feike
[[ Ccos(la) - Dsin(la) ] = ikF eiku
消去C和D解出
e -Zika A
F=
cos(2la) - ; (kº° - P)
-sin(2la)
2kl
B =i
sin (2la) (P -k)F =i
i Sin(2a) ([ -1)
2kl
2kl
在G=0的情況下，F=S214, B =SuA
所以
e-2ika A
(k -P)
cos(2la) - і
sin (2la)
2kl
e - Zika
Sz =
(k° - P)
cos (2la) - i
sin(2la)
2kl
isin(2la) (P -k°) e-Zika
S22 =
2klcos(2la) - i (k -P) sin(2la)
=S12
=S」
有限深方势阱的S矩阵为
S=
2kcos（24）-1（8 +P）5ln（214a）（15in （310）（2-1：））
igin（242）（パー82））
*** 习题2.53 传递矩阵。散射矩阵（习题2.152）告诉我们了出射振幅（B和 ）与
人射振幅（A和G）的关系
SH
S12
F)
=
有些情况利用传递矩阵 M 是很方便
SzI
的，传递矩阵可以给出势能右侧波的振幅（F和G）同左侧波的振幅（A和B）之间的关
系：
MIz
YAY
M21
M22
（a）用S矩阵的矩阵元表示出 M矩阵的四个矩阵元，反之亦然。用M矩阵的矩阵元表示
IBI2
IFI2
出S矩阵的矩阵元。用M 矩阵的矩阵元表示出（R，=
IAI
=IS,12
',T,=
IAI
=1S2112和
G=0
IFI2
IBI
R.=
IGI?
=1521
,T,=
=1Sp12）中的R、TI、R，和T。
92

===== PDF PAGE 99 =====
(PDFÑ'ËõÆ÷ - Î'x[2áºæ)
第2章补充习题解答
（b）假设一个势由两个孤立部分组成（见图2-22）。证明总势的M矩阵是两个部分势
的 M 矩阵的乘积：
M=M,M」
显然，这可以推广到任意多个部分势的情况，这说明了 M矩阵的用途。
（e）对于在点a处的一个8函数散射势能：
V（x） =-08（x-a）
求M矩阵。
（d）利用（b）中的方法，求双8函数：
V（x）=-α［8（*+a） +8（x-4）］
的M矩阵。这个势的透射系数是什么？
Ae iér
Felx
Be-r
De-ix
Ge-ik
Vxー0
MI
1(x)-0
M2
V(x)-0
图2-22含有两个孤立部分的势
解：（a）由散射矩阵
有
所以
故
所以
512
Sz2
B=S,1 +SgCG +C = 5(1-8,1) - M, 1 +Mats
Mzz
=ー
S12
M2 = -
S1z
S22
F=S2IA +S22G =S214+
-(B-S,A)
S12
-(S,252 - S,S22)A +
S12
B =M,A+M,B
S12
- detS
M.1=ー（S12S21-S,S2）=
M=1
-- dets
S12
反过来由
93

===== PDF PAGE 100 =====
（PDFN1EOE=-1'X1280）
第2章 定态薛定方程
G
M2i
M,2 A
Mzz人
有
G=MzA+ MnB→B=
-(G - M2,A) = S,,A + S12G
M22
所以
M2
S, = -

exit_code=0
```

### 2026-11-16T14:19:52.075464+08:00

```bash
mkdir -p checks/qm-02-source-pages
```

```text

exit_code=0
```

### 2026-11-16T14:19:52.144445+08:00

```bash
pdftoppm -f 67 -l 68 -scale-to 1400 -png '/Users/ai4s/Downloads/量子力学概论-格里菲斯-学习指导书习题解答-中文版.pdf' checks/qm-02-source-pages/barrier
```

```text
Fontconfig error: Cannot load default config file: File not found

exit_code=0
```

### 2026-11-16T14:19:55.838817+08:00

```bash
pdftoppm -f 98 -l 99 -scale-to 1400 -png '/Users/ai4s/Downloads/量子力学概论-格里菲斯-学习指导书习题解答-中文版.pdf' checks/qm-02-source-pages/matrix
```

```text
Fontconfig error: Cannot load default config file: File not found

exit_code=0
```

### 2026-11-16T14:19:58.758124+08:00

```bash
cat tasks/qm-01/environment/Dockerfile tasks/qm-01/environment/requirements.txt tasks/qm-01/environment/.dockerignore tasks/qm-01/task.toml
```

```text
FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2

COPY requirements.txt /tmp/requirements.txt
RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt \
 && useradd --uid 1000 --create-home student \
 && mkdir -p /app/data /app/output \
 && chown -R student:student /app

COPY public/ /app/data/
WORKDIR /app
USER student
numpy==2.1.3
scipy==1.14.1
mpmath==1.3.0
__pycache__/
*.pyc
.DS_Store
schema_version = "1.4"
artifacts = ["/app/output/answer.json"]

[task]
name = "theory-physics-bench/qm-01"
version = "0.1.0"

[metadata]
category = "research"

[agent]
user = "student"
timeout_sec = 1200.0
network_mode = "public"

[verifier]
user = "root"
timeout_sec = 120.0
environment_mode = "separate"
network_mode = "no-network"

[environment]
cpus = 4
memory_mb = 4096
storage_mb = 4096
gpus = 0
build_timeout_sec = 900.0

exit_code=0
```

### 2026-11-16T14:21:07.069565+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qm01:dev python tools/qm02_explore.py
```

```text
{"case": {"id": "barrier-01", "v_left": 20.0, "v_right": 20.0, "w_left": 0.8, "w_right": 0.8, "gap": 3.0, "emin": 0.3, "emax": 8.0}, "peaks": [[0.8286807657400089, 0.99999999999995], [3.2952011536493147, 0.9999999999999283], [7.330522025225236, 0.9999999999999887]]}
{"case": {"id": "barrier-02", "v_left": 25.0, "v_right": 21.0, "w_left": 1.0, "w_right": 0.75, "gap": 3.2, "emin": 0.3, "emax": 9.0}, "peaks": [[0.7527167095601521, 0.14121341065042559], [2.9984640765607673, 0.1552209394722984], [6.6946234025415094, 0.18291789815785114]]}
{"case": {"id": "barrier-03", "v_left": 30.0, "v_right": 30.0, "w_left": 1.3, "w_right": 1.3, "gap": 4.0, "emin": 0.2, "emax": 9.0}, "peaks": [[0.5177153348948476, 0.9999999983465728], [2.0677610257032786, 1.0000000004536735], [4.640123838007117, 0.9999999999975031], [8.215286504445766, 0.9999999999854035]]}
{"case": {"id": "barrier-04", "v_left": 18.0, "v_right": 24.0, "w_left": 0.65, "w_right": 0.9, "gap": 2.7, "emin": 0.3, "emax": 10.0}, "peaks": [[0.9975263654600625, 0.10828577781480565], [3.9600642508376978, 0.12374859805775408], [8.781766344742783, 0.15777793874632992]]}

exit_code=0
```

### 2026-11-16T14:23:57.500169+08:00

```bash
python3 tools/qm02_write_package.py
```

```text
Traceback (most recent call last):
  File "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/qm02_write_package.py", line 16, in <module>
    from qm02_explore import CASES
  File "/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30/tools/qm02_explore.py", line 2, in <module>
    import numpy as np
ModuleNotFoundError: No module named 'numpy'

exit_code=1
```

### 2026-11-16T14:25:33.994100+08:00

```bash
python3 tools/qm02_write_package.py
```

```text
qm-02 package implementation files written

exit_code=0
```

### 2026-11-16T14:25:34.106028+08:00

```bash
docker build -t theory-physics-qm02:dev tasks/qm-02/environment
```

```text
#0 building with "desktop-linux" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile: 460B done
#1 DONE 0.0s

#2 [internal] load metadata for mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#2 DONE 0.0s

#3 [internal] load .dockerignore
#3 transferring context: 69B done
#3 DONE 0.0s

#4 [1/5] FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#4 resolve mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2 0.0s done
#4 DONE 0.0s

#5 [internal] load build context
#5 transferring context: 5.09kB done
#5 DONE 0.0s

#6 [2/5] COPY requirements.txt /tmp/requirements.txt
#6 CACHED

#7 [3/5] RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt  && useradd --uid 1000 --create-home student  && mkdir -p /app/data /app/output  && chown -R student:student /app
#7 CACHED

#8 [4/5] COPY public/ /app/data/
#8 DONE 0.0s

#9 [5/5] WORKDIR /app
#9 DONE 0.0s

#10 exporting to image
#10 exporting layers 0.0s done
#10 exporting manifest sha256:311f56b770ff5cdea278bab734dc119a816a627c809a1b9ed677b3f744dee71f done
#10 exporting config sha256:293d272748c794b768d7988b6aacb0eaf8b6e120d5c56e4e5b6ccf6995ce545c done
#10 exporting attestation manifest sha256:944fbd8f7653c2560e9411784e83849340f809c05ea4041ddb89eafc1bb4cf1f 0.0s done
#10 exporting manifest list sha256:8477a3b2bc6fead0babc9eb9361ede0e083c4f186e760a083b7b65653e00e1be done
#10 naming to docker.io/library/theory-physics-qm02:dev done
#10 unpacking to docker.io/library/theory-physics-qm02:dev 0.0s done
#10 DONE 0.1s

exit_code=0
```

### 2026-11-16T14:25:34.785897+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qm02:dev python tools/build_qm02_truth.py
```

```text
{"id": "barrier-01", "peak_count": 3, "minimum_fwhm": 0.0003038908064924774, "maximum_extremum_numerator_residual": "1.60132931645575707030662699535570055604837387198835499500797e-53", "maximum_half_height_residual": "3.18540594535517191134436778752870109565213532886414742625613e-58", "maximum_transfer_determinant_residual": "1.89801965974764822067893953640293789338002691145995597559584e-59", "maximum_quadrature_split_difference": "0.0", "mean_transmission": 0.0045934398952349855, "bracket_grid_points": 1537}
{"id": "barrier-02", "peak_count": 3, "minimum_fwhm": 0.00016120846257949327, "maximum_extremum_numerator_residual": "4.38032006594620128313958056145825157062584781375578427478402e-52", "maximum_half_height_residual": "4.11788589089717736402423613558731658732808092727095981385675e-59", "maximum_transfer_determinant_residual": "3.56734350803389948362033471882945622091836205571940905905022e-58", "maximum_quadrature_split_difference": "0.0", "mean_transmission": 0.00034159926862487765, "bracket_grid_points": 1537}
{"id": "barrier-03", "peak_count": 4, "minimum_fwhm": 6.60985065366113e-08, "maximum_extremum_numerator_residual": "5.51970141147722494927262822840253548854670698233033747584401e-47", "maximum_half_height_residual": "1.14873758300446842669452984330834270644331060646323595594939e-54", "maximum_transfer_determinant_residual": "1.1338357172570292169697886496227588041821341664855599220887e-55", "maximum_quadrature_split_difference": "2.75964937611144151098441103459144379794546819539579650582506e-65", "mean_transmission": 4.8402386731592225e-06, "bracket_grid_points": 1537}
{"id": "barrier-04", "peak_count": 3, "minimum_fwhm": 0.001291927786779565, "maximum_extremum_numerator_residual": "1.62346968467163699749513828932752055767403068295927453785746e-53", "maximum_half_height_residual": "1.59416149188333466075979578377695526444495600478411773667489e-59", "maximum_transfer_determinant_residual": "4.59725253651991843615267731973006678273604878964276221957845e-58", "maximum_quadrature_split_difference": "3.41840438847352754909036721704230457551954770010318018786072e-64", "mean_transmission": 0.002141170613963343, "bracket_grid_points": 1537}
independent qm-02 truth saved

exit_code=0
```

### 2026-11-16T14:28:24.769150+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 -e PYTHONDONTWRITEBYTECODE=1 -e OPENBLAS_NUM_THREADS=1 --mount 'type=bind,source=/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30,target=/work' -w /work theory-physics-qm02:dev python tools/run_qm02_checks.py --calibrate
```

```text
{
  "metric": {
    "kind": "continuous",
    "metric_name": "平均共振谱与能窗透射误差",
    "unit": "百分点",
    "direction": "minimize",
    "baseline": 45.92644529600235,
    "reference": 1.1118326344938853e-05,
    "tolerance": 0.0001
  },
  "scores": {
    "baseline": {
      "raw_metric": 45.92644529600235,
      "score": 0.0,
      "status": "completed"
    },
    "reference": {
      "raw_metric": 1.1118326344938853e-05,
      "score": 1.0,
      "status": "completed"
    },
    "equivalent": {
      "raw_metric": 1.1118326344938853e-05,
      "score": 1.0,
      "status": "completed"
    },
    "wrong": {
      "raw_metric": 91.97358348272081,
      "score": 0.0,
      "status": "completed"
    },
    "missing_peak": {
      "raw_metric": 4.68751106679548,
      "score": 0.8979345983985049,
      "status": "completed"
    },
    "repeated_peak": {
      "raw_metric": 4.687511118326178,
      "score": 0.897934597276478,
      "status": "completed"
    },
    "wrong_width": {
      "raw_metric": 26.25001110314117,
      "score": 0.428433745078897,
      "status": "completed"
    },
    "wrong_mean": {
      "raw_metric": 25.00000005300003,
      "score": 0.45565142641041967,
      "status": "completed"
    },
    "malformed": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "boolean_number": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "nonfinite": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    },
    "duplicate_case": {
      "raw_metric": null,
      "score": 0.0,
      "status": "invalid"
    }
  },
  "runtime": {
    "platform": "Linux-6.12.76-linuxkit-aarch64-with-glibc2.36",
    "python": "3.12.13",
    "baseline_seconds": 0.13297895899995638,
    "reference_seconds": 0.4271872089999533
  },
  "checks": {
    "reference_matches_independent_truth": true,
    "reference_improves_baseline": true,
    "registered_endpoints_match": true,
    "baseline_zero_reference_one": true,
    "equivalent_reordering_same": true,
    "wrong_answer_penalized": true,
    "missing_peak_penalized": true,
    "duplicate_peak_penalized": true,
    "width_error_penalized": true,
    "mean_error_penalized": true,
    "invalid_answers_rejected": true,
    "verifier_reference_one_empty_invalid": true,
    "public_feedback_works": true,
    "course_score_exact": true
  }
}

exit_code=0
```

### 2026-11-16T14:29:08.214036+08:00

```bash
docker build -t theory-physics-qm02:dev tasks/qm-02/environment
```

```text
#0 building with "desktop-linux" instance using docker driver

#1 [internal] load build definition from Dockerfile
#1 transferring dockerfile: 460B done
#1 DONE 0.0s

#2 [internal] load metadata for mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#2 DONE 0.0s

#3 [internal] load .dockerignore
#3 transferring context: 69B done
#3 DONE 0.0s

#4 [1/5] FROM mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2
#4 resolve mirror.gcr.io/library/python:3.12.13-slim-bookworm@sha256:4766d8b510c428e595d74b9cc5bbb2fae8e26316fffb4adc89908d79aacd58a2 0.0s done
#4 DONE 0.0s

#5 [internal] load build context
#5 transferring context: 453B done
#5 DONE 0.0s

#6 [2/5] COPY requirements.txt /tmp/requirements.txt
#6 CACHED

#7 [3/5] RUN python -m pip install --no-cache-dir --requirement /tmp/requirements.txt  && useradd --uid 1000 --create-home student  && mkdir -p /app/data /app/output  && chown -R student:student /app
#7 CACHED

#8 [4/5] COPY public/ /app/data/
#8 DONE 0.0s

#9 [5/5] WORKDIR /app
#9 DONE 0.0s

#10 exporting to image
#10 exporting layers 0.0s done
#10 exporting manifest sha256:380423896bd90d2ac353edcbb3e626dd7e2dec699aece2f9af6f1f2943c0ef99 done
#10 exporting config sha256:3af5354bf6a9ea79de843373931d89556b5bf682b38a88ac05fcb1b1f9567439 done
#10 exporting attestation manifest sha256:66b1b1bb6e99f347859ed40915514f9b938e542df4d5014129ce5cd484574047 done
#10 exporting manifest list sha256:3444d294d815811a04bef4503077149f05b2a2be988a323f889e034d0debc817 done
#10 naming to docker.io/library/theory-physics-qm02:dev done
#10 unpacking to docker.io/library/theory-physics-qm02:dev 0.0s done
#10 DONE 0.1s

exit_code=0
```

### 2026-11-16T14:29:08.813674+08:00

```bash
docker run --rm --network none --cpus 4 --memory 4g theory-physics-qm02:dev python /app/data/feedback.py --case barrier-01 --energy 1.0
```

```text
{"id": "barrier-01", "energy": 1.0, "transmission": 1.3611721791069294e-06, "reflection": 0.9999986388278208, "flux_residual": -1.1102230246251565e-16}

exit_code=0
```

### 2026-11-16T14:30:04.149363+08:00

```bash
python3 -c 'import json; from pathlib import Path; p=Path('"'"'tasks/qm-02/tests/private/truth.json'"'"'); print(p.read_text()); r=json.loads(Path('"'"'checks/qm-02-truth-validation.json'"'"').read_text()); print('"'"'truth_build_seconds='"'"',r['"'"'elapsed_seconds'"'"']); print('"'"'task_files='"'"',len(list(Path('"'"'tasks/qm-02'"'"').rglob('"'"'*'"'"'))))'
```

```text
{
  "method": "independent 60-digit wavefunction transfer matrix, analytic derivative and bisection; normalized quadrature",
  "cases": [
    {
      "id": "barrier-01",
      "peaks": [
        {
          "energy": 0.8286807657400089,
          "height": 1.0,
          "fwhm": 0.0003038908064924774
        },
        {
          "energy": 3.295201153649314,
          "height": 1.0,
          "fwhm": 0.0033145443961386948
        },
        {
          "energy": 7.330522025225236,
          "height": 1.0,
          "fwhm": 0.019005997712490934
        }
      ],
      "mean_transmission": 0.0045934398952349855
    },
    {
      "id": "barrier-02",
      "peaks": [
        {
          "energy": 0.7527167095601545,
          "height": 0.14121341065039772,
          "fwhm": 0.00016120846257949327
        },
        {
          "energy": 2.9984640765607677,
          "height": 0.1552209394723148,
          "fwhm": 0.0016705162069587164
        },
        {
          "energy": 6.694623402541509,
          "height": 0.18291789815785117,
          "fwhm": 0.008783437640623646
        }
      ],
      "mean_transmission": 0.00034159926862487765
    },
    {
      "id": "barrier-03",
      "peaks": [
        {
          "energy": 0.5177153348948476,
          "height": 1.0,
          "fwhm": 6.60985065366113e-08
        },
        {
          "energy": 2.067761025703279,
          "height": 1.0,
          "fwhm": 7.264368206650854e-07
        },
        {
          "energy": 4.640123838007116,
          "height": 1.0,
          "fwhm": 4.220453219490213e-06
        },
        {
          "energy": 8.215286504445768,
          "height": 1.0,
          "fwhm": 2.210335645630546e-05
        }
      ],
      "mean_transmission": 4.8402386731592225e-06
    },
    {
      "id": "barrier-04",
      "peaks": [
        {
          "energy": 0.9975263654600641,
          "height": 0.10828577781479874,
          "fwhm": 0.001291927786779565
        },
        {
          "energy": 3.960064250837698,
          "height": 0.12374859805775011,
          "fwhm": 0.0136220569534693
        },
        {
          "energy": 8.781766344742783,
          "height": 0.1577779387463272,
          "fwhm": 0.07291631625157206
        }
      ],
      "mean_transmission": 0.002141170613963343
    }
  ]
}

truth_build_seconds= 28.40474247200001
task_files= 25

exit_code=0
```

### 2026-11-16T15:51:59.689776+08:00

```bash
python3 tools/run_harbor_local_checks.py qm-02 --macos-compat
```

```text
$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qm-02-harbor-d9eo7xgb/qm-02 -a oracle --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qm-02-harbor-d9eo7xgb/runs/oracle
  1/1 Mean: 1.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:26 0:00:00
adhoc • oracle
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 1.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 1.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 26s
Results written to 
/tmp/physics-qm-02-harbor-d9eo7xgb/runs/oracle/2026-11-16__15-52-00/result.json
Inspect results by running `harbor view 
/tmp/physics-qm-02-harbor-d9eo7xgb/runs/oracle`
Share results by running `harbor upload 
/tmp/physics-qm-02-harbor-d9eo7xgb/runs/oracle/2026-11-16__15-52-00`

$ /Users/ai4s/.local/bin/harbor run -p /tmp/physics-qm-02-harbor-d9eo7xgb/qm-02 -a nop --n-attempts 1 --n-concurrent 1 --max-retries 0 --jobs-dir /tmp/physics-qm-02-harbor-d9eo7xgb/runs/nop
  1/1 Mean: 0.000 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 0:00:25 0:00:00
adhoc • nop
┏━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━┓
┃ Trials ┃ Exceptions ┃  Mean ┃
┡━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━┩
│      1 │          0 │ 0.000 │
└────────┴────────────┴───────┘

┏━━━━━━━━┳━━━━━━━┓
┃ Reward ┃ Count ┃
┡━━━━━━━━╇━━━━━━━┩
│ 0.0    │     1 │
└────────┴───────┘

Job Info
Total runtime: 25s
Results written to 
/tmp/physics-qm-02-harbor-d9eo7xgb/runs/nop/2026-11-16__15-52-30/result.json
Inspect results by running `harbor view 
/tmp/physics-qm-02-harbor-d9eo7xgb/runs/nop`
Share results by running `harbor upload 
/tmp/physics-qm-02-harbor-d9eo7xgb/runs/nop/2026-11-16__15-52-30`

{
  "task_id": "qm-02",
  "host": "macOS-26.6.2-arm64-arm-64bit",
  "temporary_task": "/tmp/physics-qm-02-harbor-d9eo7xgb/qm-02",
  "macos_verifier_network_override": true,
  "runs": [
    {
      "agent": "oracle",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qm-02-harbor-d9eo7xgb/qm-02",
        "-a",
        "oracle",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qm-02-harbor-d9eo7xgb/runs/oracle"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T07:51:59.730345+00:00",
      "archive": "runs/qm-02/harbor-macos-compat/oracle"
    },
    {
      "agent": "nop",
      "command": [
        "/Users/ai4s/.local/bin/harbor",
        "run",
        "-p",
        "/tmp/physics-qm-02-harbor-d9eo7xgb/qm-02",
        "-a",
        "nop",
        "--n-attempts",
        "1",
        "--n-concurrent",
        "1",
        "--max-retries",
        "0",
        "--jobs-dir",
        "/tmp/physics-qm-02-harbor-d9eo7xgb/runs/nop"
      ],
      "returncode": 0,
      "started_utc": "2026-11-16T07:52:29.829785+00:00",
      "archive": "runs/qm-02/harbor-macos-compat/nop"
    }
  ]
}

exit_code=0
```
