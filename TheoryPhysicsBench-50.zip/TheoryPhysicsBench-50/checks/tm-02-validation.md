# tm-02 开发校准与验收记录

日期：2026-11-16（Asia/Shanghai）。

## 实际结果

Docker Linux aarch64、Python 3.12.13、NumPy 2.1.3、SciPy 1.14.1；4 CPU、4 GB 内存、断网。原始主指标为八个工况平均轨道观测量加权误差，单位百分点、越低越好。

| 产物 | 原始指标 | 课程得分 | 状态 |
|---|---:|---:|---|
| 近圆近似基线 | 10.420120704842862 | 0 | 有效 |
| 完整轨道积分参考 | 1.074843504126607e-11 | 1 | 有效 |
| 周期翻倍、角增量减半的独立错误解 | 56.596590855161644 | 0 | 格式有效、物理错误 |
| 反向排列工况的等价解 | 与参考相同 | 1 | 有效 |
| 缺项、重复 ID、布尔数值、超范围数值、进动恒等式错误 | 无效 | 0 | 按各自原因拒绝 |
| 无答案文件，经实际 `test.sh` 入口 | 无效 | 0 | 缺少有效 JSON |

参考解求解耗时 0.1113 秒，基线 0.1068 秒。11 项校准/评分检查全部通过，详细逐工况结果见 [校准 JSON](tm-02-calibration.json)，实际答案保存在 `runs/tm-02/development-answers/`。

独立 DOP853 验证值的远拱点相对误差最大约 \(1.60\times10^{-12}\)，能量绝对漂移最大约 \(9.22\times10^{-13}\)，见 [独立积分记录](tm-02-truth-validation.json)。

## 复现命令

在项目根目录执行：

```bash
docker build -t theory-physics-tm02:dev tasks/tm-02/environment
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 \
  --env PYTHONDONTWRITEBYTECODE=1 --env OPENBLAS_NUM_THREADS=1 \
  --mount "type=bind,source=$PWD,target=/work" --workdir /work \
  theory-physics-tm02:dev python tools/build_tm02_truth.py
docker run --rm --network none --cpus 4 --memory 4g --user 0:0 \
  --env PYTHONDONTWRITEBYTECODE=1 --env OPENBLAS_NUM_THREADS=1 \
  --mount "type=bind,source=$PWD,target=/work" --workdir /work \
  theory-physics-tm02:dev python tools/run_tm02_checks.py --calibrate
```

重新核对已登记端点时省略 `--calibrate`；数值代码和工况改变时保留原记录并重新开发校准。

## Harbor 联调

Harbor 0.24.0 的两次运行均无异常：

| Agent | Reward | 耗时 | 归档路径 |
|---|---:|---:|---|
| oracle | 1 | 28 秒 | `runs/tm-02/harbor-macos-compat/oracle/2026-11-16__12-25-04/` |
| nop | 0 | 27 秒 | `runs/tm-02/harbor-macos-compat/nop/2026-11-16__12-25-05/` |

在 `/tmp/theory-physics-tm02-harbor.WpLgJB/tm-02` 副本运行，单次、单并发、无重试。临时副本 verifier 网络设置为 `public`，以兼容 Docker Desktop；正式任务仍为 `no-network`。Docker 直接校准使用 `--network none`。路径和兼容性说明见 [tm-01 记录](tm-01-validation.md)。

课程指定 Codex 的三次正式作答在整套题集冻结后统一进行。
