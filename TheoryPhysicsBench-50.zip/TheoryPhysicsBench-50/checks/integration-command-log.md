
### 2026-11-16T17:23:48.368421+08:00

```bash
rg --files ../.. -g '*要求*' -g '*README*' -g '*benchmark*' -g '*report*'
```

```text

### 2026-11-16T17:23:48.368547+08:00

```bash
rg --files planning tasks/qft-05
```

```text

### 2026-11-16T17:23:48.368907+08:00

```bash
python3 tools/task_status.py
```

```text
rg: tasks/qft-05: No such file or directory (os error 2)
planning/source-notes/ed-sol-all.txt
planning/source-notes/gr-mid-front.txt
planning/source-notes/sp-front.txt
planning/source-notes/gr-down-front.txt
planning/source-notes/gr-up-front.txt
planning/source-notes/qm-sol-all.txt
planning/source-notes/qft-all.txt
planning/source-notes/qm-sol-front.txt
planning/source-notes/qft-front.txt
planning/source-notes/sp-sol-all.txt
planning/source-notes/ed-front.txt
planning/source-notes/gr-mid-all.txt
planning/source-notes/tm-front.txt
planning/source-notes/sp-sol-front.txt
planning/source-notes/ed-sol-front.txt
planning/source-notes/tm-all.txt
planning/source-notes/gr-down-all.txt
planning/work-order-sp02.md
planning/implementation-qft.md
planning/work-order-gr02.md
planning/work-order-gr03.md
planning/gr-candidate-evidence.md
planning/work-order-ed03.md
planning/work-order-qm03.md
planning/work-order-ed02.md
planning/work-order-qm02.md
planning/implementation-gr.md
planning/work-order-qm04-tm04.md
planning/work-order-tm03.md

exit_code=2
```
../../LLM-Serving-Bench/src/llm_serving_bench/reports.py
../../LLM-Serving-Bench/README.md
../../LLM-Serving-Bench/tests/test_reports.py
../../LLM-Serving-Bench/course/README.md
../../01-大作业开发/TheoryPhysicsBench-30/README.md
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/README.md
../../00-老师原始材料/科研探索课程项目/examples/nanogpt/original/record_2600/README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/qft-02/solution/README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/gr-02/solution/README.md
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/environment/data/README.md
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/qm-03/solution/README.md
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/report.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/scan_report.py
../../00-老师原始材料/科研探索课程项目/examples/magnetic-alloy/README.md
../../00-老师原始材料/科研探索课程项目/template/benchmark.json
../../01-大作业开发/TheoryPhysicsBench-30/tasks/qm-02/solution/README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/gr-04/solution/README.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-01/environment/public/README.txt
../../01-大作业开发/TheoryPhysicsBench-30/tasks/ed-01/solution/README.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-06/environment/public/README.txt
../../01-大作业开发/TheoryPhysicsBench-30/tasks/tm-02/solution/README.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-08/environment/public/README.txt
../../01-大作业开发/TheoryPhysicsBench-30/tasks/qft-01/solution/README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/tm-03/solution/README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/gr-03/solution/README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/qm-01/solution/README.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-09/environment/public/README.txt
../../01-大作业开发/TheoryPhysicsBench-30/tasks/tm-01/solution/README.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-07/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-05/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-10/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目/template/tasks/task-02/environment/public/README.txt
../../01-大作业开发/TheoryPhysicsBench-30/tasks/sp-01/solution/README.md
../../00-老师原始材料/科研探索课程项目 2/examples/nanogpt/README.md
../../00-老师原始材料/科研探索课程项目 2/examples/nanogpt/original/record_2600/README.md
../../00-老师原始材料/解压原件/科研探索课程项目/template/benchmark.json
../../00-老师原始材料/科研探索课程项目/template/tasks/task-04/environment/public/README.txt
../../01-大作业开发/TheoryPhysicsBench-30/tasks/ed-02/solution/README.md
../../00-老师原始材料/科研探索课程项目/template/tasks/task-03/environment/public/README.txt
../../01-大作业开发/MechanicsInverseBench-原型/README.md
../../01-大作业开发/MechanicsInverseBench-原型/benchmark.json
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-01/environment/public/README.txt
../../00-老师原始材料/解压原件/科研探索课程项目/examples/nanogpt/README.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/examples/nanogpt/._README.md
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-07/environment/public/README.txt
../../01-大作业开发/TheoryPhysicsBench-30/tasks/ed-05/solution/README.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/examples/nanogpt/original/record_2600/._README.md
../../00-老师原始材料/解压原件/科研探索课程项目/examples/nanogpt/original/record_2600/README.md
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-05/environment/public/README.txt
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-03/environment/public/README.txt
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-06/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目 2/examples/magnetic-alloy/task/environment/data/README.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/examples/magnetic-alloy/._README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/ed-04/solution/README.md
../../00-老师原始材料/解压原件/科研探索课程项目/examples/magnetic-alloy/task/environment/data/README.md
../../00-老师原始材料/科研探索课程项目 2/examples/magnetic-alloy/task/README.md
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-04/environment/public/README.txt
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-02/environment/public/README.txt
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-08/environment/public/README.txt
../../01-大作业开发/TheoryPhysicsBench-30/tasks/ed-03/solution/README.md
../../00-老师原始材料/解压原件/科研探索课程项目/examples/magnetic-alloy/task/README.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/examples/magnetic-alloy/task/environment/data/._README.md
../../01-大作业开发/TheoryPhysicsBench-30/tasks/qft-03/solution/README.md
../../00-老师原始材料/解压原件/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/report.py
../../00-老师原始材料/解压原件/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/scan_report.py
../../00-老师原始材料/解压原件/科研探索课程项目/examples/magnetic-alloy/README.md
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-10/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目 2/template/benchmark.json
../../00-老师原始材料/科研探索课程项目 2/examples/magnetic-alloy/task/tests/asb_verify/report.py
../../00-老师原始材料/科研探索课程项目 2/examples/magnetic-alloy/task/tests/asb_verify/scan_report.py
../../01-大作业开发/TheoryPhysicsBench-30/tasks/gr-01/solution/README.md
../../00-老师原始材料/解压原件/科研探索课程项目/template/tasks/task-09/environment/public/README.txt
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/._benchmark.json
../../00-老师原始材料/科研探索课程项目 2/examples/magnetic-alloy/README.md
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-01/environment/public/README.txt
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/._report.py
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/examples/magnetic-alloy/task/tests/asb_verify/._scan_report.py
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/examples/magnetic-alloy/task/._README.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-01/environment/public/._README.txt
../../InferenceOpt-Bench/docs/作业要求与验收清单.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-07/environment/public/._README.txt
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-06/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/examples/nanogpt/README.md
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-10/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-02/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-09/environment/public/README.txt
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-06/environment/public/._README.txt
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-03/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/examples/nanogpt/original/record_2600/README.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-05/environment/public/._README.txt
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-05/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-07/environment/public/README.txt
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-04/environment/public/._README.txt
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-04/environment/public/README.txt
../../00-老师原始材料/科研探索课程项目 2/template/tasks/task-08/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/examples/magnetic-alloy/README.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-08/environment/public/._README.txt
../../InferenceOpt-Bench/course_materials/examples/magnetic-alloy/task/environment/data/README.md
../../InferenceOpt-Bench/benchmark/runs/README.md
../../InferenceOpt-Bench/benchmark/benchmark.json
../../InferenceOpt-Bench/research_prototypes/ragged_prefill/README.md
../../InferenceOpt-Bench/README.md
../../InferenceOpt-Bench/course_materials/examples/magnetic-alloy/task/README.md
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-02/environment/public/._README.txt
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-09/environment/public/._README.txt
../../InferenceOpt-Bench/course_materials/examples/magnetic-alloy/task/tests/asb_verify/report.py
../../InferenceOpt-Bench/course_materials/examples/magnetic-alloy/task/tests/asb_verify/scan_report.py
../../InferenceOpt-Bench/benchmark/tasks/gqa-decode/tests/calibration/README.md
../../InferenceOpt-Bench/course_materials/template/benchmark.json
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-10/environment/public/._README.txt
../../00-老师原始材料/解压原件/__MACOSX/科研探索课程项目/template/tasks/task-03/environment/public/._README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-01/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-05/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-09/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-02/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-07/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-06/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-03/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-08/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-04/environment/public/README.txt
../../InferenceOpt-Bench/course_materials/template/tasks/task-10/environment/public/README.txt

exit_code=0
```
ed-01 calibrated=True checks=14 oracle=True nop=True
ed-02 calibrated=True checks=15 oracle=True nop=True
ed-03 calibrated=True checks=16 oracle=True nop=True
ed-04 calibrated=True checks=14 oracle=True nop=True
ed-05 calibrated=False checks=0 oracle=False nop=False
gr-01 calibrated=True checks=14 oracle=True nop=True
gr-02 calibrated=True checks=15 oracle=True nop=True
gr-03 calibrated=True checks=14 oracle=True nop=True
gr-04 calibrated=True checks=14 oracle=True nop=False
gr-05 calibrated=False checks=0 oracle=False nop=False
qft-01 calibrated=True checks=15 oracle=True nop=True
qft-02 calibrated=True checks=13 oracle=True nop=True
qft-03 calibrated=True checks=15 oracle=False nop=False
qm-01 calibrated=True checks=11 oracle=True nop=True
qm-02 calibrated=True checks=14 oracle=True nop=True
qm-03 calibrated=True checks=16 oracle=True nop=True
sp-01 calibrated=True checks=13 oracle=True nop=True
tm-01 calibrated=True checks=11 oracle=True nop=True
tm-02 calibrated=True checks=11 oracle=True nop=True
tm-03 calibrated=True checks=19 oracle=True nop=True

exit_code=0
```

### 2026-11-16T17:25:01.493311+08:00

```bash
rg --files planning -g 'status-*'
```

```text

exit_code=1
```
