
### 2026-11-16T18:27:19.303347+08:00

```bash
python3 tools/read_qft_source_pages.py gelis 282:285,294:300
```

```text

===== PDF PAGE 282 =====
26 GROSS–NEVEU MODEL 111
26. Gross–Neveu Model The Gross–Neveu model is a (1 + 1)-dimensional quantum
ﬁeld theory withN species of massless fermions (indexed byn = 1,...,N ), with a quartic
interaction,
L ≡ i
∑
n
ψn/∂ψn + g22 ( ∑n ψnψn)2.
This quantum ﬁeld theory is a toy model for the spontaneous breaking of chiral symmetry, and
also provides an example of the technique of bosonization.
26.a Check that a valid representation of the Dirac matrices in two dimensions isγ0 = σ2,
γ1 = iσ1 (with σ1,2 Pauli matrices). Also deﬁne γ5 ≡ γ0γ1. Check that (γ5)2 = 1,
(γ5)† = γ5, {γ5,γμ} = 0 for μ = 0,1 . Show that L is invariant under ψn → γ5ψn.
Would a mass term be consistent with this symmetry?
According to the power counting, can this theory be renormalizable ind = 2?
26.b Prove the following equality:
∫
[DψDψ]ei
∫
L =
∫
[DψDψDφ]ei
∫ ∑
n ψn(i/∂−φ)ψne− i2g2 ∫φ2,
whereφ is an auxiliary scalar ﬁeld.
26.c We are now interested in the ground state of this theory, in whichφ is constant. Perform
the integration over the fermions in closed form for a constant φ, and show that the
result of this integration is a factor
exp
{
N
∫ d2p
(2π)2 ln(−p2 +φ2)
}
, withp2 ≡ p20 −p21.
26.d Using ln(A)=− ∂α(A−α)α=0, and using dimensional regularization withd = 2 −2ϵ,
show that the integral can be written as
∫ ddp
(2π)d ln(−p2 +φ2)= iφ24π(1ϵ + const +1 − lnφ2 +O(ϵ2)).
Which operator should one renormalize to eliminate the ultraviolet divergence? After
introduction of an appropriate counterterm, show that the effective potential for the ﬁeld
φ can be written as
Veff(φ)= φ22g2 + Nφ24π ( ln(φ2μ2) −1),
whereμ is a constant whose precise value depends on the ﬁnite terms included in the
counterterm besides the pole inϵ−1.
26.e Determine analytically the location of the minimum of Veff(φ). Could this answer have
been found by a perturbative expansion in powers ofg2? What are the consequences for
the fermions of having a non-zero expectation value forφ?
26.f What are the diagrams that would give the result of the above functional calculation?
Why is the answer exact in the limitN →∞ ?


===== PDF PAGE 283 =====
112 2 FUNCTIONAL METHODS
26.a In order to verify that the proposed matrices are valid Dirac matrices in two dimensions,
we just need to verify that
{
γμ,γν} = 2gμν:
(
γ0)2 =(σ2)2 = 1, (γ1)2 =(iσ1)2 =− 1,
γ0γ1 +γ1γ0 = iσ2σ1 +iσ1σ2 = i(−iσ3)+ i(iσ3)= 0.
Deﬁningγ5 ≡ γ0γ1,w eh a v e
(
γ5)2 = γ0γ1γ0γ1 =− γ0 γ1γ1
/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1
γ0 =+ 1,
(
γ5)† =( iσ2σ1)† =− iσ1σ2 =+ iσ2σ1 = γ5,
{
γ5,γμ} = γ0γ1γμ +γμγ0γ1 = 0.
(In the ﬁnal equality above, since μ is either 0 or 1, γμ commutes with one of γ0,1 and
anti-commutes with the other one.) Under the transformation ψn → γ5ψn,w eh a v e
ψn → γ5ψn,
ψn ≡ ψ†nγ0 → ψ†n γ5†γ0/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=γ5γ0=−γ0γ5
=− ψnγ5,
ψnψn → −ψnψn,(
ψnψn
)2 →(ψnψn)2,
ψnγμψn → −ψn γ5γμγ5/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−γμ
ψn = ψnγμψn,
hence the invariance of the Lagrangian. Note that a mass term is not allowed by this symmetry
sinceψnψn → −ψnψn under this transformation.
The mass dimension of the ﬁeldψn is 12 ind = 2, and therefore the mass dimension of thecoupling constant g is zero. This theory should therefore be renormalizable in two dimensions
according to the power counting.
26.b In order to check the proposed equality, we proceed by explicitly performing the
integration overφ on the right-hand side. For this, we need
− 12g2 φ2 −φ ∑
n
ψnψn =− 12g2
[
φ2 +2g2φ ∑
n
ψnψn
]
=− 12g2
[(
φ +g2 ∑
n
ψnψn
)2
−g4
( ∑
n
ψnψn
)2]
.
Then, we deﬁne φ′ ≡ φ + g2 ∑n ψnψn and trade the integration variable φ in favor
of φ′. The integral produces a constant prefactor (which we ignore), and leaves a factor
exp(g22 (∑n ψnψn)2), hence the announced equality.


===== PDF PAGE 284 =====
26 GROSS–NEVEU MODEL 113
26.c Whenφ is a constant, we can perform the integration over the fermions explicitly. Each
pair of integralsDψnDψn produces a factor
det
(
i/∂ −φ
)
.
These factors do not depend on the index n, and there are N of them, so the N fermionic
integrations give
[
det
(
i/∂ −φ
)]N
= exp
{
N tr ln
(
i/∂ −φ)
}
= exp
{
N
∫ d2p
(2π)2 tr ln(/p −φ)
}
.
Note that the original trace was over both spacetime and the Dirac indices. In the ﬁnal equality,
we have rewritten the trace over spacetime as a trace over momentum and we keep unchanged
the trace over the Dirac indices. For the latter, we can write
tr ln(/p −φ)= ln det
(
−φi (p0 −p1)
−i(p0 +p1)− φ
)
= ln
(
φ2 −p2).
(We have used the explicit form of the Pauli matrices in the ﬁrst equality.) This gives the
announced formula.
Alternative Proof: It is possible to do this calculation without resorting to any explicit
representation of the Dirac matrices, as follows:
tr ln(/p −φ)= tr ln(−φ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
=2 ln(−φ)=ln(φ2)
+tr ln(1 −/p/φ)
= ln(φ2)− ∑
n≥1
1
n tr
([/p
φ
]n)
= ln(φ2)− ∑
p≥1
1
2p tr
([/p
φ
]2p)
= ln(φ2)− ∑
p≥1
1
p
(p2
φ2
)p
= ln(φ2)+ ln(1 −p2/φ2)= ln(φ2 −p2).
(In the third line, we used the fact that/p2p+1 = p2p/p has a null trace, and therefore we keep
only the terms of even order.)
26.d Then, the integration of the momentump proceeds as follows:
∫ ddp
(2π)d ln(−p2 +φ2)=− ∂α
∫ ddp
(2π)d
1
(−p2 +φ2)α
⏐⏐⏐⏐⏐
α=0
=− i∂α
∫ ddpE
(2π)d
1
(p2E +φ2)α
⏐⏐⏐⏐⏐
α=0
=− i∂α
φd−2α
(4π)d/2
Γ (α − d2 )
Γ (α)
⏐⏐⏐⏐⏐
α=0
.
Note thatΓ (α) ≈ α−1 whenα → 0. Therefore, we have


===== PDF PAGE 285 =====
114 2 FUNCTIONAL METHODS
∂α
F(α)
Γ (α)
⏐⏐⏐⏐⏐
α=0
= F(0),
and we obtain
∫ ddp
(2π)d ln(−p2 +φ2)=− i φd(4π)d/2Γ (−d2 )=− iφ2φ−2ϵ(4π)1−ϵ Γ (−1 +ϵ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
−1ϵ +const+O(ϵ)
= iφ2
4π
[1
ϵ + const +1 − ln(φ2)+ O(ϵ2)]. (2.35)
(We could have written const +1 as some unique constant, but it will be convenient later to
pull out this 1.) The pole in ϵ−1 can be removed by renormalizing the operator φ2. More
precisely, we introduce the counterterm
−iφ2
4π
[1
ϵ + const′
]
,
where const′ is a ﬁnite constant that may be subtracted along with the poleϵ−1. Combining
the original term inφ2 with the result (2.35) and the counterterm, we get
φ2
2g2 + Nφ24π ( ln(φ2μ2) −1)
for the sum of the terms inφ2 inside the exponential.
26.e The derivative of this effective potential is given by
∂
∂φVeff(φ)= 2φ
[ 1
2g2 + N4π ln(φ2μ2)].
This derivative vanishes atφ = 0, but this is a local maximum. The other zero of the derivative
is at
φ∗ ≡ μ exp
(
− πg2N).
One may check that this is a local minimum. Note that the location of this minimum depends
on the renormalization scale, but the minimum is always there, no matter which scale we
choose. Note also that this minimum is non-perturbative since its value is a non-analytic
function of the couplingg (more precisely, it is a function whose Taylor coefﬁcients atg = 0
are all zero). Because of the couplingψnφψn, and the non-zero expectation value of the scalar
ﬁeld, the fermions become massive in the ground state of this theory (this is similar to the
Higgs mechanism), and the chiral symmetry is spontaneously broken.
26.f Diagrammatically, the determinant resulting from the integration over the fermion ﬁelds
corresponds to the sum of all the diagrams with one fermion loop, dressed by insertions of the
scalar ﬁeldφ. By its position inside the exponential, N acts in a similar way to ¯h−1. Taking
the limitN → +∞ has the same effect as taking the limit ¯h → 0, namely eliminating all the
higher-order corrections. For this reason, the results we have derived in this problem do not
receive any higher-order corrections whenN is very large.


===== PDF PAGE 294 =====
29 COMPLEX LANGEVIN EQUATION 123
propagator. By combining contributions of ordersη andη3 in twoϕ’s, we can construct the
following more elaborate example:
ττ
τ' p
k =
∫
dτ′ d4k(2π)4 G(τ,τ ′,p )G(τ′,τ ′,k )G (τ,τ ′, −p)
=
∫τ
0
dτ′ d4k(2π)4 e−(m2+p2)(τ−τ′) −e−(m2+p2)(τ+τ′)p2 +m2
× 1 −e−2(m2+k2)τ′
k2 +m2 e−(m2+p2)(τ−τ′)
=
τ→∞
1
2
1
(p2 +m2)2
∫ d4k
(2π)4
1
k2 +m2.
We again recover the expected perturbative contribution (ultraviolet divergence included).
Source: Damgaard, P. H. and H¨uffel, H. (1987), Phys Rep 152: 227.
29. Complex Langevin Equation This problem is a continuation of Problem 28. Its goal
is to explore within a toy model what happens when the action is complex-valued, leading to
a complex Langevin equation. We consider the “action” S(x) ≡ α2x2 + β4 x4, and write thefollowing Langevin equation:
∂τx =− S′(x)+ η, ⟨η(τ)⟩η = 0, ⟨η(τ)η(τ′)⟩η = 2δ(τ −τ′).
29.a Whenα,β are complex, why can’t the distribution ofx deﬁned from solutions of this
equation be proportional to exp(−S(x))?
29.b Show that the momentsCn ≡
⟨zn(τ)
n!
⟩
η (if they converge) satisfy in the limitτ →∞ the
same three-term recurrence relation,
Cn−2 = αnCn +βn(n +1)(n +2)Cn+2,
as the true moments
∫
dx xnn! exp(−S(x))/ ∫dx exp(−S(x)).
29.c Show that the momentsCn obtained from the complex Langevin equation coincide with
the true moments if we have limn→∞ Cn = 0.
29.d Ifβ ∈ R ∗+, ﬁnd a condition onα that guarantees the convergence of the momentsCn
(use results from Gibson, P. M. (1971),Proc Edinb Math Soc 17(4): 317).
29.e Show that the complex Langevin equation is equivalent to the following Fokker–Planck
equation for a distributionPτ(x,y ) over the complex plane:
∂τPτ(x,y )=
(
∂2x +∂xReS′(x+iy)+∂yImS′(x+iy))Pτ(x,y ).


===== PDF PAGE 295 =====
124 2 FUNCTIONAL METHODS
29.f For β = 0,α ≡ a +ib, show that the ﬁxed point of this Fokker–Planck equation is
Gaussian,
P∞(x,y ) ∝ exp
{
−a
(
x2 + 2ab xy +(1 + 2a2b )y2)}.
Although everything looks ﬁne in this case, what practical problem arises whenb ≫ a ?
29.a As we have seen in Problem 28, when α,β are positive real integers we can view
exp(−S(x)) as a probability distribution on the real axis, and generate an ensemble of x’s that
samples this distribution by solving the following Langevin equation:
∂τx =− S′(x)+ η, ⟨η(τ)⟩ = 0, ⟨η(τ)η(τ′)⟩ = 2δ(τ −τ′). (2.38)
Moreover, the probability distribution Pτ(x) of an ensemble of x’s that obey this Langevin
equation evolves according to a Fokker–Planck equation,
∂τPτ = ∂x
(
∂x +S′(x))Pτ,
that admits exp(−S(x)) as a unique ﬁxed point.
Consider now the case where the coefﬁcients α,β that deﬁne S(x) are complex. In this
case, the weight exp(−S(x)) in the integral is complex-valued and cannot be interpreted as a
probability distribution (moreover, in this case, the integrand has a strong oscillatory behavior
that prevents evaluation by Monte Carlo sampling).
On the other hand, when we solve the Langevin equation (2.38) with a complex action,
it leads to complex solutions even if the initial condition and the noise are real-valued. For
this reason, it is called a complex Langevin equation. Thus, the equilibrium distribution of an
ensemble ofz ≡ x +iy’s obeying this Langevin equation is a positive deﬁnite distribution on
the complex plane, i.e., deﬁnitely not the complex-valued weight exp(−S(x)) of the original
integral.
29.b From the solution of the complex Langevin equation, let us deﬁneτ-dependent moments
by averaging over the noise, as follows:
Cn(τ) ≡ Z−1
∫
[Dη] zn(τ)n! e−14 ∫η2, with Z ≡ ∫ [Dη]e−14 ∫η2.
From this representation, we obtain the derivative of the moments with respect toτ:


===== PDF PAGE 296 =====
29 COMPLEX LANGEVIN EQUATION 125
∂τCn(τ)= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!∂τz(τ) e−14 ∫ η2
= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!
(
−S′(z(τ)) +η(τ)) e−14 ∫ η2
= Z−1
∫[
Dη(τ)
] zn−1(τ)
(n −1)!
(
−S′(z(τ)) −2 δδη(τ)) e−14 ∫ η2
=−
⟨xn−1(τ)
(n −1)! S′(x(τ))⟩η +2⟨xn−2(τ)(n −2)! δz(τ)δη(τ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 12
⟩
η
,
i.e.,
∂τCn(τ)= Cn−2 −αnCn −βn(n +1)(n +2)Cn+2. (2.39)
Consider now the true moments of this toy model,
Mn ≡
∫
dx e−S(x) xnn!∫
dx e−S(x) .
A simple integration by parts shows that
Mn−2 = αnMn +βn(n +1)(n +2)Mn+2.
Interestingly, the ﬁxed points of the equation (2.39) (deﬁned by requiring that∂τCn = 0) obey
exactly the same three-term recurrence relation.
This has led to the conjecture that the probability distributionPτ(x,y ) in the complex plane
(we denote byx andy the real and imaginary parts, respectively) followed by an ensemble of
solutions of the complex Langevin equation is such that
lim
τ→∞
∫
dxdy Pτ(x,y )f(x +iy)=?
∫
dx e−S(x) f(x). (2.40)
The remarkable aspect if this equality (if true) is that the left hand side has a positive weight
over C and the test functionf is evaluated at complex numbers, while on the right-hand side
the functionf is evaluated solely on the real axis but weighted with a complex-valued action.
This certainly requires at a minimum that the functionf(z) be analytic so that the values on
the real axis are related to those in the rest of the complex plane (but this limitation should
not be a surprise, since we arrived at this conjecture from considerations on the moments). If
this conjecture were valid (and generalizable from this toy model to a realistic quantum ﬁeld
theory), it would offer the prospect of turning a path integral that has a sign problem (e.g.,
a path integral in Minkowski spacetime) into one that has a positive deﬁnite weight over a
complexiﬁed ﬁeld space (and is thus approachable by Monte Carlo sampling).
The question of the validity of the conjecture (2.40) can in fact be divided into three
sub-questions:
1. If the moments Cn(τ) deﬁned from the complex Langevin equation do converge to a
ﬁxed point, does this ﬁxed point actually give the true momentsMn?


===== PDF PAGE 297 =====
126 2 FUNCTIONAL METHODS
−4
−3
−2
−1
0
1
2
3
4
5
0 500 1000 1500 2000 2500 3000 3500
ρn/2000, ϕn   (Cn,Mn = 10−ρn eiϕn )
n
α = 1+5i, β = 1
true moments
recur. w. C5000=0
Figure 2.9 Comparison of the true momentsMn (evaluated numerically) and the moments
Cn obtained by solving the recurrence with the constraintsC0 = 1,C5000 = 0. The moments
are parameterized as10−ρneiϕn ; the exponentρn (divided by2000, open squares and solid
line) and the phaseϕn (open circles and solid dots) are both shown in the plot.
2. Do they actually converge to a ﬁxed point?
3. In practice one has only a ﬁnite number of solutions of the complex Langevin equation,
which is equivalent to evaluating the left-hand side of (2.40) by Monte Carlo sampling.
Even though the distributionPτ(x,y ) is positive, are there situations where the integral
onx,y cannot be sampled efﬁciently?
29.c The recurrence relation satisﬁed both by the ﬁxed point of the Cn and by the true
moments Mn is not sufﬁcient to uniquely determine the moments, and therefore cannot
guarantee that the Cn and Mn are equal. Since this recurrence is linear and involves three
terms, the space of its solutions is a linear space of dimension two. The zeroth-order moment
is trivially ﬁxed at C0 = M0 = 1 in both cases, which reduces to one the dimension of the
space of solutions. One may check that the true momentsMn go to zero whenn →∞ , thanks
to the factorial included in their deﬁnition. Therefore, if we also had C∞ = 0, the recurrence
would determine a unique sequence of moments, and this sequence would coincide with the
true moments. This is illustrated in Figure 2.9 (for practical reasons related to the numerical
algorithm used to solve the recurrence, we have set C5000 = 0 instead of C∞ = 0), where
we see a perfect agreement (both in norm and in phase) between the true moments and those
obtained by solving the recurrence.
29.d Let us now discuss the convergence of the momentsCn whenτ → +∞. Since C0 = 1
is independent ofτ, and using the fact that the odd moments are zero, we can write the equation
of motion of the higher moments as follows:
∂τC = C∗ +BC,
where we denote


===== PDF PAGE 298 =====
29 COMPLEX LANGEVIN EQUATION 127
C ≡
⎛
⎜⎜⎜⎝
C2
C4
...
C2N
⎞
⎟⎟⎟⎠, C∗ ≡
⎛
⎜⎜⎜⎝
C0
0
...
0
⎞
⎟⎟⎟⎠, B ≡
⎛
⎜⎜⎜⎝
−2α −24β 0 ··· 00
1 −4α −120β ··· 00
... ... ... ... ...
00 0 ··· 1 −2Nα
⎞
⎟⎟⎟⎠.
(Here, we have truncated the recurrence by imposing that C2N+2 = 0. Alternatively, one could
view B as a matrix of inﬁnite size.) The matrix B is invertible, and the ﬁxed point of the
preceding equation is given by
C(∞)=− B−1C∗.
Whether the solution actually converges to this ﬁxed point is controlled by the sign of the real
part of the eigenvalues of the matrix B. A formal solution of the equation of motion of the
moments is
C(τ)= eτB
[
C(0)+
∫τ
0
dτ′ e−τ′B C∗] ,
where C(0) is the initial condition for the moments C2,4,6,.... For this solution to forget its
initial condition, we must have
lim
τ→+∞
eτB = 0,
which requires that all the eigenvalues of B have strictly negative real parts. (The matrix
B is non-Hermitian, and therefore not necessarily diagonalizable. However, the property
exp(τB) → 0 if all eigenvalues have negative real parts remains true, as can be seen by using
the Jordan form of the matrix.) Moreover, when this is the case, we also have
lim
τ→+∞
eτB
∫τ
0
dτ′ e−τ′B =− B−1,
which ensures that the solution converges to the expected ﬁxed point.
Whenβ ∈ R (in this case,β should be positive for the original integral to make sense), we
may use the following theorem (see Gibson, P. M. (1971),Proc Edinb Math Soc 17(4): 317):
given a complex tri-diagonal matrix
Ω ≡
⎛
⎜⎜⎜⎜⎜⎜⎜⎜⎝
b1 c1 0 ··· 00
a1 b2 c2 ··· 00
0a 2 b3 ··· 00
... ... ... ... ...
000 ··· bn−1 cn−1
000 ··· an−1 bn
⎞
⎟⎟⎟⎟⎟⎟⎟⎟⎠,
withai,bi,ci ∈ C ,i faici ∈ R andaici ≤ 0 for all1 ≤ i ≤ n −1, then all the eigenvaluesλ
ofΩ satisfy
min
{
Re (bi)
}
≤ Re (λ) ≤ max
{
Re (bi)
}
.
Therefore, whenβ is real positive, we may conclude that all the eigenvalues ofB have a real
part whose sign is opposite to that of the real part ofα:


===== PDF PAGE 299 =====
128 2 FUNCTIONAL METHODS
•R e (α) >0 : Re (λ) <0 for all eigenvalues, and the moments converge to the ﬁxed
point, in a ﬁctitious time at most τ ∼ (2 Re (α))−1 (this is the inverse of the smallest
possible real part, among all eigenvalues).
•R e (α) <0 : Re (λ) >0 for all eigenvalues, and the moments diverge (but would
converge if we changed the direction of the evolution,τ → −τ).
29.e The derivation of the time evolution of the distribution Pτ(x,y ) can be done by the
same method as the one used in Problem 28, by considering a generic test functionF(x,y ) and
writing
∫
dxdy
(
∂τPτ
)
F = Z−1
∫
[Dη]
{
(∂τx)∂xF +(∂τy)(∂yF)
}
e−14 ∫η2
= Z−1
∫
[Dη]
{
(−ReS′ + η/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
−2 δδη
)∂xF +( −ImS′)(∂yF)}e−14 ∫η2.
Then, we integrate the derivative with respect toη by parts to let it act on∂xF, which gives
2 δδη(τ)∂xF = 2 δx(τ)δη(τ)/bracehtipupleft /bracehtipdownright/bracehtipdownleft /bracehtipupright
= 12
∂2xF = ∂2xF.
Therefore, we have
∫
dxdy
(
∂τPτ
)
F =
∫
dxdy Pτ
{
∂2xF − ReS′(∂xF)− ImS′(∂yF)}
=
∫
dxdy F
{
∂2x +∂xReS′ +∂yImS′
}
Pτ,
which gives the announced Fokker–Planck equation since this equality must be true for any
test functionF(x,y ).
29.f Let us assume a quadratic action, i.e.,β ≡ 0,α ≡ a +ib. The statement of the problem
announces an asymptotic solution in the form of the exponential of a polynomial of degree
two, of the form
− lnP∞(x,y )= 12(ux2 +vy2 +2wxy).
Fixed points of the Fokker–Planck equation make its right-hand side vanish. With the above
ansatz, this results in the following set of equations for the coefﬁcientsu,v,w :
u2 = au +bw, w 2 = av −bw, 2uw = 2aw +b(v −u),u = 2a.
(The four equations correspond to equating to zero the coefﬁcients ofx2,y2,xy and1, respec-
tively.) Onceu is known, it is straightforward to obtain the other coefﬁcients,
w = 2a2b ,v = 2a(1 + 2a2b2 ).
(One should also check that the fourth equation is satisﬁed by this solution.) Therefore, when
β = 0, we indeed obtain the announced ﬁxed point. This distribution looks completely
innocuous, with rapidly falling tails in all directions of the complex plane.


===== PDF PAGE 300 =====
29 COMPLEX LANGEVIN EQUATION 129
When b ≫ a (i.e., when the original integral suffers from a severe sign problem), this
distribution becomes nearly isotropic in thex,y plane:
P∞(x,y )=a≪b
a
π exp
{
−a
(
x2 +y2)}. (2.41)
(We have restored the proper normalization prefactor.) From this isotropic distribution, we
would predictC0 = 1,C2,4,6,... = 0, while the exact moments are
M2n = 12nn!(a +ib)n ≈ 12nn!bn.
The momentz2n/(2n)! obtained with (2.41) in an angular slice [θ,θ +ϵ] reads
ϵ
∫ ∞
0
dr raπe−ar2 r2ne2inθ(2n)! = ϵπ n!e2inθan(2n)! ≫ M2n.
Had we performed the calculation with the exact distributionP∞(x,y ), we would have
ϵ
∫ ∞
0
dr rP∞(x,y ) r2ne2inθ(2n)! = ϵπ n!e2inθan(2n)! {1⊕ ab ⊕···⊕ anbn/bracehtipupleft/bracehtipdownright/bracehtipdownleft/bracehtipupright
order
ofM2n
⊕···
}
.
We see that the correct result forM2n results from cancellations in the angular integration over
θ (thanks to the weight e2inθ), such that the result ∼ a−n in a small angular slice is reduced to
b−n after the angular integration. Thus, the sign problem we sought to circumvent reappears
in a (milder) form that renders difﬁcult the evaluation of high-order moments.


exit_code=0
```
