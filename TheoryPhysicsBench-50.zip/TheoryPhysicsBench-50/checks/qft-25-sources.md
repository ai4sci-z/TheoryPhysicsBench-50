# QFT-25：标量强场产对、相干脉冲与玻色统计


来源：François Gelis, *Problems in Quantum Field Theory*, 第80题；用户PDF实际页209–217，书页331–339。题包材料及数值工况是本项目原创改造，未复制整本教材。


原文件：`/Users/ai4s/Downloads/Problems in Quantum Field Theory by FrançoisGelis.pdf`。SHA256：`7d96378d8e191e4e4f37fe03df3fb37cbb4ce5c0622438ae5fbafba03efa53b5`。PDF章节发生重排，以上页码逐题定位，不使用全书统一偏移。

## 原题与改造的界线

## 研究问题与约定

Gelis 第80题是**复标量 QED**的外场产对。自然单位，\(e=1\)、`mass=m`。外场空间均匀，temporal gauge \(A_0=0\)，仅 \(A_z(t)\ne0\)，电场 \(E_z=-\dot A_z\)。经典外场预先给定，不含反作用、自相互作用、光子环或费米子 Pauli 阻塞。

`backgrounds` 定义
\[
A_z(t)=A_{shift}+A_{offset}+\sum_j a_j\tanh[(t-t_j)/\tau_j],
\qquad -T\le t\le T.
\]
`pulses` 每项 `[a,center,tau]`；`offset` 是物理上对齐孤立脉冲与双脉冲相应阶段的常势，`shift` 是与canonical动量一起改变的规范平移，两者不能混用。使用输入给定有限 \(T\) 处的频率作为精确初末频率约定。对于每个 `modes`，规范未平移时 canonical \(k_z\) 就是公开 `kz`；背景含 `shift` 时必须同时取 \(k_z=\)`kz-shift`，这样 \(k_z+A_z\) 不变。`kperp` 是横动量模长。

模方程与初值为
\[
\ddot u+[m^2+k_\perp^2+(k_z+A_z(t))^2]u=0,
\qquad u(-T)=\frac1{\sqrt{2\omega_{in}}},\quad
\dot u(-T)=-i\sqrt{\omega_{in}/2}.
\]
在 \(+T\) 用正负频模分解，数目 \(n_k=|\beta_k|^2\)，满足玻色归一化 \(|\alpha_k|^2-|\beta_k|^2=1\)。评分只比较不变量，不把相位约定不同的裸 \(\alpha,\beta\) 判错。要求同时报告末态 kinetic 纵动量 \(p_{z,out}=k_z+A_z(T)\)。

每个离散输入 mode **恰好代表一个独立 canonical 模对**（正粒子 \(k\) 与负粒子 \(-k\)）；即使列表含 \(k_z\) 正负两种数值，它们是不同的模对，不额外乘二或再除二。每模产对数服从几何分布，而非 Poisson。对有限模集，计算总产对数均值 \(\mu\)、方差 \(v\)、\(\log P_0\) 及总粒子—反粒子数协方差 \(c_{+-}\)。不要混淆“总对数”与“粒子加反粒子总数”。

## 必须交付

每个 `背景ID-modeID` 行，`values=[n_k,abs_alpha_squared,pz_out]`。
每个 `背景ID-statistics` 行，`values=[mean_pairs,variance_pairs,log_vacuum_survival,cov_particle_antiparticle]`。

`first` 和 `second` 分别是孤立的正/负 Sauter 阶跃背景，`offset=1.2` 使其渐近常势分别为0→2.4、2.4→0，与 `double` 对应的两个阶段对齐；`double` 是两阶跃相干组合，`gauge-shifted` 是同一 double 的残余规范平移。对于每个 `interference-modeID` 行，报告
\[
 [n_{double}/\max(n_{first}+n_{second},\epsilon),\quad
 |n_{double}-n_{first}-n_{second}|/\max(n_{first}+n_{second},\epsilon)],
\]
其中 \(\epsilon=\)`occupation_floor`。两个孤立背景按同一 canonical 参考动量、已经对齐的渐近常势比较；分母是逐脉冲占据数的非相干相加预测，不包含相位干涉或玻色刺激项，不允许另行平移动量后重新定义分母。

任务包含频率变化、双脉冲相位干涉、规范平移和玻色统计。仅用常场率或把两次产对概率相加不能完成全部输出。公开容差对极小占据数采用绝对尺度，不按无意义的极小谱尾相对精度扣分。


## 验证路线

参考解积分二阶复KG方程，在末端按固定频率投影：beta=sqrt(omega_out/2)(u+udot/(i omega_out))，alpha采用相反号，比较模长。独立真值使用一阶绝热Bogoliubov系统：theta'=omega，alpha'=q exp(2i theta) beta，beta'=q exp(-2i theta) alpha，q=omega'/(2omega)。它不调用二阶参考函数；两个孤立Sauter背景另与解析谱核验。

对offset+a*tanh((t-center)/tau)，解析n=[cosh(2pi sqrt((a tau)²-1/4))+cosh(pi tau(omega_out-omega_in))]/[2 sinh(pi tau omega_in)sinh(pi tau omega_out)]，omega_in/out均使用已给offset和正确渐近kinetic动量。有限T尾误差已小于公开绝对容差。数值Wronskian残差独立核查。

每模两模压缩真空给几何对数分布：均值n，方差n(1+n)，P0=1/(1+n)。独立模相乘故log P0=-sum log(1+n)，总粒子与反粒子数相同，协方差等于对数方差。基线是一次绝热/Born混合并以Poisson作稀薄近似，具有明确适用层次；对双脉冲与增强占据数需改进。

公开镜像只复制environment/public，不含solution、tests或生成参数。真值和生成参数保留在tests/private，只由隔离verifier使用。参数/工况公开，私有的是真值，不是隐藏物理规律。
