
### 2026-11-16T22:09:25.635623+08:00

```bash
docker run --rm --cpus 4 --memory 4g --network none --user 0 -v '/Users/ai4s/Desktop/研一上/09、大模型理论与应用/期末项目60%/01-大作业开发/TheoryPhysicsBench-30:/workspace' -w /workspace theory-physics-qft04:dev python3 tools/build_tm04_truth.py
```

```text
[
  {
    "id": "body-01",
    "rk4_richardson_difference": 1.2698268362735615e-13,
    "energy_residual": 1.0658141036401503e-14,
    "momentum2_residual": 2.042810365310288e-14
  },
  {
    "id": "body-02",
    "rk4_richardson_difference": 2.93772529450879e-15,
    "energy_residual": 2.7755575615628914e-14,
    "momentum2_residual": 2.7977620220553945e-14
  },
  {
    "id": "body-03",
    "rk4_richardson_difference": 2.843836277577338e-14,
    "energy_residual": 7.37188088351104e-14,
    "momentum2_residual": 2.220446049250313e-13
  },
  {
    "id": "body-04",
    "rk4_richardson_difference": 4.574873755288274e-13,
    "energy_residual": 1.7985612998927536e-14,
    "momentum2_residual": 2.5757174171303632e-14
  },
  {
    "id": "body-05",
    "rk4_richardson_difference": 1.1324274851176596e-15,
    "energy_residual": 5.10702591327572e-15,
    "momentum2_residual": 4.9960036108132044e-15
  },
  {
    "id": "body-06",
    "rk4_richardson_difference": 6.12547050119853e-14,
    "energy_residual": 1.3322676295501878e-14,
    "momentum2_residual": 3.9968028886505635e-14
  }
]

exit_code=0
```
